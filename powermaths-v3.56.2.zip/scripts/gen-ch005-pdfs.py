#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Power Maths · Mensuration (CH005) — PDF generator
=================================================
Generates 7 educational PDFs for the "Mensuration" chapter:

  materials/CH005-material-01-2d-figures.pdf
  materials/CH005-material-02-3d-figures.pdf
  materials/CH005-material-03-composite-problems.pdf
  practice/CH005-practice-01.pdf
  practice/CH005-practice-01-solutions.pdf
  practice/CH005-practice-02.pdf
  practice/CH005-practice-02-solutions.pdf

Author: PDF generation subagent (Task ID pdf-CH005)
For: Power Maths · by Prof. Kalpesh Vyas
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    KeepTogether, Flowable, HRFlowable,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfgen import canvas as canvaslib

# ============================================================
# Font registration — DejaVuSans (Unicode math symbols: √ π ² ³ × ÷ ≠ ≤ ≥ ±)
# ============================================================
_FONT_DIR = "/usr/share/fonts/truetype/dejavu"
pdfmetrics.registerFont(TTFont("PMBody",        os.path.join(_FONT_DIR, "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("PMBody-Bold",   os.path.join(_FONT_DIR, "DejaVuSans-Bold.ttf")))
# DejaVuSans has no native italic; we map italic→regular, bold-italic→bold.
registerFontFamily(
    "PMBody",
    normal="PMBody", bold="PMBody-Bold",
    italic="PMBody", boldItalic="PMBody-Bold",
)

# ============================================================
# Brand colours — dark slate / teal / emerald (NO blue/indigo)
# ============================================================
BRAND_DARK   = colors.HexColor("#0f766e")   # teal-700
BRAND        = colors.HexColor("#115e59")   # teal-800
ACCENT       = colors.HexColor("#047857")   # emerald-700
HEAD         = colors.HexColor("#134e4a")   # teal-900
INK          = colors.HexColor("#1f2937")   # slate-800
MUTED        = colors.HexColor("#64748b")   # slate-500
SOFT_INK     = colors.HexColor("#334155")   # slate-700
LIGHT_BG     = colors.HexColor("#f1f5f9")   # slate-100 (example box bg)
TIP_BG       = colors.HexColor("#ecfdf5")   # emerald-50
TIP_BORDER   = colors.HexColor("#10b981")   # emerald-500
BOX_BORDER   = colors.HexColor("#cbd5e1")   # slate-300
ANSWER_LINE  = colors.HexColor("#94a3b8")   # slate-400
TABLE_HEAD_BG= colors.HexColor("#0f766e")   # teal-700
TABLE_ALT_BG = colors.HexColor("#f0fdfa")   # teal-50

# ============================================================
# Page geometry (A4 = 595.27 × 841.89 pt)
# ============================================================
PAGE_W, PAGE_H = A4
LEFT_M   = 1.6 * cm
RIGHT_M  = 1.6 * cm
TOP_M    = 2.4 * cm
BOTTOM_M = 1.9 * cm
CONTENT_W = PAGE_W - LEFT_M - RIGHT_M

# ============================================================
# Paragraph styles
# ============================================================
def _styles():
    s = {}
    s["doc_kicker"] = ParagraphStyle(
        "doc_kicker", fontName="PMBody-Bold", fontSize=9,
        textColor=ACCENT, leading=12, spaceAfter=2,
        alignment=TA_LEFT)
    s["doc_title"] = ParagraphStyle(
        "doc_title", fontName="PMBody-Bold", fontSize=21,
        textColor=HEAD, leading=25, spaceAfter=2)
    s["doc_subtitle"] = ParagraphStyle(
        "doc_subtitle", fontName="PMBody", fontSize=12,
        textColor=BRAND_DARK, leading=16, spaceAfter=6)
    s["doc_meta"] = ParagraphStyle(
        "doc_meta", fontName="PMBody", fontSize=9.5,
        textColor=MUTED, leading=13, spaceAfter=8)
    s["h1"] = ParagraphStyle(
        "h1", fontName="PMBody-Bold", fontSize=15,
        textColor=BRAND, leading=19, spaceBefore=10, spaceAfter=5)
    s["h2"] = ParagraphStyle(
        "h2", fontName="PMBody-Bold", fontSize=12.5,
        textColor=ACCENT, leading=16, spaceBefore=7, spaceAfter=3)
    s["body"] = ParagraphStyle(
        "body", fontName="PMBody", fontSize=11,
        textColor=INK, leading=18, spaceAfter=5, alignment=TA_LEFT)
    s["body_just"] = ParagraphStyle(
        "body_just", parent=s["body"], alignment=TA_JUSTIFY, leading=18)
    s["bullet"] = ParagraphStyle(
        "bullet", parent=s["body"], leftIndent=14, bulletIndent=2,
        spaceAfter=2)
    s["formula"] = ParagraphStyle(
        "formula", fontName="PMBody-Bold", fontSize=11.5,
        textColor=HEAD, leading=15.5, alignment=TA_CENTER, spaceAfter=2)
    s["ex_label"] = ParagraphStyle(
        "ex_label", fontName="PMBody-Bold", fontSize=10.5,
        textColor=BRAND, leading=14, spaceAfter=2)
    s["ex_body"] = ParagraphStyle(
        "ex_body", fontName="PMBody", fontSize=10.5,
        textColor=INK, leading=16.5, spaceAfter=3)
    s["ex_step"] = ParagraphStyle(
        "ex_step", fontName="PMBody", fontSize=10.5,
        textColor=SOFT_INK, leading=16.5, spaceAfter=2, leftIndent=10)
    s["ex_answer"] = ParagraphStyle(
        "ex_answer", fontName="PMBody-Bold", fontSize=11,
        textColor=ACCENT, leading=16, spaceAfter=3, leftIndent=10)
    s["tip"] = ParagraphStyle(
        "tip", fontName="PMBody", fontSize=10, textColor=HEAD,
        leading=14, leftIndent=8, spaceAfter=2)
    s["q"] = ParagraphStyle(
        "q", fontName="PMBody", fontSize=11, textColor=INK,
        leading=17, spaceAfter=4, spaceBefore=6)
    s["q_num"] = ParagraphStyle(
        "q_num", fontName="PMBody-Bold", fontSize=11,
        textColor=BRAND, leading=16)
    s["opt"] = ParagraphStyle(
        "opt", fontName="PMBody", fontSize=10.5, textColor=INK,
        leading=14, leftIndent=22, spaceAfter=1)
    s["tbl_cell"] = ParagraphStyle(
        "tbl_cell", fontName="PMBody", fontSize=9.5,
        textColor=INK, leading=13)
    s["tbl_cell_c"] = ParagraphStyle(
        "tbl_cell_c", parent=s["tbl_cell"], alignment=TA_CENTER)
    s["tbl_head"] = ParagraphStyle(
        "tbl_head", fontName="PMBody-Bold", fontSize=9.5,
        textColor=colors.white, leading=13, alignment=TA_CENTER)
    s["sol_step"] = ParagraphStyle(
        "sol_step", fontName="PMBody", fontSize=10.5, textColor=INK,
        leading=16.5, spaceAfter=2, leftIndent=14)
    s["sol_ans"] = ParagraphStyle(
        "sol_ans", fontName="PMBody-Bold", fontSize=11, textColor=ACCENT,
        leading=16, spaceAfter=5, leftIndent=14)
    s["small_muted"] = ParagraphStyle(
        "small_muted", fontName="PMBody", fontSize=9, textColor=MUTED,
        leading=12, spaceAfter=2)
    return s

S = _styles()

# ============================================================
# Custom flowables
# ============================================================
class ExampleBox(Flowable):
    """Rounded light-gray box wrapping a list of flowables (worked example)."""
    def __init__(self, flowables, width=None, padding=8,
                 bg=LIGHT_BG, border=BOX_BORDER, radius=6):
        Flowable.__init__(self)
        self.flowables = flowables
        self._width_arg = width
        self.padding = padding
        self.bg = bg
        self.border = border
        self.radius = radius
        self._w = 0
        self._h = 0

    def wrap(self, availWidth, availHeight):
        w = self._width_arg or availWidth
        inner_w = w - 2 * self.padding
        total_h = 0
        for f in self.flowables:
            _, fh = f.wrap(inner_w, availHeight)
            total_h += fh
        self._w = w
        self._h = total_h + 2 * self.padding
        return (self._w, self._h)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(self.bg)
        c.setStrokeColor(self.border)
        c.setLineWidth(0.5)
        c.roundRect(0, 0, self._w, self._h, self.radius, fill=1, stroke=1)
        # Left accent stripe
        c.setFillColor(BRAND_DARK)
        c.rect(0, 0, 3, self._h, fill=1, stroke=0)
        c.restoreState()
        y = self._h - self.padding
        inner_w = self._w - 2 * self.padding
        for f in self.flowables:
            _, fh = f.wrap(inner_w, self._h)
            f.drawOn(c, self.padding + 3, y - fh)
            y -= fh


class TipBox(Flowable):
    """Emerald-tinted rounded box for tips / notes."""
    def __init__(self, flowables, width=None, padding=7,
                 bg=TIP_BG, border=TIP_BORDER, radius=6):
        Flowable.__init__(self)
        self.flowables = flowables
        self._width_arg = width
        self.padding = padding
        self.bg = bg
        self.border = border
        self.radius = radius
        self._w = 0
        self._h = 0

    def wrap(self, availWidth, availHeight):
        w = self._width_arg or availWidth
        inner_w = w - 2 * self.padding
        total_h = 0
        for f in self.flowables:
            _, fh = f.wrap(inner_w, availHeight)
            total_h += fh
        self._w = w
        self._h = total_h + 2 * self.padding
        return (self._w, self._h)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(self.bg)
        c.setStrokeColor(self.border)
        c.setLineWidth(0.6)
        c.roundRect(0, 0, self._w, self._h, self.radius, fill=1, stroke=1)
        c.restoreState()
        y = self._h - self.padding
        inner_w = self._w - 2 * self.padding
        for f in self.flowables:
            _, fh = f.wrap(inner_w, self._h)
            f.drawOn(c, self.padding, y - fh)
            y -= fh


class AnswerSpace(Flowable):
    """Dotted answer lines for practice sheets."""
    def __init__(self, width=None, n_lines=3, gap=18, color=ANSWER_LINE):
        Flowable.__init__(self)
        self._width_arg = width
        self.n_lines = n_lines
        self.gap = gap
        self.color = color
        self._w = 0
        self._h = 0

    def wrap(self, availWidth, availHeight):
        self._w = self._width_arg or availWidth
        self._h = self.n_lines * self.gap + 4
        return (self._w, self._h)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setStrokeColor(self.color)
        c.setLineWidth(0.4)
        c.setDash(1, 2)
        y = self._h - 2
        for _ in range(self.n_lines):
            c.line(0, y, self._w, y)
            y -= self.gap
        c.restoreState()


class HRule(Flowable):
    """Thin horizontal accent rule used as a divider."""
    def __init__(self, width=None, thickness=0.8, color=BOX_BORDER,
                 space_before=4, space_after=4):
        Flowable.__init__(self)
        self._width_arg = width
        self.thickness = thickness
        self.color = color
        self.space_before = space_before
        self.space_after = space_after

    def wrap(self, availWidth, availHeight):
        self._w = self._width_arg or availWidth
        self._h = self.thickness + self.space_before + self.space_after
        return (self._w, self._h)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setStrokeColor(self.color)
        c.setLineWidth(self.thickness)
        y = self.space_after
        c.line(0, y, self._w, y)
        c.restoreState()


# ============================================================
# Header / footer / "Page X of Y" via custom Canvas
# ============================================================
class NumberedCanvas(canvaslib.Canvas):
    """Two-pass canvas: collects every page state, then on save() draws the
    header strip + footer (copyright + 'Page X of Y') on each page."""
    def __init__(self, *args, **kwargs):
        canvaslib.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for i, state in enumerate(self._saved_page_states):
            self.__dict__.update(state)
            self._draw_chrome(i + 1, num_pages)
            canvaslib.Canvas.showPage(self)
        canvaslib.Canvas.save(self)

    def _draw_chrome(self, page_num, page_count):
        # ---- Header strip ----
        self.saveState()
        self.setFillColor(HEAD)
        self.rect(0, PAGE_H - 0.95 * cm, PAGE_W, 0.95 * cm, fill=1, stroke=0)
        # accent ribbon
        self.setFillColor(ACCENT)
        self.rect(0, PAGE_H - 1.02 * cm, PAGE_W, 0.07 * cm, fill=1, stroke=0)
        # Brand
        self.setFillColor(colors.white)
        self.setFont("PMBody-Bold", 10.5)
        self.drawString(LEFT_M, PAGE_H - 0.62 * cm, "Power Maths")
        # Section name (set via _pm_section attr)
        section = getattr(self, "_pm_section", "Mensuration")
        self.setFont("PMBody", 9.5)
        self.drawString(LEFT_M + 2.7 * cm, PAGE_H - 0.62 * cm, "·  " + section)
        # Author right
        self.setFont("PMBody", 9.5)
        self.drawRightString(PAGE_W - RIGHT_M, PAGE_H - 0.62 * cm,
                             "by Prof. Kalpesh Vyas")
        # ---- Footer ----
        self.setStrokeColor(BOX_BORDER)
        self.setLineWidth(0.4)
        self.line(LEFT_M, BOTTOM_M - 0.45 * cm,
                  PAGE_W - RIGHT_M, BOTTOM_M - 0.45 * cm)
        self.setFont("PMBody", 8)
        self.setFillColor(MUTED)
        self.drawString(LEFT_M, BOTTOM_M - 0.85 * cm,
                        "© Power Maths · Prof. Kalpesh Vyas · For enrolled students only")
        self.drawRightString(PAGE_W - RIGHT_M, BOTTOM_M - 0.85 * cm,
                             f"Page {page_num} of {page_count}")
        self.restoreState()


class PMDocTemplate(SimpleDocTemplate):
    """SimpleDocTemplate that pushes the section name onto every page's canvas."""
    def __init__(self, *args, section_name="Mensuration", **kwargs):
        SimpleDocTemplate.__init__(self, *args, **kwargs)
        self._pm_section = section_name

    def beforePage(self):
        try:
            self.canv._pm_section = self._pm_section
        except Exception:
            pass


# ============================================================
# Helper builders
# ============================================================
def P(text, style="body"):
    return Paragraph(text, S[style])

def h1(text):       return P(text, "h1")
def h2(text):       return P(text, "h2")
def body(text):     return P(text, "body")
def body_j(text):   return P(text, "body_just")

def formula_box(label, lines):
    """A small centered formula block with a thin border."""
    flowables = [P(label, "ex_label")] + [P(ln, "formula") for ln in lines]
    inner = Table(
        [[f] for f in flowables],
        colWidths=[CONTENT_W - 0.6 * cm],
    )
    inner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.5, BOX_BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return inner

def example(label, given, steps, answer):
    """Build a worked-example box (ExampleBox)."""
    flows = [P(label, "ex_label")]
    if given:
        flows.append(P(given, "ex_body"))
    flows.append(P("<b>Solution:</b>", "ex_body"))
    for st in steps:
        flows.append(P(st, "ex_step"))
    flows.append(P(answer, "ex_answer"))
    return KeepTogether([ExampleBox(flows)])

def sol_box(label, given, to_find, formula, lines, answer):
    """Rich solution box with Given / To find / Formula / Working / Answer.
    `lines` is a list of step strings (the substitution + simplification).
    For MCQ-style concise solutions, pass given=None, to_find=None, formula=None
    and a single-element `lines` list."""
    flows = [P(label, "ex_label")]
    if given:
        flows.append(P("<b>Given:</b>  " + given, "ex_body"))
    if to_find:
        flows.append(P("<b>To find:</b>  " + to_find, "ex_body"))
    if formula:
        flows.append(P("<b>Formula:</b>  " + formula, "ex_body"))
    flows.append(P("<b>Working:</b>", "ex_body"))
    for st in lines:
        flows.append(P(st, "ex_step"))
    flows.append(P(answer, "ex_answer"))
    return KeepTogether([ExampleBox(flows)])

def tip(title, text):
    flows = [P("★ <b>" + title + "</b>", "tip"), P(text, "tip")]
    return KeepTogether([TipBox(flows)])

def learning_objectives(items):
    """Render a 'Learning Objectives' list as a TipBox with bullets."""
    flows = [P("◆ <b>Learning Objectives</b>", "tip")]
    for it in items:
        flows.append(P("•  " + it, "tip"))
    return KeepTogether([TipBox(flows)])

def how_to_use():
    flows = [P("◆ <b>How to use this material</b>", "tip"),
             P("Read each formula box carefully, then work through the example "
               "with a pencil and paper before checking the answer. Cover the "
               "solution, attempt the question yourself, then compare. Repeat "
               "the worked examples until you can do them without looking.", "tip")]
    return KeepTogether([TipBox(flows)])

def doc_header_block(kicker, title, subtitle, meta):
    """Page-1 title block that appears under the top header strip."""
    flows = [
        P(kicker, "doc_kicker"),
        P(title, "doc_title"),
        P(subtitle, "doc_subtitle"),
        P(meta, "doc_meta"),
        HRule(thickness=1.0, color=ACCENT, space_before=0, space_after=6),
    ]
    return flows

def make_summary_table(headers, rows, col_widths=None):
    """Build a styled summary table with teal header row and zebra body."""
    head_row = [Paragraph(h, S["tbl_head"]) for h in headers]
    body_rows = []
    for r in rows:
        body_rows.append([Paragraph(c, S["tbl_cell_c"] if i > 0 else S["tbl_cell"])
                          for i, c in enumerate(r)])
    data = [head_row] + body_rows
    if col_widths is None:
        n = len(headers)
        col_widths = [CONTENT_W / n] * n
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), TABLE_HEAD_BG),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, BOX_BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for i in range(1, len(rows) + 1):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), TABLE_ALT_BG))
    t.setStyle(TableStyle(style))
    return t

def build_doc(path, section_name, story):
    """Build a single PDF."""
    doc = PMDocTemplate(
        path,
        pagesize=A4,
        leftMargin=LEFT_M, rightMargin=RIGHT_M,
        topMargin=TOP_M, bottomMargin=BOTTOM_M,
        title=section_name,
        author="Prof. Kalpesh Vyas",
        subject="Power Maths · Mensuration (CH005)",
        section_name=section_name,
    )
    doc.build(story, canvasmaker=NumberedCanvas)


# ============================================================
# Shared intro / chapter preface
# ============================================================
CHAPTER_INTRO = (
    "Mensuration is the branch of mathematics that deals with the measurement of "
    "geometric figures — their lengths (perimeter), areas, surface areas and volumes. "
    "In this chapter you will learn to compute these quantities for the common "
    "two-dimensional (2D) and three-dimensional (3D) shapes that you see every day: "
    "squares, rectangles, triangles, parallelograms, rhombuses, trapeziums, circles, "
    "cubes, cuboids, cylinders, cones, spheres and hemispheres."
)
PI_NOTE = "Throughout this chapter, take π = 22/7 unless the question states otherwise."

# ============================================================
# MATERIAL 1 — 2D Figures
# ============================================================
def material_1():
    out = "/home/z/my-project/public/materials/CH005-material-01-2d-figures.pdf"
    story = doc_header_block(
        "STUDY MATERIAL 1  ·  CHAPTER CH005",
        "Perimeter &amp; Area of 2D Figures",
        "Squares, rectangles, triangles, parallelograms, rhombuses, trapeziums, circles",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(CHAPTER_INTRO),
        learning_objectives([
            "Identify common 2D figures: square, rectangle, triangle, parallelogram, rhombus, trapezium, circle.",
            "State and apply the perimeter / circumference and area formula for each figure.",
            "Use Heron's formula to find the area of a triangle when its three sides are known.",
            "Convert between units of length and area (cm ↔ m, cm² ↔ m²) correctly.",
            "Solve real-life word problems involving cost of fencing, tiling and carpeting.",
        ]),
        how_to_use(),
        tip("Conventions used", PI_NOTE +
            " All lengths are in the same unit as the data (cm, m, etc.). "
            "Area is always expressed in square units (cm², m²) and perimeter / "
            "circumference in linear units (cm, m)."),
        h1("1.  Square"),
        body("A square is a quadrilateral with all four sides equal and all four "
             "angles 90°. Its diagonals are equal and bisect each other at right angles."),
        formula_box("Formulas — Square", [
            "Perimeter  =  4 × side  =  4a",
            "Area  =  (side)²  =  a²",
            "Diagonal  =  a × √2",
        ]),
        example(
            "Example 1.1",
            "A square tile has a side of 12 cm. Find its perimeter, area and the "
            "length of its diagonal (√2 = 1.414).",
            [
                "Perimeter = 4a = 4 × 12 = 48 cm",
                "Area = a² = 12² = 144 cm²",
                "Diagonal = a√2 = 12 × 1.414 = 16.97 cm",
            ],
            "Perimeter = 48 cm,  Area = 144 cm²,  Diagonal ≈ 16.97 cm",
        ),
        h1("2.  Rectangle"),
        body("A rectangle has opposite sides equal and parallel, and all four angles "
             "90°. The longer side is usually called the length (l) and the shorter "
             "side the breadth (b)."),
        formula_box("Formulas — Rectangle", [
            "Perimeter  =  2 × (length + breadth)  =  2(l + b)",
            "Area  =  length × breadth  =  l × b",
            "Diagonal  =  √(l² + b²)",
        ]),
        example(
            "Example 2.1",
            "A rectangular board measures 18 cm by 9 cm. Find its perimeter, area "
            "and the length of its diagonal.",
            [
                "Perimeter = 2(l + b) = 2 × (18 + 9) = 2 × 27 = 54 cm",
                "Area = l × b = 18 × 9 = 162 cm²",
                "Diagonal = √(l² + b²) = √(18² + 9²) = √(324 + 81) = √405 ≈ 20.12 cm",
            ],
            "Perimeter = 54 cm,  Area = 162 cm²,  Diagonal ≈ 20.12 cm",
        ),
        example(
            "Example 2.2",
            "The perimeter of a rectangle is 50 cm and its length is 15 cm. Find its "
            "breadth and area.",
            [
                "2(l + b) = 50  ⇒  l + b = 25",
                "15 + b = 25  ⇒  b = 10 cm",
                "Area = l × b = 15 × 10 = 150 cm²",
            ],
            "Breadth = 10 cm,  Area = 150 cm²",
        ),
        h1("3.  Triangle"),
        body("For any triangle, the area is half of base × corresponding height. "
             "When the three sides are known but the height is not, use Heron's "
             "formula. For an equilateral triangle, all sides are equal and all "
             "angles are 60°."),
        formula_box("Formulas — Triangle", [
            "Area  =  ½ × base × height  =  ½ × b × h",
            "Perimeter  =  a + b + c   (sum of three sides)",
            "Heron's formula:  Area = √(s(s − a)(s − b)(s − c)),   s = (a + b + c) / 2",
            "Equilateral triangle (side a):  Area = (√3 / 4) × a²,   height = (√3 / 2) × a",
        ]),
        example(
            "Example 3.1",
            "Find the area of a triangle whose base is 14 cm and whose "
            "corresponding height is 9 cm.",
            [
                "Area = ½ × b × h = ½ × 14 × 9 = 63 cm²",
            ],
            "Area = 63 cm²",
        ),
        example(
            "Example 3.2",
            "The three sides of a triangular plot are 13 m, 14 m and 15 m. "
            "Find its area using Heron's formula.",
            [
                "s = (13 + 14 + 15) / 2 = 42 / 2 = 21 m",
                "s − a = 8,   s − b = 7,   s − c = 6",
                "Area = √(21 × 8 × 7 × 6) = √7056 = 84 m²",
            ],
            "Area = 84 m²",
        ),
        example(
            "Example 3.3",
            "Find the area of an equilateral triangle with side 10 cm "
            "(take √3 = 1.732).",
            [
                "Area = (√3 / 4) × a² = (1.732 / 4) × 10²",
                "     = 0.433 × 100 = 43.3 cm²",
            ],
            "Area ≈ 43.3 cm²",
        ),
        h1("4.  Parallelogram"),
        body("A parallelogram has both pairs of opposite sides parallel and equal. "
             "Its area is the product of any side (taken as base) and the "
             "perpendicular height drawn to that base."),
        formula_box("Formulas — Parallelogram", [
            "Area  =  base × height  =  b × h",
            "Perimeter  =  2 × (a + b)   (where a and b are adjacent sides)",
        ]),
        example(
            "Example 4.1",
            "A parallelogram has a base of 16 cm and a height of 7 cm. Find its "
            "area and perimeter if the other side is 9 cm.",
            [
                "Area = b × h = 16 × 7 = 112 cm²",
                "Perimeter = 2(a + b) = 2 × (16 + 9) = 2 × 25 = 50 cm",
            ],
            "Area = 112 cm²,  Perimeter = 50 cm",
        ),
        h1("5.  Rhombus"),
        body("A rhombus has all four sides equal; its diagonals are perpendicular "
             "and bisect each other. The area can be found from the diagonals or "
             "from base × height."),
        formula_box("Formulas — Rhombus", [
            "Area  =  ½ × d₁ × d₂   (product of diagonals ÷ 2)",
            "Area  =  base × height  =  a × h",
            "Perimeter  =  4 × side  =  4a",
        ]),
        example(
            "Example 5.1",
            "The diagonals of a rhombus are 18 cm and 24 cm. Find its area and "
            "the length of each side.",
            [
                "Area = ½ × d₁ × d₂ = ½ × 18 × 24 = 216 cm²",
                "Side = ½ × √(d₁² + d₂²) = ½ × √(324 + 576) = ½ × √900 = ½ × 30 = 15 cm",
            ],
            "Area = 216 cm²,  Side = 15 cm",
        ),
        h1("6.  Trapezium (Trapezoid)"),
        body("A trapezium has exactly one pair of parallel sides, called the two "
             "bases. The perpendicular distance between the bases is the height."),
        formula_box("Formulas — Trapezium", [
            "Area  =  ½ × (sum of parallel sides) × height  =  ½ × (a + b) × h",
            "Perimeter  =  a + b + c + d",
        ]),
        example(
            "Example 6.1",
            "The parallel sides of a trapezium are 12 cm and 18 cm, and the "
            "distance between them is 8 cm. Find the area.",
            [
                "Area = ½ × (a + b) × h = ½ × (12 + 18) × 8",
                "     = ½ × 30 × 8 = 15 × 8 = 120 cm²",
            ],
            "Area = 120 cm²",
        ),
        h1("7.  Circle"),
        body("A circle is the set of all points in a plane at a fixed distance "
             "(the radius r) from a fixed point (the centre). The diameter "
             "d = 2r. The distance around the circle is its circumference."),
        formula_box("Formulas — Circle  (π = 22/7)", [
            "Circumference  =  2 π r  =  π d",
            "Area  =  π r²",
            "Area of a semicircle  =  ½ π r²   ·   Perimeter of a semicircle  =  π r + 2 r",
        ]),
        example(
            "Example 7.1",
            "Find the circumference and area of a circle of radius 21 cm "
            "(take π = 22/7).",
            [
                "Circumference = 2 π r = 2 × (22/7) × 21 = 2 × 22 × 3 = 132 cm",
                "Area = π r² = (22/7) × 21² = (22/7) × 441 = 22 × 63 = 1386 cm²",
            ],
            "Circumference = 132 cm,  Area = 1386 cm²",
        ),
        example(
            "Example 7.2",
            "The area of a circular park is 616 m². Find its radius and "
            "circumference (take π = 22/7).",
            [
                "π r² = 616  ⇒  r² = 616 × 7 / 22 = 196  ⇒  r = 14 m",
                "Circumference = 2 π r = 2 × (22/7) × 14 = 88 m",
            ],
            "Radius = 14 m,  Circumference = 88 m",
        ),
        h1("8.  Quick-reference summary"),
        make_summary_table(
            ["Figure", "Perimeter", "Area"],
            [
                ["Square (side a)",            "4a",                "a²"],
                ["Rectangle (l, b)",           "2(l + b)",          "l × b"],
                ["Triangle (b, h)",            "a + b + c",         "½ × b × h"],
                ["Equilateral Δ (a)",          "3a",                "(√3/4) × a²"],
                ["Parallelogram (b, h)",       "2(a + b)",          "b × h"],
                ["Rhombus (d₁, d₂)",           "4a",                "½ × d₁ × d₂"],
                ["Trapezium (a, b, h)",        "a + b + c + d",     "½ × (a + b) × h"],
                ["Circle (r)",                 "2 π r",             "π r²"],
            ],
            col_widths=[5.6 * cm, 4.0 * cm, CONTENT_W - 9.6 * cm],
        ),
        Spacer(1, 6),
        tip("Exam tip",
            "Always write the formula first, substitute the values with units, "
            "and only then compute. Examiners award method marks even when the "
            "final number is wrong, but only if every step is clearly shown."),
    ]
    build_doc(out, "Material 1 · 2D Figures", story)
    return out


# ============================================================
# MATERIAL 2 — 3D Figures
# ============================================================
def material_2():
    out = "/home/z/my-project/public/materials/CH005-material-02-3d-figures.pdf"
    story = doc_header_block(
        "STUDY MATERIAL 2  ·  CHAPTER CH005",
        "Surface Area &amp; Volume of 3D Figures",
        "Cube, cuboid, cylinder, cone, sphere, hemisphere",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Three-dimensional (solid) figures occupy space. Two measurements "
            "are most useful: the total surface area (TSA) — the area of the "
            "outer skin of the solid — and the volume (V) — the amount of "
            "space enclosed by it. Surface area is measured in square units "
            "(cm², m²) and volume in cubic units (cm³, m³)."),
        learning_objectives([
            "Identify common 3D solids: cube, cuboid, cylinder, cone, sphere, hemisphere.",
            "Distinguish between curved (lateral) surface area and total surface area.",
            "Apply the correct formula for CSA, TSA and volume of each solid.",
            "Use the relation l² = r² + h² to find the slant height of a cone.",
            "Convert between cubic metres, cubic centimetres and litres for capacity problems.",
        ]),
        how_to_use(),
        tip("Conventions", PI_NOTE +
            " Curved Surface Area (CSA) is the area of only the curved part; "
            "Total Surface Area (TSA) = CSA + area of any flat base(s)."),
        h1("1.  Cube"),
        body("A cube has 6 identical square faces, 12 equal edges and 8 vertices. "
             "If the edge is a, then all faces are a × a squares."),
        formula_box("Formulas — Cube (edge a)", [
            "Lateral Surface Area (LSA)  =  4 a²",
            "Total Surface Area (TSA)  =  6 a²",
            "Volume  =  a³",
            "Diagonal of cube  =  a √3",
        ]),
        example(
            "Example 1.1",
            "A cubical box has an edge of 6 cm. Find its TSA, volume and the "
            "length of its diagonal (take √3 = 1.732).",
            [
                "TSA = 6 a² = 6 × 6² = 6 × 36 = 216 cm²",
                "Volume = a³ = 6³ = 216 cm³",
                "Diagonal = a √3 = 6 × 1.732 = 10.39 cm",
            ],
            "TSA = 216 cm²,  Volume = 216 cm³,  Diagonal ≈ 10.39 cm",
        ),
        example(
            "Example 1.2",
            "The volume of a cubical tank is 3375 m³. Find the length of its "
            "edge and its total surface area.",
            [
                "Volume = a³ = 3375  ⇒  a = ∛3375 = 15 m",
                "TSA = 6 a² = 6 × 15² = 6 × 225 = 1350 m²",
            ],
            "Edge = 15 m,  TSA = 1350 m²",
        ),
        h1("2.  Cuboid"),
        body("A cuboid has 6 rectangular faces, 12 edges and 8 vertices. Three "
             "edges meeting at a vertex are its length (l), breadth (b) and "
             "height (h)."),
        formula_box("Formulas — Cuboid (l, b, h)", [
            "LSA  =  2 (l + b) × h",
            "TSA  =  2 (l b + b h + h l)",
            "Volume  =  l × b × h",
            "Diagonal  =  √(l² + b² + h²)",
        ]),
        example(
            "Example 2.1",
            "A closed wooden box measures 10 cm × 8 cm × 5 cm. Find its TSA, "
            "volume and the length of its diagonal.",
            [
                "TSA = 2(lb + bh + hl) = 2(10×8 + 8×5 + 5×10)",
                "    = 2(80 + 40 + 50) = 2 × 170 = 340 cm²",
                "Volume = l × b × h = 10 × 8 × 5 = 400 cm³",
                "Diagonal = √(l² + b² + h²) = √(100 + 64 + 25) = √189 ≈ 13.75 cm",
            ],
            "TSA = 340 cm²,  Volume = 400 cm³,  Diagonal ≈ 13.75 cm",
        ),
        example(
            "Example 2.2",
            "An open-top wooden box (no lid) measures 20 cm × 12 cm × 8 cm. "
            "Find the area of wood used to make it.",
            [
                "An open-top box has 5 faces: base + 4 walls.",
                "Base area = l × b = 20 × 12 = 240 cm²",
                "Walls area = 2(l + b) × h = 2 × (20 + 12) × 8 = 512 cm²",
                "Total wood area = 240 + 512 = 752 cm²",
            ],
            "Wood used = 752 cm²",
        ),
        h1("3.  Cylinder (right circular)"),
        body("A cylinder has two parallel circular ends of radius r and a curved "
             "lateral surface of height h. The two circular faces are its bases."),
        formula_box("Formulas — Cylinder (r, h)", [
            "CSA  =  2 π r h",
            "TSA  =  2 π r (r + h)",
            "Volume  =  π r² h",
        ]),
        example(
            "Example 3.1",
            "A closed cylindrical container has radius 7 cm and height 20 cm "
            "(take π = 22/7). Find its CSA, TSA and volume.",
            [
                "CSA = 2 π r h = 2 × (22/7) × 7 × 20 = 2 × 22 × 20 = 880 cm²",
                "TSA = 2 π r (r + h) = 2 × (22/7) × 7 × (7 + 20) = 44 × 27 = 1188 cm²",
                "Volume = π r² h = (22/7) × 49 × 20 = 22 × 7 × 20 = 3080 cm³",
            ],
            "CSA = 880 cm²,  TSA = 1188 cm²,  Volume = 3080 cm³",
        ),
        example(
            "Example 3.2",
            "A cylindrical pipe has radius 3.5 cm and length 4 m. Find the area "
            "of metal sheet needed to make it (take π = 22/7). Hint: a pipe is "
            "open at both ends — only the curved surface is needed.",
            [
                "Convert length: 4 m = 400 cm (so units match radius).",
                "Area of sheet = CSA = 2 π r h = 2 × (22/7) × 3.5 × 400",
                "              = 2 × 22 × 0.5 × 400 = 8800 cm²",
            ],
            "Metal sheet area = 8800 cm² (= 0.88 m²)",
        ),
        h1("4.  Cone (right circular)"),
        body("A cone has a circular base of radius r, a vertex at height h above "
             "the base, and a slant height l along the curved surface. The three "
             "quantities are related by l² = r² + h² (Pythagoras)."),
        formula_box("Formulas — Cone (r, h, l)", [
            "Slant height:  l  =  √(r² + h²)",
            "CSA  =  π r l",
            "TSA  =  π r (r + l)",
            "Volume  =  (1/3) π r² h",
        ]),
        example(
            "Example 4.1",
            "A cone has radius 6 cm and height 8 cm (take π = 22/7). Find its "
            "slant height, CSA, TSA and volume.",
            [
                "l = √(r² + h²) = √(36 + 64) = √100 = 10 cm",
                "CSA = π r l = (22/7) × 6 × 10 = 1320 / 7 ≈ 188.57 cm²",
                "TSA = π r (r + l) = (22/7) × 6 × (6 + 10) = (22/7) × 96 = 2112 / 7 ≈ 301.71 cm²",
                "Volume = (1/3) π r² h = (1/3) × (22/7) × 36 × 8 = (1/3) × (22/7) × 288",
                "       = (22 × 96) / 7 = 2112 / 7 ≈ 301.71 cm³",
            ],
            "l = 10 cm,  CSA ≈ 188.57 cm²,  TSA ≈ 301.71 cm²,  Volume ≈ 301.71 cm³",
        ),
        h1("5.  Sphere"),
        body("A sphere is the 3-D analogue of a circle: every point on its surface "
             "is the same distance r from the centre."),
        formula_box("Formulas — Sphere (r)", [
            "Surface Area  =  4 π r²",
            "Volume  =  (4/3) π r³",
        ]),
        example(
            "Example 5.1",
            "Find the surface area and volume of a sphere of radius 7 cm "
            "(take π = 22/7).",
            [
                "Surface Area = 4 π r² = 4 × (22/7) × 49 = 4 × 22 × 7 = 616 cm²",
                "Volume = (4/3) π r³ = (4/3) × (22/7) × 343 = (4/3) × 22 × 49",
                "       = (4/3) × 1078 = 4312 / 3 ≈ 1437.33 cm³",
            ],
            "Surface Area = 616 cm²,  Volume ≈ 1437.33 cm³",
        ),
        h1("6.  Hemisphere"),
        body("A hemisphere is exactly half of a sphere, cut through the centre. "
             "It has one flat circular face (of area π r²) and a curved dome."),
        formula_box("Formulas — Hemisphere (r)", [
            "CSA (curved dome only)  =  2 π r²",
            "TSA (curved + flat face)  =  3 π r²",
            "Volume  =  (2/3) π r³",
        ]),
        example(
            "Example 6.1",
            "A hemispherical bowl has radius 10 cm (take π = 3.14). Find its "
            "TSA (outer surface) and the volume of water it can hold.",
            [
                "TSA = 3 π r² = 3 × 3.14 × 100 = 942 cm²",
                "Volume = (2/3) π r³ = (2/3) × 3.14 × 1000 = 6280 / 3 ≈ 2093.33 cm³",
            ],
            "TSA = 942 cm²,  Volume ≈ 2093.33 cm³",
        ),
        h1("7.  Quick-reference summary"),
        make_summary_table(
            ["Solid", "CSA / LSA", "TSA", "Volume"],
            [
                ["Cube (a)",        "4 a²",          "6 a²",            "a³"],
                ["Cuboid (l,b,h)",  "2(l+b)·h",      "2(lb+bh+hl)",     "l·b·h"],
                ["Cylinder (r,h)",  "2 π r h",       "2 π r (r + h)",   "π r² h"],
                ["Cone (r,h,l)",    "π r l",         "π r (r + l)",     "(1/3) π r² h"],
                ["Sphere (r)",      "—",             "4 π r²",          "(4/3) π r³"],
                ["Hemisphere (r)",  "2 π r²",        "3 π r²",          "(2/3) π r³"],
            ],
            col_widths=[3.6 * cm, 3.2 * cm, 4.4 * cm, CONTENT_W - 11.2 * cm],
        ),
        Spacer(1, 6),
        tip("Capacity conversion",
            "1 m³ = 1000 litres  and  1 litre = 1000 cm³. So a tank of volume "
            "3 m³ holds 3000 litres, and a 2-litre bottle has a volume of "
            "2000 cm³."),
        tip("Common mistakes to avoid",
            "1) Using radius where the question gives diameter (and vice-versa). "
            "2) Computing TSA for an open-top container (omit the top face). "
            "3) Forgetting that cone CSA needs the slant height l, not the "
            "vertical height h — always find l = √(r² + h²) first. "
            "4) Mixing units — convert all measurements to the same unit "
            "before substituting."),
    ]
    build_doc(out, "Material 2 · 3D Figures", story)
    return out


# ============================================================
# MATERIAL 3 — Composite Figures & Real-world Problems
# ============================================================
def material_3():
    out = "/home/z/my-project/public/materials/CH005-material-03-composite-problems.pdf"
    story = doc_header_block(
        "STUDY MATERIAL 3  ·  CHAPTER CH005",
        "Composite Figures &amp; Real-world Problems",
        "Combining shapes · cost calculations · capacity problems",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Real-life objects are rarely perfect single shapes. A window is a "
            "rectangle with a semicircle on top; a running track is a rectangle "
            "with two semicircular ends; an ice-cream cone is a cone mounted on a "
            "hemisphere. To solve such problems, break the figure into its basic "
            "parts, compute the area or volume of each part separately, and then "
            "add (or subtract) as the problem requires."),
        learning_objectives([
            "Decompose a composite 2D figure into basic shapes (rectangles, triangles, circles, semicircles).",
            "Compute the area and perimeter of L-shaped, T-shaped and circular-rectangular figures.",
            "Find the cost of flooring, painting, fencing and tiling using area and rate.",
            "Convert the volume of a tank or container into its capacity in litres.",
            "Combine solids (cone on cylinder, cone on hemisphere) and find total surface area and volume.",
            "Compute percentage change in area when the side of a figure is changed.",
        ]),
        how_to_use(),
        tip("Strategy", "1) Identify the basic shapes.  "
            "2) Note all measurements and convert units if needed.  "
            "3) Compute area / volume of each part.  "
            "4) Add the parts (if combined) or subtract (if one shape is cut "
            "out of another).  5) Convert to cost / litres / kg as asked."),
        h1("1.  Combining rectangles — L-shaped figure"),
        example(
            "Example 1.1",
            "An L-shaped plate is made by joining two rectangles. The first "
            "measures 12 cm × 4 cm; the second, attached to the bottom, "
            "measures 6 cm × 6 cm. Find the total area and the perimeter.",
            [
                "Area of part 1 = 12 × 4 = 48 cm²",
                "Area of part 2 = 6 × 6 = 36 cm²",
                "Total area = 48 + 36 = 84 cm²",
                "Outer boundary: 12 + 4 + 6 + 6 + 6 + 4 + 6 + 4 = 48 cm "
                "(walking around the outline)",
            ],
            "Total area = 84 cm²,  Perimeter = 48 cm",
        ),
        example(
            "Example 1.2",
            "A window is in the shape of a rectangle 60 cm × 40 cm with a "
            "semicircle on top (diameter 60 cm). Find the area of the window "
            "(take π = 22/7).",
            [
                "Rectangle area = 60 × 40 = 2400 cm²",
                "Radius of semicircle = 60 / 2 = 30 cm",
                "Semicircle area = ½ π r² = ½ × (22/7) × 900 = 9900 / 7 ≈ 1414.29 cm²",
                "Total area = 2400 + 1414.29 = 3814.29 cm²",
            ],
            "Area of window ≈ 3814.29 cm²",
        ),
        h1("2.  Rectangle + two semicircles (running track)"),
        example(
            "Example 2.1",
            "A playground consists of a rectangle 100 m × 60 m with two "
            "semicircles of radius 30 m attached on the shorter sides. Find "
            "the total area of the playground (take π = 22/7).",
            [
                "Area of rectangle = 100 × 60 = 6000 m²",
                "Two semicircles of radius 30 m make one full circle of area π r²",
                "Area of circle = (22/7) × 30² = (22/7) × 900 = 19800 / 7 ≈ 2828.57 m²",
                "Total area = 6000 + 2828.57 = 8828.57 m²",
            ],
            "Total area ≈ 8828.57 m²",
        ),
        h1("3.  Cost calculations — flooring &amp; painting"),
        example(
            "Example 3.1",
            "A rectangular room is 6 m long and 4 m broad. Find the cost of "
            "covering its floor with carpet at ₹ 85 per m².",
            [
                "Area of floor = l × b = 6 × 4 = 24 m²",
                "Cost = 24 × 85 = ₹ 2040",
            ],
            "Cost of carpeting = ₹ 2040",
        ),
        example(
            "Example 3.2",
            "A cylindrical pillar has radius 0.35 m and height 4 m. Find the "
            "cost of painting its curved surface at ₹ 15 per m² (take π = 22/7).",
            [
                "CSA = 2 π r h = 2 × (22/7) × 0.35 × 4",
                "    = 2 × 22 × 0.05 × 4 = 8.8 m²",
                "Cost = 8.8 × 15 = ₹ 132",
            ],
            "Cost of painting = ₹ 132",
        ),
        h1("4.  Fencing &amp; boundary costs"),
        example(
            "Example 4.1",
            "A square field of side 35 m is to be fenced with three rounds of "
            "wire. Find the length of wire required and the cost at ₹ 12 per "
            "metre.",
            [
                "Perimeter of field = 4 × 35 = 140 m",
                "Wire needed (3 rounds) = 3 × 140 = 420 m",
                "Cost = 420 × 12 = ₹ 5040",
            ],
            "Wire = 420 m,  Cost = ₹ 5040",
        ),
        h1("5.  Capacity of tanks (volume → litres)"),
        example(
            "Example 5.1",
            "A rectangular tank measures 2 m × 1.5 m × 1 m. Find the volume "
            "of water it can hold in litres.",
            [
                "Volume = l × b × h = 2 × 1.5 × 1 = 3 m³",
                "1 m³ = 1000 litres  ⇒  capacity = 3 × 1000 = 3000 litres",
            ],
            "Capacity = 3000 litres",
        ),
        example(
            "Example 5.2",
            "A cylindrical water tank has radius 0.7 m and height 2 m "
            "(take π = 22/7). Find its capacity in litres.",
            [
                "Volume = π r² h = (22/7) × (0.7)² × 2 = (22/7) × 0.49 × 2",
                "       = (22/7) × 0.98 = 3.08 m³",
                "Capacity = 3.08 × 1000 = 3080 litres",
            ],
            "Capacity = 3080 litres",
        ),
        example(
            "Example 5.3",
            "A hemispherical bowl has inner radius 10.5 cm (take π = 22/7). "
            "How many litres of milk can it hold?",
            [
                "Volume = (2/3) π r³ = (2/3) × (22/7) × (10.5)³",
                "(10.5)³ = 1157.625",
                "= (2/3) × (22/7) × 1157.625 = (2/3) × 3638.25 = 2425.5 cm³",
                "Capacity = 2425.5 / 1000 = 2.4255 litres ≈ 2.43 litres",
            ],
            "Capacity ≈ 2.43 litres",
        ),
        h1("6.  Percentage change in area"),
        example(
            "Example 6.1",
            "The side of a square is increased from 8 cm to 10 cm. Find the "
            "percentage increase in its area.",
            [
                "Original area = 8² = 64 cm²",
                "New area = 10² = 100 cm²",
                "Increase = 100 − 64 = 36 cm²",
                "% increase = (36 / 64) × 100 = 56.25 %",
            ],
            "Percentage increase = 56.25 %",
        ),
        h1("7.  Mixed real-world problems"),
        example(
            "Example 7.1",
            "A rectangular paper of size 22 cm × 14 cm is rolled along its "
            "length to form a cylinder. Find the volume of the cylinder "
            "(take π = 22/7).",
            [
                "When rolled along the length, the length becomes the circumference "
                "of the base: 2 π r = 22  ⇒  r = 22 × 7 / 44 = 3.5 cm",
                "Height of cylinder = breadth of paper = 14 cm",
                "Volume = π r² h = (22/7) × (3.5)² × 14 = (22/7) × 12.25 × 14",
                "       = 22 × 12.25 × 2 = 539 cm³",
            ],
            "Volume = 539 cm³",
        ),
        example(
            "Example 7.2",
            "A solid is in the shape of a cone mounted on a hemisphere. The "
            "radius of both is 3.5 cm and the height of the conical part is "
            "12 cm. Find the volume of the solid (take π = 22/7).",
            [
                "Volume of cone = (1/3) π r² h = (1/3) × (22/7) × 12.25 × 12",
                "              = (1/3) × 22 × 1.75 × 12 = (1/3) × 462 = 154 cm³",
                "Volume of hemisphere = (2/3) π r³ = (2/3) × (22/7) × 42.875",
                "              = (2/3) × 22 × 6.125 = (2/3) × 134.75 ≈ 89.83 cm³",
                "Total volume = 154 + 89.83 = 243.83 cm³",
            ],
            "Volume of the solid ≈ 243.83 cm³",
        ),
        example(
            "Example 7.3",
            "A circus tent is in the form of a cylinder surmounted by a cone. "
            "The radius is 7 m, the cylindrical part is 8 m high, and the "
            "conical top has height 7 m. Find the volume of air inside the "
            "tent (take π = 22/7).",
            [
                "Volume of cylinder = π r² h = (22/7) × 49 × 8 = 22 × 7 × 8 = 1232 m³",
                "Volume of cone = (1/3) π r² h = (1/3) × (22/7) × 49 × 7",
                "              = (1/3) × 22 × 7 × 7 = (1/3) × 1078 ≈ 359.33 m³",
                "Total volume of air = 1232 + 359.33 = 1591.33 m³",
            ],
            "Air inside the tent ≈ 1591.33 m³",
        ),
        tip("Common mistakes",
            "Forgetting to convert m³ → litres (× 1000); using radius where the "
            "question gives diameter (and vice-versa); adding the flat circular "
            "face when only the curved dome of a hemisphere is asked; computing "
            "TSA of an open-top container (omit the top face)."),
        h1("8.  Quick-reference conversions"),
        make_summary_table(
            ["From", "To", "Multiply by"],
            [
                ["m²",  "cm²",   "10 000"],
                ["m³",  "cm³",   "1 000 000"],
                ["m³",  "litres","1 000"],
                ["litres", "cm³","1 000"],
                ["cm³", "ml",    "1"],
                ["cm",  "mm",    "10"],
            ],
            col_widths=[5.0 * cm, 5.0 * cm, CONTENT_W - 10.0 * cm],
        ),
    ]
    build_doc(out, "Material 3 · Composite Problems", story)
    return out


# ============================================================
# PRACTICE 1 — 2D figures
# ============================================================
def practice_1():
    out = "/home/z/my-project/public/practice/CH005-practice-01.pdf"
    story = doc_header_block(
        "PRACTICE SHEET 1  ·  CHAPTER CH005",
        "Perimeter &amp; Area of 2D Figures",
        "18 questions · MCQ + numerical + word problems · Easy–Medium",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Attempt all 18 questions. Show every step of your working in the "
            "answer space provided. Take π = 22/7 and √3 = 1.732 unless a "
            "question says otherwise. Total marks: 40. Suggested time: 45 min."),
        tip("Formula quick-ref",
            "Square: P = 4a, A = a²  ·  Rectangle: P = 2(l+b), A = lb  ·  "
            "Triangle: A = ½ b h, Heron's A = √(s(s−a)(s−b)(s−c))  ·  "
            "Equilateral Δ: A = (√3/4) a²  ·  Parallelogram: A = bh  ·  "
            "Rhombus: A = ½ d₁ d₂  ·  Trapezium: A = ½(a+b) h  ·  "
            "Circle: C = 2πr, A = πr²"),
        h1("Section A — Multiple Choice (1 mark each)"),
    ]
    mcq = [
        ("Q1.", "The perimeter of a square of side 9 cm is:",
         ["(a) 18 cm", "(b) 27 cm", "(c) 36 cm", "(d) 81 cm"]),
        ("Q2.", "The area of a rectangle 14 cm × 6 cm is:",
         ["(a) 40 cm²", "(b) 84 cm²", "(c) 20 cm²", "(d) 60 cm²"]),
        ("Q3.", "The circumference of a circle of radius 7 cm (π = 22/7) is:",
         ["(a) 22 cm", "(b) 44 cm", "(c) 154 cm", "(d) 308 cm"]),
        ("Q4.", "The area of a triangle with base 12 cm and height 8 cm is:",
         ["(a) 48 cm²", "(b) 96 cm²", "(c) 20 cm²", "(d) 24 cm²"]),
        ("Q5.", "The area of a circle of radius 14 cm (π = 22/7) is:",
         ["(a) 88 cm²", "(b) 176 cm²", "(c) 616 cm²", "(d) 1232 cm²"]),
    ]
    for qn, qt, opts in mcq:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            *[P(o, "opt") for o in opts],
            AnswerSpace(n_lines=1, gap=20),
        ]))
    story.append(h1("Section B — Numerical Problems (2 marks each)"))
    numerical = [
        ("Q6.",  "Find the perimeter of a rectangle of length 25 cm and breadth 15 cm."),
        ("Q7.",  "Find the area of a square whose side is 13 cm."),
        ("Q8.",  "The diagonals of a rhombus are 16 cm and 12 cm. Find its area."),
        ("Q9.",  "Find the area of a trapezium whose parallel sides are 10 cm and "
                 "16 cm and the distance between them is 7 cm."),
        ("Q10.", "Find the area of a parallelogram with base 20 cm and height 9 cm."),
        ("Q11.", "Find the circumference of a circle of diameter 21 cm (π = 22/7)."),
        ("Q12.", "Find the area of an equilateral triangle of side 6 cm (√3 = 1.732)."),
    ]
    for qn, qt in numerical:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            AnswerSpace(n_lines=6, gap=22),
        ]))
    story.append(h1("Section C — Word Problems (3 marks each)"))
    word = [
        ("Q13.", "A rectangular garden 30 m × 18 m has a path 2 m wide running "
                 "all around it on the inside. Find the area of the path."),
        ("Q14.", "Find the cost of fencing a square field of side 75 m at the "
                 "rate of ₹ 15 per metre."),
        ("Q15.", "The area of a circle is 616 cm² (π = 22/7). Find its circumference."),
        ("Q16.", "A wire is bent in the shape of a square of side 22 cm. It is "
                 "then rebent into a circle. Find the radius of the circle (π = 22/7)."),
        ("Q17.", "Find the area of a triangle whose sides are 7 cm, 24 cm and "
                 "25 cm (use Heron's formula)."),
        ("Q18.", "The diagonals of a rhombus are 7.5 cm and 12 cm. Find its area "
                 "and also the length of each side."),
    ]
    for qn, qt in word:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            AnswerSpace(n_lines=8, gap=22),
        ]))
    story.append(Spacer(1, 8))
    story.append(P("— End of Practice Sheet 1 —", "small_muted"))
    build_doc(out, "Practice 1 · 2D Figures", story)
    return out


# ============================================================
# PRACTICE 1 — SOLUTIONS
# ============================================================
def practice_1_solutions():
    out = "/home/z/my-project/public/practice/CH005-practice-01-solutions.pdf"
    story = doc_header_block(
        "SOLUTIONS · PRACTICE SHEET 1  ·  CHAPTER CH005",
        "Step-by-step Worked Solutions",
        "Perimeter &amp; Area of 2D Figures — 18 problems",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Every question below is solved step-by-step. The final answer is "
            "highlighted in emerald. Where π is used, π = 22/7 unless noted. "
            "For each numerical and word problem we list the Given, To find, "
            "Formula, Working and Answer so that you can follow the structure "
            "of a perfect exam answer."),
        how_to_use(),
        h1("Section A — Multiple Choice (1 mark each)"),
    ]
    # MCQ solutions — concise
    mcq_sols = [
        ("Solution 1.", "square of side 9 cm", "Perimeter", "P = 4a",
         ["Perimeter of square = 4 × side = 4 × 9 = 36 cm"],
         "Answer: (c) 36 cm"),
        ("Solution 2.", "rectangle 14 cm × 6 cm", "Area", "A = l × b",
         ["Area of rectangle = length × breadth = 14 × 6 = 84 cm²"],
         "Answer: (b) 84 cm²"),
        ("Solution 3.", "circle, r = 7 cm; π = 22/7", "Circumference", "C = 2 π r",
         ["Circumference = 2 × (22/7) × 7 = 2 × 22 = 44 cm"],
         "Answer: (b) 44 cm"),
        ("Solution 4.", "triangle, b = 12 cm, h = 8 cm", "Area", "A = ½ × b × h",
         ["Area of triangle = ½ × base × height = ½ × 12 × 8 = 48 cm²"],
         "Answer: (a) 48 cm²"),
        ("Solution 5.", "circle, r = 14 cm; π = 22/7", "Area", "A = π r²",
         ["Area = π r² = (22/7) × 14² = (22/7) × 196 = 22 × 28 = 616 cm²"],
         "Answer: (c) 616 cm²"),
    ]
    for tup in mcq_sols:
        story.append(sol_box(*tup))
    story.append(h1("Section B — Numerical Problems (2 marks each)"))
    num_sols = [
        ("Solution 6.", "length l = 25 cm, breadth b = 15 cm", "Perimeter of the rectangle",
         "Perimeter = 2 × (l + b)",
         ["Perimeter = 2 × (25 + 15) = 2 × 40 = 80 cm"],
         "Answer: 80 cm"),
        ("Solution 7.", "side a = 13 cm", "Area of the square",
         "Area = a²",
         ["Area = 13² = 169 cm²"],
         "Answer: 169 cm²"),
        ("Solution 8.", "diagonals d₁ = 16 cm, d₂ = 12 cm", "Area of the rhombus",
         "Area = ½ × d₁ × d₂",
         ["Area = ½ × 16 × 12 = ½ × 192 = 96 cm²"],
         "Answer: 96 cm²"),
        ("Solution 9.", "parallel sides a = 10 cm, b = 16 cm; height h = 7 cm",
         "Area of the trapezium", "Area = ½ × (a + b) × h",
         ["Area = ½ × (10 + 16) × 7 = ½ × 26 × 7 = 13 × 7 = 91 cm²"],
         "Answer: 91 cm²"),
        ("Solution 10.", "base b = 20 cm, height h = 9 cm", "Area of the parallelogram",
         "Area = base × height",
         ["Area = 20 × 9 = 180 cm²"],
         "Answer: 180 cm²"),
        ("Solution 11.", "diameter d = 21 cm ⇒ radius r = 10.5 cm; π = 22/7",
         "Circumference of the circle", "Circumference = 2 π r",
         ["Circumference = 2 × (22/7) × 10.5 = 2 × 22 × 1.5 = 66 cm"],
         "Answer: 66 cm"),
        ("Solution 12.", "side a = 6 cm; √3 = 1.732", "Area of the equilateral triangle",
         "Area = (√3 / 4) × a²",
         ["Area = (1.732 / 4) × 6² = 0.433 × 36 = 15.588 cm² ≈ 15.59 cm²"],
         "Answer: 15.59 cm² (approx.)"),
    ]
    for tup in num_sols:
        story.append(sol_box(*tup))
    story.append(h1("Section C — Word Problems (3 marks each)"))
    word_sols = [
        ("Solution 13.",
         "garden 30 m × 18 m; path 2 m wide inside along boundary",
         "Area of the path",
         "Path area = Outer area − Inner area;  Inner = (l − 4) × (b − 4)",
         ["Outer area = 30 × 18 = 540 m²",
          "Inner dimensions = (30 − 4) × (18 − 4) = 26 × 14",
          "Inner area = 26 × 14 = 364 m²",
          "Area of path = 540 − 364 = 176 m²"],
         "Answer: Area of path = 176 m²"),
        ("Solution 14.",
         "square field of side 75 m; rate ₹ 15 per metre",
         "Cost of fencing the field",
         "Perimeter = 4a;  Cost = Perimeter × rate",
         ["Perimeter = 4 × 75 = 300 m",
          "Cost = 300 × 15 = ₹ 4500"],
         "Answer: ₹ 4500"),
        ("Solution 15.",
         "area of circle = 616 cm²; π = 22/7",
         "Circumference of the circle",
         "π r² = Area  ⇒  r = √(Area / π);   Circumference = 2 π r",
         ["r² = 616 × 7 / 22 = 196  ⇒  r = 14 cm",
          "Circumference = 2 × (22/7) × 14 = 88 cm"],
         "Answer: Circumference = 88 cm"),
        ("Solution 16.",
         "wire bent into square of side 22 cm, then rebent into a circle; π = 22/7",
         "Radius of the circle",
         "Perimeter of square = Circumference of circle  ⇒  4a = 2 π r",
         ["Perimeter of square = 4 × 22 = 88 cm",
          "This equals the circumference: 2 π r = 88",
          "r = (88 × 7) / (2 × 22) = 616 / 44 = 14 cm"],
         "Answer: Radius = 14 cm"),
        ("Solution 17.",
         "sides of triangle: 7 cm, 24 cm, 25 cm",
         "Area using Heron's formula",
         "s = (a+b+c)/2;  Area = √(s(s−a)(s−b)(s−c))",
         ["s = (7 + 24 + 25) / 2 = 56 / 2 = 28 cm",
          "s − a = 21,   s − b = 4,   s − c = 3",
          "Area = √(28 × 21 × 4 × 3) = √7056 = 84 cm²"],
         "Answer: Area = 84 cm²"),
        ("Solution 18.",
         "diagonals d₁ = 7.5 cm, d₂ = 12 cm",
         "Area and side of the rhombus",
         "Area = ½ d₁ d₂;  Side = ½ × √(d₁² + d₂²)",
         ["Area = ½ × 7.5 × 12 = 45 cm²",
          "Side = ½ × √((7.5)² + 12²) = ½ × √(56.25 + 144)",
          "     = ½ × √200.25 = ½ × 14.15 ≈ 7.08 cm"],
         "Answer: Area = 45 cm²,  Side ≈ 7.08 cm"),
    ]
    for tup in word_sols:
        story.append(sol_box(*tup))
    story.append(Spacer(1, 8))
    story.append(h1("Key Formula Recap"))
    story.append(make_summary_table(
        ["Figure", "Perimeter", "Area"],
        [
            ["Square",       "4a",        "a²"],
            ["Rectangle",    "2(l + b)",   "l × b"],
            ["Triangle",     "a + b + c", "½ × b × h"],
            ["Parallelogram","2(a + b)",   "b × h"],
            ["Rhombus",      "4a",        "½ × d₁ × d₂"],
            ["Trapezium",    "a + b + c + d", "½ × (a + b) × h"],
            ["Circle",       "2 π r",      "π r²"],
        ],
        col_widths=[5.0 * cm, 4.5 * cm, CONTENT_W - 9.5 * cm],
    ))
    story.append(Spacer(1, 6))
    story.append(P("— End of Solutions · Practice Sheet 1 —", "small_muted"))
    build_doc(out, "Solutions 1 · 2D Figures", story)
    return out


# ============================================================
# PRACTICE 2 — 3D figures + composite
# ============================================================
def practice_2():
    out = "/home/z/my-project/public/practice/CH005-practice-02.pdf"
    story = doc_header_block(
        "PRACTICE SHEET 2  ·  CHAPTER CH005",
        "Surface Area &amp; Volume of 3D Figures + Composite",
        "18 questions · MCQ + numerical + word problems · Easy–Medium",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Attempt all 18 questions. Show every step of your working in the "
            "answer space provided. Take π = 22/7 unless a question says "
            "otherwise. Total marks: 45. Suggested time: 50 min."),
        tip("Formula quick-ref",
            "Cube: TSA = 6a², V = a³  ·  Cuboid: TSA = 2(lb+bh+hl), V = lbh  ·  "
            "Cylinder: CSA = 2πrh, TSA = 2πr(r+h), V = πr²h  ·  "
            "Cone: l = √(r²+h²), CSA = πrl, TSA = πr(r+l), V = (1/3)πr²h  ·  "
            "Sphere: SA = 4πr², V = (4/3)πr³  ·  Hemisphere: CSA = 2πr², "
            "TSA = 3πr², V = (2/3)πr³  ·  1 m³ = 1000 litres"),
        h1("Section A — Multiple Choice (1 mark each)"),
    ]
    mcq = [
        ("Q1.", "The volume of a cube of side 5 cm is:",
         ["(a) 25 cm³", "(b) 125 cm³", "(c) 75 cm³", "(d) 150 cm³"]),
        ("Q2.", "The total surface area of a cube of side 4 cm is:",
         ["(a) 16 cm²", "(b) 64 cm²", "(c) 96 cm²", "(d) 48 cm²"]),
        ("Q3.", "The volume of a cuboid 6 cm × 4 cm × 3 cm is:",
         ["(a) 72 cm³", "(b) 13 cm³", "(c) 24 cm³", "(d) 144 cm³"]),
        ("Q4.", "The volume of a cylinder with r = 7 cm and h = 10 cm (π = 22/7) is:",
         ["(a) 770 cm³", "(b) 1540 cm³", "(c) 220 cm³", "(d) 440 cm³"]),
        ("Q5.", "The volume of a sphere of radius 3 cm (π = 22/7) is:",
         ["(a) 110 cm³", "(b) 113.14 cm³", "(c) 942 cm³", "(d) 36 cm³"]),
    ]
    for qn, qt, opts in mcq:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            *[P(o, "opt") for o in opts],
            AnswerSpace(n_lines=1, gap=20),
        ]))
    story.append(h1("Section B — Numerical Problems (2 marks each)"))
    numerical = [
        ("Q6.",  "Find the total surface area of a cuboid of dimensions "
                 "10 cm × 8 cm × 6 cm."),
        ("Q7.",  "Find the volume of a cylinder with radius 5 cm and height "
                 "14 cm (π = 22/7)."),
        ("Q8.",  "Find the curved surface area of a cone with r = 6 cm and "
                 "h = 8 cm (π = 22/7)."),
        ("Q9.",  "Find the volume of a cone with r = 3 cm and h = 14 cm "
                 "(π = 22/7)."),
        ("Q10.", "Find the total surface area of a sphere of radius 10.5 cm "
                 "(π = 22/7)."),
        ("Q11.", "Find the volume of a hemisphere of radius 7 cm (π = 22/7)."),
        ("Q12.", "Find the volume of a cuboid of dimensions 12 cm × 10 cm × 8 cm."),
    ]
    for qn, qt in numerical:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            AnswerSpace(n_lines=6, gap=22),
        ]))
    story.append(h1("Section C — Word Problems (3 marks each)"))
    word = [
        ("Q13.", "A closed cylindrical tank has radius 1.4 m and height 2 m. "
                 "Find its capacity in litres (π = 22/7)."),
        ("Q14.", "Find the cost of painting the curved surface of a closed "
                 "cylindrical tank of radius 7 m and height 10 m at ₹ 20 per m² "
                 "(π = 22/7)."),
        ("Q15.", "How many cubic metres of soil must be dug out to make a well "
                 "14 m deep with diameter 2 m? (π = 22/7)"),
        ("Q16.", "The volume of a solid sphere is 38808 cm³ (π = 22/7). Find "
                 "its surface area."),
        ("Q17.", "A solid is in the shape of a cone mounted on a cylinder. "
                 "Both have radius 3 cm; the height of the conical part is 8 cm "
                 "and that of the cylindrical part is 10 cm. Find the total "
                 "volume of the solid (π = 22/7)."),
        ("Q18.", "Find the length of the longest rod that can be placed inside "
                 "a cuboidal room of dimensions 12 m × 9 m × 8 m."),
    ]
    for qn, qt in word:
        story.append(KeepTogether([
            P("<b>" + qn + "</b>  " + qt, "q"),
            AnswerSpace(n_lines=8, gap=22),
        ]))
    story.append(Spacer(1, 8))
    story.append(P("— End of Practice Sheet 2 —", "small_muted"))
    build_doc(out, "Practice 2 · 3D Figures", story)
    return out


# ============================================================
# PRACTICE 2 — SOLUTIONS
# ============================================================
def practice_2_solutions():
    out = "/home/z/my-project/public/practice/CH005-practice-02-solutions.pdf"
    story = doc_header_block(
        "SOLUTIONS · PRACTICE SHEET 2  ·  CHAPTER CH005",
        "Step-by-step Worked Solutions",
        "Surface Area &amp; Volume of 3D Figures + Composite — 18 problems",
        "Power Maths · Mensuration   |   by Prof. Kalpesh Vyas   |   For enrolled students",
    )
    story += [
        body_j(
            "Every question below is solved step-by-step. The final answer is "
            "highlighted in emerald. For each numerical and word problem we "
            "list the Given, To find, Formula, Working and Answer so that you "
            "can follow the structure of a perfect exam answer. Where π is "
            "used, π = 22/7 unless noted."),
        how_to_use(),
        h1("Section A — Multiple Choice (1 mark each)"),
    ]
    mcq_sols = [
        ("Solution 1.", "cube of side 5 cm", "Volume", "V = a³",
         ["Volume of cube = side³ = 5³ = 125 cm³"],
         "Answer: (b) 125 cm³"),
        ("Solution 2.", "cube of side 4 cm", "Total Surface Area", "TSA = 6 a²",
         ["TSA of cube = 6 × side² = 6 × 4² = 6 × 16 = 96 cm²"],
         "Answer: (c) 96 cm²"),
        ("Solution 3.", "cuboid 6 × 4 × 3 cm", "Volume", "V = l × b × h",
         ["Volume of cuboid = l × b × h = 6 × 4 × 3 = 72 cm³"],
         "Answer: (a) 72 cm³"),
        ("Solution 4.", "cylinder, r = 7 cm, h = 10 cm; π = 22/7", "Volume", "V = π r² h",
         ["Volume of cylinder = π r² h = (22/7) × 7² × 10 = 22 × 7 × 10 = 1540 cm³"],
         "Answer: (b) 1540 cm³"),
        ("Solution 5.", "sphere, r = 3 cm; π = 22/7", "Volume", "V = (4/3) π r³",
         ["Volume = (4/3) π r³ = (4/3) × (22/7) × 27 = 2376 / 21 ≈ 113.14 cm³"],
         "Answer: (b) 113.14 cm³"),
    ]
    for tup in mcq_sols:
        story.append(sol_box(*tup))
    story.append(h1("Section B — Numerical Problems (2 marks each)"))
    num_sols = [
        ("Solution 6.",
         "cuboid 10 × 8 × 6 cm",
         "Total Surface Area (TSA) of the cuboid",
         "TSA = 2(lb + bh + hl)",
         ["TSA = 2 × (10×8 + 8×6 + 6×10)",
          "    = 2 × (80 + 48 + 60) = 2 × 188 = 376 cm²"],
         "Answer: 376 cm²"),
        ("Solution 7.",
         "cylinder r = 5 cm, h = 14 cm; π = 22/7",
         "Volume of the cylinder",
         "Volume = π r² h",
         ["Volume = (22/7) × 5² × 14 = (22/7) × 25 × 14",
          "       = 22 × 25 × 2 = 1100 cm³"],
         "Answer: 1100 cm³"),
        ("Solution 8.",
         "cone r = 6 cm, h = 8 cm; π = 22/7",
         "Curved Surface Area (CSA) of the cone",
         "First find slant height l = √(r² + h²);  CSA = π r l",
         ["l = √(6² + 8²) = √(36 + 64) = √100 = 10 cm",
          "CSA = (22/7) × 6 × 10 = 1320 / 7 ≈ 188.57 cm²"],
         "Answer: CSA ≈ 188.57 cm²"),
        ("Solution 9.",
         "cone r = 3 cm, h = 14 cm; π = 22/7",
         "Volume of the cone",
         "Volume = (1/3) π r² h",
         ["Volume = (1/3) × (22/7) × 9 × 14",
          "       = (1/3) × (22/7) × 126 = (1/3) × 22 × 18",
          "       = (1/3) × 396 = 132 cm³"],
         "Answer: 132 cm³"),
        ("Solution 10.",
         "sphere r = 10.5 cm; π = 22/7",
         "Total Surface Area of the sphere",
         "TSA = 4 π r²",
         ["TSA = 4 × (22/7) × (10.5)² = 4 × (22/7) × 110.25",
          "    = 4 × 22 × 15.75 = 88 × 15.75 = 1386 cm²"],
         "Answer: 1386 cm²"),
        ("Solution 11.",
         "hemisphere r = 7 cm; π = 22/7",
         "Volume of the hemisphere",
         "Volume = (2/3) π r³",
         ["Volume = (2/3) × (22/7) × 7³ = (2/3) × (22/7) × 343",
          "       = (2/3) × 22 × 49 = (2/3) × 1078 = 2156 / 3 ≈ 718.67 cm³"],
         "Answer: ≈ 718.67 cm³"),
        ("Solution 12.",
         "cuboid 12 × 10 × 8 cm",
         "Volume of the cuboid",
         "Volume = l × b × h",
         ["Volume = 12 × 10 × 8 = 960 cm³"],
         "Answer: 960 cm³"),
    ]
    for tup in num_sols:
        story.append(sol_box(*tup))
    story.append(h1("Section C — Word Problems (3 marks each)"))
    word_sols = [
        ("Solution 13.",
         "closed cylindrical tank: r = 1.4 m, h = 2 m; π = 22/7",
         "Capacity of the tank in litres",
         "Volume = π r² h;   1 m³ = 1000 litres",
         ["Volume = (22/7) × (1.4)² × 2 = (22/7) × 1.96 × 2",
          "       = (22/7) × 3.92 = 12.32 m³",
          "Capacity = 12.32 × 1000 = 12 320 litres"],
         "Answer: 12 320 litres"),
        ("Solution 14.",
         "closed cylindrical tank: r = 7 m, h = 10 m; rate ₹ 20/m²; π = 22/7",
         "Cost of painting the curved surface",
         "CSA = 2 π r h;  Cost = CSA × rate",
         ["CSA = 2 × (22/7) × 7 × 10 = 2 × 22 × 10 = 440 m²",
          "Cost = 440 × 20 = ₹ 8 800"],
         "Answer: ₹ 8 800"),
        ("Solution 15.",
         "well: diameter = 2 m ⇒ r = 1 m, depth h = 14 m; π = 22/7",
         "Volume of soil to be dug out",
         "Volume = π r² h   (well is a cylinder)",
         ["Volume = (22/7) × 1² × 14 = 22 × 2 = 44 m³"],
         "Answer: 44 m³ of soil"),
        ("Solution 16.",
         "sphere volume = 38808 cm³; π = 22/7",
         "Surface area of the sphere",
         "V = (4/3) π r³  ⇒  r = ∛(3V / (4π));  SA = 4 π r²",
         ["r³ = 3 × 38808 / (4 × (22/7)) = 38808 × 3 × 7 / (4 × 22)",
          "   = 814968 / 88 = 9261  ⇒  r = ∛9261 = 21 cm",
          "SA = 4 × (22/7) × 21² = 4 × (22/7) × 441 = 4 × 22 × 63 = 5544 cm²"],
         "Answer: Surface area = 5544 cm²"),
        ("Solution 17.",
         "solid = cone on cylinder; r = 3 cm; cone h = 8 cm, cylinder h = 10 cm; π = 22/7",
         "Total volume of the solid",
         "V_total = (1/3) π r² h_cone + π r² h_cyl",
         ["Cone:   V = (1/3) × (22/7) × 9 × 8 = 1584 / 21 = 528 / 7 ≈ 75.43 cm³",
          "Cylinder: V = (22/7) × 9 × 10 = 990 / 7 ≈ 141.43 cm³",
          "Total = (528 + 990) / 7 = 1518 / 7 ≈ 216.86 cm³"],
         "Answer: Total volume ≈ 216.86 cm³"),
        ("Solution 18.",
         "cuboidal room 12 m × 9 m × 8 m",
         "Length of the longest rod that fits inside",
         "Longest rod = space diagonal = √(l² + b² + h²)",
         ["Diagonal = √(12² + 9² + 8²) = √(144 + 81 + 64)",
          "         = √289 = 17 m"],
         "Answer: 17 m"),
    ]
    for tup in word_sols:
        story.append(sol_box(*tup))
    story.append(Spacer(1, 8))
    story.append(h1("Key Formula Recap"))
    story.append(make_summary_table(
        ["Solid", "CSA / LSA", "TSA", "Volume"],
        [
            ["Cube",        "4 a²",          "6 a²",          "a³"],
            ["Cuboid",      "2(l+b)·h",      "2(lb+bh+hl)",   "l·b·h"],
            ["Cylinder",    "2 π r h",       "2 π r (r + h)", "π r² h"],
            ["Cone",        "π r l",         "π r (r + l)",   "(1/3) π r² h"],
            ["Sphere",      "—",             "4 π r²",        "(4/3) π r³"],
            ["Hemisphere",  "2 π r²",        "3 π r²",        "(2/3) π r³"],
        ],
        col_widths=[3.4 * cm, 3.4 * cm, 4.6 * cm, CONTENT_W - 11.4 * cm],
    ))
    story.append(Spacer(1, 6))
    story.append(P("— End of Solutions · Practice Sheet 2 —", "small_muted"))
    build_doc(out, "Solutions 2 · 3D Figures", story)
    return out


# ============================================================
# Main entry point
# ============================================================
def main():
    # Ensure output directories exist
    os.makedirs("/home/z/my-project/public/materials", exist_ok=True)
    os.makedirs("/home/z/my-project/public/practice", exist_ok=True)

    outputs = []
    outputs.append(material_1())
    outputs.append(material_2())
    outputs.append(material_3())
    outputs.append(practice_1())
    outputs.append(practice_1_solutions())
    outputs.append(practice_2())
    outputs.append(practice_2_solutions())

    print("Generated:")
    for p in outputs:
        sz = os.path.getsize(p)
        print(f"  {p}  ({sz} bytes, {sz/1024:.1f} KB)")


if __name__ == "__main__":
    main()
