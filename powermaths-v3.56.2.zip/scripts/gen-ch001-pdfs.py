#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen-ch001-pdfs.py
=================
Generate 7 real, multi-page educational PDFs for the "Number System" chapter
(CH001) of the Power Maths portal by Prof. Kalpesh Vyas.

Outputs (all A4, 5–6 pages each):
  public/materials/CH001-material-01-natural-whole-numbers.pdf
  public/materials/CH001-material-02-rational-irrational.pdf
  public/materials/CH001-material-03-hcf-lcm.pdf
  public/practice/CH001-practice-01.pdf
  public/practice/CH001-practice-01-solutions.pdf
  public/practice/CH001-practice-02.pdf
  public/practice/CH001-practice-02-solutions.pdf

Run:
  python3 /home/z/my-project/scripts/gen-ch001-pdfs.py
"""
import os
import sys

from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, white
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    KeepTogether, Flowable, ListFlowable, ListItem, HRFlowable, CondPageBreak,
)
from reportlab.pdfgen import canvas

# ============================================================
# Paths
# ============================================================
BASE = "/home/z/my-project"
MAT_DIR = os.path.join(BASE, "public", "materials")
PRAC_DIR = os.path.join(BASE, "public", "practice")
os.makedirs(MAT_DIR, exist_ok=True)
os.makedirs(PRAC_DIR, exist_ok=True)

# ============================================================
# Fonts — FreeSans has full Unicode coverage for math symbols
# (√ ² ³ × ÷ π ≤ ≥ ≠ ∞ ∪ ∩ ∈ ∀ ∃ ₹ · — etc.) and an italic face.
# ============================================================
FD = "/usr/share/fonts/truetype/freefont"
pdfmetrics.registerFont(TTFont("FreeSans",            os.path.join(FD, "FreeSans.ttf")))
pdfmetrics.registerFont(TTFont("FreeSans-Bold",       os.path.join(FD, "FreeSansBold.ttf")))
pdfmetrics.registerFont(TTFont("FreeSans-Oblique",    os.path.join(FD, "FreeSansOblique.ttf")))
pdfmetrics.registerFont(TTFont("FreeSans-BoldOblique",os.path.join(FD, "FreeSansBoldOblique.ttf")))
registerFontFamily(
    "FreeSans",
    normal="FreeSans", bold="FreeSans-Bold",
    italic="FreeSans-Oblique", boldItalic="FreeSans-BoldOblique",
)
FN  = "FreeSans"
FNB = "FreeSans-Bold"
FNI = "FreeSans-Oblique"

# ============================================================
# Colours — dark teal / emerald (no indigo / blue)
# ============================================================
BRAND        = HexColor("#0F766E")   # teal-700  — H1
BRAND_DARK   = HexColor("#115E59")   # teal-800  — H2 / titles
ACCENT       = HexColor("#059669")   # emerald-600
EXAMPLE_BG   = HexColor("#F3F4F6")   # gray-100
EXAMPLE_BORD = HexColor("#D1D5DB")   # gray-300
DEFN_BG      = HexColor("#F0FDFA")   # teal-50
ANSWER_BG    = HexColor("#ECFDF5")   # emerald-50
ANSWER_BORD  = HexColor("#10B981")   # emerald-500
TEXT         = HexColor("#1F2937")   # gray-800
MUTED        = HexColor("#6B7280")   # gray-500
LINE_GRAY    = HexColor("#D1D5DB")   # answer-line gray

# ============================================================
# Page geometry
# ============================================================
PAGE_W, PAGE_H = A4                 # 595.27 × 841.89
LEFT_M, RIGHT_M = 42, 42
TOP_M, BOTTOM_M = 60, 54
CONTENT_W = PAGE_W - LEFT_M - RIGHT_M

# ============================================================
# Paragraph styles
# ============================================================
ss = getSampleStyleSheet()

title_style = ParagraphStyle("title", parent=ss["Normal"], fontName=FNB,
    fontSize=22, leading=26, textColor=BRAND_DARK, spaceAfter=2, alignment=TA_LEFT)
subtitle_style = ParagraphStyle("subtitle", parent=ss["Normal"], fontName=FN,
    fontSize=12, leading=15, textColor=MUTED, spaceAfter=2, alignment=TA_LEFT)
doc_title_style = ParagraphStyle("doc_title", parent=ss["Normal"], fontName=FNB,
    fontSize=15, leading=19, textColor=TEXT, spaceBefore=6, spaceAfter=3, alignment=TA_LEFT)
h1_style = ParagraphStyle("h1", parent=ss["Normal"], fontName=FNB,
    fontSize=14, leading=18, textColor=BRAND, spaceBefore=14, spaceAfter=6, alignment=TA_LEFT)
h2_style = ParagraphStyle("h2", parent=ss["Normal"], fontName=FNB,
    fontSize=12, leading=15, textColor=BRAND_DARK, spaceBefore=8, spaceAfter=4, alignment=TA_LEFT)
body_style = ParagraphStyle("body", parent=ss["Normal"], fontName=FN,
    fontSize=11, leading=16.5, textColor=TEXT, spaceAfter=6, alignment=TA_JUSTIFY)
body_left = ParagraphStyle("body_left", parent=body_style, alignment=TA_LEFT)
bullet_style = ParagraphStyle("bullet", parent=body_style,
    leftIndent=14, bulletIndent=2, spaceAfter=3, alignment=TA_LEFT)
ex_title_style = ParagraphStyle("ex_title", parent=ss["Normal"], fontName=FNB,
    fontSize=11, leading=14, textColor=BRAND_DARK, spaceAfter=4)
ex_body_style = ParagraphStyle("ex_body", parent=ss["Normal"], fontName=FN,
    fontSize=10.5, leading=15, textColor=TEXT, spaceAfter=4, alignment=TA_LEFT)
answer_style = ParagraphStyle("answer", parent=ss["Normal"], fontName=FNB,
    fontSize=11, leading=14, textColor=BRAND_DARK, alignment=TA_LEFT)
q_style = ParagraphStyle("q", parent=ss["Normal"], fontName=FNB,
    fontSize=11, leading=15, textColor=TEXT, spaceAfter=3, alignment=TA_LEFT)
q_body_style = ParagraphStyle("q_body", parent=ss["Normal"], fontName=FN,
    fontSize=11, leading=15, textColor=TEXT, spaceAfter=2, alignment=TA_LEFT)
option_style = ParagraphStyle("opt", parent=ss["Normal"], fontName=FN,
    fontSize=10.5, leading=14, textColor=TEXT, leftIndent=20, spaceAfter=1, alignment=TA_LEFT)
marks_style = ParagraphStyle("marks", parent=ss["Normal"], fontName=FNI,
    fontSize=9, leading=11, textColor=MUTED, alignment=TA_LEFT)
sol_step_style = ParagraphStyle("sol_step", parent=ss["Normal"], fontName=FN,
    fontSize=10.5, leading=15.5, textColor=TEXT, spaceAfter=3, leftIndent=10, alignment=TA_LEFT)
sol_q_style = ParagraphStyle("sol_q", parent=ss["Normal"], fontName=FNB,
    fontSize=11, leading=15, textColor=BRAND_DARK, spaceAfter=3, alignment=TA_LEFT)
section_label = ParagraphStyle("sec_lbl", parent=ss["Normal"], fontName=FNB,
    fontSize=11, leading=14, textColor=ACCENT, spaceBefore=8, spaceAfter=4, alignment=TA_LEFT)

# ============================================================
# NumberedCanvas — header on every page + "Page X of Y" footer
# ============================================================
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_decorations(num_pages)
            super().showPage()
        super().save()

    def _draw_decorations(self, total_pages):
        page_num = self._pageNumber
        # ---- top header ----
        self.setFont(FN, 8)
        self.setFillColor(MUTED)
        self.drawString(LEFT_M, PAGE_H - 38, "Power Maths  ·  Number System")
        self.drawRightString(PAGE_W - RIGHT_M, PAGE_H - 38, "by Prof. Kalpesh Vyas")
        self.setStrokeColor(BRAND)
        self.setLineWidth(0.6)
        self.line(LEFT_M, PAGE_H - 44, PAGE_W - RIGHT_M, PAGE_H - 44)
        # ---- bottom footer ----
        self.setStrokeColor(BRAND)
        self.setLineWidth(0.6)
        self.line(LEFT_M, 44, PAGE_W - RIGHT_M, 44)
        self.setFont(FN, 8)
        self.setFillColor(MUTED)
        self.drawString(LEFT_M, 32,
            "© Power Maths  ·  Prof. Kalpesh Vyas  ·  For enrolled students only")
        self.drawRightString(PAGE_W - RIGHT_M, 32,
            f"Page {page_num} of {total_pages}")

# ============================================================
# Reusable flowable helpers
# ============================================================
def title_block(doc_title, doc_subtitle=None):
    items = [
        Paragraph("Power Maths  ·  Number System", title_style),
        Paragraph("by Prof. Kalpesh Vyas", subtitle_style),
        Spacer(1, 4),
        HRFlowable(width="100%", thickness=1.5, color=BRAND,
                   spaceBefore=0, spaceAfter=6),
        Paragraph(doc_title, doc_title_style),
    ]
    if doc_subtitle:
        items.append(Paragraph(doc_subtitle, subtitle_style))
    items.append(Spacer(1, 4))
    return items

def example_box(title, body_paras):
    """Light gray rounded box for worked examples."""
    inner = [Paragraph(f"Worked Example — {title}", ex_title_style)]
    inner.append(HRFlowable(width="100%", thickness=0.4,
                            color=EXAMPLE_BORD, spaceBefore=0, spaceAfter=4))
    for p in body_paras:
        if isinstance(p, str):
            inner.append(Paragraph(p, ex_body_style))
        else:
            inner.append(p)
    t = Table([[inner]], colWidths=[CONTENT_W])
    t.setStyle(TableStyle([
        ('BACKGROUND',     (0,0), (-1,-1), EXAMPLE_BG),
        ('BOX',            (0,0), (-1,-1), 0.5, EXAMPLE_BORD),
        ('ROUNDEDCORNERS', [6,6,6,6]),
        ('LEFTPADDING',    (0,0), (-1,-1), 12),
        ('RIGHTPADDING',   (0,0), (-1,-1), 12),
        ('TOPPADDING',     (0,0), (-1,-1), 8),
        ('BOTTOMPADDING',  (0,0), (-1,-1), 8),
        ('VALIGN',         (0,0), (-1,-1), 'TOP'),
    ]))
    return KeepTogether([Spacer(1,4), t, Spacer(1,8)])

def defn_box(term, definition):
    """Definition strip — teal left bar, teal-50 background."""
    p = Paragraph(f"<b>{term}.</b>  {definition}",
                  ParagraphStyle("def", parent=body_left, leading=15.5, spaceAfter=0))
    t = Table([[p]], colWidths=[CONTENT_W])
    t.setStyle(TableStyle([
        ('BACKGROUND',    (0,0), (-1,-1), DEFN_BG),
        ('LINEBEFORE',    (0,0), (0,-1), 3, BRAND),
        ('LEFTPADDING',   (0,0), (-1,-1), 10),
        ('RIGHTPADDING',  (0,0), (-1,-1), 8),
        ('TOPPADDING',    (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    return KeepTogether([Spacer(1,3), t, Spacer(1,4)])

def answer_box(text):
    """Highlighted final-answer box."""
    p = Paragraph(f"<b>Answer:</b>  {text}", answer_style)
    t = Table([[p]], colWidths=[CONTENT_W * 0.62])
    t.setStyle(TableStyle([
        ('BACKGROUND',     (0,0), (-1,-1), ANSWER_BG),
        ('BOX',            (0,0), (-1,-1), 0.7, ANSWER_BORD),
        ('ROUNDEDCORNERS', [4,4,4,4]),
        ('LEFTPADDING',    (0,0), (-1,-1), 8),
        ('RIGHTPADDING',   (0,0), (-1,-1), 8),
        ('TOPPADDING',     (0,0), (-1,-1), 5),
        ('BOTTOMPADDING',  (0,0), (-1,-1), 5),
    ]))
    return t

def bullets(items, style=bullet_style):
    return ListFlowable(
        [ListItem(Paragraph(it, style), leftIndent=12, value="•")
         for it in items],
        bulletType="bullet", start="•", leftIndent=14,
    )

class AnswerLines(Flowable):
    """Faint horizontal lines for students to write their working on."""
    def __init__(self, n_lines=3, gap=20, width=CONTENT_W, color=LINE_GRAY):
        super().__init__()
        self.n = n_lines
        self.gap = gap
        self.width = width
        self.height = n_lines * gap + 6
        self.color = color
    def wrap(self, *args):
        return self.width, self.height
    def draw(self):
        self.canv.setStrokeColor(self.color)
        self.canv.setLineWidth(0.4)
        for i in range(self.n):
            y = self.height - 4 - (i + 1) * self.gap
            self.canv.line(0, y, self.width, y)

def section_divider(text):
    return KeepTogether([
        Spacer(1, 6),
        HRFlowable(width="100%", thickness=0.6, color=BRAND,
                   spaceBefore=0, spaceAfter=2),
        Paragraph(text, section_label),
    ])

def render(filename, title, flowables):
    doc = SimpleDocTemplate(
        filename, pagesize=A4,
        leftMargin=LEFT_M, rightMargin=RIGHT_M,
        topMargin=TOP_M, bottomMargin=BOTTOM_M,
        title=title, author="Prof. Kalpesh Vyas",
        subject="Power Maths — Number System (CH001)",
    )
    doc.build(flowables, canvasmaker=NumberedCanvas)
    return os.path.getsize(filename)


# ============================================================
# PDF 1 — Material 01: Natural, Whole, Integers
# ============================================================
def build_material_01():
    F = []
    F += title_block(
        "Study Material 1 — Natural Numbers, Whole Numbers &amp; Integers",
        "Chapter CH001 · Number System  ·  Reading time ≈ 20 min")
    F.append(Paragraph(
        "Numbers are the language of mathematics. In this first study material we "
        "begin at the very beginning — with the counting numbers that a child "
        "first learns — and step by step extend the family to include zero and "
        "the negative whole numbers. These three sets together form the backbone "
        "of all school arithmetic and prepare us for the rational and irrational "
        "numbers that follow in the next material.", body_style))
    F.append(Paragraph(
        "By the end of this material you will be able to define each set, place "
        "any integer on the number line, state the properties that govern the "
        "four operations, and confidently simplify expressions such as "
        "(−15) + 8 − (−3) using sign rules.", body_style))

    # ---- Section 1 ----
    F.append(Paragraph("1.  Natural Numbers", h1_style))
    F.append(defn_box("Natural Numbers (ℕ)",
        "The natural numbers are the counting numbers 1, 2, 3, 4, …  They begin "
        "at 1 and continue without end, so the set ℕ = { 1, 2, 3, 4, … } is "
        "infinitely large. We write this compactly as ℕ = { 1, 2, 3, … } and "
        "say that ℕ has no largest member."))
    F.append(Paragraph(
        "Natural numbers are used for counting objects (3 apples, 7 students) "
        "and for ordering (1st, 2nd, 3rd). Every natural number is either "
        "<b>odd</b> (1, 3, 5, …) or <b>even</b> (2, 4, 6, …); every natural "
        "number greater than 1 is either <b>prime</b> (2, 3, 5, 7, 11, …) or "
        "<b>composite</b> (4, 6, 8, 9, 10, …).", body_style))
    F.append(Paragraph("Properties of natural numbers", h2_style))
    F.append(bullets([
        "<b>Closure under + and ×:</b>  if a, b ∈ ℕ then a + b ∈ ℕ and a × b ∈ ℕ.",
        "<b>Commutativity:</b>  a + b = b + a  and  a × b = b × a.",
        "<b>Associativity:</b>  (a + b) + c = a + (b + c)  and  (a × b) × c = a × (b × c).",
        "<b>Distributivity:</b>  a × (b + c) = a × b + a × c.",
        "<b>Identity:</b>  for addition there is <i>no</i> identity in ℕ (0 ∉ ℕ); "
        "for multiplication the identity is 1, since a × 1 = a.",
    ]))

    # ---- Section 2 ----
    F.append(Paragraph("2.  Whole Numbers", h1_style))
    F.append(defn_box("Whole Numbers (W)",
        "The whole numbers are obtained by adjoining 0 to the set of natural "
        "numbers:  W = { 0, 1, 2, 3, 4, … }.  Thus every natural number is a "
        "whole number, but 0 is a whole number that is not a natural number. "
        "Symbolically,  ℕ ⊂ W."))
    F.append(Paragraph(
        "Adding 0 to the counting numbers gives us the <b>additive identity</b>: "
        "for any whole number a,  a + 0 = a.  This is the foundation for "
        "subtraction within the set whenever the answer is non-negative (for "
        "example 7 − 4 = 3), although subtraction such as 4 − 7 has no answer "
        "inside W — that gap is filled by the integers below.", body_style))
    F.append(Paragraph(
        "Because W is closed under addition and multiplication and contains 0, "
        "it is the smallest set in which the arithmetic of counting is fully "
        "self-contained for non-negative answers.", body_style))

    F.append(example_box("1.  Operations on whole numbers", [
        "Simplify  18 + (6 × 4) − (12 ÷ 3).",
        "We follow BODMAS — brackets, of, division, multiplication, addition, subtraction.",
        "Step 1 — division:   12 ÷ 3 = 4",
        "Step 2 — multiplication:   6 × 4 = 24",
        "Step 3 — the expression becomes  18 + 24 − 4",
        "Step 4 — addition:   18 + 24 = 42",
        "Step 5 — subtraction:   42 − 4 = 38",
        answer_box("38"),
    ]))

    # ---- Section 3 ----
    F.append(PageBreak())
    F.append(Paragraph("3.  Integers", h1_style))
    F.append(defn_box("Integers (ℤ)",
        "The integers consist of the positive whole numbers, the negative whole "
        "numbers, and zero:  ℤ = { …, −3, −2, −1, 0, 1, 2, 3, … }.  We write "
        "ℤ⁺ = { 1, 2, 3, … } for the positive integers and ℤ⁻ = { …, −3, −2, −1 } "
        "for the negative integers, so that  ℤ = ℤ⁻ ∪ {0} ∪ ℤ⁺."))
    F.append(Paragraph(
        "Negative numbers arise naturally when we measure quantities that can "
        "go in opposite directions from a reference point — temperatures below "
        "freezing, depths below sea level, bank debits, or westward distances "
        "from a starting town. The number 0 serves as the reference.", body_style))

    F.append(Paragraph("3.1  The Number Line", h2_style))
    F.append(Paragraph(
        "Every integer can be represented as a single point on a straight line "
        "called the <b>number line</b>. We choose a point for 0, mark equal "
        "unit lengths to the right for positive integers (1, 2, 3, …) and to "
        "the left for negative integers (−1, −2, −3, …).", body_style))
    F.append(Paragraph(
        "Two important facts about the number line:", body_left))
    F.append(bullets([
        "Numbers to the <b>right</b> are <b>greater</b>:  −2 &lt; 0 &lt; 3.",
        "The integer −5 lies 5 units to the left of 0; +4 lies 4 units to the right.",
        "For any integer a, the point −a is the mirror image of a about 0 — "
        "they are the same distance from 0 but on opposite sides.",
    ]))

    F.append(example_box("2.  Reading the number line", [
        "Arrange in increasing order:  −7,  3,  −2,  0,  −10,  5.",
        "Plot each integer on the number line. Reading from left to right "
        "(smallest to largest) gives:",
        "        −10  &lt;  −7  &lt;  −2  &lt;  0  &lt;  3  &lt;  5",
        "Rule of thumb — the more negative a number is, the further left it "
        "sits, so it is the smaller.",
        answer_box("−10,  −7,  −2,  0,  3,  5"),
    ]))

    # ---- Section 4 ----
    F.append(Paragraph("4.  Operations on Integers — Sign Rules", h1_style))
    F.append(Paragraph(
        "Once we admit negative numbers we must agree on how the four operations "
        "behave. The rules below are the working tools of school arithmetic.", body_style))
    F.append(Paragraph("4.1  Addition and subtraction", h2_style))
    F.append(bullets([
        "<b>Same signs:</b>  add the magnitudes and keep the sign.  "
        "(−3) + (−4) = −7.",
        "<b>Opposite signs:</b>  subtract the smaller magnitude from the larger "
        "and keep the sign of the larger.  (−8) + (+5) = −3.",
        "<b>Subtraction</b> is addition of the additive inverse:  "
        "a − b = a + (−b).  So  7 − (−4) = 7 + 4 = 11.",
    ]))
    F.append(Paragraph("4.2  Multiplication and division", h2_style))
    F.append(bullets([
        "<b>Like signs → positive:</b>  (−6) × (−3) = +18 ;  (−24) ÷ (−4) = +6.",
        "<b>Unlike signs → negative:</b>  (−6) × (+3) = −18 ;  (+24) ÷ (−4) = −6.",
        "Any integer × 0 = 0.",
    ]))

    F.append(example_box("3.  Simplifying an integer expression", [
        "Evaluate  (−15) + 8 − (−3).",
        "Step 1 — rewrite the subtraction:  −(−3) = +3, so the expression becomes "
        "(−15) + 8 + 3.",
        "Step 2 — group the positives:  8 + 3 = 11.",
        "Step 3 — combine with the negative:  −15 + 11 = −4.",
        answer_box("−4"),
    ]))

    # ---- Section 5 ----
    F.append(PageBreak())
    F.append(Paragraph("5.  Properties of Integer Operations", h1_style))
    F.append(Paragraph(
        "Integers inherit almost all the algebraic properties of natural numbers "
        "and, because they contain 0 and negatives, gain two important new ones:", body_style))
    F.append(bullets([
        "<b>Closure:</b>  ℤ is closed under +, −, ×.  (It is not closed under ÷, "
        "since 3 ÷ 2 ∉ ℤ.)",
        "<b>Commutativity &amp; associativity</b> of + and ×.",
        "<b>Distributivity</b> of × over +.",
        "<b>Additive identity</b> is 0:   a + 0 = a.",
        "<b>Additive inverse</b> exists for every a:   a + (−a) = 0.",
        "<b>Multiplicative identity</b> is 1:   a × 1 = a.",
        "<b>Multiplicative inverse</b> exists in ℤ only for a = 1 and a = −1.",
    ]))

    F.append(example_box("4.  A word problem with integers", [
        "The temperature at noon in Shimla was 5 °C. By midnight it had fallen "
        "by 12 °C. What was the temperature at midnight?",
        "Let noon temperature = +5.  A fall of 12 °C means we add −12.",
        "        midnight temperature = (+5) + (−12) = −7",
        answer_box("−7 °C"),
        "Interpretation: the temperature dropped below freezing.",
    ]))

    # ---- Section 6 ----
    F.append(Paragraph("6.  Summary", h1_style))
    F.append(Paragraph(
        "We have built the number family step by step, each set extending the "
        "previous one:", body_style))
    F.append(bullets([
        "Natural  ℕ = { 1, 2, 3, … }  — counting numbers.",
        "Whole  W = { 0, 1, 2, 3, … } = ℕ ∪ {0}.",
        "Integers  ℤ = { …, −3, −2, −1, 0, 1, 2, 3, … }  = W ∪ {−1, −2, −3, …}.",
        "Chain of containment:  ℕ ⊂ W ⊂ ℤ.",
        "The number line gives a geometric picture; right = greater, left = smaller.",
        "Sign rules: like signs → + for ×, ÷; unlike signs → −.",
        "Every integer has an additive inverse; only ±1 have multiplicative inverses in ℤ.",
    ]))
    F.append(Paragraph(
        "In the next study material we go beyond ℤ and meet the rational "
        "numbers (fractions p/q) and the irrational numbers (such as √2 and π) "
        "that together fill the entire number line.", body_style))
    return F


# ============================================================
# PDF 2 — Material 02: Rational & Irrational Numbers
# ============================================================
def build_material_02():
    F = []
    F += title_block(
        "Study Material 2 — Rational &amp; Irrational Numbers",
        "Chapter CH001 · Number System  ·  Reading time ≈ 22 min")
    F.append(Paragraph(
        "Integers are excellent for whole-quantity arithmetic, but the real "
        "world constantly produces quantities that lie <i>between</i> the "
        "integers — half a pizza, three-quarters of an hour, the diagonal of "
        "a unit square. To describe these we extend ℤ in two stages: first to "
        "the <b>rational</b> numbers (fractions), and then to the "
        "<b>irrational</b> numbers. Together they form the <b>real</b> numbers.", body_style))

    # ---- Section 1 ----
    F.append(Paragraph("1.  Rational Numbers", h1_style))
    F.append(defn_box("Rational Number (ℚ)",
        "A number is called rational if it can be written in the form p/q, "
        "where p and q are integers and q ≠ 0. The set of all rational numbers "
        "is denoted by ℚ.  Every integer n is rational because n = n/1."))
    F.append(Paragraph("Examples of rational numbers:", body_left))
    F.append(bullets([
        "3/4,  −7/9,  5 (= 5/1),  0 (= 0/1),  −2 (= −2/1).",
        "0.25 = 25/100 = 1/4   and   0.333… = 1/3.",
        "−1.5 = −3/2.",
    ]))
    F.append(Paragraph("1.1  Equivalent fractions and standard form", h2_style))
    F.append(Paragraph(
        "Two fractions p/q and r/s are <b>equivalent</b> if p × s = q × r. For "
        "example 2/3 = 6/9 = 10/15. A fraction is in <b>standard form</b> "
        "(or lowest terms) when q &gt; 0 and gcd(|p|, q) = 1 — that is, the "
        "numerator and denominator have no common factor other than 1.", body_style))

    F.append(example_box("1.  Reducing to standard form", [
        "Write 36/60 in standard form.",
        "Find gcd(36, 60).  36 = 2² × 3²  and  60 = 2² × 3 × 5.",
        "Common factors: 2² × 3 = 12.  So gcd = 12.",
        "Divide numerator and denominator by 12:",
        "        36 ÷ 12 = 3,   60 ÷ 12 = 5.",
        answer_box("3/5"),
    ]))

    # ---- Section 2 ----
    F.append(PageBreak())
    F.append(Paragraph("2.  Decimal Expansions of Rational Numbers", h1_style))
    F.append(Paragraph(
        "When we divide the numerator of a rational number p/q by its "
        "denominator q, exactly one of two things happens:", body_style))
    F.append(bullets([
        "<b>Terminating decimal</b> — the division stops and the decimal ends. "
        "This happens when the prime factors of q (after reducing) are only 2 "
        "and/or 5.  Examples: 1/4 = 0.25,  7/20 = 0.35,  3/8 = 0.375.",
        "<b>Non-terminating recurring decimal</b> — the division never ends "
        "but a block of digits repeats forever. This happens for every other "
        "denominator.  Examples: 1/3 = 0.333… = 0.3̄,  2/7 = 0.285714285714… = 0.2̄8̄5̄7̄1̄4̄.",
    ]))
    F.append(Paragraph(
        "The bar over the digits indicates the recurring block. A useful fact: "
        "a decimal that either terminates or recurs is always rational, and "
        "every rational number has one of these two decimal forms.", body_style))

    F.append(example_box("2.  Converting a recurring decimal to a fraction", [
        "Write 0.363636… (= 0.3̄6̄) as a fraction in lowest terms.",
        "Let  x = 0.363636…",
        "Then  100 x = 36.363636…   (shift two places because the repeating block has length 2)",
        "Subtract:  100 x − x = 36.363636… − 0.363636…",
        "        99 x = 36",
        "        x = 36/99",
        "Reduce:  gcd(36, 99) = 9,  so  x = 4/11.",
        answer_box("4/11"),
    ]))

    # ---- Section 3 ----
    F.append(PageBreak())
    F.append(Paragraph("3.  Irrational Numbers", h1_style))
    F.append(defn_box("Irrational Number",
        "A real number that cannot be written in the form p/q with p, q ∈ ℤ and "
        "q ≠ 0 is called irrational. In other words, an irrational number is a "
        "real number that is not rational. Its decimal expansion is "
        "<b>non-terminating and non-recurring</b>."))
    F.append(Paragraph("Familiar irrational numbers:", body_left))
    F.append(bullets([
        "√2 ≈ 1.41421356…   (the diagonal of a unit square — proved irrational by Pythagoreans).",
        "√3 ≈ 1.73205081…   (diagonal of a 1 × √2 rectangle).",
        "√5 ≈ 2.23606798…",
        "π ≈ 3.14159265…   (ratio of circumference to diameter of any circle).",
        "e ≈ 2.71828183…   (base of natural logarithms).",
    ]))
    F.append(Paragraph(
        "The sum, difference, product, or quotient of a non-zero rational with "
        "an irrational is irrational. For example 2 + √3 is irrational, and "
        "5 × √2 is irrational. (But √2 × √2 = 2 is rational — the product of "
        "two irrationals need not be irrational.)", body_style))

    F.append(example_box("3.  An irrational between two rationals", [
        "Find an irrational number between 2 and 3.",
        "The integers 4 and 9 lie on either side: 4 &lt; 5, 6, 7, 8 &lt; 9, so "
        "√4 = 2 and √9 = 3.",
        "Pick any perfect square strictly between 4 and 9 — say 5 — and take its "
        "square root. Since 5 is not a perfect square, √5 is irrational, and",
        "        2 = √4  &lt;  √5  &lt;  √9 = 3.",
        answer_box("√5  (≈ 2.236) lies between 2 and 3 and is irrational."),
    ]))

    # ---- Section 4 ----
    F.append(PageBreak())
    F.append(Paragraph("4.  Locating √2 and √3 on the Number Line", h1_style))
    F.append(Paragraph(
        "Irrational numbers are real points on the number line just like "
        "rationals — they only resist being written as fractions. We can "
        "construct them geometrically with a compass and ruler using the "
        "Pythagorean theorem.", body_style))
    F.append(Paragraph("4.1  Construction of √2", h2_style))
    F.append(bullets([
        "Step 1 — Mark the point O for 0 and the point A for 1 on the number line.",
        "Step 2 — At A, draw a perpendicular of length 1 (= AB).",
        "Step 3 — Join O to B. By Pythagoras,  OB = √(OA² + AB²) = √(1² + 1²) = √2.",
        "Step 4 — With centre O and radius OB, draw an arc cutting the number "
        "line at P. Then OP = √2, so P represents √2.",
    ]))
    F.append(Paragraph("4.2  Construction of √3 (extending the spiral)", h2_style))
    F.append(bullets([
        "From the point P (which marks √2), draw a perpendicular of length 1 (= PQ).",
        "Join O to Q. Then OQ = √((√2)² + 1²) = √(2 + 1) = √3.",
        "With centre O and radius OQ, draw an arc cutting the number line at R. "
        "Then R represents √3.",
        "Continuing this <b>square-root spiral</b> (each time drawing a unit "
        "perpendicular) locates √4, √5, √6, … in turn.",
    ]))

    F.append(example_box("4.  Comparing a rational with an irrational", [
        "Which is larger,  √2  or  1.41 ?",
        "Square both numbers (both are positive, so squaring preserves order).",
        "        (√2)² = 2      and      (1.41)² = 1.9881",
        "Since  2 &gt; 1.9881,  we have  √2 &gt; 1.41.",
        answer_box("√2 &gt; 1.41   (more precisely, √2 ≈ 1.41421…)."),
    ]))

    # ---- Section 5 ----
    F.append(PageBreak())
    F.append(Paragraph("5.  Real Numbers and the Number Line", h1_style))
    F.append(defn_box("Real Numbers (ℝ)",
        "The union of all rational and all irrational numbers is called the set "
        "of real numbers, written ℝ. Geometrically, every point on the number "
        "line corresponds to exactly one real number, and every real number "
        "corresponds to exactly one point on the line."))
    F.append(Paragraph(
        "The chain of containment is now complete:", body_style))
    F.append(bullets([
        "ℕ ⊂ W ⊂ ℤ ⊂ ℚ ⊂ ℝ,   and   ℝ = ℚ ∪ (ℝ \\ ℚ),",
        "where  ℝ \\ ℚ  denotes the set of irrational numbers.",
        "Between any two distinct real numbers there are infinitely many "
        "rationals and infinitely many irrationals — the line is <b>dense</b>.",
    ]))

    F.append(Paragraph("6.  Summary", h1_style))
    F.append(bullets([
        "Rational = p/q form, q ≠ 0; decimal terminates or recurs.",
        "Irrational = not p/q; decimal is non-terminating, non-recurring.",
        "Real = rational ∪ irrational = every point on the number line.",
        "Use the square-root spiral to locate √n geometrically.",
        "Compare a positive irrational √n with a rational r by squaring both.",
    ]))
    return F


# ============================================================
# PDF 3 — Material 03: HCF and LCM
# ============================================================
def build_material_03():
    F = []
    F += title_block(
        "Study Material 3 — HCF and LCM",
        "Chapter CH001 · Number System  ·  Reading time ≈ 22 min")
    F.append(Paragraph(
        "Two of the most useful ideas in number theory are the <b>Highest Common "
        "Factor</b> (HCF) and the <b>Least Common Multiple</b> (LCM) of a pair "
        "of numbers. They help us split quantities into equal groups, combine "
        "repeating events, simplify fractions, and add them efficiently. This "
        "material covers both methods — prime factorisation and the division "
        "method — and the elegant identity that links the two ideas.", body_style))

    # ---- Section 1 ----
    F.append(Paragraph("1.  Factors, Multiples and Primes", h1_style))
    F.append(defn_box("Factor &amp; Multiple",
        "For natural numbers a and b, we say a is a <b>factor</b> (or divisor) "
        "of b, written a | b, if b = a × k for some natural number k. Then b is "
        "called a <b>multiple</b> of a.  For example 3 | 12 because 12 = 3 × 4; "
        "the factors of 12 are 1, 2, 3, 4, 6, 12."))
    F.append(defn_box("Prime &amp; Composite",
        "A natural number greater than 1 whose only factors are 1 and itself is "
        "called <b>prime</b> (2, 3, 5, 7, 11, 13, …). A natural number greater "
        "than 1 that is not prime is <b>composite</b> (4, 6, 8, 9, 10, 12, …). "
        "The number 1 is neither prime nor composite."))
    F.append(Paragraph(
        "Every composite number can be written as a product of primes in "
        "essentially one way — this is the <b>Fundamental Theorem of Arithmetic</b>.", body_style))

    F.append(Paragraph("2.  Prime Factorisation", h1_style))
    F.append(Paragraph(
        "To prime-factorise a number, repeatedly divide it by the smallest "
        "prime that divides it until the quotient itself is prime. The product "
        "of all the prime divisors (counted with repetition) is the prime "
        "factorisation.", body_style))

    F.append(example_box("1.  Prime factorisation", [
        "Prime-factorise 84 and 90.",
        "84 = 2 × 42 = 2 × 2 × 21 = 2 × 2 × 3 × 7 = 2² × 3 × 7.",
        "90 = 2 × 45 = 2 × 3 × 15 = 2 × 3 × 3 × 5 = 2 × 3² × 5.",
        answer_box("84 = 2² × 3 × 7    and    90 = 2 × 3² × 5."),
    ]))

    # ---- Section 3 ----
    F.append(PageBreak())
    F.append(Paragraph("3.  Highest Common Factor (HCF)", h1_style))
    F.append(defn_box("HCF",
        "The Highest Common Factor (HCF) — also called the Greatest Common "
        "Divisor (GCD) — of two or more natural numbers is the largest natural "
        "number that divides each of them.  It is written HCF(a, b) or gcd(a, b)."))

    F.append(Paragraph("3.1  HCF by prime factorisation", h2_style))
    F.append(Paragraph(
        "Write each number as a product of primes. The HCF is the product of "
        "each common prime raised to the <b>smaller</b> of the two powers.", body_style))
    F.append(example_box("2.  HCF by prime factorisation", [
        "Find HCF(84, 90).",
        "From Example 1:   84 = 2² × 3 × 7      and      90 = 2 × 3² × 5.",
        "Common primes: 2 and 3.",
        "Take the smaller power of each:  min(2, 1) = 1 for 2,  min(1, 2) = 1 for 3.",
        "So  HCF = 2¹ × 3¹ = 2 × 3 = 6.",
        answer_box("HCF(84, 90) = 6"),
    ]))

    F.append(Paragraph("3.2  HCF by the division (Euclid's) method", h2_style))
    F.append(Paragraph(
        "For larger numbers the division method is faster. To find HCF(a, b) "
        "with a &gt; b:", body_style))
    F.append(bullets([
        "Step 1 — Divide a by b.  Write  a = b × q₁ + r₁,  where 0 ≤ r₁ &lt; b.",
        "Step 2 — If r₁ = 0, then HCF = b.  Otherwise divide b by r₁:  "
        "b = r₁ × q₂ + r₂.",
        "Step 3 — Continue dividing the previous divisor by the previous "
        "remainder until the remainder becomes 0. The last non-zero remainder "
        "is the HCF.",
    ]))
    F.append(example_box("3.  HCF by the division method", [
        "Find HCF(96, 404).",
        "Step 1 — 404 ÷ 96 = 4 remainder 20      →  404 = 96 × 4 + 20",
        "Step 2 — 96 ÷ 20 = 4 remainder 16       →   96 = 20 × 4 + 16",
        "Step 3 — 20 ÷ 16 = 1 remainder 4        →   20 = 16 × 1 + 4",
        "Step 4 — 16 ÷ 4 = 4 remainder 0         →   16 = 4 × 4 + 0",
        "The last non-zero remainder is 4.",
        answer_box("HCF(96, 404) = 4"),
    ]))

    # ---- Section 4 ----
    F.append(PageBreak())
    F.append(Paragraph("4.  Least Common Multiple (LCM)", h1_style))
    F.append(defn_box("LCM",
        "The Least Common Multiple (LCM) of two or more natural numbers is the "
        "smallest natural number that is a multiple of each of them.  "
        "For example, multiples of 4 are 4, 8, 12, 16, 20, … and multiples of 6 "
        "are 6, 12, 18, 24, … ; their smallest common multiple is 12, so "
        "LCM(4, 6) = 12."))

    F.append(Paragraph("4.1  LCM by prime factorisation", h2_style))
    F.append(Paragraph(
        "Write each number as a product of primes. The LCM is the product of "
        "every prime that appears, raised to the <b>larger</b> of the two powers.", body_style))
    F.append(example_box("4.  LCM of three numbers", [
        "Find LCM(12, 15, 20).",
        "Prime factorise:   12 = 2² × 3,   15 = 3 × 5,   20 = 2² × 5.",
        "Primes appearing: 2, 3, 5. Take the largest power of each:",
        "        2²,   3¹,   5¹.",
        "Multiply:   LCM = 2² × 3 × 5 = 4 × 3 × 5 = 60.",
        answer_box("LCM(12, 15, 20) = 60"),
    ]))

    F.append(Paragraph("4.2  LCM by the division method", h2_style))
    F.append(Paragraph(
        "Place the numbers in a row. Divide them all by any prime that divides "
        "at least one of them, carrying down undivided numbers unchanged. "
        "Repeat until the bottom row contains only 1s. The LCM is the product "
        "of every prime used in the left column.", body_style))
    F.append(example_box("5.  LCM by the division method", [
        "Find LCM(8, 12) by the ladder method.",
        "        2 |  8 ,  12",
        "        2 |  4 ,   6",
        "        2 |  2 ,   3",
        "        3 |  1 ,   3",
        "          |  1 ,   1",
        "Multiply all the divisors in the left column:",
        "        LCM = 2 × 2 × 2 × 3 = 24.",
        answer_box("LCM(8, 12) = 24"),
    ]))

    # ---- Section 5 ----
    F.append(PageBreak())
    F.append(Paragraph("5.  The HCF × LCM Identity", h1_style))
    F.append(defn_box("HCF–LCM Identity",
        "For any two positive integers a and b:   HCF(a, b) × LCM(a, b) = a × b.   "
        "Equivalently,   LCM(a, b) = (a × b) ÷ HCF(a, b).   "
        "This lets us find the LCM instantly once the HCF is known (or vice versa)."))
    F.append(Paragraph(
        "Why it works. In the prime factorisations of a and b, the HCF takes "
        "the <i>smaller</i> power of each prime while the LCM takes the "
        "<i>larger</i> power. Multiplying the two therefore gives, for every "
        "prime, the sum of the two powers — exactly the prime factorisation of "
        "a × b. (Note: this identity holds only for two numbers; for three or "
        "more it must be applied pairwise.)", body_style))

    F.append(example_box("6.  Using the identity", [
        "The HCF of two numbers is 11 and their LCM is 693. If one of the "
        "numbers is 77, find the other.",
        "By the identity:   HCF × LCM = product of the two numbers.",
        "        11 × 693 = 77 × other",
        "        other = (11 × 693) ÷ 77 = 7623 ÷ 77 = 99",
        answer_box("The other number is 99."),
    ]))

    # ---- Section 6: Applications ----
    F.append(Paragraph("6.  Choosing HCF or LCM in a Word Problem", h1_style))
    F.append(Paragraph(
        "Students often confuse HCF and LCM when reading a word problem. A "
        "simple rule of thumb removes the confusion:", body_style))
    F.append(defn_box("Rule of thumb",
        "Ask: <i>Are we splitting things into equal groups, or are we waiting "
        "for repeating events to coincide?</i>  "
        "If the answer is <b>splitting / dividing / maximum size of equal "
        "groups</b> → use the <b>HCF</b>.  "
        "If the answer is <b>coinciding / next time together / smallest common "
        "multiple</b> → use the <b>LCM</b>."))
    F.append(bullets([
        "<b>HCF situations:</b>  longest possible tile that fits a floor "
        "exactly; largest bottle that measures several quantities exactly; "
        "maximum students per row when planting in equal rows.",
        "<b>LCM situations:</b>  two bells ringing together; three buses "
        "leaving a depot together; traffic lights changing together; "
        "smallest common length when cutting rods into equal pieces with "
        "no remainder.",
    ]))

    F.append(example_box("7.  Choosing the right tool", [
        "Two ropes of length 36 m and 48 m are to be cut into pieces of equal "
        "length. What is the maximum length of each piece so that no rope is "
        "wasted?",
        "We want the largest length that divides both 36 and 48 — that is HCF(36, 48).",
        "Prime factorise:  36 = 2² × 3²,  48 = 2⁴ × 3.",
        "HCF = 2² × 3 = 12.  So each piece can be at most 12 m long.",
        "Check:  36 ÷ 12 = 3 pieces from rope 1,  48 ÷ 12 = 4 pieces from rope 2 — no waste. ✓",
        answer_box("Maximum piece length = 12 m  (use HCF)."),
    ]))

    # ---- Section 7: Summary ----
    F.append(Paragraph("7.  Summary", h1_style))
    F.append(bullets([
        "HCF = highest number that divides each of the given numbers.",
        "LCM = smallest number that is a multiple of each of the given numbers.",
        "Prime-factor method: HCF takes the smaller power of each common prime; "
        "LCM takes the larger power of every prime that appears.",
        "Division (Euclid) method: keep dividing until remainder 0; the last "
        "non-zero remainder is the HCF.",
        "Identity:  HCF(a, b) × LCM(a, b) = a × b  (two numbers only).",
        "Use HCF to split into largest equal groups; use LCM to find when "
        "repeating events next coincide.",
        "Rule of thumb — 'splitting / maximum size' → HCF ; "
        "'coinciding / next together' → LCM.",
    ]))
    return F


# ============================================================
# PDF 4 — Practice Sheet 1 (problems only)
# ============================================================
# Each problem is a tuple: (number, type, marks, question_text, options_or_none, n_answer_lines)
PRACTICE_1 = [
    (1,  "MCQ",  1,
     "Which of the following is a natural number?",
     ["0", "−3", "7", "2.5"], 2),
    (2,  "MCQ",  1,
     "The smallest whole number is",
     ["−1", "0", "1", "2"], 2),
    (3,  "MCQ",  1,
     "The value of (−5) + (+3) is",
     ["−8", "−2", "2", "8"], 2),
    (4,  "MCQ",  1,
     "Which of these is NOT an integer?",
     ["−7", "0", "4", "1/2"], 2),
    (5,  "MCQ",  1,
     "The additive inverse of −8 is",
     ["−8", "1/8", "8", "0"], 2),
    (6,  "MCQ",  1,
     "Which of the following is a rational number between 1/3 and 2/3?",
     ["1/4", "5/12", "3/4", "1/2 is irrational"], 2),
    (7,  "NUM",  2,
     "Evaluate (−15) + 8 − (−3).", None, 6),
    (8,  "NUM",  2,
     "Find the value of (−6) × (−4) × 2.", None, 6),
    (9,  "NUM",  2,
     "Simplify:  24 ÷ (−6) + (−3).", None, 6),
    (10, "NUM",  2,
     "Convert 5/8 to a decimal.", None, 6),
    (11, "NUM",  3,
     "Express 0.363636… (= 0.3̄6̄) as a fraction in lowest terms.", None, 8),
    (12, "NUM",  3,
     "Find three rational numbers between 1/3 and 2/3.", None, 8),
    (13, "NUM",  3,
     "Simplify:  2/3 + (−5/6) − (−1/4).", None, 8),
    (14, "WORD", 3,
     "The temperature at noon was 5 °C. By midnight it had dropped by 12 °C. "
     "What was the temperature at midnight?", None, 8),
    (15, "WORD", 4,
     "A submarine is cruising at −150 m. It descends another 60 m and then "
     "ascends 35 m. What is its final depth?", None, 9),
    (16, "WORD", 4,
     "Priya had ₹0 in her bank account. She deposited ₹2000, then withdrew "
     "₹750, and later withdrew another ₹1200. What is her final balance?",
     None, 9),
    (17, "WORD", 3,
     "The product of two integers is −72. If one integer is 9, find the other.",
     None, 8),
    (18, "WORD", 4,
     "An elevator starts at the ground floor (0). It goes up 12 floors, then "
     "down 17 floors, then up 5 floors. On which floor does it finally stop?",
     None, 9),
]

def build_practice_01():
    F = []
    F += title_block(
        "Practice Sheet 1 — Natural, Whole, Integers &amp; Rational Numbers",
        "Chapter CH001 · Number System  ·  Total marks: 45  ·  Time: 60 min")
    F.append(Paragraph(
        "<b>Instructions.</b>  Answer all questions in the space provided. "
        "Section A contains multiple-choice questions — circle the correct "
        "option. Section B contains short numerical questions — show your "
        "working. Section C contains word problems — write each step clearly. "
        "All the best!", body_style))

    F.append(section_divider("Section A  ·  Multiple Choice  ·  1 mark each"))
    for q in PRACTICE_1[:6]:
        F.append(_render_question(q))

    F.append(section_divider("Section B  ·  Numerical Questions  ·  2–3 marks each"))
    for q in PRACTICE_1[6:13]:
        F.append(_render_question(q))

    F.append(section_divider("Section C  ·  Word Problems  ·  3–4 marks each"))
    for q in PRACTICE_1[13:]:
        F.append(_render_question(q))
    return F

def _render_question(q):
    """Render a single practice question with answer space, kept together."""
    num, qtype, marks, text, options, n_lines = q
    head = (f"<b>Q{num}.</b>  {text}  "
            f"<font color='#6B7280' size='9'><i>[{marks} mark"
            f"{'s' if marks != 1 else ''}]</i></font>")
    blocks = [Paragraph(head, q_style)]
    if options:
        letters = ["A", "B", "C", "D", "E"]
        for i, opt in enumerate(options):
            blocks.append(Paragraph(f"<b>{letters[i]}.</b>  {opt}", option_style))
    blocks.append(Spacer(1, 3))
    if qtype == "MCQ":
        blocks.append(AnswerLines(n_lines=1, gap=18))
    else:
        blocks.append(AnswerLines(n_lines=n_lines, gap=20))
    blocks.append(Spacer(1, 6))
    return KeepTogether(blocks)


# ============================================================
# PDF 5 — Practice Sheet 1 Solutions
# ============================================================
SOLUTIONS_1 = [
    (1, "MCQ", "Which of the following is a natural number?",
     [
        "Natural numbers are 1, 2, 3, 4, …  — the counting numbers.",
        "Check each option:  0 is whole but not natural;  −3 is an integer but not natural;  7 ∈ ℕ;  2.5 is not an integer.",
        "Only 7 belongs to ℕ.",
     ], "C) 7"),
    (2, "MCQ", "The smallest whole number is",
     [
        "Whole numbers W = { 0, 1, 2, 3, … } begin at 0.",
        "Every other option (−1, 1, 2) is either not in W or is larger than 0.",
        "The smallest is 0.",
     ], "B) 0"),
    (3, "MCQ", "The value of (−5) + (+3) is",
     [
        "Signs are opposite — subtract the magnitudes: 5 − 3 = 2.",
        "Keep the sign of the larger magnitude (5), which is negative.",
        "So (−5) + (+3) = −2.",
     ], "B) −2"),
    (4, "MCQ", "Which of these is NOT an integer?",
     [
        "Integers ℤ = { …, −2, −1, 0, 1, 2, … } — whole numbers, positive and negative.",
        "−7, 0 and 4 are all integers. 1/2 is a fraction that is not a whole number.",
        "So 1/2 ∉ ℤ.",
     ], "D) 1/2"),
    (5, "MCQ", "The additive inverse of −8 is",
     [
        "The additive inverse of a number x is the number −x such that x + (−x) = 0.",
        "For x = −8, the additive inverse is −(−8) = +8, since  −8 + 8 = 0.",
     ], "C) 8"),
    (6, "MCQ", "Which of the following is a rational number between 1/3 and 2/3?",
     [
        "1/3 ≈ 0.333  and  2/3 ≈ 0.667.",
        "Option A: 1/4 = 0.25 &lt; 0.333 — too small.",
        "Option C: 3/4 = 0.75 &gt; 0.667 — too large.",
        "Option D is a false statement (1/2 = 0.5 is rational).",
        "Option B: 5/12 ≈ 0.4167, which lies between 0.333 and 0.667.",
     ], "B) 5/12"),
    (7, "NUM", "Evaluate (−15) + 8 − (−3).",
     [
        "Rewrite the subtraction: −(−3) = +3.",
        "Expression becomes (−15) + 8 + 3.",
        "Combine the positives:  8 + 3 = 11.",
        "Add the negative:  −15 + 11 = −4.",
     ], "−4"),
    (8, "NUM", "Find the value of (−6) × (−4) × 2.",
     [
        "Multiply the first two factors: like signs give a positive,  6 × 4 = 24,  so (−6) × (−4) = +24.",
        "Now multiply by 2:  24 × 2 = 48.",
     ], "48"),
    (9, "NUM", "Simplify:  24 ÷ (−6) + (−3).",
     [
        "Apply BODMAS — division first.",
        "24 ÷ (−6) = −4   (unlike signs → negative).",
        "Then add:  −4 + (−3) = −7.",
     ], "−7"),
    (10, "NUM", "Convert 5/8 to a decimal.",
     [
        "Divide 5 by 8:  8 × 0.6 = 4.8,  remainder 0.2.",
        "Continue:  0.2 = 2.0 / 10,  and 8 × 0.02 = 0.16,  remainder 0.04…",
        "Directly:  5.000 ÷ 8 = 0.625   (8 × 0.625 = 5).",
        "Check:  625 × 8 = 5000, so 0.625 × 8 = 5.000. ✓",
     ], "0.625"),
    (11, "NUM", "Express 0.363636… (= 0.3̄6̄) as a fraction in lowest terms.",
     [
        "Let  x = 0.363636…",
        "The repeating block is '36' (length 2), so multiply by 10² = 100.",
        "100 x = 36.363636…",
        "Subtract:  100 x − x = 36.363636… − 0.363636…",
        "99 x = 36      ⇒      x = 36/99.",
        "Reduce:  gcd(36, 99) = 9,  so  x = 4/11.",
     ], "4/11"),
    (12, "NUM", "Find three rational numbers between 1/3 and 2/3.",
     [
        "Make the denominators equal and large enough to leave room.",
        "Multiply numerator and denominator of each by 4:",
        "        1/3 = 4/12     and     2/3 = 8/12.",
        "The fractions strictly between 4/12 and 8/12 are 5/12, 6/12, 7/12.",
        "These are three rational numbers between 1/3 and 2/3.",
     ], "5/12,  6/12 (= 1/2),  7/12"),
    (13, "NUM", "Simplify:  2/3 + (−5/6) − (−1/4).",
     [
        "Rewrite subtractions as additions:  −(−1/4) = +1/4,  and  + (−5/6) = −5/6.",
        "Expression:  2/3 − 5/6 + 1/4.",
        "LCM of denominators 3, 6, 4 is 12.",
        "Convert:  2/3 = 8/12,  −5/6 = −10/12,  1/4 = 3/12.",
        "Add:  8/12 − 10/12 + 3/12 = (8 − 10 + 3)/12 = 1/12.",
     ], "1/12"),
    (14, "WORD", "The temperature at noon was 5 °C. By midnight it had dropped by 12 °C. What was the temperature at midnight?",
     [
        "Let noon temperature = +5 °C.",
        "A drop of 12 °C means we add −12.",
        "Midnight temperature = (+5) + (−12) = −7 °C.",
        "The temperature fell below freezing.",
     ], "−7 °C"),
    (15, "WORD", "A submarine is cruising at −150 m. It descends another 60 m and then ascends 35 m. What is its final depth?",
     [
        "Starting depth = −150 m.",
        "Descending 60 m adds −60:  −150 + (−60) = −210 m.",
        "Ascending 35 m adds +35:  −210 + 35 = −175 m.",
        "Final position is 175 m below sea level.",
     ], "−175 m  (175 m below sea level)"),
    (16, "WORD", "Priya had ₹0 in her bank account. She deposited ₹2000, then withdrew ₹750, and later withdrew another ₹1200. What is her final balance?",
     [
        "Use integers: deposit = +, withdrawal = −.",
        "Balance = 0 + 2000 − 750 − 1200.",
        "Step 1:  0 + 2000 = 2000.",
        "Step 2:  2000 − 750 = 1250.",
        "Step 3:  1250 − 1200 = 50.",
        "Final balance is ₹50.",
     ], "₹50"),
    (17, "WORD", "The product of two integers is −72. If one integer is 9, find the other.",
     [
        "Let the other integer be x.",
        "Then  9 × x = −72.",
        "Solve:  x = (−72) ÷ 9 = −8   (unlike signs → negative).",
        "Check:  9 × (−8) = −72. ✓",
     ], "−8"),
    (18, "WORD", "An elevator starts at the ground floor (0). It goes up 12 floors, then down 17 floors, then up 5 floors. On which floor does it finally stop?",
     [
        "Track position with integers: up = +, down = −.",
        "Start: 0.",
        "Up 12:   0 + 12 = +12.",
        "Down 17:  12 + (−17) = −5   (below ground, in the basement levels).",
        "Up 5:    −5 + 5 = 0.",
        "The elevator returns to the ground floor.",
     ], "Floor 0  (ground floor)"),
]

def build_practice_01_solutions():
    F = []
    F += title_block(
        "Practice Sheet 1 — Solutions",
        "Chapter CH001 · Number System  ·  Step-by-step worked solutions")
    F.append(Paragraph(
        "Below are full, step-by-step solutions to every question in Practice "
        "Sheet 1. Read each line carefully — the reasoning matters more than "
        "the final number. The boxed answer at the end of each solution is the "
        "result you should arrive at.", body_style))

    # ---- Quick reference box ----
    F.append(Paragraph("Quick Reference — rules used in this sheet", h1_style))
    F.append(defn_box("Number sets",
        "Natural  ℕ = { 1, 2, 3, … }  ⊂  Whole  W = { 0, 1, 2, … }  ⊂  "
        "Integers  ℤ = { …, −2, −1, 0, 1, 2, … }  ⊂  Rational  ℚ = { p/q : "
        "p, q ∈ ℤ, q ≠ 0 }.  Every integer is rational (write n = n/1)."))
    F.append(Paragraph("Sign rules for integers", h2_style))
    F.append(bullets([
        "<b>Addition, same signs:</b>  add magnitudes, keep the sign.  "
        "(−3) + (−4) = −7.",
        "<b>Addition, opposite signs:</b>  subtract magnitudes, keep the sign "
        "of the larger.  (−8) + (+5) = −3.",
        "<b>Subtraction:</b>  a − b = a + (−b).  So  7 − (−4) = 7 + 4 = 11.",
        "<b>Multiplication / division — like signs → +:</b>  "
        "(−6) × (−3) = +18,  (−24) ÷ (−4) = +6.",
        "<b>Multiplication / division — unlike signs → −:</b>  "
        "(−6) × (+3) = −18,  (+24) ÷ (−4) = −6.",
    ]))
    F.append(Paragraph("Working with rational numbers", h2_style))
    F.append(bullets([
        "Standard form:  q &gt; 0 and gcd(|p|, q) = 1.",
        "To convert a recurring decimal 0.āb̄  to a fraction:  let x = 0.abab…, "
        "multiply by 10ⁿ where n = length of the repeating block, subtract, "
        "and reduce.",
        "To add/subtract fractions, take the LCM of denominators, convert each "
        "fraction, then combine the numerators.",
    ]))
    F.append(Spacer(1, 4))

    for sol in SOLUTIONS_1:
        F.append(_render_solution(sol))
    return F

def _render_solution(sol):
    num, qtype, question, steps, final = sol
    head = (f"<b>Q{num}.</b>  {question}")
    blocks = [Paragraph(head, sol_q_style)]
    for i, s in enumerate(steps, 1):
        blocks.append(Paragraph(f"<b>Step {i}.</b>  {s}", sol_step_style))
    blocks.append(Spacer(1, 3))
    blocks.append(answer_box(final))
    blocks.append(Spacer(1, 8))
    return KeepTogether(blocks)


# ============================================================
# PDF 6 — Practice Sheet 2 (problems only)
# ============================================================
PRACTICE_2 = [
    (1,  "MCQ",  1,
     "The HCF of 12 and 18 is",
     ["2", "3", "6", "36"], 2),
    (2,  "MCQ",  1,
     "The LCM of 4 and 6 is",
     ["2", "12", "24", "48"], 2),
    (3,  "MCQ",  1,
     "Which of these is a prime number?",
     ["9", "15", "21", "23"], 2),
    (4,  "MCQ",  1,
     "For two positive integers a and b, HCF(a, b) × LCM(a, b) equals",
     ["a + b", "a − b", "a × b", "a ÷ b"], 2),
    (5,  "MCQ",  1,
     "0.75 written as a fraction in lowest terms is",
     ["3/4", "75/100", "7/5", "3/5"], 2),
    (6,  "MCQ",  1,
     "The decimal expansion of 1/7 is",
     ["0.142857 (terminating)", "0.1̄4̄2̄8̄5̄7̄ (recurring)",
      "0.142857142857… (recurring)", "none of these"], 2),
    (7,  "NUM",  2,
     "Find the HCF of 36 and 60 by prime factorisation.", None, 6),
    (8,  "NUM",  2,
     "Find the LCM of 12, 15 and 20 by prime factorisation.", None, 6),
    (9,  "NUM",  3,
     "Find the HCF of 96 and 404 using the division method.", None, 8),
    (10, "NUM",  3,
     "Find the LCM of 8 and 12 using the division (ladder) method.", None, 8),
    (11, "NUM",  2,
     "Convert 7/20 to a decimal.", None, 6),
    (12, "NUM",  3,
     "Convert 0.454545… (= 0.4̄5̄) to a fraction in lowest terms.", None, 8),
    (13, "NUM",  3,
     "Simplify:  3/4 + 5/6 − 1/3.", None, 8),
    (14, "WORD", 4,
     "Two bells ring at intervals of 18 minutes and 24 minutes respectively. "
     "After how many minutes will they next ring together?", None, 9),
    (15, "WORD", 4,
     "Three containers hold 12 L, 16 L and 20 L of oil respectively. What is "
     "the capacity of the largest measuring vessel that can measure each "
     "container's oil exactly?", None, 9),
    (16, "WORD", 4,
     "The HCF of two numbers is 11 and their LCM is 693. If one of the numbers "
     "is 77, find the other.", None, 9),
    (17, "WORD", 4,
     "A farmer wants to plant 84 apple trees and 90 mango trees in rows. Each "
     "row must contain only one type of tree, and every row must have the same "
     "number of trees. What is the maximum number of trees per row?", None, 9),
    (18, "WORD", 3,
     "Three school buses leave the depot at the same time. They return after "
     "every 45 min, 60 min and 75 min respectively. After how many minutes "
     "will they all next leave the depot together?", None, 8),
]

def build_practice_02():
    F = []
    F += title_block(
        "Practice Sheet 2 — HCF, LCM, Decimals &amp; Fractions",
        "Chapter CH001 · Number System  ·  Total marks: 49  ·  Time: 60 min")
    F.append(Paragraph(
        "<b>Instructions.</b>  Answer all questions in the space provided. "
        "Section A is multiple choice — circle the correct option. Section B "
        "is numerical — show every step of working. Section C is word "
        "problems — define the quantities, then solve. Calculators are not "
        "required; all answers are exact.", body_style))

    F.append(section_divider("Section A  ·  Multiple Choice  ·  1 mark each"))
    for q in PRACTICE_2[:6]:
        F.append(_render_question(q))

    F.append(section_divider("Section B  ·  Numerical Questions  ·  2–3 marks each"))
    for q in PRACTICE_2[6:13]:
        F.append(_render_question(q))

    F.append(section_divider("Section C  ·  Word Problems  ·  3–4 marks each"))
    for q in PRACTICE_2[13:]:
        F.append(_render_question(q))
    return F


# ============================================================
# PDF 7 — Practice Sheet 2 Solutions
# ============================================================
SOLUTIONS_2 = [
    (1, "MCQ", "The HCF of 12 and 18 is",
     [
        "List the factors of each number.",
        "Factors of 12:  1, 2, 3, 4, 6, 12.",
        "Factors of 18:  1, 2, 3, 6, 9, 18.",
        "Common factors:  1, 2, 3, 6.  The largest is 6.",
     ], "C) 6"),
    (2, "MCQ", "The LCM of 4 and 6 is",
     [
        "Multiples of 4:  4, 8, 12, 16, 20, …",
        "Multiples of 6:  6, 12, 18, 24, …",
        "Smallest common multiple is 12.",
     ], "B) 12"),
    (3, "MCQ", "Which of these is a prime number?",
     [
        "A prime has exactly two factors: 1 and itself.",
        "9 = 3 × 3 (composite),  15 = 3 × 5 (composite),  21 = 3 × 7 (composite).",
        "23 has no factors other than 1 and 23 — it is prime.",
     ], "D) 23"),
    (4, "MCQ", "For two positive integers a and b, HCF(a, b) × LCM(a, b) equals",
     [
        "This is the HCF–LCM identity for two numbers:",
        "        HCF(a, b) × LCM(a, b) = a × b.",
     ], "C) a × b"),
    (5, "MCQ", "0.75 written as a fraction in lowest terms is",
     [
        "0.75 = 75/100.",
        "Reduce:  gcd(75, 100) = 25.",
        "75 ÷ 25 = 3,  100 ÷ 25 = 4.",
        "So 0.75 = 3/4.",
     ], "A) 3/4"),
    (6, "MCQ", "The decimal expansion of 1/7 is",
     [
        "Divide 1 by 7:  1.000000 ÷ 7 = 0.142857142857…",
        "The block '142857' repeats forever — it is non-terminating and recurring.",
        "So 1/7 = 0.1̄4̄2̄8̄5̄7̄.",
        "Option C is the correct statement of this fact.",
     ], "C) 0.142857142857… (recurring)"),
    (7, "NUM", "Find the HCF of 36 and 60 by prime factorisation.",
     [
        "Prime factorise:  36 = 2² × 3²   and   60 = 2² × 3 × 5.",
        "Common primes: 2 and 3.",
        "HCF takes the smaller power of each common prime:",
        "        2²  (min of 2 and 2),   3¹  (min of 2 and 1).",
        "HCF = 2² × 3 = 4 × 3 = 12.",
     ], "12"),
    (8, "NUM", "Find the LCM of 12, 15 and 20 by prime factorisation.",
     [
        "Prime factorise:  12 = 2² × 3,  15 = 3 × 5,  20 = 2² × 5.",
        "Primes appearing: 2, 3, 5.",
        "LCM takes the larger power of each prime across all numbers:",
        "        2²  (max of 2, 0, 2),   3¹  (max of 1, 1, 0),   5¹  (max of 0, 1, 1).",
        "LCM = 2² × 3 × 5 = 4 × 3 × 5 = 60.",
     ], "60"),
    (9, "NUM", "Find the HCF of 96 and 404 using the division method.",
     [
        "Step 1 — 404 ÷ 96 = 4 remainder 20     →  404 = 96 × 4 + 20",
        "Step 2 — 96 ÷ 20 = 4 remainder 16       →   96 = 20 × 4 + 16",
        "Step 3 — 20 ÷ 16 = 1 remainder 4        →   20 = 16 × 1 + 4",
        "Step 4 — 16 ÷ 4 = 4 remainder 0         →   16 = 4 × 4 + 0",
        "The last non-zero remainder is 4 — that is the HCF.",
     ], "4"),
    (10, "NUM", "Find the LCM of 8 and 12 using the division (ladder) method.",
     [
        "Place 8 and 12 in a row and divide by primes that divide at least one of them.",
        "        2 |  8 ,  12",
        "        2 |  4 ,   6",
        "        2 |  2 ,   3",
        "        3 |  1 ,   3",
        "          |  1 ,   1",
        "LCM = product of all divisors in the left column = 2 × 2 × 2 × 3 = 24.",
     ], "24"),
    (11, "NUM", "Convert 7/20 to a decimal.",
     [
        "Make the denominator a power of 10.",
        "20 × 5 = 100, so multiply numerator and denominator by 5.",
        "7/20 = (7 × 5) / (20 × 5) = 35/100 = 0.35.",
     ], "0.35"),
    (12, "NUM", "Convert 0.454545… (= 0.4̄5̄) to a fraction in lowest terms.",
     [
        "Let  x = 0.454545…",
        "Repeating block '45' has length 2, so multiply by 100.",
        "100 x = 45.454545…",
        "Subtract:  100 x − x = 45.454545… − 0.454545…",
        "99 x = 45      ⇒      x = 45/99.",
        "Reduce:  gcd(45, 99) = 9,  so  x = 5/11.",
     ], "5/11"),
    (13, "NUM", "Simplify:  3/4 + 5/6 − 1/3.",
     [
        "LCM of denominators 4, 6, 3 is 12.",
        "Convert each:  3/4 = 9/12,  5/6 = 10/12,  1/3 = 4/12.",
        "Substitute:  9/12 + 10/12 − 4/12 = (9 + 10 − 4)/12 = 15/12.",
        "Reduce:  gcd(15, 12) = 3,  so  15/12 = 5/4.",
        "As a mixed number: 5/4 = 1¼.",
     ], "5/4  (= 1.25 = 1¼)"),
    (14, "WORD", "Two bells ring at intervals of 18 minutes and 24 minutes respectively. After how many minutes will they next ring together?",
     [
        "The bells ring together at times that are common multiples of 18 and 24.",
        "We want the smallest such time — that is the LCM of 18 and 24.",
        "Prime factorise:  18 = 2 × 3²,  24 = 2³ × 3.",
        "LCM = larger power of each prime = 2³ × 3² = 8 × 9 = 72.",
        "So the bells next ring together after 72 minutes.",
     ], "72 minutes"),
    (15, "WORD", "Three containers hold 12 L, 16 L and 20 L of oil respectively. What is the capacity of the largest measuring vessel that can measure each container's oil exactly?",
     [
        "The vessel must measure 12, 16 and 20 exactly — its capacity must divide each of them.",
        "We want the largest such capacity — that is the HCF of 12, 16 and 20.",
        "Prime factorise:  12 = 2² × 3,  16 = 2⁴,  20 = 2² × 5.",
        "HCF = product of common primes with the smallest power = 2² = 4.",
        "So the largest vessel that measures all three exactly has capacity 4 L.",
     ], "4 litres"),
    (16, "WORD", "The HCF of two numbers is 11 and their LCM is 693. If one of the numbers is 77, find the other.",
     [
        "Use the identity:  HCF × LCM = product of the two numbers.",
        "Let the other number be x.  Then  11 × 693 = 77 × x.",
        "Compute  11 × 693 = 7623.",
        "Solve:  x = 7623 ÷ 77 = 99.",
        "Check:  HCF(77, 99) = 11 ✓  and  LCM(77, 99) = 693 ✓ (since 77 = 7 × 11, 99 = 9 × 11).",
     ], "99"),
    (17, "WORD", "A farmer wants to plant 84 apple trees and 90 mango trees in rows. Each row must contain only one type of tree, and every row must have the same number of trees. What is the maximum number of trees per row?",
     [
        "The number of trees per row must divide both 84 and 90.",
        "We want the maximum such number — that is the HCF of 84 and 90.",
        "Prime factorise:  84 = 2² × 3 × 7,  90 = 2 × 3² × 5.",
        "HCF = common primes with the smaller power = 2 × 3 = 6.",
        "So the farmer can plant at most 6 trees per row "
        "(84 = 14 rows × 6,  90 = 15 rows × 6).",
     ], "6 trees per row"),
    (18, "WORD", "Three school buses leave the depot at the same time. They return after every 45 min, 60 min and 75 min respectively. After how many minutes will they all next leave the depot together?",
     [
        "All three leave the depot together at times that are common multiples of 45, 60 and 75.",
        "We want the smallest such time — that is the LCM(45, 60, 75).",
        "Prime factorise:  45 = 3² × 5,  60 = 2² × 3 × 5,  75 = 3 × 5².",
        "LCM = larger power of each prime = 2² × 3² × 5² = 4 × 9 × 25 = 900.",
        "So the buses next leave together after 900 minutes (= 15 hours).",
     ], "900 minutes  (= 15 hours)"),
]

def build_practice_02_solutions():
    F = []
    F += title_block(
        "Practice Sheet 2 — Solutions",
        "Chapter CH001 · Number System  ·  Step-by-step worked solutions")
    F.append(Paragraph(
        "Below are full, step-by-step solutions to every question in Practice "
        "Sheet 2. Where a question involves HCF or LCM, the prime factorisation "
        "is shown explicitly so that you can see exactly which primes are "
        "common and which powers are taken. The boxed value at the end of each "
        "solution is the final answer.", body_style))

    # ---- Quick reference box ----
    F.append(Paragraph("Quick Reference — methods used in this sheet", h1_style))
    F.append(defn_box("HCF and LCM",
        "<b>HCF</b> (highest common factor) = largest number that divides each "
        "of the given numbers.   <b>LCM</b> (least common multiple) = smallest "
        "number that is a multiple of each of the given numbers."))
    F.append(Paragraph("Prime factorisation method", h2_style))
    F.append(bullets([
        "Write each number as a product of primes (e.g. 60 = 2² × 3 × 5).",
        "<b>HCF</b> = product of <i>common</i> primes, each raised to the "
        "<i>smaller</i> of the powers present.",
        "<b>LCM</b> = product of <i>every</i> prime that appears, each raised "
        "to the <i>larger</i> of the powers present.",
    ]))
    F.append(Paragraph("Division method &amp; identity", h2_style))
    F.append(bullets([
        "<b>HCF by Euclid's algorithm:</b>  repeatedly divide the previous "
        "divisor by the previous remainder; the last non-zero remainder is "
        "the HCF.",
        "<b>LCM by the ladder:</b>  divide the row of numbers by primes; "
        "the LCM is the product of all divisors in the left column.",
        "<b>Identity (two numbers only):</b>  HCF(a, b) × LCM(a, b) = a × b.",
        "<b>Decimals ↔ fractions:</b>  terminating decimal → write over a "
        "power of 10 and reduce; recurring decimal → use the multiply-and-"
        "subtract trick (multiply by 10ⁿ where n = length of the block).",
    ]))
    F.append(Spacer(1, 4))

    for sol in SOLUTIONS_2:
        F.append(_render_solution(sol))
    return F


# ============================================================
# Main
# ============================================================
def main():
    jobs = [
        (os.path.join(MAT_DIR,   "CH001-material-01-natural-whole-numbers.pdf"),
         "Power Maths — Number System — Material 1: Natural, Whole & Integers",
         build_material_01),
        (os.path.join(MAT_DIR,   "CH001-material-02-rational-irrational.pdf"),
         "Power Maths — Number System — Material 2: Rational & Irrational",
         build_material_02),
        (os.path.join(MAT_DIR,   "CH001-material-03-hcf-lcm.pdf"),
         "Power Maths — Number System — Material 3: HCF and LCM",
         build_material_03),
        (os.path.join(PRAC_DIR,  "CH001-practice-01.pdf"),
         "Power Maths — Number System — Practice Sheet 1",
         build_practice_01),
        (os.path.join(PRAC_DIR,  "CH001-practice-01-solutions.pdf"),
         "Power Maths — Number System — Practice Sheet 1 Solutions",
         build_practice_01_solutions),
        (os.path.join(PRAC_DIR,  "CH001-practice-02.pdf"),
         "Power Maths — Number System — Practice Sheet 2",
         build_practice_02),
        (os.path.join(PRAC_DIR,  "CH001-practice-02-solutions.pdf"),
         "Power Maths — Number System — Practice Sheet 2 Solutions",
         build_practice_02_solutions),
    ]
    print(f"Generating {len(jobs)} PDFs ...\n")
    for path, title, builder in jobs:
        flowables = builder()
        size = render(path, title, flowables)
        # quick page count
        try:
            from pypdf import PdfReader
            n = len(PdfReader(path).pages)
        except Exception as e:
            n = f"? ({e})"
        print(f"  ✓ {os.path.basename(path):55s}  {size/1024:7.1f} KB   pages = {n}")
    print("\nDone.")


if __name__ == "__main__":
    main()
