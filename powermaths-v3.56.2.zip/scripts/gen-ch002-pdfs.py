#!/usr/bin/env python3
"""
Power Maths — CH002 Algebra Basics
Generates 7 educational PDFs (3 study materials + 2 practice sheets + 2 solution sets).

All PDFs are A4, 5-6 pages each, professionally styled using FreeSans (Unicode)
so math symbols (x², x³, √, ×, ÷, ≠, ≤, ≥, ±, (x+a)²) render correctly.

Run:  python3 /home/z/my-project/scripts/gen-ch002-pdfs.py
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table,
    TableStyle, KeepTogether, PageBreak, Flowable, CondPageBreak,
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ------------------------------------------------------------------
# Paths & directories
# ------------------------------------------------------------------
BASE_DIR        = '/home/z/my-project'
MATERIALS_DIR   = os.path.join(BASE_DIR, 'public/materials')
PRACTICE_DIR    = os.path.join(BASE_DIR, 'public/practice')
os.makedirs(MATERIALS_DIR, exist_ok=True)
os.makedirs(PRACTICE_DIR, exist_ok=True)

# ------------------------------------------------------------------
# Page geometry  (A4 = 595.27 × 841.89 pt)
# ------------------------------------------------------------------
PAGE_W, PAGE_H = A4
MARGIN_L = 2.0 * cm
MARGIN_R = 2.0 * cm
MARGIN_T = 2.6 * cm
MARGIN_B = 2.0 * cm

# ------------------------------------------------------------------
# Brand palette  (dark slate / teal / emerald — NO blue / indigo)
# ------------------------------------------------------------------
COLOR_PRIMARY  = HexColor('#0f766e')   # teal-700
COLOR_ACCENT   = HexColor('#047857')   # emerald-700
COLOR_HEADING  = HexColor('#134e4a')   # teal-900
COLOR_SUBHEAD  = HexColor('#115e59')   # teal-800
COLOR_TEXT     = HexColor('#1e293b')   # slate-800
COLOR_MUTED    = HexColor('#64748b')   # slate-500
COLOR_BOX_BG   = HexColor('#f1f5f9')   # slate-100  (worked example)
COLOR_BOX_BD   = HexColor('#cbd5e1')   # slate-300
COLOR_ANS_BG   = HexColor('#d1fae5')   # emerald-100 (final answer)
COLOR_ANS_BD   = HexColor('#10b981')   # emerald-500
COLOR_RULE     = HexColor('#e2e8f0')   # slate-200
COLOR_QNUM_BG  = HexColor('#ccfbf1')   # teal-50

BRAND       = "Power Maths"
CHAPTER     = "Algebra Basics"
AUTHOR      = "Prof. Kalpesh Vyas"
FOOTER_COPY = "© Power Maths · Prof. Kalpesh Vyas · For enrolled students only"

# ------------------------------------------------------------------
# Register Unicode TTF font family (FreeSans covers √ ≠ ≤ ≥ ± × ÷ ² ³ ·)
# ------------------------------------------------------------------
_FONT_DIR = '/usr/share/fonts/truetype/freefont'
pdfmetrics.registerFont(TTFont('FS',         os.path.join(_FONT_DIR, 'FreeSans.ttf')))
pdfmetrics.registerFont(TTFont('FS-Bold',    os.path.join(_FONT_DIR, 'FreeSansBold.ttf')))
pdfmetrics.registerFont(TTFont('FS-Oblique', os.path.join(_FONT_DIR, 'FreeSansOblique.ttf')))
pdfmetrics.registerFont(TTFont('FS-BoldObl', os.path.join(_FONT_DIR, 'FreeSansBoldOblique.ttf')))
pdfmetrics.registerFontFamily(
    'FS', normal='FS', bold='FS-Bold', italic='FS-Oblique', boldItalic='FS-BoldObl'
)

# ------------------------------------------------------------------
# Paragraph styles
# ------------------------------------------------------------------
def make_styles():
    s = {}
    s['title']    = ParagraphStyle('title',    fontName='FS-Bold',   fontSize=22, leading=27,
                                   textColor=COLOR_HEADING, alignment=TA_LEFT, spaceAfter=2)
    s['subtitle'] = ParagraphStyle('subtitle', fontName='FS-Oblique',fontSize=11.5, leading=15,
                                   textColor=COLOR_MUTED, alignment=TA_LEFT, spaceAfter=2)
    s['meta']     = ParagraphStyle('meta',     fontName='FS',        fontSize=9.5, leading=12,
                                   textColor=COLOR_MUTED, alignment=TA_LEFT, spaceAfter=0)
    s['h1']       = ParagraphStyle('h1',       fontName='FS-Bold',   fontSize=15, leading=20,
                                   textColor=COLOR_HEADING, spaceBefore=10, spaceAfter=5)
    s['h2']       = ParagraphStyle('h2',       fontName='FS-Bold',   fontSize=12.5, leading=17,
                                   textColor=COLOR_SUBHEAD, spaceBefore=8, spaceAfter=3)
    s['body']     = ParagraphStyle('body',     fontName='FS',        fontSize=11, leading=16.5,
                                   textColor=COLOR_TEXT, alignment=TA_JUSTIFY, spaceAfter=5)
    s['body_l']   = ParagraphStyle('body_l',   fontName='FS',        fontSize=11, leading=16.5,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=5)
    s['bullet']   = ParagraphStyle('bullet',   fontName='FS',        fontSize=11, leading=16,
                                   textColor=COLOR_TEXT, leftIndent=18, bulletIndent=6,
                                   alignment=TA_LEFT, spaceAfter=2)
    s['note']     = ParagraphStyle('note',     fontName='FS-Oblique',fontSize=10, leading=14,
                                   textColor=COLOR_MUTED, alignment=TA_LEFT, spaceAfter=3,
                                   leftIndent=6)
    s['ex_title'] = ParagraphStyle('ex_title', fontName='FS-Bold',   fontSize=11, leading=15,
                                   textColor=COLOR_ACCENT, spaceAfter=3)
    s['ex_body']  = ParagraphStyle('ex_body',  fontName='FS',        fontSize=10.5, leading=15.5,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=3)
    s['ex_step']  = ParagraphStyle('ex_step',  fontName='FS',        fontSize=10.5, leading=15.5,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=2,
                                   leftIndent=12)
    s['q']        = ParagraphStyle('q',        fontName='FS-Bold',   fontSize=11, leading=15.5,
                                   textColor=COLOR_HEADING, alignment=TA_LEFT, spaceAfter=3)
    s['q_text']   = ParagraphStyle('q_text',   fontName='FS',        fontSize=11, leading=15.5,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=2)
    s['q_opt']    = ParagraphStyle('q_opt',    fontName='FS',        fontSize=10.5, leading=14.5,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=1,
                                   leftIndent=22)
    s['marks']    = ParagraphStyle('marks',    fontName='FS-Oblique',fontSize=9.5, leading=12,
                                   textColor=COLOR_MUTED, alignment=TA_RIGHT, spaceAfter=0)
    s['sol_step'] = ParagraphStyle('sol_step', fontName='FS',        fontSize=10.5, leading=15,
                                   textColor=COLOR_TEXT, alignment=TA_LEFT, spaceAfter=2,
                                   leftIndent=14)
    s['sol_final']= ParagraphStyle('sol_final',fontName='FS-Bold',   fontSize=11, leading=15,
                                   textColor=COLOR_ACCENT, alignment=TA_LEFT, spaceAfter=2)
    s['ans_lbl']  = ParagraphStyle('ans_lbl',  fontName='FS-Bold',   fontSize=10.5, leading=14,
                                   textColor=COLOR_ACCENT, alignment=TA_LEFT, spaceAfter=0)
    return s

S = make_styles()

# ------------------------------------------------------------------
# Custom flowable: rounded box wrapping inner flowables
# ------------------------------------------------------------------
class RoundedBox(Flowable):
    def __init__(self, content, width=None, padding=10,
                 bg=COLOR_BOX_BG, border=COLOR_BOX_BD,
                 border_w=0.6, radius=7):
        Flowable.__init__(self)
        self.content = content
        self.width = width
        self.padding = padding
        self.bg = bg
        self.border = border
        self.border_w = border_w
        self.radius = radius

    def wrap(self, availWidth, availHeight):
        w = self.width if self.width else availWidth
        inner_w = w - 2 * self.padding
        h = 0
        for f in self.content:
            fw, fh = f.wrap(inner_w, availHeight)
            h += fh
        self._cw = w
        self._ch = h + 2 * self.padding
        return (self._cw, self._ch)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(self.bg)
        c.setStrokeColor(self.border)
        c.setLineWidth(self.border_w)
        c.roundRect(0, 0, self._cw, self._ch, self.radius, fill=1, stroke=1)
        c.restoreState()
        y = self._ch - self.padding
        x = self.padding
        inner_w = self._cw - 2 * self.padding
        for f in self.content:
            fw, fh = f.wrap(inner_w, self._ch)
            y -= fh
            f.drawOn(c, x, y)


# ------------------------------------------------------------------
# Numbered canvas for "Page X of Y"
# ------------------------------------------------------------------
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def _draw_page_number(self, total):
        self.saveState()
        self.setFont('FS', 8.5)
        self.setFillColor(COLOR_MUTED)
        self.drawRightString(PAGE_W - MARGIN_R, MARGIN_B - 0.85 * cm,
                             f"Page {self._pageNumber} of {total}")
        self.restoreState()


# ------------------------------------------------------------------
# Page header / footer (drawn on every page)
# ------------------------------------------------------------------
def header_footer(canv, doc):
    canv.saveState()
    # ---- Header bar ----
    canv.setFillColor(COLOR_HEADING)
    canv.setFont('FS-Bold', 10)
    canv.drawString(MARGIN_L, PAGE_H - 1.5 * cm, f"{BRAND}  ·  {CHAPTER}")
    canv.setFillColor(COLOR_MUTED)
    canv.setFont('FS-Oblique', 10)
    canv.drawRightString(PAGE_W - MARGIN_R, PAGE_H - 1.5 * cm, f"by {AUTHOR}")
    # accent rule
    canv.setStrokeColor(COLOR_PRIMARY)
    canv.setLineWidth(1.4)
    canv.line(MARGIN_L, PAGE_H - 1.72 * cm, PAGE_W - MARGIN_R, PAGE_H - 1.72 * cm)
    # subtle dot
    canv.setFillColor(COLOR_ACCENT)
    canv.circle(MARGIN_L + 1.6 * cm, PAGE_H - 1.72 * cm, 1.6, fill=1, stroke=0)
    # ---- Footer ----
    canv.setStrokeColor(COLOR_RULE)
    canv.setLineWidth(0.5)
    canv.line(MARGIN_L, MARGIN_B - 0.45 * cm, PAGE_W - MARGIN_R, MARGIN_B - 0.45 * cm)
    canv.setFont('FS', 8)
    canv.setFillColor(COLOR_MUTED)
    canv.drawString(MARGIN_L, MARGIN_B - 0.85 * cm, FOOTER_COPY)
    # page number drawn by NumberedCanvas
    canv.restoreState()


# ------------------------------------------------------------------
# Build helper
# ------------------------------------------------------------------
def build_pdf(path, story):
    doc = BaseDocTemplate(
        path, pagesize=A4,
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
        title=os.path.basename(path), author=AUTHOR,
        subject=f"{BRAND} — {CHAPTER}",
    )
    frame = Frame(MARGIN_L, MARGIN_B,
                  PAGE_W - MARGIN_L - MARGIN_R,
                  PAGE_H - MARGIN_T - MARGIN_B,
                  id='main', leftPadding=0, rightPadding=0,
                  topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id='main', frames=[frame],
                                       onPage=header_footer)])
    doc.build(story, canvasmaker=NumberedCanvas)


# ------------------------------------------------------------------
# Content helpers
# ------------------------------------------------------------------
def title_block(story, title, subtitle, meta_line):
    """Top title block under the running header."""
    story.append(Paragraph(title, S['title']))
    story.append(Paragraph(subtitle, S['subtitle']))
    story.append(Spacer(1, 2))
    # meta strip
    tbl = Table([[Paragraph(meta_line, S['meta'])]],
                colWidths=[PAGE_W - MARGIN_L - MARGIN_R])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), COLOR_QNUM_BG),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LINEBEFORE', (0, 0), (0, -1), 3, COLOR_ACCENT),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 8))


def H1(t):  return Paragraph(t, S['h1'])
def H2(t):  return Paragraph(t, S['h2'])
def P(t):   return Paragraph(t, S['body'])
def PL(t):  return Paragraph(t, S['body_l'])
def B(t):   return Paragraph('• ' + t, S['bullet'])
def N(t):   return Paragraph(t, S['note'])


def example(title, lines):
    """Worked example in a light gray rounded box. lines = list of strings."""
    content = [Paragraph(title, S['ex_title'])]
    for ln in lines:
        content.append(Paragraph(ln, S['ex_body']))
    return RoundedBox(content, padding=10, bg=COLOR_BOX_BG,
                      border=COLOR_BOX_BD, border_w=0.6, radius=7)


def example_steps(title, steps):
    """Worked example with numbered/algebraic steps shown as indented lines."""
    content = [Paragraph(title, S['ex_title'])]
    for st in steps:
        content.append(Paragraph(st, S['ex_step']))
    return RoundedBox(content, padding=10, bg=COLOR_BOX_BG,
                      border=COLOR_BOX_BD, border_w=0.6, radius=7)


def question(num, text, marks=None, sub_text=None):
    """A numbered practice question with optional marks and sub-text."""
    out = []
    if marks:
        row = Table(
            [[Paragraph(f"<b>Q{num}.</b>  {text}", S['q']),
              Paragraph(f"[{marks}]", S['marks'])]],
            colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 1.6 * cm, 1.6 * cm])
        row.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 0),
            ('RIGHTPADDING', (0, 0), (-1, -1), 0),
            ('TOPPADDING', (0, 0), (-1, -1), 0),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ]))
        out.append(row)
    else:
        out.append(Paragraph(f"<b>Q{num}.</b>  {text}", S['q']))
    if sub_text:
        out.append(Paragraph(sub_text, S['q_text']))
    return out


def mcq_options(opts):
    """Render MCQ options A/B/C/D."""
    out = []
    for i, opt in enumerate(opts):
        letter = chr(ord('A') + i)
        out.append(Paragraph(f"({letter})  {opt}", S['q_opt']))
    return out


def answer_space(height_cm=2.2):
    """Ruled notebook-style answer space — multiple thin baselines."""
    h = height_cm * cm
    line_spacing = 0.72 * cm
    n_lines = max(1, int(round(h / line_spacing)))
    rows = [[''] for _ in range(n_lines)]
    tbl = Table(rows, colWidths=[PAGE_W - MARGIN_L - MARGIN_R],
                rowHeights=[line_spacing] * n_lines)
    style = [
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]
    for i in range(n_lines):
        style.append(('LINEBELOW', (0, i), (-1, i), 0.4, COLOR_RULE))
    tbl.setStyle(TableStyle(style))
    return tbl


def solution(num, q_text, steps, final_answer):
    """A complete solution block: question + steps + highlighted final answer.
    The final_answer may include a short concept note after '||'."""
    # Allow optional concept note appended to final_answer with ' || '
    if ' || ' in final_answer:
        final_text, concept = final_answer.split(' || ', 1)
    else:
        final_text, concept = final_answer, None
    out = [Paragraph(f"<b>Q{num}.</b>  {q_text}", S['q'])]
    out.append(Spacer(1, 3))
    out.append(Paragraph("<b>Solution.</b>", S['sol_step']))
    for st in steps:
        out.append(Paragraph(st, S['sol_step']))
    out.append(Spacer(1, 4))
    # highlighted final answer box
    ans_para = [Paragraph("Answer:", S['ans_lbl']),
                Paragraph(final_text, S['sol_final'])]
    if concept:
        ans_para.append(Paragraph(
            f"<i>Concept:</i> {concept}", S['note']))
    out.append(RoundedBox(ans_para, padding=8, bg=COLOR_ANS_BG,
                          border=COLOR_ANS_BD, border_w=0.8, radius=6))
    out.append(Spacer(1, 12))
    return out


# ==================================================================
#  MATERIAL 1 — Algebraic Expressions
# ==================================================================
def material_01():
    story = []
    title_block(story,
                "Algebraic Expressions",
                "Study Material 1 · Terms, Coefficients, Like/Unlike Terms & Simplification",
                "Chapter 02 · Algebra Basics   |   Reading time ≈ 20 min   |   Level: Foundation")

    story.append(H1("1.  What is an Algebraic Expression?"))
    story.append(P(
        "An <b>algebraic expression</b> is a mathematical phrase that combines "
        "numbers (constants), letters (variables) and the four operations "
        "+, −, ×, ÷. For example, <b>3x + 5</b>, <b>2a² − 7ab + 4</b> and "
        "<b>(p + 2)(p − 3)</b> are all algebraic expressions. A single letter "
        "such as <b>x</b> standing for an unknown number is also an expression."))
    story.append(P(
        "An expression does <b>not</b> contain an equals sign (=); once we "
        "place an = sign between two expressions, we obtain an <b>equation</b>. "
        "Expressions are the building blocks of all of algebra — once you can "
        "read, simplify and manipulate them confidently, solving equations and "
        "factorising become much easier."))

    story.append(H1("2.  Terms, Factors and Coefficients"))
    story.append(P(
        "A <b>term</b> is a part of an expression separated from the rest by a "
        "+ or − sign. In <b>5x² − 3xy + 7</b> the three terms are "
        "<b>5x²</b>, <b>−3xy</b> and <b>7</b>. The sign in front of a term "
        "belongs to that term, so the second term is <b>−3xy</b>, not +3xy."))
    story.append(B("<b>Factors</b> — the quantities multiplied together to form a term. "
                   "The factors of <b>−3xy</b> are <b>−3</b>, <b>x</b> and <b>y</b>."))
    story.append(B("<b>Coefficient</b> — the numerical factor of a term. In <b>5x²</b> "
                   "the coefficient of x² is 5; in <b>−3xy</b> the coefficient of xy "
                   "is −3. We may also speak of the coefficient of <i>x</i> in "
                   "−3xy as −3y."))
    story.append(B("<b>Constant term</b> — a term with no variable, e.g. the 7 in "
                   "5x² − 3xy + 7."))

    story.append(H1("3.  Like and Unlike Terms"))
    story.append(P(
        "<b>Like terms</b> have exactly the same variable part (the same letters "
        "raised to the same powers). Only their coefficients may differ. "
        "<b>Unlike terms</b> have different variable parts. We can <b>add or "
        "subtract like terms</b> by combining their coefficients, but unlike "
        "terms cannot be combined into a single term."))
    story.append(B("Like terms:  7x and −3x  ·  4a²b and 9a²b  ·  6, −2 and 15 (all constants)."))
    story.append(B("Unlike terms:  5x and 5y  ·  3a²b and 3ab²  ·  2x and 2x²."))

    story.append(example(
        "Worked Example 1 — Combine like terms",
        ["Simplify  7x + 3y − 2x + 5y − 4.",
         "Group the like terms:  (7x − 2x) + (3y + 5y) − 4.",
         "Combine coefficients:  5x + 8y − 4.",
         "Answer:  <b>5x + 8y − 4</b>"]))

    story.append(H1("4.  Types of Expressions"))
    story.append(P("Expressions are classified by how many terms they contain:"))
    tbl = Table([
        ['<b>Type</b>',         '<b>Number of terms</b>', '<b>Example</b>'],
        ['Monomial',            '1',  '5x'],
        ['Binomial',            '2',  '3x + 7'],
        ['Trinomial',           '3',  'x² − 4x + 4'],
        ['Polynomial',          '1 or more', '2x³ − 5x² + x − 9'],
    ], colWidths=[3.5*cm, 4*cm, 8*cm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), COLOR_HEADING),
        ('TEXTCOLOR',  (0,0), (-1,0), white),
        ('FONTNAME',   (0,0), (-1,0), 'FS-Bold'),
        ('FONTNAME',   (0,1), (-1,-1), 'FS'),
        ('FONTSIZE',   (0,0), (-1,-1), 10),
        ('TEXTCOLOR',  (0,1), (-1,-1), COLOR_TEXT),
        ('ALIGN',      (1,0), (1,-1), 'CENTER'),
        ('VALIGN',     (0,0), (-1,-1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, COLOR_BOX_BG]),
        ('GRID',       (0,0), (-1,-1), 0.4, COLOR_BOX_BD),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING',  (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    # Convert HTML markup in table cells to Paragraphs for proper rendering
    def _pt(cell, style_name='body_l'):
        return Paragraph(cell, S[style_name])
    body_para = ParagraphStyle('tblh', fontName='FS-Bold', fontSize=10,
                               leading=13, textColor=white, alignment=TA_LEFT)
    body_cell = ParagraphStyle('tblc', fontName='FS', fontSize=10,
                               leading=13, textColor=COLOR_TEXT, alignment=TA_LEFT)
    body_cell_c = ParagraphStyle('tblcc', fontName='FS', fontSize=10,
                                 leading=13, textColor=COLOR_TEXT, alignment=TA_CENTER)
    tbl = Table([
        [Paragraph('Type', body_para), Paragraph('Number of terms', body_para), Paragraph('Example', body_para)],
        [Paragraph('Monomial', body_cell), Paragraph('1', body_cell_c), Paragraph('5x', body_cell)],
        [Paragraph('Binomial', body_cell), Paragraph('2', body_cell_c), Paragraph('3x + 7', body_cell)],
        [Paragraph('Trinomial', body_cell), Paragraph('3', body_cell_c), Paragraph('x² − 4x + 4', body_cell)],
        [Paragraph('Polynomial', body_cell), Paragraph('1 or more', body_cell_c), Paragraph('2x³ − 5x² + x − 9', body_cell)],
    ], colWidths=[3.8*cm, 4*cm, 8*cm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), COLOR_HEADING),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, COLOR_BOX_BG]),
        ('GRID',       (0,0), (-1,-1), 0.4, COLOR_BOX_BD),
        ('VALIGN',     (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 7),
        ('RIGHTPADDING', (0,0), (-1,-1), 7),
        ('TOPPADDING',  (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 6))
    story.append(P(
        "A <b>polynomial</b> in one variable x has the general form "
        "<b>aₙxⁿ + aₙ₋₁xⁿ⁻¹ + … + a₁x + a₀</b>, where the coefficients "
        "aᵢ are real numbers and n is a non-negative integer called the "
        "<b>degree</b> of the polynomial."))

    story.append(PageBreak())
    story.append(H1("5.  Simplifying Algebraic Expressions"))
    story.append(P("To simplify an expression we follow three rules in order:"))
    story.append(B("<b>Step 1 — Remove brackets</b> using the distributive law: "
                   "a(b + c) = ab + ac. Watch the sign: −a(b − c) = −ab + ac."))
    story.append(B("<b>Step 2 — Combine like terms</b> by adding or subtracting "
                   "their coefficients."))
    story.append(B("<b>Step 3 — Write the result</b> in a tidy order (e.g. "
                   "descending powers of x)."))

    story.append(example_steps(
        "Worked Example 2 — Distributive law with a negative sign",
        ["Simplify  3(2x − 5) − 2(x − 4).",
         "Expand each bracket:  6x − 15 − 2x + 8.",
         "   (note: −2 × −4 = +8)",
         "Group like terms:  (6x − 2x) + (−15 + 8).",
         "Combine:  4x − 7.",
         "Answer:  <b>4x − 7</b>"]))

    story.append(example_steps(
        "Worked Example 3 — Nested brackets and like terms",
        ["Simplify  2(x + 3) + 4(x − 1) − (x − 2).",
         "Expand:  2x + 6 + 4x − 4 − x + 2.",
         "   (the minus before (x − 2) flips both signs: −x + 2)",
         "Group like terms:  (2x + 4x − x) + (6 − 4 + 2).",
         "Combine:  5x + 4.",
         "Answer:  <b>5x + 4</b>"]))

    story.append(H2("5.1  Substituting values into an expression"))
    story.append(P(
        "To <b>evaluate</b> an expression for a particular value of the variable, "
        "we replace every occurrence of the variable with the given number "
        "(in brackets) and then carry out the arithmetic using BODMAS."))
    story.append(example_steps(
        "Worked Example 4 — Substitution",
        ["Evaluate  3x² − 2x + 5  when  x = −2.",
         "Substitute:  3(−2)² − 2(−2) + 5.",
         "Work out the power:  (−2)² = 4, so  3 × 4 − 2 × (−2) + 5.",
         "Multiply:  12 + 4 + 5.",
         "Add:  21.",
         "Answer:  <b>21</b>"]))

    story.append(PageBreak())
    story.append(H1("6.  Adding and Subtracting Polynomials"))
    story.append(P(
        "When adding or subtracting two polynomials, write them one below the "
        "other so that <b>like terms line up vertically</b>, then add or "
        "subtract the coefficients column by column. Always remember to "
        "distribute the sign of the operation into every term of the second "
        "polynomial."))
    story.append(example_steps(
        "Worked Example 5 — Subtracting polynomials",
        ["Subtract  (2x² − 5x + 3)  from  (5x² + 2x − 7).",
         "Write as:  (5x² + 2x − 7) − (2x² − 5x + 3).",
         "Distribute the minus:  5x² + 2x − 7 − 2x² + 5x − 3.",
         "Group like terms:  (5x² − 2x²) + (2x + 5x) + (−7 − 3).",
         "Combine:  3x² + 7x − 10.",
         "Answer:  <b>3x² + 7x − 10</b>"]))

    story.append(H1("7.  Multiplying Algebraic Expressions"))
    story.append(P(
        "When two terms are multiplied, multiply their coefficients together "
        "and multiply their variable parts together (adding the powers of any "
        "repeated letters). The distributive law lets us multiply a single term "
        "by a bracket, or one bracket by another."))
    story.append(B("<b>Monomial × monomial:</b>  3x · 4x² = 12x³."))
    story.append(B("<b>Monomial × bracket:</b>  2x(3x − 5) = 6x² − 10x."))
    story.append(B("<b>Bracket × bracket:</b>  multiply each term of the first by "
                   "each term of the second."))

    story.append(example_steps(
        "Worked Example 6 — Multiplying a binomial by a binomial",
        ["Expand  (x + 4)(x + 3).",
         "Use FOIL:  First, Outer, Inner, Last.",
         "   First  = x · x = x²",
         "   Outer  = x · 3 = 3x",
         "   Inner  = 4 · x = 4x",
         "   Last   = 4 · 3 = 12",
         "Add them:  x² + 3x + 4x + 12.",
         "Combine like terms:  x² + 7x + 12.",
         "Answer:  <b>x² + 7x + 12</b>"]))

    story.append(example_steps(
        "Worked Example 7 — Multiplying with a negative term",
        ["Expand  (2x − 3)(x + 5).",
         "Apply the distributive law (or FOIL):",
         "   2x · x = 2x²,   2x · 5 = 10x,",
         "   (−3) · x = −3x,  (−3) · 5 = −15.",
         "Add:  2x² + 10x − 3x − 15.",
         "Combine:  2x² + 7x − 15.",
         "Answer:  <b>2x² + 7x − 15</b>"]))

    story.append(H1("8.  Concept Map — Vocabulary at a Glance"))
    body_para = ParagraphStyle('tblh2', fontName='FS-Bold', fontSize=10,
                               leading=13, textColor=white, alignment=TA_LEFT)
    body_cell = ParagraphStyle('tblc2', fontName='FS', fontSize=10,
                               leading=13, textColor=COLOR_TEXT, alignment=TA_LEFT)
    tbl2 = Table([
        [Paragraph('Word', body_para), Paragraph('Meaning', body_para), Paragraph('Example', body_para)],
        [Paragraph('Variable', body_cell), Paragraph('A letter standing for an unknown number.', body_cell), Paragraph('x, y, a, b', body_cell)],
        [Paragraph('Constant', body_cell), Paragraph('A fixed number with no variable.', body_cell), Paragraph('5, −3, ½', body_cell)],
        [Paragraph('Term', body_cell), Paragraph('A part of an expression separated by + or −.', body_cell), Paragraph('5x², −3xy, 7', body_cell)],
        [Paragraph('Coefficient', body_cell), Paragraph('The numerical factor of a term.', body_cell), Paragraph('5 in 5x²', body_cell)],
        [Paragraph('Like terms', body_cell), Paragraph('Same variable part, possibly different coefficients.', body_cell), Paragraph('3a and −7a', body_cell)],
        [Paragraph('Polynomial', body_cell), Paragraph('One or more terms with whole-number powers.', body_cell), Paragraph('x² − 4x + 1', body_cell)],
    ], colWidths=[3.2*cm, 8.4*cm, 4.2*cm])
    tbl2.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), COLOR_HEADING),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, COLOR_BOX_BG]),
        ('GRID',       (0,0), (-1,-1), 0.4, COLOR_BOX_BD),
        ('VALIGN',     (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 7),
        ('RIGHTPADDING', (0,0), (-1,-1), 7),
        ('TOPPADDING',  (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(tbl2)
    story.append(Spacer(1, 6))

    story.append(H1("9.  Common Mistakes to Avoid"))
    story.append(B("Treating 3x + 5 as 8x — you cannot add unlike terms."))
    story.append(B("Forgetting to flip the sign when removing brackets "
                   "preceded by a minus, e.g. −(x − 4) = −x + 4, not −x − 4."))
    story.append(B("Writing (−x)² as −x² — squaring a negative gives a positive, "
                   "so (−x)² = x²."))
    story.append(B("Mixing up the coefficient and the variable, e.g. 3x × 2x = 6x², "
                   "not 5x or 6x."))
    story.append(B("Multiplying only the first term in a bracket: 2(x + 5) is "
                   "2x + 10, not 2x + 5."))

    story.append(H1("10.  Key Takeaways"))
    story.append(B("An expression combines numbers, variables and operations but "
                   "has no equals sign."))
    story.append(B("A term has a coefficient (number) and a variable part; the "
                   "sign in front belongs to the term."))
    story.append(B("Like terms share the same variable part and can be combined."))
    story.append(B("Monomial = 1 term, binomial = 2 terms, trinomial = 3 terms, "
                   "polynomial = any number of terms."))
    story.append(B("Simplify by removing brackets first, then combining like terms."))
    story.append(B("When multiplying, multiply coefficients and add powers of "
                   "the same letter."))
    story.append(N(
        "Tip: when in doubt, write each term in full with its sign and circle "
        "the like terms before adding. A neat, well-spaced page of working "
        "is the single biggest cause of correct algebra answers."))

    story.append(H1("11.  Quick Self-Check"))
    story.append(P("Try these before moving on to Practice Sheet 1 — answers "
                   "are in the worked-example boxes above."))
    story.append(B("How many terms are there in  4a²b − 3ab + 6?  (answer: 3)"))
    story.append(B("Combine like terms:  9x − 4 + 2x + 7.  (answer: 11x + 3)"))
    story.append(B("Simplify  2(x + 4) − 3(x − 1).  (answer: −x + 11)"))
    story.append(B("Evaluate  2x² + 3x − 1  at  x = 3.  (answer: 26)"))
    story.append(B("Expand  (x + 4)(x + 3).  (answer: x² + 7x + 12)"))
    story.append(B("If  P = x² − 2x + 1  and  Q = x² + 3x − 4, find  P − Q.  "
                   "(answer: −5x + 5)"))

    path = os.path.join(MATERIALS_DIR, 'CH002-material-01-algebraic-expressions.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  MATERIAL 2 — Linear Equations in One Variable
# ==================================================================
def material_02():
    story = []
    title_block(story,
                "Linear Equations in One Variable",
                "Study Material 2 · Solving x + a = b, ax = b, ax + b = c & Word Problems",
                "Chapter 02 · Algebra Basics   |   Reading time ≈ 22 min   |   Level: Foundation")

    story.append(H1("1.  What is a Linear Equation?"))
    story.append(P(
        "A <b>linear equation in one variable</b> is an equation that can be "
        "written in the form <b>ax + b = c</b>, where a, b, c are real numbers "
        "and a ≠ 0. The highest power of the variable x is 1, which is what "
        "makes the equation <i>linear</i>. The <b>solution</b> (or root) of "
        "the equation is the value of x that makes the two sides equal."))
    story.append(P(
        "Solving such an equation means finding the value of x. The big idea "
        "is simple: <b>whatever you do to one side, you must do exactly the "
        "same to the other side</b>. We use this rule to gradually isolate x "
        "until it sits alone on one side of the equals sign."))

    story.append(H1("2.  The Three Basic Forms"))
    story.append(P("Almost every linear equation reduces to one of three simple forms."))

    story.append(H2("2.1  Form 1 —  x + a = b"))
    story.append(P("Subtract a from both sides. The variable is already "
                   "free of any coefficient."))
    story.append(example_steps(
        "Worked Example 1 —  x + a = b",
        ["Solve  x + 7 = 12.",
         "Subtract 7 from both sides:  x + 7 − 7 = 12 − 7.",
         "Simplify:  x = 5.",
         "Answer:  <b>x = 5</b>"]))

    story.append(H2("2.2  Form 2 —  ax = b"))
    story.append(P("Divide both sides by the coefficient a (a ≠ 0)."))
    story.append(example_steps(
        "Worked Example 2 —  ax = b",
        ["Solve  4x = 24.",
         "Divide both sides by 4:  4x ÷ 4 = 24 ÷ 4.",
         "Simplify:  x = 6.",
         "Answer:  <b>x = 6</b>"]))

    story.append(H2("2.3  Form 3 —  ax + b = c"))
    story.append(P("First undo the + b (subtract b), then undo the × a "
                   "(divide by a). Always undo additions/subtractions before "
                   "multiplications/divisions."))
    story.append(example_steps(
        "Worked Example 3 —  ax + b = c",
        ["Solve  3x + 5 = 20.",
         "Step 1 (undo +5):  3x = 20 − 5 = 15.",
         "Step 2 (undo ×3):  x = 15 ÷ 3 = 5.",
         "Check:  3(5) + 5 = 15 + 5 = 20  ✓",
         "Answer:  <b>x = 5</b>"]))

    story.append(PageBreak())
    story.append(H1("3.  Equations with Variables on Both Sides"))
    story.append(P(
        "When the variable appears on both sides of the equation, first move "
        "all the x-terms to one side and all the constants to the other. "
        "Choose the side that keeps the coefficient of x positive — this "
        "avoids having to deal with negative coefficients later."))
    story.append(example_steps(
        "Worked Example 4 — Variable on both sides",
        ["Solve  5x − 3 = 2x + 9.",
         "Subtract 2x from both sides:  3x − 3 = 9.",
         "Add 3 to both sides:  3x = 12.",
         "Divide by 3:  x = 4.",
         "Check:  5(4) − 3 = 17,  2(4) + 9 = 17  ✓",
         "Answer:  <b>x = 4</b>"]))

    story.append(H1("4.  Equations with Brackets and Fractions"))
    story.append(P(
        "If the equation contains brackets, expand them first. If it contains "
        "fractions, multiply every term by the <b>LCM of the denominators</b> "
        "to clear the fractions — this turns the equation into a much simpler "
        "integer equation."))
    story.append(example_steps(
        "Worked Example 5 — Brackets on both sides",
        ["Solve  2(x + 3) = 3(x − 1).",
         "Expand:  2x + 6 = 3x − 3.",
         "Subtract 2x from both sides:  6 = x − 3.",
         "Add 3:  9 = x, i.e.  x = 9.",
         "Check:  2(9+3) = 24,  3(9−1) = 24  ✓",
         "Answer:  <b>x = 9</b>"]))
    story.append(example_steps(
        "Worked Example 6 — Equation with fractions",
        ["Solve  (x/2) + (x/3) = 10.",
         "LCM of 2 and 3 is 6. Multiply every term by 6:",
         "   6·(x/2) + 6·(x/3) = 6·10",
         "   3x + 2x = 60",
         "Combine:  5x = 60,  so  x = 12.",
         "Check:  12/2 + 12/3 = 6 + 4 = 10  ✓",
         "Answer:  <b>x = 12</b>"]))

    story.append(PageBreak())
    story.append(H1("5.  Solving Word Problems"))
    story.append(P(
        "Word problems become manageable once you follow a fixed routine:"))
    story.append(B("<b>Read</b> the problem carefully and decide what the unknown is."))
    story.append(B("<b>Let</b> a letter (usually x) stand for the unknown and write "
                   "down what it represents."))
    story.append(B("<b>Translate</b> the words into an equation using the information "
                   "given."))
    story.append(B("<b>Solve</b> the equation using the techniques above."))
    story.append(B("<b>Check</b> the answer against the original wording and "
                   "<b>state</b> it in a sentence."))

    story.append(example_steps(
        "Worked Example 7 — Age problem",
        ["Ravi is 5 years older than his sister. The sum of their ages is 27. "
         "Find Ravi's age.",
         "Let the sister's age be x years. Then Ravi's age is x + 5.",
         "Equation:  x + (x + 5) = 27.",
         "Simplify:  2x + 5 = 27.",
         "Subtract 5:  2x = 22.",
         "Divide by 2:  x = 11  (sister's age).",
         "Ravi's age = 11 + 5 = 16.",
         "Answer:  <b>Ravi is 16 years old.</b>"]))

    story.append(example_steps(
        "Worked Example 8 — Consecutive integers",
        ["Three consecutive integers add up to 84. Find the largest one.",
         "Let the smallest integer be n. The others are n+1 and n+2.",
         "Equation:  n + (n+1) + (n+2) = 84.",
         "Simplify:  3n + 3 = 84.",
         "Subtract 3:  3n = 81.",
         "Divide by 3:  n = 27.",
         "Largest = n + 2 = 29.",
         "Answer:  <b>29</b>"]))

    story.append(PageBreak())
    story.append(H1("6.  Common Mistakes to Avoid"))
    story.append(B("Dividing only one side by the coefficient — you must divide "
                   "<i>both</i> sides equally."))
    story.append(B("Forgetting to flip the sign when moving a term to the other "
                   "side; e.g. moving +5 gives −5."))
    story.append(B("Not distributing a minus into a bracket:  −(x − 3) = −x + 3, "
                   "not −x − 3."))
    story.append(B("Dividing by zero — never divide by a coefficient that might be "
                   "0 without checking."))
    story.append(B("Forgetting to multiply <i>every</i> term by the LCM when "
                   "clearing fractions."))

    story.append(H1("7.  Key Takeaways"))
    story.append(B("A linear equation in one variable can be written as ax + b = c."))
    story.append(B("The golden rule: do the same operation to <i>both</i> sides."))
    story.append(B("Undo additions/subtractions first, then multiplications/divisions."))
    story.append(B("Move all x-terms to one side and all constants to the other."))
    story.append(B("Clear fractions by multiplying through by the LCM of denominators."))
    story.append(B("Always check the answer by substituting back into the original."))
    story.append(N(
        "Tip: keep your working neat and vertical — write each new line directly "
        "underneath the previous one with the equals signs lined up. This makes "
        "it far easier to spot a slip in signs or arithmetic."))

    story.append(H1("8.  Quick Self-Check"))
    story.append(P("Try these before moving on to Practice Sheet 2."))
    story.append(B("Solve  x + 9 = 4.   (answer: x = −5)"))
    story.append(B("Solve  6x = −42.   (answer: x = −7)"))
    story.append(B("Solve  2x + 7 = 1.   (answer: x = −3)"))
    story.append(B("Solve  5x − 4 = 2x + 11.   (answer: x = 5)"))
    story.append(B("Solve  (x/3) − 2 = 4.   (answer: x = 18)"))

    path = os.path.join(MATERIALS_DIR, 'CH002-material-02-linear-equations.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  MATERIAL 3 — Factorisation and Algebraic Identities
# ==================================================================
def material_03():
    story = []
    title_block(story,
                "Factorisation and Algebraic Identities",
                "Study Material 3 · Common-Factor Method, (a+b)², (a−b)², a²−b²",
                "Chapter 02 · Algebra Basics   |   Reading time ≈ 22 min   |   Level: Foundation")

    story.append(H1("1.  What is Factorisation?"))
    story.append(P(
        "<b>Factorisation</b> is the reverse of expanding brackets. Given a "
        "polynomial, we write it as a <b>product of simpler expressions</b> "
        "called its factors. For example, expanding (x + 2)(x + 3) gives "
        "x² + 5x + 6; factorising x² + 5x + 6 means going the other way and "
        "writing it back as (x + 2)(x + 3)."))
    story.append(P(
        "Factorisation is useful for simplifying fractions, solving equations "
        "and rewriting expressions in a more revealing form. We will look at "
        "two big techniques: (i) taking out a <b>common factor</b>, and "
        "(ii) recognising the three <b>standard algebraic identities</b>."))

    story.append(H1("2.  Taking Out the Common Factor"))
    story.append(P(
        "If every term of an expression shares a common factor, divide each "
        "term by that factor and write the result inside a bracket, with the "
        "common factor outside. The common factor may be a number, a letter, "
        "or both."))
    story.append(example_steps(
        "Worked Example 1 — Numerical common factor",
        ["Factorise  6x + 9.",
         "HCF of 6 and 9 is 3.",
         "Take 3 out:  3(2x + 3).",
         "Answer:  <b>3(2x + 3)</b>"]))
    story.append(example_steps(
        "Worked Example 2 — Common factor with variables",
        ["Factorise  4x³y − 8x²y² + 12xy.",
         "Numerical HCF of 4, 8, 12 is 4.",
         "Variable HCF: x and y each appear in every term, lowest powers x and y.",
         "Common factor = 4xy.",
         "Divide each term by 4xy:  x² − 2xy + 3.",
         "Answer:  <b>4xy(x² − 2xy + 3)</b>"]))

    story.append(H1("3.  Factorisation by Grouping"))
    story.append(P(
        "When a polynomial with four terms has no factor common to all of "
        "them, try grouping the terms in pairs and removing a common factor "
        "from each pair. If the same bracket appears in both groups, it can "
        "be taken out as a new common factor."))
    story.append(example_steps(
        "Worked Example 3 — Grouping",
        ["Factorise  ax + ay + bx + by.",
         "Group in pairs:  (ax + ay) + (bx + by).",
         "Factor each pair:  a(x + y) + b(x + y).",
         "(x + y) is common — take it out:  (x + y)(a + b).",
         "Answer:  <b>(x + y)(a + b)</b>"]))

    story.append(PageBreak())
    story.append(H1("4.  The Three Standard Identities"))
    story.append(P("An <b>identity</b> is an equation that is true for every "
                   "value of the variable. Memorise these three — they turn up "
                   "again and again throughout algebra."))

    story.append(H2("4.1  Identity 1 —  (a + b)² = a² + 2ab + b²"))
    story.append(P("The square of a sum equals the sum of the squares plus "
                   "twice the product."))
    story.append(example_steps(
        "Worked Example 4 — Expand (2x + 3)²",
        ["(2x + 3)² = (2x)² + 2·(2x)·3 + 3²",
         "         = 4x² + 12x + 9.",
         "Answer:  <b>4x² + 12x + 9</b>"]))

    story.append(H2("4.2  Identity 2 —  (a − b)² = a² − 2ab + b²"))
    story.append(P("The square of a difference equals the sum of the squares "
                   "minus twice the product."))
    story.append(example_steps(
        "Worked Example 5 — Evaluate  98²  without a calculator",
        ["98 = 100 − 2,  so  98² = (100 − 2)².",
         "Apply (a − b)² = a² − 2ab + b² with a = 100, b = 2:",
         "   = 100² − 2·100·2 + 2²",
         "   = 10000 − 400 + 4 = 9604.",
         "Answer:  <b>9604</b>"]))

    story.append(H2("4.3  Identity 3 —  a² − b² = (a + b)(a − b)"))
    story.append(P("The difference of two squares factorises as the product "
                   "of a sum and a difference."))
    story.append(example_steps(
        "Worked Example 6 — Factorise  x² − 25",
        ["x² − 25 = x² − 5² = (x + 5)(x − 5).",
         "Answer:  <b>(x + 5)(x − 5)</b>"]))
    story.append(example_steps(
        "Worked Example 7 — Evaluate  53² − 47²",
        ["Use a² − b² = (a + b)(a − b) with a = 53, b = 47.",
         "   = (53 + 47)(53 − 47)",
         "   = 100 × 6 = 600.",
         "Answer:  <b>600</b>"]))

    story.append(PageBreak())
    story.append(H1("5.  Using Identities for Factorisation"))
    story.append(P(
        "Recognising an identity inside an expression lets you factorise it "
        "instantly. Look at the structure of the terms: two squared terms "
        "and a middle term that is ±2ab suggest Identity 1 or 2; two squared "
        "terms with no middle term suggest Identity 3."))
    story.append(example_steps(
        "Worked Example 8 — Factorise  4x² + 12x + 9",
        ["Compare with a² + 2ab + b².",
         "Take a = 2x,  b = 3  (because (2x)² = 4x² and 3² = 9).",
         "Check middle:  2·(2x)·3 = 12x  ✓",
         "So  4x² + 12x + 9 = (2x + 3)².",
         "Answer:  <b>(2x + 3)²</b>"]))
    story.append(example_steps(
        "Worked Example 9 — Factorise  9y² − 16",
        ["9y² − 16 = (3y)² − 4² = (3y + 4)(3y − 4).",
         "Answer:  <b>(3y + 4)(3y − 4)</b>"]))
    story.append(example_steps(
        "Worked Example 10 — Factorise  2x² − 50",
        ["First take out the common factor 2:  2(x² − 25).",
         "Then apply a² − b² inside the bracket:  x² − 25 = (x + 5)(x − 5).",
         "So  2x² − 50 = 2(x + 5)(x − 5).",
         "Answer:  <b>2(x + 5)(x − 5)</b>"]))

    story.append(H1("6.  Common Mistakes to Avoid"))
    story.append(B("Writing (a + b)² = a² + b² — the middle term 2ab is missing."))
    story.append(B("Writing (a − b)² = a² − b² — again the middle term is missing."))
    story.append(B("Confusing a² − b² (factorises) with a² + b² (does <i>not</i> "
                   "factorise over the reals)."))
    story.append(B("Forgetting to take out a numerical common factor before "
                   "applying an identity."))
    story.append(B("Stopping too early — always check that the brackets cannot "
                   "be factorised further."))

    story.append(H1("7.  Key Takeaways"))
    story.append(B("Factorisation is the reverse of expanding brackets."))
    story.append(B("Always look for a common factor first — numerical, "
                   "variable, or both."))
    story.append(B("Four-term polynomials often factorise by grouping in pairs."))
    story.append(B("Memorise (a+b)² = a² + 2ab + b², (a−b)² = a² − 2ab + b², "
                   "and a² − b² = (a+b)(a−b)."))
    story.append(B("Identities are useful both for expanding quickly and for "
                   "evaluating squares without a calculator."))
    story.append(N(
        "Tip: when you have factorised an expression, multiply your answer out "
        "again as a check. If you get back to the original, the factorisation "
        "is correct."))

    story.append(H1("8.  Quick Self-Check"))
    story.append(P("Try these before moving on to Practice Sheet 2."))
    story.append(B("Factorise  5x + 15.   (answer: 5(x + 3))"))
    story.append(B("Expand  (x + 4)².   (answer: x² + 8x + 16)"))
    story.append(B("Factorise  x² − 49.   (answer: (x + 7)(x − 7))"))
    story.append(B("Factorise  9x² + 6x + 1.   (answer: (3x + 1)²)"))
    story.append(B("Evaluate  101² using an identity.   (answer: 10201)"))

    path = os.path.join(MATERIALS_DIR, 'CH002-material-03-factorisation-identities.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  PRACTICE SHEET 1  (substitution, simplifying, like terms)
# ==================================================================
def practice_01():
    story = []
    title_block(story,
                "Practice Sheet 1 — Algebraic Expressions",
                "Substitution · Simplifying Expressions · Like & Unlike Terms",
                "Chapter 02 · 16 questions · Easy + Medium   |   Total marks: 40")

    story.append(P("<b>Instructions.</b>  Attempt all questions. Show your working "
                   "neatly in the space provided. MCQs carry 1 mark each, "
                   "numerical and short-answer questions carry 2–3 marks, and "
                   "word problems carry 4 marks. A separate solutions PDF is "
                   "available."))
    story.append(Spacer(1, 4))

    # --- Section A: MCQ ---
    story.append(H2("Section A — Multiple Choice  (1 mark each)"))
    for q in question(1, "Identify the coefficient of x in the term −7xy.", marks=1):
        story.append(q)
    for o in mcq_options(['7', '−7', '−7y', '7y']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(2, "Which of the following pairs are <b>like terms</b>?", marks=1):
        story.append(q)
    for o in mcq_options(['3x and 3y', '5a²b and 5ab²', '8p²q and −2p²q', '2x and 2x²']):
        story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(3, "How many terms are there in  4x² − 3xy + y − 7?", marks=1):
        story.append(q)
    for o in mcq_options(['2', '3', '4', '5']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(4, "When x = 3, the value of  2x² − x + 4  is:", marks=1):
        story.append(q)
    for o in mcq_options(['19', '21', '22', '25']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    # --- Section B: Numerical ---
    story.append(H2("Section B — Numerical  (2 marks each)"))
    for q in question(5, "If  a = 2  and  b = −3, evaluate  3a² + 2ab − b².", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(6, "Simplify by combining like terms:  7x − 3 + 4x + 8 − 2x.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(7, "Simplify:  5(x + 2) − 3(x − 4).", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(8, "Simplify:  2(3a − b) + 4(a + 2b).", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(9, "Evaluate  4x² − 2x + 1  when  x = −2.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(10, "If  P = x² − 3x + 2  and  Q = x² + 5x − 7, find  P + Q.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    # --- Section C: Short answer ---
    story.append(CondPageBreak(4*cm))
    story.append(H2("Section C — Short Answer  (3 marks each)"))
    for q in question(11, "Subtract  (2x² − 5x + 3)  from  (4x² + x − 6).", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    for q in question(12, "Simplify  3(x − 2) − 2(x − 3) + 4(x + 1)  and find its value at x = 1.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    for q in question(13, "If  l = 2x + 3  and  b = x − 1, write the expression for "
                          "the perimeter of the rectangle and simplify it.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    for q in question(14, "Find the value of  5a − 3b + 2c  when  a = 1, b = −2, c = 4.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    # --- Section D: Word problems ---
    story.append(H2("Section D — Word Problems  (4 marks each)"))
    for q in question(15, "A rectangle has length  (3x + 2) cm  and breadth  (x − 1) cm. "
                          "Express its perimeter as a simplified algebraic expression "
                          "and find its value when  x = 4.", marks=4):
        story.append(q)
    story.append(answer_space(7.5)); story.append(Spacer(1, 6))

    for q in question(16, "Priya has  (5x + 10)  marbles. She gives  (2x − 3)  marbles "
                          "to her brother. Write a simplified expression for the "
                          "number of marbles she has left, and evaluate it at  x = 6.", marks=4):
        story.append(q)
    story.append(answer_space(7.5))

    path = os.path.join(PRACTICE_DIR, 'CH002-practice-01.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  PRACTICE 1 SOLUTIONS
# ==================================================================
def practice_01_solutions():
    story = []
    title_block(story,
                "Practice Sheet 1 — Solutions",
                "Step-by-step worked solutions for all 16 questions",
                "Chapter 02 · Algebraic Expressions   |   Use to self-check your work")

    story.append(H1("How to use these solutions"))
    story.append(P(
        "Each solution below shows one clean way of arriving at the answer. "
        "Compare your own working line by line — even if your final answer is "
        "correct, you may spot a quicker method or a sign error you got away "
        "with. The highlighted box at the end of every solution gives the "
        "final answer together with a one-line <i>Concept</i> note explaining "
        "the key idea you should remember."))
    story.append(P(
        "<b>Marking guide.</b>  Each MCQ (Q1–Q4) is worth 1 mark for the "
        "correct option. Each numerical question (Q5–Q10) is worth 2 marks: "
        "1 mark for the correct method and 1 mark for the correct final "
        "answer. Each short-answer question (Q11–Q14) is worth 3 marks: 1 "
        "for setting up, 1 for correct simplification, and 1 for the final "
        "answer. Each word problem (Q15–Q16) is worth 4 marks: 1 for the "
        "algebraic set-up, 2 for the working, and 1 for the correct final "
        "answer with units where applicable."))
    story.append(Spacer(1, 4))

    sols = [
        (1, "Identify the coefficient of x in the term −7xy.",
            ["A term of the form  k·x·y  has coefficient k of xy, and "
             "coefficient (k·y) of x.",
             "So the coefficient of x in  −7xy  is  −7·y  =  −7y.",
             "Among the options, the choice that gives the numerical "
             "coefficient is −7."],
            "<b>(B)  −7</b> || The coefficient is the number multiplying the variable; its sign always travels with it."),
        (2, "Which of the following pairs are like terms?",
            ["Like terms have the same variable part raised to the same "
             "powers.",
             "Option (C):  8p²q  and  −2p²q  both contain p²q — same "
             "letters, same powers."],
            "<b>(C)  8p²q and −2p²q</b> || Only the numerical coefficients may differ; the variable parts must match exactly."),
        (3, "How many terms are there in  4x² − 3xy + y − 7?",
            ["Separate at the +/− signs:  4x²,  −3xy,  +y,  −7.",
             "Counting them gives four terms."],
            "<b>(C)  4</b> || Each + or − sign begins a new term; the sign belongs to that term."),
        (4, "When x = 3, the value of  2x² − x + 4  is:",
            ["Substitute x = 3:  2·(3)² − 3 + 4.",
             "Simplify:  2·9 − 3 + 4 = 18 − 3 + 4 = 19."],
            "<b>(A)  19</b> || Replace every x with the given number in brackets, then apply BODMAS."),
        (5, "If  a = 2  and  b = −3, evaluate  3a² + 2ab − b².",
            ["Substitute:  3·(2)² + 2·2·(−3) − (−3)².",
             "Powers:  3·4 + 2·2·(−3) − 9.",
             "Multiply:  12 + (−12) − 9 = 12 − 12 − 9 = −9."],
            "<b>−9</b> || Always square the negative inside brackets: (−3)² = +9, not −9."),
        (6, "Simplify  7x − 3 + 4x + 8 − 2x.",
            ["Group like terms:  (7x + 4x − 2x) + (−3 + 8).",
             "Combine x's:  9x.   Combine constants:  +5.",
             "Result:  9x + 5."],
            "<b>9x + 5</b> || Only like terms (same variable part) can be combined."),
        (7, "Simplify  5(x + 2) − 3(x − 4).",
            ["Expand:  5x + 10 − 3x + 12.",
             "   (note: −3 × −4 = +12)",
             "Group:  (5x − 3x) + (10 + 12) = 2x + 22."],
            "<b>2x + 22</b> || A minus before a bracket flips the sign of every term inside it."),
        (8, "Simplify  2(3a − b) + 4(a + 2b).",
            ["Expand:  6a − 2b + 4a + 8b.",
             "Group a's:  10a.   Group b's:  6b.",
             "Result:  10a + 6b."],
            "<b>10a + 6b</b> || Multiply the outside number by every term inside the bracket."),
        (9, "Evaluate  4x² − 2x + 1  when  x = −2.",
            ["Substitute:  4·(−2)² − 2·(−2) + 1.",
             "Power:  (−2)² = 4,  so  4·4 − 2·(−2) + 1.",
             "Multiply:  16 + 4 + 1 = 21."],
            "<b>21</b> || Use brackets when substituting a negative value to avoid sign slips."),
        (10, "If  P = x² − 3x + 2  and  Q = x² + 5x − 7, find  P + Q.",
            ["Add term by term:",
             "   (x² + x²) + (−3x + 5x) + (2 − 7)",
             "   = 2x² + 2x − 5."],
            "<b>2x² + 2x − 5</b> || Line up like terms vertically before adding to avoid missing any."),
        (11, "Subtract  (2x² − 5x + 3)  from  (4x² + x − 6).",
            ["Write:  (4x² + x − 6) − (2x² − 5x + 3).",
             "Distribute the minus:  4x² + x − 6 − 2x² + 5x − 3.",
             "Group:  (4x² − 2x²) + (x + 5x) + (−6 − 3).",
             "Combine:  2x² + 6x − 9."],
            "<b>2x² + 6x − 9</b> || 'Subtract A from B' means B − A — keep the order in mind."),
        (12, "Simplify  3(x − 2) − 2(x − 3) + 4(x + 1)  and find its value at x = 1.",
            ["Expand:  3x − 6 − 2x + 6 + 4x + 4.",
             "Group:  (3x − 2x + 4x) + (−6 + 6 + 4) = 5x + 4.",
             "Substitute x = 1:  5·1 + 4 = 9."],
            "<b>Simplified: 5x + 4;  at x = 1, value = 9</b> || Simplify first — substituting before simplifying usually wastes effort."),
        (13, "If  l = 2x + 3  and  b = x − 1, write and simplify the perimeter.",
            ["Perimeter  P = 2(l + b) = 2[(2x + 3) + (x − 1)].",
             "Inside the bracket:  3x + 2.",
             "Multiply by 2:  P = 2·(3x + 2) = 6x + 4."],
            "<b>Perimeter = 6x + 4</b> || Substitute the expressions for l and b before simplifying."),
        (14, "Find  5a − 3b + 2c  when  a = 1, b = −2, c = 4.",
            ["Substitute:  5·1 − 3·(−2) + 2·4.",
             "Multiply:  5 + 6 + 8 = 19."],
            "<b>19</b> || Minus times minus gives plus: −3 × (−2) = +6."),
        (15, "Perimeter of a rectangle with  l = (3x + 2) cm  and  b = (x − 1) cm; evaluate at x = 4.",
            ["Perimeter  P = 2(l + b) = 2[(3x + 2) + (x − 1)].",
             "Inside:  4x + 1.",
             "Multiply by 2:  P = 8x + 2 cm.",
             "At x = 4:  P = 8·4 + 2 = 34 cm."],
            "<b>P = (8x + 2) cm;  at x = 4, P = 34 cm</b> || Remember to carry the units (cm) through the working."),
        (16, "Priya has (5x + 10) marbles; gives (2x − 3) away. Marbles left, at x = 6.",
            ["Marbles left  =  (5x + 10) − (2x − 3).",
             "Distribute the minus:  5x + 10 − 2x + 3.",
             "Combine:  3x + 13.",
             "At x = 6:  3·6 + 13 = 18 + 13 = 31."],
            "<b>3x + 13 marbles;  at x = 6, she has 31 marbles left</b> || 'Gives away' means subtract — flip every sign inside that bracket."),
    ]
    for num, q, steps, final in sols:
        for f in solution(num, q, steps, final):
            story.append(f)

    story.append(H1("Common pitfalls observed in this sheet"))
    story.append(B("Forgetting that a minus before a bracket flips every sign "
                   "inside it (Q7, Q8, Q11, Q16)."))
    story.append(B("Treating (−3)² as −9 instead of +9 (Q5, Q9)."))
    story.append(B("Combining unlike terms such as 5x + 3 = 8x (Q6)."))
    story.append(B("Dropping units (cm, marbles, years) from the final answer "
                   "in word problems (Q13, Q15, Q16)."))
    story.append(B("Substituting into a messy expression instead of simplifying "
                   "first (Q12)."))
    story.append(N(
        "If you lost marks on any of these, revisit the matching worked example "
        "in Study Material 1 (Algebraic Expressions). Mastery is a matter of "
        "deliberate practice — redo the question from scratch until you can "
        "solve it confidently without looking at the solution."))

    path = os.path.join(PRACTICE_DIR, 'CH002-practice-01-solutions.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  PRACTICE SHEET 2  (linear equations, factorisation, identities)
# ==================================================================
def practice_02():
    story = []
    title_block(story,
                "Practice Sheet 2 — Linear Equations, Factorisation & Identities",
                "Linear equations · Factorisation · Algebraic identities · Word problems",
                "Chapter 02 · 16 questions · Easy + Medium   |   Total marks: 40")

    story.append(P("<b>Instructions.</b>  Attempt all questions. Show every line of "
                   "your working. MCQs carry 1 mark, solve/factorise questions "
                   "carry 2–3 marks, and word problems carry 4 marks. A "
                   "separate solutions PDF is available."))
    story.append(Spacer(1, 4))

    # --- Section A: MCQ ---
    story.append(H2("Section A — Multiple Choice  (1 mark each)"))
    for q in question(1, "The solution of  3x − 5 = 16  is:", marks=1):
        story.append(q)
    for o in mcq_options(['x = 5', 'x = 6', 'x = 7', 'x = 8']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(2, "Which value of x satisfies  2x + 7 = x + 12 ?", marks=1):
        story.append(q)
    for o in mcq_options(['3', '4', '5', '6']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(3, "Expanding  (x + 4)²  gives:", marks=1):
        story.append(q)
    for o in mcq_options(['x² + 16', 'x² + 4x + 16', 'x² + 8x + 16',
                          'x² + 8x + 4']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    for q in question(4, "Factorised form of  x² − 36  is:", marks=1):
        story.append(q)
    for o in mcq_options(['(x − 6)²', '(x + 6)(x − 6)', '(x − 6)(x − 6)',
                          '(x + 6)²']): story.append(o)
    story.append(Spacer(1, 3)); story.append(answer_space(1.5)); story.append(Spacer(1, 6))

    # --- Section B: Solve ---
    story.append(H2("Section B — Solve the Linear Equation  (2 marks each)"))
    for q in question(5, "Solve  4x + 9 = 29.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(6, "Solve  5x − 3 = 2x + 12.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(7, "Solve  3(x − 2) = 2(x + 4).", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    for q in question(8, "Solve  (x/2) + (x/3) = 10.", marks=2):
        story.append(q)
    story.append(answer_space(5.0)); story.append(Spacer(1, 6))

    # --- Section C: Factorise ---
    story.append(CondPageBreak(4*cm))
    story.append(H2("Section C — Factorise  (3 marks each)"))
    for q in question(9, "Factorise  6x + 9.", marks=3):
        story.append(q)
    story.append(answer_space(6.0)); story.append(Spacer(1, 6))

    for q in question(10, "Factorise  4a³b − 8a²b² + 12ab.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    for q in question(11, "Factorise using an identity:  9x² + 12x + 4.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    for q in question(12, "Factorise  2x² − 50  completely.", marks=3):
        story.append(q)
    story.append(answer_space(6.5)); story.append(Spacer(1, 6))

    # --- Section D: Use identities / word problems ---
    story.append(H2("Section D — Identities & Word Problems  (4 marks each)"))
    for q in question(13, "Using a suitable identity, evaluate  103².", marks=4):
        story.append(q)
    story.append(answer_space(7.0)); story.append(Spacer(1, 6))

    for q in question(14, "Using a suitable identity, evaluate  55² − 45².", marks=4):
        story.append(q)
    story.append(answer_space(7.0)); story.append(Spacer(1, 6))

    for q in question(15, "The sum of three consecutive integers is 96. Find the "
                          "largest integer (set up an equation and solve).", marks=4):
        story.append(q)
    story.append(answer_space(7.5)); story.append(Spacer(1, 6))

    for q in question(16, "A father is 4 times as old as his son. In 20 years he "
                          "will be twice as old. Find their present ages.", marks=4):
        story.append(q)
    story.append(answer_space(7.5))

    path = os.path.join(PRACTICE_DIR, 'CH002-practice-02.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  PRACTICE 2 SOLUTIONS
# ==================================================================
def practice_02_solutions():
    story = []
    title_block(story,
                "Practice Sheet 2 — Solutions",
                "Step-by-step worked solutions for all 16 questions",
                "Chapter 02 · Linear Equations, Factorisation & Identities")

    sols = [
        (1, "The solution of  3x − 5 = 16  is:",
            ["Add 5 to both sides:  3x = 21.",
             "Divide by 3:  x = 7."],
            "<b>(C)  x = 7</b> || Undo the +/− first, then undo the × / ÷."),
        (2, "Which value of x satisfies  2x + 7 = x + 12 ?",
            ["Subtract x from both sides:  x + 7 = 12.",
             "Subtract 7:  x = 5."],
            "<b>(C)  5</b> || Collect the x-terms on one side and the constants on the other."),
        (3, "Expanding  (x + 4)²  gives:",
            ["Use (a + b)² = a² + 2ab + b² with a = x, b = 4.",
             "   = x² + 2·x·4 + 4² = x² + 8x + 16."],
            "<b>(C)  x² + 8x + 16</b> || Never forget the middle term 2ab when squaring a binomial."),
        (4, "Factorised form of  x² − 36  is:",
            ["x² − 36 = x² − 6² = (x + 6)(x − 6)  (difference of squares)."],
            "<b>(B)  (x + 6)(x − 6)</b> || a² − b² always factorises as (a + b)(a − b); a² + b² does not."),
        (5, "Solve  4x + 9 = 29.",
            ["Subtract 9:  4x = 20.",
             "Divide by 4:  x = 5.",
             "Check:  4·5 + 9 = 29  ✓"],
            "<b>x = 5</b> || Always check by substituting back into the original equation."),
        (6, "Solve  5x − 3 = 2x + 12.",
            ["Subtract 2x:  3x − 3 = 12.",
             "Add 3:  3x = 15.",
             "Divide by 3:  x = 5.",
             "Check:  5·5 − 3 = 22,  2·5 + 12 = 22  ✓"],
            "<b>x = 5</b> || Move the smaller x-term so that the x-coefficient stays positive."),
        (7, "Solve  3(x − 2) = 2(x + 4).",
            ["Expand both sides:  3x − 6 = 2x + 8.",
             "Subtract 2x:  x − 6 = 8.",
             "Add 6:  x = 14.",
             "Check:  3(14 − 2) = 36,  2(14 + 4) = 36  ✓"],
            "<b>x = 14</b> || Expand brackets before you start moving terms between sides."),
        (8, "Solve  (x/2) + (x/3) = 10.",
            ["LCM of 2 and 3 is 6. Multiply every term by 6:",
             "   6·(x/2) + 6·(x/3) = 6·10",
             "   3x + 2x = 60   →   5x = 60.",
             "Divide by 5:  x = 12.",
             "Check:  12/2 + 12/3 = 6 + 4 = 10  ✓"],
            "<b>x = 12</b> || Clear fractions early by multiplying through by the LCM of denominators."),
        (9, "Factorise  6x + 9.",
            ["HCF of 6 and 9 is 3.",
             "Take 3 out:  3(2x + 3)."],
            "<b>3(2x + 3)</b> || Always look for the highest common numerical factor first."),
        (10, "Factorise  4a³b − 8a²b² + 12ab.",
            ["Numerical HCF of 4, 8, 12 is 4.",
             "Variable HCF: a and b in every term, lowest powers a and b.",
             "Common factor = 4ab.",
             "Divide each term by 4ab:  a² − 2ab + 3.",
             "Result:  4ab(a² − 2ab + 3)."],
            "<b>4ab(a² − 2ab + 3)</b> || The common variable part uses the lowest power of each letter present."),
        (11, "Factorise  9x² + 12x + 4.",
            ["Compare with  a² + 2ab + b².",
             "Take a = 3x,  b = 2  (because (3x)² = 9x² and 2² = 4).",
             "Check the middle term:  2·(3x)·2 = 12x  ✓",
             "So  9x² + 12x + 4 = (3x + 2)²."],
            "<b>(3x + 2)²</b> || If first and last terms are perfect squares and the middle term equals ±2ab, use Identity 1 or 2."),
        (12, "Factorise  2x² − 50  completely.",
            ["Take out the common factor 2:  2(x² − 25).",
             "Apply a² − b² inside the bracket:  x² − 25 = (x + 5)(x − 5).",
             "So  2x² − 50 = 2(x + 5)(x − 5)."],
            "<b>2(x + 5)(x − 5)</b> || Remove a common factor first; only then check for an identity."),
        (13, "Using a suitable identity, evaluate  103².",
            ["Write 103 = 100 + 3 and use  (a + b)² = a² + 2ab + b².",
             "   103² = (100 + 3)²",
             "        = 100² + 2·100·3 + 3²",
             "        = 10000 + 600 + 9",
             "        = 10609."],
            "<b>103² = 10609</b> || Pick a, b close to a 'round' number so the arithmetic is mental."),
        (14, "Using a suitable identity, evaluate  55² − 45².",
            ["Use  a² − b² = (a + b)(a − b)  with a = 55, b = 45.",
             "   55² − 45² = (55 + 45)(55 − 45)",
             "             = 100 × 10",
             "             = 1000."],
            "<b>55² − 45² = 1000</b> || For differences of squares, factorising first often beats squaring then subtracting."),
        (15, "Three consecutive integers add up to 96. Find the largest.",
            ["Let the smallest be n. The others are n + 1 and n + 2.",
             "Equation:  n + (n + 1) + (n + 2) = 96.",
             "Simplify:  3n + 3 = 96.",
             "Subtract 3:  3n = 93.",
             "Divide by 3:  n = 31.",
             "Largest = n + 2 = 33."],
            "<b>Largest integer = 33</b> || Define the smallest unknown and build the others from it."),
        (16, "A father is 4 times as old as his son. In 20 years he will be twice as old. Find present ages.",
            ["Let the son's present age be x years. Father's age = 4x.",
             "In 20 years:  son = x + 20,  father = 4x + 20.",
             "Equation:  4x + 20 = 2(x + 20).",
             "Expand:  4x + 20 = 2x + 40.",
             "Subtract 2x:  2x + 20 = 40.",
             "Subtract 20:  2x = 20.",
             "Divide by 2:  x = 10  (son).",
             "Father = 4x = 40."],
            "<b>Son = 10 years;  Father = 40 years</b> || 'In 20 years' means add 20 to both present ages before equating."),
    ]
    for num, q, steps, final in sols:
        for f in solution(num, q, steps, final):
            story.append(f)

    path = os.path.join(PRACTICE_DIR, 'CH002-practice-02-solutions.pdf')
    build_pdf(path, story)
    return path


# ==================================================================
#  Main
# ==================================================================
if __name__ == '__main__':
    print("Generating CH002 Algebra Basics PDFs ...")
    outputs = [
        material_01(),
        material_02(),
        material_03(),
        practice_01(),
        practice_01_solutions(),
        practice_02(),
        practice_02_solutions(),
    ]
    for p in outputs:
        size_kb = os.path.getsize(p) / 1024.0
        print(f"  ✓  {os.path.basename(p)}   ({size_kb:.1f} KB)")
    print("\nAll 7 PDFs generated.")
