#!/usr/bin/env python3
"""
Power Maths Portal — 42-PDF Content Generator
=============================================
Generates 42 real multi-page PDFs (5-6 pages each) covering 6 chapters:
  - 3 Study Materials per chapter  (18 materials)
  - 2 Practice Sheets per chapter  (12 sheets)
  - 2 Solutions PDFs per chapter   (12 solutions)

Output:
  /home/z/my-project/public/materials/CH00X-material-0N-<slug>.pdf
  /home/z/my-project/public/practice/CH00X-practice-0N.pdf
  /home/z/my-project/public/practice/CH00X-practice-0N-solutions.pdf

Each PDF uses ReportLab Platypus with DejaVu Sans (Unicode math symbol
coverage: π √ ² ³ ≤ ≥ × ÷ ° ± ≠ → etc.). Pages have a header band with
chapter name + a footer with page numbers and the "Power Maths by Prof.
Kalpesh Vyas" tagline.
"""

import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak,
    Table, TableStyle, KeepTogether, HRFlowable, ListFlowable, ListItem
)
from reportlab.platypus.flowables import Flowable

# ──────────────────────────────────────────────────────────────────────
# Font registration
# ──────────────────────────────────────────────────────────────────────
FONT_REGULAR = "DejaVuSans"
FONT_BOLD    = "DejaVuSans-Bold"
FONT_ITALIC  = "DejaVuSans-Oblique"  # fallback to regular if not present
FONT_MONO    = "DejaVuSansMono"

pdfmetrics.registerFont(TTFont(FONT_REGULAR, "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont(FONT_BOLD,    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
try:
    pdfmetrics.registerFont(TTFont(FONT_ITALIC, "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf"))
except:
    FONT_ITALIC = FONT_REGULAR
pdfmetrics.registerFont(TTFont(FONT_MONO,    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"))

from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily(FONT_REGULAR, normal=FONT_REGULAR, bold=FONT_BOLD,
                   italic=FONT_ITALIC, boldItalic=FONT_BOLD)

# ──────────────────────────────────────────────────────────────────────
# Color palette (emerald/teal — matches portal theme, NO indigo/blue)
# ──────────────────────────────────────────────────────────────────────
COL_PRIMARY    = colors.HexColor("#0f766e")  # teal-700
COL_PRIMARY_LT = colors.HexColor("#ccfbf1")  # teal-100
COL_ACCENT     = colors.HexColor("#d97706")  # amber-600
COL_ACCENT_LT  = colors.HexColor("#fef3c7")  # amber-100
COL_TEXT       = colors.HexColor("#1f2937")  # gray-800
COL_MUTED      = colors.HexColor("#6b7280")  # gray-500
COL_BG_TINT    = colors.HexColor("#f0fdfa")  # teal-50
COL_BG_AMBER   = colors.HexColor("#fffbeb")  # amber-50
COL_BORDER     = colors.HexColor("#d1d5db")  # gray-300
COL_RULE       = colors.HexColor("#5eead4")  # teal-300

# ──────────────────────────────────────────────────────────────────────
# Page geometry
# ──────────────────────────────────────────────────────────────────────
PAGE_W, PAGE_H = A4
MARGIN_L = 20 * mm
MARGIN_R = 20 * mm
MARGIN_T = 26 * mm   # leave room for header band
MARGIN_B = 22 * mm   # leave room for footer
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R

# ──────────────────────────────────────────────────────────────────────
# Paragraph styles
# ──────────────────────────────────────────────────────────────────────
styles = getSampleStyleSheet()

S_COVER_KICKER = ParagraphStyle("CoverKicker", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=11, textColor=colors.white,
    alignment=TA_LEFT, leading=14, spaceAfter=4)
S_COVER_TITLE = ParagraphStyle("CoverTitle", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=26, textColor=colors.white,
    alignment=TA_LEFT, leading=32, spaceAfter=8)
S_COVER_SUB = ParagraphStyle("CoverSub", parent=styles["Normal"],
    fontName=FONT_REGULAR, fontSize=13, textColor=colors.HexColor("#d1fae5"),
    alignment=TA_LEFT, leading=18, spaceAfter=4)
S_COVER_META = ParagraphStyle("CoverMeta", parent=styles["Normal"],
    fontName=FONT_REGULAR, fontSize=9.5, textColor=colors.HexColor("#a7f3d0"),
    alignment=TA_LEFT, leading=13)

S_H1 = ParagraphStyle("H1", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=17, textColor=COL_PRIMARY,
    leading=22, spaceBefore=2, spaceAfter=8)
S_H2 = ParagraphStyle("H2", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=13, textColor=COL_TEXT,
    leading=18, spaceBefore=10, spaceAfter=5)
S_H3 = ParagraphStyle("H3", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=11, textColor=COL_ACCENT,
    leading=15, spaceBefore=6, spaceAfter=3)
S_BODY = ParagraphStyle("Body", parent=styles["Normal"],
    fontName=FONT_REGULAR, fontSize=10.5, textColor=COL_TEXT,
    leading=15.5, alignment=TA_JUSTIFY, spaceAfter=6)
S_BODY_TIGHT = ParagraphStyle("BodyTight", parent=S_BODY, spaceAfter=3)
S_BULLET = ParagraphStyle("Bullet", parent=S_BODY, leftIndent=14, bulletIndent=2, spaceAfter=3)
S_NOTE = ParagraphStyle("Note", parent=styles["Normal"],
    fontName=FONT_ITALIC, fontSize=9.5, textColor=COL_MUTED,
    leading=13, alignment=TA_LEFT, spaceAfter=4)
S_FORMULA = ParagraphStyle("Formula", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=12, textColor=COL_PRIMARY,
    leading=17, alignment=TA_CENTER, spaceBefore=4, spaceAfter=6,
    backColor=COL_BG_TINT, borderColor=COL_RULE, borderWidth=0.6,
    borderPadding=6, borderRadius=3)
S_EXAMPLE_LABEL = ParagraphStyle("ExLabel", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=10, textColor=COL_ACCENT,
    leading=14, spaceBefore=4, spaceAfter=2)
S_PROB = ParagraphStyle("Problem", parent=styles["Normal"],
    fontName=FONT_REGULAR, fontSize=10.5, textColor=COL_TEXT,
    leading=15, alignment=TA_LEFT, spaceAfter=2)
S_PROB_NUM = ParagraphStyle("ProbNum", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=10.5, textColor=COL_PRIMARY,
    leading=15, alignment=TA_LEFT)
S_SOLN_STEP = ParagraphStyle("SolnStep", parent=styles["Normal"],
    fontName=FONT_REGULAR, fontSize=10, textColor=COL_TEXT,
    leading=14, alignment=TA_LEFT, leftIndent=14, spaceAfter=2)
S_ANSWER = ParagraphStyle("Answer", parent=styles["Normal"],
    fontName=FONT_BOLD, fontSize=10, textColor=COL_PRIMARY,
    leading=14, alignment=TA_LEFT, leftIndent=14, spaceAfter=8)
S_FOOTER_TIP = ParagraphStyle("FooterTip", parent=styles["Normal"],
    fontName=FONT_ITALIC, fontSize=9, textColor=COL_MUTED,
    leading=12, alignment=TA_CENTER, spaceBefore=4)

# ──────────────────────────────────────────────────────────────────────
# Custom flowables
# ──────────────────────────────────────────────────────────────────────
class CoverBand(Flowable):
    """Full-width colored band for the cover page — drawn at top."""
    def __init__(self, chapter_title, doc_title, doc_kind, chapter_num):
        super().__init__()
        self.chapter_title = chapter_title
        self.doc_title = doc_title
        self.doc_kind = doc_kind    # 'Material', 'Practice Sheet', 'Solutions'
        self.chapter_num = chapter_num
        self.width = CONTENT_W
        self.height = 90 * mm
    def draw(self):
        c = self.canv
        # Background gradient effect (two-tone)
        c.setFillColor(COL_PRIMARY)
        c.rect(0, 0, self.width, self.height, fill=1, stroke=0)
        c.setFillColor(colors.HexColor("#0d9488"))  # teal-600
        c.rect(0, self.height - 28*mm, self.width, 28*mm, fill=1, stroke=0)
        # Accent stripe
        c.setFillColor(COL_ACCENT)
        c.rect(0, self.height - 30*mm, self.width, 2*mm, fill=1, stroke=0)
        # Chapter chip (top-left)
        c.setFillColor(colors.white)
        c.setStrokeColor(colors.white)
        c.setLineWidth(0.8)
        c.roundRect(8*mm, self.height - 16*mm, 50*mm, 7*mm, 2*mm, fill=0, stroke=1)
        c.setFont(FONT_BOLD, 8.5)
        c.setFillColor(colors.white)
        c.drawCentredString(33*mm, self.height - 11.5*mm, f"CHAPTER {self.chapter_num}")
        # Doc kind label
        c.setFont(FONT_BOLD, 10)
        c.setFillColor(colors.HexColor("#fef3c7"))
        c.drawString(8*mm, self.height - 28*mm, self.doc_kind.upper())
        # Title
        c.setFont(FONT_BOLD, 22)
        c.setFillColor(colors.white)
        # Wrap title manually if too long
        title = self.doc_title
        if c.stringWidth(title, FONT_BOLD, 22) > self.width - 16*mm:
            # split into two lines
            words = title.split()
            line1, line2 = "", ""
            for w in words:
                if c.stringWidth(line1 + " " + w, FONT_BOLD, 22) < self.width - 16*mm:
                    line1 = (line1 + " " + w).strip()
                else:
                    line2 = (line2 + " " + w).strip()
            c.drawString(8*mm, self.height - 44*mm, line1)
            if line2:
                c.drawString(8*mm, self.height - 54*mm, line2)
        else:
            c.drawString(8*mm, self.height - 44*mm, title)
        # Chapter name (subtitle)
        c.setFont(FONT_REGULAR, 11)
        c.setFillColor(colors.HexColor("#ccfbf1"))
        c.drawString(8*mm, self.height - 66*mm, self.chapter_title)
        # Tagline
        c.setFont(FONT_ITALIC, 9)
        c.setFillColor(colors.HexColor("#a7f3d0"))
        c.drawString(8*mm, self.height - 78*mm, "Power Maths  ·  by Prof. Kalpesh Vyas")
        # Bottom border line
        c.setStrokeColor(COL_ACCENT)
        c.setLineWidth(1.2)
        c.line(0, 0, self.width, 0)


class CalloutBox(Flowable):
    """A coloured callout box for tips / notes / formulas."""
    def __init__(self, title, body_html, kind="tip", width=CONTENT_W):
        super().__init__()
        self.title = title
        self.body_html = body_html
        self.kind = kind
        self.width = width
        if kind == "tip":
            self.bg = COL_BG_TINT
            self.border = COL_PRIMARY
            self.title_col = COL_PRIMARY
        elif kind == "warn":
            self.bg = COL_BG_AMBER
            self.border = COL_ACCENT
            self.title_col = COL_ACCENT
        else:
            self.bg = colors.HexColor("#f9fafb")
            self.border = COL_BORDER
            self.title_col = COL_TEXT
        # Measure body
        self._body_para = Paragraph(body_html, ParagraphStyle("CalloutBody",
            fontName=FONT_REGULAR, fontSize=10, textColor=COL_TEXT,
            leading=14, alignment=TA_LEFT))
        self._title_para = Paragraph(f"<b>{title}</b>", ParagraphStyle("CalloutTitle",
            fontName=FONT_BOLD, fontSize=10, textColor=self.title_col,
            leading=13, alignment=TA_LEFT, spaceAfter=2))
        self._inner_w = width - 12  # 6pt padding each side
        _, th = self._title_para.wrap(self._inner_w, 1000)
        _, bh = self._body_para.wrap(self._inner_w, 1000)
        self.height = th + bh + 14
    def wrap(self, availW, availH):
        return self.width, self.height
    def draw(self):
        c = self.canv
        c.setFillColor(self.bg)
        c.setStrokeColor(self.border)
        c.setLineWidth(0.8)
        c.roundRect(0, 0, self.width, self.height, 3, fill=1, stroke=1)
        # Left accent bar
        c.setFillColor(self.border)
        c.rect(0, 0, 3, self.height, fill=1, stroke=0)
        # Render title + body
        self._title_para.drawOn(c, 8, self.height - 8 - self._title_para.height)
        self._body_para.drawOn(c, 8, 8)


class WorkingSpace(Flowable):
    """Empty lined space for students to write working."""
    def __init__(self, lines=4, width=CONTENT_W):
        super().__init__()
        self.lines = lines
        self.width = width
        self.height = lines * 7 + 4
    def wrap(self, availW, availH):
        return self.width, self.height
    def draw(self):
        c = self.canv
        c.setStrokeColor(colors.HexColor("#e5e7eb"))
        c.setLineWidth(0.4)
        for i in range(self.lines):
            y = self.height - 4 - (i * 7)
            c.line(2, y, self.width - 2, y)


# ──────────────────────────────────────────────────────────────────────
# Page templates (header + footer)
# ──────────────────────────────────────────────────────────────────────
def make_page_decorator(chapter_title, doc_title, doc_kind):
    """Returns an onPage function that draws header + footer on every page."""
    def decorate(canvas, doc):
        canvas.saveState()
        # ── Header band (skip on cover page = page 1) ──
        if doc.page > 1:
            # Top thin rule
            canvas.setStrokeColor(COL_RULE)
            canvas.setLineWidth(0.6)
            canvas.line(MARGIN_L, PAGE_H - 16*mm, PAGE_W - MARGIN_R, PAGE_H - 16*mm)
            # Chapter name (left)
            canvas.setFont(FONT_BOLD, 8.5)
            canvas.setFillColor(COL_PRIMARY)
            canvas.drawString(MARGIN_L, PAGE_H - 13*mm, chapter_title.upper())
            # Doc title (right)
            canvas.setFont(FONT_REGULAR, 8.5)
            canvas.setFillColor(COL_MUTED)
            title_text = doc_title
            if len(title_text) > 60:
                title_text = title_text[:57] + "..."
            canvas.drawRightString(PAGE_W - MARGIN_R, PAGE_H - 13*mm, f"{doc_kind} · {title_text}")
            # Small accent dot
            canvas.setFillColor(COL_ACCENT)
            canvas.circle(PAGE_W/2, PAGE_H - 13.5*mm, 1.2, fill=1, stroke=0)
        # ── Footer (always) ──
        # Bottom rule
        canvas.setStrokeColor(COL_RULE)
        canvas.setLineWidth(0.6)
        canvas.line(MARGIN_L, 14*mm, PAGE_W - MARGIN_R, 14*mm)
        # Tagline (left)
        canvas.setFont(FONT_ITALIC, 8)
        canvas.setFillColor(COL_MUTED)
        canvas.drawString(MARGIN_L, 10*mm, "Power Maths  ·  Prof. Kalpesh Vyas")
        # Page number (right)
        canvas.setFont(FONT_BOLD, 8.5)
        canvas.setFillColor(COL_PRIMARY)
        canvas.drawRightString(PAGE_W - MARGIN_R, 10*mm, f"Page {doc.page}")
        # Center: confidential mark
        canvas.setFont(FONT_REGULAR, 7.5)
        canvas.setFillColor(COL_MUTED)
        canvas.drawCentredString(PAGE_W/2, 10*mm, "© Power Maths Portal — For enrolled students only")
        canvas.restoreState()
    return decorate


# ──────────────────────────────────────────────────────────────────────
# Document builder
# ──────────────────────────────────────────────────────────────────────
def build_pdf(out_path, chapter_title, doc_title, doc_kind, chapter_num, story_builder):
    """Build a single PDF. `story_builder` is a callable(story) that appends
    flowables to the story list (after the cover)."""
    doc = BaseDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
        title=f"{doc_title} — {chapter_title}",
        author="Prof. Kalpesh Vyas",
        subject=f"Power Maths {doc_kind} — {chapter_title}",
        creator="Power Maths Portal",
    )
    frame = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PAGE_H - MARGIN_T - MARGIN_B,
                  id="normal", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    template = PageTemplate(id="main", frames=[frame],
                            onPage=make_page_decorator(chapter_title, doc_title, doc_kind))
    doc.addPageTemplates([template])

    story = []
    # ── Cover page ──
    story.append(CoverBand(chapter_title, doc_title, doc_kind, chapter_num))
    story.append(Spacer(1, 6*mm))
    # Cover body — learning objectives or instructions
    story_builder(story, is_cover=True)
    story.append(PageBreak())
    # ── Body pages ──
    story_builder(story, is_cover=False)

    doc.build(story)


# ──────────────────────────────────────────────────────────────────────
# Content helpers
# ──────────────────────────────────────────────────────────────────────
def H1(text): return Paragraph(text, S_H1)
def H2(text): return Paragraph(text, S_H2)
def H3(text): return Paragraph(text, S_H3)
def P(text): return Paragraph(text, S_BODY)
def Pt(text): return Paragraph(text, S_BODY_TIGHT)
def Note(text): return Paragraph(text, S_NOTE)
def Formula(text): return Paragraph(text, S_FORMULA)
def ExLabel(text): return Paragraph(text, S_EXAMPLE_LABEL)
def Bullets(items):
    return ListFlowable(
        [ListItem(Paragraph(t, S_BULLET), value="•", leftIndent=10) for t in items],
        bulletType="bullet", bulletColor=COL_PRIMARY, leftIndent=14, spaceAfter=6
    )

def problem(num, text, working_lines=3):
    """A numbered practice problem with working space below."""
    tbl = Table(
        [[Paragraph(f"<b>Q{num}.</b>", S_PROB_NUM), Paragraph(text, S_PROB)],
         ["", WorkingSpace(lines=working_lines)]],
        colWidths=[12*mm, CONTENT_W - 12*mm],
    )
    tbl.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING", (0,0), (-1,-1), 2),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    return KeepTogether(tbl)

def problem_compact(num, text):
    """A numbered problem WITHOUT working space (for solutions)."""
    tbl = Table(
        [[Paragraph(f"<b>Q{num}.</b>", S_PROB_NUM), Paragraph(text, S_PROB)]],
        colWidths=[12*mm, CONTENT_W - 12*mm],
    )
    tbl.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING", (0,0), (-1,-1), 2),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    return tbl

def solution_step(text):
    return Paragraph(text, S_SOLN_STEP)

def answer(text):
    return Paragraph(f"<b>Answer:</b> {text}", S_ANSWER)

def objective_list(items):
    """Used on cover page — numbered learning objectives."""
    items_html = "<br/>".join([f"<b>{i+1}.</b>  {it}" for i, it in enumerate(items)])
    return Paragraph(items_html, ParagraphStyle("ObjList",
        fontName=FONT_REGULAR, fontSize=10.5, textColor=COL_TEXT,
        leading=15, alignment=TA_LEFT, leftIndent=4, spaceAfter=4))

def section_break():
    return Spacer(1, 4*mm)


# ──────────────────────────────────────────────────────────────────────
# CONTENT — import from content module
# ──────────────────────────────────────────────────────────────────────
from pdf_content import CONTENT

# ──────────────────────────────────────────────────────────────────────
# Main — generate all 42 PDFs
# ──────────────────────────────────────────────────────────────────────
def main():
    materials_dir = "/home/z/my-project/public/materials"
    practice_dir  = "/home/z/my-project/public/practice"
    os.makedirs(materials_dir, exist_ok=True)
    os.makedirs(practice_dir, exist_ok=True)

    total = 0
    for entry in CONTENT:
        chapter_id = entry["chapter_id"]
        chapter_num = int(chapter_id.replace("CH", ""))
        chapter_title = entry["chapter_title"]
        kind = entry["kind"]      # 'material' | 'practice' | 'solutions'
        index = entry["index"]    # 1, 2, 3
        title = entry["title"]
        slug = entry.get("slug", f"doc-{index}")
        builder = entry["builder"]

        if kind == "material":
            out_path = os.path.join(materials_dir,
                f"{chapter_id}-material-{index:02d}-{slug}.pdf")
            doc_kind = "Study Material"
        elif kind == "practice":
            out_path = os.path.join(practice_dir,
                f"{chapter_id}-practice-{index:02d}.pdf")
            doc_kind = "Practice Sheet"
        elif kind == "solutions":
            out_path = os.path.join(practice_dir,
                f"{chapter_id}-practice-{index:02d}-solutions.pdf")
            doc_kind = "Solutions"
        else:
            raise ValueError(f"Unknown kind: {kind}")

        print(f"  [{total+1:02d}/42] {os.path.basename(out_path)}")
        build_pdf(out_path, chapter_title, title, doc_kind, chapter_num, builder)
        total += 1

    print(f"\n✓ Generated {total} PDFs")
    print(f"  Materials: {materials_dir}")
    print(f"  Practice + Solutions: {practice_dir}")

if __name__ == "__main__":
    main()
