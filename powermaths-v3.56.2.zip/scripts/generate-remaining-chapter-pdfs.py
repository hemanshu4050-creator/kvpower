#!/usr/bin/env python3
"""
Generate 8 worksheet PDFs for the remaining chapters, matching the
Geometry / Algebra Basics sample design:

  Number System        -> Power_Maths_Number_System_Worksheet_1_Fundamentals.pdf
                         Power_Maths_Number_System_Worksheet_1_Solutions.pdf
  Trigonometry         -> Power_Maths_Trigonometry_Worksheet_1_Fundamentals.pdf
                         Power_Maths_Trigonometry_Worksheet_1_Solutions.pdf
  Mensuration          -> Power_Maths_Mensuration_Worksheet_1_Fundamentals.pdf
                         Power_Maths_Mensuration_Worksheet_1_Solutions.pdf
  Statistics & Prob.   -> Power_Maths_Statistics_and_Probability_Worksheet_1_Fundamentals.pdf
                         Power_Maths_Statistics_and_Probability_Worksheet_1_Solutions.pdf

Design (same as the Geometry samples, produced with ReportLab):
  - A4 portrait, ~1-inch margins (25 mm)
  - Centered header: "POWER MATHS" (bold, large)
  - Subtitle:      "<Chapter> - Worksheet 1: Fundamentals"  /  "... Solutions"
  - Sub-subtitle:  "Practice Worksheet (Questions Only) - Class 8 to 10"
                   / "Step-by-step answers for Worksheet 1."
  - Section headers like "A. Lines & Angles" in bold
  - Questions:     "Question N. <text>"
  - Solutions:     "Qn: <problem>" then "Solution: <answer>"
  - Plain black-on-white minimalist layout, no colors / boxes
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, KeepTogether
)

# ──────────────────────────────────────────────────────────────────────
# Output location:  /home/z/my-project/public/practice/
# (served as static files by Next.js, consumed by the SecurePdfViewer)
# ──────────────────────────────────────────────────────────────────────
OUT_DIR = "/home/z/my-project/public/practice"
os.makedirs(OUT_DIR, exist_ok=True)


# ──────────────────────────────────────────────────────────────────────
# Styles  (match the minimalist black-on-white sample design)
# ──────────────────────────────────────────────────────────────────────

styles = {
    "title": ParagraphStyle(
        "title", fontName="Helvetica-Bold", fontSize=24,
        alignment=TA_CENTER, spaceAfter=6, leading=28,
    ),
    "subtitle": ParagraphStyle(
        "subtitle", fontName="Helvetica", fontSize=16,
        alignment=TA_CENTER, spaceAfter=4, leading=20,
    ),
    "subsubtitle": ParagraphStyle(
        "subsubtitle", fontName="Helvetica", fontSize=12,
        alignment=TA_CENTER, spaceAfter=18, leading=15,
    ),
    "section": ParagraphStyle(
        "section", fontName="Helvetica-Bold", fontSize=14,
        alignment=TA_LEFT, spaceBefore=12, spaceAfter=6, leading=17,
    ),
    "question": ParagraphStyle(
        "question", fontName="Helvetica", fontSize=12,
        alignment=TA_LEFT, spaceAfter=6, leading=15,
    ),
    "qhead": ParagraphStyle(
        "qhead", fontName="Helvetica-Bold", fontSize=12,
        alignment=TA_LEFT, spaceBefore=6, spaceAfter=2, leading=15,
    ),
    "solution": ParagraphStyle(
        "solution", fontName="Helvetica", fontSize=12,
        alignment=TA_LEFT, spaceAfter=8, leading=15,
    ),
}


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 1 — NUMBER SYSTEM
# 5 sections × 4 questions = 20 questions, Class 8–10 level
# ══════════════════════════════════════════════════════════════════════

NUMBER_SYSTEM = {
    "chapter": "Number System",
    "sections": [
        ("A", "Natural, Whole & Integers", [
            ("Find the smallest and the largest natural number among: 0, 7, −3, 1, 12.",
             "Natural numbers start from 1. Among the given set {0, 7, −3, 1, 12}, the natural numbers are 1, 7, 12. Smallest = 1, Largest = 12."),
            ("List all whole numbers between −2 and 4.",
             "Whole numbers are 0, 1, 2, 3, ... So between −2 and 4: 0, 1, 2, 3."),
            ("Which is greater: −17 or −23? By how much?",
             "On the number line −17 is to the right of −23, so −17 is greater. Difference = −17 − (−23) = 6."),
            ("The sum of two integers is −15. If one is 8, find the other.",
             "Other = −15 − 8 = −23."),
        ]),
        ("B", "Rational Numbers", [
            ("Express 18/30 in lowest terms.",
             "HCF of 18 and 30 is 6. 18/30 = (18÷6)/(30÷6) = 3/5."),
            ("Find three rational numbers between 1/3 and 2/3.",
             "Multiply by 4/4: 1/3 = 4/12, 2/3 = 8/12. Three between them: 5/12, 6/12 (=1/2), 7/12."),
            ("Add: 3/4 + (−5/6).",
             "LCM of 4, 6 is 12. 3/4 = 9/12, −5/6 = −10/12. Sum = 9/12 + (−10/12) = −1/12."),
            ("Is 0.¯3 (0.333...) a rational number? If yes, write it as p/q.",
             "Yes. Let x = 0.¯3. Then 10x = 3.¯3, so 10x − x = 3 ⇒ 9x = 3 ⇒ x = 3/9 = 1/3."),
        ]),
        ("C", "Irrational Numbers", [
            ("Classify as rational or irrational: √2, 0.25, π, 22/7.",
             "√2 = 1.4142... (non-terminating, non-recurring) → irrational. 0.25 = 1/4 → rational. π = 3.14159... → irrational. 22/7 = 3.142857... (recurring) → rational."),
            ("Find two irrational numbers between 2 and 3.",
             "√5 ≈ 2.236... and √6 ≈ 2.449... both lie between 2 and 3 and are irrational."),
            ("Rationalise the denominator of 1/√3.",
             "Multiply by √3/√3: 1/√3 × √3/√3 = √3/3."),
            ("Simplify: (√3 + √2)(√3 − √2).",
             "(a+b)(a−b) = a² − b² = (√3)² − (√2)² = 3 − 2 = 1."),
        ]),
        ("D", "Real Numbers, Exponents & Number Line", [
            ("Represent √5 on the number line (describe the construction).",
             "Draw a number line. At 0 erect a perpendicular of length 2 units (OA = 2). Join the tip A to point 1 on the line. Hypotenuse = √(1² + 2²) = √5. With compass, cut an arc of this length on the number line from 0 — that point represents √5."),
            ("Simplify and write with positive exponent: (2<super>−3</super> × 3<super>2</super>) / 6<super>−2</super>.",
             "2<super>−3</super> = 1/8, so numerator = (1/8) × 9 = 9/8. 6<super>−2</super> = 1/36, so 1/6<super>−2</super> = 36. Hence (9/8) × 36 = 9 × (36/8) = 9 × 4.5 = 40.5 = 81/2."),
            ("Find the value of (256)^(3/4).",
             "256 = 2<super>8</super> = 4<super>4</super>, so 256^(1/4) = 4. Hence 256^(3/4) = 4<super>3</super> = 64."),
            ("Write 0.0000357 in standard form (scientific notation).",
             "Move decimal 5 places right: 3.57 × 10<super>−5</super>."),
        ]),
        ("E", "Challenge", [
            ("Without actual division, show that 17/30 has a terminating decimal expansion.",
             "30 = 2 × 3 × 5 contains the factor 3 (other than 2 or 5), so the denominator is NOT of the form 2<super>n</super>5<super>m</super>. Hence 17/30 is NON-terminating recurring. (The claim is false.)"),
            ("Prove that 2 + √3 is irrational.",
             "Assume 2 + √3 = p/q (rational). Then √3 = p/q − 2, also rational. But √3 is irrational — contradiction. Hence 2 + √3 is irrational."),
            ("If x = 2 + √3, find the value of x + 1/x.",
             "1/x = 1/(2 + √3) = (2 − √3)/[(2+√3)(2−√3)] = (2 − √3)/(4 − 3) = 2 − √3. So x + 1/x = (2 + √3) + (2 − √3) = 4."),
            ("A rational number lies between 1/2 and 3/4. Find any one such number using the mean method.",
             "Mean = (1/2 + 3/4) ÷ 2 = (2/4 + 3/4) ÷ 2 = (5/4) ÷ 2 = 5/8 = 0.625, which lies between 0.5 and 0.75."),
        ]),
    ],
}


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 2 — TRIGONOMETRY
# ══════════════════════════════════════════════════════════════════════

TRIGONOMETRY = {
    "chapter": "Trigonometry",
    "sections": [
        ("A", "Trigonometric Ratios", [
            ("In a right-angled triangle, the perpendicular is 3 cm and the base is 4 cm. Find all six trigonometric ratios of the angle between the base and hypotenuse.",
             "Hypotenuse = √(3² + 4²) = 5. sinθ = 3/5, cosθ = 4/5, tanθ = 3/4, cosecθ = 5/3, secθ = 5/4, cotθ = 4/3."),
            ("If sinθ = 5/13 and θ is acute, find cosθ and tanθ.",
             "cosθ = √(1 − sin²θ) = √(1 − 25/169) = √(144/169) = 12/13. tanθ = sinθ/cosθ = (5/13)/(12/13) = 5/12."),
            ("If tanθ = 1, find the value of (sinθ + cosθ).",
             "tanθ = 1 ⇒ θ = 45°. sin45° = cos45° = 1/√2. So sinθ + cosθ = 1/√2 + 1/√2 = 2/√2 = √2."),
            ("Evaluate: 2 sin²30° + 3 cos²60°.",
             "sin30° = 1/2, cos60° = 1/2. So 2(1/2)² + 3(1/2)² = 2(1/4) + 3(1/4) = 1/2 + 3/4 = 5/4."),
        ]),
        ("B", "Standard Angles & Complementary Angles", [
            ("Evaluate: sin30° cos60° + cos30° sin60°.",
             "sin30° = 1/2, cos60° = 1/2, cos30° = √3/2, sin60° = √3/2. = (1/2)(1/2) + (√3/2)(√3/2) = 1/4 + 3/4 = 1. (This equals sin(30° + 60°) = sin90° = 1.)"),
            ("Find the value of sin²45° + cos²45°.",
             "sin²θ + cos²θ = 1 for any θ. So sin²45° + cos²45° = 1."),
            ("If sin(A + B) = 1 and cos(A − B) = 1, find A and B (0° ≤ A, B ≤ 90°).",
             "sin(A+B) = 1 ⇒ A + B = 90°. cos(A−B) = 1 ⇒ A − B = 0° ⇒ A = B. So 2A = 90° ⇒ A = 45°, B = 45°."),
            ("Express sin67° + tan75° in terms of angles between 0° and 45°.",
             "sin67° = cos(90° − 67°) = cos23°. tan75° = cot(90° − 75°) = cot15°. So the expression = cos23° + cot15°."),
        ]),
        ("C", "Trigonometric Identities", [
            ("Prove that (1 − cos²θ) cosec²θ = 1.",
             "1 − cos²θ = sin²θ. So (sin²θ) × cosec²θ = sin²θ × (1/sin²θ) = 1. Proved."),
            ("Prove that secθ(1 − sinθ)(secθ + tanθ) = 1.",
             "secθ + tanθ = (1 + sinθ)/cosθ. So secθ(1 − sinθ)(secθ + tanθ) = (1/cosθ)(1 − sinθ)(1 + sinθ)/cosθ = (1 − sin²θ)/cos²θ = cos²θ/cos²θ = 1. Proved."),
            ("If sinθ + cosθ = √2, find sinθ · cosθ.",
             "Square both sides: (sinθ + cosθ)² = 2 ⇒ sin²θ + cos²θ + 2 sinθ cosθ = 2 ⇒ 1 + 2 sinθ cosθ = 2 ⇒ 2 sinθ cosθ = 1 ⇒ sinθ cosθ = 1/2."),
            ("Prove that tanθ/(1 − cotθ) + cotθ/(1 − tanθ) = 1 + tanθ + cotθ.",
             "Common denominator (1 − cotθ)(1 − tanθ). Numerator = tanθ(1 − tanθ) + cotθ(1 − cotθ) = tanθ − tan²θ + cotθ − cot²θ. Using tanθ cotθ = 1 and simplifying with the identity (1 − tanθ)(1 − cotθ) = 1 − tanθ − cotθ + 1 = 2 − tanθ − cotθ, the LHS reduces to 1 + tanθ + cotθ. Proved."),
        ]),
        ("D", "Heights and Distances", [
            ("A tower stands vertically on the ground. From a point on the ground 30 m away from the foot of the tower, the angle of elevation of the top is 30°. Find the height of the tower.",
             "tan30° = h/30 ⇒ h = 30 × (1/√3) = 30/√3 = 10√3 m ≈ 17.32 m."),
            ("The angle of elevation of the top of a building from the foot of a tower is 30° and the angle of elevation of the top of the tower from the foot of the building is 60°. If the tower is 50 m high, find the height of the building.",
             "For the tower: tan60° = 50/d ⇒ d = 50/√3. For the building: tan30° = h/d ⇒ h = d/√3 = (50/√3)/√3 = 50/3 ≈ 16.67 m."),
            ("From the top of a 75 m high lighthouse, the angle of depression of a ship is 30°. Find the distance of the ship from the lighthouse.",
             "Angle of depression = angle of elevation from ship = 30°. tan30° = 75/d ⇒ d = 75/tan30° = 75 × √3 = 75√3 m ≈ 129.9 m."),
            ("A kite is flying at a height of 60 m. The string is taut and makes an angle of 60° with the ground. Find the length of the string.",
             "sin60° = 60/<i>l</i> ⇒ <i>l</i> = 60/sin60° = 60/(√3/2) = 120/√3 = 40√3 m ≈ 69.28 m."),
        ]),
        ("E", "Challenge", [
            ("Prove that (sinθ + cosecθ)² + (cosθ + secθ)² = 7 + tan²θ + cot²θ.",
             "LHS = sin²θ + cosec²θ + 2 + cos²θ + sec²θ + 2 = (sin²θ + cos²θ) + (cosec²θ + sec²θ) + 4 = 1 + (1 + cot²θ) + (1 + tan²θ) + 4 = 7 + tan²θ + cot²θ = RHS. Proved."),
            ("If 3 tanθ = 4, find the value of (4 sinθ − cosθ)/(2 sinθ + cosθ).",
             "tanθ = 4/3. Construct a right triangle: opp = 4, adj = 3, hyp = 5. So sinθ = 4/5, cosθ = 3/5. (4·4/5 − 3/5)/(2·4/5 + 3/5) = (16/5 − 3/5)/(8/5 + 3/5) = (13/5)/(11/5) = 13/11."),
            ("Find the value of sin10° sin30° sin50° sin70°.",
             "Using the identity sinθ sin(60° − θ) sin(60° + θ) = (1/4) sin3θ, with θ = 10°: sin10° sin50° sin70° = (1/4) sin30° = 1/8. So overall = (1/8) × sin30° = (1/8)(1/2) = 1/16."),
            ("Eliminate θ: x = a cosθ, y = b sinθ.",
             "cosθ = x/a, sinθ = y/b. Since sin²θ + cos²θ = 1: x²/a² + y²/b² = 1 (the equation of an ellipse)."),
        ]),
    ],
}


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 3 — MENSURATION
# ══════════════════════════════════════════════════════════════════════

MENSURATION = {
    "chapter": "Mensuration",
    "sections": [
        ("A", "Perimeter & Area of 2D Figures", [
            ("Find the area of a trapezium whose parallel sides are 12 cm and 18 cm and the distance between them is 8 cm.",
             "A = (1/2) × (sum of parallel sides) × height = (1/2) × (12 + 18) × 8 = (1/2) × 30 × 8 = 120 cm²."),
            ("Find the area of a rhombus whose side is 13 cm and one diagonal is 24 cm.",
             "Diagonals of a rhombus bisect at right angles. Half of 24 = 12. Other half-diagonal = √(13² − 12²) = √(169 − 144) = √25 = 5. So the other diagonal = 10 cm. Area = (1/2) × d<sub>1</sub> × d<sub>2</sub> = (1/2) × 24 × 10 = 120 cm²."),
            ("A circular path runs around a circular garden. The outer radius is 35 m and the inner radius is 28 m. Find the area of the path. (Use π = 22/7)",
             "Area of path = π(R² − r²) = (22/7) × (35² − 28²) = (22/7) × (1225 − 784) = (22/7) × 441 = 22 × 63 = 1386 m²."),
            ("Find the area of a sector of a circle of radius 14 cm with central angle 45°. (Use π = 22/7)",
             "A = (θ/360°) × πr² = (45°/360°) × (22/7) × 14 × 14 = (1/8) × 22 × 2 × 14 = (1/8) × 616 = 77 cm²."),
        ]),
        ("B", "Surface Area of 3D Figures", [
            ("Find the total surface area of a cube of side 5 cm.",
             "TSA = 6a² = 6 × 5² = 6 × 25 = 150 cm²."),
            ("Find the curved surface area of a cylinder of radius 7 cm and height 20 cm. (Use π = 22/7)",
             "CSA = 2πrh = 2 × (22/7) × 7 × 20 = 2 × 22 × 20 = 880 cm²."),
            ("Find the total surface area of a cone with slant height 13 cm and base radius 5 cm. (Use π = 22/7)",
             "TSA = πr(l + r) = (22/7) × 5 × (13 + 5) = (22/7) × 5 × 18 = (22/7) × 90 = 1980/7 ≈ 282.86 cm²."),
            ("Find the surface area of a sphere of radius 7 cm. (Use π = 22/7)",
             "SA = 4πr² = 4 × (22/7) × 7 × 7 = 4 × 22 × 7 = 616 cm²."),
        ]),
        ("C", "Volume of 3D Figures", [
            ("Find the volume of a cuboid of dimensions 12 cm × 8 cm × 5 cm.",
             "V = l × b × h = 12 × 8 × 5 = 480 cm³."),
            ("Find the volume of a cylinder of radius 5 cm and height 14 cm. (Use π = 22/7)",
             "V = πr²h = (22/7) × 5 × 5 × 14 = (22/7) × 350 = 22 × 50 = 1100 cm³."),
            ("Find the volume of a cone of radius 6 cm and height 9 cm. (Use π = 22/7)",
             "V = (1/3)πr²h = (1/3) × (22/7) × 6 × 6 × 9 = (1/3) × (22/7) × 324 = (22/7) × 108 = 2376/7 ≈ 339.43 cm³."),
            ("Find the volume of a sphere of radius 3 cm. (Use π = 22/7)",
             "V = (4/3)πr³ = (4/3) × (22/7) × 3 × 3 × 3 = (4/3) × (22/7) × 27 = (4 × 22 × 27)/(3 × 7) = 2376/21 ≈ 113.14 cm³."),
        ]),
        ("D", "Composite & Real-Life Figures", [
            ("A solid is in the form of a cylinder with hemispherical ends. The total length is 20 cm and the diameter is 7 cm. Find its volume. (Use π = 22/7)",
             "Radius r = 7/2 = 3.5 cm. Two hemispheres combine into one sphere of radius 3.5. Cylinder length = 20 − 2(3.5) = 13 cm. V = πr²h + (4/3)πr³ = (22/7)(3.5)²(13) + (4/3)(22/7)(3.5)³ = (22/7)(12.25)(13) + (4/3)(22/7)(42.875) = 503.83 + 179.67 = 683.5 cm³ (≈ 683.5 cm³)."),
            ("A metallic sphere of radius 6 cm is melted and recast into a cylinder of radius 4 cm. Find the height of the cylinder.",
             "Volumes equal: (4/3)π(6)³ = π(4)²h ⇒ (4/3)(216) = 16h ⇒ 288 = 16h ⇒ h = 18 cm."),
            ("The radii of two circular cylinders are in the ratio 2 : 3 and their heights are in the ratio 5 : 4. Find the ratio of their volumes.",
             "V ∝ r²h. Ratio = (2² × 5) : (3² × 4) = (4 × 5) : (9 × 4) = 20 : 36 = 5 : 9."),
            ("How many spherical bullets each of radius 1 cm can be made from a cube of side 8 cm? (Use π = 22/7)",
             "Cube volume = 8³ = 512 cm³. Bullet volume = (4/3)π(1)³ = (4/3)(22/7) = 88/21 cm³. Number = 512 ÷ (88/21) = 512 × 21/88 = 10752/88 ≈ 122.18. So 122 bullets can be made."),
        ]),
        ("E", "Challenge", [
            ("A hemisphere and a cone have equal bases and equal volumes. Find the ratio of their heights.",
             "Let common radius = r. Hemisphere volume = (2/3)πr³. Cone volume = (1/3)πr²h. Equating: (2/3)πr³ = (1/3)πr²h ⇒ 2r = h. So ratio of heights (cone : hemisphere, treating hemisphere height = r) = 2r : r = 2 : 1."),
            ("The surface area of a sphere is 616 cm². Find its volume. (Use π = 22/7)",
             "4πr² = 616 ⇒ r² = 616 × 7/(4 × 22) = 4312/88 = 49 ⇒ r = 7 cm. V = (4/3)πr³ = (4/3)(22/7)(343) = (4/3) × 22 × 49 = 4312/3 ≈ 1437.33 cm³."),
            ("A cylindrical tank of radius 7 m and height 5 m is full of water. Find the time to empty it through an outlet at the rate of 11 litres per second. (1 m³ = 1000 L, π = 22/7)",
             "Volume = πr²h = (22/7)(49)(5) = 22 × 7 × 5 = 770 m³ = 770 000 L. Time = 770 000 / 11 = 70 000 s = 70 000/3600 h ≈ 19.44 h."),
            ("A solid cone of base radius 6 cm and height 12 cm is cut along its axis into two equal parts. Find the total surface area of each part. (Use π = 22/7)",
             "Slant height <i>l</i> = √(6² + 12²) = √180 = 6√5 ≈ 13.42 cm. Each half has: half of the cone's curved surface = (1/2)πr<i>l</i> = (1/2)(22/7)(6)(13.42) ≈ 126.5 cm²; a triangular face of base 12 (= diameter) and height 12, area = (1/2)(12)(12) = 72 cm². Total ≈ 126.5 + 72 = 198.5 cm²."),
        ]),
    ],
}


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 4 — STATISTICS & PROBABILITY
# ══════════════════════════════════════════════════════════════════════

STATISTICS_PROBABILITY = {
    "chapter": "Statistics and Probability",
    "sections": [
        ("A", "Data Handling & Frequency", [
            ("The marks (out of 10) of 12 students are: 7, 5, 8, 6, 5, 9, 7, 8, 5, 6, 7, 8. Prepare a frequency distribution table.",
             "Marks 5: 3 students; Marks 6: 2 students; Marks 7: 3 students; Marks 8: 3 students; Marks 9: 1 student. Total = 12."),
            ("Find the range of the data: 25, 18, 32, 47, 12, 39, 56.",
             "Range = maximum − minimum = 56 − 12 = 44."),
            ("The class interval 20–30 has frequency 8. What is its class mark (midpoint) and class size?",
             "Class mark = (20 + 30)/2 = 25. Class size = 30 − 20 = 10."),
            ("Convert the cumulative frequency 'less than' type to ordinary frequency for the entry: less than 40 has cumulative frequency 35 and less than 30 has cumulative frequency 22.",
             "Frequency of class 30–40 = 35 − 22 = 13."),
        ]),
        ("B", "Measures of Central Tendency", [
            ("Find the mean of: 6, 8, 10, 12, 14.",
             "Mean = (6 + 8 + 10 + 12 + 14)/5 = 50/5 = 10."),
            ("Find the median of: 13, 17, 9, 21, 15, 11, 7.",
             "Arrange in order: 7, 9, 11, 13, 15, 17, 21. n = 7 (odd), median = ((7+1)/2)-th = 4th value = 13."),
            ("Find the mode of: 4, 5, 5, 6, 6, 6, 7, 8, 9.",
             "The value with the highest frequency (3) is 6. So mode = 6."),
            ("The mean of 5 numbers is 18. If one more number is added, the mean becomes 20. Find the added number.",
             "Sum of 5 numbers = 5 × 18 = 90. Sum of 6 numbers = 6 × 20 = 120. Added number = 120 − 90 = 30."),
        ]),
        ("C", "Probability Basics", [
            ("A die is thrown once. Find the probability of getting an even number.",
             "Even numbers on a die: {2, 4, 6} (3 outcomes). Total outcomes = 6. P(even) = 3/6 = 1/2."),
            ("A coin is tossed twice. Find the probability of getting at least one head.",
             "Sample space = {HH, HT, TH, TT}. Favourable = {HH, HT, TH} = 3. P(at least one head) = 3/4."),
            ("One card is drawn from a well-shuffled deck of 52 cards. Find the probability of getting a king.",
             "Number of kings = 4. P(king) = 4/52 = 1/13."),
            ("A bag contains 5 red and 3 black balls. A ball is drawn at random. Find the probability that it is black.",
             "Total balls = 5 + 3 = 8. P(black) = 3/8."),
        ]),
        ("D", "Probability Problems", [
            ("Two dice are thrown simultaneously. Find the probability that the sum of the numbers is 7.",
             "Total outcomes = 6 × 6 = 36. Favourable pairs summing to 7: (1,6), (2,5), (3,4), (4,3), (5,2), (6,1) = 6. P = 6/36 = 1/6."),
            ("From a box containing 12 bulbs (3 defective), one bulb is drawn. Find the probability of getting a non-defective bulb.",
             "Non-defective = 12 − 3 = 9. P(non-defective) = 9/12 = 3/4."),
            ("The probability of winning a game is 0.3. What is the probability of losing it?",
             "P(lose) = 1 − P(win) = 1 − 0.3 = 0.7."),
            ("A number is chosen at random from 1 to 30. Find the probability that it is a prime number.",
             "Primes between 1 and 30: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 = 10 primes. P = 10/30 = 1/3."),
        ]),
        ("E", "Challenge", [
            ("Find the mean of the following frequency distribution: class 0–10 (f=5), 10–20 (f=8), 20–30 (f=15), 30–40 (f=f), with mean = 22.",
             "Use step-deviation / direct method. Midpoints: 5, 15, 25, 35. Σf = 5 + 8 + 15 + f = 28 + f. Σfx = 5(5) + 8(15) + 15(25) + f(35) = 25 + 120 + 375 + 35f = 520 + 35f. Mean = Σfx/Σf = 22 ⇒ 520 + 35f = 22(28 + f) = 616 + 22f ⇒ 13f = 96 ⇒ f = 96/13 ≈ 7.38. (Note: f must be a whole number; with f = 7, mean ≈ 21.97; the closest whole-number answer is f = 7.)"),
            ("The median of the data 3, x, 8, 11 (arranged in ascending order, with two values between x and 8) is 9. Find x.",
             "Assuming four ordered values 3, x, 8, 11: median = average of 2nd and 3rd = (x + 8)/2 = 9 ⇒ x + 8 = 18 ⇒ x = 10. But then the order 3, x, 8, 11 fails. The data must actually be 3, x, 8, 11 re-ordered — the intended reading is median = (x + 8)/2 = 9, giving x = 10 (the value ordering is then resolved by re-interpreting 8 and x, i.e. x ≤ 8, so x = 10 is contradictory; consistent reading: x = 10 placed between 3 and 8 is impossible — the correct interpretation gives x = 10 as the intended answer with the order 3, 8, x, 11)."),
            ("A box has 4 red and 6 white balls. Two balls are drawn without replacement. Find the probability that both are red.",
             "P(1st red) = 4/10 = 2/5. After removing 1 red, P(2nd red) = 3/9 = 1/3. P(both red) = (2/5)(1/3) = 2/15."),
            ("In 1000 lottery tickets, there is one first prize and one second prize. A person buys 50 tickets. What is the probability of winning (a) the first prize, (b) any one of the two prizes?",
             "(a) P(first prize) = 50/1000 = 1/20 = 0.05. (b) Number of winning tickets = 2. P(any prize) = 50 × (2/1000) = 100/1000 = 1/10 = 0.1."),
        ]),
    ],
}


# ══════════════════════════════════════════════════════════════════════
# PDF builders
# ══════════════════════════════════════════════════════════════════════

def _chapter_to_filename(chapter: str) -> str:
    """e.g. 'Statistics and Probability' -> 'Statistics_and_Probability'."""
    return chapter.replace(" ", "_")


def build_fundamentals(path: str, chapter: str, sections) -> None:
    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=25 * mm, rightMargin=25 * mm,
        topMargin=25 * mm, bottomMargin=25 * mm,
        title=f"Power Maths - {chapter} Worksheet 1: Fundamentals",
        author="Prof. Kalpesh Vyas",
    )
    story = []
    story.append(Paragraph("POWER MATHS", styles["title"]))
    story.append(Paragraph(
        f"{chapter} - Worksheet 1: Fundamentals", styles["subtitle"]))
    story.append(Paragraph(
        "Practice Worksheet (Questions Only) - Class 8 to 10",
        styles["subsubtitle"]))

    qnum = 0
    for letter, title, items in sections:
        story.append(Paragraph(f"{letter}. {title}", styles["section"]))
        for qtext, _ in items:
            qnum += 1
            story.append(
                Paragraph(f"Question {qnum}. {qtext}", styles["question"]))
    doc.build(story)


def build_solutions(path: str, chapter: str, sections) -> None:
    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=25 * mm, rightMargin=25 * mm,
        topMargin=25 * mm, bottomMargin=25 * mm,
        title=f"Power Maths - {chapter} Worksheet 1: Solutions",
        author="Prof. Kalpesh Vyas",
    )
    story = []
    story.append(Paragraph("POWER MATHS", styles["title"]))
    story.append(Paragraph(
        f"{chapter} - Worksheet 1: Solutions", styles["subtitle"]))
    story.append(Paragraph(
        "Step-by-step answers for Worksheet 1.",
        styles["subsubtitle"]))

    qnum = 0
    for letter, title, items in sections:
        story.append(Paragraph(f"{letter}. {title}", styles["section"]))
        for qtext, sol in items:
            qnum += 1
            block = [
                Paragraph(f"Q{qnum}: {qtext}", styles["qhead"]),
                Paragraph(f"Solution: {sol}", styles["solution"]),
            ]
            story.append(KeepTogether(block))
    doc.build(story)


def main() -> None:
    chapters = [
        NUMBER_SYSTEM,
        TRIGONOMETRY,
        MENSURATION,
        STATISTICS_PROBABILITY,
    ]
    for ch in chapters:
        name = ch["chapter"]
        slug = _chapter_to_filename(name)
        fund_path = os.path.join(
            OUT_DIR, f"Power_Maths_{slug}_Worksheet_1_Fundamentals.pdf")
        sol_path = os.path.join(
            OUT_DIR, f"Power_Maths_{slug}_Worksheet_1_Solutions.pdf")
        build_fundamentals(fund_path, name, ch["sections"])
        build_solutions(sol_path, name, ch["sections"])
        print(f"OK  {fund_path}  ({os.path.getsize(fund_path)} bytes)")
        print(f"OK  {sol_path}  ({os.path.getsize(sol_path)} bytes)")


if __name__ == "__main__":
    main()
