#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen-ch006-pdfs.py
=================
Generate 7 educational PDFs for the "Statistics & Probability" chapter
(CH006) of the Power Maths portal by Prof. Kalpesh Vyas.

Outputs (A4, 5-6 pages each, ReportLab):
  public/materials/CH006-material-01-statistics-basics.pdf
  public/materials/CH006-material-02-graphical-representation.pdf
  public/materials/CH006-material-03-probability.pdf
  public/practice/CH006-practice-01.pdf
  public/practice/CH006-practice-01-solutions.pdf
  public/practice/CH006-practice-02.pdf
  public/practice/CH006-practice-02-solutions.pdf
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, KeepTogether, PageBreak, ListFlowable, ListItem,
    HRFlowable, Flowable
)
from reportlab.pdfgen import canvas as canvasmod

# ----------------------------------------------------------------------
# PATHS & GLOBALS
# ----------------------------------------------------------------------
ROOT      = "/home/z/my-project"
MAT_DIR   = os.path.join(ROOT, "public", "materials")
PRAC_DIR  = os.path.join(ROOT, "public", "practice")
SCRIPT_DIR= os.path.join(ROOT, "scripts")
for d in (MAT_DIR, PRAC_DIR, SCRIPT_DIR):
    os.makedirs(d, exist_ok=True)

PAGE_W, PAGE_H = A4                       # 595.27 x 841.89
MARGIN_L = 18 * mm
MARGIN_R = 18 * mm
MARGIN_T = 26 * mm                        # leave room for header band
MARGIN_B = 18 * mm                        # leave room for footer

# Colour palette — dark slate / teal / emerald (NO blue / indigo)
C_SLATE_DARK = colors.HexColor("#0f172a")  # slate-900
C_SLATE      = colors.HexColor("#1e293b")  # slate-800
C_SLATE_MID  = colors.HexColor("#334155")  # slate-700
C_SLATE_LITE = colors.HexColor("#64748b")  # slate-500
C_RULE       = colors.HexColor("#cbd5e1")  # slate-300
C_BG_SOFT    = colors.HexColor("#f1f5f9")  # slate-100
C_BG_BOX     = colors.HexColor("#f8fafc")  # slate-50
C_TEAL_DARK  = colors.HexColor("#115e59")  # teal-800
C_TEAL       = colors.HexColor("#0f766e")  # teal-700
C_TEAL_MID   = colors.HexColor("#14b8a6")  # teal-500
C_EMERALD_DK = colors.HexColor("#064e3b")  # emerald-900
C_EMERALD    = colors.HexColor("#047857")  # emerald-700
C_EMERALD_LT = colors.HexColor("#d1fae5")  # emerald-100
C_AMBER      = colors.HexColor("#b45309")  # amber-700
C_ANS_LINE   = colors.HexColor("#94a3b8")  # slate-400

# ----------------------------------------------------------------------
# STYLES
# ----------------------------------------------------------------------
def build_styles():
    ss = getSampleStyleSheet()
    base = ParagraphStyle(
        "Body",
        parent=ss["Normal"],
        fontName="Helvetica",
        fontSize=11,
        leading=16.5,                 # ~1.5 line spacing
        textColor=C_SLATE_DARK,
        alignment=TA_JUSTIFY,
        spaceAfter=6,
    )
    styles = {
        "body": base,
        "body_left": ParagraphStyle("BodyLeft", parent=base, alignment=TA_LEFT),
        "body_center": ParagraphStyle("BodyCenter", parent=base, alignment=TA_CENTER),
        "h1": ParagraphStyle(
            "H1", parent=base, fontName="Helvetica-Bold", fontSize=20,
            leading=24, textColor=C_TEAL_DARK, alignment=TA_LEFT,
            spaceBefore=4, spaceAfter=2,
        ),
        "h1_sub": ParagraphStyle(
            "H1Sub", parent=base, fontName="Helvetica-Oblique", fontSize=12,
            leading=16, textColor=C_SLATE_MID, alignment=TA_LEFT,
            spaceBefore=0, spaceAfter=4,
        ),
        "h2": ParagraphStyle(
            "H2", parent=base, fontName="Helvetica-Bold", fontSize=14,
            leading=18, textColor=C_TEAL, alignment=TA_LEFT,
            spaceBefore=12, spaceAfter=4,
        ),
        "h3": ParagraphStyle(
            "H3", parent=base, fontName="Helvetica-Bold", fontSize=12,
            leading=16, textColor=C_EMERALD, alignment=TA_LEFT,
            spaceBefore=8, spaceAfter=2,
        ),
        "example_title": ParagraphStyle(
            "ExTitle", parent=base, fontName="Helvetica-Bold", fontSize=11.5,
            leading=15, textColor=C_TEAL_DARK, spaceBefore=2, spaceAfter=2,
        ),
        "example_body": ParagraphStyle(
            "ExBody", parent=base, fontName="Helvetica", fontSize=10.5,
            leading=15, textColor=C_SLATE, alignment=TA_LEFT, spaceAfter=3,
        ),
        "answer": ParagraphStyle(
            "Ans", parent=base, fontName="Helvetica-Bold", fontSize=11,
            leading=15, textColor=C_EMERALD_DK, alignment=TA_LEFT,
            spaceBefore=2, spaceAfter=2,
        ),
        "qnum": ParagraphStyle(
            "QNum", parent=base, fontName="Helvetica-Bold", fontSize=11.5,
            leading=15, textColor=C_TEAL_DARK, spaceBefore=4, spaceAfter=2,
        ),
        "qbody": ParagraphStyle(
            "QBody", parent=base, fontName="Helvetica", fontSize=11,
            leading=15.5, textColor=C_SLATE_DARK, alignment=TA_LEFT, spaceAfter=2,
        ),
        "qchoice": ParagraphStyle(
            "QChoice", parent=base, fontName="Helvetica", fontSize=10.5,
            leading=14, textColor=C_SLATE, alignment=TA_LEFT,
            leftIndent=18, spaceAfter=1,
        ),
        "sol_step": ParagraphStyle(
            "SolStep", parent=base, fontName="Helvetica", fontSize=10.5,
            leading=15, textColor=C_SLATE_DARK, alignment=TA_LEFT, spaceAfter=3,
        ),
        "sol_q": ParagraphStyle(
            "SolQ", parent=base, fontName="Helvetica-Bold", fontSize=11.5,
            leading=15, textColor=C_TEAL_DARK, spaceBefore=6, spaceAfter=2,
        ),
        "table_h": ParagraphStyle(
            "TableH", parent=base, fontName="Helvetica-Bold", fontSize=10.5,
            leading=13, textColor=colors.white, alignment=TA_CENTER, spaceAfter=0,
        ),
        "table_c": ParagraphStyle(
            "TableC", parent=base, fontName="Helvetica", fontSize=10.5,
            leading=13, textColor=C_SLATE_DARK, alignment=TA_CENTER, spaceAfter=0,
        ),
        "table_l": ParagraphStyle(
            "TableL", parent=base, fontName="Helvetica", fontSize=10.5,
            leading=13, textColor=C_SLATE_DARK, alignment=TA_LEFT, spaceAfter=0,
        ),
        "footer_note": ParagraphStyle(
            "FooterNote", parent=base, fontName="Helvetica-Oblique", fontSize=9.5,
            leading=12, textColor=C_SLATE_MID, alignment=TA_CENTER,
        ),
        "callout": ParagraphStyle(
            "Callout", parent=base, fontName="Helvetica-Oblique", fontSize=10.5,
            leading=15, textColor=C_EMERALD_DK, alignment=TA_LEFT, spaceAfter=4,
        ),
    }
    return styles

STYLES = build_styles()

# ----------------------------------------------------------------------
# HEADER / FOOTER (canvas callback)
# ----------------------------------------------------------------------
class HeaderFooter:
    """Draw header band + footer on every page."""
    def __init__(self, chapter_label, doc_title):
        self.chapter_label = chapter_label
        self.doc_title = doc_title

    def __call__(self, canv, doc):
        canv.saveState()
        # ---- Header band ----
        band_h = 16 * mm
        band_y = PAGE_H - band_h
        # soft slate background
        canv.setFillColor(C_BG_SOFT)
        canv.rect(0, band_y, PAGE_W, band_h, fill=1, stroke=0)
        # thin teal accent under band
        canv.setFillColor(C_TEAL)
        canv.rect(0, band_y - 1.2, PAGE_W, 1.2, fill=1, stroke=0)

        # Left: brand
        canv.setFillColor(C_TEAL_DARK)
        canv.setFont("Helvetica-Bold", 10.5)
        canv.drawString(MARGIN_L, band_y + 5.2*mm, "Power Maths")
        canv.setFillColor(C_SLATE_MID)
        canv.setFont("Helvetica", 9)
        canv.drawString(MARGIN_L, band_y + 1.6*mm, "Statistics & Probability  ·  by Prof. Kalpesh Vyas")

        # Right: chapter + doc title
        canv.setFillColor(C_EMERALD)
        canv.setFont("Helvetica-Bold", 9.5)
        canv.drawRightString(PAGE_W - MARGIN_R, band_y + 5.2*mm, self.chapter_label)
        canv.setFillColor(C_SLATE_MID)
        canv.setFont("Helvetica", 9)
        canv.drawRightString(PAGE_W - MARGIN_R, band_y + 1.6*mm, self.doc_title)

        # ---- Footer band ----
        foot_y = 10 * mm
        canv.setFillColor(C_BG_SOFT)
        canv.rect(0, 0, PAGE_W, foot_y, fill=1, stroke=0)
        canv.setFillColor(C_TEAL)
        canv.rect(0, foot_y, PAGE_W, 1.0, fill=1, stroke=0)

        canv.setFillColor(C_SLATE_MID)
        canv.setFont("Helvetica-Oblique", 8.5)
        canv.drawString(MARGIN_L, 4.0*mm,
                        "© Power Maths · Prof. Kalpesh Vyas · For enrolled students only")
        canv.setFont("Helvetica-Bold", 8.5)
        canv.setFillColor(C_TEAL_DARK)
        total = getattr(doc, "_total_pages", None)
        if total is None:
            page_str = "Page %d" % doc.page
        else:
            page_str = "Page %d of %d" % (doc.page, total)
        canv.drawRightString(PAGE_W - MARGIN_R, 4.0*mm, page_str)
        canv.restoreState()


class CountingDoc(BaseDocTemplate):
    """BaseDocTemplate that counts total pages for 'Page X of Y' footer."""
    def __init__(self, *args, **kwargs):
        BaseDocTemplate.__init__(self, *args, **kwargs)
        self._total_pages = "?"

    def multi_build(self, story, **kwargs):
        # First build to count pages
        BaseDocTemplate.multi_build(self, story, **kwargs)
        # platypus multi_build doesn't return page count directly,
        # so we re-set via canvas after first pass through _pageRefs
        # Use canvs via afterPage hook trick:
        # Actually we will rely on the build() page count via doc.page after first pass.
        # BaseDocTemplate.multi_build already loops until stable, but our Y is unknown
        # in the first pass. So we set _total_pages after the last pass:
        # (BaseDocTemplate sets self.page to the last page number built.)
        return self.page


# We'll use a two-pass approach below.

def make_doc(path, chapter_label, doc_title, total_pages=None):
    """Create a BaseDocTemplate with header/footer wired up."""
    doc = BaseDocTemplate(
        path,
        pagesize=A4,
        leftMargin=MARGIN_L,
        rightMargin=MARGIN_R,
        topMargin=MARGIN_T,
        bottomMargin=MARGIN_B,
        title=doc_title,
        author="Prof. Kalpesh Vyas",
        subject="Power Maths · Statistics & Probability",
    )
    hf = HeaderFooter(chapter_label, doc_title)
    if total_pages is not None:
        doc._total_pages = total_pages
    frame = Frame(
        MARGIN_L, MARGIN_B,
        PAGE_W - MARGIN_L - MARGIN_R,
        PAGE_H - MARGIN_T - MARGIN_B,
        leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
        id="main"
    )
    doc.addPageTemplates([
        PageTemplate(id="all", frames=[frame], onPage=hf)
    ])
    return doc


# ----------------------------------------------------------------------
# FLOWABLE HELPERS
# ----------------------------------------------------------------------
def H1(text, sub=None):
    out = [Paragraph(text, STYLES["h1"])]
    if sub:
        out.append(Paragraph(sub, STYLES["h1_sub"]))
    out.append(HRFlowable(width="100%", thickness=1.2, color=C_TEAL,
                          spaceBefore=2, spaceAfter=8))
    return out


def H2(text):
    return Paragraph(text, STYLES["h2"])


def H3(text):
    return Paragraph(text, STYLES["h3"])


def P(text, style="body"):
    return Paragraph(text, STYLES[style])


def bullet_list(items, style="body"):
    """Bullet list using ListFlowable."""
    lst = []
    for it in items:
        lst.append(ListItem(
            Paragraph(it, STYLES[style]),
            leftIndent=14, value="•",
            bulletColor=C_TEAL
        ))
    return ListFlowable(
        lst, bulletType="bullet", start="•",
        leftIndent=14, bulletFontName="Helvetica-Bold",
        bulletFontSize=10, bulletColor=C_TEAL,
        spaceBefore=2, spaceAfter=4
    )


def numbered_list(items, style="body"):
    lst = []
    for it in items:
        lst.append(ListItem(
            Paragraph(it, STYLES[style]),
            leftIndent=18
        ))
    return ListFlowable(
        lst, bulletType="1", start="1",
        leftIndent=18, bulletFontName="Helvetica-Bold",
        bulletFontSize=10.5, bulletColor=C_EMERALD,
        spaceBefore=2, spaceAfter=4
    )


def example_box(title, paragraphs, answer=None):
    """Light-gray rounded example box. paragraphs: list of HTML strings."""
    inner = []
    inner.append(Paragraph("<b>Worked Example:</b> " + title, STYLES["example_title"]))
    for p in paragraphs:
        inner.append(Paragraph(p, STYLES["example_body"]))
    if answer:
        inner.append(HRFlowable(width="92%", thickness=0.5, color=C_RULE,
                                spaceBefore=3, spaceAfter=3))
        inner.append(Paragraph("<b>Answer:</b> " + answer, STYLES["answer"]))

    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 6])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_BG_SOFT),
        ("BOX",        (0, 0), (-1, -1), 0.6, C_RULE),
        ("LINEBEFORE", (0, 0), (0, -1), 3, C_TEAL_MID),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return KeepTogether([Spacer(1, 4), tbl, Spacer(1, 6)])


def solution_box(q_label, steps, final_answer):
    """One solution block: question label + steps + highlighted final answer."""
    inner = [Paragraph(q_label, STYLES["sol_q"])]
    for s in steps:
        inner.append(Paragraph(s, STYLES["sol_step"]))
    # highlighted final answer
    ans_tbl = Table(
        [[Paragraph("<b>Final Answer:</b> " + final_answer, STYLES["answer"])]],
        colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 6]
    )
    ans_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_EMERALD_LT),
        ("BOX",        (0, 0), (-1, -1), 0.6, C_EMERALD),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
        ("TOPPADDING",    (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    inner.append(Spacer(1, 4))
    inner.append(ans_tbl)
    wrap = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R])
    wrap.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, -1), C_BG_BOX),
        ("BOX",          (0, 0), (-1, -1), 0.4, C_RULE),
        ("LINEBEFORE",   (0, 0), (0, -1), 2.5, C_TEAL_MID),
        ("LEFTPADDING",   (0, 0), (-1, -1), 9),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 9),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return KeepTogether([wrap, Spacer(1, 14)])


def data_table(header_row, data_rows, col_widths=None, align="center"):
    """A clean data table with teal header row."""
    hdr = [Paragraph(str(c), STYLES["table_h"]) for c in header_row]
    body = []
    for row in data_rows:
        body.append([Paragraph(str(c), STYLES["table_c" if align=="center" else "table_l"]) for c in row])
    data = [hdr] + body
    if col_widths is None:
        n = len(header_row)
        total = PAGE_W - MARGIN_L - MARGIN_R
        col_widths = [total / n] * n

    tbl = Table(data, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), C_TEAL),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
        ("GRID",       (0, 0), (-1, -1), 0.4, C_RULE),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",(0, 0), (-1, -1), 5),
        ("RIGHTPADDING",(0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 4),
    ]
    # zebra striping
    for i in range(1, len(data)):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), C_BG_SOFT))
        else:
            style.append(("BACKGROUND", (0, i), (-1, i), colors.white))
    tbl.setStyle(TableStyle(style))
    return tbl


def answer_lines(n=3, width=None, height=26):
    """Render n underline blanks for students to write on."""
    if width is None:
        width = PAGE_W - MARGIN_L - MARGIN_R - 4
    rows = [[""]] * n
    tbl = Table(rows, colWidths=[width], rowHeights=[height]*n)
    style = []
    for i in range(n):
        style.append(("LINEBELOW", (0, i), (0, i), 0.5, C_ANS_LINE))
        style.append(("LEFTPADDING", (0, i), (0, i), 0))
        style.append(("RIGHTPADDING", (0, i), (0, i), 0))
    tbl.setStyle(TableStyle(style))
    return tbl


# ----------------------------------------------------------------------
# TWO-PASS BUILD (to know total page count for 'Page X of Y')
# ----------------------------------------------------------------------
def build_pdf(path, chapter_label, doc_title, story_factory):
    """
    Build a PDF using a 2-pass approach so that the footer shows
    'Page X of Y' on every page.

    story_factory: a callable that returns a fresh list of flowables.
    ReportLab's BaseDocTemplate.build() consumes the story list, so we
    must rebuild it for the second pass.
    """
    # PASS 1: build to count pages (footer shows "Page N" only)
    tmp = path + ".tmp"
    doc1 = make_doc(tmp, chapter_label, doc_title, total_pages=None)
    doc1.build(story_factory())
    total = doc1.page

    # PASS 2: build the real file with known total
    doc2 = make_doc(path, chapter_label, doc_title, total_pages=total)
    doc2.build(story_factory())
    # cleanup tmp
    try:
        os.remove(tmp)
    except OSError:
        pass
    return total


# ----------------------------------------------------------------------
# CONTENT BUILDERS  (one per PDF)
# ----------------------------------------------------------------------
CHAPTER_LABEL = "Chapter 6 · Statistics & Probability"

# ============ 1. MATERIAL: STATISTICS BASICS ==========================
def build_material_01():
    story = []
    story += H1("Statistics Basics",
                "Data, frequency distributions, and measures of central tendency")

    story.append(P(
        "Statistics is the branch of mathematics that deals with collecting, "
        "organising, presenting, analysing and interpreting numerical data. "
        "In everyday life we constantly come across data — marks of students "
        "in a class, runs scored in cricket matches, monthly rainfall, prices "
        "of vegetables, and so on. Statistics gives us a systematic way to "
        "make sense of such data and to draw meaningful conclusions from it."
    ))

    story.append(H2("1.  Key Terms"))
    story.append(bullet_list([
        "<b>Data:</b> A collection of facts, such as numbers, words, measurements or observations.",
        "<b>Raw data:</b> Data in its original form, collected but not yet organised.",
        "<b>Observation:</b> Each individual value in a data set.",
        "<b>Frequency:</b> The number of times a particular observation or value occurs.",
        "<b>Range:</b> The difference between the highest and lowest values (Range = Maximum − Minimum).",
        "<b>Variable:</b> A characteristic that can take different values, e.g. height, marks, age.",
    ]))

    story.append(H2("2.  Types of Data"))
    story.append(P(
        "Data can be classified in two main ways — by its nature and by how it "
        "is collected."
    ))
    story.append(H3("2.1  By nature"))
    story.append(bullet_list([
        "<b>Qualitative (categorical) data:</b> describes qualities or categories, "
        "e.g. blood group, favourite subject, eye colour.",
        "<b>Quantitative (numerical) data:</b> expressed in numbers, e.g. height in cm, "
        "marks obtained, number of siblings. Quantitative data is further split into "
        "<i>discrete</i> (countable whole numbers like the number of students) and "
        "<i>continuous</i> (measurable values that can take any value in a range, like "
        "weight or time).",
    ]))
    story.append(H3("2.2  By source"))
    story.append(bullet_list([
        "<b>Primary data:</b> collected first-hand by the investigator for a specific "
        "purpose. Example: a teacher recording the heights of all students in her class.",
        "<b>Secondary data:</b> collected by someone else and later used by another "
        "person. Example: using the Census of India report to study population trends.",
    ]))

    story.append(H2("3.  Methods of Collecting Data"))
    story.append(numbered_list([
        "<b>Direct observation:</b> the investigator observes and records data personally (e.g. counting vehicles passing a checkpoint).",
        "<b>Interview:</b> asking questions face-to-face or by phone.",
        "<b>Questionnaire / Survey:</b> a printed or online list of questions filled in by respondents.",
        "<b>Experiment:</b> conducting controlled tests (e.g. measuring the boiling point of water at different altitudes).",
        "<b>Published / online sources:</b> government reports, journals, websites — gives secondary data.",
    ]))

    story.append(H2("4.  Frequency Distribution"))
    story.append(P(
        "A frequency distribution is a tabular arrangement that shows how often "
        "each value (or group of values) occurs in the data. It makes a large "
        "data set easy to read and analyse."
    ))
    story.append(H3("4.1  Ungrouped frequency distribution"))
    story.append(P(
        "Used when the number of distinct values is small. We list each value "
        "and write its frequency against it. A <i>tally mark</i> column helps "
        "count correctly (|||  for 3,  ||||  with a slash for 5)."
    ))
    story.append(H3("4.2  Grouped frequency distribution"))
    story.append(P(
        "Used when data values are many and spread out. We divide the entire "
        "range into equal intervals called <b>class intervals</b> (e.g. 0–10, "
        "10–20, …). For each interval we record:"
    ))
    story.append(bullet_list([
        "<b>Class limits:</b> the smallest and largest values that can fall in the class.",
        "<b>Class width (size):</b> upper limit − lower limit (e.g. 10 − 0 = 10).",
        "<b>Class mark:</b> the midpoint = (lower limit + upper limit) ÷ 2.",
        "<b>Frequency:</b> number of observations lying in that interval.",
    ]))

    # Example 1
    story.append(example_box(
        "Constructing an ungrouped frequency table",
        [
            "The marks (out of 10) obtained by 20 students in a class test are:<br/>"
            "<font face='Courier'>5, 7, 8, 6, 5, 9, 7, 8, 6, 5, 8, 7, 6, 9, 8, 5, 7, 6, 8, 7</font>",
            "We list each distinct mark (3 does not occur here) and count its frequency.",
        ],
        answer=None
    ))
    story.append(data_table(
        ["Marks", "Tally", "Frequency"],
        [
            ["5", "||||", "4"],
            ["6", "||||", "4"],
            ["7", "||||", "5"],
            ["8", "||||", "5"],
            ["9", "||", "2"],
        ],
        col_widths=[120, 200, 160]
    ))
    story.append(Spacer(1, 4))
    story.append(P("Total frequency Σf = 4 + 4 + 5 + 5 + 2 = 20 ✓", "callout"))

    story.append(H2("5.  Measures of Central Tendency"))
    story.append(P(
        "A measure of central tendency is a single value that represents the "
        "centre or typical value of a data set. The three most common are the "
        "<b>mean</b>, the <b>median</b> and the <b>mode</b>."
    ))

    story.append(H3("5.1  Mean (arithmetic average)"))
    story.append(P(
        "The mean of n observations x₁, x₂, …, xₙ is given by"
    ))
    story.append(P(
        "<b>Mean  =  (x₁ + x₂ + … + xₙ) / n  =  Σx / n</b>",
        "body_center"
    ))
    story.append(P(
        "For a frequency distribution, Mean = Σ(f·x) / Σf, where x is each "
        "value (or class mark) and f is its frequency."
    ))

    story.append(H3("5.2  Median (middle value)"))
    story.append(P(
        "The median is the value that lies in the middle when the data is "
        "arranged in ascending (or descending) order."
    ))
    story.append(bullet_list([
        "If n is <b>odd</b>, Median = the ((n + 1)/2)th observation.",
        "If n is <b>even</b>, Median = average of the (n/2)th and ((n/2) + 1)th observations.",
    ]))

    story.append(H3("5.3  Mode (most frequent value)"))
    story.append(P(
        "The mode is the observation that occurs the maximum number of times. "
        "A data set can have one mode (unimodal), two modes (bimodal) or no "
        "mode at all (if every value occurs only once)."
    ))

    story.append(H2("6.  Range"))
    story.append(P(
        "<b>Range = Maximum value − Minimum value</b>. It is the simplest "
        "measure of how spread out the data is."
    ))

    # Worked examples
    story.append(H2("7.  Worked Examples"))

    story.append(example_box(
        "Finding the mean",
        [
            "Find the mean of the data set: 12, 18, 15, 20, 10, 17, 19, 13, 16, 20.",
            "Sum  Σx = 12 + 18 + 15 + 20 + 10 + 17 + 19 + 13 + 16 + 20 = 160",
            "Number of observations, n = 10",
            "Mean = Σx / n = 160 / 10 = 16",
        ],
        answer="Mean = 16"
    ))

    story.append(example_box(
        "Finding the median (odd n)",
        [
            "Find the median of: 25, 18, 32, 9, 21, 40, 15.",
            "Arrange in ascending order: 9, 15, 18, 21, 25, 32, 40.",
            "Number of observations n = 7 (odd).",
            "Median position = (n + 1)/2 = (7 + 1)/2 = 4 → the 4th observation.",
            "The 4th value in the ordered list is 21.",
        ],
        answer="Median = 21"
    ))

    story.append(example_box(
        "Finding the median (even n)",
        [
            "Find the median of: 6, 14, 8, 12, 10, 16, 4, 18.",
            "Ascending order: 4, 6, 8, 10, 12, 14, 16, 18.",
            "n = 8 (even). The two middle values are the 4th and 5th = 10 and 12.",
            "Median = (10 + 12)/2 = 22/2 = 11.",
        ],
        answer="Median = 11"
    ))

    story.append(example_box(
        "Mean and mode from a frequency table",
        [
            "From the frequency table of marks (Section 4.1):",
            "Σ(f·x) = (5×4) + (6×4) + (7×5) + (8×5) + (9×2) = 20 + 24 + 35 + 40 + 18 = 137",
            "Σf = 20.  Mean = 137 / 20 = 6.85",
            "The marks 7 and 8 both occur 5 times — the data is bimodal, so Mode = 7 and 8.",
            "Range = 9 − 5 = 4.",
        ],
        answer="Mean = 6.85;  Modes = 7 and 8;  Range = 4"
    ))

    story.append(H2("8.  Quick Recap"))
    story.append(bullet_list([
        "Always arrange data in order before finding the median.",
        "Mean uses every value; median ignores extremes; mode is about frequency only.",
        "A frequency distribution tables organises raw data for quick analysis.",
        "For grouped data, use the class mark (midpoint) as the representative value of each class.",
        "Range only tells the spread between extremes, not what is happening in between.",
    ]))

    story.append(H2("9.  Key Formulas at a Glance"))
    story.append(data_table(
        ["Quantity", "Formula", "When to use"],
        [
            ["Mean (ungrouped)",     "Σx ÷ n",                          "Raw list of values"],
            ["Mean (frequency)",     "Σ(f·x) ÷ Σf",                     "Data given as a frequency table"],
            ["Mean (grouped)",       "Σ(fᵢ · xᵢ) ÷ Σfᵢ  (xᵢ = class mark)", "Grouped continuous data"],
            ["Median (odd n)",       "((n + 1)/2)th observation",       "Number of observations is odd"],
            ["Median (even n)",      "average of (n/2)th and ((n/2)+1)th", "Number of observations is even"],
            ["Mode",                 "value with highest frequency",    "Most frequent observation"],
            ["Range",                "Maximum − Minimum",               "Spread between extremes"],
        ],
        col_widths=[(PAGE_W - MARGIN_L - MARGIN_R)*0.28,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.42,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.30],
        align="left"
    ))

    story.append(H2("10.  Common Mistakes to Avoid"))
    story.append(bullet_list([
        "Forgetting to sort the data before finding the median.",
        "Confusing the class limits with the class mark when computing the mean of grouped data.",
        "Reporting the mode as ‘none’ just because two values tie — that is a <b>bimodal</b> data set.",
        "Adding Σf incorrectly when totalling frequencies (double-check with a running total).",
        "Treating the upper limit of one class as the lower limit of the next without checking for gaps/overlaps.",
    ]))

    story.append(example_box(
        "Mean of grouped data using class marks",
        [
            "The following table shows the daily wages (in ₹) of 30 workers. Find the mean wage.",
        ],
        answer=None
    ))
    story.append(data_table(
        ["Wages (₹)", "Class mark x", "Frequency f", "f · x"],
        [
            ["200–250", "225", "4",  "900"],
            ["250–300", "275", "8",  "2200"],
            ["300–350", "325", "10", "3250"],
            ["350–400", "375", "6",  "2250"],
            ["400–450", "425", "2",  "850"],
        ],
        col_widths=[120, 120, 120, 120]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "Σf = 4 + 8 + 10 + 6 + 2 = 30;   Σ(f·x) = 900 + 2200 + 3250 + 2250 + 850 = 9450.",
        "body_left"
    ))
    story.append(P(
        "Mean = Σ(f·x) / Σf = 9450 / 30 = 315.  So the mean wage is ₹ 315.",
        "body_left"
    ))

    story.append(Spacer(1, 6))
    story.append(P(
        "In the next material we will learn how to represent such frequency "
        "distributions visually using bar graphs, histograms, frequency "
        "polygons, pie charts and ogives.", "callout"
    ))

    return story


# ============ 2. MATERIAL: GRAPHICAL REPRESENTATION ===================
def build_material_02():
    story = []
    story += H1("Graphical Representation of Data",
                "Bar graphs, histograms, frequency polygons, pie charts and ogives")

    story.append(P(
        "Numerical data presented in tables is precise but hard to interpret "
        "at a glance. Graphs make patterns, comparisons and trends jump out "
        "instantly. In this material we study the five most common ways of "
        "representing data pictorially."
    ))

    story.append(H2("1.  Bar Graph"))
    story.append(P(
        "A bar graph uses rectangular bars of uniform width to represent "
        "different categories. The <b>length (height) of each bar</b> is "
        "proportional to the value it represents. The bars are drawn with "
        "<i>equal gaps</i> between them, which signals that the categories "
        "are separate (discrete)."
    ))
    story.append(H3("How to construct"))
    story.append(numbered_list([
        "Draw two perpendicular lines — a horizontal axis (x-axis) and a vertical axis (y-axis).",
        "Mark the categories on the x-axis with equal spacing.",
        "Choose a suitable scale for the y-axis so that the largest value fits comfortably.",
        "For each category, draw a rectangle of uniform width whose height equals the value.",
        "Leave equal gaps between consecutive bars.",
        "Give the graph a title and label both axes.",
    ]))
    story.append(example_box(
        "Bar graph — interpreting it",
        [
            "The bar graph below shows the number of saplings planted by a school "
            "on five days of a plantation drive.",
        ],
        answer=None
    ))
    story.append(data_table(
        ["Day", "Mon", "Tue", "Wed", "Thu", "Fri"],
        [["Saplings", "20", "35", "25", "45", "30"]],
        col_widths=[80, 80, 80, 80, 80, 80]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "Reading the graph: Thursday has the tallest bar (45 saplings), so the "
        "maximum plantation was on Thursday. Monday has the shortest bar (20). "
        "Total saplings = 20 + 35 + 25 + 45 + 30 = 155.",
        "callout"
    ))

    story.append(H2("2.  Histogram"))
    story.append(P(
        "A histogram is a bar graph for <b>continuous grouped data</b>. The "
        "class intervals are marked on the x-axis (with <i>no gaps</i> between "
        "bars), and the frequency on the y-axis. Each rectangle represents the "
        "frequency of a class interval and its area is proportional to that "
        "frequency (when class widths are equal, height alone is enough)."
    ))
    story.append(H3("How to construct"))
    story.append(numbered_list([
        "Mark the class limits along the x-axis using a continuous scale.",
        "Choose a scale for the y-axis to represent frequency.",
        "For each class interval, draw a rectangle of width = class size and height = frequency.",
        "There must be NO gaps between consecutive rectangles.",
        "Add a title and axis labels.",
    ]))
    story.append(example_box(
        "Histogram — frequency of weights",
        [
            "The weights (in kg) of 36 students grouped into class intervals of width 5 are:",
        ],
        answer=None
    ))
    story.append(data_table(
        ["Weight (kg)", "40–45", "45–50", "50–55", "55–60", "60–65"],
        [["Frequency", "4", "10", "12", "6", "4"]],
        col_widths=[90, 80, 80, 80, 80, 80]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "When drawn, the rectangles for 45–50 and 50–55 will be the tallest, "
        "showing most students weigh between 45 kg and 55 kg. The total of all "
        "frequencies = 4 + 10 + 12 + 6 + 4 = 36 ✓.",
        "callout"
    ))

    story.append(H2("3.  Frequency Polygon"))
    story.append(P(
        "A frequency polygon is a line graph that shows frequencies. To draw "
        "it we plot the <b>class marks</b> on the x-axis against the "
        "frequencies on the y-axis, then join consecutive points with straight "
        "line segments. The polygon is closed at both ends by plotting points "
        "at the midpoints of the imaginary classes just before the first and "
        "just after the last interval (with frequency 0)."
    ))
    story.append(H3("Steps"))
    story.append(numbered_list([
        "Compute the class mark of each interval: x = (lower limit + upper limit) ÷ 2.",
        "Plot (class mark, frequency) for every class.",
        "Add imaginary classes at both ends with frequency 0 and plot their midpoints.",
        "Join the points in order with straight lines to form a polygon.",
    ]))
    story.append(example_box(
        "Frequency polygon — class marks",
        [
            "For the weight data above, the class marks are: 42.5, 47.5, 52.5, 57.5, 62.5.",
            "Plot (42.5, 4), (47.5, 10), (52.5, 12), (57.5, 6), (62.5, 4).",
            "Add the imaginary classes 35–40 (mark 37.5, freq 0) and 65–70 (mark 67.5, freq 0).",
            "Join all seven points in order to get the closed frequency polygon.",
        ],
        answer="Polygon peaks at (52.5, 12) — the modal class 50–55."
    ))

    story.append(H2("4.  Pie Chart"))
    story.append(P(
        "A pie chart is a circle divided into sectors. Each sector represents "
        "a category, and the <b>angle of each sector</b> is proportional to the "
        "value of that category."
    ))
    story.append(P("<b>Formula:</b>  Sector angle = (Value of category ÷ Total value) × 360°", "body_center"))
    story.append(H3("Construction steps"))
    story.append(numbered_list([
        "Find the total of all the values.",
        "For each category, compute the sector angle using the formula above.",
        "Draw a circle of convenient radius.",
        "Using a protractor, draw each sector at its computed angle.",
        "Label each sector and shade / colour it differently.",
        "Give the chart a title.",
    ]))
    story.append(example_box(
        "Pie chart — weekly activities",
        [
            "A student spends 24 hours of a day as: Study 8 h, School 6 h, Play 4 h, Sleep 6 h.",
            "Total = 8 + 6 + 4 + 6 = 24 h. Each hour corresponds to 360° ÷ 24 = 15°.",
            "Study = 8 × 15° = 120°;  School = 6 × 15° = 90°;  Play = 4 × 15° = 60°;  Sleep = 6 × 15° = 90°.",
            "Check: 120° + 90° + 60° + 90° = 360° ✓",
        ],
        answer="Angles: Study 120°, School 90°, Play 60°, Sleep 90°."
    ))

    story.append(H2("5.  Ogive (Cumulative Frequency Curve)"))
    story.append(P(
        "An ogive is a line graph that shows <b>cumulative frequency</b>. There "
        "are two types: the <i>less-than</i> ogive and the <i>more-than</i> ogive."
    ))
    story.append(H3("Less-than ogive"))
    story.append(P(
        "Plot the <b>upper class limits</b> on the x-axis against the cumulative "
        "frequency (less than type) on the y-axis, then join the points with a "
        "smooth free-hand curve."
    ))
    story.append(H3("More-than ogive"))
    story.append(P(
        "Plot the <b>lower class limits</b> on the x-axis against the cumulative "
        "frequency (more than type) on the y-axis, then join the points smoothly."
    ))
    story.append(P(
        "The point where the two ogives intersect gives the <b>median</b> of "
        "the distribution — the x-coordinate of the intersection is the median value.",
        "callout"
    ))
    story.append(example_box(
        "Less-than ogive — weight data",
        [
            "Cumulative frequencies for the weight data (Section 2):",
            "Less than 45 → 4;  Less than 50 → 4 + 10 = 14;  Less than 55 → 14 + 12 = 26;",
            "Less than 60 → 26 + 6 = 32;  Less than 65 → 32 + 4 = 36.",
        ],
        answer=None
    ))
    story.append(data_table(
        ["Upper limit", "45", "50", "55", "60", "65"],
        [["Cumulative freq (less than)", "4", "14", "26", "32", "36"]],
        col_widths=[140, 70, 70, 70, 70, 70]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "Plot (45, 4), (50, 14), (55, 26), (60, 32), (65, 36) and join them "
        "smoothly. Since N = 36, the median corresponds to N/2 = 18 on the "
        "y-axis. Reading across at y = 18 gives a median of about 51.5 kg.",
        "callout"
    ))

    story.append(H2("6.  Choosing the Right Graph"))
    story.append(data_table(
        ["Type of data", "Best graph"],
        [
            ["Discrete categories (e.g. favourite fruit)", "Bar graph"],
            ["Continuous grouped data", "Histogram / frequency polygon"],
            ["Parts of a whole (percentages)", "Pie chart"],
            ["Cumulative totals / median visually", "Ogive"],
        ],
        col_widths=[(PAGE_W - MARGIN_L - MARGIN_R)*0.55,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.45],
        align="left"
    ))

    story.append(H2("7.  Quick Recap"))
    story.append(bullet_list([
        "Bars in a bar graph have gaps; rectangles in a histogram do not.",
        "Use class marks (midpoints) to plot frequency polygons.",
        "Each pie sector angle = (value ÷ total) × 360°; the angles always add to 360°.",
        "Less-than ogive uses upper limits; more-than ogive uses lower limits.",
        "The intersection of the two ogives gives the median.",
    ]))

    story.append(H2("8.  Worked Example — Pie Chart from a Table"))
    story.append(P(
        "The table below shows how a family spends ₹ 24,000 of monthly income "
        "on five heads. Construct a pie chart by computing each sector angle."
    ))
    story.append(data_table(
        ["Head", "Amount (₹)", "Fraction", "Sector angle"],
        [
            ["Food",     "9000",  "9000 / 24000 = 3/8",  "3/8 × 360° = 135°"],
            ["Rent",     "6000",  "6000 / 24000 = 1/4",  "1/4 × 360° = 90°"],
            ["Education","3600",  "3600 / 24000 = 3/20", "3/20 × 360° = 54°"],
            ["Savings",  "3000",  "3000 / 24000 = 1/8",  "1/8 × 360° = 45°"],
            ["Others",   "2400",  "2400 / 24000 = 1/10", "1/10 × 360° = 36°"],
        ],
        col_widths=[100, 90, 130, 140]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "Check: 135° + 90° + 54° + 45° + 36° = 360° ✓  Total amount = ₹ 24000 ✓",
        "callout"
    ))

    story.append(H2("9.  Common Mistakes to Avoid"))
    story.append(bullet_list([
        "Leaving gaps between bars of a histogram — they must touch because the data is continuous.",
        "Forgetting to add the imaginary ‘zero-frequency’ classes when drawing a frequency polygon.",
        "Computing pie-chart angles without dividing by the total — the angles will not add up to 360°.",
        "Using the lower limits (instead of upper limits) when plotting a less-than ogive.",
        "Choosing a y-axis scale that distorts the data (e.g. starting from a non-zero value when bar heights are compared).",
    ]))

    story.append(H2("10.  Quick Reference Table"))
    story.append(data_table(
        ["Graph", "x-axis plots", "y-axis plots", "Bars touch?"],
        [
            ["Bar graph",          "Discrete categories", "Value",          "No (gaps)"],
            ["Histogram",          "Continuous class limits", "Frequency",   "Yes (no gaps)"],
            ["Frequency polygon",  "Class marks (midpoints)", "Frequency",   "Line graph"],
            ["Pie chart",          "—",                   "Sector angle (°)", "Sectors of a circle"],
            ["Less-than ogive",    "Upper class limits",  "Cumulative freq.", "Smooth curve"],
            ["More-than ogive",    "Lower class limits",  "Cumulative freq.", "Smooth curve"],
        ],
        col_widths=[120, 130, 130, 90]
    ))

    story.append(H2("11.  Worked Example — Histogram & Frequency Polygon Together"))
    story.append(P(
        "The table below shows the heights (in cm) of 40 students of Class X. "
        "Draw a histogram and a frequency polygon on the same axes."
    ))
    story.append(data_table(
        ["Height (cm)", "140–145", "145–150", "150–155", "155–160", "160–165", "165–170"],
        [["No. of students", "5", "8", "12", "9", "4", "2"]],
        col_widths=[80, 75, 75, 75, 75, 75, 75]
    ))
    story.append(Spacer(1, 3))
    story.append(P(
        "<b>Step 1 — Verify total:</b> 5 + 8 + 12 + 9 + 4 + 2 = 40 students ✓",
        "body_left"
    ))
    story.append(P(
        "<b>Step 2 — Draw the histogram:</b> Mark class limits 140, 145, 150, 155, 160, 165, 170 "
        "on the x-axis. Choose a y-scale (say 1 cm = 2 students). For each class interval draw "
        "a rectangle of width 5 (cm) and height equal to the frequency. The rectangles must touch.",
        "body_left"
    ))
    story.append(P(
        "<b>Step 3 — Find class marks:</b> (140+145)/2 = 142.5, 147.5, 152.5, 157.5, 162.5, 167.5.",
        "body_left"
    ))
    story.append(P(
        "<b>Step 4 — Plot the polygon:</b> Mark the points (142.5, 5), (147.5, 8), "
        "(152.5, 12), (157.5, 9), (162.5, 4), (167.5, 2).",
        "body_left"
    ))
    story.append(P(
        "<b>Step 5 — Close the polygon:</b> Add imaginary classes 135–140 (mark 137.5, freq 0) "
        "and 170–175 (mark 172.5, freq 0). Plot (137.5, 0) and (172.5, 0).",
        "body_left"
    ))
    story.append(P(
        "<b>Step 6 — Join:</b> Connect all eight points in order with straight line segments "
        "to form the closed frequency polygon.",
        "body_left"
    ))
    story.append(Spacer(1, 4))
    story.append(P(
        "Observation: The histogram peaks at the class 150–155 (12 students). The polygon "
        "also peaks at the same class mark 152.5, which is the modal class.",
        "callout"
    ))
    return story


# ============ 3. MATERIAL: PROBABILITY =================================
def build_material_03():
    story = []
    story += H1("Probability",
                "Experiments, sample space, events and computing chances")

    story.append(P(
        "Probability is the measure of how likely an event is to happen. From "
        "tossing a coin to predicting the weather, probability is the language "
        "we use to talk about uncertainty. In this material we develop the "
        "basic vocabulary and formulas needed for school-level probability."
    ))

    story.append(H2("1.  Some Everyday Words"))
    story.append(bullet_list([
        "<b>Trial:</b> a single performance of a random experiment (e.g. one toss of a coin).",
        "<b>Outcome:</b> the result of a trial (e.g. getting Heads).",
        "<b>Event:</b> a collection of one or more outcomes (e.g. getting an even number on a die).",
        "<b>Certain event:</b> an event that is sure to happen — probability = 1.",
        "<b>Impossible event:</b> an event that can never happen — probability = 0.",
    ]))

    story.append(H2("2.  Random Experiment and Sample Space"))
    story.append(P(
        "A <b>random experiment</b> is one whose outcome cannot be predicted "
        "with certainty in advance, even though we know all possible outcomes. "
        "The set of all possible outcomes of a random experiment is called the "
        "<b>sample space</b>, denoted by S. The number of outcomes in S is "
        "written as n(S)."
    ))
    story.append(H3("Common examples"))
    story.append(data_table(
        ["Experiment", "Sample space S", "n(S)"],
        [
            ["Tossing one coin",        "{H, T}",                          "2"],
            ["Tossing two coins",       "{HH, HT, TH, TT}",                "4"],
            ["Rolling one die",         "{1, 2, 3, 4, 5, 6}",              "6"],
            ["Rolling two dice together","36 ordered pairs (1,1) … (6,6)", "36"],
            ["Drawing one card from a pack of 52", "52 cards",             "52"],
        ],
        col_widths=[(PAGE_W - MARGIN_L - MARGIN_R)*0.30,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.50,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.20],
        align="left"
    ))

    story.append(H2("3.  Definition of Probability"))
    story.append(P(
        "For a random experiment with equally likely outcomes, the probability "
        "of an event E is defined as:"
    ))
    story.append(P(
        "<b>P(E)  =  Number of outcomes favourable to E  ÷  Total number of possible outcomes</b>",
        "body_center"
    ))
    story.append(P(
        "i.e.  <b>P(E) = n(E) / n(S)</b>, where n(E) is the number of outcomes "
        "favourable to event E and n(S) is the total number of outcomes in the "
        "sample space.",
        "body_center"
    ))
    story.append(bullet_list([
        "Probability is always a number between 0 and 1:  0 ≤ P(E) ≤ 1.",
        "If P(E) = 0, the event is impossible.",
        "If P(E) = 1, the event is certain.",
        "Probabilities are often written as fractions, decimals or percentages.",
    ]))

    story.append(H2("4.  Complementary Events"))
    story.append(P(
        "The event <i>not E</i> (written as Ē or ‘not E’) is called the "
        "complementary event of E. It contains all outcomes of S that are NOT "
        "in E. The most useful identity in probability is:"
    ))
    story.append(P("<b>P(E) + P(not E) = 1     ⇒     P(not E) = 1 − P(E)</b>", "body_center"))
    story.append(P(
        "This is very handy when ‘not E’ is easier to count than E itself — "
        "we find P(not E) first and subtract from 1.",
        "callout"
    ))

    story.append(H2("5.  Standard Sample Spaces"))
    story.append(H3("5.1  Coins"))
    story.append(bullet_list([
        "1 coin: outcomes = {H, T}, n(S) = 2.",
        "2 coins: outcomes = {HH, HT, TH, TT}, n(S) = 4.  (Note: HT and TH are different.)",
        "3 coins: n(S) = 2 × 2 × 2 = 8 outcomes.",
    ]))
    story.append(H3("5.2  Dice"))
    story.append(bullet_list([
        "1 die: outcomes = {1, 2, 3, 4, 5, 6}, n(S) = 6.",
        "2 dice: n(S) = 6 × 6 = 36 ordered pairs like (2, 5), (5, 2), (6, 6).",
    ]))
    story.append(H3("5.3  Playing cards"))
    story.append(bullet_list([
        "A standard deck has 52 cards in 4 suits — Spades ♠, Hearts ♥, Diamonds ♦, Clubs ♣.",
        "Each suit has 13 cards: A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K.",
        "Face cards = J, Q, K of each suit → 12 in all.",
        "Honours / court cards = A, K, Q, J of each suit → 16 in all.",
        "Red cards (Hearts + Diamonds) = 26;  Black cards (Spades + Clubs) = 26.",
    ]))

    story.append(H2("6.  Worked Examples"))

    story.append(example_box(
        "Tossing a coin",
        [
            "A coin is tossed once. Find the probability of getting Heads.",
            "S = {H, T},  n(S) = 2.  Favourable outcome: H,  n(E) = 1.",
            "P(H) = n(E) / n(S) = 1/2 = 0.5.",
        ],
        answer="P(Heads) = 1/2"
    ))

    story.append(example_box(
        "Rolling a single die",
        [
            "A die is rolled once. Find the probability of getting (a) an even "
            "number, (b) a number greater than 4, (c) a multiple of 3.",
            "S = {1, 2, 3, 4, 5, 6}, n(S) = 6.",
            "(a) Even numbers: {2, 4, 6}, n(E) = 3.  P = 3/6 = 1/2.",
            "(b) Numbers &gt; 4: {5, 6}, n(E) = 2.  P = 2/6 = 1/3.",
            "(c) Multiples of 3: {3, 6}, n(E) = 2.  P = 2/6 = 1/3.",
        ],
        answer="(a) 1/2  (b) 1/3  (c) 1/3"
    ))

    story.append(example_box(
        "Tossing two coins together",
        [
            "Two coins are tossed together. Find the probability of getting "
            "(a) exactly one Head, (b) at least one Tail.",
            "S = {HH, HT, TH, TT}, n(S) = 4.",
            "(a) Exactly one Head = {HT, TH}, n(E) = 2.  P = 2/4 = 1/2.",
            "(b) At least one Tail = {HT, TH, TT}, n(E) = 3.  P = 3/4.",
        ],
        answer="(a) 1/2   (b) 3/4"
    ))

    story.append(example_box(
        "Drawing a card from a deck",
        [
            "One card is drawn at random from a well-shuffled deck of 52 cards. "
            "Find the probability that it is (a) a King, (b) a face card, (c) a red card, (d) a spade.",
            "n(S) = 52.",
            "(a) Kings: 4  → P = 4/52 = 1/13.",
            "(b) Face cards (J, Q, K): 12  → P = 12/52 = 3/13.",
            "(c) Red cards: 26  → P = 26/52 = 1/2.",
            "(d) Spades: 13  → P = 13/52 = 1/4.",
        ],
        answer="(a) 1/13  (b) 3/13  (c) 1/2  (d) 1/4"
    ))

    story.append(example_box(
        "Balls in a bag (using complement)",
        [
            "A bag contains 5 red, 8 white and 7 green balls. One ball is drawn "
            "at random. Find the probability that it is (a) green, (b) not red.",
            "Total balls = 5 + 8 + 7 = 20, so n(S) = 20.",
            "(a) Green balls = 7  →  P(green) = 7/20.",
            "(b) Red balls = 5  →  P(red) = 5/20 = 1/4.",
            "    P(not red) = 1 − P(red) = 1 − 1/4 = 3/4.",
        ],
        answer="(a) 7/20   (b) 3/4"
    ))

    story.append(example_box(
        "Two dice — sum equals 7",
        [
            "Two dice are rolled together. Find the probability that the sum of "
            "the numbers on top is 7.",
            "n(S) = 6 × 6 = 36.  Favourable pairs that sum to 7:",
            "(1,6), (2,5), (3,4), (4,3), (5,2), (6,1) → 6 outcomes.",
            "P(sum = 7) = 6/36 = 1/6.",
        ],
        answer="P(sum = 7) = 1/6"
    ))

    story.append(H2("7.  Quick Recap"))
    story.append(bullet_list([
        "Always start by writing down the sample space S and finding n(S).",
        "Probability = favourable outcomes ÷ total outcomes.",
        "Use P(not E) = 1 − P(E) when ‘not E’ is easier to count.",
        "For two dice, remember there are 36 ordered pairs (not 21).",
        "Probability is always between 0 and 1 — never outside this range.",
    ]))

    story.append(H2("8.  Key Formulas & Facts at a Glance"))
    story.append(data_table(
        ["Item", "Value / Formula"],
        [
            ["P(E) — basic definition",      "n(E) ÷ n(S)"],
            ["Complement rule",               "P(not E) = 1 − P(E)"],
            ["Range of probability",          "0 ≤ P(E) ≤ 1"],
            ["Sample space: 1 coin / 2 / 3",  "2 / 4 / 8 outcomes"],
            ["Sample space: 1 die / 2 dice",  "6 / 36 outcomes"],
            ["Total cards / face cards / honours", "52 / 12 / 16"],
            ["Red cards / Black cards",       "26 / 26"],
            ["Cards of any one suit",         "13"],
            ["Cards of any one denomination (e.g. all 4 Jacks)", "4"],
        ],
        col_widths=[(PAGE_W - MARGIN_L - MARGIN_R)*0.50,
                    (PAGE_W - MARGIN_L - MARGIN_R)*0.50],
        align="left"
    ))

    story.append(H2("9.  Common Mistakes to Avoid"))
    story.append(bullet_list([
        "Confusing the events HT and TH when tossing two coins — they are two different outcomes.",
        "Counting ‘at least one Head’ as a single outcome instead of {HH, HT, TH}.",
        "Forgetting that ‘sum = 7’ for two dice has six favourable pairs, not one.",
        "Reporting a probability greater than 1 (or less than 0) — always recheck n(E) ≤ n(S).",
        "Mixing up face cards (J, Q, K) with honours (A, K, Q, J) — they are different sets.",
        "Adding probabilities of events that are not mutually exclusive (we only add when events cannot occur together).",
    ]))

    story.append(example_box(
        "Three coins — at least two Heads",
        [
            "Three coins are tossed together. Find the probability of getting "
            "at least two Heads.",
            "S has 8 outcomes: HHH, HHT, HTH, HTT, THH, THT, TTH, TTT.",
            "Favourable (≥ 2 Heads): {HHH, HHT, HTH, THH} → 4 outcomes.",
            "P = 4/8 = 1/2.",
        ],
        answer="P(at least 2 Heads) = 1/2"
    ))

    story.append(example_box(
        "Card — neither a King nor a Queen",
        [
            "One card is drawn from a well-shuffled deck. Find the probability "
            "that it is neither a King nor a Queen.",
            "n(S) = 52.  Number of Kings = 4,  number of Queens = 4.",
            "Total King-or-Queen cards = 4 + 4 = 8 (they are mutually exclusive).",
            "Favourable = 52 − 8 = 44.",
            "P(neither K nor Q) = 44/52 = 11/13.",
        ],
        answer="P(neither K nor Q) = 11/13"
    ))
    return story


# ============ 4. PRACTICE 1: STATISTICS ================================
def build_practice_01():
    story = []
    story += H1("Practice Sheet 1 — Statistics",
                "Mean, Median, Mode, Range & Frequency Tables")

    story.append(P(
        "<b>Instructions:</b> Solve all 18 questions in the space provided. "
        "Show your working clearly. MCQs have exactly one correct option. "
        "Round numerical answers to two decimal places where needed.",
        "callout"
    ))
    story.append(Spacer(1, 6))

    GAP = Spacer(1, 10)

    # Q1 MCQ
    story.append(Paragraph("Q1. The mean of 5, 10, 15, 20, 25 is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 12   (b) 15   (c) 17   (d) 20", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q2 MCQ
    story.append(Paragraph("Q2. The mode of the data 3, 5, 7, 5, 8, 5, 9, 7 is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 5   (b) 7   (c) 8   (d) no mode", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q3 MCQ
    story.append(Paragraph("Q3. For an ungrouped data set with n observations, "
                           "the median is the:", STYLES["qnum"]))
    story.append(Paragraph("(a) most frequent value   (b) arithmetic average   "
                           "(c) middlemost value after sorting   (d) largest value", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q4 MCQ
    story.append(Paragraph("Q4. The range of 18, 25, 32, 9, 41, 27 is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 23   (b) 32   (c) 41   (d) 50", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q5 numerical
    story.append(Paragraph("Q5. Find the mean of the first five natural numbers.", STYLES["qnum"]))
    story.append(answer_lines(4))
    story.append(GAP)

    # Q6 numerical
    story.append(Paragraph("Q6. Find the median of: 14, 9, 21, 17, 11, 23, 6.", STYLES["qnum"]))
    story.append(answer_lines(4))
    story.append(GAP)

    # Q7 numerical
    story.append(Paragraph("Q7. The mean of 8 observations is 25. If one more "
                           "observation of value 33 is added, find the new mean.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q8 numerical — frequency table
    story.append(Paragraph("Q8. From the following frequency table, find the mean:", STYLES["qnum"]))
    story.append(data_table(
        ["x", "4", "6", "8", "10", "12"],
        [["f", "3", "5", "6", "4", "2"]],
        col_widths=[60, 80, 80, 80, 80, 80]
    ))
    story.append(Spacer(1, 4))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q9 word problem
    story.append(Paragraph("Q9. The ages (in years) of 12 players of a cricket "
                           "team are: 21, 24, 22, 26, 25, 23, 24, 27, 24, 22, 25, 24. "
                           "Find the mean, median and mode of their ages.", STYLES["qnum"]))
    story.append(answer_lines(6))
    story.append(GAP)

    # Q10 word problem
    story.append(Paragraph("Q10. The marks of 10 students in a test (out of 50) "
                           "are 42, 38, 45, 36, 49, 38, 41, 45, 33, 38. Find the "
                           "mean, median and range.", STYLES["qnum"]))
    story.append(answer_lines(6))
    story.append(GAP)

    # Q11 grouped frequency
    story.append(Paragraph("Q11. Construct a grouped frequency distribution "
                           "table with class intervals of width 10 for the data below:", STYLES["qnum"]))
    story.append(P(
        "<font face='Courier'>12, 25, 18, 36, 42, 8, 31, 27, 19, 44, 22, 35, "
        "29, 14, 48, 17, 33, 41, 26, 11, 38, 23, 30, 46, 21</font>",
        "body_left"
    ))
    story.append(answer_lines(6))
    story.append(GAP)

    # Q12 MCQ
    story.append(Paragraph("Q12. The class mark of the interval 30–40 is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 30   (b) 35   (c) 40   (d) 70", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q13 word
    story.append(Paragraph("Q13. The mean of 6 numbers is 18. If one number, "
                           "24, is removed, find the mean of the remaining numbers.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q14 numerical
    story.append(Paragraph("Q14. Find the mode and median of: "
                           "7, 9, 11, 7, 8, 7, 10, 11, 7, 9, 8, 11, 7.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q15 word
    story.append(Paragraph("Q15. The heights (in cm) of 9 students are: "
                           "148, 152, 155, 149, 151, 153, 150, 154, 156. "
                           "Find the median height and the range.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q16 MCQ
    story.append(Paragraph("Q16. If the mean of x, x + 2, x + 4, x + 6 and x + 8 is 12, then x is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 6   (b) 8   (c) 10   (d) 12", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q17 numerical — grouped mean
    story.append(Paragraph("Q17. The table below shows the daily wages (in ₹) of "
                           "30 workers. Using class marks, find the mean wage.", STYLES["qnum"]))
    story.append(data_table(
        ["Wages (₹)", "200–250", "250–300", "300–350", "350–400", "400–450"],
        [["Workers", "4", "8", "10", "6", "2"]],
        col_widths=[80, 80, 80, 80, 80, 80]
    ))
    story.append(Spacer(1, 4))
    story.append(answer_lines(6))
    story.append(GAP)

    # Q18 word problem
    story.append(Paragraph("Q18. The daily maximum temperatures (in °C) recorded "
                           "in a city for 10 days are: 32, 35, 30, 34, 36, 33, 31, "
                           "35, 37, 32. Find the mean, median, mode and range of "
                           "the temperatures. Identify if the data is unimodal or "
                           "bimodal.", STYLES["qnum"]))
    story.append(answer_lines(6))
    story.append(GAP)

    # Self-assessment footer
    story.append(Spacer(1, 6))
    story.append(H2("Self-Assessment Checklist"))
    story.append(P(
        "Before submitting your answers, tick each box once you have done it.",
        "body_left"
    ))
    story.append(bullet_list([
        "I sorted the data before computing the median.",
        "I checked whether n is odd or even before applying the median formula.",
        "For grouped data, I used class marks (midpoints), not class limits, in Σ(f·x).",
        "I computed the range as Maximum − Minimum (not Maximum + Minimum).",
        "I double-checked the total Σf against the number of observations in the question.",
        "All numerical answers are rounded to two decimal places where required.",
    ]))
    story.append(Spacer(1, 4))
    story.append(P(
        "Score interpretation: 16–18 correct = excellent · 13–15 = good · "
        "10–12 = revise and retry · below 10 = please re-study Material 1 "
        "before attempting again.",
        "callout"
    ))

    return story


# ============ 5. PRACTICE 1 SOLUTIONS ==================================
def build_practice_01_solutions():
    story = []
    story += H1("Practice Sheet 1 — Solutions",
                "Step-by-step worked solutions · Statistics")

    story.append(P(
        "<b>How to use these solutions:</b> First attempt every question on "
        "your own. Then check your working against the steps shown here. If your "
        "answer is wrong, identify the exact step where you went off track and "
        "redo the question from that point. Pay special attention to how the "
        "data is arranged before computing the median and how Σ(f·x) is built "
        "up row by row for grouped-data problems.",
        "callout"
    ))
    story.append(Spacer(1, 4))

    sols = [
        ("Q1.  Mean of 5, 10, 15, 20, 25",
         ["Sum = 5 + 10 + 15 + 20 + 25 = 75",
          "Number of observations n = 5",
          "Mean = Σx / n = 75 / 5 = 15 → matches option (b)."],
         "(b) 15"),

        ("Q2.  Mode of 3, 5, 7, 5, 8, 5, 9, 7",
         ["Count each value: 3→1, 5→3, 7→2, 8→1, 9→1.",
          "Highest frequency = 3, for the value 5."],
         "(a) 5"),

        ("Q3.  Definition of median",
         ["By definition, the median is the middle value when data is sorted."],
         "(c) middlemost value after sorting"),

        ("Q4.  Range of 18, 25, 32, 9, 41, 27",
         ["Maximum value = 41;  Minimum value = 9.",
          "Range = Max − Min = 41 − 9 = 32."],
         "(b) 32"),

        ("Q5.  Mean of first five natural numbers",
         ["First five natural numbers: 1, 2, 3, 4, 5.",
          "Sum = 1 + 2 + 3 + 4 + 5 = 15;  n = 5.",
          "Mean = 15 / 5 = 3."],
         "Mean = 3"),

        ("Q6.  Median of 14, 9, 21, 17, 11, 23, 6",
         ["Arrange in ascending order: 6, 9, 11, 14, 17, 21, 23.",
          "n = 7 (odd).  Position = (7 + 1)/2 = 4.",
          "The 4th value = 14."],
         "Median = 14"),

        ("Q7.  New mean when one observation is added",
         ["Original mean of 8 observations = 25 ⇒ Sum = 8 × 25 = 200.",
          "New observation added = 33 ⇒ New sum = 200 + 33 = 233.",
          "New n = 9.  New mean = 233 / 9 ≈ 25.89."],
         "New mean ≈ 25.89"),

        ("Q8.  Mean from frequency table",
         ["Compute Σ(f·x) and Σf:",
          "(4×3) + (6×5) + (8×6) + (10×4) + (12×2) = 12 + 30 + 48 + 40 + 24 = 154.",
          "Σf = 3 + 5 + 6 + 4 + 2 = 20.",
          "Mean = Σ(f·x) / Σf = 154 / 20 = 7.7."],
         "Mean = 7.7"),

        ("Q9.  Ages of cricket players — mean, median, mode",
         ["Sum = 21+24+22+26+25+23+24+27+24+22+25+24 = 287;  n = 12.",
          "Mean = 287 / 12 ≈ 23.92 years.",
          "Sorted: 21, 22, 22, 23, 24, 24, 24, 24, 25, 25, 26, 27.",
          "Median = (6th + 7th)/2 = (24 + 24)/2 = 24.",
          "Frequency of 24 = 4 (highest). Mode = 24."],
         "Mean ≈ 23.92 yr; Median = 24 yr; Mode = 24 yr"),

        ("Q10.  Marks out of 50 — mean, median, range",
         ["Sum = 42+38+45+36+49+38+41+45+33+38 = 405;  n = 10.",
          "Mean = 405 / 10 = 40.5.",
          "Sorted: 33, 36, 38, 38, 38, 41, 42, 45, 45, 49.",
          "Median = (5th + 6th)/2 = (38 + 41)/2 = 79/2 = 39.5.",
          "Range = 49 − 33 = 16."],
         "Mean = 40.5; Median = 39.5; Range = 16"),

        ("Q11.  Grouped frequency table (width 10)",
         ["Range = 48 − 8 = 40;  Class size = 10 ⇒ 5 classes: 0–10, 10–20, 20–30, 30–40, 40–50.",
          "Counting the values: 0–10 → {8} = 1;  10–20 → {12,18,19,14,17,11} = 6;  "
          "20–30 → {25,27,22,29,26,23,21} = 7;  30–40 → {36,31,35,33,38,30} = 6;  "
          "40–50 → {42,44,48,41,46} = 5.",
          "Check: 1 + 6 + 7 + 6 + 5 = 25 ✓ (matches n = 25)."],
         "Frequencies: 1, 6, 7, 6, 5  (total 25)"),

        ("Q12.  Class mark of 30–40",
         ["Class mark = (lower + upper) / 2 = (30 + 40) / 2 = 35."],
         "(b) 35"),

        ("Q13.  Mean after removing 24",
         ["Mean of 6 numbers = 18 ⇒ Sum = 6 × 18 = 108.",
          "After removing 24: New sum = 108 − 24 = 84;  New n = 5.",
          "New mean = 84 / 5 = 16.8."],
         "New mean = 16.8"),

        ("Q14.  Mode and median",
         ["Counts: 7→4, 8→2, 9→2, 10→1, 11→3.",
          "Highest frequency = 4 (value 7). Mode = 7.",
          "n = 13 (odd). Sorted: 7,7,7,7,8,8,9,9,10,11,11,11,11... "
          "(continue: 7,7,7,7,8,8,9,9,10,11,11,11,11).",
          "Position = (13 + 1)/2 = 7 → 7th value = 9. Median = 9."],
         "Mode = 7; Median = 9"),

        ("Q15.  Median height and range",
         ["Sorted: 148, 149, 150, 151, 152, 153, 154, 155, 156.",
          "n = 9 (odd) ⇒ position = (9 + 1)/2 = 5.",
          "5th value = 152 cm. Median = 152 cm.",
          "Range = 156 − 148 = 8 cm."],
         "Median = 152 cm; Range = 8 cm"),

        ("Q16.  Find x if mean of x, x+2, x+4, x+6, x+8 is 12",
         ["Sum = x + (x+2) + (x+4) + (x+6) + (x+8) = 5x + 20.",
          "Mean = (5x + 20)/5 = x + 4.",
          "Given mean = 12 ⇒ x + 4 = 12 ⇒ x = 8."],
         "(b) 8"),

        ("Q17.  Mean wage using class marks (grouped data)",
         ["Class marks xᵢ: 225, 275, 325, 375, 425.  Frequencies fᵢ: 4, 8, 10, 6, 2.",
          "Compute fᵢ · xᵢ:",
          "4×225 = 900;  8×275 = 2200;  10×325 = 3250;  6×375 = 2250;  2×425 = 850.",
          "Σ(fᵢ · xᵢ) = 900 + 2200 + 3250 + 2250 + 850 = 9450.",
          "Σfᵢ = 4 + 8 + 10 + 6 + 2 = 30.",
          "Mean = 9450 / 30 = 315."],
         "Mean wage = ₹ 315"),

        ("Q18.  Daily temperatures — mean, median, mode, range",
         ["Data: 32, 35, 30, 34, 36, 33, 31, 35, 37, 32.  n = 10.",
          "Sum = 32+35+30+34+36+33+31+35+37+32 = 335.  Mean = 335/10 = 33.5 °C.",
          "Sorted: 30, 31, 32, 32, 33, 34, 35, 35, 36, 37.",
          "Median = (5th + 6th)/2 = (33 + 34)/2 = 67/2 = 33.5 °C.",
          "Frequencies: 32→2, 35→2, all others→1. The data has two modes: 32 and 35 → bimodal.",
          "Range = 37 − 30 = 7 °C."],
         "Mean = 33.5 °C; Median = 33.5 °C; Modes = 32 and 35 (bimodal); Range = 7 °C"),
    ]

    for q, steps, ans in sols:
        story.append(solution_box(q, steps, ans))

    # Closing key takeaways
    story.append(Spacer(1, 6))
    story.append(H2("Key Takeaways from this Practice Sheet"))
    story.append(bullet_list([
        "Always sort the data before finding the median — getting the order wrong is the most common mistake.",
        "For an even number of observations, the median is the <b>average</b> of the two middle values, not just one of them.",
        "When adding or removing an observation, recompute the new sum first, then divide by the new n.",
        "For grouped data, never use class limits in Σ(f·x) — always use the class marks (midpoints).",
        "A data set with two equally-frequent values is <b>bimodal</b> — both values are reported as modes.",
        "Range is the simplest measure of spread: Max − Min. It does not tell you anything about the middle of the data.",
    ]))
    story.append(Spacer(1, 4))
    story.append(P(
        "If you scored 14 or more out of 18 correctly, you are ready to move on "
        "to graphical representation. Otherwise, revise the corresponding sections "
        "of Material 1 before retrying the questions you missed.",
        "callout"
    ))

    return story


# ============ 6. PRACTICE 2: PROBABILITY ===============================
def build_practice_02():
    story = []
    story += H1("Practice Sheet 2 — Probability",
                "Coins, Dice, Cards, Balls & Combined Events")

    story.append(P(
        "<b>Instructions:</b> Attempt all 18 questions. For numerical answers, "
        "express probabilities as fractions in lowest terms (e.g. 1/4) unless "
        "asked otherwise. Show all working in the answer space.",
        "callout"
    ))
    story.append(Spacer(1, 6))

    GAP = Spacer(1, 10)

    # Q1 MCQ
    story.append(Paragraph("Q1. When a fair coin is tossed once, the probability "
                           "of getting a Tail is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 0   (b) 1/4   (c) 1/2   (d) 1", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q2 MCQ
    story.append(Paragraph("Q2. A die is rolled once. The probability of getting "
                           "a number greater than 6 is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 0   (b) 1/6   (c) 1/3   (d) 1", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q3 MCQ
    story.append(Paragraph("Q3. The probability of an event E always satisfies:", STYLES["qnum"]))
    story.append(Paragraph("(a) 0 &lt; P(E) &lt; 1   (b) 0 ≤ P(E) ≤ 1   "
                           "(c) −1 ≤ P(E) ≤ 1   (d) P(E) &gt; 1", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q4 MCQ
    story.append(Paragraph("Q4. If P(E) = 0.3, then P(not E) is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 0.3   (b) 0.6   (c) 0.7   (d) 1.3", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q5 numerical
    story.append(Paragraph("Q5. A die is rolled once. Find the probability of "
                           "getting (a) a prime number, (b) a number less than 3.", STYLES["qnum"]))
    story.append(answer_lines(4))
    story.append(GAP)

    # Q6 numerical
    story.append(Paragraph("Q6. Two coins are tossed together. Find the probability "
                           "of getting (a) two Heads, (b) at least one Head.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q7 word
    story.append(Paragraph("Q7. One card is drawn from a well-shuffled deck of "
                           "52 cards. Find the probability that it is (a) a Queen, "
                           "(b) a black card, (c) a number card (2 to 10).", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q8 word
    story.append(Paragraph("Q8. A bag contains 4 red, 5 white and 6 blue balls. "
                           "One ball is drawn at random. Find the probability that "
                           "the ball drawn is (a) blue, (b) not white.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q9 numerical
    story.append(Paragraph("Q9. Two dice are rolled together. Find the probability "
                           "that the sum of the numbers on them is (a) 8, (b) more than 9.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q10 word
    story.append(Paragraph("Q10. In a lottery, there are 10 prizes and 25 blanks. "
                           "A ticket is drawn at random. What is the probability "
                           "of getting a prize?", STYLES["qnum"]))
    story.append(answer_lines(4))
    story.append(GAP)

    # Q11 numerical
    story.append(Paragraph("Q11. Three coins are tossed together. Find the "
                           "probability of getting (a) exactly 2 Heads, (b) all three Tails.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q12 MCQ
    story.append(Paragraph("Q12. A die is thrown once. The probability of getting "
                           "an odd number is:", STYLES["qnum"]))
    story.append(Paragraph("(a) 1/6   (b) 1/3   (c) 1/2   (d) 2/3", STYLES["qchoice"]))
    story.append(answer_lines(3))
    story.append(GAP)

    # Q13 word
    story.append(Paragraph("Q13. A box contains 5 red marbles, 8 white marbles "
                           "and 4 green marbles. One marble is taken out at random. "
                           "What is the probability that the marble is (a) red, "
                           "(b) white, (c) not green?", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q14 numerical
    story.append(Paragraph("Q14. From a deck of 52 cards, one card is drawn. "
                           "Find the probability that it is (a) the Ace of hearts, "
                           "(b) a Jack, (c) a card of spades or clubs.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q15 word
    story.append(Paragraph("Q15. The probability of winning a game is 0.48. "
                           "What is the probability of losing the game? Justify using "
                           "the complementary-event formula.", STYLES["qnum"]))
    story.append(answer_lines(4))
    story.append(GAP)

    # Q16 numerical
    story.append(Paragraph("Q16. Two dice are thrown together. Find the probability "
                           "that the product of the two numbers on the dice is 12.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q17 word
    story.append(Paragraph("Q17. A jar has 12 cards, each bearing one of the "
                           "numbers 1 to 12. One card is drawn at random. Find the "
                           "probability that the number on the card drawn is "
                           "(a) a multiple of 4, (b) a factor of 12, (c) a prime number.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Q18 numerical
    story.append(Paragraph("Q18. A die is rolled once. Find the probability that "
                           "the number obtained is (a) even and greater than 2, "
                           "(b) odd or a multiple of 3. Give your answers as "
                           "fractions in lowest terms.", STYLES["qnum"]))
    story.append(answer_lines(5))
    story.append(GAP)

    # Self-assessment footer
    story.append(Spacer(1, 6))
    story.append(H2("Self-Assessment Checklist"))
    story.append(P(
        "Before submitting your answers, tick each box once you have done it.",
        "body_left"
    ))
    story.append(bullet_list([
        "I wrote down the sample space S for every question involving coins, dice or cards.",
        "I reduced every probability fraction to its lowest terms.",
        "I verified that 0 ≤ P(E) ≤ 1 for every answer.",
        "I checked whether ‘at least one’ or ‘exactly’ is asked — they are different.",
        "I used the complement rule P(not E) = 1 − P(E) wherever it saved time.",
    ]))
    story.append(Spacer(1, 4))
    story.append(P(
        "Score interpretation: 16–18 correct = excellent · 13–15 = good · "
        "10–12 = revise and retry · below 10 = please re-study Material 3 "
        "before attempting again.",
        "callout"
    ))

    return story


# ============ 7. PRACTICE 2 SOLUTIONS ==================================
def build_practice_02_solutions():
    story = []
    story += H1("Practice Sheet 2 — Solutions",
                "Step-by-step worked solutions · Probability")

    story.append(P(
        "<b>How to use these solutions:</b> Always write the sample space S "
        "and n(S) before computing any probability — most mistakes come from "
        "missing outcomes or double-counting. Reduce fractions to their lowest "
        "terms as the final step. If your answer is greater than 1, something "
        "has gone wrong; recheck n(E) ≤ n(S).",
        "callout"
    ))
    story.append(Spacer(1, 4))

    sols = [
        ("Q1.  P(Tail) when a fair coin is tossed once",
         ["S = {H, T},  n(S) = 2.  Favourable outcome (T) = 1.",
          "P(Tail) = 1/2."],
         "(c) 1/2"),

        ("Q2.  P(number greater than 6) on a single die",
         ["A die shows only 1, 2, 3, 4, 5, 6. No outcome is &gt; 6.",
          "Favourable outcomes = 0.",
          "P = 0/6 = 0  (impossible event)."],
         "(a) 0"),

        ("Q3.  Range of probability",
         ["By definition, probability of any event E lies between 0 and 1, inclusive."],
         "(b) 0 ≤ P(E) ≤ 1"),

        ("Q4.  Complementary probability",
         ["P(E) + P(not E) = 1  ⇒  P(not E) = 1 − P(E).",
          "P(E) = 0.3  ⇒  P(not E) = 1 − 0.3 = 0.7."],
         "(c) 0.7"),

        ("Q5.  Die rolled once — (a) prime, (b) less than 3",
         ["S = {1, 2, 3, 4, 5, 6}, n(S) = 6.",
          "(a) Primes on a die: {2, 3, 5} ⇒ n(E) = 3. P = 3/6 = 1/2.",
          "(b) Numbers &lt; 3: {1, 2} ⇒ n(E) = 2. P = 2/6 = 1/3."],
         "(a) 1/2   (b) 1/3"),

        ("Q6.  Two coins tossed — (a) two Heads, (b) at least one Head",
         ["S = {HH, HT, TH, TT}, n(S) = 4.",
          "(a) Two Heads = {HH} ⇒ P = 1/4.",
          "(b) At least one Head = {HH, HT, TH} ⇒ n(E) = 3 ⇒ P = 3/4."],
         "(a) 1/4   (b) 3/4"),

        ("Q7.  One card from 52 — Queen, black, number card",
         ["n(S) = 52.",
          "(a) Queens in a deck = 4 ⇒ P(Queen) = 4/52 = 1/13.",
          "(b) Black cards (spades + clubs) = 26 ⇒ P = 26/52 = 1/2.",
          "(c) Number cards 2 to 10 in each suit = 9 ⇒ total 9 × 4 = 36 ⇒ P = 36/52 = 9/13."],
         "(a) 1/13   (b) 1/2   (c) 9/13"),

        ("Q8.  Bag with 4 red, 5 white, 6 blue balls",
         ["Total balls = 4 + 5 + 6 = 15 ⇒ n(S) = 15.",
          "(a) Blue balls = 6 ⇒ P(blue) = 6/15 = 2/5.",
          "(b) White balls = 5 ⇒ P(white) = 5/15 = 1/3.",
          "    P(not white) = 1 − 1/3 = 2/3."],
         "(a) 2/5   (b) 2/3"),

        ("Q9.  Two dice — sum = 8, and sum &gt; 9",
         ["n(S) = 6 × 6 = 36.",
          "(a) Pairs with sum 8: (2,6),(3,5),(4,4),(5,3),(6,2) ⇒ 5 outcomes. P = 5/36.",
          "(b) Sums &gt; 9 are 10, 11, 12. Pairs: (4,6),(5,5),(6,4),(5,6),(6,5),(6,6) ⇒ 6 outcomes. P = 6/36 = 1/6."],
         "(a) 5/36   (b) 1/6"),

        ("Q10.  Lottery with 10 prizes and 25 blanks",
         ["Total tickets = 10 + 25 = 35 ⇒ n(S) = 35.",
          "Favourable (prize) = 10.",
          "P(prize) = 10/35 = 2/7."],
         "P(prize) = 2/7"),

        ("Q11.  Three coins tossed — exactly 2 Heads, all three Tails",
         ["n(S) = 2 × 2 × 2 = 8.",
          "Outcomes: HHH, HHT, HTH, HTT, THH, THT, TTH, TTT.",
          "(a) Exactly 2 Heads: {HHT, HTH, THH} ⇒ n(E) = 3 ⇒ P = 3/8.",
          "(b) All three Tails: {TTT} ⇒ n(E) = 1 ⇒ P = 1/8."],
         "(a) 3/8   (b) 1/8"),

        ("Q12.  P(odd number) on a single die",
         ["Odd numbers on a die: {1, 3, 5} ⇒ n(E) = 3, n(S) = 6.",
          "P = 3/6 = 1/2."],
         "(c) 1/2"),

        ("Q13.  Box with 5 red, 8 white, 4 green marbles",
         ["Total marbles = 5 + 8 + 4 = 17 ⇒ n(S) = 17.",
          "(a) Red = 5 ⇒ P(red) = 5/17.",
          "(b) White = 8 ⇒ P(white) = 8/17.",
          "(c) Green = 4 ⇒ P(green) = 4/17.",
          "    P(not green) = 1 − 4/17 = 13/17."],
         "(a) 5/17   (b) 8/17   (c) 13/17"),

        ("Q14.  Card from 52 — Ace of hearts, Jack, spades or clubs",
         ["n(S) = 52.",
          "(a) Ace of hearts: only 1 card ⇒ P = 1/52.",
          "(b) Jacks: 4 ⇒ P = 4/52 = 1/13.",
          "(c) Spades + clubs (all black cards) = 26 ⇒ P = 26/52 = 1/2."],
         "(a) 1/52   (b) 1/13   (c) 1/2"),

        ("Q15.  Probability of losing given P(win) = 0.48",
         ["Winning and losing are complementary events.",
          "P(win) + P(lose) = 1.",
          "P(lose) = 1 − 0.48 = 0.52."],
         "P(losing) = 0.52  (= 13/25)"),

        ("Q16.  Two dice — product equals 12",
         ["n(S) = 36.  Pairs (a, b) with a × b = 12:",
          "(2,6), (3,4), (4,3), (6,2) ⇒ 4 outcomes.",
          "P = 4/36 = 1/9."],
         "P(product = 12) = 1/9"),

        ("Q17.  12 cards numbered 1 to 12 — multiple of 4, factor of 12, prime",
         ["n(S) = 12.  Cards: {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}.",
          "(a) Multiples of 4 in 1–12: {4, 8, 12} ⇒ 3 outcomes ⇒ P = 3/12 = 1/4.",
          "(b) Factors of 12: {1, 2, 3, 4, 6, 12} ⇒ 6 outcomes ⇒ P = 6/12 = 1/2.",
          "(c) Primes in 1–12: {2, 3, 5, 7, 11} ⇒ 5 outcomes ⇒ P = 5/12."],
         "(a) 1/4   (b) 1/2   (c) 5/12"),

        ("Q18.  Die rolled once — (a) even and &gt; 2, (b) odd or multiple of 3",
         ["S = {1, 2, 3, 4, 5, 6}, n(S) = 6.",
          "(a) Even numbers: {2, 4, 6}.  Of these, &gt; 2: {4, 6} ⇒ 2 outcomes.",
          "    P(even and &gt; 2) = 2/6 = 1/3.",
          "(b) Odd numbers: {1, 3, 5}.  Multiples of 3: {3, 6}.",
          "    Union (odd or multiple of 3) = {1, 3, 5, 6} ⇒ 4 outcomes.",
          "    P = 4/6 = 2/3."],
         "(a) 1/3   (b) 2/3"),
    ]

    for q, steps, ans in sols:
        story.append(solution_box(q, steps, ans))

    # Closing key takeaways
    story.append(Spacer(1, 6))
    story.append(H2("Key Takeaways from this Practice Sheet"))
    story.append(bullet_list([
        "Always begin a probability problem by writing the sample space S and computing n(S).",
        "When two coins are tossed, the four outcomes HH, HT, TH, TT are equally likely — HT and TH are different.",
        "When two dice are thrown, there are 6 × 6 = 36 ordered pairs, not 21.",
        "A standard deck has 52 cards: 4 suits × 13 cards. Face cards (J, Q, K) total 12; honours (A, K, Q, J) total 16.",
        "Use P(not E) = 1 − P(E) whenever ‘not E’ is easier to count than E itself.",
        "Reduce all probability fractions to lowest terms before writing the final answer.",
    ]))
    story.append(Spacer(1, 4))
    story.append(P(
        "If you scored 14 or more out of 18 correctly, congratulations — you "
        "have mastered the basics of probability! Move on to combined events "
        "and conditional probability in the next chapter. Otherwise, revise "
        "Material 3 and retry the questions you missed.",
        "callout"
    ))

    return story


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------
def main():
    files = [
        # (path, doc_title, builder)
        (os.path.join(MAT_DIR,  "CH006-material-01-statistics-basics.pdf"),
         "Material 1 · Statistics Basics",       build_material_01),
        (os.path.join(MAT_DIR,  "CH006-material-02-graphical-representation.pdf"),
         "Material 2 · Graphical Representation", build_material_02),
        (os.path.join(MAT_DIR,  "CH006-material-03-probability.pdf"),
         "Material 3 · Probability",              build_material_03),
        (os.path.join(PRAC_DIR, "CH006-practice-01.pdf"),
         "Practice 1 · Statistics",               build_practice_01),
        (os.path.join(PRAC_DIR, "CH006-practice-01-solutions.pdf"),
         "Practice 1 · Solutions",                build_practice_01_solutions),
        (os.path.join(PRAC_DIR, "CH006-practice-02.pdf"),
         "Practice 2 · Probability",              build_practice_02),
        (os.path.join(PRAC_DIR, "CH006-practice-02-solutions.pdf"),
         "Practice 2 · Solutions",                build_practice_02_solutions),
    ]

    print("=" * 72)
    print("  Power Maths · CH006 Statistics & Probability — PDF generator")
    print("=" * 72)
    for path, title, builder in files:
        pages = build_pdf(path, CHAPTER_LABEL, title, builder)
        size = os.path.getsize(path) if os.path.exists(path) else 0
        rel = os.path.relpath(path, ROOT)
        print(f"  ✓ {rel:60s}  {pages:>2} pages   {size/1024:>7.1f} KB")
    print("=" * 72)
    print("  Done — 7 PDFs generated.")
    print("=" * 72)


if __name__ == "__main__":
    main()
