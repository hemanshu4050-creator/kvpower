"""
Power Maths Portal — PDF Content Module
========================================
Defines the CONTENT list — 42 PDF specs (3 materials + 2 practice + 2 solutions
per chapter × 6 chapters). Each entry has a `builder(story, is_cover)` callable
that appends ReportLab flowables to the story.

Helpers imported from pdf_gen:
  H1, H2, H3, P, Pt, Note, Formula, ExLabel, Bullets,
  problem(num, text, working_lines), problem_compact, solution_step, answer,
  objective_list, section_break, Spacer, PageBreak, KeepTogether,
  CalloutBox, HRFlowable, Table, TableStyle, CONTENT_W, mm, colors, ...
"""

from pdf_gen import (
    H1, H2, H3, P, Pt, Note, Formula, ExLabel, Bullets,
    problem, problem_compact, solution_step, answer,
    objective_list, section_break, CalloutBox,
    CONTENT_W, COL_PRIMARY, COL_ACCENT, COL_BG_TINT, COL_BG_AMBER,
    COL_BORDER, COL_TEXT, COL_MUTED, FONT_BOLD, FONT_REGULAR,
)
from reportlab.platypus import Spacer, PageBreak, KeepTogether, Table, TableStyle, HRFlowable
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import Paragraph

# Shared local styles
S_COVER_BODY = ParagraphStyle("CoverBody", fontName=FONT_REGULAR, fontSize=10.5,
    textColor=COL_TEXT, leading=15, alignment=TA_LEFT, spaceAfter=4)
S_COVER_OBJ_TITLE = ParagraphStyle("CoverObjTitle", fontName=FONT_BOLD, fontSize=11,
    textColor=COL_PRIMARY, leading=14, spaceBefore=4, spaceAfter=4)
S_INSTR = ParagraphStyle("Instr", fontName=FONT_REGULAR, fontSize=10,
    textColor=COL_TEXT, leading=14, alignment=TA_LEFT, spaceAfter=3)
S_INSTR_WARN = ParagraphStyle("InstrWarn", fontName=FONT_BOLD, fontSize=10,
    textColor=COL_ACCENT, leading=14, alignment=TA_LEFT, spaceAfter=3)

def cover_objectives(title, items):
    """Returns a list of flowables for the cover page objectives block."""
    out = []
    out.append(Paragraph(title, S_COVER_OBJ_TITLE))
    out.append(objective_list(items))
    return out

def cover_intro(text):
    return Paragraph(text, S_COVER_BODY)

def cover_instructions(items, total_marks=None, duration=None):
    """Cover-page instructions block for practice sheets / solutions."""
    out = []
    out.append(Paragraph("Instructions", S_COVER_OBJ_TITLE))
    for it in items:
        out.append(Paragraph(f"•  {it}", S_INSTR))
    if total_marks or duration:
        out.append(Spacer(1, 4))
        meta = []
        if total_marks is not None: meta.append(f"Total Marks: <b>{total_marks}</b>")
        if duration is not None: meta.append(f"Duration: <b>{duration} minutes</b>")
        out.append(Paragraph("   ·   ".join(meta), S_INSTR_WARN))
    return out

def answer_key_table(pairs):
    """Compact 2-column answer table: pairs = [(qnum, answer), ...]."""
    rows = []
    for i in range(0, len(pairs), 3):
        row = []
        for j in range(3):
            if i + j < len(pairs):
                n, a = pairs[i + j]
                row.append(Paragraph(f"<b>Q{n}.</b>", S_INSTR))
                row.append(Paragraph(str(a), S_INSTR))
            else:
                row.append("")
                row.append("")
        rows.append(row)
    tbl = Table(rows, colWidths=[CONTENT_W/6]*6)
    tbl.setStyle(TableStyle([
        ("FONTNAME", (0,0), (-1,-1), FONT_REGULAR),
        ("FONTSIZE", (0,0), (-1,-1), 9.5),
        ("TEXTCOLOR", (0,0), (-1,-1), COL_TEXT),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("BACKGROUND", (0,0), (-1,-1), COL_BG_TINT),
        ("BOX", (0,0), (-1,-1), 0.6, COL_PRIMARY),
        ("INNERGRID", (0,0), (-1,-1), 0.3, COL_BORDER),
    ]))
    return tbl


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 1 — NUMBER SYSTEM
# ══════════════════════════════════════════════════════════════════════
CH001_TITLE = "Number System"

def ch001_m1(story, is_cover):
    if is_cover:
        story.append(cover_intro("This study material introduces the building blocks of all mathematics — the different families of numbers. You will learn how natural numbers, whole numbers, integers, rationals, and irrationals fit together to form the real number system."))
        story.extend(cover_objectives("Learning Objectives", [
            "Identify and classify numbers into the correct number family",
            "Convert between fractions, decimals, and percentages",
            "Find HCF and LCM using prime factorisation and division method",
            "Understand the properties of rational and irrational numbers",
            "Apply number-system concepts to solve real-world problems",
        ]))
        return
    # Page 2 — Number families
    story.append(H1("1.  The Five Great Families of Numbers"))
    story.append(P("Every number you have ever seen belongs to one of five great families. Each family is built on top of the previous one — like the floors of a building. The ground floor is the natural numbers, and the top floor is the real numbers. Knowing which family a number belongs to tells you instantly what operations are safe to perform on it."))
    story.append(H2("1.1  Natural Numbers (N)"))
    story.append(P("The natural numbers are the counting numbers: <b>1, 2, 3, 4, 5, …</b> They are the first numbers humans ever used — to count sheep, coins, days. They have no zero, no negatives, no fractions. The set is written as <b>N = {1, 2, 3, …}</b> and goes on forever."))
    story.append(H2("1.2  Whole Numbers (W)"))
    story.append(P("Add zero to the natural numbers and you get the whole numbers: <b>0, 1, 2, 3, …</b> Zero was a profound Indian invention (around the 5th century CE). It lets us represent 'nothing' mathematically, which is essential for place-value notation, algebra, and calculus."))
    story.append(H2("1.3  Integers (Z)"))
    story.append(P("Integers extend whole numbers to include negatives: <b>… , −3, −2, −1, 0, 1, 2, 3, …</b> Negatives let us represent debts, temperatures below zero, and directions. The set is <b>Z = {…, −2, −1, 0, 1, 2, …}</b>."))
    story.append(CalloutBox("Remember the nesting",
        "N ⊂ W ⊂ Z.  Every natural number is whole; every whole number is an integer; "
        "but NOT every integer is whole (e.g. −5) and not every whole is natural (i.e. 0).",
        kind="tip"))
    story.append(H2("1.4  Rational Numbers (Q)"))
    story.append(P("A rational number is any number that can be written as a fraction <b>p/q</b> where <b>p</b> and <b>q</b> are integers and <b>q ≠ 0</b>. Examples: 3/4, −7/2, 5 (because 5 = 5/1), 0.25 (because 0.25 = 1/4), 0.333… (because it equals 1/3). The decimal either terminates or repeats."))
    story.append(Formula("Q = { p/q  :  p, q ∈ Z,  q ≠ 0 }"))
    story.append(H2("1.5  Irrational Numbers"))
    story.append(P("Irrational numbers CANNOT be written as a fraction of two integers. Their decimal expansions go on forever without repeating. Famous examples: <b>√2 ≈ 1.41421356…</b>, <b>√3 ≈ 1.732…</b>, <b>π ≈ 3.14159…</b>, <b>e ≈ 2.71828…</b>. Together, rationals + irrationals = the real numbers R."))
    story.append(PageBreak())

    # Page 3 — Decimals, fractions, percentages
    story.append(H1("2.  Fractions, Decimals, and Percentages"))
    story.append(P("These are three different costumes for the same number. Knowing how to switch between them is one of the most useful skills in school mathematics."))
    story.append(H2("2.1  Fraction → Decimal"))
    story.append(P("Divide the numerator by the denominator. If the denominator's only prime factors are 2 and 5, the decimal terminates. Otherwise it repeats."))
    story.append(ExLabel("Example 2.1"))
    story.append(P("Convert <b>7/8</b> to a decimal.  7 ÷ 8 = 0.875.  (Terminates because 8 = 2³.)"))
    story.append(P("Convert <b>5/6</b> to a decimal.  5 ÷ 6 = 0.8333… = 0.8̅3̅.  (Repeats because 6 = 2 × 3 has a factor other than 2 and 5.)"))
    story.append(H2("2.2  Decimal → Percentage"))
    story.append(P("Multiply by 100 and add the % sign.  Example: 0.875 × 100 = <b>87.5%</b>."))
    story.append(H2("2.3  Percentage → Fraction"))
    story.append(P("Write the percentage over 100, then simplify.  Example: <b>87.5% = 87.5/100 = 875/1000 = 7/8</b>."))
    story.append(CalloutBox("Three costumes, one number",
        "<b>7/8 = 0.875 = 87.5%</b>  —  all three are the same quantity. "
        "Choose the form that makes your problem easiest.",
        kind="tip"))
    story.append(H2("2.4  Comparing Fractions"))
    story.append(P("To compare fractions with different denominators, find a common denominator (the LCM), rewrite each fraction, then compare numerators. Example: which is larger, 3/4 or 5/7?  LCM(4,7) = 28.  3/4 = 21/28,  5/7 = 20/28.  So 3/4 > 5/7."))
    story.append(PageBreak())

    # Page 4 — HCF and LCM
    story.append(H1("3.  HCF and LCM"))
    story.append(P("The <b>Highest Common Factor (HCF)</b> of two numbers is the largest number that divides both exactly. The <b>Least Common Multiple (LCM)</b> is the smallest number that both divide exactly. They are the two most important tools for working with fractions."))
    story.append(H2("3.1  Prime Factorisation Method"))
    story.append(P("Break each number into prime factors. The HCF is the product of common primes (taken at their smallest power). The LCM is the product of all primes that appear (taken at their largest power)."))
    story.append(ExLabel("Example 3.1"))
    story.append(P("Find HCF and LCM of <b>36</b> and <b>60</b>."))
    story.append(P("36 = 2² × 3²  &nbsp;&nbsp;|&nbsp;&nbsp;  60 = 2² × 3 × 5"))
    story.append(P("HCF = 2² × 3 = <b>12</b> &nbsp;&nbsp;(common primes, smallest powers)"))
    story.append(P("LCM = 2² × 3² × 5 = <b>180</b> &nbsp;&nbsp;(all primes, largest powers)"))
    story.append(H2("3.2  Division Method (for HCF)"))
    story.append(P("Divide the larger by the smaller. Then divide the smaller by the remainder. Repeat until the remainder is 0 — the last divisor is the HCF."))
    story.append(ExLabel("Example 3.2 — HCF of 36 and 60 by division"))
    story.append(P("60 ÷ 36 = 1 remainder 24"))
    story.append(P("36 ÷ 24 = 1 remainder 12"))
    story.append(P("24 ÷ 12 = 2 remainder 0  →  HCF = <b>12</b> ✓"))
    story.append(H2("3.3  The Golden Relation"))
    story.append(Formula("HCF(a, b) × LCM(a, b) = a × b"))
    story.append(P("This works only for two numbers. Verify with our example: 12 × 180 = 2160, and 36 × 60 = 2160. ✓"))
    story.append(PageBreak())

    # Page 5 — Properties and the real line
    story.append(H1("4.  Properties of Rational Numbers"))
    story.append(P("Rational numbers obey most of the rules you know from arithmetic. The five big properties are:"))
    story.append(Bullets([
        "<b>Closure:</b> a + b, a − b, a × b are all rational when a, b are rational. (a ÷ b is rational too, as long as b ≠ 0.)",
        "<b>Commutative:</b> a + b = b + a, and a × b = b × a.",
        "<b>Associative:</b> (a + b) + c = a + (b + c), and (a × b) × c = a × (b × c).",
        "<b>Distributive:</b> a × (b + c) = a×b + a×c.",
        "<b>Identity:</b> 0 is the additive identity (a + 0 = a), 1 is the multiplicative identity (a × 1 = a).",
    ]))
    story.append(H2("4.1  Additive Inverse and Reciprocal"))
    story.append(P("The <b>additive inverse</b> of p/q is −p/q (they sum to 0). The <b>multiplicative inverse (reciprocal)</b> of p/q is q/p (they multiply to 1). Zero has no reciprocal because 1/0 is undefined."))
    story.append(H2("4.2  Rational Numbers on the Number Line"))
    story.append(P("Every rational number can be plotted on the number line. To plot 3/4, divide the segment from 0 to 1 into 4 equal parts and mark the third division. To plot −2.5, mark 5 equal divisions to the left of 0 — the second one is −2.5."))
    story.append(H2("4.3  Finding a Rational Between Two Rationals"))
    story.append(P("Given two rationals a and b, the number <b>(a + b) / 2</b> is always rational and lies strictly between them. You can repeat this to find as many rationals as you like between any two."))
    story.append(ExLabel("Example 4.1"))
    story.append(P("Find a rational between 1/3 and 1/2.  Answer: (1/3 + 1/2)/2 = (5/6)/2 = <b>5/12</b>. Verify: 1/3 ≈ 0.333, 5/12 ≈ 0.417, 1/2 = 0.5. ✓"))
    story.append(PageBreak())

    # Page 6 — Worked examples + summary
    story.append(H1("5.  Worked Examples"))
    story.append(ExLabel("Example 5.1"))
    story.append(P("Classify <b>√81</b>, <b>√2</b>, <b>0.</b3̅</b> (0.333…), and <b>−7</b>."))
    story.append(P("√81 = 9 (natural, whole, integer, rational).  √2 is irrational.  0.3̅ = 1/3 is rational (not integer).  −7 is an integer (rational) but not whole or natural."))
    story.append(ExLabel("Example 5.2"))
    story.append(P("Express <b>0.</b>6̅2̅</b> (0.626262…) as a fraction in lowest terms."))
    story.append(P("Let x = 0.626262…  Then 100x = 62.626262…  Subtract: 99x = 62  →  x = 62/99.  (Already in lowest terms since gcd(62, 99) = 1.)"))
    story.append(ExLabel("Example 5.3"))
    story.append(P("Two bells ring every 18 minutes and 24 minutes respectively. After how many minutes will they ring together again?"))
    story.append(P("This is an LCM problem.  18 = 2 × 3²,  24 = 2³ × 3.  LCM = 2³ × 3² = 8 × 9 = <b>72 minutes</b>."))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "Five families: N ⊂ W ⊂ Z ⊂ Q ⊂ R.  Irrationals fill the gaps in Q.",
        "Every rational is p/q (q ≠ 0).  Its decimal terminates or repeats.",
        "Fraction ↔ Decimal ↔ Percentage: three costumes, one number.",
        "HCF × LCM = product of the two numbers (only for two numbers).",
        "Properties: closure, commutative, associative, distributive, identity.",
    ]))
    story.append(Note("End of Study Material 1 — Number System.  Continue with Material 2 for operations on real numbers."))

def ch001_m2(story, is_cover):
    if is_cover:
        story.append(cover_intro("This material dives deeper into operations on real numbers — exponents, squares, square roots, cubes, and the laws that govern them. You will learn to manipulate large and small numbers effortlessly using the laws of exponents."))
        story.extend(cover_objectives("Learning Objectives", [
            "Apply the laws of exponents to simplify expressions",
            "Find squares and square roots using prime factorisation and division",
            "Estimate square roots of non-perfect squares",
            "Work with cubes and cube roots",
            "Use standard form (scientific notation) for very large/small numbers",
        ]))
        return
    # Page 2 — Laws of exponents
    story.append(H1("1.  Laws of Exponents"))
    story.append(P("Exponents (also called powers or indices) are a shorthand for repeated multiplication. <b>aⁿ</b> means a multiplied by itself n times. The laws below work for any base a, b (≠ 0) and any integer exponents m, n."))
    story.append(Formula("aᵐ × aⁿ = aᵐ⁺ⁿ  &nbsp;&nbsp;(multiply → add powers)"))
    story.append(Formula("aᵐ ÷ aⁿ = aᵐ⁻ⁿ  &nbsp;&nbsp;(divide → subtract powers)"))
    story.append(Formula("(aᵐ)ⁿ = aᵐⁿ  &nbsp;&nbsp;(power of a power → multiply)"))
    story.append(Formula("a⁰ = 1  (any non-zero base);   a⁻ⁿ = 1 / aⁿ"))
    story.append(Formula("(ab)ⁿ = aⁿbⁿ  ;   (a/b)ⁿ = aⁿ / bⁿ"))
    story.append(ExLabel("Example 1.1"))
    story.append(P("Simplify <b>2³ × 2⁴ ÷ 2⁵</b>.  Using laws: 2³⁺⁴⁻⁵ = 2² = <b>4</b>."))
    story.append(ExLabel("Example 1.2"))
    story.append(P("Simplify <b>(3⁻² × 3⁵) / 3⁰</b>.  3⁻²⁺⁵ / 1 = 3³ = <b>27</b>. (Recall 3⁰ = 1.)"))
    story.append(CalloutBox("Common Mistake",
        "aᵐ + aⁿ ≠ aᵐ⁺ⁿ.  Powers ADD only when bases are MULTIPLIED, not added. "
        "So 2³ + 2² = 8 + 4 = 12 (NOT 2⁵ = 32).",
        kind="warn"))
    story.append(PageBreak())

    # Page 3 — Squares and square roots
    story.append(H1("2.  Squares and Square Roots"))
    story.append(P("The square of a number is the number multiplied by itself: 7² = 49. A <b>perfect square</b> is a number whose square root is a whole number. The first ten perfect squares: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100."))
    story.append(H2("2.1  Square Root by Prime Factorisation"))
    story.append(ExLabel("Example 2.1 — Find √784"))
    story.append(P("784 = 2 × 392 = 2 × 2 × 196 = 2 × 2 × 2 × 98 = 2 × 2 × 2 × 2 × 49 = 2⁴ × 7²"))
    story.append(P("√784 = √(2⁴ × 7²) = 2² × 7 = 4 × 7 = <b>28</b>."))
    story.append(H2("2.2  Square Root by Long Division"))
    story.append(P("For larger numbers (or non-perfect squares), the long-division method gives the answer digit by digit. The trick: pair digits from the right, find the largest square ≤ the first pair, double the divisor at each step."))
    story.append(ExLabel("Example 2.2 — Find √5329"))
    story.append(P("Pair: 53 | 29. Largest square ≤ 53 is 49 (= 7²). Quotient so far: 7. Bring down 29. New divisor: 14_. Find x such that (140 + x)·x ≤ 529. Try x = 3: 143 × 3 = 429 ≤ 529 ✓. Try x = 4: 144 × 4 = 576 > 529 ✗. So x = 3. Quotient = <b>73</b>. Check: 73² = 5329 ✓."))
    story.append(H2("2.3  Estimating Square Roots"))
    story.append(P("To estimate √n when n is not a perfect square, find the two perfect squares it lies between, then interpolate. Example: √40 lies between √36 = 6 and √49 = 7, closer to 6. Estimate ≈ 6.3. (Actual ≈ 6.325.)"))
    story.append(PageBreak())

    # Page 4 — Cubes and cube roots
    story.append(H1("3.  Cubes and Cube Roots"))
    story.append(P("A cube is a number raised to the third power: 4³ = 4 × 4 × 4 = 64. A <b>perfect cube</b> has a whole-number cube root. First eight perfect cubes: 1, 8, 27, 64, 125, 216, 343, 512."))
    story.append(H2("3.1  Cube Root by Prime Factorisation"))
    story.append(ExLabel("Example 3.1 — Find ∛1728"))
    story.append(P("1728 = 2 × 864 = 2⁶ × 27 = 2⁶ × 3³ = (2²)³ × 3³ = 4³ × 3³ = (4 × 3)³ = 12³"))
    story.append(P("So ∛1728 = <b>12</b>.  (Sanity check: 12³ = 1728 ✓)"))
    story.append(H2("3.2  Quick Cube Tests"))
    story.append(Bullets([
        "A number ending in 0, 1, 4, 5, 6, or 9 — its cube ends in the same digit.",
        "A number ending in 2 — its cube ends in 8.  A number ending in 8 — its cube ends in 2.",
        "A number ending in 3 — its cube ends in 7.  A number ending in 7 — its cube ends in 3.",
    ]))
    story.append(H2("3.3  Cube Root of a Negative Number"))
    story.append(P("Odd powers preserve sign, so ∛(−27) = −3. (Compare with square roots: √(−9) is NOT a real number — it is imaginary.)"))
    story.append(PageBreak())

    # Page 5 — Standard form
    story.append(H1("4.  Standard Form (Scientific Notation)"))
    story.append(P("Very large and very small numbers are written in <b>standard form</b> as <b>a × 10ⁿ</b> where 1 ≤ a < 10 and n is an integer. This is how scientists avoid writing strings of zeros."))
    story.append(Formula("Standard form:  a × 10ⁿ,   1 ≤ a < 10,  n ∈ Z"))
    story.append(ExLabel("Example 4.1"))
    story.append(P("The speed of light is approximately 300,000,000 m/s. In standard form: <b>3 × 10⁸ m/s</b>."))
    story.append(ExLabel("Example 4.2"))
    story.append(P("The diameter of a red blood cell is about 0.000007 m. In standard form: <b>7 × 10⁻⁶ m</b>."))
    story.append(H2("4.1  Multiplying and Dividing in Standard Form"))
    story.append(P("Multiply the a-parts, add the powers of 10. Divide the a-parts, subtract the powers of 10. Then re-adjust if a is outside 1–10."))
    story.append(ExLabel("Example 4.3"))
    story.append(P("(3 × 10⁵) × (4 × 10³) = (3 × 4) × 10⁵⁺³ = 12 × 10⁸ = <b>1.2 × 10⁹</b>."))
    story.append(ExLabel("Example 4.4"))
    story.append(P("(8 × 10¹⁰) ÷ (2 × 10⁴) = (8/2) × 10¹⁰⁻⁴ = <b>4 × 10⁶</b>."))
    story.append(CalloutBox("Real-Life Use",
        "Distances in astronomy, sizes of cells, masses of atoms, the national debt — "
        "all are written in standard form. Mastering it makes science far less intimidating.",
        kind="tip"))
    story.append(PageBreak())

    # Page 6 — Mixed exercises + summary
    story.append(H1("5.  Worked Mixed Examples"))
    story.append(ExLabel("Example 5.1"))
    story.append(P("Simplify and write in standard form: <b>(5 × 10⁻³)² × (2 × 10⁴)</b>."))
    story.append(P("= 25 × 10⁻⁶ × 2 × 10⁴ = 50 × 10⁻² = 5.0 × 10¹ = <b>5 × 10¹</b>."))
    story.append(ExLabel("Example 5.2"))
    story.append(P("Find the smallest number by which <b>392</b> must be multiplied so that the product is a perfect cube."))
    story.append(P("392 = 2³ × 7². For a perfect cube, every prime's exponent must be a multiple of 3. The exponent of 2 is 3 ✓; the exponent of 7 is 2 ✗ — needs one more 7. So multiply by <b>7</b>. Check: 392 × 7 = 2744 = 14³ ✓."))
    story.append(ExLabel("Example 5.3"))
    story.append(P("Evaluate <b>(0.0001)⁻¹ᐟ²</b>."))
    story.append(P("0.0001 = 10⁻⁴. (10⁻⁴)⁻¹ᐟ² = 10⁻⁴ × (−1/2) = 10² = <b>100</b>."))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "Laws of exponents: multiply → add, divide → subtract, power → multiply.",
        "a⁰ = 1, a⁻ⁿ = 1/aⁿ.  Powers ADD only when bases MULTIPLY.",
        "Square root: pair digits, prime-factorise, or long-division.",
        "Cube root: triple-group digits, prime-factorise.",
        "Standard form: a × 10ⁿ with 1 ≤ a < 10.  Used everywhere in science.",
    ]))
    story.append(Note("End of Study Material 2 — Number System.  Continue with Material 3 for applications."))

def ch001_m3(story, is_cover):
    if is_cover:
        story.append(cover_intro("This third material focuses on applications of the number system: percentages, profit and loss, simple and compound interest, and word problems. These are the topics that appear most often in real life and in exams."))
        story.extend(cover_objectives("Learning Objectives", [
            "Solve percentage increase and decrease problems",
            "Calculate profit, loss, discount, and marked price",
            "Compute simple interest and compound interest",
            "Solve word problems involving ratios and proportions",
            "Apply number-system concepts to real-life situations",
        ]))
        return
    # Page 2 — Percentages
    story.append(H1("1.  Percentages in Real Life"))
    story.append(P("A percentage is a fraction out of 100. The % symbol means 'per hundred'. So 25% = 25/100 = 0.25 = 1/4. Percentages let us compare quantities on a common scale, which is why they appear in discounts, marks, interest rates, and statistics."))
    story.append(H2("1.1  Percentage Increase and Decrease"))
    story.append(Formula("Increase = New − Original ;  % Increase = (Increase / Original) × 100"))
    story.append(ExLabel("Example 1.1"))
    story.append(P("A school's enrolment grew from 800 to 920. Find the percentage increase."))
    story.append(P("Increase = 920 − 800 = 120. % Increase = (120 / 800) × 100 = <b>15%</b>."))
    story.append(ExLabel("Example 1.2"))
    story.append(P("A shirt priced at ₹800 is sold at a 15% discount. Find the selling price."))
    story.append(P("Discount = 15% of 800 = ₹120. Selling price = 800 − 120 = <b>₹680</b>."))
    story.append(H2("1.2  Reverse Percentage Problems"))
    story.append(P("If a quantity after a 20% increase is 240, what was the original? Let original = x. Then x × 1.20 = 240, so x = 240 / 1.20 = <b>200</b>."))
    story.append(CalloutBox("Watch Out",
        "A 20% increase followed by a 20% decrease does NOT return you to the original! "
        "100 → 120 → 96. The order matters and the net result is a 4% loss.",
        kind="warn"))
    story.append(PageBreak())

    # Page 3 — Profit, loss, discount
    story.append(H1("2.  Profit, Loss, and Discount"))
    story.append(P("In any sale, the <b>cost price (CP)</b> is what the shopkeeper paid; the <b>selling price (SP)</b> is what the customer pays. If SP > CP there is profit; if SP < CP there is loss."))
    story.append(Formula("Profit = SP − CP  ;  Loss = CP − SP"))
    story.append(Formula("Profit % = (Profit / CP) × 100  ;  Loss % = (Loss / CP) × 100"))
    story.append(ExLabel("Example 2.1"))
    story.append(P("A trader buys a radio for ₹600 and sells it for ₹720. Find the profit percentage."))
    story.append(P("Profit = 720 − 600 = ₹120. Profit % = (120 / 600) × 100 = <b>20%</b>."))
    story.append(H2("2.1  Marked Price and Discount"))
    story.append(P("Shopkeepers mark a price (MP) on the item, then offer a discount. <b>SP = MP − Discount</b>. Discount is usually given as a percentage of MP."))
    story.append(ExLabel("Example 2.2"))
    story.append(P("A watch is marked at ₹1,200. A 15% discount is offered. Find the SP and the profit % if the CP was ₹850."))
    story.append(P("Discount = 0.15 × 1200 = ₹180. SP = 1200 − 180 = <b>₹1,020</b>. Profit = 1020 − 850 = ₹170. Profit % = (170/850) × 100 = <b>20%</b>."))
    story.append(H2("2.2  Tax (GST) on Sales"))
    story.append(P("GST is added to the selling price. If SP = ₹1,020 and GST = 18%, then bill = 1020 × 1.18 = <b>₹1,203.60</b>."))
    story.append(PageBreak())

    # Page 4 — Simple and compound interest
    story.append(H1("3.  Simple and Compound Interest"))
    story.append(P("When you borrow money, you pay interest. <b>Simple interest (SI)</b> is calculated on the original principal only. <b>Compound interest (CI)</b> is calculated on the principal PLUS any interest already added — 'interest on interest'."))
    story.append(Formula("SI = (P × R × T) / 100   ;   Amount = P + SI"))
    story.append(Formula("CI Amount = P × (1 + R/100)ⁿ  ;  CI = Amount − P"))
    story.append(ExLabel("Example 3.1 — Simple Interest"))
    story.append(P("₹5,000 is borrowed at 8% per annum simple interest for 3 years. Find the SI and the total amount to repay."))
    story.append(P("SI = (5000 × 8 × 3) / 100 = <b>₹1,200</b>.  Total = 5000 + 1200 = <b>₹6,200</b>."))
    story.append(ExLabel("Example 3.2 — Compound Interest"))
    story.append(P("₹5,000 is invested at 8% per annum compounded annually for 3 years. Find the amount."))
    story.append(P("Amount = 5000 × (1.08)³ = 5000 × 1.259712 = <b>₹6,298.56</b>. So CI = 6298.56 − 5000 = ₹1,298.56 (compare with SI = ₹1,200 — the difference is the 'interest on interest')."))
    story.append(CalloutBox("Why CI > SI",
        "In SI, interest is earned only on the principal. In CI, each year's interest is added to the principal, "
        "so next year's interest is earned on a larger amount. Over long periods, CI grows exponentially.",
        kind="tip"))
    story.append(PageBreak())

    # Page 5 — Ratio and proportion
    story.append(H1("4.  Ratio and Proportion"))
    story.append(P("A <b>ratio</b> compares two quantities of the same kind using division. A <b>proportion</b> says two ratios are equal. If a : b = c : d, then a × d = b × c (cross-multiplication)."))
    story.append(ExLabel("Example 4.1"))
    story.append(P("The ratio of boys to girls in a class is 4 : 5. If there are 36 students, how many girls are there?"))
    story.append(P("Total parts = 4 + 5 = 9. One part = 36 / 9 = 4 students. Girls = 5 × 4 = <b>20</b>."))
    story.append(ExLabel("Example 4.2 — Direct proportion"))
    story.append(P("If 8 workers can build a wall in 15 days, how many days will 12 workers take? (Assume equal work rate.)"))
    story.append(P("More workers → fewer days (inverse proportion). 8 × 15 = 12 × d → d = (8 × 15) / 12 = <b>10 days</b>."))
    story.append(H2("4.1  Time, Speed, and Distance"))
    story.append(Formula("Distance = Speed × Time  ;  Speed = Distance / Time  ;  Time = Distance / Speed"))
    story.append(ExLabel("Example 4.3"))
    story.append(P("A train travels 360 km in 4 hours 30 minutes. Find its average speed."))
    story.append(P("Time = 4.5 hours. Speed = 360 / 4.5 = <b>80 km/h</b>."))
    story.append(PageBreak())

    # Page 6 — Mixed word problems + summary
    story.append(H1("5.  Mixed Word Problems"))
    story.append(ExLabel("Example 5.1"))
    story.append(P("A man bought an old scooter for ₹4,500 and spent ₹500 on repairs. He sold it for ₹5,800. Find his profit or loss %."))
    story.append(P("Total CP = 4500 + 500 = ₹5,000. SP = ₹5,800. Profit = ₹800. Profit % = (800/5000) × 100 = <b>16%</b>."))
    story.append(ExLabel("Example 5.2"))
    story.append(P("A sum of money doubles in 8 years at simple interest. In how many years will it become 4 times?"))
    story.append(P("To double: SI = P. So P × R × 8 / 100 = P → R = 12.5% per year. To quadruple: SI = 3P. So P × 12.5 × T / 100 = 3P → T = (3 × 100) / 12.5 = <b>24 years</b>."))
    story.append(ExLabel("Example 5.3"))
    story.append(P("The population of a town is 40,000. It increases by 10% in the first year and 5% in the second. Find the population after 2 years."))
    story.append(P("After year 1: 40000 × 1.10 = 44,000. After year 2: 44000 × 1.05 = <b>46,200</b>. (Note: not 40000 × 1.15 — successive percentage changes do not add!)"))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "% Increase = (Increase / Original) × 100.  Reverse: Original = New / (1 + %/100).",
        "Profit = SP − CP ; Profit % = (Profit / CP) × 100.",
        "SI = PRT/100.  CI Amount = P × (1 + R/100)ⁿ.  CI > SI for the same rate and time.",
        "Ratio a : b = c : d  ⇔  ad = bc.  Watch for inverse proportion.",
        "Distance = Speed × Time.  Population growth uses successive multiplication.",
    ]))
    story.append(Note("End of Study Material 3 — Number System.  Attempt Practice Sheet 1 and 2 next."))

def ch001_p1(story, is_cover):
    if is_cover:
        story.append(cover_intro("Practice Sheet 1 covers number families, fractions/decimals/percentages, HCF/LCM, and properties of rational numbers. Solve each question showing full working."))
        story.extend(cover_instructions([
            "All questions are compulsory. Show working in the space provided.",
            "Use a pencil for rough work; final answers in pen.",
            "Calculators are NOT permitted.",
            "Each question carries the marks shown in brackets.",
        ], total_marks=40, duration=60))
        return
    story.append(H1("Section A — Number Families  (10 marks)"))
    story.append(problem(1, "Classify each of the following into the smallest number family it belongs to (N, W, Z, Q, or R-irrational):  <b>(a)</b> 7  <b>(b)</b> 0  <b>(c)</b> −9  <b>(d)</b> 3/5  <b>(e)</b> √11  <b>(f)</b> √16  <b>(g)</b> 0.2̅  <b>(h)</b> π.   (5)", 3))
    story.append(problem(2, "Write three rational numbers between <b>1/4</b> and <b>1/3</b>.   (3)", 3))
    story.append(problem(3, "Express <b>0.</b>5̅4̅</b> (0.545454…) as a fraction in lowest terms.   (2)", 3))
    story.append(H1("Section B — Fractions, Decimals, Percentages  (10 marks)"))
    story.append(problem(4, "Convert and simplify:  <b>(a)</b> 7/16 to a decimal;  <b>(b)</b> 0.375 to a fraction;  <b>(c)</b> 5/8 to a percentage.   (3)", 3))
    story.append(problem(5, "Which is larger: <b>5/6</b> or <b>7/9</b>? Show your working.   (3)", 3))
    story.append(problem(6, "A fruit seller sold 60% of his 450 oranges. How many are left?   (2)", 2))
    story.append(problem(7, "A number increased by 25% gives 750. Find the original number.   (2)", 2))
    story.append(PageBreak())

    story.append(H1("Section C — HCF and LCM  (10 marks)"))
    story.append(problem(8, "Find the HCF and LCM of <b>72</b> and <b>108</b> using prime factorisation.   (4)", 4))
    story.append(problem(9, "Verify that HCF × LCM = product of the two numbers for Q8.   (2)", 2))
    story.append(problem(10, "Two ropes of lengths 8 m and 12 m are to be cut into pieces of equal length. What is the maximum possible length of each piece?   (2)", 2))
    story.append(problem(11, "Three buses leave the depot at the same time. They return every 12, 15, and 20 minutes. After how many minutes will they all be at the depot together again?   (2)", 2))
    story.append(H1("Section D — Properties of Rationals  (10 marks)"))
    story.append(problem(12, "Name the property illustrated:  <b>(a)</b> 3/5 + 0 = 3/5  <b>(b)</b> (2/7 × 3/11) = (3/11 × 2/7)  <b>(c)</b> 1/2 × (1/3 + 1/4) = 1/2 × 1/3 + 1/2 × 1/4.   (3)", 3))
    story.append(problem(13, "Find the additive inverse and the multiplicative inverse (reciprocal) of <b>−7/9</b>.   (2)", 2))
    story.append(problem(14, "Using the property (a + b)/2 between two rationals, find <b>three</b> rational numbers between <b>−1</b> and <b>1</b>.   (3)", 3))
    story.append(problem(15, "A rational number can be written as p/q. Is every integer a rational number? Justify with one example.   (2)", 2))
    story.append(Note("End of Practice Sheet 1 — Number System.  Check your answers against Solutions."))

def ch001_p1_sol(story, is_cover):
    if is_cover:
        story.append(cover_intro("Step-by-step worked solutions to Practice Sheet 1. Each solution shows the method clearly so you can identify where you went wrong."))
        story.extend(cover_instructions([
            "Compare your working with these solutions.",
            "Marks are shown in brackets for each step.",
            "If your answer differs, recheck the method, not just the final number.",
        ]))
        return
    story.append(H1("Solutions — Practice Sheet 1"))
    story.append(H2("Section A — Number Families"))
    story.append(problem_compact(1, "Classify: (a) 7  (b) 0  (c) −9  (d) 3/5  (e) √11  (f) √16  (g) 0.2̅  (h) π."))
    story.append(solution_step("(a) 7 — Natural (N)  (also W, Z, Q)"))
    story.append(solution_step("(b) 0 — Whole (W)  (also Z, Q; NOT natural)"))
    story.append(solution_step("(c) −9 — Integer (Z)  (also Q; NOT whole or natural)"))
    story.append(solution_step("(d) 3/5 — Rational (Q)  (NOT integer)"))
    story.append(solution_step("(e) √11 ≈ 3.3166… non-repeating — Irrational (R \\ Q)"))
    story.append(solution_step("(f) √16 = 4 — Natural (N)  (also W, Z, Q)"))
    story.append(solution_step("(g) 0.2̅ = 2/9 — Rational (Q)"))
    story.append(solution_step("(h) π — Irrational (R \\ Q)"))
    story.append(answer("Smallest families: (a) N  (b) W  (c) Z  (d) Q  (e) R-irrational  (f) N  (g) Q  (h) R-irrational"))
    story.append(problem_compact(2, "Three rationals between 1/4 and 1/3."))
    story.append(solution_step("1/4 = 0.25, 1/3 ≈ 0.3333. Common denominator 12: 1/4 = 3/12, 1/3 = 4/12. Use 36: 1/4 = 9/36, 1/3 = 12/36. The numbers 10/36, 11/36 lie between. To get a third, use 108: 1/4 = 27/108, 1/3 = 36/108 — pick 28/108, 31/108, 34/108."))
    story.append(answer("E.g. 7/27, 5/18, 11/36 (any three rationals strictly between 1/4 and 1/3)"))
    story.append(problem_compact(3, "0.5̅4̅ = 0.545454… as a fraction."))
    story.append(solution_step("Let x = 0.545454…  Then 100x = 54.545454…  Subtract: 99x = 54  →  x = 54/99."))
    story.append(solution_step("Simplify: gcd(54, 99) = 9. 54/99 = 6/11."))
    story.append(answer("6/11"))
    story.append(H2("Section B — Fractions, Decimals, Percentages"))
    story.append(problem_compact(4, "(a) 7/16 to decimal;  (b) 0.375 to fraction;  (c) 5/8 to %."))
    story.append(solution_step("(a) 7 ÷ 16 = 0.4375"))
    story.append(solution_step("(b) 0.375 = 375/1000 = 3/8"))
    story.append(solution_step("(c) 5/8 = 0.625 = 62.5%"))
    story.append(answer("(a) 0.4375   (b) 3/8   (c) 62.5%"))
    story.append(problem_compact(5, "5/6 vs 7/9 — which is larger?"))
    story.append(solution_step("LCM(6, 9) = 18. 5/6 = 15/18. 7/9 = 14/18. 15 > 14, so 15/18 > 14/18."))
    story.append(answer("5/6 is larger"))
    story.append(problem_compact(6, "60% of 450 oranges sold; how many left?"))
    story.append(solution_step("Sold = 0.60 × 450 = 270. Left = 450 − 270 = 180."))
    story.append(answer("180 oranges"))
    story.append(problem_compact(7, "Number + 25% = 750. Find original."))
    story.append(solution_step("Let original = x.  x × 1.25 = 750.  x = 750 / 1.25 = 600."))
    story.append(answer("600"))
    story.append(PageBreak())

    story.append(H2("Section C — HCF and LCM"))
    story.append(problem_compact(8, "HCF and LCM of 72 and 108 by prime factorisation."))
    story.append(solution_step("72 = 8 × 9 = 2³ × 3²"))
    story.append(solution_step("108 = 4 × 27 = 2² × 3³"))
    story.append(solution_step("HCF = product of common primes at SMALLEST power = 2² × 3² = 4 × 9 = 36"))
    story.append(solution_step("LCM = product of all primes at LARGEST power = 2³ × 3³ = 8 × 27 = 216"))
    story.append(answer("HCF = 36,  LCM = 216"))
    story.append(problem_compact(9, "Verify HCF × LCM = product."))
    story.append(solution_step("HCF × LCM = 36 × 216 = 7,776."))
    story.append(solution_step("72 × 108 = 7,776. ✓ Verified."))
    story.append(answer("Verified: 36 × 216 = 7,776 = 72 × 108 ✓"))
    story.append(problem_compact(10, "8 m and 12 m ropes cut into equal-length pieces — maximum length?"))
    story.append(solution_step("This is an HCF problem. HCF(8, 12) = 4."))
    story.append(answer("4 metres (8 m rope → 2 pieces, 12 m rope → 3 pieces)"))
    story.append(problem_compact(11, "Buses return every 12, 15, 20 min — together after?"))
    story.append(solution_step("LCM problem. 12 = 2² × 3; 15 = 3 × 5; 20 = 2² × 5."))
    story.append(solution_step("LCM = 2² × 3 × 5 = 60."))
    story.append(answer("60 minutes"))
    story.append(H2("Section D — Properties of Rationals"))
    story.append(problem_compact(12, "Name the property."))
    story.append(solution_step("(a) 3/5 + 0 = 3/5 — Additive identity (0 is the identity)."))
    story.append(solution_step("(b) 2/7 × 3/11 = 3/11 × 2/7 — Commutative property of multiplication."))
    story.append(solution_step("(c) 1/2 × (1/3 + 1/4) = 1/2 × 1/3 + 1/2 × 1/4 — Distributive property."))
    story.append(answer("(a) Additive identity  (b) Commutativity of ×  (c) Distributivity"))
    story.append(problem_compact(13, "Additive and multiplicative inverse of −7/9."))
    story.append(solution_step("Additive inverse (sum = 0): +7/9."))
    story.append(solution_step("Multiplicative inverse (product = 1): −9/7."))
    story.append(answer("Additive inverse = 7/9;  Reciprocal = −9/7"))
    story.append(problem_compact(14, "Three rationals between −1 and 1 using (a + b)/2."))
    story.append(solution_step("Midpoint of −1 and 1: (−1 + 1)/2 = 0. So 0 is one."))
    story.append(solution_step("Midpoint of −1 and 0: −1/2. Midpoint of 0 and 1: 1/2."))
    story.append(answer("−1/2,  0,  1/2  (or any three rationals between −1 and 1)"))
    story.append(problem_compact(15, "Is every integer rational? Justify."))
    story.append(solution_step("Yes. Any integer n can be written as n/1, which is a fraction with integer numerator and non-zero integer denominator. By definition, n is rational."))
    story.append(answer("Yes — every integer n = n/1, so n ∈ Q. E.g., −5 = −5/1."))

def ch001_p2(story, is_cover):
    if is_cover:
        story.append(cover_intro("Practice Sheet 2 covers exponents, squares, square roots, cubes, standard form, and applications (percentages, profit/loss, interest). Attempt all questions showing working."))
        story.extend(cover_instructions([
            "All questions are compulsory. Show working in the space provided.",
            "Calculators are NOT permitted.",
            "For roots, use prime factorisation or division method.",
            "Each question carries the marks shown in brackets.",
        ], total_marks=50, duration=75))
        return
    story.append(H1("Section A — Exponents  (8 marks)"))
    story.append(problem(1, "Simplify:  <b>(a)</b> 2³ × 2⁵ ÷ 2⁴  <b>(b)</b> (3²)³ × 3⁻²  <b>(c)</b> (5⁰ + 2⁻¹) × 4.   (6)", 3))
    story.append(problem(2, "Write in standard form:  <b>(a)</b> 0.000056  <b>(b)</b> 3,45,00,000.   (2)", 2))
    story.append(H1("Section B — Squares and Square Roots  (12 marks)"))
    story.append(problem(3, "Find the square root by prime factorisation: <b>1296</b>.   (3)", 3))
    story.append(problem(4, "Find the square root by long-division: <b>4225</b>.   (3)", 3))
    story.append(problem(5, "Estimate √50 to one decimal place. (Hint: √49 = 7.)   (2)", 2))
    story.append(problem(6, "Find the smallest number by which <b>180</b> must be multiplied to make it a perfect square.   (2)", 2))
    story.append(problem(7, "A square garden has area 1764 m². Find its perimeter.   (2)", 2))
    story.append(PageBreak())

    story.append(H1("Section C — Cubes and Cube Roots  (8 marks)"))
    story.append(problem(8, "Find ∛<b>2744</b> by prime factorisation.   (3)", 3))
    story.append(problem(9, "Find the smallest number by which <b>1323</b> must be divided to make it a perfect cube.   (2)", 2))
    story.append(problem(10, "Evaluate: <b>(0.2)³</b> and <b>(−4)³</b>.   (3)", 2))
    story.append(H1("Section D — Percentages, Profit/Loss, Interest  (14 marks)"))
    story.append(problem(11, "A shopkeeper bought a chair for ₹750 and sold it for ₹900. Find the profit %.   (3)", 3))
    story.append(problem(12, "A marked price of ₹2,000 is offered at a 12% discount. Find the SP and the bill amount including 18% GST.   (4)", 3))
    story.append(problem(13, "<b>₹8,000</b> is invested at <b>10% per annum simple interest</b>. Find the interest and amount after 3 years.   (3)", 3))
    story.append(problem(14, "<b>₹8,000</b> is invested at <b>10% per annum compounded annually</b>. Find the amount after 3 years. Compare with Q13.   (4)", 3))
    story.append(PageBreak())

    story.append(H1("Section E — Word Problems  (8 marks)"))
    story.append(problem(15, "Two buses leave the same stop. One returns every 15 min, the other every 20 min. After how many minutes will they next leave together?   (2)", 2))
    story.append(problem(16, "A car travels 240 km in 3 hours 45 min. Find its average speed.   (3)", 3))
    story.append(problem(17, "The population of a village is 8,000. It increases by 5% in year 1 and 10% in year 2. Find the population after 2 years.   (3)", 3))
    story.append(Note("End of Practice Sheet 2 — Number System.  Check your answers against Solutions."))

def ch001_p2_sol(story, is_cover):
    if is_cover:
        story.append(cover_intro("Step-by-step worked solutions to Practice Sheet 2 (Number System)."))
        story.extend(cover_instructions([
            "Compare each step carefully with your own working.",
            "Method marks are awarded for correct setup, not just the final answer.",
        ]))
        return
    story.append(H1("Solutions — Practice Sheet 2"))
    story.append(H2("Section A — Exponents"))
    story.append(problem_compact(1, "Simplify."))
    story.append(solution_step("(a) 2³ × 2⁵ ÷ 2⁴ = 2³⁺⁵⁻⁴ = 2⁴ = 16"))
    story.append(solution_step("(b) (3²)³ × 3⁻² = 3⁶ × 3⁻² = 3⁶⁻² = 3⁴ = 81"))
    story.append(solution_step("(c) (5⁰ + 2⁻¹) × 4 = (1 + 0.5) × 4 = 1.5 × 4 = 6"))
    story.append(answer("(a) 16   (b) 81   (c) 6"))
    story.append(problem_compact(2, "Standard form."))
    story.append(solution_step("(a) 0.000056 = 5.6 × 10⁻⁵"))
    story.append(solution_step("(b) 3,45,00,000 = 3,45,00,000 = 3.45 × 10⁷"))
    story.append(answer("(a) 5.6 × 10⁻⁵   (b) 3.45 × 10⁷"))
    story.append(H2("Section B — Squares and Square Roots"))
    story.append(problem_compact(3, "√1296 by prime factorisation."))
    story.append(solution_step("1296 = 2 × 648 = 2 × 2 × 324 = 4 × 324 = 4 × 4 × 81 = 4 × 4 × 9 × 9 = 2⁴ × 3⁴ = (2² × 3²)² = 36²"))
    story.append(answer("√1296 = 36"))
    story.append(problem_compact(4, "√4225 by long-division."))
    story.append(solution_step("Pair: 42 | 25. Largest square ≤ 42 is 36 (= 6²). Quotient = 6, remainder = 6. Bring down 25 → 625."))
    story.append(solution_step("New divisor: 12_. Find x: (120 + x) × x ≤ 625. Try x = 5: 125 × 5 = 625 ✓. So x = 5."))
    story.append(answer("√4225 = 65"))
    story.append(problem_compact(5, "Estimate √50 to one decimal."))
    story.append(solution_step("49 < 50 < 64, so 7 < √50 < 8. Midpoint ≈ 7.05. Closer to 7 because 50 − 49 = 1 (small gap)."))
    story.append(answer("√50 ≈ 7.1  (actual ≈ 7.071)"))
    story.append(problem_compact(6, "Smallest multiplier to make 180 a perfect square."))
    story.append(solution_step("180 = 2² × 3² × 5. The exponent of 5 is 1 (odd). To make it even, multiply by 5."))
    story.append(answer("5  (180 × 5 = 900 = 30²)"))
    story.append(problem_compact(7, "Square garden area 1764 m² — perimeter?"))
    story.append(solution_step("√1764 = 42 (since 42² = 1764). Side = 42 m. Perimeter = 4 × 42 = 168 m."))
    story.append(answer("168 metres"))
    story.append(PageBreak())

    story.append(H2("Section C — Cubes and Cube Roots"))
    story.append(problem_compact(8, "∛2744 by prime factorisation."))
    story.append(solution_step("2744 = 2 × 1372 = 2 × 2 × 686 = 2 × 2 × 2 × 343 = 2³ × 7³ = (2 × 7)³ = 14³"))
    story.append(answer("∛2744 = 14"))
    story.append(problem_compact(9, "Smallest divisor to make 1323 a perfect cube."))
    story.append(solution_step("1323 = 3 × 441 = 3 × 21² = 3 × 441 = 3³ × 7². Exponent of 7 is 2 (not a multiple of 3). Divide by 7² = 49 to leave 3³ = 27 = 3³."))
    story.append(answer("49  (1323 ÷ 49 = 27 = 3³)"))
    story.append(problem_compact(10, "(0.2)³ and (−4)³."))
    story.append(solution_step("(0.2)³ = 0.2 × 0.2 × 0.2 = 0.008"))
    story.append(solution_step("(−4)³ = −4 × −4 × −4 = 16 × (−4) = −64"))
    story.append(answer("(0.2)³ = 0.008 ;  (−4)³ = −64"))
    story.append(H2("Section D — Percentages, Profit/Loss, Interest"))
    story.append(problem_compact(11, "Chair CP ₹750, SP ₹900 — profit %?"))
    story.append(solution_step("Profit = 900 − 750 = ₹150. Profit % = (150/750) × 100 = 20%."))
    story.append(answer("20%"))
    story.append(problem_compact(12, "MP ₹2,000, 12% discount, 18% GST. SP and bill?"))
    story.append(solution_step("Discount = 0.12 × 2000 = ₹240. SP = 2000 − 240 = ₹1,760."))
    story.append(solution_step("GST = 0.18 × 1760 = ₹316.80. Bill = 1760 + 316.80 = ₹2,076.80."))
    story.append(answer("SP = ₹1,760 ;  Total bill = ₹2,076.80"))
    story.append(problem_compact(13, "₹8,000 at 10% SI for 3 years."))
    story.append(solution_step("SI = (P × R × T) / 100 = (8000 × 10 × 3) / 100 = ₹2,400."))
    story.append(solution_step("Amount = 8000 + 2400 = ₹10,400."))
    story.append(answer("SI = ₹2,400 ;  Amount = ₹10,400"))
    story.append(problem_compact(14, "₹8,000 at 10% CI annually for 3 years."))
    story.append(solution_step("Amount = 8000 × (1.10)³ = 8000 × 1.331 = ₹10,648."))
    story.append(solution_step("CI = 10,648 − 8,000 = ₹2,648. Compared to SI (₹2,400), CI is ₹248 more."))
    story.append(answer("Amount = ₹10,648 ;  CI = ₹2,648 (₹248 more than SI)"))
    story.append(H2("Section E — Word Problems"))
    story.append(problem_compact(15, "Buses every 15 and 20 min — together after?"))
    story.append(solution_step("LCM(15, 20) = 60."))
    story.append(answer("60 minutes"))
    story.append(problem_compact(16, "240 km in 3h 45min — average speed?"))
    story.append(solution_step("Time = 3 + 45/60 = 3.75 hours. Speed = 240 / 3.75 = 64 km/h."))
    story.append(answer("64 km/h"))
    story.append(problem_compact(17, "Population 8000, +5% then +10% — final?"))
    story.append(solution_step("Year 1: 8000 × 1.05 = 8,400."))
    story.append(solution_step("Year 2: 8400 × 1.10 = 9,240. (NOT 8000 × 1.15 = 9,200 — successive changes don't add.)"))
    story.append(answer("9,240"))


# ══════════════════════════════════════════════════════════════════════
# CHAPTER 2 — ALGEBRA BASICS
# ══════════════════════════════════════════════════════════════════════
CH002_TITLE = "Algebra Basics"

def ch002_m1(story, is_cover):
    if is_cover:
        story.append(cover_intro("This material introduces algebra — the language of symbols. You will learn what variables, expressions, terms, and like terms are, and how to add, subtract, multiply, and simplify algebraic expressions."))
        story.extend(cover_objectives("Learning Objectives", [
            "Identify variables, constants, coefficients, and terms",
            "Distinguish like and unlike terms",
            "Add, subtract, and multiply algebraic expressions",
            "Simplify expressions by combining like terms",
            "Translate word phrases into algebraic expressions",
        ]))
        return
    story.append(H1("1.  What is Algebra?"))
    story.append(P("Algebra is arithmetic with letters. A <b>variable</b> (or unknown) is a letter like x, y, a, n that stands for a number we don't know yet, or that can take many values. A <b>constant</b> is a fixed number. A <b>coefficient</b> is the number multiplying a variable."))
    story.append(ExLabel("Example 1.1"))
    story.append(P("In the expression <b>5x + 7</b>, x is the variable, 5 is the coefficient of x, 5x is a term, 7 is a constant term, and the whole thing 5x + 7 is an expression with two terms."))
    story.append(H2("1.1  Terms and Like Terms"))
    story.append(P("A <b>term</b> is a single number, a single variable, or a number × variables. <b>Like terms</b> have the same variables raised to the same powers — only their coefficients can differ. <b>Unlike terms</b> have different variables or different powers."))
    story.append(CalloutBox("Like or Unlike?",
        "<b>3x</b> and <b>−7x</b> — like terms (both are 'x').<br/>"
        "<b>5a²b</b> and <b>2ba²</b> — like terms (same variables & powers; order doesn't matter).<br/>"
        "<b>4x²</b> and <b>4x</b> — UNLIKE (powers differ).<br/>"
        "<b>6y</b> and <b>6z</b> — UNLIKE (different variables).",
        kind="tip"))
    story.append(H2("1.2  Combining Like Terms"))
    story.append(P("To simplify an expression, add (or subtract) the coefficients of like terms. The variable part stays the same. Unlike terms cannot be combined."))
    story.append(ExLabel("Example 1.2"))
    story.append(P("Simplify <b>3x + 7 − 2x + 5</b>. Group like terms: (3x − 2x) + (7 + 5) = x + 12."))
    story.append(ExLabel("Example 1.3"))
    story.append(P("Simplify <b>4a² − 3a + 2a² + 7a − 1</b>. Group: (4a² + 2a²) + (−3a + 7a) + (−1) = 6a² + 4a − 1."))
    story.append(PageBreak())

    story.append(H1("2.  Adding and Subtracting Expressions"))
    story.append(P("When adding or subtracting two expressions, write them in standard form (variables aligned) and combine like terms column-wise. Watch the signs!"))
    story.append(ExLabel("Example 2.1"))
    story.append(P("Add <b>(3x² + 5x − 7)</b> and <b>(2x² − 3x + 4)</b>."))
    story.append(P("= (3x² + 2x²) + (5x − 3x) + (−7 + 4) = 5x² + 2x − 3."))
    story.append(ExLabel("Example 2.2"))
    story.append(P("Subtract <b>(2x² − 3x + 4)</b> from <b>(3x² + 5x − 7)</b>."))
    story.append(P("= (3x² + 5x − 7) − (2x² − 3x + 4) = 3x² + 5x − 7 − 2x² + 3x − 4 = x² + 8x − 11."))
    story.append(CalloutBox("Sign Trap",
        "When subtracting an expression in brackets, EVERY term inside flips sign: "
        "−(2x² − 3x + 4) becomes −2x² + 3x − 4. The most common mistake in school algebra!",
        kind="warn"))
    story.append(H2("2.1  Vertical (Column) Method"))
    story.append(P("Arrange like terms in columns, then add or subtract column by column. This is the same as arithmetic and reduces sign errors."))
    story.append(ExLabel("Example 2.3"))
    story.append(P("Add <b>5x² + 3x − 2</b> and <b>2x² − 4x + 7</b>."))
    story.append(P("&nbsp;&nbsp;&nbsp;5x² + 3x − 2<br/>+ 2x² − 4x + 7<br/>───────────────<br/>&nbsp;&nbsp;&nbsp;7x² − x + 5"))
    story.append(PageBreak())

    story.append(H1("3.  Multiplying Algebraic Expressions"))
    story.append(H2("3.1  Multiplying a Monomial by a Polynomial"))
    story.append(P("Use the distributive law: a(b + c) = ab + ac. Multiply the monomial by each term in the bracket."))
    story.append(ExLabel("Example 3.1"))
    story.append(P("Simplify <b>3x(2x² − 5x + 1)</b>. = 3x × 2x² − 3x × 5x + 3x × 1 = 6x³ − 15x² + 3x."))
    story.append(H2("3.2  Multiplying Two Binomials — FOIL"))
    story.append(P("To multiply (a + b)(c + d), use <b>FOIL</b>: First, Outer, Inner, Last. Then combine like terms."))
    story.append(Formula("(a + b)(c + d) = ac + ad + bc + bd"))
    story.append(ExLabel("Example 3.2"))
    story.append(P("Expand <b>(x + 3)(x + 5)</b>. = x·x + x·5 + 3·x + 3·5 = x² + 5x + 3x + 15 = x² + 8x + 15."))
    story.append(ExLabel("Example 3.3"))
    story.append(P("Expand <b>(2x − 3)(x + 4)</b>. = 2x² + 8x − 3x − 12 = 2x² + 5x − 12."))
    story.append(H2("3.3  Multiplying Two Polynomials"))
    story.append(P("Multiply each term of the first by each term of the second, then collect like terms."))
    story.append(ExLabel("Example 3.4"))
    story.append(P("Expand <b>(x² + 2x − 1)(x + 3)</b>."))
    story.append(P("= x²·x + x²·3 + 2x·x + 2x·3 + (−1)·x + (−1)·3"))
    story.append(P("= x³ + 3x² + 2x² + 6x − x − 3 = x³ + 5x² + 5x − 3."))
    story.append(PageBreak())

    story.append(H1("4.  Standard Algebraic Identities"))
    story.append(P("An <b>identity</b> is an equation that is true for every value of the variable. Memorise these four — they will save you hours of multiplication."))
    story.append(Formula("I.   (a + b)² = a² + 2ab + b²"))
    story.append(Formula("II.  (a − b)² = a² − 2ab + b²"))
    story.append(Formula("III. (a + b)(a − b) = a² − b²"))
    story.append(Formula("IV.  (x + a)(x + b) = x² + (a + b)x + ab"))
    story.append(ExLabel("Example 4.1 — Using identity I"))
    story.append(P("Expand <b>(2x + 5)²</b>. Let a = 2x, b = 5. = (2x)² + 2·(2x)·5 + 5² = 4x² + 20x + 25."))
    story.append(ExLabel("Example 4.2 — Using identity III"))
    story.append(P("Evaluate <b>53 × 47</b> mentally. = (50 + 3)(50 − 3) = 50² − 3² = 2500 − 9 = 2491."))
    story.append(ExLabel("Example 4.3 — Using identity II"))
    story.append(P("Expand <b>(3x − 4)²</b>. = (3x)² − 2·(3x)·4 + 4² = 9x² − 24x + 16."))
    story.append(ExLabel("Example 4.4 — Using identity IV"))
    story.append(P("Expand <b>(x + 7)(x + 2)</b>. = x² + (7+2)x + 7·2 = x² + 9x + 14."))
    story.append(CalloutBox("Why Identities Matter",
        "They turn tedious multiplication into a one-line answer. They are also the backbone of factorisation — "
        "you factorise by RECOGNISING which identity was used to build the expression.",
        kind="tip"))
    story.append(PageBreak())

    story.append(H1("5.  Translating Words into Algebra"))
    story.append(P("Many exam questions describe a situation in words. Translating them into symbols is a key skill. Common translations:"))
    tbl = Table([
        [Paragraph("<b>Phrase</b>", S_INSTR), Paragraph("<b>Algebra</b>", S_INSTR)],
        [Paragraph("'a number'", S_INSTR), Paragraph("let it be x (or n)", S_INSTR)],
        [Paragraph("'twice a number'", S_INSTR), Paragraph("2x", S_INSTR)],
        [Paragraph("'5 more than a number'", S_INSTR), Paragraph("x + 5", S_INSTR)],
        [Paragraph("'3 less than twice a number'", S_INSTR), Paragraph("2x − 3", S_INSTR)],
        [Paragraph("'the sum of a number and 7'", S_INSTR), Paragraph("x + 7", S_INSTR)],
        [Paragraph("'the product of x and y'", S_INSTR), Paragraph("xy", S_INSTR)],
        [Paragraph("'the quotient of a and b'", S_INSTR), Paragraph("a / b", S_INSTR)],
        [Paragraph("'a number squared'", S_INSTR), Paragraph("x²", S_INSTR)],
    ], colWidths=[CONTENT_W * 0.55, CONTENT_W * 0.45])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), COL_PRIMARY),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), FONT_BOLD),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("GRID", (0,0), (-1,-1), 0.4, COL_BORDER),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, COL_BG_TINT]),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 6))
    story.append(H2("5.1  A Worked Translation"))
    story.append(P("<i>'5 less than 3 times a number is 16. Find the number.'</i>"))
    story.append(P("Let the number be x. '3 times' = 3x. '5 less than' = 3x − 5. 'is 16' = 3x − 5 = 16. Solve: 3x = 21, x = 7. ✓"))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "Variable = letter; constant = number; coefficient = number in front of variable.",
        "Like terms: same variables, same powers. Only like terms can be combined.",
        "Subtracting (a + b) reverses every sign: −(a + b) = −a − b.",
        "FOIL: (a+b)(c+d) = ac + ad + bc + bd.",
        "Four identities: (a±b)², (a+b)(a−b), (x+a)(x+b). Memorise them cold.",
    ]))
    story.append(Note("End of Study Material 1 — Algebra Basics.  Continue with Material 2 for linear equations."))

def ch002_m2(story, is_cover):
    if is_cover:
        story.append(cover_intro("This material covers linear equations in one variable — setting them up, solving them, and using them to solve word problems. Linear equations are the most-used algebra tool in school and in daily life."))
        story.extend(cover_objectives("Learning Objectives", [
            "Solve linear equations in one variable using the balance method",
            "Solve equations with variables on both sides",
            "Solve equations containing brackets and fractions",
            "Translate word problems into linear equations",
            "Verify solutions by substitution",
        ]))
        return
    story.append(H1("1.  What is a Linear Equation?"))
    story.append(P("A <b>linear equation in one variable</b> is an equation that can be written as <b>ax + b = 0</b>, where a ≠ 0. The highest power of x is 1 (that's why it's 'linear'). Examples: 3x − 5 = 7, 2(x + 4) = x + 9, (x/2) + 3 = 10. The equation has exactly one solution."))
    story.append(H2("1.1  The Balance Method"))
    story.append(P("Think of an equation as a balance. Whatever you do to one side, you MUST do to the other to keep it balanced. The goal: isolate x on one side by itself."))
    story.append(Formula("Golden Rule:  Do unto one side what you do unto the other."))
    story.append(ExLabel("Example 1.1"))
    story.append(P("Solve <b>3x − 5 = 7</b>."))
    story.append(P("Step 1: Add 5 to both sides. 3x = 12."))
    story.append(P("Step 2: Divide both sides by 3. x = 4. ✓ (Check: 3(4) − 5 = 12 − 5 = 7 ✓)"))
    story.append(ExLabel("Example 1.2"))
    story.append(P("Solve <b>2x + 7 = x − 4</b>. Variables on both sides!"))
    story.append(P("Step 1: Subtract x from both sides. x + 7 = −4."))
    story.append(P("Step 2: Subtract 7. x = −11. ✓ (Check: 2(−11) + 7 = −22 + 7 = −15; (−11) − 4 = −15 ✓)"))
    story.append(PageBreak())

    story.append(H1("2.  Equations with Brackets and Fractions"))
    story.append(H2("2.1  Brackets — Expand First"))
    story.append(ExLabel("Example 2.1"))
    story.append(P("Solve <b>3(x − 4) = 2(x + 5)</b>."))
    story.append(P("Expand: 3x − 12 = 2x + 10."))
    story.append(P("Subtract 2x: x − 12 = 10. Add 12: x = 22. ✓"))
    story.append(H2("2.2  Fractions — Clear by LCM"))
    story.append(P("If the equation has fractions, multiply EVERY term by the LCM of the denominators. This clears all fractions in one step."))
    story.append(ExLabel("Example 2.2"))
    story.append(P("Solve <b>(x/2) + (x/3) = 5</b>. LCM of 2 and 3 = 6."))
    story.append(P("Multiply every term by 6: 6·(x/2) + 6·(x/3) = 6·5  →  3x + 2x = 30  →  5x = 30  →  x = 6. ✓"))
    story.append(ExLabel("Example 2.3 — With brackets AND fractions"))
    story.append(P("Solve <b>(x − 1)/2 + (x + 2)/3 = 4</b>. LCM = 6."))
    story.append(P("Multiply by 6: 3(x − 1) + 2(x + 2) = 24."))
    story.append(P("Expand: 3x − 3 + 2x + 4 = 24  →  5x + 1 = 24  →  5x = 23  →  x = 23/5 = 4.6."))
    story.append(CalloutBox("Step Order for Hard Equations",
        "1. Clear fractions (multiply by LCM).  2. Expand brackets.  "
        "3. Collect x-terms on one side, constants on the other.  4. Divide.  5. Verify.",
        kind="tip"))
    story.append(PageBreak())

    story.append(H1("3.  Word Problems — Setting Up Equations"))
    story.append(P("Word problems are just equations wearing a costume. The trick: read twice, identify the unknown, define it as x, then translate each sentence into algebra."))
    story.append(H2("3.1  Number Problems"))
    story.append(ExLabel("Example 3.1"))
    story.append(P("<i>'The sum of two consecutive odd integers is 56. Find them.'</i>"))
    story.append(P("Let the smaller odd integer be x. The next consecutive odd integer is x + 2. Sum: x + (x + 2) = 56. 2x + 2 = 56. 2x = 54. x = 27. Numbers: <b>27 and 29</b>. ✓ (Check: 27 + 29 = 56 ✓)"))
    story.append(H2("3.2  Age Problems"))
    story.append(ExLabel("Example 3.2"))
    story.append(P("<i>'A father is 4 times as old as his son. In 20 years, he will be twice as old. Find their present ages.'</i>"))
    story.append(P("Let son's age = x. Father = 4x. In 20 years: son = x + 20, father = 4x + 20. Twice condition: 4x + 20 = 2(x + 20). 4x + 20 = 2x + 40. 2x = 20. x = 10. So son = <b>10</b>, father = <b>40</b>. ✓"))
    story.append(H2("3.3  Perimeter / Geometry Problems"))
    story.append(ExLabel("Example 3.3"))
    story.append(P("<i>'A rectangle's length is 5 cm more than its width. The perimeter is 38 cm. Find the dimensions.'</i>"))
    story.append(P("Let width = w. Length = w + 5. Perimeter = 2(L + W) = 2(w + 5 + w) = 2(2w + 5) = 4w + 10."))
    story.append(P("4w + 10 = 38. 4w = 28. w = 7. So width = <b>7 cm</b>, length = <b>12 cm</b>. ✓"))
    story.append(PageBreak())

    story.append(H1("4.  More Word Problem Types"))
    story.append(H2("4.1  Coin / Currency Problems"))
    story.append(ExLabel("Example 4.1"))
    story.append(P("<i>'A piggy bank has ₹1 and ₹2 coins totalling ₹50. There are 35 coins. How many of each?'</i>"))
    story.append(P("Let ₹1 coins = x. Then ₹2 coins = 35 − x. Total value: 1·x + 2·(35 − x) = 50."))
    story.append(P("x + 70 − 2x = 50 → −x = −20 → x = 20. So <b>20 ₹1 coins</b> and <b>15 ₹2 coins</b>. ✓ (Check: 20 + 30 = 50 ✓)"))
    story.append(H2("4.2  Speed / Distance Problems"))
    story.append(ExLabel("Example 4.2"))
    story.append(P("<i>'A car travels from A to B at 60 km/h and returns at 40 km/h. Total time is 5 hours. Find the distance A to B.'</i>"))
    story.append(P("Let distance = d. Time going = d/60. Time returning = d/40. Total: d/60 + d/40 = 5."))
    story.append(P("LCM = 120. Multiply: 2d + 3d = 600 → 5d = 600 → d = 120. Distance = <b>120 km</b>. ✓"))
    story.append(H2("4.3  Mixture Problems"))
    story.append(ExLabel("Example 4.3"))
    story.append(P("<i>'How much pure water must be added to 30 L of a 20% salt solution to make it a 10% solution?'</i>"))
    story.append(P("Salt = 0.20 × 30 = 6 L (constant). Let water added = x. New volume = 30 + x. 10% of (30 + x) = 6."))
    story.append(P("0.1(30 + x) = 6 → 30 + x = 60 → x = 30. Add <b>30 litres</b> of water. ✓"))
    story.append(PageBreak())

    story.append(H1("5.  Solving Strategy & Common Mistakes"))
    story.append(H2("5.1  A 5-Step Strategy"))
    story.append(Bullets([
        "<b>Read</b> the problem twice. Identify the unknown.",
        "<b>Define</b> the unknown as x (or another letter). Express other quantities in terms of x.",
        "<b>Translate</b> the key sentence into an equation.",
        "<b>Solve</b> the equation step-by-step.",
        "<b>Verify</b> the answer in the ORIGINAL problem (not just your equation).",
    ]))
    story.append(H2("5.2  Common Mistakes"))
    story.append(Bullets([
        "Forgetting to multiply EVERY term by the LCM (only some terms cleared).",
        "Sign errors when subtracting an expression in brackets.",
        "Solving for x but answering a different question (e.g. find the OTHER quantity).",
        "Not verifying — small arithmetic slips go unnoticed.",
    ]))
    story.append(CalloutBox("The Verification Habit",
        "Always plug your answer back into the WORDS of the problem, not your equation. "
        "If the equation was set up wrong, verifying against the equation will pass — "
        "but verifying against the words will catch the setup error.",
        kind="warn"))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "Linear eqn in 1 var: ax + b = 0 (a ≠ 0). Highest power of x = 1.",
        "Balance method: same operation on both sides.",
        "Clear fractions by multiplying every term by the LCM of denominators.",
        "Word problems: define unknown, translate, solve, verify in original words.",
        "Always verify — it catches both arithmetic and setup errors.",
    ]))
    story.append(Note("End of Study Material 2 — Algebra Basics.  Continue with Material 3 for factorisation."))

def ch002_m3(story, is_cover):
    if is_cover:
        story.append(cover_intro("This third material covers factorisation — the reverse of expansion. You will learn to split expressions into products of factors using common factors, grouping, and the standard identities. This is essential for solving quadratic equations later."))
        story.extend(cover_objectives("Learning Objectives", [
            "Factorise by taking out the highest common factor (HCF)",
            "Factorise by grouping terms",
            "Recognise and apply the difference-of-squares identity",
            "Factorise perfect-square trinomials",
            "Factorise general quadratic trinomials x² + bx + c",
        ]))
        return
    story.append(H1("1.  What is Factorisation?"))
    story.append(P("<b>Factorisation</b> is the reverse of expansion. Expansion multiplies brackets out; factorisation writes an expression as a product of brackets. For example, expansion turns (x + 2)(x + 3) into x² + 5x + 6; factorisation turns x² + 5x + 6 back into (x + 2)(x + 3)."))
    story.append(H2("1.1  Method 1 — Common Factor"))
    story.append(P("Look for the largest factor common to every term. Pull it out front."))
    story.append(ExLabel("Example 1.1"))
    story.append(P("Factorise <b>6x² + 9x</b>. Common factor = 3x. = 3x(2x + 3)."))
    story.append(ExLabel("Example 1.2"))
    story.append(P("Factorise <b>12a³b − 18a²b²</b>. Common factor = 6a²b. = 6a²b(2a − 3b)."))
    story.append(H2("1.2  Method 2 — Grouping"))
    story.append(P("When there is no common factor to ALL terms, group terms in pairs and factorise each pair."))
    story.append(ExLabel("Example 1.3"))
    story.append(P("Factorise <b>ax + ay + bx + by</b>."))
    story.append(P("Group: (ax + ay) + (bx + by) = a(x + y) + b(x + y). Now (x + y) is common. = (x + y)(a + b)."))
    story.append(ExLabel("Example 1.4"))
    story.append(P("Factorise <b>2x³ + 3x² − 2x − 3</b>."))
    story.append(P("Group: (2x³ + 3x²) + (−2x − 3) = x²(2x + 3) − 1(2x + 3) = (2x + 3)(x² − 1)."))
    story.append(P("But x² − 1 is itself factorable (difference of squares — see §3): = (2x + 3)(x + 1)(x − 1)."))
    story.append(PageBreak())

    story.append(H1("2.  Difference of Two Squares"))
    story.append(P("The identity (a + b)(a − b) = a² − b² run in reverse gives one of the most-used factorisations in school algebra."))
    story.append(Formula("a² − b² = (a + b)(a − b)"))
    story.append(ExLabel("Example 2.1"))
    story.append(P("Factorise <b>x² − 25</b>. = (x + 5)(x − 5). (Here a = x, b = 5.)"))
    story.append(ExLabel("Example 2.2"))
    story.append(P("Factorise <b>9y² − 16</b>. = (3y + 4)(3y − 4). (a = 3y, b = 4.)"))
    story.append(ExLabel("Example 2.3 — With a common factor first"))
    story.append(P("Factorise <b>2x² − 50</b>. Pull out 2 first: 2(x² − 25) = 2(x + 5)(x − 5)."))
    story.append(ExLabel("Example 2.4 — Three terms"))
    story.append(P("Factorise <b>x⁴ − 16</b>. = (x²)² − 4² = (x² + 4)(x² − 4) = (x² + 4)(x + 2)(x − 2). (x² + 4 doesn't factorise further over the reals.)"))
    story.append(CalloutBox("Spot the Pattern",
        "Whenever you see a² − (something)², the difference-of-squares factorisation applies. "
        "Look for it FIRST before trying anything else — it's the quickest win in factorisation.",
        kind="tip"))
    story.append(PageBreak())

    story.append(H1("3.  Perfect-Square Trinomials"))
    story.append(P("If the first and last terms of a trinomial are perfect squares AND the middle term is ±2 × (sqrt of first) × (sqrt of last), the trinomial is a perfect square."))
    story.append(Formula("a² + 2ab + b² = (a + b)²"))
    story.append(Formula("a² − 2ab + b² = (a − b)²"))
    story.append(ExLabel("Example 3.1"))
    story.append(P("Factorise <b>x² + 6x + 9</b>. √(x²) = x, √9 = 3, middle = 6x = 2·x·3 ✓. So = (x + 3)²."))
    story.append(ExLabel("Example 3.2"))
    story.append(P("Factorise <b>4a² − 20a + 25</b>. √(4a²) = 2a, √25 = 5, middle = 20a = 2·2a·5 ✓. So = (2a − 5)²."))
    story.append(H2("3.1  Test: Is This Trinomial a Perfect Square?"))
    story.append(Bullets([
        "Are the first and last terms perfect squares?",
        "Is the middle term ±2 × (sqrt first) × (sqrt last)?",
        "If BOTH yes, the trinomial is a perfect square. If NO to either, use Method 4 below.",
    ]))
    story.append(PageBreak())

    story.append(H1("4.  General Trinomial x² + bx + c"))
    story.append(P("When the trinomial is NOT a perfect square, look for two numbers that MULTIPLY to c (the constant) and ADD to b (the coefficient of x). Then write the factorisation as (x + p)(x + q)."))
    story.append(ExLabel("Example 4.1"))
    story.append(P("Factorise <b>x² + 7x + 12</b>. Find p, q such that p × q = 12 and p + q = 7. Pairs for 12: (1,12), (2,6), (3,4). Sum check: 3 + 4 = 7 ✓. So = (x + 3)(x + 4)."))
    story.append(ExLabel("Example 4.2 — Negative constant"))
    story.append(P("Factorise <b>x² + 2x − 15</b>. Need p × q = −15 and p + q = 2. Pairs: (5, −3) → 5 + (−3) = 2 ✓, 5 × (−3) = −15 ✓. So = (x + 5)(x − 3)."))
    story.append(ExLabel("Example 4.3 — Both negative"))
    story.append(P("Factorise <b>x² − 9x + 20</b>. Need p × q = 20 and p + q = −9. Both must be negative. Pairs: (−4, −5) → sum −9 ✓. So = (x − 4)(x − 5)."))
    story.append(CalloutBox("Sign Trick",
        "Constant positive, middle negative → both factors have '−'.  "
        "Constant negative → factors have OPPOSITE signs (one '+', one '−').  "
        "Constant positive, middle positive → both factors have '+'.",
        kind="tip"))
    story.append(H2("4.1  Trinomials with Leading Coefficient > 1"))
    story.append(P("For ax² + bx + c with a > 1, find two numbers whose product is a × c and whose sum is b. Then split the middle term and factorise by grouping."))
    story.append(ExLabel("Example 4.4"))
    story.append(P("Factorise <b>2x² + 7x + 3</b>. a × c = 6. Find numbers with product 6 and sum 7: 6 and 1. Split middle: 2x² + 6x + x + 3 = 2x(x + 3) + 1(x + 3) = (x + 3)(2x + 1)."))
    story.append(PageBreak())

    story.append(H1("5.  Mixed Practice"))
    story.append(ExLabel("Example 5.1"))
    story.append(P("Factorise <b>3x² − 12</b>. Common factor first: 3(x² − 4) = 3(x + 2)(x − 2)."))
    story.append(ExLabel("Example 5.2"))
    story.append(P("Factorise <b>x² + 10x + 25 − y²</b>. Group as (x² + 10x + 25) − y² = (x + 5)² − y². Now difference of squares: = (x + 5 + y)(x + 5 − y)."))
    story.append(ExLabel("Example 5.3"))
    story.append(P("Factorise <b>6x² + 11x − 10</b>. a × c = −60. Find numbers with product −60 and sum 11: 15 and −4. Split: 6x² + 15x − 4x − 10 = 3x(2x + 5) − 2(2x + 5) = (2x + 5)(3x − 2)."))
    story.append(H2("Chapter Summary"))
    story.append(Bullets([
        "Factorisation = reverse of expansion. Always look for the common factor FIRST.",
        "Grouping works when there's no common factor to all terms.",
        "Difference of squares: a² − b² = (a + b)(a − b). Look for this first.",
        "Perfect-square test: middle term must be ±2 × √first × √last.",
        "General trinomial x² + bx + c: find p, q with p+q=b, p×q=c.",
        "Trinomial ax² + bx + c (a>1): split middle using product a×c, sum b.",
    ]))
    story.append(Note("End of Study Material 3 — Algebra Basics.  Attempt Practice Sheet 1 and 2 next."))

def ch002_p1(story, is_cover):
    if is_cover:
        story.append(cover_intro("Practice Sheet 1 covers expressions, like terms, addition/subtraction, multiplication, and the standard identities."))
        story.extend(cover_instructions([
            "Show all working in the space provided.",
            "Calculators are NOT permitted.",
            "Each question carries the marks shown in brackets.",
        ], total_marks=40, duration=60))
        return
    story.append(H1("Section A — Expressions and Like Terms  (8 marks)"))
    story.append(problem(1, "Identify the variable, coefficient, and constant term in: <b>4x − 9</b>.   (2)", 2))
    story.append(problem(2, "List the like terms in: <b>3a + 5b − 2a + 7 − b + 4a²</b>.   (3)", 3))
    story.append(problem(3, "Simplify by combining like terms: <b>5x² − 3x + 7 − 2x² + 4x − 2</b>.   (3)", 3))
    story.append(H1("Section B — Add/Subtract Expressions  (10 marks)"))
    story.append(problem(4, "Add: <b>(3x² + 5x − 7)</b> and <b>(2x² − 3x + 4)</b>.   (3)", 3))
    story.append(problem(5, "Subtract <b>(2x² − 3x + 4)</b> from <b>(3x² + 5x − 7)</b>.   (3)", 3))
    story.append(problem(6, "Simplify: <b>(5a − 2b + 3c) − (2a + b − 4c) + (a − 3b)</b>.   (4)", 4))
    story.append(H1("Section C — Multiplication  (12 marks)"))
    story.append(problem(7, "Expand: <b>4x(2x² − 3x + 5)</b>.   (3)", 3))
    story.append(problem(8, "Expand using FOIL: <b>(x + 6)(x − 4)</b>.   (3)", 3))
    story.append(problem(9, "Expand: <b>(2x − 3)(x + 5)</b>.   (3)", 3))
    story.append(problem(10, "Expand: <b>(x² + 2x − 1)(x + 3)</b>.   (3)", 3))
    story.append(PageBreak())

    story.append(H1("Section D — Identities  (10 marks)"))
    story.append(problem(11, "Expand using identity: <b>(2x + 5)²</b>.   (2)", 2))
    story.append(problem(12, "Expand using identity: <b>(3x − 4)²</b>.   (2)", 2))
    story.append(problem(13, "Expand using identity: <b>(2x + 7)(2x − 7)</b>.   (2)", 2))
    story.append(problem(14, "Evaluate using a suitable identity: <b>52 × 48</b>.   (2)", 2))
    story.append(problem(15, "Expand: <b>(x + 5)(x + 3)</b> using identity IV.   (2)", 2))
    story.append(Note("End of Practice Sheet 1 — Algebra Basics."))

def ch002_p1_sol(story, is_cover):
    if is_cover:
        story.append(cover_intro("Worked solutions to Practice Sheet 1 (Algebra Basics)."))
        story.extend(cover_instructions(["Compare each step carefully with your own working."]))
        return
    story.append(H1("Solutions — Practice Sheet 1"))
    story.append(H2("Section A — Expressions and Like Terms"))
    story.append(problem_compact(1, "4x − 9 — identify parts."))
    story.append(answer("Variable = x; Coefficient = 4; Constant term = −9"))
    story.append(problem_compact(2, "Like terms in 3a + 5b − 2a + 7 − b + 4a²."))
    story.append(solution_step("Like terms (same variable, same power): {3a, −2a}; {5b, −b}. The 7 is constant; 4a² is alone (a², not a)."))
    story.append(answer("Like groups: (3a, −2a); (5b, −b); constants: 7; standalone: 4a²"))
    story.append(problem_compact(3, "Simplify 5x² − 3x + 7 − 2x² + 4x − 2."))
    story.append(solution_step("Group: (5x² − 2x²) + (−3x + 4x) + (7 − 2) = 3x² + x + 5."))
    story.append(answer("3x² + x + 5"))
    story.append(H2("Section B — Add/Subtract"))
    story.append(problem_compact(4, "Add (3x² + 5x − 7) + (2x² − 3x + 4)."))
    story.append(solution_step("= (3x² + 2x²) + (5x − 3x) + (−7 + 4) = 5x² + 2x − 3."))
    story.append(answer("5x² + 2x − 3"))
    story.append(problem_compact(5, "Subtract (2x² − 3x + 4) from (3x² + 5x − 7)."))
    story.append(solution_step("= (3x² + 5x − 7) − (2x² − 3x + 4) = 3x² + 5x − 7 − 2x² + 3x − 4"))
    story.append(solution_step("= (3x² − 2x²) + (5x + 3x) + (−7 − 4) = x² + 8x − 11."))
    story.append(answer("x² + 8x − 11"))
    story.append(problem_compact(6, "(5a − 2b + 3c) − (2a + b − 4c) + (a − 3b)."))
    story.append(solution_step("Remove brackets (watch signs): 5a − 2b + 3c − 2a − b + 4c + a − 3b."))
    story.append(solution_step("Group: (5a − 2a + a) + (−2b − b − 3b) + (3c + 4c) = 4a − 6b + 7c."))
    story.append(answer("4a − 6b + 7c"))
    story.append(H2("Section C — Multiplication"))
    story.append(problem_compact(7, "4x(2x² − 3x + 5)."))
    story.append(solution_step("= 4x·2x² − 4x·3x + 4x·5 = 8x³ − 12x² + 20x."))
    story.append(answer("8x³ − 12x² + 20x"))
    story.append(problem_compact(8, "(x + 6)(x − 4)."))
    story.append(solution_step("FOIL: x·x + x·(−4) + 6·x + 6·(−4) = x² − 4x + 6x − 24 = x² + 2x − 24."))
    story.append(answer("x² + 2x − 24"))
    story.append(PageBreak())

    story.append(problem_compact(9, "(2x − 3)(x + 5)."))
    story.append(solution_step("FOIL: 2x·x + 2x·5 + (−3)·x + (−3)·5 = 2x² + 10x − 3x − 15 = 2x² + 7x − 15."))
    story.append(answer("2x² + 7x − 15"))
    story.append(problem_compact(10, "(x² + 2x − 1)(x + 3)."))
    story.append(solution_step("Each term of first × each of second:"))
    story.append(solution_step("x²·x + x²·3 + 2x·x + 2x·3 + (−1)·x + (−1)·3"))
    story.append(solution_step("= x³ + 3x² + 2x² + 6x − x − 3 = x³ + 5x² + 5x − 3."))
    story.append(answer("x³ + 5x² + 5x − 3"))
    story.append(H2("Section D — Identities"))
    story.append(problem_compact(11, "(2x + 5)² — identity I."))
    story.append(solution_step("(a + b)² = a² + 2ab + b². a = 2x, b = 5."))
    story.append(solution_step("= (2x)² + 2·(2x)·5 + 5² = 4x² + 20x + 25."))
    story.append(answer("4x² + 20x + 25"))
    story.append(problem_compact(12, "(3x − 4)² — identity II."))
    story.append(solution_step("(a − b)² = a² − 2ab + b². a = 3x, b = 4."))
    story.append(solution_step("= 9x² − 24x + 16."))
    story.append(answer("9x² − 24x + 16"))
    story.append(problem_compact(13, "(2x + 7)(2x − 7) — identity III."))
    story.append(solution_step("(a + b)(a − b) = a² − b². a = 2x, b = 7."))
    story.append(solution_step("= (2x)² − 7² = 4x² − 49."))
    story.append(answer("4x² − 49"))
    story.append(problem_compact(14, "Evaluate 52 × 48."))
    story.append(solution_step("= (50 + 2)(50 − 2) = 50² − 2² = 2500 − 4 = 2496."))
    story.append(answer("2496"))
    story.append(problem_compact(15, "(x + 5)(x + 3) — identity IV."))
    story.append(solution_step("(x + a)(x + b) = x² + (a + b)x + ab. Here a = 5, b = 3."))
    story.append(solution_step("= x² + (5+3)x + 5·3 = x² + 8x + 15."))
    story.append(answer("x² + 8x + 15"))

def ch002_p2(story, is_cover):
    if is_cover:
        story.append(cover_intro("Practice Sheet 2 covers linear equations, word problems, and factorisation."))
        story.extend(cover_instructions([
            "Show all working in the space provided.",
            "Calculators are NOT permitted.",
            "Always verify your answer by substitution.",
        ], total_marks=50, duration=75))
        return
    story.append(H1("Section A — Linear Equations  (12 marks)"))
    story.append(problem(1, "Solve: <b>3x − 5 = 7</b>.   (2)", 2))
    story.append(problem(2, "Solve: <b>2x + 7 = x − 4</b>.   (2)", 2))
    story.append(problem(3, "Solve: <b>3(x − 4) = 2(x + 5)</b>.   (3)", 3))
    story.append(problem(4, "Solve: <b>(x/2) + (x/3) = 5</b>.   (3)", 3))
    story.append(problem(5, "Solve: <b>(x − 1)/2 + (x + 2)/3 = 4</b>.   (4)", 3))
    story.append(PageBreak())

    story.append(H1("Section B — Word Problems  (14 marks)"))
    story.append(problem(6, "The sum of two consecutive odd integers is 56. Find them.   (3)", 3))
    story.append(problem(7, "A father is 4 times as old as his son. In 20 years, he will be twice as old. Find their present ages.   (4)", 4))
    story.append(problem(8, "A rectangle's length is 5 cm more than its width. The perimeter is 38 cm. Find the dimensions.   (3)", 3))
    story.append(problem(9, "A piggy bank has ₹1 and ₹2 coins totalling ₹50. There are 35 coins. How many of each?   (4)", 3))
    story.append(H1("Section C — Factorisation  (16 marks)"))
    story.append(problem(10, "Factorise: <b>6x² + 9x</b>.   (2)", 2))
    story.append(problem(11, "Factorise by grouping: <b>ax + ay + bx + by</b>.   (3)", 3))
    story.append(problem(12, "Factorise: <b>x² − 25</b> and <b>9y² − 16</b>.   (3)", 3))
    story.append(problem(13, "Factorise: <b>x² + 7x + 12</b>.   (3)", 3))
    story.append(problem(14, "Factorise: <b>x² + 2x − 15</b>.   (3)", 3))
    story.append(problem(15, "Factorise: <b>2x² + 7x + 3</b> (leading coefficient > 1).   (4)", 3))
    story.append(PageBreak())

    story.append(H1("Section D — Mixed Challenge  (8 marks)"))
    story.append(problem(16, "Factorise: <b>x² + 10x + 25 − y²</b>.   (4)", 3))
    story.append(problem(17, "Solve and verify: <b>5(x − 2) = 3(x + 4) − 2</b>.   (4)", 3))
    story.append(Note("End of Practice Sheet 2 — Algebra Basics."))

def ch002_p2_sol(story, is_cover):
    if is_cover:
        story.append(cover_intro("Worked solutions to Practice Sheet 2 (Algebra Basics)."))
        story.extend(cover_instructions(["Compare each step with your working."]))
        return
    story.append(H1("Solutions — Practice Sheet 2"))
    story.append(H2("Section A — Linear Equations"))
    story.append(problem_compact(1, "3x − 5 = 7."))
    story.append(solution_step("Add 5: 3x = 12. Divide by 3: x = 4. ✓ (Check: 3·4 − 5 = 7 ✓)"))
    story.append(answer("x = 4"))
    story.append(problem_compact(2, "2x + 7 = x − 4."))
    story.append(solution_step("Subtract x: x + 7 = −4. Subtract 7: x = −11."))
    story.append(answer("x = −11  (check: 2·(−11) + 7 = −15 = (−11) − 4 ✓)"))
    story.append(problem_compact(3, "3(x − 4) = 2(x + 5)."))
    story.append(solution_step("Expand: 3x − 12 = 2x + 10. Subtract 2x: x − 12 = 10. Add 12: x = 22."))
    story.append(answer("x = 22"))
    story.append(problem_compact(4, "(x/2) + (x/3) = 5."))
    story.append(solution_step("LCM = 6. Multiply every term: 3x + 2x = 30 → 5x = 30 → x = 6."))
    story.append(answer("x = 6"))
    story.append(problem_compact(5, "(x − 1)/2 + (x + 2)/3 = 4."))
    story.append(solution_step("LCM = 6. Multiply: 3(x − 1) + 2(x + 2) = 24."))
    story.append(solution_step("Expand: 3x − 3 + 2x + 4 = 24 → 5x + 1 = 24 → 5x = 23 → x = 23/5 = 4.6."))
    story.append(answer("x = 23/5 (or 4.6)"))
    story.append(H2("Section B — Word Problems"))
    story.append(problem_compact(6, "Consecutive odd integers summing to 56."))
    story.append(solution_step("Let smaller = x; next consecutive odd = x + 2. x + (x + 2) = 56 → 2x + 2 = 56 → 2x = 54 → x = 27."))
    story.append(answer("27 and 29"))
    story.append(problem_compact(7, "Father 4× son's age; in 20 years, twice."))
    story.append(solution_step("Son = x, Father = 4x. In 20 years: 4x + 20 = 2(x + 20). 4x + 20 = 2x + 40. 2x = 20. x = 10."))
    story.append(answer("Son = 10 years; Father = 40 years"))
    story.append(problem_compact(8, "Rectangle: L = W + 5, perimeter = 38."))
    story.append(solution_step("Perimeter = 2(W + L) = 2(W + W + 5) = 2(2W + 5) = 4W + 10. 4W + 10 = 38 → W = 7. L = 12."))
    story.append(answer("Width = 7 cm; Length = 12 cm"))
    story.append(PageBreak())

    story.append(problem_compact(9, "35 coins of ₹1 and ₹2 totalling ₹50."))
    story.append(solution_step("Let ₹1 coins = x. ₹2 coins = 35 − x. Value: x + 2(35 − x) = 50."))
    story.append(solution_step("x + 70 − 2x = 50 → −x = −20 → x = 20. So 20 ₹1 coins, 15 ₹2 coins."))
    story.append(answer("20 coins of ₹1 and 15 coins of ₹2 (check: 20 + 30 = 50 ✓)"))
    story.append(H2("Section C — Factorisation"))
    story.append(problem_compact(10, "6x² + 9x."))
    story.append(solution_step("Common factor = 3x. = 3x(2x + 3)."))
    story.append(answer("3x(2x + 3)"))
    story.append(problem_compact(11, "ax + ay + bx + by."))
    story.append(solution_step("Group: (ax + ay) + (bx + by) = a(x + y) + b(x + y) = (x + y)(a + b)."))
    story.append(answer("(x + y)(a + b)"))
    story.append(problem_compact(12, "x² − 25 and 9y² − 16."))
    story.append(solution_step("Both are difference of squares."))
    story.append(solution_step("x² − 25 = (x + 5)(x − 5).  9y² − 16 = (3y + 4)(3y − 4)."))
    story.append(answer("(x + 5)(x − 5)  ;  (3y + 4)(3y − 4)"))
    story.append(problem_compact(13, "x² + 7x + 12."))
    story.append(solution_step("Find p, q: p + q = 7, p × q = 12. Pairs for 12: (1,12)=13, (2,6)=8, (3,4)=7 ✓."))
    story.append(answer("(x + 3)(x + 4)"))
    story.append(problem_compact(14, "x² + 2x − 15."))
    story.append(solution_step("Need p × q = −15, p + q = 2. Pairs: (5, −3): 5 + (−3) = 2 ✓, 5 × (−3) = −15 ✓."))
    story.append(answer("(x + 5)(x − 3)"))
    story.append(problem_compact(15, "2x² + 7x + 3."))
    story.append(solution_step("a × c = 6. Find numbers with product 6, sum 7: 6 and 1."))
    story.append(solution_step("Split middle: 2x² + 6x + x + 3 = 2x(x + 3) + 1(x + 3) = (x + 3)(2x + 1)."))
    story.append(answer("(x + 3)(2x + 1)"))
    story.append(H2("Section D — Mixed Challenge"))
    story.append(problem_compact(16, "x² + 10x + 25 − y²."))
    story.append(solution_step("Recognise x² + 10x + 25 = (x + 5)² (perfect square, since 2·x·5 = 10x)."))
    story.append(solution_step("So = (x + 5)² − y² = [(x + 5) + y][(x + 5) − y] (difference of squares)."))
    story.append(answer("(x + 5 + y)(x + 5 − y)"))
    story.append(problem_compact(17, "5(x − 2) = 3(x + 4) − 2."))
    story.append(solution_step("Expand: 5x − 10 = 3x + 12 − 2 → 5x − 10 = 3x + 10."))
    story.append(solution_step("Subtract 3x: 2x − 10 = 10. Add 10: 2x = 20. x = 10."))
    story.append(solution_step("Verify: LHS = 5·(10 − 2) = 40. RHS = 3·14 − 2 = 42 − 2 = 40 ✓."))
    story.append(answer("x = 10  (verified ✓)"))


# ══════════════════════════════════════════════════════════════════════
# CONTENT REGISTRY — chapters 1 & 2 done here; 3-6 will be added in
# pdf_content_part2.py and merged below.
# ══════════════════════════════════════════════════════════════════════
CONTENT = [
    # ─── Chapter 1: Number System ───
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"material","index":1,
     "title":"Number Families, Fractions & HCF-LCM","slug":"families-hcf-lcm","builder":ch001_m1},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"material","index":2,
     "title":"Exponents, Squares, Cubes & Standard Form","slug":"exponents-roots","builder":ch001_m2},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"material","index":3,
     "title":"Percentages, Profit-Loss & Interest","slug":"percent-applications","builder":ch001_m3},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"practice","index":1,
     "title":"Practice Sheet 1","builder":ch001_p1},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"solutions","index":1,
     "title":"Solutions — Practice Sheet 1","builder":ch001_p1_sol},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"practice","index":2,
     "title":"Practice Sheet 2","builder":ch001_p2},
    {"chapter_id":"CH001","chapter_title":CH001_TITLE,"kind":"solutions","index":2,
     "title":"Solutions — Practice Sheet 2","builder":ch001_p2_sol},

    # ─── Chapter 2: Algebra Basics ───
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"material","index":1,
     "title":"Expressions, Terms & Identities","slug":"expressions-identities","builder":ch002_m1},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"material","index":2,
     "title":"Linear Equations & Word Problems","slug":"linear-equations","builder":ch002_m2},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"material","index":3,
     "title":"Factorisation","slug":"factorisation","builder":ch002_m3},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"practice","index":1,
     "title":"Practice Sheet 1","builder":ch002_p1},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"solutions","index":1,
     "title":"Solutions — Practice Sheet 1","builder":ch002_p1_sol},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"practice","index":2,
     "title":"Practice Sheet 2","builder":ch002_p2},
    {"chapter_id":"CH002","chapter_title":CH002_TITLE,"kind":"solutions","index":2,
     "title":"Solutions — Practice Sheet 2","builder":ch002_p2_sol},
]

# ─── Append chapters 3-6 from part 2 module ───
from pdf_content_part2 import CONTENT_PART2
CONTENT.extend(CONTENT_PART2)
