#!/usr/bin/env python3
"""
Generate 2 Geometry worksheet PDFs matching the Algebra Basics sample design:
  - Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf  (questions only)
  - Power_Maths_Geometry_Worksheet_1_Solutions.pdf      (step-by-step answers)

Design (replicated from the uploaded Algebra Basics samples, which were
produced with ReportLab):
  - A4 portrait, ~1-inch margins
  - Centered header: "POWER MATHS" (bold, large)
  - Subtitle:  "Geometry - Worksheet 1: Fundamentals"  /  "... Solutions"
  - Sub-subtitle: "Practice Worksheet (Questions Only) - Class 8 to 10"
                   / "Step-by-step answers for Worksheet 1."
  - Section headers like "A. Lines & Angles" in bold
  - Questions: "Question N. <text>"
  - Solutions: "Qn: <problem>" then "Solution: <answer>"
  - Plain black-on-white minimalist layout, no colors / boxes
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, KeepTogether
)

# ──────────────────────────────────────────────────────────────────────
# Output location:  /home/z/my-project/public/practice/
# (served as static files by Next.js, consumed by the SecurePdfViewer)
# ──────────────────────────────────────────────────────────────────────
OUT_DIR = "/home/z/my-project/public/practice"
os.makedirs(OUT_DIR, exist_ok=True)


# ──────────────────────────────────────────────────────────────────────
# Geometry Worksheet 1 — content
# 5 sections (A–E) × 4 questions = 20 questions, Class 8–10 level
# ──────────────────────────────────────────────────────────────────────

WORKSHEET_TITLE = "Geometry - Worksheet 1: Fundamentals"
SOLUTIONS_TITLE = "Geometry - Worksheet 1: Solutions"
WORKSHEET_SUB = "Practice Worksheet (Questions Only) - Class 8 to 10"
SOLUTIONS_SUB = "Step-by-step answers for Worksheet 1."

# Each section: (letter, title, [(question_text, solution_text), ...])
SECTIONS = [
    ("A", "Lines & Angles", [
        ("Two angles are complementary. If one angle is 35°, find the other.",
         "35° + x = 90°  ⇒  x = 90° − 35° = 55°"),
        ("Two angles are supplementary. If one angle is 110°, find the other.",
         "110° + x = 180°  ⇒  x = 180° − 110° = 70°"),
        ("Find the measure of each angle of an equilateral triangle.",
         "All 3 angles are equal and sum to 180°, so each = 180° ÷ 3 = 60°."),
        ("Two lines intersect forming one angle of 65°. Find the other three angles.",
         "Vertically opposite angles are equal: 65° and 65°. The adjacent angles are 180° − 65° = 115° each. So the four angles are 65°, 115°, 65°, 115°."),
    ]),
    ("B", "Triangles", [
        ("In a right-angled triangle, the two legs are 3 cm and 4 cm. Find the hypotenuse.",
         "h² = 3² + 4² = 9 + 16 = 25  ⇒  h = √25 = 5 cm"),
        ("The angles of a triangle are in the ratio 2 : 3 : 4. Find each angle.",
         "Sum of parts = 2 + 3 + 4 = 9. One part = 180° ÷ 9 = 20°. Angles = 40°, 60°, 80°."),
        ("Two sides of a triangle are 5 cm and 8 cm. The included angle is 90°. Find the third side.",
         "Third side (hypotenuse) = √(5² + 8²) = √(25 + 64) = √89 ≈ 9.43 cm"),
        ("Find the perimeter of an isosceles triangle with equal sides 7 cm and base 10 cm.",
         "Perimeter = 7 + 7 + 10 = 24 cm"),
    ]),
    ("C", "Quadrilaterals & Polygons", [
        ("Find the sum of the interior angles of a hexagon (6 sides).",
         "Sum = (n − 2) × 180° = (6 − 2) × 180° = 4 × 180° = 720°"),
        ("Find each interior angle of a regular pentagon (5 sides).",
         "Each angle = (n − 2) × 180° ÷ n = (5 − 2) × 180° ÷ 5 = 540° ÷ 5 = 108°"),
        ("The three angles of a quadrilateral are 75°, 110° and 95°. Find the fourth angle.",
         "Sum of quadrilateral = 360°. Fourth angle = 360° − (75° + 110° + 95°) = 360° − 280° = 80°"),
        ("Find the perimeter of a rectangle with length 12 cm and breadth 7 cm.",
         "Perimeter = 2 × (l + b) = 2 × (12 + 7) = 2 × 19 = 38 cm"),
    ]),
    ("D", "Circles", [
        ("Find the circumference of a circle with radius 14 cm. (Use π = 22/7)",
         "C = 2πr = 2 × (22/7) × 14 = 2 × 22 × 2 = 88 cm"),
        ("Find the area of a circle with radius 7 cm. (Use π = 22/7)",
         "A = πr² = (22/7) × 7 × 7 = 22 × 7 = 154 cm²"),
        ("The diameter of a circle is 20 cm. Find its radius and circumference. (Use π = 3.14)",
         "r = d ÷ 2 = 20 ÷ 2 = 10 cm. C = πd = 3.14 × 20 = 62.8 cm"),
        ("Find the length of an arc that subtends 90° at the centre of a circle of radius 21 cm. (Use π = 22/7)",
         "Arc = (θ/360°) × 2πr = (90°/360°) × 2 × (22/7) × 21 = (1/4) × 2 × 22 × 3 = (1/4) × 132 = 33 cm"),
    ]),
    ("E", "Challenge", [
        ("Find the area of a triangle with base 12 cm and height 5 cm.",
         "A = (1/2) × b × h = (1/2) × 12 × 5 = 30 cm²"),
        ("A square and a rectangle have the same perimeter of 40 cm. The rectangle is 12 cm long. Whose area is larger?",
         "Square side = 40 ÷ 4 = 10 cm, area = 100 cm². Rectangle breadth = (40 ÷ 2) − 12 = 8 cm, area = 12 × 8 = 96 cm². The square has the larger area (100 > 96)."),
        ("Find the area of a parallelogram with base 9 cm and height 6 cm.",
         "A = base × height = 9 × 6 = 54 cm²"),
        ("The radius of a circle is doubled. By what factor does its area change?",
         "A = πr². If r becomes 2r, new A = π(2r)² = 4πr². The area becomes 4 times the original."),
    ]),
]


# ──────────────────────────────────────────────────────────────────────
# Styles  (match the minimalist black-on-white sample design)
# ──────────────────────────────────────────────────────────────────────

styles = {
    "title": ParagraphStyle(
        "title", fontName="Helvetica-Bold", fontSize=24,
        alignment=TA_CENTER, spaceAfter=6, leading=28,
    ),
    "subtitle": ParagraphStyle(
        "subtitle", fontName="Helvetica", fontSize=16,
        alignment=TA_CENTER, spaceAfter=4, leading=20,
    ),
    "subsubtitle": ParagraphStyle(
        "subsubtitle", fontName="Helvetica", fontSize=12,
        alignment=TA_CENTER, spaceAfter=18, leading=15,
    ),
    "section": ParagraphStyle(
        "section", fontName="Helvetica-Bold", fontSize=14,
        alignment=TA_LEFT, spaceBefore=12, spaceAfter=6, leading=17,
    ),
    "question": ParagraphStyle(
        "question", fontName="Helvetica", fontSize=12,
        alignment=TA_LEFT, spaceAfter=6, leading=15,
    ),
    "qhead": ParagraphStyle(
        "qhead", fontName="Helvetica-Bold", fontSize=12,
        alignment=TA_LEFT, spaceBefore=6, spaceAfter=2, leading=15,
    ),
    "solution": ParagraphStyle(
        "solution", fontName="Helvetica", fontSize=12,
        alignment=TA_LEFT, spaceAfter=8, leading=15,
    ),
}


def build_fundamentals(path: str) -> None:
    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=25 * mm, rightMargin=25 * mm,
        topMargin=25 * mm, bottomMargin=25 * mm,
        title="Power Maths - Geometry Worksheet 1: Fundamentals",
        author="Prof. Kalpesh Vyas",
    )
    story = []
    story.append(Paragraph("POWER MATHS", styles["title"]))
    story.append(Paragraph(WORKSHEET_TITLE, styles["subtitle"]))
    story.append(Paragraph(WORKSHEET_SUB, styles["subsubtitle"]))

    qnum = 0
    for letter, title, items in SECTIONS:
        story.append(Paragraph(f"{letter}. {title}", styles["section"]))
        for qtext, _ in items:
            qnum += 1
            story.append(Paragraph(f"Question {qnum}. {qtext}", styles["question"]))
    doc.build(story)


def build_solutions(path: str) -> None:
    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=25 * mm, rightMargin=25 * mm,
        topMargin=25 * mm, bottomMargin=25 * mm,
        title="Power Maths - Geometry Worksheet 1: Solutions",
        author="Prof. Kalpesh Vyas",
    )
    story = []
    story.append(Paragraph("POWER MATHS", styles["title"]))
    story.append(Paragraph(SOLUTIONS_TITLE, styles["subtitle"]))
    story.append(Paragraph(SOLUTIONS_SUB, styles["subsubtitle"]))

    qnum = 0
    for letter, title, items in SECTIONS:
        story.append(Paragraph(f"{letter}. {title}", styles["section"]))
        for qtext, sol in items:
            qnum += 1
            block = [
                Paragraph(f"Q{qnum}: {qtext}", styles["qhead"]),
                Paragraph(f"Solution: {sol}", styles["solution"]),
            ]
            story.append(KeepTogether(block))
    doc.build(story)


if __name__ == "__main__":
    fund_path = os.path.join(OUT_DIR, "Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf")
    sol_path = os.path.join(OUT_DIR, "Power_Maths_Geometry_Worksheet_1_Solutions.pdf")
    build_fundamentals(fund_path)
    build_solutions(sol_path)
    print(f"✓ Generated {fund_path}")
    print(f"✓ Generated {sol_path}")
    print(f"  Fundamentals: {os.path.getsize(fund_path)} bytes")
    print(f"  Solutions:    {os.path.getsize(sol_path)} bytes")
