#!/usr/bin/env python3
"""
Generate 7 educational PDFs for CH004 Trigonometry chapter of Power Maths.

Files generated (A4, 5-6 pages each):
  /home/z/my-project/public/materials/CH004-material-01-trig-ratios.pdf
  /home/z/my-project/public/materials/CH004-material-02-trig-identities.pdf
  /home/z/my-project/public/materials/CH004-material-03-applications.pdf
  /home/z/my-project/public/practice/CH004-practice-01.pdf
  /home/z/my-project/public/practice/CH004-practice-01-solutions.pdf
  /home/z/my-project/public/practice/CH004-practice-02.pdf
  /home/z/my-project/public/practice/CH004-practice-02-solutions.pdf
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table,
    TableStyle, KeepTogether, PageBreak, NextPageTemplate, ListFlowable,
    ListItem, HRFlowable, CondPageBreak,
)
from reportlab.platypus.flowables import Flowable
from reportlab.pdfgen import canvas

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
BASE_DIR    = "/home/z/my-project/public"
MATERIALS_DIR = os.path.join(BASE_DIR, "materials")
PRACTICE_DIR  = os.path.join(BASE_DIR, "practice")
os.makedirs(MATERIALS_DIR, exist_ok=True)
os.makedirs(PRACTICE_DIR,  exist_ok=True)

PAGE_W, PAGE_H = A4              # 595.27 x 841.89 pt
MARGIN_L = 18 * mm
MARGIN_R = 18 * mm
MARGIN_T = 22 * mm
MARGIN_B = 20 * mm

# Brand palette — dark slate / teal / emerald (NO blue / indigo)
COLOR_PRIMARY    = HexColor("#0f766e")   # teal-700
COLOR_DARK       = HexColor("#134e4a")   # teal-900 (slate-teal)
COLOR_ACCENT     = HexColor("#059669")   # emerald-600
COLOR_ACCENT_SOFT= HexColor("#10b981")   # emerald-500
COLOR_TEXT       = HexColor("#1f2937")   # gray-800
COLOR_MUTED      = HexColor("#64748b")   # slate-500
COLOR_EXAMPLE_BG = HexColor("#f1f5f9")   # slate-100 (light gray box)
COLOR_EXAMPLE_BD = HexColor("#cbd5e1")   # slate-300
COLOR_TABLE_HEAD = HexColor("#0f766e")   # teal-700
COLOR_TABLE_ALT  = HexColor("#f8fafc")   # slate-50
COLOR_ANSWER_HI  = HexColor("#fef3c7")   # amber-100 highlight for final answer

FOOTER_TEXT = "© Power Maths · Prof. Kalpesh Vyas · For enrolled students only"
HEADER_BRAND = "Power Maths · Trigonometry"
HEADER_AUTHOR = "by Prof. Kalpesh Vyas"

# ---------------------------------------------------------------------------
# Paragraph styles
# ---------------------------------------------------------------------------
ss = getSampleStyleSheet()

STY_TITLE = ParagraphStyle(
    "Title", parent=ss["Title"], fontName="Helvetica-Bold",
    fontSize=22, leading=26, textColor=COLOR_DARK,
    alignment=TA_LEFT, spaceAfter=4,
)
STY_SUBTITLE = ParagraphStyle(
    "Subtitle", parent=ss["Normal"], fontName="Helvetica",
    fontSize=12, leading=16, textColor=COLOR_PRIMARY,
    alignment=TA_LEFT, spaceAfter=10,
)
STY_H1 = ParagraphStyle(
    "H1", parent=ss["Heading1"], fontName="Helvetica-Bold",
    fontSize=15, leading=19, textColor=COLOR_DARK,
    alignment=TA_LEFT, spaceBefore=10, spaceAfter=6,
)
STY_H2 = ParagraphStyle(
    "H2", parent=ss["Heading2"], fontName="Helvetica-Bold",
    fontSize=12.5, leading=16, textColor=COLOR_PRIMARY,
    alignment=TA_LEFT, spaceBefore=8, spaceAfter=4,
)
STY_BODY = ParagraphStyle(
    "Body", parent=ss["Normal"], fontName="Helvetica",
    fontSize=11, leading=17, textColor=COLOR_TEXT,
    alignment=TA_JUSTIFY, spaceAfter=7,
)
STY_BODY_L = ParagraphStyle(
    "BodyLeft", parent=STY_BODY, alignment=TA_LEFT,
)
STY_BULLET = ParagraphStyle(
    "Bullet", parent=STY_BODY, leftIndent=14, bulletIndent=2,
    spaceAfter=3, alignment=TA_LEFT,
)
STY_EXAMPLE = ParagraphStyle(
    "Example", parent=STY_BODY, fontName="Helvetica",
    fontSize=10.5, leading=15.5, textColor=COLOR_TEXT,
    alignment=TA_LEFT, spaceAfter=4,
)
STY_EXAMPLE_LABEL = ParagraphStyle(
    "ExampleLabel", parent=ss["Normal"], fontName="Helvetica-Bold",
    fontSize=10.5, leading=14, textColor=COLOR_DARK,
    alignment=TA_LEFT, spaceAfter=2,
)
STY_TABLE_HEAD = ParagraphStyle(
    "TableHead", parent=ss["Normal"], fontName="Helvetica-Bold",
    fontSize=10.5, leading=13, textColor=white, alignment=TA_CENTER,
)
STY_TABLE_CELL = ParagraphStyle(
    "TableCell", parent=ss["Normal"], fontName="Helvetica",
    fontSize=10.5, leading=13, textColor=COLOR_TEXT, alignment=TA_CENTER,
)
STY_TABLE_CELL_L = ParagraphStyle(
    "TableCellL", parent=STY_TABLE_CELL, alignment=TA_LEFT,
)
STY_Q = ParagraphStyle(
    "Question", parent=STY_BODY, fontName="Helvetica",
    fontSize=11, leading=16, textColor=COLOR_TEXT,
    alignment=TA_LEFT, spaceAfter=4,
)
STY_QNUM = ParagraphStyle(
    "QNum", parent=ss["Normal"], fontName="Helvetica-Bold",
    fontSize=11, leading=16, textColor=COLOR_PRIMARY, alignment=TA_LEFT,
)
STY_ANSWER_SPACE = ParagraphStyle(
    "AnswerSpace", parent=ss["Normal"], fontName="Helvetica",
    fontSize=10, leading=14, textColor=COLOR_MUTED, alignment=TA_LEFT,
)
STY_SOLUTION_STEP = ParagraphStyle(
    "SolutionStep", parent=STY_BODY, fontName="Helvetica",
    fontSize=10.5, leading=16.5, textColor=COLOR_TEXT,
    alignment=TA_LEFT, spaceAfter=5, leftIndent=10,
)
STY_FINAL = ParagraphStyle(
    "Final", parent=ss["Normal"], fontName="Helvetica-Bold",
    fontSize=11, leading=15, textColor=COLOR_DARK, alignment=TA_LEFT,
    backColor=COLOR_ANSWER_HI, borderPadding=4, spaceAfter=8, leftIndent=10,
)
STY_FOOTER = ParagraphStyle(
    "Footer", parent=ss["Normal"], fontName="Helvetica",
    fontSize=8.5, leading=11, textColor=COLOR_MUTED, alignment=TA_CENTER,
)
STY_NOTE = ParagraphStyle(
    "Note", parent=STY_BODY, fontName="Helvetica-Oblique",
    fontSize=10.5, leading=15, textColor=COLOR_MUTED,
    leftIndent=10, spaceAfter=6,
)

# ---------------------------------------------------------------------------
# Header / footer drawing
# ---------------------------------------------------------------------------
class HeaderFooterCanvas(canvas.Canvas):
    """Canvas that draws the brand header band and footer on every page,
    plus 'Page X of Y' using a two-pass save trick."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total_pages = len(self._saved_page_states)
        for i, state in enumerate(self._saved_page_states):
            self.__dict__.update(state)
            self._draw_header_footer(i + 1, total_pages)
            super().showPage()
        super().save()

    def _draw_header_footer(self, page_num, total_pages):
        # Top brand band
        band_h = 14 * mm
        self.setFillColor(COLOR_DARK)
        self.rect(0, PAGE_H - band_h, PAGE_W, band_h, stroke=0, fill=1)
        # accent thin line under band
        self.setFillColor(COLOR_ACCENT)
        self.rect(0, PAGE_H - band_h - 1.4, PAGE_W, 1.4, stroke=0, fill=1)
        # Brand text (left)
        self.setFillColor(white)
        self.setFont("Helvetica-Bold", 10.5)
        self.drawString(MARGIN_L, PAGE_H - band_h + 4.5, HEADER_BRAND)
        # Author (right)
        self.setFont("Helvetica", 9)
        self.drawRightString(PAGE_W - MARGIN_R, PAGE_H - band_h + 5,
                             HEADER_AUTHOR)

        # Footer
        footer_y = 10 * mm
        self.setStrokeColor(COLOR_EXAMPLE_BD)
        self.setLineWidth(0.5)
        self.line(MARGIN_L, footer_y + 8, PAGE_W - MARGIN_R, footer_y + 8)
        self.setFont("Helvetica", 8.5)
        self.setFillColor(COLOR_MUTED)
        self.drawCentredString(PAGE_W / 2, footer_y, FOOTER_TEXT)
        # page number, right-aligned under line
        self.setFont("Helvetica-Bold", 9)
        self.setFillColor(COLOR_PRIMARY)
        self.drawRightString(PAGE_W - MARGIN_R, footer_y,
                             f"Page {page_num} of {total_pages}")
        # chapter chip, left-aligned
        self.setFont("Helvetica", 8.5)
        self.setFillColor(COLOR_MUTED)
        self.drawString(MARGIN_L, footer_y, "CH004 · Trigonometry")


def build_doc(path, title_flowables):
    """Create a BaseDocTemplate with one Frame and the HeaderFooterCanvas."""
    frame = Frame(
        MARGIN_L, MARGIN_B,
        PAGE_W - MARGIN_L - MARGIN_R,
        PAGE_H - MARGIN_T - MARGIN_B - 4 * mm,  # leave space for header band + footer
        leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
        showBoundary=0,
    )
    template = PageTemplate(id="main", frames=[frame])
    doc = BaseDocTemplate(
        path, pagesize=A4,
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
        pageTemplates=[template],
        title="Power Maths · CH004 Trigonometry",
        author="Prof. Kalpesh Vyas",
        subject="Trigonometry — Study Material & Practice",
    )
    doc.build(title_flowables, canvasmaker=HeaderFooterCanvas)
    return path


# ---------------------------------------------------------------------------
# Helper flowables
# ---------------------------------------------------------------------------
def hrule(color=COLOR_EXAMPLE_BD, thickness=0.7, space_before=2, space_after=6):
    return HRFlowable(width="100%", thickness=thickness, color=color,
                      spaceBefore=space_before, spaceAfter=space_after)

def example_box(label, lines):
    """Light gray rounded box for worked examples.
    label: 'Example 1' style heading.
    lines: list of Paragraph (or strings -> wrapped in STY_EXAMPLE)."""
    inner = []
    if label:
        inner.append(Paragraph(label, STY_EXAMPLE_LABEL))
    for ln in lines:
        if isinstance(ln, str):
            inner.append(Paragraph(ln, STY_EXAMPLE))
        else:
            inner.append(ln)
    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 4])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), COLOR_EXAMPLE_BG),
        ("BOX",        (0, 0), (-1, -1), 0.7, COLOR_EXAMPLE_BD),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("ROUNDEDCORNERS", [4, 4, 4, 4]),
    ]))
    return KeepTogether([Spacer(1, 4), tbl, Spacer(1, 6)])

def solution_box(label, steps, final_answer, tip=None):
    """A solution block: label, steps (list of str/Paragraph), highlighted final answer,
    and an optional italic teaching tip below."""
    inner = [Paragraph(label, STY_EXAMPLE_LABEL)]
    for s in steps:
        if isinstance(s, str):
            inner.append(Paragraph(s, STY_SOLUTION_STEP))
        else:
            inner.append(s)
    inner.append(Paragraph(f"<b>Final Answer:</b> {final_answer}", STY_FINAL))
    if tip:
        inner.append(Paragraph(f"<i>Teacher's note:</i> {tip}", STY_NOTE))
    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 4])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), COLOR_EXAMPLE_BG),
        ("BOX",        (0, 0), (-1, -1), 0.7, COLOR_EXAMPLE_BD),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("ROUNDEDCORNERS", [4, 4, 4, 4]),
    ]))
    return KeepTogether([Spacer(1, 4), tbl, Spacer(1, 6)])

def question(qid, text, mcq_options=None, answer_lines=3):
    """A numbered practice question with answer space (ruled lines)."""
    flow = []
    qpara = Paragraph(f"<b>{qid}.</b> {text}", STY_Q)
    flow.append(qpara)
    if mcq_options:
        opts_tbl_data = []
        row = []
        for i, opt in enumerate(mcq_options):
            row.append(Paragraph(f"<b>({chr(65+i)})</b> {opt}", STY_ANSWER_SPACE))
            if len(row) == 2:
                opts_tbl_data.append(row); row = []
        if row:
            row.append(Paragraph("", STY_ANSWER_SPACE))
            opts_tbl_data.append(row)
        opt_tbl = Table(opts_tbl_data, colWidths=[
            (PAGE_W - MARGIN_L - MARGIN_R) / 2.0] * 2)
        opt_tbl.setStyle(TableStyle([
            ("LEFTPADDING", (0,0), (-1,-1), 6),
            ("RIGHTPADDING", (0,0), (-1,-1), 6),
            ("TOPPADDING", (0,0), (-1,-1), 1),
            ("BOTTOMPADDING", (0,0), (-1,-1), 1),
        ]))
        flow.append(opt_tbl)
        flow.append(Spacer(1, 2))
    # answer-space ruled lines (generous writing space)
    line_w = PAGE_W - MARGIN_L - MARGIN_R - 10
    for _ in range(answer_lines):
        ln = Table([[""]], colWidths=[line_w], rowHeights=[19])
        ln.setStyle(TableStyle([
            ("LINEBELOW", (0,0), (-1,-1), 0.4, COLOR_EXAMPLE_BD),
            ("LEFTPADDING", (0,0), (-1,-1), 0),
            ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ]))
        flow.append(ln)
    flow.append(Spacer(1, 8))
    # Return a list of flowables so the caller can extend; this lets ReportLab
    # split a long question across pages naturally between answer lines.
    return flow


def small_table(header_row, body_rows, col_widths=None, header_bg=COLOR_TABLE_HEAD):
    """Styled table with teal header, zebra striping."""
    data = [[Paragraph(h, STY_TABLE_HEAD) for h in header_row]]
    for r in body_rows:
        data.append([Paragraph(c, STY_TABLE_CELL) for c in r])
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), header_bg),
        ("TEXTCOLOR",  (0, 0), (-1, 0), white),
        ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("GRID",       (0, 0), (-1, -1), 0.4, COLOR_EXAMPLE_BD),
        ("LEFTPADDING",  (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING",   (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 5),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), COLOR_TABLE_ALT))
    t.setStyle(TableStyle(style_cmds))
    return t


# ===========================================================================
# PDF 1 — Study Material 01: Trigonometric Ratios
# ===========================================================================
def pdf_material_01():
    flow = []
    flow.append(Paragraph("Trigonometric Ratios", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Material 01 · Right-Triangle Foundations",
                          STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph("1. Introduction", STY_H1))
    flow.append(Paragraph(
        "Trigonometry is the branch of mathematics that studies the relationships "
        "between the side lengths and angles of triangles. The word comes from the "
        "Greek words <i>trigonon</i> (triangle) and <i>metron</i> (measure). "
        "In this material we focus on <b>right-angled triangles</b>, where one "
        "angle is exactly 90°. The ratios of the sides, expressed in terms of an "
        "acute angle θ, are called the <b>trigonometric ratios</b>.",
        STY_BODY))
    flow.append(Paragraph(
        "These six ratios — sin θ, cos θ, tan θ, cosec θ, sec θ and cot θ — "
        "form the foundation on which all later trigonometry (identities, "
        "equations, heights-and-distances, and even calculus) is built. "
        "Master them carefully: every formula in the chapter rests on the "
        "three basic ratios.", STY_BODY))

    flow.append(Paragraph("2. The Right-Angled Triangle", STY_H1))
    flow.append(Paragraph(
        "Consider a right-angled triangle ABC with the right angle at C, "
        "and let θ be the angle at vertex A. The three sides are labelled "
        "relative to the angle θ:", STY_BODY))
    flow.append(Paragraph(
        "<b>• Hypotenuse (h)</b> — the side opposite the 90° angle; it is the "
        "longest side of the triangle.", STY_BULLET))
    flow.append(Paragraph(
        "<b>• Opposite side (o)</b> — the side directly across from the angle θ "
        "(in triangle ABC, this is side BC).", STY_BULLET))
    flow.append(Paragraph(
        "<b>• Adjacent side (a)</b> — the side next to the angle θ that is not "
        "the hypotenuse (in triangle ABC, this is side AC).", STY_BULLET))
    flow.append(Paragraph(
        "By the Pythagorean theorem, the three sides always satisfy "
        "<b>a² + o² = h²</b>. This single fact will produce every trigonometric "
        "identity we study in Material 02.", STY_NOTE))

    flow.append(Paragraph("3. The Six Trigonometric Ratios", STY_H1))
    flow.append(Paragraph(
        "Using the labels H (hypotenuse), O (opposite) and A (adjacent), the "
        "six ratios are defined as follows:", STY_BODY))

    ratios = [
        ["Ratio", "Definition (in words)", "Formula"],
        ["sin θ",  "Opposite ÷ Hypotenuse",            "sin θ = O / H"],
        ["cos θ",  "Adjacent ÷ Hypotenuse",            "cos θ = A / H"],
        ["tan θ",  "Opposite ÷ Adjacent",              "tan θ = O / A"],
        ["cosec θ","Hypotenuse ÷ Opposite",            "cosec θ = H / O"],
        ["sec θ",  "Hypotenuse ÷ Adjacent",            "sec θ = H / A"],
        ["cot θ",  "Adjacent ÷ Opposite",              "cot θ = A / O"],
    ]
    flow.append(small_table(
        ratios[0], ratios[1:],
        col_widths=[60, 230, 200]))
    flow.append(Spacer(1, 4))

    flow.append(Paragraph("4. Reciprocal Relationships", STY_H1))
    flow.append(Paragraph(
        "Notice that the last three ratios are simply the reciprocals of the "
        "first three. This gives us three pairs:", STY_BODY))
    flow.append(Paragraph(
        "<b>•</b>  cosec θ = 1 / sin θ   &nbsp;&nbsp;(so  sin θ · cosec θ = 1)",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  sec θ   = 1 / cos θ   &nbsp;&nbsp;(so  cos θ · sec θ   = 1)",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  cot θ   = 1 / tan θ   &nbsp;&nbsp;(so  tan θ · cot θ   = 1)",
        STY_BULLET))
    flow.append(Paragraph(
        "Also observe: <b>tan θ = sin θ / cos θ</b> and "
        "<b>cot θ = cos θ / sin θ</b>. These quotient forms appear constantly "
        "when simplifying trigonometric expressions.", STY_BODY))

    # Mnemonic
    flow.append(example_box(
        "Memory Aid — SOH-CAH-TOA",
        ["<b>SOH</b> → <b>S</b>in = <b>O</b>pposite ÷ <b>H</b>ypotenuse",
         "<b>CAH</b> → <b>C</b>os = <b>A</b>djacent ÷ <b>H</b>ypotenuse",
         "<b>TOA</b> → <b>T</b>an = <b>O</b>pposite ÷ <b>A</b>djacent",
         "Say it aloud a few times — generations of students have used "
         "this rhyme to remember the three basic ratios instantly."]))

    flow.append(Paragraph("5. Standard Values (0°, 30°, 45°, 60°, 90°)",
                          STY_H1))
    flow.append(Paragraph(
        "The following table of standard values must be memorised. Notice the "
        "elegant pattern: sin θ rises from 0 to 1 as θ goes from 0° to 90°, "
        "while cos θ falls from 1 to 0 — they are mirror images of each other.",
        STY_BODY))

    std_vals = [
        ["θ",     "0°", "30°",          "45°",          "60°",          "90°"],
        ["sin θ", "0",  "1/2",          "1/√2",         "√3/2",         "1"],
        ["cos θ", "1",  "√3/2",         "1/√2",         "1/2",          "0"],
        ["tan θ", "0",  "1/√3",         "1",            "√3",           "Not defined"],
        ["cosec θ","Not defined","2",   "√2",           "2/√3",         "1"],
        ["sec θ", "1",  "2/√3",         "√2",           "2",            "Not defined"],
        ["cot θ", "Not defined","√3",   "1",            "1/√3",         "0"],
    ]
    flow.append(small_table(
        std_vals[0], std_vals[1:],
        col_widths=[60, 70, 70, 70, 70, 130]))
    flow.append(Spacer(1, 4))
    flow.append(Paragraph(
        "<b>Pattern tip:</b> Write sin θ values as √0/2, √1/2, √2/2, √3/2, "
        "√4/2 — i.e. √n/2 for n = 0,1,2,3,4 at θ = 0°, 30°, 45°, 60°, 90°. "
        "The cos θ row is just the sin θ row read backwards.",
        STY_NOTE))

    flow.append(Paragraph("6. Worked Examples", STY_H1))

    flow.append(example_box(
        "Example 1 — Find a ratio from sides",
        ["In right △ABC, right-angled at B, AB = 6 cm and BC = 8 cm. "
         "Find sin A, cos A and tan A.",
         "<b>Step 1:</b> Identify the sides relative to ∠A. "
         "AB is adjacent, BC is opposite, and AC (hypotenuse) is found by "
         "Pythagoras: AC = √(6² + 8²) = √(36+64) = √100 = 10 cm.",
         "<b>Step 2:</b> Apply definitions:",
         "&nbsp;&nbsp;&nbsp;sin A = BC / AC = 8 / 10 = 4/5",
         "&nbsp;&nbsp;&nbsp;cos A = AB / AC = 6 / 10 = 3/5",
         "&nbsp;&nbsp;&nbsp;tan A = BC / AB = 8 / 6  = 4/3",
         "<b>Answer:</b> sin A = 4/5,  cos A = 3/5,  tan A = 4/3."]))

    flow.append(example_box(
        "Example 2 — Evaluate using standard values",
        ["Evaluate:  sin 30° · cos 60° + cos 30° · sin 60°.",
         "<b>Step 1:</b> Substitute the standard values:",
         "&nbsp;&nbsp;&nbsp;sin 30° = 1/2,  cos 60° = 1/2,  "
         "cos 30° = √3/2,  sin 60° = √3/2.",
         "<b>Step 2:</b> Compute each product:",
         "&nbsp;&nbsp;&nbsp;(1/2)(1/2) + (√3/2)(√3/2) = 1/4 + 3/4 = 4/4 = 1.",
         "<b>Answer:</b> The expression equals 1. (This is, in fact, the "
         "sin(A+B) identity with A = 30°, B = 60°.)"]))

    flow.append(example_box(
        "Example 3 — Find an unknown side using a ratio",
        ["In right △PQR, right-angled at Q, ∠P = 45° and PQ = 7 cm. "
         "Find QR.",
         "<b>Step 1:</b> QR is opposite to ∠P, and PQ is adjacent. "
         "Use tan P = QR / PQ.",
         "<b>Step 2:</b> tan 45° = 1, so 1 = QR / 7, giving QR = 7 cm.",
         "<b>Answer:</b> QR = 7 cm. (A 45°-45°-90° triangle is isosceles, "
         "so the two legs are always equal.)"]))

    flow.append(example_box(
        "Example 4 — Use a reciprocal identity",
        ["If sin θ = 3/5 and θ is acute, find cosec θ, cos θ and tan θ.",
         "<b>Step 1:</b> cosec θ = 1 / sin θ = 1 / (3/5) = 5/3.",
         "<b>Step 2:</b> Use sin²θ + cos²θ = 1 → cos²θ = 1 − 9/25 = 16/25, "
         "so cos θ = 4/5 (positive because θ is acute).",
         "<b>Step 3:</b> tan θ = sin θ / cos θ = (3/5) / (4/5) = 3/4.",
         "<b>Answer:</b> cosec θ = 5/3,  cos θ = 4/5,  tan θ = 3/4."]))

    flow.append(example_box(
        "Example 5 — Mixed standard-angle evaluation",
        ["Evaluate:  (sin 30° + cos 30°)(sin 60° + cos 60°).",
         "<b>Step 1:</b> sin 30° = 1/2,  cos 30° = √3/2,  sin 60° = √3/2,  "
         "cos 60° = 1/2.",
         "<b>Step 2:</b> First bracket  = 1/2 + √3/2 = (1 + √3)/2.",
         "<b>Step 3:</b> Second bracket = √3/2 + 1/2 = (1 + √3)/2.",
         "<b>Step 4:</b> Product = ((1 + √3)/2)² = (1 + 2√3 + 3)/4 = "
         "(4 + 2√3)/4 = (2 + √3)/2.",
         "<b>Answer:</b> (2 + √3)/2  ≈ 1.866."]))

    flow.append(example_box(
        "Example 6 — Find θ from a given ratio",
        ["In right △XYZ, right-angled at Y, if XY = √3 · YZ, find ∠X.",
         "<b>Step 1:</b> XY is adjacent to ∠X and YZ is opposite, so "
         "tan X = YZ / XY = YZ / (√3 · YZ) = 1/√3.",
         "<b>Step 2:</b> tan 30° = 1/√3, so ∠X = 30°.",
         "<b>Answer:</b> ∠X = 30°.  (The third angle is 60° — a 30-60-90 "
         "triangle.)"]))

    flow.append(Paragraph("7. Common Mistakes to Avoid", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> Writing <b>sin²θ</b> as <b>sin θ²</b>. The exponent belongs "
        "to the <i>value</i> of the ratio, not to θ.  sin²θ means (sin θ)², "
        "which is <i>not</i> the same as sin(θ²).", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Forgetting that cosec, sec and cot are reciprocals — many "
        "students write cosec θ = 1/cos θ, but the correct reciprocal of "
        "sin θ is cosec θ.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Treating tan 90° as 0 instead of \"not defined\". "
        "tan 90° = sin 90° / cos 90° = 1/0, which is undefined.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Mixing up opposite and adjacent when the angle changes. "
        "If you swap from ∠A to ∠B (where ∠A + ∠B = 90°), the opposite and "
        "adjacent sides swap.", STY_BULLET))

    flow.append(Paragraph("8. Quick Recap", STY_H1))
    flow.append(small_table(
        ["Quantity", "Formula"],
        [
            ["sin θ",  "opposite / hypotenuse"],
            ["cos θ",  "adjacent / hypotenuse"],
            ["tan θ",  "opposite / adjacent  =  sin θ / cos θ"],
            ["cosec θ","1 / sin θ"],
            ["sec θ",  "1 / cos θ"],
            ["cot θ",  "1 / tan θ  =  cos θ / sin θ"],
        ],
        col_widths=[120, 350]))
    flow.append(Spacer(1, 4))
    flow.append(Paragraph(
        "Remember the SOH-CAH-TOA mnemonic, the standard value table for "
        "0°, 30°, 45°, 60°, 90°, and the three reciprocal pairs. With these "
        "tools you are ready for the next material on identities and the two "
        "practice sheets.", STY_BODY))

    flow.append(Paragraph("9. Key Takeaways", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> There are six trig ratios, but only sin, cos and tan are "
        "primary — the other three (cosec, sec, cot) are reciprocals.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> tan θ = sin θ / cos θ;  cot θ = cos θ / sin θ.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> For θ ∈ {0°, 30°, 45°, 60°, 90°}, learn the standard value "
        "table by heart — it is the most-used fact in the chapter.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> sin²θ + cos²θ = 1 follows directly from the Pythagorean "
        "theorem divided through by H².", STY_BULLET))

    return build_doc(os.path.join(MATERIALS_DIR,
        "CH004-material-01-trig-ratios.pdf"), flow)


# ===========================================================================
# PDF 2 — Study Material 02: Trigonometric Identities
# ===========================================================================
def pdf_material_02():
    flow = []
    flow.append(Paragraph("Trigonometric Identities", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Material 02 · Proofs and Applications",
                          STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph("1. What is a Trigonometric Identity?", STY_H1))
    flow.append(Paragraph(
        "An <b>identity</b> is an equation that is true for <i>every</i> value "
        "of the variable for which both sides are defined. Unlike an equation "
        "such as sin θ = 1/2 (true only at θ = 30° or 150°), an identity such "
        "as sin²θ + cos²θ = 1 holds for <i>all</i> real θ.", STY_BODY))
    flow.append(Paragraph(
        "There are three <b>fundamental</b> identities from which most others "
        "follow. Each is a direct consequence of the Pythagorean theorem "
        "applied to a right-angled triangle with hypotenuse 1 (or with one "
        "of the other sides scaled to 1).", STY_BODY))
    flow.append(Paragraph(
        "Identities are powerful because they let us <i>rewrite</i> a "
        "trigonometric expression in a more convenient form. If you can "
        "replace sin²θ with 1 − cos²θ, then any expression involving both "
        "sin²θ and cos²θ may suddenly simplify to something elegant. This "
        "<i>algebraic shape-shifting</i> is the heart of trigonometric "
        "problem-solving.", STY_BODY))
    flow.append(Paragraph(
        "<b>Three Pythagorean identities</b> are the pillars of this chapter:",
        STY_BODY))
    flow.append(Paragraph(
        "<b>•</b>  sin²θ + cos²θ = 1", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  1 + tan²θ = sec²θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  1 + cot²θ = cosec²θ", STY_BULLET))

    flow.append(Paragraph("2. Fundamental Identity: sin²θ + cos²θ = 1",
                          STY_H1))
    flow.append(Paragraph(
        "<b>Proof.</b> Take any right-angled triangle with sides O (opposite), "
        "A (adjacent) and H (hypotenuse). By Pythagoras, A² + O² = H². "
        "Divide every term by H²:", STY_BODY))
    flow.append(Paragraph(
        "A²/H²  +  O²/H²  =  H²/H²  =  1", STY_EXAMPLE))
    flow.append(Paragraph(
        "But A/H = cos θ and O/H = sin θ, so (A/H)² + (O/H)² = cos²θ + sin²θ. "
        "Therefore:", STY_BODY))
    flow.append(Paragraph(
        "<b>sin²θ + cos²θ = 1</b>", STY_EXAMPLE))
    flow.append(Paragraph(
        "Dividing this identity by cos²θ and by sin²θ produces the other two "
        "fundamental identities — a beautiful example of how one fact gives "
        "rise to many.", STY_NOTE))

    flow.append(Paragraph("3. Identity: 1 + tan²θ = sec²θ", STY_H1))
    flow.append(Paragraph(
        "<b>Proof.</b> Start with sin²θ + cos²θ = 1 and divide every term "
        "by cos²θ (assuming cos θ ≠ 0, i.e. θ ≠ 90°):", STY_BODY))
    flow.append(Paragraph(
        "sin²θ / cos²θ  +  cos²θ / cos²θ  =  1 / cos²θ", STY_EXAMPLE))
    flow.append(Paragraph(
        "But sin θ / cos θ = tan θ and 1 / cos θ = sec θ. Squaring gives "
        "tan²θ and sec²θ:", STY_BODY))
    flow.append(Paragraph(
        "<b>1 + tan²θ = sec²θ</b>", STY_EXAMPLE))

    flow.append(Paragraph("4. Identity: 1 + cot²θ = cosec²θ", STY_H1))
    flow.append(Paragraph(
        "<b>Proof.</b> Again begin with sin²θ + cos²θ = 1, this time dividing "
        "every term by sin²θ (assuming sin θ ≠ 0, i.e. θ ≠ 0°):", STY_BODY))
    flow.append(Paragraph(
        "sin²θ / sin²θ  +  cos²θ / sin²θ  =  1 / sin²θ", STY_EXAMPLE))
    flow.append(Paragraph(
        "Since cos θ / sin θ = cot θ and 1 / sin θ = cosec θ, we obtain:",
        STY_BODY))
    flow.append(Paragraph(
        "<b>1 + cot²θ = cosec²θ</b>", STY_EXAMPLE))

    # Summary table of the three identities
    flow.append(small_table(
        ["Identity", "Obtained by", "Valid when"],
        [
            ["sin²θ + cos²θ = 1",
             "Pythagoras ÷ H²",
             "all θ"],
            ["1 + tan²θ = sec²θ",
             "above ÷ cos²θ",
             "cos θ ≠ 0  (θ ≠ 90°)"],
            ["1 + cot²θ = cosec²θ",
             "above ÷ sin²θ",
             "sin θ ≠ 0  (θ ≠ 0°)"],
        ],
        col_widths=[160, 160, 175]))
    flow.append(Spacer(1, 6))

    flow.append(Paragraph("5. Co-function (Complementary Angle) Identities",
                          STY_H1))
    flow.append(Paragraph(
        "Two angles are <b>complementary</b> if they add up to 90°. In a "
        "right-angled triangle, the two acute angles are always complementary "
        "(because the third angle is 90° and the angle-sum is 180°). "
        "If one acute angle is θ, the other is (90° − θ), and the side that "
        "is <i>opposite</i> to one is <i>adjacent</i> to the other. This gives "
        "the co-function identities:", STY_BODY))
    flow.append(Paragraph(
        "<b>•</b>  sin(90° − θ) = cos θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  cos(90° − θ) = sin θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  tan(90° − θ) = cot θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  cosec(90° − θ) = sec θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  sec(90° − θ) = cosec θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  cot(90° − θ) = tan θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>Quick check:</b> sin(90° − 30°) = sin 60° = √3/2 and "
        "cos 30° = √3/2 — they match, as the identity promises.",
        STY_NOTE))

    flow.append(Paragraph("6. Useful Derived Identities", STY_H1))
    flow.append(Paragraph(
        "These three identities spawn countless useful rearrangements. "
        "Memorise the following four — they appear constantly in problems:",
        STY_BODY))
    flow.append(Paragraph(
        "<b>•</b>  sin²θ = 1 − cos²θ &nbsp;&nbsp;&nbsp; "
        "cos²θ = 1 − sin²θ", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  tan²θ = sec²θ − 1 &nbsp;&nbsp;&nbsp; "
        "sec²θ − tan²θ = 1", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  cot²θ = cosec²θ − 1 &nbsp;&nbsp;&nbsp; "
        "cosec²θ − cot²θ = 1", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  (sin θ + cos θ)² = 1 + 2 sin θ cos θ", STY_BULLET))

    flow.append(Paragraph("7. Worked Examples", STY_H1))

    flow.append(example_box(
        "Example 1 — Simplify using sin² + cos² = 1",
        ["Simplify:  (1 − sin²θ) · sec²θ.",
         "<b>Step 1:</b> Replace 1 − sin²θ with cos²θ (from the first identity).",
         "<b>Step 2:</b> sec²θ = 1 / cos²θ, so the expression becomes "
         "cos²θ · (1 / cos²θ) = 1.",
         "<b>Answer:</b> 1."]))

    flow.append(example_box(
        "Example 2 — Prove an identity",
        ["Prove that  (1 + tan²θ) · cos²θ = 1.",
         "<b>LHS:</b> 1 + tan²θ = sec²θ (identity).",
         "<b>So</b> LHS = sec²θ · cos²θ = (1 / cos²θ) · cos²θ = 1 = RHS.",
         "<b>Conclusion:</b> LHS = RHS, hence proved."]))

    flow.append(example_box(
        "Example 3 — Express in terms of sin θ",
        ["Express sec⁴θ − tan⁴θ in terms of sin θ.",
         "<b>Step 1:</b> Use a² − b² = (a − b)(a + b):",
         "&nbsp;&nbsp;&nbsp;sec⁴θ − tan⁴θ = (sec²θ − tan²θ)(sec²θ + tan²θ).",
         "<b>Step 2:</b> sec²θ − tan²θ = 1, so the expression reduces to "
         "sec²θ + tan²θ.",
         "<b>Step 3:</b> sec²θ + tan²θ = (1 + sin²θ) / cos²θ "
         "= (1 + sin²θ) / (1 − sin²θ).",
         "<b>Answer:</b> sec⁴θ − tan⁴θ = (1 + sin²θ) / (1 − sin²θ)."]))

    flow.append(example_box(
        "Example 4 — Evaluate using an identity",
        ["If sin θ + cos θ = √2, find the value of sin θ · cos θ.",
         "<b>Step 1:</b> Square both sides: "
         "(sin θ + cos θ)² = (√2)² = 2.",
         "<b>Step 2:</b> Expand: sin²θ + cos²θ + 2 sin θ cos θ = 2.",
         "<b>Step 3:</b> Use sin²θ + cos²θ = 1: 1 + 2 sin θ cos θ = 2, "
         "so 2 sin θ cos θ = 1.",
         "<b>Answer:</b> sin θ · cos θ = 1/2  (this occurs at θ = 45°)."]))

    flow.append(example_box(
        "Example 5 — Co-function identity",
        ["Evaluate:  sin² 35° + sin² 55°  +  tan² 10° · tan² 80°.",
         "<b>Step 1:</b> sin 55° = sin(90° − 35°) = cos 35°, so "
         "sin² 55° = cos² 35°.",
         "<b>Step 2:</b> sin² 35° + cos² 35° = 1.",
         "<b>Step 3:</b> tan 80° = cot 10° = 1 / tan 10°, so "
         "tan² 10° · tan² 80° = tan² 10° · (1 / tan² 10°) = 1.",
         "<b>Answer:</b> 1 + 1 = 2."]))

    flow.append(example_box(
        "Example 6 — Eliminate θ from a system",
        ["If x = a sin θ and y = a cos θ, prove that  x² + y² = a².",
         "<b>Step 1:</b> x² + y² = (a sin θ)² + (a cos θ)² = a² sin²θ + "
         "a² cos²θ = a² (sin²θ + cos²θ).",
         "<b>Step 2:</b> sin²θ + cos²θ = 1, so x² + y² = a² · 1 = a².",
         "<b>Answer:</b> Proved. (This is the equation of a circle of "
         "radius a — a beautiful geometric meaning of the identity.)"]))

    flow.append(example_box(
        "Example 7 — Conditional equation",
        ["Find all θ in [0°, 90°] such that  2 cos²θ + 3 sin θ = 3.",
         "<b>Step 1:</b> Replace cos²θ with 1 − sin²θ:  "
         "2 (1 − sin²θ) + 3 sin θ = 3.",
         "<b>Step 2:</b> Expand:  2 − 2 sin²θ + 3 sin θ = 3, so "
         "2 sin²θ − 3 sin θ + 1 = 0.",
         "<b>Step 3:</b> Let u = sin θ.  Solve 2u² − 3u + 1 = 0 → "
         "(2u − 1)(u − 1) = 0, so u = 1/2 or u = 1.",
         "<b>Step 4:</b> sin θ = 1/2 → θ = 30°.  sin θ = 1 → θ = 90°.",
         "<b>Answer:</b> θ = 30°  or  θ = 90°."]))

    flow.append(example_box(
        "Example 8 — Maximum / minimum using identities",
        ["Find the maximum and minimum values of  5 sin θ + 12 cos θ.",
         "<b>Step 1:</b> For any expression of the form a sin θ + b cos θ, the "
         "maximum is √(a² + b²) and the minimum is −√(a² + b²).",
         "<b>Step 2:</b> Here a = 5, b = 12, so √(25 + 144) = √169 = 13.",
         "<b>Answer:</b> Maximum = 13,  Minimum = −13.",
         "<b>Why?</b> Divide by 13:  (5/13) sin θ + (12/13) cos θ. Now if we "
         "set cos φ = 5/13 and sin φ = 12/13 (which is valid because "
         "(5/13)² + (12/13)² = 1), the expression becomes "
         "sin(θ + φ), whose range is [−1, 1]. Multiplying back by 13 gives "
         "the range [−13, 13]."]))

    flow.append(Paragraph("9. Strategy for Proving Identities", STY_H1))
    flow.append(Paragraph(
        "When asked to <i>prove</i> an identity LHS = RHS, follow this "
        "strategy:", STY_BODY))
    flow.append(Paragraph(
        "<b>•</b> Pick the side that looks more complicated and simplify it "
        "first. Often the LHS will collapse to a single term.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Convert everything to sin θ and cos θ.  This is the "
        "<i>universal currency</i> of trigonometry — tan, cot, sec and cosec "
        "all become sin and cos.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Look for opportunities to apply one of the three Pythagorean "
        "identities, especially sin²θ + cos²θ = 1.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> If both sides are complicated, simplify both until they "
        "meet in the middle.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Never cross-multiply or move terms across the \"=\" sign — "
        "an identity is a chain of equal expressions, not an equation to "
        "solve.", STY_BULLET))

    flow.append(Paragraph("10. Common Mistakes", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> Writing sin²θ + cos²θ = 2 instead of 1. This is the most "
        "common slip — always remember the sum is <i>1</i>, not 2.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Applying the Pythagorean identity before converting other "
        "ratios to sin and cos. Always simplify first.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Confusing co-function identities: sin(90° − θ) = cos θ, "
        "but sin(90° + θ) ≠ cos θ — that requires the supplementary-angle "
        "identity (beyond this chapter).", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Dividing by cos²θ or sin²θ without checking it is non-zero. "
        "At θ = 90°, cos θ = 0, so sec θ is undefined.", STY_BULLET))

    flow.append(Paragraph("11. Key Takeaways", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> All fundamental identities come from sin²θ + cos²θ = 1 by "
        "dividing through by sin²θ or cos²θ.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Co-function identities swap sin ↔ cos, tan ↔ cot, "
        "sec ↔ cosec when 90° − θ is used.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> When asked to <i>prove</i> an identity, simplify the more "
        "complex side first, then meet in the middle.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> When asked to <i>evaluate</i>, look for hidden applications "
        "of sin² + cos² = 1 — the answer is very often 0 or 1.",
        STY_BULLET))

    return build_doc(os.path.join(MATERIALS_DIR,
        "CH004-material-02-trig-identities.pdf"), flow)


# ===========================================================================
# PDF 3 — Study Material 03: Applications of Trigonometry
# ===========================================================================
def pdf_material_03():
    flow = []
    flow.append(Paragraph("Applications of Trigonometry", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Material 03 · Heights and Distances",
                          STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph("1. Why Applications Matter", STY_H1))
    flow.append(Paragraph(
        "Trigonometry began as a practical tool for astronomers, navigators "
        "and surveyors who needed to measure distances that were impossible "
        "to measure directly — the height of a mountain, the width of a river, "
        "the distance to a star. The same techniques are used today in "
        "architecture, satellite communication, video-game graphics, and "
        "robotics. In this material we will learn how to translate a real-world "
        "measurement problem into a right-angled triangle and solve it using "
        "the ratios we already know.", STY_BODY))

    flow.append(Paragraph("2. Key Vocabulary", STY_H1))
    flow.append(Paragraph(
        "<b>• Line of sight</b> — the straight line drawn from the eye of an "
        "observer to the point being viewed.", STY_BULLET))
    flow.append(Paragraph(
        "<b>• Angle of elevation</b> — the angle <i>above</i> the horizontal "
        "line, formed between the line of sight and the horizontal, when the "
        "object is above the observer.", STY_BULLET))
    flow.append(Paragraph(
        "<b>• Angle of depression</b> — the angle <i>below</i> the horizontal "
        "line, formed between the line of sight and the horizontal, when the "
        "object is below the observer.", STY_BULLET))
    flow.append(Paragraph(
        "<b>• Horizontal line</b> — the line parallel to the ground, passing "
        "through the observer's eye.", STY_BULLET))
    flow.append(Paragraph(
        "<b>Important fact:</b> In any such problem, the angle of elevation "
        "of an object from the observer <i>equals</i> the angle of depression "
        "of the observer from the object (they are alternate interior angles "
        "between parallel horizontals).", STY_NOTE))

    flow.append(Paragraph("3. A Picture is Worth a Thousand Words", STY_H1))
    flow.append(Paragraph(
        "Almost every heights-and-distances problem becomes easy once you draw "
        "the correct diagram. The standard recipe:", STY_BODY))
    flow.append(Paragraph(
        "<b>Step 1.</b> Draw a right-angled triangle. The vertical side is the "
        "object's height, the horizontal side is the distance along the ground, "
        "and the slanted side is the line of sight.", STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 2.</b> Label every known quantity (height, distance, angle) "
        "on the diagram. Mark the unknown with a variable such as h or x.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 3.</b> Decide which ratio involves the unknown and the known "
        "values. If the unknown is the opposite side and you know the "
        "adjacent, use tan. If you know the hypotenuse, use sin or cos.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 4.</b> Substitute, solve, and write the answer with units "
        "(metres, feet, etc.).", STY_BULLET))

    flow.append(Paragraph("4. Which Ratio Should I Use?", STY_H1))
    flow.append(small_table(
        ["Known pair", "Unknown", "Use this ratio"],
        [
            ["adjacent + angle",        "opposite",     "tan θ = O / A"],
            ["opposite + angle",        "adjacent",     "tan θ = O / A"],
            ["hypotenuse + angle",      "opposite",     "sin θ = O / H"],
            ["hypotenuse + angle",      "adjacent",     "cos θ = A / H"],
            ["opposite + adjacent",     "angle",        "tan θ = O / A"],
        ],
        col_widths=[180, 120, 195]))
    flow.append(Spacer(1, 4))
    flow.append(Paragraph(
        "Rule of thumb: <b>if the hypotenuse is not mentioned, you almost "
        "certainly need tan θ</b>. The line of sight (hypotenuse) is rarely "
        "the quantity that surveyors measure.", STY_NOTE))

    flow.append(Paragraph("5. Worked Examples", STY_H1))

    flow.append(example_box(
        "Example 1 — Height of a tower (angle of elevation)",
        ["A vertical tower stands on level ground. From a point 30 m away "
         "from its foot, the angle of elevation of the top of the tower is "
         "45°. Find the height of the tower.",
         "<b>Step 1:</b> Let the height be h metres. The triangle has "
         "adjacent = 30 m, opposite = h, and angle θ = 45°.",
         "<b>Step 2:</b> tan 45° = h / 30.",
         "<b>Step 3:</b> 1 = h / 30  →  h = 30 m.",
         "<b>Answer:</b> The tower is 30 m tall."]))

    flow.append(example_box(
        "Example 2 — Distance from a tower (using 60°)",
        ["The angle of elevation of the top of a 50 m tall tower, from a "
         "point on the ground, is 60°. How far is the point from the foot "
         "of the tower? (Use √3 ≈ 1.732.)",
         "<b>Step 1:</b> Let the distance be x m. Then tan 60° = 50 / x.",
         "<b>Step 2:</b> √3 = 50 / x  →  x = 50 / √3.",
         "<b>Step 3:</b> Rationalise: x = (50 √3) / 3 ≈ (50 × 1.732) / 3 "
         "≈ 28.87 m.",
         "<b>Answer:</b> The point is about 28.87 m from the foot of the tower."]))

    flow.append(example_box(
        "Example 3 — Two observers, two angles",
        ["A ladder leans against a vertical wall. The foot of the ladder is "
         "4 m from the wall and the ladder makes a 60° angle with the ground. "
         "Find (a) the length of the ladder, and (b) how high up the wall it "
         "reaches.",
         "<b>(a) Length of ladder (hypotenuse):</b>",
         "&nbsp;&nbsp;&nbsp;cos 60° = adjacent / hypotenuse = 4 / L",
         "&nbsp;&nbsp;&nbsp;1/2 = 4 / L  →  L = 8 m.",
         "<b>(b) Height on wall (opposite):</b>",
         "&nbsp;&nbsp;&nbsp;sin 60° = h / L  →  h = 8 × (√3/2) = 4√3 ≈ 6.93 m.",
         "<b>Answer:</b> Ladder length = 8 m; reaches ≈ 6.93 m up the wall."]))

    flow.append(example_box(
        "Example 4 — Angle of depression",
        ["From the top of a 75 m high lighthouse, the angle of depression of "
         "a ship on the sea is 30°. How far is the ship from the foot of the "
         "lighthouse?",
         "<b>Step 1:</b> Angle of depression = angle of elevation from ship "
         "(alternate interior angles), so θ = 30° at the ship.",
         "<b>Step 2:</b> In the triangle, opposite = 75 m, adjacent = x "
         "(distance to ship). Use tan 30° = 75 / x.",
         "<b>Step 3:</b> 1/√3 = 75 / x  →  x = 75 √3 ≈ 75 × 1.732 ≈ 129.9 m.",
         "<b>Answer:</b> The ship is about 129.9 m from the lighthouse."]))

    flow.append(example_box(
        "Example 5 — Two points in a line",
        ["The angles of elevation of the top of a tower from two points P and "
         "Q on the ground, in line with the tower (Q on the opposite side of "
         "P from the tower), are 30° and 60°. If PQ = 40 m, find the height "
         "of the tower.",
         "<b>Step 1:</b> Let the height be h and the distance from the nearer "
         "point Q to the foot be x. Then the distance from P to the foot is "
         "(x + 40).",
         "<b>Step 2:</b> From Q:  tan 60° = h / x  →  h = x √3.",
         "<b>Step 3:</b> From P:  tan 30° = h / (x + 40)  →  h = (x + 40)/√3.",
         "<b>Step 4:</b> Equate:  x √3 = (x + 40) / √3  →  3x = x + 40  →  "
         "2x = 40  →  x = 20 m.",
         "<b>Step 5:</b> h = 20 √3 ≈ 34.64 m.",
         "<b>Answer:</b> The tower is about 34.64 m tall."]))

    flow.append(example_box(
        "Example 6 — Shadow of a pole (angle of elevation of the sun)",
        ["A vertical pole 12 m tall casts a shadow 12√3 m long on the ground. "
         "Find the angle of elevation of the sun.",
         "<b>Step 1:</b> The pole is the opposite side (h = 12 m), the shadow "
         "is the adjacent side (d = 12√3 m).",
         "<b>Step 2:</b> tan θ = h / d = 12 / (12√3) = 1/√3.",
         "<b>Step 3:</b> tan⁻¹(1/√3) = 30°.",
         "<b>Answer:</b> The angle of elevation of the sun is 30°. (When the "
         "sun is low, shadows are long — this is why shadows grow at sunset.)"]))

    flow.append(example_box(
        "Example 7 — Two buildings facing each other",
        ["Two buildings of heights 30 m and 50 m stand on opposite sides of a "
         "road. From the top of the shorter building, the angle of elevation "
         "of the top of the taller building is 30°. Find the width of the "
         "road.",
         "<b>Step 1:</b> The height difference between the buildings is "
         "50 − 30 = 20 m. This is the opposite side of the right triangle "
         "formed at the top of the shorter building.",
         "<b>Step 2:</b> The road width d is the adjacent side. "
         "tan 30° = 20 / d → 1/√3 = 20/d → d = 20√3 m.",
         "<b>Step 3:</b> d ≈ 20 × 1.732 ≈ 34.64 m.",
         "<b>Answer:</b> The road is about 34.64 m wide."]))

    flow.append(Paragraph("6. Step-by-Step Problem-Solving Strategy", STY_H1))
    flow.append(Paragraph(
        "Use this five-step recipe on every heights-and-distances problem. "
        "Following it consistently will eliminate most careless errors.",
        STY_BODY))
    flow.append(Paragraph(
        "<b>Step 1 — Read & visualise.</b> Identify the observer, the object, "
        "the angle (elevation or depression) and which quantity is unknown.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 2 — Draw & label.</b> Sketch the right-angled triangle. "
        "Mark the right angle clearly, label every known side/angle, and use "
        "a variable (h, x, d, …) for the unknown.", STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 3 — Pick the ratio.</b> Choose the ratio that links the "
        "unknown to the known values. Use the table from §4 as a guide.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 4 — Substitute & solve.</b> Plug in the numbers, isolate the "
        "unknown, and rationalise any surds (e.g. 1/√3 = √3/3).", STY_BULLET))
    flow.append(Paragraph(
        "<b>Step 5 — State the answer.</b> Write the final value with units "
        "and a short concluding sentence. Sanity-check the magnitude.",
        STY_BULLET))

    flow.append(Paragraph("7. Common Pitfalls", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> Mixing up the angle of elevation with the angle the ladder "
        "makes with the wall — read the question twice.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Forgetting that the angle of depression is measured from "
        "the horizontal, <i>not</i> from the vertical line of the tower.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Using the wrong side as the hypotenuse. The hypotenuse is "
        "always opposite the 90° angle — it is the line of sight, not the "
        "tower.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Leaving the answer without units. Heights are in metres "
        "or feet; always state them.", STY_BULLET))

    flow.append(Paragraph("8. Key Takeaways", STY_H1))
    flow.append(Paragraph(
        "<b>•</b> Always draw a labelled diagram first — it solves 80% of "
        "the problem.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> tan θ is the workhorse ratio for heights and distances "
        "because both legs (height and ground distance) are usually the "
        "measurable quantities.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Angle of elevation = angle of depression for the same pair "
        "of points.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> When two observers give two angles, set up two equations "
        "in two unknowns (h and one distance) and solve simultaneously.",
        STY_BULLET))

    return build_doc(os.path.join(MATERIALS_DIR,
        "CH004-material-03-applications.pdf"), flow)


# ===========================================================================
# PDF 4 — Practice Sheet 1 (ratios, standard values, reciprocals)
# ===========================================================================
def pdf_practice_01():
    flow = []
    flow.append(Paragraph("Practice Sheet 1", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Trigonometric Ratios & Standard Values · "
                          "Easy + Medium", STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph(
        "<b>Instructions:</b> Attempt all 18 questions. Show your working in "
        "the space provided. Use √3 ≈ 1.732 and √2 ≈ 1.414 where required. "
        "Each MCQ carries 1 mark; numerical / word problems carry 2-3 marks.",
        STY_NOTE))

    flow.append(Paragraph("Section A — Multiple Choice (1 mark each)", STY_H2))
    flow.extend(question("Q1",
        "The value of sin 30° × cos 60° is:",
        mcq_options=["1/2", "1/4", "√3/4", "1"], answer_lines=2))
    flow.extend(question("Q2",
        "If sin θ = 3/5 (θ acute), then cosec θ equals:",
        mcq_options=["3/5", "5/3", "4/5", "4/3"], answer_lines=2))
    flow.extend(question("Q3",
        "The value of tan 45° + cot 45° is:",
        mcq_options=["0", "1", "2", "√2"], answer_lines=2))
    flow.extend(question("Q4",
        "Which of the following is <b>not defined</b>?",
        mcq_options=["tan 0°", "tan 90°", "cot 90°", "sin 90°"], answer_lines=2))
    flow.extend(question("Q5",
        "In a right triangle, if the side opposite θ is 5 and the "
        "hypotenuse is 13, then cos θ is:",
        mcq_options=["5/13", "12/13", "13/5", "5/12"], answer_lines=2))

    flow.append(Paragraph("Section B — Numerical (2 marks each)", STY_H2))
    flow.extend(question("Q6",
        "Evaluate:  sin² 60° + cos² 60°.", answer_lines=7))
    flow.extend(question("Q7",
        "Evaluate:  2 sin² 30° + 2 cos² 30°.", answer_lines=7))
    flow.extend(question("Q8",
        "Evaluate:  sin 60° · cos 30° + cos 60° · sin 30°.", answer_lines=8))
    flow.extend(question("Q9",
        "Find the value of  tan² 60° − 3 sin² 60°.", answer_lines=8))
    flow.extend(question("Q10",
        "If cos θ = 5/13 and θ is acute, find sin θ and tan θ.", answer_lines=8))
    flow.extend(question("Q11",
        "Evaluate:  (sin 45° + cos 45°)².", answer_lines=7))
    flow.extend(question("Q12",
        "Find the value of  sin 90° + cos 0° + tan 45°.", answer_lines=7))

    flow.append(Paragraph("Section C — Word Problems (3 marks each)", STY_H2))
    flow.extend(question("Q13",
        "In right △ABC (right-angled at B), AB = 9 cm and BC = 12 cm. "
        "Find sin A, cos A and tan A.", answer_lines=9))
    flow.extend(question("Q14",
        "If tan θ = 7/24 and θ is acute, find all other five trigonometric "
        "ratios of θ.", answer_lines=10))
    flow.extend(question("Q15",
        "In right △PQR, right-angled at Q, ∠P = 60° and PQ = 8 cm. "
        "Find the lengths of QR and PR.", answer_lines=9))
    flow.extend(question("Q16",
        "Verify numerically that  sin² 45° + cos² 45° = 1 by substituting "
        "the exact standard values.", answer_lines=8))
    flow.extend(question("Q17",
        "A 5 m long ladder leans against a vertical wall with its foot 3 m "
        "from the wall. Find the angle the ladder makes with the ground, and "
        "the height the ladder reaches up the wall.", answer_lines=10))
    flow.extend(question("Q18",
        "If 2 sin θ = √3 and θ is acute, find the value of  "
        "(1 + tan²θ) · cos²θ.", answer_lines=8))

    return build_doc(os.path.join(PRACTICE_DIR,
        "CH004-practice-01.pdf"), flow)


# ===========================================================================
# PDF 5 — Solutions for Practice Sheet 1
# ===========================================================================
def pdf_practice_01_solutions():
    flow = []
    flow.append(Paragraph("Practice Sheet 1 — Solutions", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Trigonometric Ratios · Step-by-step "
                          "Worked Solutions", STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph("How to Use These Solutions", STY_H1))
    flow.append(Paragraph(
        "Attempt every problem on the practice sheet <i>before</i> looking at "
        "these solutions. Then compare your working step-by-step. If your "
        "answer matches but your steps differ, ask yourself: <b>which method "
        "is shorter, and which is less likely to lead to mistakes?</b> That "
        "is the method you want to internalise.", STY_BODY))
    flow.append(Paragraph(
        "<b>Universal facts used in these solutions:</b>", STY_BODY))
    flow.append(Paragraph(
        "<b>•</b> The three primary ratios are sin θ = O/H, cos θ = A/H, "
        "tan θ = O/A. The other three are reciprocals.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> Standard values: sin 30° = 1/2, cos 30° = √3/2, "
        "sin 45° = cos 45° = 1/√2, sin 60° = √3/2, cos 60° = 1/2, "
        "sin 90° = 1, cos 0° = 1, tan 45° = 1.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> The Pythagorean identity sin²θ + cos²θ = 1 lets us "
        "convert between sin and cos whenever one is known.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b> For an acute angle, all six trig ratios are positive, "
        "so we always take the positive square root.", STY_BULLET))
    flow.append(Spacer(1, 4))

    flow.append(Paragraph("Section A — Multiple Choice", STY_H2))

    flow.append(solution_box("Q1.",
        ["sin 30° = 1/2  and  cos 60° = 1/2.",
         "Product = (1/2) × (1/2) = 1/4."],
        "(B) 1/4",
        tip="Memorise the standard value table — this product takes 5 seconds if you know it cold."))

    flow.append(solution_box("Q2.",
        ["cosec θ = 1 / sin θ = 1 / (3/5) = 5/3."],
        "(B) 5/3",
        tip="cosec is the reciprocal of sin; sec is the reciprocal of cos; cot is the reciprocal of tan. Match them in pairs."))

    flow.append(solution_box("Q3.",
        ["tan 45° = 1  and  cot 45° = 1.",
         "Sum = 1 + 1 = 2."],
        "(C) 2",
        tip="45° is a special angle: sin 45° = cos 45° = 1/√2, so tan 45° = cot 45° = 1."))

    flow.append(solution_box("Q4.",
        ["tan 90° = sin 90° / cos 90° = 1 / 0, which is undefined "
         "(division by zero)."],
        "(B) tan 90°",
        tip="tan θ and sec θ are undefined when cos θ = 0, i.e. at θ = 90°. cot θ and cosec θ are undefined when sin θ = 0, i.e. at θ = 0°."))

    flow.append(solution_box("Q5.",
        ["Adjacent side = √(13² − 5²) = √(169 − 25) = √144 = 12.",
         "cos θ = adjacent / hypotenuse = 12/13."],
        "(B) 12/13",
        tip="Whenever two sides of a right triangle are known, the third comes from Pythagoras: a² + b² = c²."))

    flow.append(Paragraph("Section B — Numerical", STY_H2))

    flow.append(solution_box("Q6.",
        ["Using sin²θ + cos²θ = 1 for any θ:",
         "sin² 60° + cos² 60° = 1."],
        "1",
        tip="This is the Pythagorean identity — the single most-used fact in trigonometry."))

    flow.append(solution_box("Q7.",
        ["2 sin² 30° + 2 cos² 30° = 2 (sin² 30° + cos² 30°) = 2 × 1 = 2."],
        "2",
        tip="Factor out the 2 first — this avoids evaluating four terms separately."))

    flow.append(solution_box("Q8.",
        ["sin 60° = √3/2,  cos 30° = √3/2,  cos 60° = 1/2,  sin 30° = 1/2.",
         "Product terms:  (√3/2)(√3/2) + (1/2)(1/2) = 3/4 + 1/4 = 1."],
        "1",
        tip="This pattern sin A cos B + cos A sin B = sin(A+B) is the sine addition formula — here A = 60°, B = 30°."))

    flow.append(solution_box("Q9.",
        ["tan 60° = √3  →  tan² 60° = 3.",
         "sin 60° = √3/2  →  sin² 60° = 3/4.",
         "Expression = 3 − 3 × (3/4) = 3 − 9/4 = (12 − 9)/4 = 3/4."],
        "3/4",
        tip="Work with exact surd values until the very end — never round prematurely."))

    flow.append(solution_box("Q10.",
        ["sin²θ = 1 − cos²θ = 1 − (5/13)² = 1 − 25/169 = 144/169.",
         "sin θ = 12/13  (θ acute ⇒ positive).",
         "tan θ = sin θ / cos θ = (12/13) / (5/13) = 12/5."],
        "sin θ = 12/13,  tan θ = 12/5",
        tip="A 5-12-13 triangle is one of the most common Pythagorean triples — recognise it instantly."))

    flow.append(solution_box("Q11.",
        ["sin 45° = 1/√2  and  cos 45° = 1/√2.",
         "Sum = 1/√2 + 1/√2 = 2/√2 = √2.",
         "Squared: (√2)² = 2.",
         "(Alternatively, (sin θ + cos θ)² = 1 + 2 sin θ cos θ = 1 + 2 × "
         "(1/2) = 2.)"],
        "2",
        tip="The identity (sin θ + cos θ)² = 1 + 2 sin θ cos θ is worth memorising — it appears in many problems."))

    flow.append(solution_box("Q12.",
        ["sin 90° = 1,  cos 0° = 1,  tan 45° = 1.",
         "Sum = 1 + 1 + 1 = 3."],
        "3",
        tip="These are the three \"boundary\" values: sin 90° = cos 0° = tan 45° = 1. Useful sanity-check anchors."))

    flow.append(Paragraph("Section C — Word Problems", STY_H2))

    flow.append(solution_box("Q13.",
        ["Sides: AB = 9 (adjacent to ∠A), BC = 12 (opposite to ∠A).",
         "Hypotenuse AC = √(9² + 12²) = √(81 + 144) = √225 = 15 cm.",
         "sin A = opposite / hypotenuse = BC / AC = 12/15 = 4/5.",
         "cos A = adjacent / hypotenuse = AB / AC = 9/15 = 3/5.",
         "tan A = opposite / adjacent = BC / AB = 12/9 = 4/3."],
        "sin A = 4/5,  cos A = 3/5,  tan A = 4/3",
        tip="9-12-15 is the 3-4-5 triangle scaled by 3. Recognising Pythagorean triples saves time."))

    flow.append(solution_box("Q14.",
        ["tan θ = opposite / adjacent = 7/24, so take opposite = 7k, "
         "adjacent = 24k.",
         "Hypotenuse h = √((7k)² + (24k)²) = √(49k² + 576k²) = √(625k²) = 25k.",
         "sin θ = O/H = 7/25.",
         "cos θ = A/H = 24/25.",
         "cosec θ = 1/sin θ = 25/7.",
         "sec θ = 1/cos θ = 25/24.",
         "cot θ = 1/tan θ = 24/7."],
        "sin θ = 7/25,  cos θ = 24/25,  cosec θ = 25/7,  "
        "sec θ = 25/24,  cot θ = 24/7",
        tip="7-24-25 is another classic Pythagorean triple. Once you spot it, all six ratios are immediate."))

    flow.append(solution_box("Q15.",
        ["Right-angled at Q; ∠P = 60°; PQ (adjacent) = 8 cm.",
         "QR (opposite):  tan 60° = QR / PQ  →  √3 = QR / 8  →  QR = 8√3 cm.",
         "PR (hypotenuse):  cos 60° = PQ / PR  →  1/2 = 8 / PR  →  PR = 16 cm."],
        "QR = 8√3 cm (≈ 13.86 cm),  PR = 16 cm",
        tip="A 30-60-90 triangle has sides in the ratio 1 : √3 : 2. Here that pattern is scaled by 8."))

    flow.append(solution_box("Q16.",
        ["sin 45° = 1/√2  →  sin² 45° = 1/2.",
         "cos 45° = 1/√2  →  cos² 45° = 1/2.",
         "Sum = 1/2 + 1/2 = 1.  ✓"],
        "Verified: sin² 45° + cos² 45° = 1",
        tip="This verification shows that the identity is more than an abstract formula — it works numerically at every angle."))

    flow.append(solution_box("Q17.",
        ["Ladder (hypotenuse) = 5 m, distance from wall (adjacent) = 3 m.",
         "Height reached h:  h = √(5² − 3²) = √(25 − 9) = √16 = 4 m.",
         "Angle θ with ground:  cos θ = 3/5  →  θ = cos⁻¹(3/5) ≈ 53.13°. "
         "(Equivalently, sin θ = 4/5, tan θ = 4/3.)"],
        "Angle ≈ 53.13° (a 3-4-5 triangle); height reached = 4 m",
        tip="3-4-5 triangles give a 53.13° / 36.87° pair of acute angles — common in textbook problems."))

    flow.append(solution_box("Q18.",
        ["2 sin θ = √3  →  sin θ = √3/2  →  θ = 60° (θ acute).",
         "Now evaluate (1 + tan²θ) · cos²θ.",
         "<b>Method 1 (substitute):</b>  tan 60° = √3, cos 60° = 1/2, so "
         "(1 + 3) · (1/4) = 4 · (1/4) = 1.",
         "<b>Method 2 (identity):</b>  1 + tan²θ = sec²θ, so the expression "
         "becomes sec²θ · cos²θ = (1/cos²θ) · cos²θ = 1."],
        "1",
        tip="Method 2 is faster and works for any θ — identities beat direct substitution when the structure matches."))

    return build_doc(os.path.join(PRACTICE_DIR,
        "CH004-practice-01-solutions.pdf"), flow)


# ===========================================================================
# PDF 6 — Practice Sheet 2 (identities, simplification, heights/distances)
# ===========================================================================
def pdf_practice_02():
    flow = []
    flow.append(Paragraph("Practice Sheet 2", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Identities, Simplification & "
                          "Heights/Distances · Easy + Medium", STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph(
        "<b>Instructions:</b> Attempt all 17 questions. Show every step of "
        "your working. Use √3 ≈ 1.732 and √2 ≈ 1.414 where required. "
        "Each MCQ carries 1 mark; numerical / proof / word problems carry "
        "2-3 marks.", STY_NOTE))

    flow.append(Paragraph("Section A — Multiple Choice (1 mark each)", STY_H2))
    flow.extend(question("Q1",
        "The value of sin²θ + cos²θ is:",
        mcq_options=["0", "1", "2", "depends on θ"], answer_lines=2))
    flow.extend(question("Q2",
        "Which identity equals sec²θ − 1?",
        mcq_options=["sin²θ", "cos²θ", "tan²θ", "cot²θ"], answer_lines=2))
    flow.extend(question("Q3",
        "sin(90° − θ) is equal to:",
        mcq_options=["sin θ", "cos θ", "tan θ", "cosec θ"], answer_lines=2))
    flow.extend(question("Q4",
        "If cosec θ = 13/5 (θ acute), then cot θ equals:",
        mcq_options=["5/13", "12/5", "13/12", "5/12"], answer_lines=2))
    flow.extend(question("Q5",
        "The simplified form of (1 − cos²θ) / sin²θ is:",
        mcq_options=["0", "1", "sin²θ", "cos²θ"], answer_lines=2))

    flow.append(Paragraph("Section B — Simplify / Prove (2 marks each)", STY_H2))
    flow.extend(question("Q6",
        "Simplify:  (1 − sin²θ) · sec²θ.", answer_lines=7))
    flow.extend(question("Q7",
        "Simplify:  (sin θ + cos θ)² + (sin θ − cos θ)².", answer_lines=8))
    flow.extend(question("Q8",
        "Prove the identity:  tan θ · cot θ = 1.", answer_lines=7))
    flow.extend(question("Q9",
        "Prove the identity:  sec²θ − tan²θ = 1.", answer_lines=8))
    flow.extend(question("Q10",
        "Simplify:  sin⁴θ − cos⁴θ.  (Express in factored form.)",
        answer_lines=8))
    flow.extend(question("Q11",
        "If sin θ + cos θ = √2, find sin θ · cos θ.", answer_lines=7))
    flow.extend(question("Q12",
        "Evaluate:  sin² 25° + sin² 65°  +  cos² 25° + cos² 65°.",
        answer_lines=8))

    flow.append(Paragraph("Section C — Heights and Distances (3 marks each)",
                          STY_H2))
    flow.extend(question("Q13",
        "A vertical pole 15 m tall casts a shadow 15√3 m long on the ground. "
        "Find the angle of elevation of the sun.", answer_lines=9))
    flow.extend(question("Q14",
        "From a point 40 m away from the foot of a tower, the angle of "
        "elevation of the top is 30°. Find the height of the tower "
        "(use √3 ≈ 1.732).", answer_lines=9))
    flow.extend(question("Q15",
        "From the top of a 60 m high building, the angle of depression of a "
        "car on the road is 60°. Find the distance of the car from the foot "
        "of the building.", answer_lines=9))
    flow.extend(question("Q16",
        "A kite is flying at a height of 60 m above the ground. The string "
        "attached to the kite is temporarily tied to a point on the ground. "
        "The inclination of the string with the ground is 60°. Find the "
        "length of the string, assuming there is no slack.", answer_lines=10))
    flow.extend(question("Q17",
        "The angles of elevation of the top of a tower from two points at "
        "distances a and b from the base (and in the same straight line) "
        "are complementary. Prove that the height of the tower is √(ab).",
        answer_lines=10))

    return build_doc(os.path.join(PRACTICE_DIR,
        "CH004-practice-02.pdf"), flow)


# ===========================================================================
# PDF 7 — Solutions for Practice Sheet 2
# ===========================================================================
def pdf_practice_02_solutions():
    flow = []
    flow.append(Paragraph("Practice Sheet 2 — Solutions", STY_TITLE))
    flow.append(Paragraph("Chapter 4 · Identities & Heights/Distances · "
                          "Step-by-step Worked Solutions", STY_SUBTITLE))
    flow.append(hrule())

    flow.append(Paragraph("How to Use These Solutions", STY_H1))
    flow.append(Paragraph(
        "The problems on Practice Sheet 2 test three skills: <b>recognising "
        "identities</b>, <b>simplifying expressions</b>, and <b>modelling "
        "real situations as right-angled triangles</b>. Read each solution "
        "carefully and notice <i>which identity</i> was used at each step — "
        "that recognition is the real skill being tested.", STY_BODY))
    flow.append(Paragraph(
        "<b>Key identities used in these solutions:</b>", STY_BODY))
    flow.append(Paragraph(
        "<b>•</b>  sin²θ + cos²θ = 1  →  sin²θ = 1 − cos²θ,  "
        "cos²θ = 1 − sin²θ.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  1 + tan²θ = sec²θ  →  tan²θ = sec²θ − 1.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  1 + cot²θ = cosec²θ  →  cot²θ = cosec²θ − 1.",
        STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  Co-function identities: sin(90° − θ) = cos θ, "
        "cos(90° − θ) = sin θ, tan(90° − θ) = cot θ.", STY_BULLET))
    flow.append(Paragraph(
        "<b>•</b>  In heights-and-distances: angle of elevation = angle of "
        "depression (alternate interior angles). Use tan θ = O/A when the "
        "hypotenuse (line of sight) is not given.", STY_BULLET))
    flow.append(Spacer(1, 4))

    flow.append(Paragraph("Section A — Multiple Choice", STY_H2))

    flow.append(solution_box("Q1.",
        ["The fundamental Pythagorean identity: sin²θ + cos²θ = 1 for "
         "every θ."],
        "(B) 1",
        tip="This is the most-referenced identity in the entire chapter. Everything else follows from it."))

    flow.append(solution_box("Q2.",
        ["From 1 + tan²θ = sec²θ, rearrange:  tan²θ = sec²θ − 1."],
        "(C) tan²θ",
        tip="sec²θ − tan²θ = 1 is the rearranged form — both directions appear in problems."))

    flow.append(solution_box("Q3.",
        ["Co-function identity:  sin(90° − θ) = cos θ."],
        "(B) cos θ",
        tip="Co-function identities swap sin↔cos, tan↔cot, sec↔cosec whenever 90° − θ appears."))

    flow.append(solution_box("Q4.",
        ["cosec θ = 13/5  →  sin θ = 5/13.",
         "cos θ = √(1 − 25/169) = √(144/169) = 12/13.",
         "cot θ = cos θ / sin θ = (12/13) / (5/13) = 12/5."],
        "(B) 12/5",
        tip="5-12-13 is yet another Pythagorean triple — these show up constantly in trig problems."))

    flow.append(solution_box("Q5.",
        ["1 − cos²θ = sin²θ (from the fundamental identity).",
         "Therefore (1 − cos²θ) / sin²θ = sin²θ / sin²θ = 1."],
        "(B) 1",
        tip="Whenever you see 1 − cos²θ, instantly replace it with sin²θ — this single substitution solves many problems."))

    flow.append(Paragraph("Section B — Simplify / Prove", STY_H2))

    flow.append(solution_box("Q6.",
        ["1 − cos²θ = sin²θ, so the expression becomes sin²θ · sec²θ.",
         "sec θ = 1 / cos θ, so sec²θ = 1 / cos²θ.",
         "sin²θ · (1 / cos²θ) = sin²θ / cos²θ = tan²θ."],
        "tan²θ",
        tip="Convert sec to 1/cos first, then cancel — this is the universal simplification strategy."))

    flow.append(solution_box("Q7.",
        ["Expand both squares:",
         "  (sin θ + cos θ)² = sin²θ + cos²θ + 2 sin θ cos θ = 1 + 2 sin θ cos θ.",
         "  (sin θ − cos θ)² = sin²θ + cos²θ − 2 sin θ cos θ = 1 − 2 sin θ cos θ.",
         "Sum = (1 + 2 sin θ cos θ) + (1 − 2 sin θ cos θ) = 2."],
        "2",
        tip="Cross-terms cancel when adding (a + b)² and (a − b)² — a classic algebra trick."))

    flow.append(solution_box("Q8.",
        ["tan θ = sin θ / cos θ  and  cot θ = cos θ / sin θ (definitions).",
         "Multiply:  tan θ · cot θ = (sin θ / cos θ) · (cos θ / sin θ) = 1.",
         "The sin θ and cos θ cancel. ∎"],
        "Proved: tan θ · cot θ = 1",
        tip="In a proof, write LHS and RHS separately and show LHS collapses to RHS — never cross the equals sign."))

    flow.append(solution_box("Q9.",
        ["Start with sin²θ + cos²θ = 1 and divide every term by cos²θ:",
         "  sin²θ / cos²θ + cos²θ / cos²θ = 1 / cos²θ.",
         "  →  tan²θ + 1 = sec²θ.",
         "Rearrange:  sec²θ − tan²θ = 1. ∎"],
        "Proved: sec²θ − tan²θ = 1",
        tip="This is exactly how the second Pythagorean identity is derived — knowing the proof helps you remember it."))

    flow.append(solution_box("Q10.",
        ["Use difference of squares:  a⁴ − b⁴ = (a² − b²)(a² + b²).",
         "sin⁴θ − cos⁴θ = (sin²θ − cos²θ)(sin²θ + cos²θ)",
         "  = (sin²θ − cos²θ) · 1  =  sin²θ − cos²θ."],
        "sin⁴θ − cos⁴θ = (sin²θ − cos²θ)(sin²θ + cos²θ) = sin²θ − cos²θ",
        tip="Spotting the difference-of-squares pattern unlocks this instantly — train your eye for algebra structures."))

    flow.append(solution_box("Q11.",
        ["Square both sides:  (sin θ + cos θ)² = (√2)² = 2.",
         "Expand:  sin²θ + cos²θ + 2 sin θ cos θ = 2.",
         "Use sin²θ + cos²θ = 1:  1 + 2 sin θ cos θ = 2.",
         "2 sin θ cos θ = 1  →  sin θ cos θ = 1/2."],
        "sin θ · cos θ = 1/2  (occurs at θ = 45°)",
        tip="This trick — squaring a sum — converts a hard equation into one that the identity can crack."))

    flow.append(solution_box("Q12.",
        ["sin 65° = sin(90° − 25°) = cos 25°, so sin² 65° = cos² 25°.",
         "cos 65° = cos(90° − 25°) = sin 25°, so cos² 65° = sin² 25°.",
         "Therefore:",
         "  sin² 25° + sin² 65° = sin² 25° + cos² 25° = 1,",
         "  cos² 25° + cos² 65° = cos² 25° + sin² 25° = 1.",
         "Total = 1 + 1 = 2."],
        "2",
        tip="Whenever two angles add to 90°, co-function identities let you swap one for the complement of the other."))

    flow.append(Paragraph("Section C — Heights and Distances", STY_H2))

    flow.append(solution_box("Q13.",
        ["Height of pole h = 15 m;  length of shadow on ground d = 15√3 m.",
         "The angle of elevation of the sun θ satisfies tan θ = h / d.",
         "tan θ = 15 / (15√3) = 1/√3.",
         "tan⁻¹(1/√3) = 30°."],
        "Angle of elevation of the sun = 30°",
        tip="When the shadow length is √3 times the object's height, the sun's elevation is 30°. If shadow = height, elevation = 45°."))

    flow.append(solution_box("Q14.",
        ["Let the tower height be h. Distance from foot = 40 m; θ = 30°.",
         "tan 30° = h / 40  →  1/√3 = h / 40  →  h = 40 / √3.",
         "Rationalise:  h = (40 √3) / 3 ≈ (40 × 1.732) / 3 ≈ 23.09 m."],
        "Height ≈ 23.09 m",
        tip="Always rationalise surds at the end: 1/√3 = √3/3. This gives the cleanest possible form."))

    flow.append(solution_box("Q15.",
        ["Height of building = 60 m.  Angle of depression = 60°, so the "
         "angle of elevation from the car is also 60° (alternate angles).",
         "tan 60° = 60 / d  →  √3 = 60 / d  →  d = 60 / √3.",
         "Rationalise:  d = (60 √3) / 3 = 20 √3 ≈ 20 × 1.732 ≈ 34.64 m."],
        "Distance of car from foot ≈ 34.64 m",
        tip="Angle of depression from above = angle of elevation from below. They are alternate interior angles."))

    flow.append(solution_box("Q16.",
        ["Height (opposite) = 60 m;  angle with ground θ = 60°;  string is "
         "the hypotenuse L.",
         "sin 60° = 60 / L  →  √3/2 = 60 / L  →  L = 120 / √3.",
         "Rationalise:  L = (120 √3) / 3 = 40 √3 ≈ 40 × 1.732 ≈ 69.28 m."],
        "Length of string ≈ 69.28 m  (exactly 40√3 m)",
        tip="When the hypotenuse is the unknown, use sin θ (if opposite is known) or cos θ (if adjacent is known)."))

    flow.append(solution_box("Q17.",
        ["Let the tower height be h. Place two points P (at distance a) and "
         "Q (at distance b) from the base, on the same side, with angles of "
         "elevation α and β respectively. Given α + β = 90° (complementary), "
         "so β = 90° − α.",
         "From P:  tan α = h / a  →  h = a tan α.",
         "From Q:  tan β = h / b  →  h = b tan β = b tan(90° − α) = b cot α "
         "= b / tan α.",
         "Multiply the two expressions for h:",
         "  h × h = (a tan α) × (b / tan α) = a · b  (the tan α cancels).",
         "Therefore  h² = ab,  so  h = √(ab). ∎"],
        "Proved: height of the tower = √(ab)",
        tip="This beautiful result links geometry and algebra: if the two elevation angles are complementary, the height is the geometric mean of the two distances."))

    return build_doc(os.path.join(PRACTICE_DIR,
        "CH004-practice-02-solutions.pdf"), flow)


# ===========================================================================
# Main
# ===========================================================================
def main():
    print("Generating CH004 Trigonometry PDFs ...")
    paths = [
        pdf_material_01(),
        pdf_material_02(),
        pdf_material_03(),
        pdf_practice_01(),
        pdf_practice_01_solutions(),
        pdf_practice_02(),
        pdf_practice_02_solutions(),
    ]
    print("\nGenerated:")
    for p in paths:
        size = os.path.getsize(p)
        print(f"  {p}  ({size:,} bytes)")
    print("\nDone.")


if __name__ == "__main__":
    main()
