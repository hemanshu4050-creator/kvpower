#!/usr/bin/env python3
"""
Power Maths · Geometry (CH003) — PDF generator
==============================================

Generates 7 educational A4 PDFs for the Geometry chapter of the Power Maths
portal (by Prof. Kalpesh Vyas):

  Materials (study text + worked examples)
    1. CH003-material-01-lines-angles.pdf
    2. CH003-material-02-triangles.pdf
    3. CH003-material-03-quadrilaterals-circles.pdf

  Practice (problems + step-by-step solutions)
    4. CH003-practice-01.pdf               (angles, parallel lines, triangles)
    5. CH003-practice-01-solutions.pdf
    6. CH003-practice-02.pdf               (quadrilaterals, circles, Pythagoras)
    7. CH003-practice-02-solutions.pdf

Author : PDF generation subagent (Task ID pdf-CH003)
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    KeepTogether, HRFlowable, ListFlowable, ListItem, CondPageBreak,
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
OUT_DIR        = "/home/z/my-project/public"
MATERIALS_DIR  = os.path.join(OUT_DIR, "materials")
PRACTICE_DIR   = os.path.join(OUT_DIR, "practice")
for d in (MATERIALS_DIR, PRACTICE_DIR):
    os.makedirs(d, exist_ok=True)

# Brand colours — teal / emerald (NO blue / indigo)
BRAND_TEAL       = HexColor('#0f766e')   # teal-700  — section headings
BRAND_EMERALD    = HexColor('#047857')   # emerald-700 — sub-headings
BRAND_DARK       = HexColor('#134e4a')   # teal-900  — chapter titles
BRAND_TINT       = HexColor('#ecfdf5')   # emerald-50
TEXT_PRIMARY     = HexColor('#1f2937')   # gray-800
TEXT_SECONDARY   = HexColor('#4b5563')   # gray-600
TEXT_MUTED       = HexColor('#6b7280')   # gray-500
LIGHT_BG         = HexColor('#f3f4f6')   # gray-100  — example boxes
LIGHT_BORDER     = HexColor('#d1d5db')   # gray-300
ANSWER_BG        = HexColor('#fef3c7')   # amber-100 — final-answer highlight
ANSWER_BORDER    = HexColor('#f59e0b')   # amber-500
ANSWER_TEXT      = HexColor('#92400e')   # amber-800

PAGE_W, PAGE_H = A4
MARGIN_L = 50
MARGIN_R = 50
MARGIN_T = 60      # leaves room for header band
MARGIN_B = 55      # leaves room for footer band

# ----------------------------------------------------------------------------
# Font registration (FreeSans — full Unicode math glyph coverage)
# ----------------------------------------------------------------------------
FONT_DIR_FREE = "/usr/share/fonts/truetype/freefont"
pdfmetrics.registerFont(TTFont('Sans',         f"{FONT_DIR_FREE}/FreeSans.ttf"))
pdfmetrics.registerFont(TTFont('Sans-Bold',    f"{FONT_DIR_FREE}/FreeSansBold.ttf"))
pdfmetrics.registerFont(TTFont('Sans-Italic',  f"{FONT_DIR_FREE}/FreeSansOblique.ttf"))
pdfmetrics.registerFont(TTFont('Sans-BoldIt',  f"{FONT_DIR_FREE}/FreeSansBoldOblique.ttf"))
pdfmetrics.registerFontFamily(
    'Sans',
    normal='Sans',
    bold='Sans-Bold',
    italic='Sans-Italic',
    boldItalic='Sans-BoldIt',
)

# ----------------------------------------------------------------------------
# NumberedCanvas — adds "Page X of Y" + brand header/footer on every page
# ----------------------------------------------------------------------------
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_page_states)
        for i, state in enumerate(self._saved_page_states):
            self.__dict__.update(state)
            self._draw_chrome(i + 1, total)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def _draw_chrome(self, page_num, total_pages):
        self.saveState()
        # ---------- Header band ----------
        self.setFont('Sans-Bold', 9)
        self.setFillColor(BRAND_TEAL)
        self.drawString(MARGIN_L, PAGE_H - 30, "Power Maths · Geometry")
        self.setFont('Sans-Italic', 9)
        self.setFillColor(TEXT_SECONDARY)
        self.drawRightString(PAGE_W - MARGIN_R, PAGE_H - 30, "by Prof. Kalpesh Vyas")
        # Header underline
        self.setStrokeColor(BRAND_TEAL)
        self.setLineWidth(1.0)
        self.line(MARGIN_L, PAGE_H - 36, PAGE_W - MARGIN_R, PAGE_H - 36)

        # ---------- Footer ----------
        self.setStrokeColor(LIGHT_BORDER)
        self.setLineWidth(0.5)
        self.line(MARGIN_L, 42, PAGE_W - MARGIN_R, 42)
        self.setFont('Sans', 8)
        self.setFillColor(TEXT_MUTED)
        self.drawString(
            MARGIN_L, 30,
            "© Power Maths · Prof. Kalpesh Vyas · For enrolled students only"
        )
        self.drawRightString(
            PAGE_W - MARGIN_R, 30,
            f"Page {page_num} of {total_pages}"
        )
        self.restoreState()


# ----------------------------------------------------------------------------
# Paragraph styles
# ----------------------------------------------------------------------------
BODY = ParagraphStyle(
    'Body', fontName='Sans', fontSize=11, leading=16.5,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY, spaceAfter=6,
)
BODY_LEFT = ParagraphStyle('BodyLeft', parent=BODY, alignment=TA_LEFT)
BODY_CENTER = ParagraphStyle('BodyCenter', parent=BODY, alignment=TA_CENTER)

H1 = ParagraphStyle(
    'H1', fontName='Sans-Bold', fontSize=22, leading=28,
    textColor=BRAND_DARK, alignment=TA_LEFT, spaceAfter=4, spaceBefore=0,
)
H1_SUB = ParagraphStyle(
    'H1Sub', fontName='Sans-Italic', fontSize=11.5, leading=15,
    textColor=TEXT_SECONDARY, alignment=TA_LEFT, spaceAfter=10,
)
H2 = ParagraphStyle(
    'H2', fontName='Sans-Bold', fontSize=14, leading=20,
    textColor=BRAND_TEAL, alignment=TA_LEFT, spaceAfter=4, spaceBefore=12,
)
H3 = ParagraphStyle(
    'H3', fontName='Sans-Bold', fontSize=12, leading=16,
    textColor=BRAND_EMERALD, alignment=TA_LEFT, spaceAfter=3, spaceBefore=8,
)

EX_TITLE = ParagraphStyle(
    'ExTitle', fontName='Sans-Bold', fontSize=10.5, leading=14,
    textColor=BRAND_DARK, spaceAfter=2,
)
EX_BODY = ParagraphStyle(
    'ExBody', fontName='Sans', fontSize=10.5, leading=15,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=2,
)

Q_STYLE = ParagraphStyle(
    'Q', fontName='Sans', fontSize=11, leading=15.5,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=2,
)
OPT_STYLE = ParagraphStyle(
    'Opt', fontName='Sans', fontSize=11, leading=15,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    leftIndent=18, spaceAfter=1,
)

ANS_LABEL = ParagraphStyle(
    'AnsLabel', fontName='Sans-Bold', fontSize=11, leading=14,
    textColor=ANSWER_TEXT, spaceBefore=4, spaceAfter=2,
)
SOL_STEP = ParagraphStyle(
    'SolStep', fontName='Sans', fontSize=10.5, leading=15,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=3,
    leftIndent=4,
)
RECAP = ParagraphStyle(
    'Recap', fontName='Sans', fontSize=10.5, leading=15,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=2,
    leftIndent=12, bulletIndent=2,
)

TABLE_CELL = ParagraphStyle(
    'Cell', fontName='Sans', fontSize=10, leading=13.5,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT,
)
TABLE_HEAD = ParagraphStyle(
    'CellH', fontName='Sans-Bold', fontSize=10, leading=13.5,
    textColor=white, alignment=TA_LEFT,
)

# ----------------------------------------------------------------------------
# Helper builders
# ----------------------------------------------------------------------------
def h1(title, sub=None):
    flow = [Paragraph(title, H1)]
    if sub:
        flow.append(Paragraph(sub, H1_SUB))
    return flow

def h2(text):
    return Paragraph(text, H2)

def h3(text):
    return Paragraph(text, H3)

def p(text):
    return Paragraph(text, BODY)

def pl(text):
    return Paragraph(text, BODY_LEFT)

def sp(h=6):
    return Spacer(1, h)

def hr(color=LIGHT_BORDER, w=0.5, dash=None):
    return HRFlowable(width='100%', thickness=w, color=color, dash=dash,
                      spaceBefore=2, spaceAfter=2)

def bullet_list(items):
    """Render an unnumbered bullet list."""
    items = [ListItem(Paragraph(t, RECAP), leftIndent=18) for t in items]
    return ListFlowable(items, bulletType='bullet', start='•',
                        bulletColor=BRAND_TEAL, bulletFontSize=10,
                        leftIndent=14, bulletOffsetY=-1)

def numbered_list(items, start=1):
    items = [ListItem(Paragraph(t, RECAP), leftIndent=22) for t in items]
    return ListFlowable(items, bulletType='1', start=start,
                        bulletFontName='Sans-Bold', bulletColor=BRAND_TEAL,
                        leftIndent=18)

def example_box(title, body_paragraphs):
    """Light-gray rounded box containing a worked example."""
    inner = [Paragraph(f"<b>Worked Example.</b> {title}", EX_TITLE)]
    for ln in body_paragraphs:
        if isinstance(ln, str):
            inner.append(Paragraph(ln, EX_BODY))
        else:
            inner.append(ln)
    inner.append(Spacer(1, 2))
    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 12])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (-1, -1), LIGHT_BG),
        ('BOX',           (0, 0), (-1, -1), 0.6, LIGHT_BORDER),
        ('LEFTPADDING',   (0, 0), (-1, -1), 10),
        ('RIGHTPADDING',  (0, 0), (-1, -1), 10),
        ('TOPPADDING',    (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('ROUNDEDCORNERS', [6, 6, 6, 6]),
    ]))
    return KeepTogether([Spacer(1, 4), tbl, Spacer(1, 6)])

def answer_box(text):
    """Highlighted final-answer line inside a solution block (returns list)."""
    inner = Paragraph(f"<b>Answer:</b> {text}", ParagraphStyle(
        'AnsIn', fontName='Sans-Bold', fontSize=11, leading=14,
        textColor=ANSWER_TEXT))
    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 12])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (-1, -1), ANSWER_BG),
        ('BOX',           (0, 0), (-1, -1), 0.8, ANSWER_BORDER),
        ('LEFTPADDING',   (0, 0), (-1, -1), 8),
        ('RIGHTPADDING',  (0, 0), (-1, -1), 8),
        ('TOPPADDING',    (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('ROUNDEDCORNERS', [4, 4, 4, 4]),
    ]))
    return [Spacer(1, 2), tbl, Spacer(1, 10)]

def writing_lines(n_lines, height_per_line=18, indent=0):
    """Ruled writing space, like a school worksheet."""
    width = PAGE_W - MARGIN_L - MARGIN_R - 12 - indent
    data = [[''] for _ in range(n_lines)]
    tbl = Table(data, colWidths=[width],
                rowHeights=[height_per_line] * n_lines)
    style = [
        ('LINEBELOW', (0, i), (-1, i), 0.4, LIGHT_BORDER) for i in range(n_lines)
    ]
    style += [
        ('LEFTPADDING',  (0, 0), (-1, -1), 2),
        ('RIGHTPADDING', (0, 0), (-1, -1), 2),
        ('TOPPADDING',   (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING',(0, 0), (-1, -1), 0),
    ]
    tbl.setStyle(TableStyle(style))
    return tbl

CONCEPT_STYLE = ParagraphStyle(
    'Concept', fontName='Sans-Italic', fontSize=10, leading=13.5,
    textColor=BRAND_EMERALD, alignment=TA_LEFT, spaceAfter=3, leftIndent=4,
)
TIP_STYLE = ParagraphStyle(
    'Tip', fontName='Sans-Italic', fontSize=10, leading=13.5,
    textColor=TEXT_SECONDARY, alignment=TA_LEFT, spaceAfter=4, leftIndent=4,
)

def solution_block(qnum, question_text, steps, answer_text,
                   concept=None, tip=None):
    """A complete Q-block for a solution PDF: question, concept, steps,
    highlighted answer, optional tip. Returns a list of flowables (no
    KeepTogether wrapper) so solutions flow naturally across pages."""
    flow = [CondPageBreak(120),
            Paragraph(f"<b>Q{qnum}.</b> {question_text}", Q_STYLE),
            Spacer(1, 2)]
    if concept:
        flow.append(Paragraph(f"<b>Concept:</b> {concept}", CONCEPT_STYLE))
    flow.append(Paragraph("<b>Solution:</b>", ParagraphStyle(
        'SolL', fontName='Sans-Bold', fontSize=10.5, leading=14,
        textColor=BRAND_EMERALD, spaceAfter=2)))
    for s in steps:
        flow.append(Paragraph(s, SOL_STEP))
    flow.extend(answer_box(answer_text))
    if tip:
        flow.append(Paragraph(f"<i>Tip:</i> {tip}", TIP_STYLE))
    return flow

def problem_block(qnum, text, options=None, lines=0, marks=None, mcq_space=14):
    """A practice-sheet problem with optional MCQ options or ruled answer
    space (`lines` = number of writing lines)."""
    flow = [Paragraph(f"<b>Q{qnum}.</b> {text}", Q_STYLE)]
    if marks:
        # Grammar: "1 mark" vs "N marks"
        try:
            n = int(str(marks).split()[0])
            label = f"{marks} mark" if n == 1 else f"{marks} marks"
        except ValueError:
            label = f"{marks} marks"
        flow.append(Paragraph(f"<i>[{label}]</i>", ParagraphStyle(
            'Mrk', fontName='Sans-Italic', fontSize=9, leading=12,
            textColor=TEXT_MUTED, alignment=TA_RIGHT, spaceAfter=2)))
    if options:
        for opt in options:
            flow.append(Paragraph(opt, OPT_STYLE))
        flow.append(Spacer(1, mcq_space))
    elif lines and lines > 0:
        flow.append(Spacer(1, 4))
        flow.append(writing_lines(lines))
        flow.append(Spacer(1, 6))
    else:
        flow.append(Spacer(1, 8))
    return KeepTogether(flow)

def info_table(rows, col_widths=None, header_row=True):
    """Generic data table with brand styling."""
    if col_widths is None:
        col_widths = [(PAGE_W - MARGIN_L - MARGIN_R) / len(rows[0])] * len(rows[0])
    # Wrap text cells in Paragraphs
    table_data = []
    for r_idx, row in enumerate(rows):
        new_row = []
        for c in row:
            if isinstance(c, str):
                style = TABLE_HEAD if (header_row and r_idx == 0) else TABLE_CELL
                new_row.append(Paragraph(c, style))
            else:
                new_row.append(c)
        table_data.append(new_row)
    tbl = Table(table_data, colWidths=col_widths, repeatRows=1 if header_row else 0)
    style = [
        ('GRID',          (0, 0), (-1, -1), 0.4, LIGHT_BORDER),
        ('VALIGN',        (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING',   (0, 0), (-1, -1), 6),
        ('RIGHTPADDING',  (0, 0), (-1, -1), 6),
        ('TOPPADDING',    (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]
    if header_row:
        style.append(('BACKGROUND', (0, 0), (-1, 0), BRAND_TEAL))
        style.append(('ROWBACKGROUNDS', (0, 1), (-1, -1),
                      [white, HexColor('#f9fafb')]))
    tbl.setStyle(TableStyle(style))
    return tbl

def section_card(title, body_lines):
    """A bordered teal-tinted card used for summary/recap blocks."""
    inner = [Paragraph(f"<b>{title}</b>", ParagraphStyle(
        'CardT', fontName='Sans-Bold', fontSize=11, leading=14,
        textColor=BRAND_DARK, spaceAfter=4))]
    for ln in body_lines:
        if isinstance(ln, str):
            inner.append(Paragraph(ln, ParagraphStyle(
                'CardB', fontName='Sans', fontSize=10.5, leading=15,
                textColor=TEXT_PRIMARY, spaceAfter=2, leftIndent=4)))
        else:
            inner.append(ln)
    tbl = Table([[inner]], colWidths=[PAGE_W - MARGIN_L - MARGIN_R - 12])
    tbl.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (-1, -1), BRAND_TINT),
        ('BOX',           (0, 0), (-1, -1), 0.8, BRAND_TEAL),
        ('LINEBEFORE',    (0, 0), (0, -1), 3, BRAND_TEAL),
        ('LEFTPADDING',   (0, 0), (-1, -1), 10),
        ('RIGHTPADDING',  (0, 0), (-1, -1), 10),
        ('TOPPADDING',    (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    return KeepTogether([Spacer(1, 6), tbl, Spacer(1, 8)])


# ----------------------------------------------------------------------------
# Page-build helper
# ----------------------------------------------------------------------------
def build_pdf(path, story):
    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
        title=os.path.basename(path),
        author="Prof. Kalpesh Vyas",
        subject="Power Maths · Geometry (CH003)",
    )
    doc.build(story, canvasmaker=NumberedCanvas)
    size_kb = os.path.getsize(path) / 1024
    print(f"  ✓ {os.path.basename(path):50s}  {size_kb:6.1f} KB")
    return path


# ===========================================================================
#  MATERIAL 1 — Lines and Angles
# ===========================================================================
def material_01_lines_angles():
    s = []
    s += h1("Lines and Angles",
            "Material 01 · Geometry (CH003) · Power Maths by Prof. Kalpesh Vyas")

    s.append(p(
        "Geometry is the branch of mathematics that studies the size, shape and "
        "position of figures. The two most fundamental building-blocks of all "
        "geometric figures are <b>lines</b> and <b>angles</b>. Once you understand "
        "how they behave — especially when lines cross or run parallel to each "
        "other — you can solve almost every school-level geometry problem with "
        "confidence. This material covers types of angles, angle pairs, parallel "
        "lines cut by a transversal, and the key properties you must memorise."))

    s.append(h2("1.  Basic Terms — Points, Lines and Rays"))
    s.append(p(
        "A <b>point</b> has no length, breadth or thickness; it only marks a "
        "position and is named with a capital letter (e.g. P). A <b>line</b> "
        "extends endlessly in both directions and is denoted by two points on "
        "it, such as AB&#x20;. A <b>line segment</b> AB is the part of a line "
        "between two fixed endpoints A and B — it has a definite length. A "
        "<b>ray</b> has one endpoint and extends endlessly in one direction; "
        "ray AB starts at A and passes through B."))

    s.append(p(
        "Two lines in a plane are either <b>intersecting</b> (they meet at one "
        "point) or <b>parallel</b> (they never meet, no matter how far they are "
        "extended). When two lines intersect at right angles (90°) they are "
        "called <b>perpendicular</b> lines, written AB ⊥ CD."))

    s.append(h2("2.  What is an Angle?"))
    s.append(p(
        "An <b>angle</b> is formed when two rays (or line segments) share a "
        "common endpoint. The common endpoint is called the <b>vertex</b> and "
        "the two rays are called the <b>arms</b> of the angle. An angle is "
        "denoted by the symbol ∠ followed by three letters (vertex in the "
        "middle), such as ∠ABC, or by a single letter or number when there is "
        "no ambiguity, such as ∠x or ∠1."))
    s.append(p(
        "Angles are measured in <b>degrees</b> (°) using a protractor. A full "
        "turn around a point measures 360°, a half-turn measures 180° and a "
        "quarter-turn measures 90°."))

    s.append(h2("3.  Types of Angles"))
    s.append(p(
        "Angles are classified by their measure. The table below summarises "
        "the six standard types you must know."))
    s.append(sp(2))
    s.append(info_table([
        ["Type of angle", "Measure", "Example"],
        ["Acute angle",      "0° &lt; θ &lt; 90°",      "35°, 60°, 89°"],
        ["Right angle",      "θ = 90°",                  "the corner of a square"],
        ["Obtuse angle",     "90° &lt; θ &lt; 180°",    "120°, 150°"],
        ["Straight angle",   "θ = 180°",                 "a straight line"],
        ["Reflex angle",     "180° &lt; θ &lt; 360°",   "270°, 300°"],
        ["Complete angle",   "θ = 360°",                 "one full rotation"],
    ], col_widths=[120, 160, 220]))
    s.append(sp(4))

    s.append(example_box(
        "Identifying angle types",
        ["Classify each angle: (a) 45°,  (b) 90°,  (c) 135°,  (d) 180°,  (e) 320°.",
         "(a) 0° &lt; 45° &lt; 90°  →  <b>acute</b>.",
         "(b) 90° exactly  →  <b>right angle</b>.",
         "(c) 90° &lt; 135° &lt; 180°  →  <b>obtuse</b>.",
         "(d) 180° exactly  →  <b>straight angle</b>.",
         "(e) 180° &lt; 320° &lt; 360°  →  <b>reflex angle</b>."]))

    s.append(h2("4.  Complementary and Supplementary Angles"))
    s.append(p(
        "Two angles are <b>complementary</b> if the sum of their measures is "
        "90°. Each angle is called the <i>complement</i> of the other. For "
        "example, 35° and 55° are complementary because 35° + 55° = 90°. "
        "If two angles are equal and complementary, each one measures 45°."))
    s.append(p(
        "Two angles are <b>supplementary</b> if the sum of their measures is "
        "180°. Each angle is called the <i>supplement</i> of the other. For "
        "example, 110° and 70° are supplementary because 110° + 70° = 180°. "
        "If two angles are equal and supplementary, each one measures 90°."))

    s.append(example_box(
        "Finding complements and supplements",
        ["Find (a) the complement of 35° and (b) the supplement of 110°.",
         "<b>(a)</b> Complement = 90° − 35° = <b>55°</b>.",
         "<b>(b)</b> Supplement = 180° − 110° = <b>70°</b>.",
         "Quick check: 35° + 55° = 90° ✓   and   110° + 70° = 180° ✓."]))

    s.append(h2("5.  Adjacent Angles, Linear Pair and Vertically Opposite Angles"))
    s.append(p(
        "<b>Adjacent angles</b> share a common vertex and a common arm, and "
        "lie on opposite sides of that common arm. In the figure below, ∠ABD "
        "and ∠DBC are adjacent: common vertex B, common arm BC — sorry, common "
        "arm BD — and the non-common arms BA and BC lie on opposite sides of BD."))
    s.append(p(
        "A <b>linear pair</b> is a special pair of adjacent angles whose "
        "non-common arms form a straight line. The two angles of a linear "
        "pair are always <b>supplementary</b> — they add up to 180°."))
    s.append(p(
        "When two lines intersect, the angles that lie <i>opposite</i> each "
        "other at the vertex are called <b>vertically opposite angles</b>. "
        "Vertically opposite angles are always <b>equal</b>."))

    s.append(example_box(
        "Using vertically opposite angles",
        ["Two lines PQ and RS intersect at O. If ∠POR = 70°, find ∠QOS and ∠ROQ.",
         "∠POR and ∠QOS are vertically opposite, so ∠QOS = ∠POR = <b>70°</b>.",
         "∠POR and ∠ROQ form a linear pair on line PQ, so ∠ROQ = 180° − 70° = <b>110°</b>.",
         "(And ∠POS, vertically opposite to ∠ROQ, is also 110° — a good check.)"]))

    s.append(h2("6.  Parallel Lines and a Transversal"))
    s.append(p(
        "Two lines in a plane are <b>parallel</b> if they never meet, no matter "
        "how far they are extended. We write AB ∥ CD. A <b>transversal</b> is a "
        "line that intersects two (or more) lines at distinct points. When a "
        "transversal cuts two parallel lines, it forms <b>eight angles</b> at "
        "the two points of intersection. These eight angles fall into four "
        "special pairs whose properties are summarised below."))

    s.append(info_table([
        ["Pair of angles", "Position", "Property when lines are parallel"],
        ["Corresponding angles", "same side of transversal, same side of each line",  "equal"],
        ["Alternate interior angles", "opposite sides of transversal, between the lines", "equal"],
        ["Alternate exterior angles", "opposite sides of transversal, outside the lines", "equal"],
        ["Co-interior (allied) angles", "same side of transversal, between the lines", "supplementary (sum = 180°)"],
    ], col_widths=[130, 200, 200]))
    s.append(sp(4))

    s.append(p(
        "<b>Converse</b> statements are also true: if a transversal cuts two "
        "lines and <i>any one</i> of the above equal/supplementary conditions "
        "holds, then the two lines must be parallel. This is how we prove that "
        "two given lines are parallel."))

    s.append(example_box(
        "Finding unknown angles with parallel lines",
        ["AB ∥ CD and a transversal cuts them. If one corresponding angle is "
         "62°, find all the other seven angles.",
         "Let ∠1 = 62° (given). Corresponding angles are equal, so the matching "
         "angle at the second intersection is also 62°.",
         "The angle vertically opposite ∠1 is also 62°, and the angle vertically "
         "opposite the corresponding angle is also 62°. So four angles are 62°.",
         "Each of the remaining four angles forms a linear pair with a 62° "
         "angle, so each measures 180° − 62° = 118°.",
         "Hence four angles are <b>62°</b> and four angles are <b>118°</b>."]))

    s.append(example_box(
        "Using co-interior angles",
        ["In the figure, AB ∥ CD, transversal PQ meets AB at E and CD at F. "
         "If ∠BEF = 3x and ∠EFC = 2x + 30°, find x.",
         "∠BEF and ∠EFC are co-interior angles on the same side of the "
         "transversal, so their sum is 180°.",
         "3x + (2x + 30°) = 180°",
         "5x + 30° = 180°  →  5x = 150°  →  x = <b>30°</b>.",
         "Check: ∠BEF = 90° and ∠EFC = 90° — both right angles, sum = 180° ✓."]))

    s.append(h2("7.  Angle Bisector"))
    s.append(p(
        "An <b>angle bisector</b> is a ray that divides an angle into two "
        "equal parts. If the ray BD bisects ∠ABC, then ∠ABD = ∠DBC = "
        "½ ∠ABC. Conversely, if a ray BD through the vertex B satisfies "
        "∠ABD = ∠DBC, then BD is the bisector of ∠ABC. The angle bisector "
        "is used constantly in congruence proofs and in constructing "
        "special lines inside triangles."))
    s.append(p(
        "A point on the angle bisector of an angle is <b>equidistant</b> "
        "from the two arms of the angle — that is, the perpendicular "
        "distances from the point to the two arms are equal."))

    s.append(example_box(
        "Using an angle bisector",
        ["BD bisects ∠ABC. If ∠ABD = (3x + 5)° and ∠DBC = (2x + 15)°, "
         "find x and ∠ABC.",
         "Since BD is the bisector, the two parts are equal: 3x + 5 = 2x + 15.",
         "3x − 2x = 15 − 5  →  x = 10°.",
         "So ∠ABD = (3·10 + 5)° = 35° and ∠DBC = (2·10 + 15)° = 35°.",
         "Hence ∠ABC = ∠ABD + ∠DBC = 35° + 35° = <b>70°</b>."]))

    s.append(h2("8.  Perpendicular Bisector of a Segment"))
    s.append(p(
        "The <b>perpendicular bisector</b> of a line segment AB is the line "
        "that is perpendicular to AB and passes through its midpoint M. "
        "Every point on the perpendicular bisector is <b>equidistant</b> "
        "from the endpoints A and B. Conversely, any point that is "
        "equidistant from A and B lies on the perpendicular bisector of AB. "
        "This converse is a powerful tool for proving that four points "
        "form a special quadrilateral (e.g. a rhombus)."))

    s.append(example_box(
        "Property of the perpendicular bisector",
        ["P lies on the perpendicular bisector of segment AB. If PA = "
         "(2x + 3) cm and PB = (3x − 2) cm, find x and the actual length.",
         "Any point on the perpendicular bisector is equidistant from the "
         "endpoints, so PA = PB.",
         "2x + 3 = 3x − 2  →  3 + 2 = 3x − 2x  →  x = 5.",
         "Length = PA = (2·5 + 3) cm = <b>13 cm</b>  (also PB = 3·5 − 2 = 13 cm ✓)."]))

    s.append(section_card(
        "Common Mistakes to Avoid — Lines &amp; Angles",
        ["• Complementary = 90°, supplementary = 180°. Mixing these up is the "
         "most common slip — memorise them as a pair.",
         "• Vertically opposite angles are equal <i>only when two lines "
         "intersect</i> — not for any pair of opposite-looking angles.",
         "• Corresponding / alternate angles are equal <i>only if the two "
         "lines are parallel</i>. Always state the parallel-lines condition.",
         "• Co-interior angles are <b>supplementary</b> (sum to 180°), "
         "<b>not equal</b>. Alternate angles are equal, co-interior are not.",
         "• An angle of exactly 90° is a right angle, <b>not</b> acute. "
         "An angle of exactly 180° is a straight angle, <b>not</b> obtuse."]))

    s.append(section_card(
        "Quick Recap — Lines &amp; Angles",
        ["• Acute &lt; 90° &lt; Obtuse &lt; 180° &lt; Reflex &lt; 360°.",
         "• Complementary pair sums to 90°; supplementary pair sums to 180°.",
         "• Angles of a linear pair are supplementary.",
         "• Vertically opposite angles are always equal.",
         "• For parallel lines cut by a transversal: corresponding = alternate "
         "(interior &amp; exterior) = equal; co-interior pair sums to 180°.",
         "• Any one of the above conditions is enough to <i>prove</i> two lines "
         "are parallel.",
         "• An angle bisector divides an angle into two equal parts.",
         "• Points on the perpendicular bisector of a segment are equidistant "
         "from its endpoints."]))

    return s


# ===========================================================================
#  MATERIAL 2 — Triangles
# ===========================================================================
def material_02_triangles():
    s = []
    s += h1("Triangles",
            "Material 02 · Geometry (CH003) · Power Maths by Prof. Kalpesh Vyas")

    s.append(p(
        "A <b>triangle</b> is a closed plane figure formed by three line "
        "segments joining three non-collinear points. It is the simplest "
        "polygon and the foundation of most geometric reasoning. Every "
        "triangle has three sides, three vertices, three interior angles and "
        "three exterior angles. We write △ABC for the triangle whose vertices "
        "are A, B and C; its sides are AB, BC and CA and its angles are "
        "∠A, ∠B and ∠C."))

    s.append(h2("1.  Classification by Sides"))
    s.append(info_table([
        ["Type",         "Property",                          "Example"],
        ["Scalene",      "All three sides of different lengths",         "3 cm, 4 cm, 5 cm"],
        ["Isosceles",    "Any two sides equal",                           "5 cm, 5 cm, 7 cm"],
        ["Equilateral",  "All three sides equal",                         "6 cm, 6 cm, 6 cm"],
    ], col_widths=[110, 240, 180]))
    s.append(sp(4))
    s.append(p(
        "An equilateral triangle is also <i>equiangular</i> — all three angles "
        "are equal (each is 60°). In an isosceles triangle, the angles opposite "
        "the equal sides are also equal."))

    s.append(h2("2.  Classification by Angles"))
    s.append(info_table([
        ["Type",             "Property",                                "Note"],
        ["Acute-angled",     "All three angles &lt; 90°",               "e.g. 60°, 60°, 60°"],
        ["Right-angled",     "One angle = 90°",                          "the other two are acute"],
        ["Obtuse-angled",    "One angle &gt; 90°",                       "the other two are acute"],
    ], col_widths=[120, 220, 190]))
    s.append(sp(4))
    s.append(p(
        "A triangle can have <b>at most one</b> right or obtuse angle — never "
        "two — because the sum of all three angles is fixed at 180°."))

    s.append(h2("3.  The Angle-Sum Property"))
    s.append(p(
        "The sum of the three interior angles of any triangle is <b>180°</b>. "
        "This is the <b>angle-sum property</b> of a triangle and is one of "
        "the most frequently used facts in geometry."))
    s.append(p("For △ABC:   ∠A + ∠B + ∠C = 180°."))

    s.append(example_box(
        "Using the angle-sum property",
        ["In △PQR, ∠P = 45° and ∠Q = 65°. Find ∠R.",
         "By the angle-sum property: ∠P + ∠Q + ∠R = 180°.",
         "45° + 65° + ∠R = 180°  →  110° + ∠R = 180°.",
         "∠R = 180° − 110° = <b>70°</b>."]))

    s.append(example_box(
        "Isosceles triangle with an unknown",
        ["In an isosceles triangle, the equal angles are each (2x + 10)° and "
         "the third angle is 3x°. Find x and all three angles.",
         "Let the equal angles be A = B = (2x + 10)° and C = 3x°.",
         "A + B + C = 180°  →  2(2x + 10) + 3x = 180.",
         "4x + 20 + 3x = 180  →  7x = 160  →  x = 160 ÷ 7 ≈ <b>22.86°</b>.",
         "So the equal angles ≈ (2·22.86 + 10)° ≈ 55.7° each, and the third "
         "angle ≈ 68.6°. (Check: 55.7 + 55.7 + 68.6 = 180.0 ✓.)"]))

    s.append(h2("4.  The Exterior-Angle Theorem"))
    s.append(p(
        "If a side of a triangle is produced (extended) beyond a vertex, the "
        "angle so formed is called an <b>exterior angle</b>. The two interior "
        "angles that are <i>not</i> adjacent to it are called the <b>interior "
        "opposite angles</b>."))
    s.append(p(
        "<b>Exterior-Angle Theorem.</b> The exterior angle of a triangle is "
        "equal to the sum of its two interior opposite angles."))
    s.append(p("In symbols, for △ABC with side BC extended to D:   "
               "∠ACD = ∠A + ∠B."))

    s.append(example_box(
        "Exterior-angle theorem",
        ["In △ABC, ∠A = 50°, ∠B = 70° and side BC is extended to D. "
         "Find the exterior angle ∠ACD (a) by the theorem and (b) by the "
         "angle-sum property — to verify both agree.",
         "<b>(a)</b> By the exterior-angle theorem: ∠ACD = ∠A + ∠B = 50° + 70° = <b>120°</b>.",
         "<b>(b)</b> ∠ACB = 180° − (50° + 70°) = 60°. ∠ACD is a linear pair with "
         "∠ACB, so ∠ACD = 180° − 60° = <b>120°</b>.   ✓  Both methods agree."]))

    s.append(h2("5.  Pythagoras' Theorem"))
    s.append(p(
        "In a <b>right-angled triangle</b>, the side opposite the right angle "
        "is called the <b>hypotenuse</b>; it is the longest side. The other "
        "two sides are called the <b>legs</b> (or perpendicular and base)."))
    s.append(p(
        "<b>Pythagoras' Theorem.</b> In a right triangle, the square of the "
        "hypotenuse equals the sum of the squares of the other two sides."))
    s.append(p("If the legs are a and b and the hypotenuse is c, then:    "
               "<b>a² + b² = c²</b>."))
    s.append(p(
        "<b>Converse.</b> If the sum of the squares of two sides equals the "
        "square of the third, the triangle is right-angled — with the right "
        "angle opposite the longest side."))

    s.append(example_box(
        "Finding the hypotenuse",
        ["A right triangle has legs 6 cm and 8 cm. Find the hypotenuse.",
         "Let the hypotenuse be c. By Pythagoras' theorem:",
         "c² = 6² + 8² = 36 + 64 = 100.",
         "c = √100 = <b>10 cm</b>."]))

    s.append(example_box(
        "Finding a leg and testing right-angledness",
        ["<b>(a)</b> The hypotenuse of a right triangle is 13 cm and one leg "
         "is 5 cm. Find the other leg.",
         "<b>(b)</b> Check whether a triangle with sides 7 cm, 24 cm, 25 cm is "
         "right-angled.",
         "<b>(a)</b>  Let the unknown leg be x. Then x² + 5² = 13² → "
         "x² + 25 = 169 → x² = 144 → x = <b>12 cm</b>.",
         "<b>(b)</b>  The longest side is 25 cm. Check: 7² + 24² = 49 + 576 = "
         "625 = 25². Since 7² + 24² = 25², the triangle <b>is right-angled</b> "
         "(right angle opposite the 25 cm side)."]))

    s.append(h2("6.  Congruence of Triangles"))
    s.append(p(
        "Two triangles are <b>congruent</b> (written △ABC ≅ △PQR) if their "
        "corresponding sides and corresponding angles are all equal. There are "
        "four standard <b>rules of congruence</b> — prove any one of these "
        "conditions and the triangles are congruent:"))

    s.append(info_table([
        ["Rule", "Stands for", "What must be equal"],
        ["SSS", "Side-Side-Side",         "All three pairs of corresponding sides"],
        ["SAS", "Side-Angle-Side",        "Two pairs of sides and the included angle"],
        ["ASA", "Angle-Side-Angle",       "Two pairs of angles and the included side"],
        ["RHS", "Right-angle-Hypotenuse-Side", "Right angle, hypotenuse and one leg (right-angled triangles only)"],
    ], col_widths=[60, 170, 290]))
    s.append(sp(4))
    s.append(p(
        "<b>Note.</b> There is no SSA or AAA rule — two triangles with the "
        "same angles need not be congruent (they may only be similar). Always "
        "place the equal angle <i>between</i> the equal sides for SAS, and "
        "the equal side <i>between</i> the equal angles for ASA."))

    s.append(example_box(
        "Identifying the congruence rule",
        ["<b>(a)</b>  In △ABC and △DEF, AB = DE, BC = EF and ∠B = ∠E. "
         "Which rule proves the triangles congruent?",
         "<b>(b)</b>  In △PQR and △LMN, ∠P = ∠L, ∠Q = ∠M and PQ = LM. "
         "Which rule applies here?",
         "<b>(a)</b>  Two sides and the angle <i>between</i> them are equal "
         "→ <b>SAS</b> congruence.",
         "<b>(b)</b>  Two angles and the side <i>between</i> them are equal "
         "→ <b>ASA</b> congruence."]))

    s.append(h2("7.  The Triangle Inequality"))
    s.append(p(
        "The <b>triangle inequality</b> states that the sum of the lengths "
        "of any two sides of a triangle is always <b>greater than</b> the "
        "length of the third side. Equivalently, the difference of any two "
        "sides is always <b>less than</b> the third side. For a triangle "
        "with sides a, b, c:"))
    s.append(p("    a + b &gt; c,    b + c &gt; a,    c + a &gt; b,    "
               "and    |a − b| &lt; c."))
    s.append(p(
        "This is the test you use to decide whether three given lengths "
        "can form a triangle at all."))

    s.append(example_box(
        "Can these lengths form a triangle?",
        ["<b>(a)</b> Can 4 cm, 6 cm, 10 cm be the sides of a triangle?",
         "<b>(b)</b> Can 5 cm, 7 cm, 9 cm be the sides of a triangle?",
         "<b>(a)</b>  Check the smallest two against the largest: "
         "4 + 6 = 10, which is NOT greater than 10. So the lengths "
         "<b>cannot</b> form a triangle — they would lie flat in a straight "
         "line.",
         "<b>(b)</b>  Smallest two: 5 + 7 = 12 &gt; 9 ✓.  5 + 9 = 14 &gt; 7 ✓.  "
         "7 + 9 = 16 &gt; 5 ✓.  All three inequalities hold, so the lengths "
         "<b>can</b> form a triangle."]))

    s.append(h2("8.  Median, Altitude and Angle Bisector of a Triangle"))
    s.append(p(
        "Three special line segments are commonly drawn from a vertex of a "
        "triangle to the opposite side:"))
    s.append(bullet_list([
        "<b>Median</b> — a line segment joining a vertex to the midpoint of "
        "the opposite side. Every triangle has three medians; they all meet "
        "at a single point called the <b>centroid</b>, which divides each "
        "median in the ratio 2 : 1.",
        "<b>Altitude</b> — the perpendicular segment from a vertex to the "
        "line containing the opposite side. Every triangle has three "
        "altitudes; they meet at the <b>orthocentre</b>. The altitude "
        "represents the <i>height</i> of the triangle for area calculations.",
        "<b>Angle bisector</b> — a line segment from a vertex that bisects "
        "the angle at that vertex and ends on the opposite side. The three "
        "angle bisectors meet at the <b>incentre</b>, the centre of the "
        "circle inscribed in the triangle.",
    ]))

    s.append(example_box(
        "Using the median ratio",
        ["The centroid G of △ABC divides median AD in the ratio 2 : 1 "
         "(measured from the vertex). If the median AD is 12 cm long, find "
         "AG and GD.",
         "Let AG = 2k and GD = k.  Then 2k + k = 12  →  3k = 12  →  k = 4.",
         "AG = 2 × 4 = <b>8 cm</b>;   GD = 4 cm  →  <b>4 cm</b>.",
         "(The part nearer the vertex is twice the part nearer the side.)"]))

    s.append(section_card(
        "Common Mistakes to Avoid — Triangles",
        ["• A triangle can have at most one right or one obtuse angle — never "
         "two. The other two angles must be acute.",
         "• Pythagoras' theorem works <b>only</b> for right-angled triangles. "
         "Don't apply it to acute or obtuse triangles.",
         "• The hypotenuse is always the side <b>opposite</b> the right angle "
         "— and it is always the <b>longest</b> side.",
         "• SSA and AAA are <b>not</b> congruence rules. Always check that "
         "the equal angle is the <i>included</i> one (SAS) or the equal side "
         "is the <i>included</i> one (ASA).",
         "• In the triangle inequality, the sum of the two smaller sides "
         "must be strictly greater than (not equal to) the largest side."]))

    s.append(section_card(
        "Quick Recap — Triangles",
        ["• △ABC has ∠A + ∠B + ∠C = 180° (angle-sum property).",
         "• Exterior angle = sum of the two interior opposite angles.",
         "• In a right triangle: a² + b² = c², where c is the hypotenuse.",
         "• Equilateral: all sides equal, all angles = 60°.",
         "• Isosceles: two equal sides, two equal angles opposite them.",
         "• Four congruence rules: SSS, SAS, ASA, RHS — there is no SSA / AAA.",
         "• Triangle inequality: sum of any two sides &gt; the third side.",
         "• Median joins vertex to midpoint of opposite side; centroid "
         "divides it 2 : 1.",
         "• Altitude is the perpendicular from a vertex to the opposite side.",
         "• Congruent figures are identical in shape and size (but may be "
         "rotated or flipped)."]))

    return s


# ===========================================================================
#  MATERIAL 3 — Quadrilaterals and Circles
# ===========================================================================
def material_03_quadrilaterals_circles():
    s = []
    s += h1("Quadrilaterals and Circles",
            "Material 03 · Geometry (CH003) · Power Maths by Prof. Kalpesh Vyas")

    s.append(p(
        "A <b>quadrilateral</b> is a closed plane figure bounded by four line "
        "segments. It has four vertices, four sides, four interior angles and "
        "two diagonals. The sum of the four interior angles of any "
        "quadrilateral is <b>360°</b> — you can see this by drawing one "
        "diagonal, which splits the quadrilateral into two triangles "
        "(2 × 180° = 360°). A <b>circle</b> is the set of all points in a "
        "plane that are at a fixed distance (the radius) from a fixed point "
        "(the centre). This material covers the special types of "
        "quadrilaterals, their properties, and the basic vocabulary of "
        "circles."))

    s.append(h2("1.  Types of Quadrilaterals"))
    s.append(p(
        "Quadrilaterals are classified by how their sides and angles relate. "
        "Each special type inherits all the properties of the more general "
        "type above it in the family tree:"))

    s.append(info_table([
        ["Quadrilateral", "Defining property"],
        ["Trapezium",      "One pair of opposite sides parallel"],
        ["Parallelogram",  "Both pairs of opposite sides parallel"],
        ["Rectangle",      "A parallelogram with all angles = 90°"],
        ["Rhombus",        "A parallelogram with all sides equal"],
        ["Square",         "A parallelogram with all sides equal and all angles = 90°"],
        ["Kite",           "Two distinct pairs of adjacent sides equal"],
    ], col_widths=[130, 380]))
    s.append(sp(4))
    s.append(p(
        "A <b>square</b> is therefore a special rectangle, a special rhombus "
        "and a special parallelogram — it has every property of all three."))

    s.append(h2("2.  Properties of a Parallelogram"))
    s.append(p(
        "A <b>parallelogram</b> ABCD (AB ∥ CD and AD ∥ BC) has these key "
        "properties — most parallelogram problems use one or more of them:"))
    s.append(bullet_list([
        "Both pairs of opposite sides are <b>parallel</b> and <b>equal</b>: "
        "AB = CD and AD = BC.",
        "Both pairs of opposite angles are equal: ∠A = ∠C and ∠B = ∠D.",
        "Adjacent angles are <b>supplementary</b>: ∠A + ∠B = 180°, etc.",
        "The two diagonals <b>bisect each other</b>: AO = OC and BO = OD "
        "(where O is their point of intersection).",
        "Each diagonal divides the parallelogram into two congruent triangles.",
    ]))

    s.append(example_box(
        "Using parallelogram properties",
        ["In parallelogram PQRS, ∠P = (3x − 10)° and ∠Q = (2x + 30)°. "
         "Find x and all four angles.",
         "Adjacent angles of a parallelogram are supplementary:",
         "(3x − 10) + (2x + 30) = 180  →  5x + 20 = 180  →  5x = 160.",
         "x = <b>32°</b>.",
         "∠P = (3·32 − 10)° = 86°,    ∠Q = (2·32 + 30)° = 94°.",
         "Opposite angles are equal: ∠R = ∠P = 86° and ∠S = ∠Q = 94°.",
         "Check: 86 + 94 + 86 + 94 = 360° ✓."]))

    s.append(h2("3.  Rectangles, Rhombuses and Squares"))
    s.append(p(
        "A <b>rectangle</b> is a parallelogram in which all four angles are "
        "right angles. In addition to all parallelogram properties, a "
        "rectangle has:"))
    s.append(bullet_list([
        "Both diagonals are <b>equal in length</b> (AC = BD).",
        "The diagonals bisect each other (inherited from parallelogram).",
    ]))
    s.append(p(
        "A <b>rhombus</b> is a parallelogram in which all four sides are "
        "equal. Its extra properties are:"))
    s.append(bullet_list([
        "The diagonals are <b>perpendicular</b> to each other (AC ⊥ BD).",
        "Each diagonal bisects a pair of opposite angles.",
    ]))
    s.append(p(
        "A <b>square</b> combines both: all sides equal, all angles 90°, "
        "diagonals are equal <i>and</i> perpendicular <i>and</i> bisect the "
        "angles."))

    s.append(example_box(
        "Diagonals of a rectangle",
        ["The length of a rectangle is 12 cm and its width is 5 cm. "
         "Find the length of each diagonal.",
         "A diagonal of a rectangle forms a right triangle whose legs are the "
         "length and width. By Pythagoras' theorem:",
         "d² = 12² + 5² = 144 + 25 = 169.",
         "d = √169 = <b>13 cm</b>.",
         "(Both diagonals of a rectangle are equal, so each is 13 cm.)"]))

    s.append(h2("4.  Introduction to Circles"))
    s.append(p(
        "A <b>circle</b> is the set of all points in a plane that are at a "
        "fixed distance from a fixed point. The fixed point is the "
        "<b>centre</b> (O) and the fixed distance is the <b>radius</b> (r). "
        "Every point on the circle is at distance r from O. The distance "
        "around the circle — its perimeter — is called the "
        "<b>circumference</b>, given by C = 2πr. The area enclosed is "
        "A = πr²."))

    s.append(h2("5.  Key Terms for a Circle"))
    s.append(info_table([
        ["Term", "Meaning"],
        ["Centre (O)",         "The fixed point equidistant from every point on the circle"],
        ["Radius (r)",          "Line segment joining the centre to a point on the circle"],
        ["Diameter (d = 2r)",   "Chord passing through the centre; the longest chord"],
        ["Chord",               "Line segment joining any two points on the circle"],
        ["Arc",                 "A continuous part of the circle (between two points)"],
        ["Semicircle",          "Half of a circle (an arc of 180°)"],
        ["Sector",              "Region bounded by two radii and an arc (like a pizza slice)"],
        ["Segment",             "Region bounded by a chord and an arc"],
        ["Secant",              "A line that intersects the circle at two points"],
        ["Tangent",             "A line that touches the circle at exactly one point"],
        ["Concentric circles",  "Two or more circles with the same centre but different radii"],
    ], col_widths=[140, 370]))
    s.append(sp(4))

    s.append(h2("6.  Important Circle Properties"))
    s.append(bullet_list([
        "The diameter is the longest chord of a circle.",
        "Equal chords of a circle are equidistant from the centre (and vice-versa).",
        "The perpendicular from the centre to a chord bisects the chord.",
        "A line drawn through the centre and perpendicular to a chord bisects "
        "the chord — and the converse.",
        "Equal arcs subtend equal angles at the centre.",
        "The angle subtended by an arc at the centre is twice the angle "
        "subtended by it at any point on the remaining part of the circle.",
        "A tangent to a circle is perpendicular to the radius at the point of "
        "contact.",
    ]))

    s.append(example_box(
        "Radius, diameter, circumference, area",
        ["A circle has radius 7 cm. Find its diameter, circumference and area "
         "(take π = 22/7).",
         "Diameter      d = 2r = 2 × 7 = <b>14 cm</b>.",
         "Circumference C = 2πr = 2 × (22/7) × 7 = <b>44 cm</b>.",
         "Area          A = πr² = (22/7) × 7² = (22/7) × 49 = <b>154 cm²</b>."]))

    s.append(example_box(
        "Perpendicular from the centre bisects a chord",
        ["A chord AB of a circle is 12 cm long and is 8 cm from the centre O. "
         "Find the radius of the circle.",
         "Drop the perpendicular OM from O to AB. By the chord property, "
         "OM bisects AB, so AM = MB = 6 cm.",
         "In right triangle OMA: OA² = OM² + AM² = 8² + 6² = 64 + 36 = 100.",
         "OA = √100 = <b>10 cm</b>.  Hence the radius is 10 cm."]))

    s.append(h2("7.  Cyclic Quadrilateral"))
    s.append(p(
        "A <b>cyclic quadrilateral</b> is a quadrilateral whose four vertices "
        "all lie on a single circle. The circle is called its <b>circumcircle</b>. "
        "Cyclic quadrilaterals have one very useful property:"))
    s.append(p(
        "<b>Theorem.</b> The opposite angles of a cyclic quadrilateral are "
        "<b>supplementary</b> — that is, they add up to 180°. If ABCD is "
        "cyclic, then ∠A + ∠C = 180° and ∠B + ∠D = 180°."))
    s.append(p(
        "The converse is also true: if a pair of opposite angles of a "
        "quadrilateral are supplementary, then the quadrilateral is cyclic."))

    s.append(example_box(
        "Opposite angles of a cyclic quadrilateral",
        ["ABCD is a cyclic quadrilateral in which ∠A = (2x + 30)° and "
         "∠C = (3x − 10)°. Find x and hence ∠A and ∠C.",
         "Opposite angles of a cyclic quadrilateral are supplementary:",
         "(2x + 30) + (3x − 10) = 180",
         "5x + 20 = 180  →  5x = 160  →  x = 32°.",
         "∠A = (2·32 + 30)° = 94°;   ∠C = (3·32 − 10)° = 86°.",
         "Check: 94° + 86° = 180° ✓."]))

    s.append(h2("8.  Tangents from an External Point"))
    s.append(p(
        "A <b>tangent</b> to a circle is a line that touches the circle at "
        "exactly one point — the <b>point of contact</b>. The tangent is "
        "perpendicular to the radius drawn to the point of contact. When two "
        "tangents are drawn to a circle from an external point, two important "
        "properties hold:"))
    s.append(bullet_list([
        "The two tangents are <b>equal in length</b>.",
        "The line joining the external point to the centre of the circle "
        "<b>bisects the angle</b> between the two tangents.",
    ]))

    s.append(example_box(
        "Equal tangents from an external point",
        ["From a point P outside a circle with centre O, two tangents PA and "
         "PB touch the circle at A and B. If PA = (3x + 1) cm and "
         "PB = (2x + 4) cm, find x and the length of each tangent.",
         "Tangents from an external point are equal: PA = PB.",
         "3x + 1 = 2x + 4  →  x = 3.",
         "PA = PB = (3·3 + 1) cm = <b>10 cm</b> each."]))

    s.append(section_card(
        "Common Mistakes to Avoid — Quadrilaterals &amp; Circles",
        ["• The diagonals of a general parallelogram are <b>not</b> equal. "
         "Only rectangles (and squares) have equal diagonals.",
         "• The diagonals of a general parallelogram are <b>not</b> "
         "perpendicular. Only rhombuses (and squares) have perpendicular "
         "diagonals.",
         "• A square is the only quadrilateral that has both — equal AND "
         "perpendicular diagonals.",
         "• Diameter = 2 × radius. Don't forget the factor of 2 in "
         "circumference (C = 2πr) and area (A = πr²).",
         "• The perpendicular from the centre to a chord bisects the chord "
         "— but the chord is <b>not</b> the diameter unless it passes through "
         "the centre.",
         "• A cyclic quadrilateral's <b>opposite</b> angles are supplementary "
         "(sum to 180°) — not its adjacent angles."]))

    s.append(section_card(
        "Quick Recap — Quadrilaterals &amp; Circles",
        ["• Sum of the four interior angles of any quadrilateral = 360°.",
         "• Parallelogram: opp. sides ∥ and =, opp. angles =, diagonals bisect each other.",
         "• Rectangle: parallelogram + all angles 90° + diagonals equal.",
         "• Rhombus: parallelogram + all sides equal + diagonals perpendicular.",
         "• Square: all sides equal, all angles 90°, diagonals equal and perpendicular.",
         "• Circle: C = 2πr, A = πr², diameter d = 2r (longest chord).",
         "• Perpendicular from centre to a chord bisects the chord.",
         "• Tangent at a point is perpendicular to the radius at that point.",
         "• Two tangents from an external point are equal in length.",
         "• Opposite angles of a cyclic quadrilateral sum to 180°."]))

    return s


# ===========================================================================
#  PRACTICE 1 — problems
# ===========================================================================
def practice_01():
    s = []
    s += h1("Practice Sheet 1 — Lines, Angles &amp; Triangles",
            "CH003 Geometry · Power Maths by Prof. Kalpesh Vyas · 17 questions · "
            "Easy + Medium · Total: 40 marks")

    s.append(p(
        "<b>Instructions.</b> Attempt every question. For MCQs, circle the "
        "letter of the correct option. For numerical and word problems, show "
        "your working in the ruled space provided. Each question carries the "
        "marks shown in brackets."))

    s.append(section_card(
        "Useful Facts to Remember",
        ["• Complementary angles sum to 90°; supplementary angles sum to 180°.",
         "• Angles of a linear pair are supplementary; vertically opposite "
         "angles are equal.",
         "• For parallel lines cut by a transversal: corresponding and "
         "alternate angles are equal; co-interior angles sum to 180°.",
         "• Angle-sum property of a triangle: ∠A + ∠B + ∠C = 180°.",
         "• Exterior angle of a triangle = sum of the two interior opposite "
         "angles.",
         "• Pythagoras: a² + b² = c² (c is the hypotenuse)."]))

    s.append(h2("Section A — Multiple Choice (1 mark each)"))

    s.append(problem_block(1,
        "Which of the following is <b>not</b> an acute angle?",
        options=["(a)  35°", "(b)  60°", "(c)  89°", "(d)  90°"],
        marks="1"))
    s.append(problem_block(2,
        "The complement of 27° is",
        options=["(a)  53°", "(b)  63°", "(c)  73°", "(d)  153°"],
        marks="1"))
    s.append(problem_block(3,
        "The supplement of 105° is",
        options=["(a)  65°", "(b)  75°", "(c)  85°", "(d)  95°"],
        marks="1"))
    s.append(problem_block(4,
        "If two lines intersect and one of the angles so formed is 75°, the "
        "measure of its vertically opposite angle is",
        options=["(a)  15°", "(b)  75°", "(c)  105°", "(d)  180°"],
        marks="1"))
    s.append(problem_block(5,
        "Two angles of a triangle are 40° and 65°. The third angle is",
        options=["(a)  65°", "(b)  70°", "(c)  75°", "(d)  85°"],
        marks="1"))
    s.append(problem_block(6,
        "In a right triangle, the side opposite the right angle is called the",
        options=["(a)  base", "(b)  leg",
                 "(c)  hypotenuse", "(d)  altitude"],
        marks="1"))

    s.append(h2("Section B — Numerical Problems (2 marks each)"))

    s.append(problem_block(7,
        "Find the value of x if (2x + 10)° and (3x − 20)° are a pair of "
        "complementary angles.", lines=5, marks="2"))
    s.append(problem_block(8,
        "Two supplementary angles are in the ratio 2 : 3. Find each angle.",
        lines=5, marks="2"))
    s.append(problem_block(9,
        "In △XYZ, ∠X = 72° and ∠Y = ∠Z. Find ∠Y.", lines=5, marks="2"))
    s.append(problem_block(10,
        "An exterior angle of a triangle is 110° and one of its interior "
        "opposite angles is 45°. Find the other interior opposite angle.",
        lines=5, marks="2"))
    s.append(problem_block(11,
        "Find the length of the hypotenuse of a right triangle whose legs "
        "are 9 cm and 12 cm.", lines=5, marks="2"))
    s.append(problem_block(12,
        "The hypotenuse of a right triangle is 17 cm and one leg is 8 cm. "
        "Find the length of the other leg.", lines=5, marks="2"))
    s.append(problem_block(13,
        "AB ∥ CD and a transversal cuts them. One corresponding pair of "
        "angles measures (4x − 5)° and (2x + 25)°. Find x.", lines=5, marks="2"))
    s.append(problem_block(14,
        "BD bisects ∠ABC. If ∠ABD = (3x + 5)° and ∠DBC = (2x + 15)°, find x "
        "and ∠ABC.", lines=6, marks="2"))

    s.append(h2("Section C — Word Problems (3 marks each)"))

    s.append(problem_block(15,
        "Two lines PQ and RS intersect at O. If ∠POR : ∠ROQ = 3 : 2, find "
        "all four angles formed at O. Give reasons.", lines=10, marks="3"))
    s.append(problem_block(16,
        "In parallelogram ABCD, ∠A = (2x + 25)° and ∠B = (3x − 5)°. Find x "
        "and hence all four angles of the parallelogram. Give reasons.",
        lines=10, marks="3"))
    s.append(problem_block(17,
        "AB ∥ CD. A transversal EF meets AB at G and CD at H. ∠EGB = "
        "(4x + 10)° and ∠GHD = (3x + 30)° are co-interior angles. Find x and "
        "both angles. Give reasons.", lines=10, marks="3"))

    s.append(section_card(
        "Self-Assessment",
        ["• How many did you get right out of 17?  ____________",
         "• Which question did you find hardest?  ____________",
         "• Which fact or formula do you need to revise before the next "
         "practice sheet?  ____________"]))

    return s


# ===========================================================================
#  PRACTICE 1 — solutions
# ===========================================================================
def practice_01_solutions():
    s = []
    s += h1("Practice Sheet 1 — Solutions",
            "CH003 Geometry · Power Maths by Prof. Kalpesh Vyas · Step-by-step "
            "worked solutions for all 17 questions")

    s.append(p(
        "Every solution below shows the reasoning, the working and the final "
        "answer in a highlighted box. The <i>Concept</i> line names the key "
        "fact or theorem used; the <i>Tip</i> line points out a common slip "
        "to avoid. Read these carefully — the reasoning is what earns you "
        "marks in geometry, not just the final number."))

    # Section A
    s.append(h2("Section A — Multiple Choice"))

    s.extend(solution_block(1,
        "Which of the following is not an acute angle? "
        "(a) 35°  (b) 60°  (c) 89°  (d) 90°",
        ["An <b>acute</b> angle is one whose measure is strictly less than 90°.",
         "35°, 60° and 89° are all less than 90°, so they are acute.",
         "90° is exactly a right angle — it is not acute."],
        "(d)  90°",
        concept="Definition of an acute angle (0° &lt; θ &lt; 90°).",
        tip="The inequalities are strict: 90° itself is right, not acute."))

    s.extend(solution_block(2,
        "The complement of 27°",
        ["Complementary angles add up to 90°.",
         "Complement = 90° − 27° = 63°."],
        "(b)  63°",
        concept="Complementary angles: sum = 90°.",
        tip="Subtract from 90° for complement, from 180° for supplement."))

    s.extend(solution_block(3,
        "The supplement of 105°",
        ["Supplementary angles add up to 180°.",
         "Supplement = 180° − 105° = 75°."],
        "(b)  75°",
        concept="Supplementary angles: sum = 180°."))

    s.extend(solution_block(4,
        "Two lines intersect; one angle is 75°. Find its vertically opposite angle.",
        ["Vertically opposite angles are always <b>equal</b>.",
         "So the vertically opposite angle = 75°."],
        "(b)  75°",
        concept="Vertically opposite angles are equal.",
        tip="The other two angles (each 105°) form linear pairs with 75°."))

    s.extend(solution_block(5,
        "Two angles of a triangle are 40° and 65°. Find the third angle.",
        ["By the angle-sum property: ∠₁ + ∠₂ + ∠₃ = 180°.",
         "40° + 65° + ∠₃ = 180°  →  105° + ∠₃ = 180°.",
         "∠₃ = 180° − 105° = 75°."],
        "(c)  75°",
        concept="Angle-sum property of a triangle."))

    s.extend(solution_block(6,
        "In a right triangle, the side opposite the right angle is called the",
        ["By definition, the longest side of a right triangle — the one "
         "opposite the right angle — is the <b>hypotenuse</b>."],
        "(c)  hypotenuse",
        concept="Definition of the hypotenuse.",
        tip="The hypotenuse is always the longest side of a right triangle."))

    # Section B
    s.append(h2("Section B — Numerical Problems"))

    s.extend(solution_block(7,
        "Find x if (2x + 10)° and (3x − 20)° are complementary.",
        ["Complementary angles sum to 90°:",
         "(2x + 10) + (3x − 20) = 90",
         "5x − 10 = 90",
         "5x = 100",
         "x = 20°.",
         "<i>Check:</i> (2·20 + 10)° = 50°, (3·20 − 20)° = 40°; 50 + 40 = 90 ✓."],
        "x = 20°",
        concept="Complementary angles sum to 90°.",
        tip="Always check your answer by substituting back into both expressions."))

    s.extend(solution_block(8,
        "Two supplementary angles are in the ratio 2 : 3. Find each angle.",
        ["Supplementary angles sum to 180°.",
         "Let the angles be 2k and 3k.",
         "2k + 3k = 180  →  5k = 180  →  k = 36.",
         "So the angles are 2 × 36 = 72° and 3 × 36 = 108°.",
         "<i>Check:</i> 72 + 108 = 180 ✓."],
        "Angles are 72° and 108°",
        concept="Supplementary angles + ratio.",
        tip="When a ratio is given, introduce a common multiplier k."))

    s.extend(solution_block(9,
        "In △XYZ, ∠X = 72° and ∠Y = ∠Z. Find ∠Y.",
        ["By the angle-sum property: ∠X + ∠Y + ∠Z = 180°.",
         "Since ∠Y = ∠Z, let each be a.",
         "72° + a + a = 180°  →  2a = 108°  →  a = 54°.",
         "So ∠Y = ∠Z = 54°."],
        "∠Y = 54°",
        concept="Angle-sum property + isosceles-style reasoning.",
        tip="Equal angles in a triangle are opposite equal sides."))

    s.extend(solution_block(10,
        "An exterior angle of a triangle is 110° and one interior opposite "
        "angle is 45°. Find the other interior opposite angle.",
        ["By the exterior-angle theorem: exterior angle = sum of the two "
         "interior opposite angles.",
         "Let the unknown angle be x.",
         "x + 45° = 110°  →  x = 110° − 45° = 65°.",
         "<i>Check:</i> third angle = 180° − (45° + 65°) = 70°; "
         "exterior = 180° − 70° = 110° ✓."],
        "65°",
        concept="Exterior-angle theorem."))

    s.extend(solution_block(11,
        "Find the hypotenuse of a right triangle whose legs are 9 cm and 12 cm.",
        ["By Pythagoras' theorem: hypotenuse² = (leg₁)² + (leg₂)².",
         "h² = 9² + 12² = 81 + 144 = 225.",
         "h = √225 = 15 cm.",
         "(This is the 3-4-5 triple scaled by 3.)"],
        "15 cm",
        concept="Pythagoras' theorem: a² + b² = c².",
        tip="Memorising the 3-4-5, 5-12-13 and 8-15-17 Pythagorean triples "
            "saves time in exams."))

    s.extend(solution_block(12,
        "The hypotenuse of a right triangle is 17 cm and one leg is 8 cm. "
        "Find the other leg.",
        ["Let the unknown leg be x.",
         "By Pythagoras: x² + 8² = 17².",
         "x² + 64 = 289  →  x² = 225  →  x = 15 cm."],
        "15 cm",
        concept="Pythagoras' theorem (finding a leg).",
        tip="This is the 8-15-17 Pythagorean triple."))

    s.extend(solution_block(13,
        "AB ∥ CD; a transversal cuts them. One corresponding pair is "
        "(4x − 5)° and (2x + 25)°. Find x.",
        ["When parallel lines are cut by a transversal, <b>corresponding "
         "angles are equal</b>.",
         "4x − 5 = 2x + 25",
         "4x − 2x = 25 + 5",
         "2x = 30  →  x = 15°.",
         "<i>Check:</i> (4·15 − 5)° = 55°; (2·15 + 25)° = 55° ✓."],
        "x = 15°",
        concept="Corresponding angles are equal when lines are parallel."))

    s.extend(solution_block(14,
        "BD bisects ∠ABC. If ∠ABD = (3x + 5)° and ∠DBC = (2x + 15)°, find x "
        "and ∠ABC.",
        ["An angle bisector divides the angle into two equal parts, so "
         "∠ABD = ∠DBC:",
         "3x + 5 = 2x + 15",
         "3x − 2x = 15 − 5  →  x = 10°.",
         "∠ABD = (3·10 + 5)° = 35° and ∠DBC = (2·10 + 15)° = 35°.",
         "∠ABC = ∠ABD + ∠DBC = 35° + 35° = 70°."],
        "x = 10° ;   ∠ABC = 70°",
        concept="An angle bisector creates two equal angles.",
        tip="If BD bisects ∠ABC, then ∠ABD = ∠DBC = ½ ∠ABC."))

    # Section C
    s.append(h2("Section C — Word Problems"))

    s.extend(solution_block(15,
        "Two lines PQ and RS intersect at O. If ∠POR : ∠ROQ = 3 : 2, find "
        "all four angles at O.",
        ["∠POR and ∠ROQ are a <b>linear pair</b> on line PQ, so they are "
         "supplementary.",
         "Let ∠POR = 3k and ∠ROQ = 2k.",
         "3k + 2k = 180°  →  5k = 180°  →  k = 36°.",
         "∠POR = 3 × 36 = 108° and ∠ROQ = 2 × 36 = 72°.",
         "Vertically opposite angles are equal:",
         "∠QOS = ∠POR = 108°  and  ∠POS = ∠ROQ = 72°.",
         "<i>Check:</i> 108 + 72 + 108 + 72 = 360° ✓."],
        "∠POR = ∠QOS = 108° ;   ∠ROQ = ∠POS = 72°",
        concept="Linear pair (supplementary) + vertically opposite angles.",
        tip="Angles around a point always sum to 360° — use that as a check."))

    s.extend(solution_block(16,
        "In parallelogram ABCD, ∠A = (2x + 25)° and ∠B = (3x − 5)°. Find x "
        "and all four angles.",
        ["Adjacent angles of a parallelogram are <b>supplementary</b>.",
         "So ∠A + ∠B = 180°:",
         "(2x + 25) + (3x − 5) = 180",
         "5x + 20 = 180  →  5x = 160  →  x = 32°.",
         "∠A = (2·32 + 25)° = 89°;   ∠B = (3·32 − 5)° = 91°.",
         "Opposite angles are equal: ∠C = ∠A = 89° and ∠D = ∠B = 91°.",
         "<i>Check:</i> 89 + 91 + 89 + 91 = 360° ✓."],
        "x = 32° ;   ∠A = ∠C = 89° ;   ∠B = ∠D = 91°",
        concept="Adjacent angles of a parallelogram are supplementary; "
                "opposite angles are equal.",
        tip="Sum of all four angles of any quadrilateral = 360° — always."))

    s.extend(solution_block(17,
        "AB ∥ CD. Transversal EF meets AB at G and CD at H. ∠EGB = "
        "(4x + 10)° and ∠GHD = (3x + 30)° are co-interior angles. Find x "
        "and both angles.",
        ["Co-interior angles on the same side of a transversal cutting two "
         "<b>parallel</b> lines are supplementary (sum = 180°):",
         "(4x + 10) + (3x + 30) = 180",
         "7x + 40 = 180  →  7x = 140  →  x = 20°.",
         "∠EGB = (4·20 + 10)° = 90°;   ∠GHD = (3·20 + 30)° = 90°.",
         "<i>Check:</i> 90 + 90 = 180 ✓."],
        "x = 20° ;   ∠EGB = 90° ;   ∠GHD = 90°",
        concept="Co-interior angles on parallel lines sum to 180°.",
        tip="Co-interior angles are NOT equal — only supplementary. "
            "Alternate angles are equal."))

    return s


# ===========================================================================
#  PRACTICE 2 — problems
# ===========================================================================
def practice_02():
    s = []
    s += h1("Practice Sheet 2 — Quadrilaterals, Circles &amp; Pythagoras",
            "CH003 Geometry · Power Maths by Prof. Kalpesh Vyas · 17 questions · "
            "Easy + Medium · Total: 40 marks")

    s.append(p(
        "<b>Instructions.</b> Attempt every question. For MCQs, circle the "
        "letter of the correct option. For numerical and word problems, show "
        "your working in the ruled space provided. Each question carries the "
        "marks shown in brackets."))

    s.append(section_card(
        "Useful Facts to Remember",
        ["• Sum of the four angles of any quadrilateral = 360°.",
         "• Parallelogram: opp. sides ∥ and =, opp. angles =, diagonals bisect "
         "each other; adjacent angles supplementary.",
         "• Rectangle: parallelogram + all angles 90° + diagonals equal.",
         "• Rhombus: parallelogram + all sides equal + diagonals perpendicular.",
         "• Circle: C = 2πr, A = πr², diameter d = 2r (longest chord).",
         "• Perpendicular from centre to a chord bisects the chord.",
         "• Pythagoras: a² + b² = c² (c is the hypotenuse).",
         "• Two tangents from an external point to a circle are equal."]))

    s.append(h2("Section A — Multiple Choice (1 mark each)"))

    s.append(problem_block(1,
        "The sum of the four interior angles of any quadrilateral is",
        options=["(a)  180°", "(b)  270°", "(c)  360°", "(d)  540°"],
        marks="1"))
    s.append(problem_block(2,
        "Which of the following is <b>not</b> a property of every parallelogram?",
        options=["(a)  Opposite sides equal",
                 "(b)  Opposite angles equal",
                 "(c)  Diagonals equal",
                 "(d)  Diagonals bisect each other"],
        marks="1"))
    s.append(problem_block(3,
        "The diagonals of a rhombus are",
        options=["(a)  equal", "(b)  perpendicular",
                 "(c)  parallel", "(d)  not bisecting"],
        marks="1"))
    s.append(problem_block(4,
        "Each angle of a rectangle is",
        options=["(a)  60°", "(b)  90°", "(c)  120°", "(d)  180°"],
        marks="1"))
    s.append(problem_block(5,
        "The diameter of a circle is 14 cm. Its radius is",
        options=["(a)  7 cm", "(b)  14 cm", "(c)  21 cm", "(d)  28 cm"],
        marks="1"))
    s.append(problem_block(6,
        "The longest chord of a circle is the",
        options=["(a)  radius", "(b)  arc",
                 "(c)  diameter", "(d)  tangent"],
        marks="1"))

    s.append(h2("Section B — Numerical Problems (2 marks each)"))

    s.append(problem_block(7,
        "Three angles of a quadrilateral are 75°, 110° and 95°. Find the "
        "fourth angle.", lines=5, marks="2"))
    s.append(problem_block(8,
        "In parallelogram ABCD, ∠A = 65°. Find ∠B, ∠C and ∠D.",
        lines=5, marks="2"))
    s.append(problem_block(9,
        "Two adjacent angles of a parallelogram are (4x + 5)° and (5x − 5)°. "
        "Find x and each angle.", lines=5, marks="2"))
    s.append(problem_block(10,
        "Find the length of the diagonal of a rectangle with length 15 cm "
        "and width 8 cm.", lines=5, marks="2"))
    s.append(problem_block(11,
        "A circle has a radius of 5 cm. Find its circumference and area "
        "(take π = 22/7).", lines=6, marks="2"))
    s.append(problem_block(12,
        "Find the length of a chord that is 6 cm from the centre of a circle "
        "of radius 10 cm.", lines=6, marks="2"))
    s.append(problem_block(13,
        "A ladder 13 m long leans against a wall and its foot is 5 m from "
        "the wall. How high up the wall does the ladder reach?",
        lines=5, marks="2"))
    s.append(problem_block(14,
        "From an external point P, two tangents PA and PB are drawn to a "
        "circle. If PA = (2x + 5) cm and PB = (3x − 1) cm, find x and the "
        "length of each tangent.", lines=5, marks="2"))

    s.append(h2("Section C — Word Problems (3 marks each)"))

    s.append(problem_block(15,
        "Show that a triangle with sides 8 cm, 15 cm and 17 cm is "
        "right-angled. Which side is the hypotenuse? Give reasons.",
        lines=10, marks="3"))
    s.append(problem_block(16,
        "In a circle of radius 13 cm, a chord AB is 24 cm long. Find the "
        "distance of AB from the centre O. Give reasons for each step.",
        lines=10, marks="3"))
    s.append(problem_block(17,
        "ABCD is a cyclic quadrilateral in which ∠A = (2x + 30)° and "
        "∠C = (3x − 10)°. Find x and hence ∠A and ∠C. Give reasons.",
        lines=10, marks="3"))

    s.append(section_card(
        "Self-Assessment",
        ["• How many did you get right out of 17?  ____________",
         "• Which question did you find hardest?  ____________",
         "• Which fact or formula do you need to revise before the exam?  "
         "____________"]))

    return s


# ===========================================================================
#  PRACTICE 2 — solutions
# ===========================================================================
def practice_02_solutions():
    s = []
    s += h1("Practice Sheet 2 — Solutions",
            "CH003 Geometry · Power Maths by Prof. Kalpesh Vyas · Step-by-step "
            "worked solutions for all 17 questions")

    s.append(p(
        "Every solution below shows the reasoning, the working and the final "
        "answer in a highlighted box. The <i>Concept</i> line names the key "
        "fact or theorem used; the <i>Tip</i> line points out a common slip "
        "to avoid. Read these carefully — the reasoning is what earns you "
        "marks in geometry, not just the final number."))

    # Section A
    s.append(h2("Section A — Multiple Choice"))

    s.extend(solution_block(1,
        "Sum of the four interior angles of any quadrilateral?",
        ["Drawing one diagonal splits the quadrilateral into two triangles.",
         "Sum of angles = 2 × 180° = 360°."],
        "(c)  360°",
        concept="Angle-sum of a quadrilateral = 2 × 180° = 360°.",
        tip="A diagonal always splits a quadrilateral into two triangles."))

    s.extend(solution_block(2,
        "Which is NOT a property of every parallelogram?",
        ["Opposite sides equal — true of every parallelogram.",
         "Opposite angles equal — true of every parallelogram.",
         "Diagonals bisect each other — true of every parallelogram.",
         "Diagonals equal — only true of a rectangle, not of a general "
         "parallelogram (e.g. a non-rectangular parallelogram has unequal "
         "diagonals)."],
        "(c)  Diagonals equal",
        concept="Property list of a parallelogram.",
        tip="Only rectangles (and squares) have equal diagonals — never a "
            "general parallelogram or rhombus."))

    s.extend(solution_block(3,
        "The diagonals of a rhombus are …",
        ["A defining extra property of a rhombus is that its diagonals "
         "are perpendicular (they meet at 90°).",
         "They also bisect each other and bisect the angles of the rhombus."],
        "(b)  perpendicular",
        concept="Diagonals of a rhombus are perpendicular.",
        tip="In a square, the diagonals are BOTH equal AND perpendicular."))

    s.extend(solution_block(4,
        "Each angle of a rectangle is",
        ["By definition, a rectangle is a parallelogram with all four angles "
         "equal to 90°."],
        "(b)  90°",
        concept="Definition of a rectangle."))

    s.extend(solution_block(5,
        "The diameter of a circle is 14 cm. Its radius is",
        ["Radius = Diameter ÷ 2 = 14 ÷ 2 = 7 cm."],
        "(a)  7 cm",
        concept="Diameter = 2 × radius, so radius = diameter ÷ 2."))

    s.extend(solution_block(6,
        "The longest chord of a circle is the",
        ["A chord is any segment joining two points on the circle. The "
         "longest such segment passes through the centre — that is the "
         "diameter."],
        "(c)  diameter",
        concept="The diameter is the longest chord of a circle.",
        tip="Every diameter is a chord, but not every chord is a diameter."))

    # Section B
    s.append(h2("Section B — Numerical Problems"))

    s.extend(solution_block(7,
        "Three angles of a quadrilateral are 75°, 110° and 95°. Find the "
        "fourth angle.",
        ["Sum of all four angles = 360°.",
         "Let the fourth angle = x.",
         "75° + 110° + 95° + x = 360°",
         "280° + x = 360°  →  x = 360° − 280° = 80°."],
        "80°",
        concept="Angle-sum of a quadrilateral = 360°.",
        tip="Use the 360° total as a check on any quadrilateral angle work."))

    s.extend(solution_block(8,
        "In parallelogram ABCD, ∠A = 65°. Find ∠B, ∠C and ∠D.",
        ["Adjacent angles are supplementary: ∠A + ∠B = 180°.",
         "65° + ∠B = 180°  →  ∠B = 115°.",
         "Opposite angles are equal: ∠C = ∠A = 65° and ∠D = ∠B = 115°.",
         "<i>Check:</i> 65 + 115 + 65 + 115 = 360° ✓."],
        "∠B = 115° ;   ∠C = 65° ;   ∠D = 115°",
        concept="Adjacent angles supplementary; opposite angles equal.",
        tip="Once you know one angle of a parallelogram, you know all four."))

    s.extend(solution_block(9,
        "Adjacent angles of a parallelogram are (4x + 5)° and (5x − 5)°. "
        "Find x and each angle.",
        ["Adjacent angles of a parallelogram are supplementary:",
         "(4x + 5) + (5x − 5) = 180",
         "9x = 180  →  x = 20°.",
         "Angle 1 = (4·20 + 5)° = 85°;   Angle 2 = (5·20 − 5)° = 95°.",
         "Opposite angles are equal, so the four angles are 85°, 95°, 85°, 95°."],
        "x = 20° ;   angles 85°, 95°, 85°, 95°",
        concept="Adjacent angles of a parallelogram are supplementary.",
        tip="Always verify the four angles sum to 360°."))

    s.extend(solution_block(10,
        "Find the diagonal of a rectangle with length 15 cm and width 8 cm.",
        ["A diagonal of a rectangle forms a right triangle with the length "
         "and width as legs. By Pythagoras' theorem:",
         "d² = 15² + 8² = 225 + 64 = 289.",
         "d = √289 = 17 cm."],
        "17 cm",
        concept="A rectangle's diagonal forms a right triangle with the sides.",
        tip="Both diagonals of a rectangle are equal in length."))

    s.extend(solution_block(11,
        "Circle, radius 5 cm. Find circumference and area (π = 22/7).",
        ["Circumference  C = 2πr = 2 × (22/7) × 5 = 220/7 ≈ 31.43 cm.",
         "Area           A = πr² = (22/7) × 5² = (22/7) × 25 = 550/7 ≈ 78.57 cm².",
         "<i>Exact values:</i> 220/7 cm and 550/7 cm²."],
        "C ≈ 31.43 cm ;   A ≈ 78.57 cm²",
        concept="C = 2πr and A = πr².",
        tip="Don't confuse the formulas: circumference uses r, area uses r²."))

    s.extend(solution_block(12,
        "Find the length of a chord that is 6 cm from the centre of a circle "
        "of radius 10 cm.",
        ["Drop the perpendicular OM from the centre O to the chord AB. "
         "By the chord property, OM bisects AB.",
         "So AM = MB = ½ × AB. In right triangle OMA:",
         "OA² = OM² + AM²  →  10² = 6² + AM²  →  100 = 36 + AM².",
         "AM² = 64  →  AM = 8 cm.",
         "Full chord AB = 2 × AM = 2 × 8 = 16 cm."],
        "16 cm",
        concept="Perpendicular from the centre to a chord bisects the chord.",
        tip="Always form the right triangle OMA with the radius OA as hypotenuse."))

    s.extend(solution_block(13,
        "A 13 m ladder leans against a wall; its foot is 5 m from the wall. "
        "How high does it reach?",
        ["The ladder (13 m), the wall (height h) and the ground (5 m) form a "
         "right triangle, with the ladder as the hypotenuse.",
         "By Pythagoras: h² + 5² = 13².",
         "h² + 25 = 169  →  h² = 144  →  h = 12 m."],
        "12 m up the wall",
        concept="Pythagoras applied to a real-life right triangle.",
        tip="The ladder is always the hypotenuse — it's the longest side."))

    s.extend(solution_block(14,
        "From an external point P, two tangents PA and PB are drawn to a "
        "circle. If PA = (2x + 5) cm and PB = (3x − 1) cm, find x and the "
        "length of each tangent.",
        ["Tangents drawn from an external point to a circle are <b>equal</b>",
         "in length, so PA = PB.",
         "2x + 5 = 3x − 1  →  5 + 1 = 3x − 2x  →  x = 6.",
         "PA = PB = (2·6 + 5) cm = <b>17 cm</b> each.",
         "<i>Check:</i> PB = (3·6 − 1) cm = 17 cm ✓."],
        "x = 6 ;   PA = PB = 17 cm",
        concept="Two tangents from an external point are equal.",
        tip="The line PO also bisects ∠APB — useful in harder problems."))

    # Section C
    s.append(h2("Section C — Word Problems"))

    s.extend(solution_block(15,
        "Show that a triangle with sides 8 cm, 15 cm, 17 cm is right-angled. "
        "Which side is the hypotenuse?",
        ["By the <b>converse of Pythagoras' theorem</b>: if the sum of the "
         "squares of two sides equals the square of the third side, the "
         "triangle is right-angled.",
         "The longest side is 17 cm, so it would be the hypotenuse. "
         "Check whether 8² + 15² = 17²:",
         "8² = 64;    15² = 225;    64 + 225 = 289.",
         "17² = 289.   So 8² + 15² = 17² ✓.",
         "Hence the triangle is right-angled, with the right angle opposite "
         "the side of length 17 cm — that is, the side of 17 cm is the "
         "hypotenuse."],
        "Right-angled ; hypotenuse = 17 cm",
        concept="Converse of Pythagoras' theorem.",
        tip="Always test against the longest side — that's the only candidate "
            "for the hypotenuse."))

    s.extend(solution_block(16,
        "In a circle of radius 13 cm, a chord AB is 24 cm long. Find the "
        "distance of AB from the centre O.",
        ["Drop the perpendicular OM from O to AB.",
         "By the chord property, the perpendicular from the centre to a "
         "chord bisects the chord, so AM = MB = 24 ÷ 2 = 12 cm.",
         "OA is a radius, so OA = 13 cm.",
         "In right triangle OMA, by Pythagoras:",
         "OA² = OM² + AM²  →  13² = OM² + 12²  →  169 = OM² + 144.",
         "OM² = 169 − 144 = 25  →  OM = 5 cm.",
         "So the chord AB is 5 cm from the centre."],
        "Distance from centre = 5 cm",
        concept="Perpendicular from centre bisects the chord + Pythagoras.",
        tip="If the chord were the diameter, its distance from the centre "
            "would be zero — that's a useful sanity check."))

    s.extend(solution_block(17,
        "ABCD is a cyclic quadrilateral in which ∠A = (2x + 30)° and "
        "∠C = (3x − 10)°. Find x and hence ∠A and ∠C.",
        ["Opposite angles of a cyclic quadrilateral are <b>supplementary</b> "
         "(sum = 180°):",
         "∠A + ∠C = 180°",
         "(2x + 30) + (3x − 10) = 180",
         "5x + 20 = 180  →  5x = 160  →  x = 32°.",
         "∠A = (2·32 + 30)° = 94°;   ∠C = (3·32 − 10)° = 86°.",
         "<i>Check:</i> 94° + 86° = 180° ✓."],
        "x = 32° ;   ∠A = 94° ;   ∠C = 86°",
        concept="Opposite angles of a cyclic quadrilateral sum to 180°.",
        tip="The <i>opposite</i> angles are supplementary — not the adjacent "
            "ones. Adjacent angles have no special relation in a cyclic "
            "quadrilateral."))

    return s


# ===========================================================================
#  Main
# ===========================================================================
def main():
    print("Generating CH003 Geometry PDFs …\n")

    jobs = [
        (os.path.join(MATERIALS_DIR, "CH003-material-01-lines-angles.pdf"),
         material_01_lines_angles),
        (os.path.join(MATERIALS_DIR, "CH003-material-02-triangles.pdf"),
         material_02_triangles),
        (os.path.join(MATERIALS_DIR, "CH003-material-03-quadrilaterals-circles.pdf"),
         material_03_quadrilaterals_circles),
        (os.path.join(PRACTICE_DIR,  "CH003-practice-01.pdf"),
         practice_01),
        (os.path.join(PRACTICE_DIR,  "CH003-practice-01-solutions.pdf"),
         practice_01_solutions),
        (os.path.join(PRACTICE_DIR,  "CH003-practice-02.pdf"),
         practice_02),
        (os.path.join(PRACTICE_DIR,  "CH003-practice-02-solutions.pdf"),
         practice_02_solutions),
    ]

    for path, builder in jobs:
        build_pdf(path, builder())

    print(f"\nAll {len(jobs)} PDFs generated successfully.")


if __name__ == "__main__":
    main()
