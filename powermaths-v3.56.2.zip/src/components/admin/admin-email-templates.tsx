'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Award,
  BookCheck,
  Check,
  CreditCard,
  Edit3,
  Lock,
  Mail,
  MailOpen,
  Megaphone,
  RotateCcw,
  Search,
  ShieldBan,
  UserPlus,
  Variable,
  type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  useDataStore,
  type EmailTemplate,
  type EmailTemplateId,
} from '@/lib/data-store'

const templateIcon: Record<EmailTemplateId, LucideIcon> = {
  welcome: UserPlus,
  exam_assigned: BookCheck,
  exam_result: Award,
  certificate_issued: Award,
  password_reset: Lock,
  account_suspended: ShieldBan,
  payment_received: CreditCard,
  announcement: Megaphone,
}

function iconFor(id: EmailTemplateId): LucideIcon {
  return templateIcon[id] ?? Mail
}

interface EditState {
  id: EmailTemplateId
  subject: string
  body: string
  enabled: boolean
}

export function AdminEmailTemplates({ variant = 'page' }: { variant?: 'page' | 'inline' } = {}) {
  const {
    emailTemplates,
    updateEmailTemplate,
    toggleEmailTemplate,
    resetEmailTemplate,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [editOpen, setEditOpen] = useState(false)
  const [editing, setEditing] = useState<EditState | null>(null)

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return emailTemplates
    return emailTemplates.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.subject.toLowerCase().includes(q),
    )
  }, [emailTemplates, search])

  const stats = useMemo(() => {
    const total = emailTemplates.length
    const active = emailTemplates.filter((t) => t.enabled).length
    const disabled = total - active
    const uniqueVars = new Set<string>()
    for (const t of emailTemplates) {
      for (const v of t.variables) uniqueVars.add(v)
    }
    return { total, active, disabled, variables: uniqueVars.size }
  }, [emailTemplates])

  const openEdit = (t: EmailTemplate) => {
    setEditing({
      id: t.id,
      subject: t.subject,
      body: t.body,
      enabled: t.enabled,
    })
    setEditOpen(true)
  }

  const patchEdit = (patch: Partial<EditState>) =>
    setEditing((p) => (p ? { ...p, ...patch } : p))

  const appendVariable = (v: string) => {
    if (!editing) return
    const token = `{{${v}}}`
    patchEdit({ body: editing.body + (editing.body.endsWith('\n') ? '' : ' ') + token })
  }

  const handleSave = () => {
    if (!editing) return
    const subject = editing.subject.trim()
    if (!subject) {
      toast.error('Subject is required')
      return
    }
    updateEmailTemplate(editing.id, {
      subject,
      body: editing.body,
      enabled: editing.enabled,
    })
    toast.success('Template saved', { description: editing.subject })
    setEditOpen(false)
    setEditing(null)
  }

  const handleReset = () => {
    if (!editing) return
    resetEmailTemplate(editing.id)
    toast.success('Template reset to default')
    setEditOpen(false)
    setEditing(null)
  }

  const handleToggle = (t: EmailTemplate) => {
    toggleEmailTemplate(t.id)
    toast.success(
      t.enabled ? 'Template disabled' : 'Template enabled',
      { description: t.name },
    )
  }

  // ── Inline variant: used inside Settings → Email tab. Renders a compact
  // search + grid without the PageHeader + KPI stat cards.
  if (variant === 'inline') {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <MailOpen className="h-4 w-4 text-primary" /> Email Templates
            </h3>
            <p className="text-xs text-muted-foreground">
              {stats.active} of {stats.total} active · {stats.disabled} disabled
            </p>
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search templates…"
              className="pl-9 sm:w-[240px]"
              aria-label="Search email templates"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-lg border border-dashed px-4 py-6 text-center text-xs text-muted-foreground">
            No templates match your search.
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {filtered.map((t) => {
              const Icon = iconFor(t.id)
              return (
                <div
                  key={t.id}
                  className={`flex h-full flex-col gap-2 rounded-xl border bg-card p-4 transition-shadow hover:shadow-sm ${t.enabled ? '' : 'opacity-60'}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex min-w-0 items-start gap-2.5">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="truncate text-sm font-semibold leading-tight">{t.name}</h4>
                        <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{t.subject}</p>
                      </div>
                    </div>
                    <Switch
                      checked={t.enabled}
                      onCheckedChange={() => handleToggle(t)}
                      aria-label={`Toggle ${t.name}`}
                    />
                  </div>
                  <p className="line-clamp-2 whitespace-pre-wrap text-xs text-muted-foreground">{t.body}</p>
                  <div className="mt-auto flex items-center justify-between border-t pt-2">
                    <span className="text-[10px] text-muted-foreground">Edited {t.lastEditedAt}</span>
                    <Button variant="outline" size="sm" onClick={() => openEdit(t)}>
                      <Edit3 className="h-3.5 w-3.5" /> Edit
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Edit dialog (shared with the full-page variant) */}
        <EditTemplateDialog
          open={editOpen}
          onOpenChange={(o) => { setEditOpen(o); if (!o) setEditing(null) }}
          editing={editing}
          emailTemplates={emailTemplates}
          patchEdit={patchEdit}
          appendVariable={appendVariable}
          onSave={handleSave}
          onReset={handleReset}
          onCancel={() => { setEditOpen(false); setEditing(null) }}
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Email Templates"
        description="Manage the subject and body of every automated email sent by the portal."
        icon={<MailOpen className="h-5 w-5" />}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="Total Templates"
          value={stats.total}
          icon={Mail}
          accent="emerald"
          delay={0}
        />
        <StatCard
          title="Active"
          value={stats.active}
          icon={Check}
          accent="teal"
          delay={0.05}
        />
        <StatCard
          title="Disabled"
          value={stats.disabled}
          icon={Lock}
          accent="rose"
          delay={0.1}
        />
        <StatCard
          title="Variables Available"
          value={stats.variables}
          icon={Variable}
          accent="violet"
          delay={0.15}
        />
      </div>

      {/* Search */}
      <Card className="card-elevated p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search templates by name or subject…"
            className="pl-9"
            aria-label="Search email templates"
          />
        </div>
      </Card>

      {/* Template grid */}
      {filtered.length === 0 ? (
        <Card className="card-elevated">
          <EmptyState
            icon={MailOpen}
            title="No templates found"
            description="Adjust your search to find the template you want to edit."
            action={
              <Button variant="outline" onClick={() => setSearch('')}>
                Reset search
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((t, i) => {
            const Icon = iconFor(t.id)
            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
              >
                <Card
                  className={`card-elevated flex h-full flex-col gap-3 p-5 transition-shadow hover:shadow-md ${
                    t.enabled ? '' : 'opacity-60'
                  }`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex min-w-0 items-start gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="truncate text-sm font-semibold leading-tight">
                          {t.name}
                        </h3>
                        <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">
                          {t.subject}
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={t.enabled}
                      onCheckedChange={() => handleToggle(t)}
                      aria-label={`Toggle ${t.name}`}
                    />
                  </div>

                  {/* Body preview */}
                  <p className="line-clamp-2 whitespace-pre-wrap text-xs text-muted-foreground">
                    {t.body}
                  </p>

                  {/* Variable count hint */}
                  {t.variables.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1">
                      {t.variables.slice(0, 3).map((v) => (
                        <Badge
                          key={v}
                          variant="outline"
                          className="px-1.5 py-0 text-[10px] font-mono"
                        >
                          {`{{${v}}}`}
                        </Badge>
                      ))}
                      {t.variables.length > 3 && (
                        <span className="text-[10px] text-muted-foreground">
                          +{t.variables.length - 3} more
                        </span>
                      )}
                    </div>
                  )}

                  {/* Footer */}
                  <div className="mt-auto flex items-center justify-between border-t pt-3">
                    <span className="text-xs text-muted-foreground">
                      Edited {t.lastEditedAt}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEdit(t)}
                    >
                      <Edit3 className="h-3.5 w-3.5" /> Edit
                    </Button>
                  </div>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Edit dialog (shared component) */}
      <EditTemplateDialog
        open={editOpen}
        onOpenChange={(o) => { setEditOpen(o); if (!o) setEditing(null) }}
        editing={editing}
        emailTemplates={emailTemplates}
        patchEdit={patchEdit}
        appendVariable={appendVariable}
        onSave={handleSave}
        onReset={handleReset}
        onCancel={() => { setEditOpen(false); setEditing(null) }}
      />
    </div>
  )
}

// ── Reusable edit dialog (used by both the page + inline variants) ──────
function EditTemplateDialog({
  open,
  onOpenChange,
  editing,
  emailTemplates,
  patchEdit,
  appendVariable,
  onSave,
  onReset,
  onCancel,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  editing: EditState | null
  emailTemplates: EmailTemplate[]
  patchEdit: (patch: Partial<EditState>) => void
  appendVariable: (v: string) => void
  onSave: () => void
  onReset: () => void
  onCancel: () => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {emailTemplates.find((t) => t.id === editing?.id)?.name ??
              'Edit template'}
          </DialogTitle>
          <DialogDescription>
            Edit the subject and body. Use{' '}
            <code className="rounded bg-muted px-1 py-0.5 text-[10px] font-mono">
              {'{{variable}}'}
            </code>{' '}
            placeholders to inject dynamic content.
          </DialogDescription>
        </DialogHeader>

        {editing && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="et-subject">Subject</Label>
              <Input
                id="et-subject"
                value={editing.subject}
                onChange={(e) => patchEdit({ subject: e.target.value })}
                placeholder="Email subject"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="et-body">Body</Label>
              <Textarea
                id="et-body"
                rows={10}
                value={editing.body}
                onChange={(e) => patchEdit({ body: e.target.value })}
                placeholder="Email body…"
                className="font-mono text-xs"
              />
            </div>

            {/* Variables */}
            {(() => {
              const t = emailTemplates.find((x) => x.id === editing.id)
              if (!t || t.variables.length === 0) return null
              return (
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">
                    Available variables — click to insert at end of body
                  </Label>
                  <div className="flex flex-wrap gap-1.5">
                    {t.variables.map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => appendVariable(v)}
                        className="rounded-md border border-emerald-500/30 bg-emerald-500/10 px-2 py-1 font-mono text-[11px] text-emerald-700 transition-colors hover:bg-emerald-500/20 dark:text-emerald-300"
                      >
                        {`{{${v}}}`}
                      </button>
                    ))}
                  </div>
                </div>
              )
            })()}

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Template enabled</p>
                <p className="text-xs text-muted-foreground">
                  Disabled templates will not be sent automatically.
                </p>
              </div>
              <Switch
                checked={editing.enabled}
                onCheckedChange={(c) => patchEdit({ enabled: c })}
                aria-label="Toggle template enabled"
              />
            </div>
          </div>
        )}

        <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
          <Button
            type="button"
            variant="ghost"
            onClick={onReset}
            className="text-muted-foreground"
          >
            <RotateCcw className="h-4 w-4" /> Reset to default
          </Button>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="button" onClick={onSave}>
              <Check className="h-4 w-4" /> Save
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
