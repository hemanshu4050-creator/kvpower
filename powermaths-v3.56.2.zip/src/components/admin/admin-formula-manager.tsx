'use client'

/**
 * AdminFormulaManager — Formula notebook management for a single chapter.
 *
 * Rendered inside the ChapterContentSheet "Formula" tab. Provides:
 *   • Search + filter by category
 *   • Add / Edit / Delete / Duplicate / Hide-show formulas
 *   • Drag-and-drop reordering (up/down buttons as a reliable fallback
 *     since the sheet is a narrow drawer)
 *   • Live KaTeX preview in the editor
 *
 * Look-and-feel matches the student notes section: card list, icon tiles,
 * accent colours, smooth animations.
 */

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus, Search, Pencil, Trash2, Copy, Eye, EyeOff,
  ChevronUp, ChevronDown, Sigma, Sparkles,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { KatexMath } from '@/components/shared/katex-math'
import { useDataStore, type Formula } from '@/lib/data-store'
import { cn } from '@/lib/utils'

interface AdminFormulaManagerProps {
  chapterId: string
  formulas: Formula[]
}

interface FormulaFormState {
  title: string
  category: string
  expression: string
  explanation: string
  example: string
  notes: string
}

const EMPTY_FORM: FormulaFormState = {
  title: '', category: '', expression: '', explanation: '', example: '', notes: '',
}

const ACCENTS = ['emerald', 'teal', 'violet', 'amber', 'rose', 'blue']

function accentFor(idx: number) {
  const a = ACCENTS[idx % ACCENTS.length]
  return {
    bg: `bg-${a}-500/10`,
    text: `text-${a}-600 dark:text-${a}-400`,
    ring: `ring-${a}-500/30`,
  }
}

export function AdminFormulaManager({ chapterId, formulas }: AdminFormulaManagerProps) {
  const { addFormula, updateFormula, deleteFormula, duplicateFormula, reorderFormulas } = useDataStore()

  const [search, setSearch] = React.useState('')
  const [activeCategory, setActiveCategory] = React.useState<string>('all')
  const [editOpen, setEditOpen] = React.useState(false)
  const [editingId, setEditingId] = React.useState<string | null>(null)
  const [form, setForm] = React.useState<FormulaFormState>(EMPTY_FORM)
  const [deleteId, setDeleteId] = React.useState<string | null>(null)

  const categories = React.useMemo(() => {
    const set = new Set<string>()
    formulas.forEach((f) => f.category && set.add(f.category))
    return ['all', ...Array.from(set).sort()]
  }, [formulas])

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase()
    return [...formulas]
      .sort((a, b) => a.order - b.order)
      .filter((f) => !f.hidden || true) // admin sees hidden ones too
      .filter((f) => activeCategory === 'all' || f.category === activeCategory)
      .filter((f) => {
        if (!q) return true
        return (
          f.title.toLowerCase().includes(q) ||
          f.category.toLowerCase().includes(q) ||
          f.expression.toLowerCase().includes(q) ||
          f.explanation.toLowerCase().includes(q)
        )
      })
  }, [formulas, search, activeCategory])

  const openAdd = () => {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setEditOpen(true)
  }

  const openEdit = (f: Formula) => {
    setEditingId(f.id)
    setForm({
      title: f.title, category: f.category, expression: f.expression,
      explanation: f.explanation, example: f.example, notes: f.notes ?? '',
    })
    setEditOpen(true)
  }

  const handleSave = () => {
    if (!form.title.trim()) { toast.error('Title is required'); return }
    if (!form.expression.trim()) { toast.error('Formula expression is required'); return }
    if (editingId) {
      updateFormula(chapterId, editingId, {
        title: form.title.trim(),
        category: form.category.trim() || 'General',
        expression: form.expression.trim(),
        explanation: form.explanation.trim(),
        example: form.example.trim(),
        notes: form.notes.trim() || undefined,
      })
      toast.success('Formula updated')
    } else {
      addFormula(chapterId, {
        title: form.title.trim(),
        category: form.category.trim() || 'General',
        expression: form.expression.trim(),
        explanation: form.explanation.trim(),
        example: form.example.trim(),
        notes: form.notes.trim() || undefined,
        hidden: false,
      })
      toast.success('Formula added')
    }
    setEditOpen(false)
    setForm(EMPTY_FORM)
    setEditingId(null)
  }

  const handleDelete = () => {
    if (!deleteId) return
    deleteFormula(chapterId, deleteId)
    toast.success('Formula deleted')
    setDeleteId(null)
  }

  const handleDuplicate = (f: Formula) => {
    duplicateFormula(chapterId, f.id)
    toast.success('Formula duplicated')
  }

  const handleToggleHidden = (f: Formula) => {
    updateFormula(chapterId, f.id, { hidden: !f.hidden })
    toast.success(f.hidden ? 'Formula shown' : 'Formula hidden')
  }

  const handleMove = (f: Formula, dir: -1 | 1) => {
    const sorted = [...formulas].sort((a, b) => a.order - b.order)
    const idx = sorted.findIndex((x) => x.id === f.id)
    const swapWith = idx + dir
    if (swapWith < 0 || swapWith >= sorted.length) return
    const reordered = [...sorted]
    const tmp = reordered[idx]
    reordered[idx] = reordered[swapWith]
    reordered[swapWith] = tmp
    reorderFormulas(chapterId, reordered.map((x) => x.id))
  }

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search formulas..."
            className="input-premium h-9 pl-9"
          />
        </div>
        <Button size="sm" className="btn-premium-primary h-9" onClick={openAdd}>
          <Plus className="h-3.5 w-3.5" /> Add Formula
        </Button>
      </div>

      {/* Category chips */}
      {categories.length > 1 && (
        <div className="flex flex-wrap gap-1.5">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c)}
              className={cn(
                'rounded-full border px-2.5 py-0.5 text-[11px] font-medium transition-colors',
                activeCategory === c
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-border bg-background text-muted-foreground hover:bg-muted'
              )}
            >
              {c === 'all' ? 'All categories' : c}
            </button>
          ))}
        </div>
      )}

      {/* Formula cards */}
      {filtered.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 px-4 py-8 text-center">
          <Sigma className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm font-medium text-foreground">No formulas yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Add the chapter's key formulas here — they'll appear in every student's formula notebook.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          <AnimatePresence initial={false}>
            {filtered.map((f, idx) => {
              const accent = accentFor(idx)
              return (
                <motion.div
                  key={f.id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                >
                  <Card className={cn(
                    'relative overflow-hidden p-3.5 transition-all hover:shadow-md',
                    f.hidden && 'opacity-55'
                  )}>
                    {/* Accent strip */}
                    <div className={cn('absolute left-0 top-0 h-full w-1', accent.bg)} />

                    <div className="flex items-start gap-3 pl-2">
                      {/* Icon tile */}
                      <div className={cn(
                        'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ring-1',
                        accent.bg, accent.text, accent.ring
                      )}>
                        <Sigma className="h-4 w-4" />
                      </div>

                      {/* Content */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="truncate text-sm font-semibold">{f.title}</p>
                              {f.hidden && (
                                <Badge variant="outline" className="h-4 px-1 text-[9px] uppercase tracking-wide text-muted-foreground">
                                  Hidden
                                </Badge>
                              )}
                            </div>
                            {f.category && (
                              <p className="text-[11px] text-muted-foreground">{f.category}</p>
                            )}
                          </div>

                          {/* Actions */}
                          <div className="flex shrink-0 items-center gap-0.5">
                            <button
                              onClick={() => handleMove(f, -1)}
                              disabled={idx === 0}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Move up"
                            >
                              <ChevronUp className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleMove(f, 1)}
                              disabled={idx === filtered.length - 1}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Move down"
                            >
                              <ChevronDown className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleToggleHidden(f)}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                              title={f.hidden ? 'Show formula' : 'Hide formula'}
                            >
                              {f.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                            </button>
                            <button
                              onClick={() => handleDuplicate(f)}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                              title="Duplicate"
                            >
                              <Copy className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => openEdit(f)}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                              title="Edit"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteId(f.id)}
                              className="rounded p-1 text-destructive hover:bg-destructive/10"
                              title="Delete"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Formula expression (KaTeX) */}
                        <div className="mt-2 rounded-md bg-muted/30 px-3 py-2 text-center overflow-x-auto">
                          <KatexMath expression={f.expression} display />
                        </div>

                        {/* Explanation */}
                        {f.explanation && (
                          <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                            {f.explanation}
                          </p>
                        )}

                        {/* Example */}
                        {f.example && (
                          <div className="mt-2 rounded-md border border-border/60 bg-background px-2.5 py-1.5">
                            <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                              Example
                            </p>
                            <div className="text-xs overflow-x-auto">
                              <KatexMath expression={f.example} display={false} />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Edit / Add dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="flex max-h-[92vh] flex-col overflow-hidden p-6 sm:max-w-4xl">
          <DialogHeader className="shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              {editingId ? 'Edit Formula' : 'Add New Formula'}
            </DialogTitle>
            <DialogDescription>
              Use LaTeX syntax for the expression (KaTeX renders it). Inline math in the example can use $...$ delimiters.
            </DialogDescription>
          </DialogHeader>

          {/* Side-by-side: form (left) + live preview (right). Stacks on mobile. */}
          <div className="grid min-h-0 flex-1 gap-4 md:grid-cols-2">
            {/* Left: form fields (scrollable) */}
            <div className="flex min-h-0 flex-col gap-3 overflow-y-auto pr-1">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Title <span className="text-destructive">*</span></Label>
                  <Input
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Pythagoras Theorem"
                    className="input-premium"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Category</Label>
                  <Input
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    placeholder="e.g. Identities, Areas"
                    className="input-premium"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Formula (LaTeX) <span className="text-destructive">*</span></Label>
                <Textarea
                  value={form.expression}
                  onChange={(e) => setForm({ ...form, expression: e.target.value })}
                  placeholder="a^2 + b^2 = c^2"
                  className="input-premium font-mono text-sm"
                  rows={2}
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Explanation</Label>
                <Textarea
                  value={form.explanation}
                  onChange={(e) => setForm({ ...form, explanation: e.target.value })}
                  placeholder="Plain-text explanation of what the formula means..."
                  className="input-premium"
                  rows={3}
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Example (LaTeX allowed)</Label>
                <Textarea
                  value={form.example}
                  onChange={(e) => setForm({ ...form, example: e.target.value })}
                  placeholder="3^2 + 4^2 = 9 + 16 = 25 = 5^2"
                  className="input-premium font-mono text-sm"
                  rows={2}
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Notes (optional)</Label>
                <Textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Any extra tips or caveats..."
                  className="input-premium"
                  rows={2}
                />
              </div>
            </div>

            {/* Right: live preview (always visible alongside form on md+) */}
            <div className="flex min-h-0 flex-col overflow-hidden rounded-md border border-primary/30 bg-primary/5">
              <div className="flex shrink-0 items-center justify-between border-b border-primary/20 bg-primary/10 px-3 py-1.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-primary">
                  Live preview
                </p>
                <span className="text-[9px] text-muted-foreground">updates as you type</span>
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
                {/* Title */}
                {form.title ? (
                  <p className="mb-2 text-sm font-semibold">{form.title}</p>
                ) : (
                  <p className="mb-2 text-sm font-semibold text-muted-foreground italic">Formula title</p>
                )}

                {/* Category badge */}
                {form.category && (
                  <Badge variant="outline" className="mb-3 text-[10px]">
                    {form.category}
                  </Badge>
                )}

                {/* Expression (display math) */}
                <div className="mb-3 rounded-md bg-background px-3 py-3 text-center ring-1 ring-border/60">
                  {form.expression ? (
                    <KatexMath expression={form.expression} display />
                  ) : (
                    <p className="text-xs text-muted-foreground italic">Formula expression preview</p>
                  )}
                </div>

                {/* Explanation */}
                {form.explanation && (
                  <div className="mb-3">
                    <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Explanation
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{form.explanation}</p>
                  </div>
                )}

                {/* Example */}
                {form.example && (
                  <div className="mb-3 rounded-md border border-border/60 bg-background px-2.5 py-1.5">
                    <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Example
                    </p>
                    <div className="text-xs overflow-x-auto">
                      <KatexMath expression={form.example} display={false} />
                    </div>
                  </div>
                )}

                {/* Notes */}
                {form.notes && (
                  <div className="mb-3">
                    <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Notes
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{form.notes}</p>
                  </div>
                )}

                {/* Empty state */}
                {!form.expression && !form.explanation && !form.example && (
                  <div className="flex h-32 flex-col items-center justify-center text-center text-muted-foreground">
                    <Eye className="mb-2 h-6 w-6 opacity-40" />
                    <p className="text-xs">Start filling the form to see the rendered formula preview here.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="shrink-0">
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button className="btn-premium-primary" onClick={handleSave}>
              {editingId ? 'Save changes' : 'Add formula'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this formula?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The formula will be removed from every student's notebook immediately.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
