'use client'

import * as React from 'react'
import { useAppStore, type AdminPage } from '@/lib/store'
import { AdminDashboard } from './admin-dashboard'
import { AdminStudents } from './admin-students'
import { AdminBatches } from './admin-batches'
import { AdminChapters } from './admin-chapters'
import { AdminQuestions } from './admin-questions'
import { AdminExams } from './admin-exams'
import { AdminResults } from './admin-results'
import { AdminCertificates } from './admin-certificates'
import { AdminStudentReports } from './admin-student-reports'
import { AdminNotifications } from './admin-notifications'
import { AdminAnnouncements } from './admin-announcements'
import { AdminMarketing } from './admin-marketing'
import { AdminActivity } from './admin-activity'
import { AdminEmailTemplates } from './admin-email-templates'
import { AdminEmailLog } from './admin-email-log'
import { AdminSettings } from './admin-settings'

const modules: Record<AdminPage, React.ComponentType> = {
  dashboard: AdminDashboard,
  students: AdminStudents,
  batches: AdminBatches,
  chapters: AdminChapters,
  questions: AdminQuestions,
  exams: AdminExams,
  results: AdminResults,
  certificates: AdminCertificates,
  'student-reports': AdminStudentReports,
  notifications: AdminNotifications,
  announcements: AdminAnnouncements,
  marketing: AdminMarketing,
  activity: AdminActivity,
  'email-templates': AdminEmailTemplates,
  'email-log': AdminEmailLog,
  settings: AdminSettings,
}

export function AdminRouter() {
  const page = useAppStore((s) => s.adminPage)
  const Module = modules[page] ?? AdminDashboard
  return (
    <div key={page} className="animate-fade-in">
      <Module />
    </div>
  )
}
