'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Download,
  Filter,
  Mail,
  MailOpen,
  Search,
  Trash2,
  type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  useDataStore,
  type EmailLog,
  type EmailStatus,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'

const statusMeta: Record<
  EmailStatus,
  { icon: LucideIcon; dot: string; badge: string; label: string }
> = {
  sent: {
    icon: CheckCircle2,
    dot: 'bg-emerald-500',
    badge:
      'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    label: 'Sent',
  },
  queued: {
    icon: Clock,
    dot: 'bg-amber-500',
    badge:
      'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    label: 'Queued',
  },
  failed: {
    icon: AlertCircle,
    dot: 'bg-rose-500',
    badge: 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
    label: 'Failed',
  },
}

export function AdminEmailLog() {
  const pageTitle = useNavLabel('email-log', 'Email Log')
  const { emailLogs, clearEmailLog } = useDataStore()

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | EmailStatus>('all')
  const [clearOpen, setClearOpen] = useState(false)

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return emailLogs.filter((l) => {
      if (
        q &&
        !l.toName.toLowerCase().includes(q) &&
        !l.toEmail.toLowerCase().includes(q) &&
        !l.subject.toLowerCase().includes(q)
      )
        return false
      if (statusFilter !== 'all' && l.status !== statusFilter) return false
      return true
    })
  }, [emailLogs, search, statusFilter])

  const stats = useMemo(() => {
    const total = emailLogs.length
    const sent = emailLogs.filter((l) => l.status === 'sent').length
    const queued = emailLogs.filter((l) => l.status === 'queued').length
    const failed = emailLogs.filter((l) => l.status === 'failed').length
    return { total, sent, queued, failed }
  }, [emailLogs])

  const clearFilters = () => {
    setSearch('')
    setStatusFilter('all')
  }

  const handleClearLog = () => {
    clearEmailLog()
    toast.success('Email log cleared')
    setClearOpen(false)
  }

  const handleExport = () => {
    toast.success('Export started', {
      description: `${filtered.length} email${filtered.length === 1 ? '' : 's'} will download shortly.`,
    })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Every email sent by the portal — welcome messages, exam results, certificates and announcements."
        icon={<Mail className="h-5 w-5" />}
        actions={
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4" /> Export
          </Button>
        }
      />

      {/* v3.36.0 — 30-day auto-delete retention notice. */}
      <div className="flex items-start gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-sm">
        <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
        <div>
          <p className="font-medium text-foreground">Auto-deleted after 30 days</p>
          <p className="mt-0.5 text-muted-foreground">
            Email log entries are automatically and permanently deleted{' '}
            <span className="font-medium text-foreground">30 days</span> after they are sent to
            keep the log lightweight. Export to CSV if you need a permanent record.
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="Total Sent"
          value={stats.total}
          icon={MailOpen}
          accent="emerald"
          delay={0}
        />
        <StatCard
          title="Delivered"
          value={stats.sent}
          icon={CheckCircle2}
          accent="teal"
          delay={0.05}
        />
        <StatCard
          title="Queued"
          value={stats.queued}
          icon={Clock}
          accent="amber"
          delay={0.1}
        />
        <StatCard
          title="Failed"
          value={stats.failed}
          icon={AlertCircle}
          accent="rose"
          delay={0.15}
        />
      </div>

      {/* Toolbar */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by recipient, email or subject…"
              className="pl-9"
              aria-label="Search email log"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select
              value={statusFilter}
              onValueChange={(v) =>
                setStatusFilter(v as 'all' | EmailStatus)
              }
            >
              <SelectTrigger className="w-[140px]" aria-label="Filter by status">
                <span className="flex items-center gap-2">
                  <Filter className="h-3.5 w-3.5 text-muted-foreground" />
                  <SelectValue placeholder="Status" />
                </span>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="queued">Queued</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            {(search || statusFilter !== 'all') && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setClearOpen(true)}
              disabled={emailLogs.length === 0}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" /> Clear log
            </Button>
          </div>
        </div>
      </Card>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border">
        <Card className="card-elevated gap-0 p-0">
          {filtered.length === 0 ? (
            <EmptyState
              icon={Mail}
              title="No emails found"
              description={
                emailLogs.length === 0
                  ? 'Emails sent by the portal will appear here.'
                  : 'Try adjusting your search or filters.'
              }
              action={
                emailLogs.length > 0 ? (
                  <Button variant="outline" onClick={clearFilters}>
                    Reset filters
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="min-w-[180px]">Recipient</TableHead>
                    <TableHead className="min-w-[200px]">Subject</TableHead>
                    <TableHead className="hidden md:table-cell">
                      Template
                    </TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden sm:table-cell text-right">
                      Sent At
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((log, i) => (
                    <LogRow key={log.id} log={log} index={i} />
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </Card>
      </div>

      {/* Clear confirmation */}
      <AlertDialog open={clearOpen} onOpenChange={setClearOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear entire email log?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove all{' '}
              <span className="font-medium text-foreground">
                {emailLogs.length}
              </span>{' '}
              email log entries. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleClearLog}
            >
              <Trash2 className="h-4 w-4" /> Clear log
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function LogRow({ log, index }: { log: EmailLog; index: number }) {
  const meta = statusMeta[log.status]
  const StatusIcon = meta.icon
  return (
    <motion.tr
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.03, 0.4) }}
      className="group"
    >
      <TableCell>
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Mail className="h-3.5 w-3.5" />
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-medium">{log.toName}</div>
            <div className="truncate text-xs text-muted-foreground">
              {log.toEmail}
            </div>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{log.subject}</p>
          <p className="line-clamp-1 truncate text-xs text-muted-foreground">
            {log.preview}
          </p>
        </div>
      </TableCell>
      <TableCell className="hidden md:table-cell">
        <Badge variant="outline" className="font-normal">
          {log.templateName}
        </Badge>
      </TableCell>
      <TableCell>
        <Badge variant="outline" className={`gap-1.5 ${meta.badge}`}>
          <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
          <StatusIcon className="h-3 w-3" />
          {meta.label}
        </Badge>
      </TableCell>
      <TableCell className="hidden sm:table-cell text-right text-xs text-muted-foreground tabular-nums">
        {log.sentAt}
      </TableCell>
    </motion.tr>
  )
}
