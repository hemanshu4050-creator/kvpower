'use client'

import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity,
  Award,
  BarChart3,
  BookCheck,
  BookOpen,
  Calendar,
  CalendarRange,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Copy,
  Crown,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  Flame,
  Layers,
  LayoutDashboard,
  Mail,
  Medal,
  MoreHorizontal,
  Network,
  Pencil,
  PlayCircle,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Star,
  Trash2,
  TrendingUp,
  Trophy,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  useDataStore,
  type Batch,
  type Student,
  type Result,
  type Certificate,
  type Chapter,
  type Exam,
  type ActivityLog,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import {
  avatarColorClasses,
  dotColor,
  initials,
  getChapterIcon,
} from './lib/helpers'

// ────────────────────────────────────────────────────────────────────────────
//  Types & helpers
// ────────────────────────────────────────────────────────────────────────────

type BatchStatus = Batch['status']

interface BatchStat {
  studentCount: number
  studentIds: string[]
  results: Result[]
  certificates: Certificate[]
  avgScore: number
  avgProgress: number
  highest: number
  lowest: number
  passed: number
  failed: number
  certsIssued: number
  trend: number[]
}

interface BatchFormState {
  id?: string
  name: string
  code: string
  academicYear: string
  startDate: string
  endDate: string
  description: string
  status: BatchStatus
  maxStudents: number
  notes: string
  // v3.39 — assignment options are now part of the Create/Edit form so the
  // admin can configure chapters / exams / students in the SAME place where
  // they define the level.  For Create mode these are applied immediately
  // after the batch is created (addBatch returns the new Batch with its id).
  chapterIds: string[]
  examIds: string[]
  studentIds: string[]
}

const emptyForm: BatchFormState = {
  name: '',
  code: '',
  academicYear: '2026-2027',
  startDate: '',
  endDate: '',
  description: '',
  status: 'active',
  maxStudents: 40,
  notes: '',
  chapterIds: [],
  examIds: [],
  studentIds: [],
}

const statusBadge: Record<BatchStatus, string> = {
  active:
    'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  inactive:
    'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  archived:
    'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300',
}

const statusDot: Record<BatchStatus, string> = {
  active: 'bg-emerald-500',
  inactive: 'bg-amber-500',
  archived: 'bg-zinc-400',
}

const examTypeLabel: Record<Exam['type'], string> = {
  chapter_test: 'Chapter Test',
  cumulative: 'Cumulative',
  semi: 'Semi',
  final: 'Final',
  worksheet_test: 'Worksheet',
}

const examTypeBadge: Record<Exam['type'], string> = {
  chapter_test:
    'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  cumulative:
    'border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-violet-300',
  semi:
    'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  final:
    'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
  worksheet_test:
    'border-teal-500/30 bg-teal-500/10 text-teal-700 dark:text-teal-300',
}

/** Tier derived from average score — for leaderboard ranking. */
function tierFor(score: number): {
  label: string
  icon: typeof Crown
  className: string
  tierClass: string
} {
  if (score >= 85)
    return {
      label: 'Gold',
      icon: Crown,
      className: 'text-amber-600 dark:text-amber-400',
      tierClass: 'tier-glow-gold',
    }
  if (score >= 70)
    return {
      label: 'Silver',
      icon: Medal,
      className: 'text-zinc-500 dark:text-zinc-300',
      tierClass: 'tier-glow-silver',
    }
  if (score >= 50)
    return {
      label: 'Bronze',
      icon: Award,
      className: 'text-orange-600 dark:text-orange-400',
      tierClass: 'tier-glow-bronze',
    }
  return {
    label: 'Newcomer',
    icon: Sparkles,
    className: 'text-emerald-600 dark:text-emerald-400',
    tierClass: 'tier-glow-new',
  }
}

/** Relative time formatter ("2 hours ago"). */
function timeAgo(iso: string | null): { rel: string; abs: string } {
  if (!iso) return { rel: 'Never', abs: '—' }
  const d = new Date(iso.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return { rel: iso, abs: iso }
  const diff = Date.now() - d.getTime()
  const abs = d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
  if (diff < 0) return { rel: 'Just now', abs }
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return { rel: 'Just now', abs }
  if (mins < 60) return { rel: `${mins} min ago`, abs }
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return { rel: `${hrs} hour${hrs === 1 ? '' : 's'} ago`, abs }
  const days = Math.floor(hrs / 24)
  if (days < 7) return { rel: `${days} day${days === 1 ? '' : 's'} ago`, abs }
  const weeks = Math.floor(days / 7)
  if (weeks < 5) return { rel: `${weeks} week${weeks === 1 ? '' : 's'} ago`, abs }
  const months = Math.floor(days / 30)
  return { rel: `${months} month${months === 1 ? '' : 's'} ago`, abs }
}

/** Tiny SVG sparkline. */
function Sparkline({
  data,
  positive = true,
}: {
  data: number[]
  positive?: boolean
}) {
  const pts = data.length >= 2 ? data : [40, positive ? 70 : 50]
  const w = 44
  const h = 18
  const max = Math.max(...pts, 1)
  const min = Math.min(...pts, 0)
  const range = max - min || 1
  const step = w / (pts.length - 1)
  const coords = pts.map(
    (p, i) => `${(i * step).toFixed(1)},${(h - ((p - min) / range) * h).toFixed(1)}`
  )
  const color = positive ? '#10b981' : '#f43f5e'
  return (
    <svg width={w} height={h} className="shrink-0" aria-hidden>
      <polyline
        points={coords.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx={w}
        cy={h - ((pts[pts.length - 1] - min) / range) * h}
        r={1.8}
        fill={color}
      />
    </svg>
  )
}

/** Animated count-up number. */
function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const from = display
    const dur = 600
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (value - from) * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value])
  return <span className="tabular-nums">{display}</span>
}

/** Compute a per-student progress value derived from their assigned chapters
 *  and the results they've logged (passed chapter = completed). */
function studentProgress(
  student: Student,
  results: Result[],
  chapters: Chapter[]
): number {
  const assigned = student.assignedChapters.length
  if (!assigned) return 0
  const completed = student.assignedChapters.filter((chId) => {
    const ch = chapters.find((c) => c.id === chId)
    if (!ch) return false
    return results.some(
      (r) =>
        r.studentId === student.id &&
        r.chapterName === ch.name &&
        r.status === 'passed'
    )
  }).length
  return Math.round((completed / assigned) * 100)
}

/** Compute a per-student avg score. */
function studentAvg(studentId: string, results: Result[]): number {
  const sResults = results.filter((r) => r.studentId === studentId)
  if (!sResults.length) return 0
  return Math.round(
    sResults.reduce((a, r) => a + r.percentage, 0) / sResults.length
  )
}


// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminBatches() {
  const pageTitle = useNavLabel('batches', 'Levels Management')
  const {
    batches,
    students,
    chapters,
    exams,
    results,
    certificates,
    activityLogs,
    addBatch,
    updateBatch,
    deleteBatch,
    assignChaptersToBatch,
    removeChaptersFromBatch,
    assignExamsToBatch,
    removeExamsFromBatch,
    addStudentsToBatch,
    removeStudentsFromBatch,
    moveStudentsToBatch,
    updateStudent,
    generateCertificate,
    sendEmail,
    logActivity,
  } = useDataStore()

  // ── Filters ──
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [yearFilter, setYearFilter] = useState<string>('all')
  const [sortBy, setSortBy] = useState<string>('created')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(5)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)

  // ── Dialogs / drawers ──
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [editing, setEditing] = useState<BatchFormState>(emptyForm)
  const [viewing, setViewing] = useState<Batch | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTab, setDrawerTab] = useState('overview')
  const [deleteTarget, setDeleteTarget] = useState<Batch | null>(null)
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false)
  const [bulkAssignChaptersOpen, setBulkAssignChaptersOpen] = useState(false)
  const [bulkAssignExamsOpen, setBulkAssignExamsOpen] = useState(false)
  const [bulkChapterSelection, setBulkChapterSelection] = useState<Set<string>>(
    new Set()
  )
  const [bulkExamSelection, setBulkExamSelection] = useState<Set<string>>(
    new Set()
  )
  const [lastSync, setLastSync] = useState(() => new Date())

  // Simulate loading skeleton on first mount so the premium feel is visible.
  // `loading` starts `true`; flip it to false after a short delay.
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 320)
    return () => clearTimeout(t)
  }, [])

  // ── Per-batch analytics ──
  const batchStats = useMemo(() => {
    const map: Record<string, BatchStat> = {}
    for (const b of batches) {
      const batchStudents = students.filter((s) => s.batch === b.name)
      const studentIds = batchStudents.map((s) => s.id)
      const batchResults = results.filter((r) =>
        studentIds.includes(r.studentId)
      )
      const batchCerts = certificates.filter(
        (c) => studentIds.includes(c.studentId) && c.status === 'issued'
      )
      const avgScore = batchResults.length
        ? Math.round(
            batchResults.reduce((a, r) => a + r.percentage, 0) /
              batchResults.length
          )
        : 0
      const progresses = batchStudents.map((s) =>
        studentProgress(s, results, chapters)
      )
      const avgProgress = progresses.length
        ? Math.round(progresses.reduce((a, p) => a + p, 0) / progresses.length)
        : 0
      const scores = batchResults.map((r) => r.percentage)
      const highest = scores.length ? Math.max(...scores) : 0
      const lowest = scores.length ? Math.min(...scores) : 0
      const passed = batchResults.filter((r) => r.status === 'passed').length
      const failed = batchResults.filter((r) => r.status === 'failed').length
      const trend = batchResults
        .slice(-6)
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
        .map((r) => r.percentage)
      map[b.id] = {
        studentCount: batchStudents.length,
        studentIds,
        results: batchResults,
        certificates: batchCerts,
        avgScore,
        avgProgress,
        highest,
        lowest,
        passed,
        failed,
        certsIssued: batchCerts.length,
        trend,
      }
    }
    return map
  }, [batches, students, results, certificates, chapters])

  // ── Aggregate dashboard stats ──
  const totalBatches = batches.length
  const activeBatches = batches.filter((b) => b.status === 'active').length
  const totalStudentsInBatches = useMemo(
    () =>
      students.filter((s) =>
        batches.some((b) => b.name === s.batch)
      ).length,
    [students, batches]
  )
  const totalUniqueChapters = useMemo(() => {
    const set = new Set<string>()
    batches.forEach((b) => b.chapterIds.forEach((c) => set.add(c)))
    return set.size
  }, [batches])
  const totalUniqueExams = useMemo(() => {
    const set = new Set<string>()
    batches.forEach((b) => b.examIds.forEach((e) => set.add(e)))
    return set.size
  }, [batches])
  // ── Academic years ──
  const academicYears = useMemo(
    () => Array.from(new Set(batches.map((b) => b.academicYear))).sort(),
    [batches]
  )

  // ── Filtered + sorted batches ──
  const filtered = useMemo(() => {
    const list = batches.filter((b) => {
      const q = search.trim().toLowerCase()
      if (
        q &&
        !b.name.toLowerCase().includes(q) &&
        !b.code.toLowerCase().includes(q) &&
        !b.description.toLowerCase().includes(q)
      )
        return false
      if (statusFilter !== 'all' && b.status !== statusFilter) return false
      if (yearFilter !== 'all' && b.academicYear !== yearFilter) return false
      return true
    })
    list.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name)
        case 'students':
          return (
            (batchStats[b.id]?.studentCount ?? 0) -
            (batchStats[a.id]?.studentCount ?? 0)
          )
        case 'score':
          return (
            (batchStats[b.id]?.avgScore ?? 0) -
            (batchStats[a.id]?.avgScore ?? 0)
          )
        case 'created':
        default:
          return b.createdAt.localeCompare(a.createdAt)
      }
    })
    return list
  }, [batches, search, statusFilter, yearFilter, sortBy, batchStats])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const toggleRow = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  const togglePage = () => {
    const allOnPage = rows.length > 0 && rows.every((r) => selected.has(r.id))
    setSelected((prev) => {
      const next = new Set(prev)
      if (allOnPage) rows.forEach((r) => next.delete(r.id))
      else rows.forEach((r) => next.add(r.id))
      return next
    })
  }
  const clearFilters = () => {
    setSearch('')
    setStatusFilter('all')
    setYearFilter('all')
    setSortBy('created')
    setPage(0)
  }
  const activeFilters =
    search || statusFilter !== 'all' || yearFilter !== 'all' || sortBy !== 'created'

  // ── Handlers ──
  const suggestCode = (name: string) => {
    const m = name.match(/(\d{4})\s*-\s*([A-Z])/i)
    if (m) return `PM${m[1].slice(2)}-${m[2].toUpperCase()}`
    if (name.trim()) {
      const parts = name.trim().split(/\s+/)
      const last = parts[parts.length - 1]
      return `PM-${last.slice(0, 3).toUpperCase()}`
    }
    return ''
  }

  const openAdd = () => {
    setEditing(emptyForm)
    setAddOpen(true)
  }
  const openEdit = (b: Batch) => {
    setEditing({
      id: b.id,
      name: b.name,
      code: b.code,
      academicYear: b.academicYear,
      startDate: b.startDate,
      endDate: b.endDate,
      description: b.description,
      status: b.status,
      maxStudents: b.maxStudents,
      notes: b.notes,
      // v3.39 — pre-populate the assignment tabs with the batch's current
      // chapters / exams / enrolled students so the admin sees the full
      // picture in one place and can edit everything together.
      chapterIds: [...b.chapterIds],
      examIds: [...b.examIds],
      studentIds: students
        .filter((s) => s.batch === b.name)
        .map((s) => s.id),
    })
    setEditOpen(true)
  }
  const openDrawer = (b: Batch, tab = 'overview') => {
    setViewing(b)
    setDrawerTab(tab)
    setDrawerOpen(true)
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.name.trim() || !editing.code.trim()) {
      toast.error('Level name and code are required')
      return
    }
    const created = addBatch({
      name: editing.name.trim(),
      code: editing.code.trim(),
      academicYear: editing.academicYear || '2026-2027',
      startDate: editing.startDate,
      endDate: editing.endDate,
      description: editing.description.trim(),
      status: editing.status,
      maxStudents: Number(editing.maxStudents) || 40,
      notes: editing.notes.trim(),
      chapterIds: [],
      examIds: [],
    })
    // v3.39 — apply the assignments the admin picked in the Create form's
    // Chapters / Exams / Students tabs.  These are applied to the freshly
    // created batch (addBatch returns the new Batch with its id) so the
    // same inheritance logic (assignChaptersToBatch / addStudentsToBatch)
    // is reused — no duplication of logic.
    const chapCount = editing.chapterIds.length
    const examCount = editing.examIds.length
    const stuCount = editing.studentIds.length
    if (chapCount) assignChaptersToBatch(created.id, editing.chapterIds)
    if (examCount) assignExamsToBatch(created.id, editing.examIds)
    if (stuCount) addStudentsToBatch(created.id, editing.studentIds)
    toast.success('Level created', {
      description: `${editing.name} is now ${editing.status}${
        chapCount || examCount || stuCount
          ? `  •  ${chapCount} chapter(s), ${examCount} exam(s), ${stuCount} student(s)`
          : ''
      }.`,
    })
    setAddOpen(false)
    setEditing(emptyForm)
    setLastSync(new Date())
  }

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    if (!editing.name.trim() || !editing.code.trim()) {
      toast.error('Level name and code are required')
      return
    }
    updateBatch(editing.id, {
      name: editing.name.trim(),
      code: editing.code.trim(),
      academicYear: editing.academicYear || '2026-2027',
      startDate: editing.startDate,
      endDate: editing.endDate,
      description: editing.description.trim(),
      status: editing.status,
      maxStudents: Number(editing.maxStudents) || 40,
      notes: editing.notes.trim(),
    })
    // v3.39 — reconcile the assignment tabs.  Whatever the admin ticked in
    // the Chapters / Exams / Students tabs of the Edit form is the new
    // source of truth, so we add the newly-selected ids and remove the
    // newly-deselected ones.  This reuses the existing store actions so the
    // inheritance / propagation logic is identical to the dedicated detail
    // page.
    const batch = batches.find((b) => b.id === editing.id)
    if (batch) {
      const prevChap = new Set(batch.chapterIds)
      const prevExam = new Set(batch.examIds)
      const prevStu = new Set(
        students.filter((s) => s.batch === batch.name).map((s) => s.id)
      )
      const nextChap = new Set(editing.chapterIds)
      const nextExam = new Set(editing.examIds)
      const nextStu = new Set(editing.studentIds)
      const chapAdd = [...nextChap].filter((id) => !prevChap.has(id))
      const chapRem = [...prevChap].filter((id) => !nextChap.has(id))
      const examAdd = [...nextExam].filter((id) => !prevExam.has(id))
      const examRem = [...prevExam].filter((id) => !nextExam.has(id))
      const stuAdd = [...nextStu].filter((id) => !prevStu.has(id))
      const stuRem = [...prevStu].filter((id) => !nextStu.has(id))
      if (chapAdd.length) assignChaptersToBatch(editing.id, chapAdd)
      if (chapRem.length) removeChaptersFromBatch(editing.id, chapRem)
      if (examAdd.length) assignExamsToBatch(editing.id, examAdd)
      if (examRem.length) removeExamsFromBatch(editing.id, examRem)
      if (stuAdd.length) addStudentsToBatch(editing.id, stuAdd)
      if (stuRem.length) removeStudentsFromBatch(editing.id, stuRem)
    }
    toast.success('Level updated', { description: editing.name })
    setEditOpen(false)
    setLastSync(new Date())
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    deleteBatch(deleteTarget.id)
    toast.error('Level deleted', { description: deleteTarget.name })
    if (viewing?.id === deleteTarget.id) {
      setDrawerOpen(false)
      setViewing(null)
    }
    setDeleteTarget(null)
  }

  // ── Single-batch chapter / exam assignment (drawer) ──
  const assignChapters = (batchId: string, chapterIds: string[]) => {
    if (!chapterIds.length) {
      toast.error('Pick at least one chapter')
      return
    }
    const batch = batches.find((b) => b.id === batchId)
    if (!batch) return
    const n = students.filter((s) => s.batch === batch.name).length
    assignChaptersToBatch(batchId, chapterIds)
    toast.success('Chapters assigned', {
      description: `${n} student${n === 1 ? '' : 's'} updated automatically`,
    })
  }
  const removeChapter = (batchId: string, chapterId: string) => {
    const batch = batches.find((b) => b.id === batchId)
    if (!batch) return
    const n = students.filter((s) => s.batch === batch.name).length
    removeChaptersFromBatch(batchId, [chapterId])
    toast.success('Chapter removed', {
      description: `${n} student${n === 1 ? '' : 's'} updated automatically`,
    })
  }
  const assignExams = (batchId: string, examIds: string[]) => {
    if (!examIds.length) {
      toast.error('Pick at least one exam')
      return
    }
    assignExamsToBatch(batchId, examIds)
    toast.success('Exams assigned', { description: `${examIds.length} exam(s)` })
  }
  const removeExam = (batchId: string, examId: string) => {
    removeExamsFromBatch(batchId, [examId])
    toast.success('Exam removed')
  }

  // ── Drawer: student management ──
  const addStudents = (batchId: string, studentIds: string[]) => {
    if (!studentIds.length) {
      toast.error('Pick at least one student')
      return
    }
    const batch = batches.find((b) => b.id === batchId)
    if (!batch) return
    addStudentsToBatch(batchId, studentIds)
    toast.success('Students added', {
      description: `${studentIds.length} student(s) inherited ${batch.chapterIds.length} chapter(s)`,
    })
  }
  const removeStudent = (batchId: string, studentId: string) => {
    removeStudentsFromBatch(batchId, [studentId])
    toast.success('Student removed from batch')
  }
  const moveStudent = (studentId: string, toBatchId: string) => {
    moveStudentsToBatch(toBatchId, [studentId])
    const b = batches.find((x) => x.id === toBatchId)
    toast.success('Student moved', { description: b?.name })
  }

  // ── Bulk actions ──
  const bulkActivate = () => {
    selected.forEach((id) => updateBatch(id, { status: 'active' }))
    toast.success(`${selected.size} batch(es) activated`)
    setSelected(new Set())
  }
  const bulkArchive = () => {
    selected.forEach((id) => updateBatch(id, { status: 'archived' }))
    toast.success(`${selected.size} batch(es) archived`)
    setSelected(new Set())
  }
  const bulkDelete = () => {
    selected.forEach((id) => deleteBatch(id))
    toast.error(`${selected.size} batch(es) deleted`)
    setSelected(new Set())
    setBulkDeleteOpen(false)
  }
  const bulkAssignChapters = () => {
    if (bulkChapterSelection.size === 0) {
      toast.error('Pick at least one chapter')
      return
    }
    const chapterArr = Array.from(bulkChapterSelection)
    selected.forEach((id) => assignChaptersToBatch(id, chapterArr))
    toast.success('Chapters assigned', {
      description: `${chapterArr.length} chapter(s) → ${selected.size} batch(es)`,
    })
    setSelected(new Set())
    setBulkChapterSelection(new Set())
    setBulkAssignChaptersOpen(false)
  }
  const bulkAssignExams = () => {
    if (bulkExamSelection.size === 0) {
      toast.error('Pick at least one exam')
      return
    }
    const examArr = Array.from(bulkExamSelection)
    selected.forEach((id) => assignExamsToBatch(id, examArr))
    toast.success('Exams assigned', {
      description: `${examArr.length} exam(s) → ${selected.size} batch(es)`,
    })
    setSelected(new Set())
    setBulkExamSelection(new Set())
    setBulkAssignExamsOpen(false)
  }

  const exportCSV = (batchList: Batch[]) => {
    const rows = [
      ['Name', 'Code', 'Year', 'Status', 'Students', 'Max', 'Chapters', 'Exams', 'Avg Score', 'Avg Progress'],
      ...batchList.map((b) => [
        b.name,
        b.code,
        b.academicYear,
        b.status,
        String(batchStats[b.id]?.studentCount ?? 0),
        String(b.maxStudents),
        String(b.chapterIds.length),
        String(b.examIds.length),
        String(batchStats[b.id]?.avgScore ?? 0),
        String(batchStats[b.id]?.avgProgress ?? 0),
      ]),
    ]
    const csv = rows
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
      .join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `batches-${new Date().toISOString().slice(0, 10)}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('CSV exported', {
      description: `${batchList.length} batch(es)`,
    })
  }

  // ── Drawer: bulk email + cert helpers ──
  const bulkEmailBatch = (b: Batch) => {
    const batchStudents = students.filter((s) => s.batch === b.name)
    if (!batchStudents.length) {
      toast.error('No students in this batch')
      return
    }
    batchStudents.forEach((s) =>
      sendEmail({
        to: s.email,
        toName: s.name,
        from: 'admin@powermaths.edu',
        fromName: 'Power Maths',
        subject: `Update for ${b.name}`,
        body: `Hi ${s.name},\n\nThis is a notification regarding your batch ${b.name} (${b.code}).\n\nRegards,\nPower Maths Team`,
        status: 'sent',
        templateId: 'manual',
      })
    )
    toast.success('Emails sent', {
      description: `${batchStudents.length} student(s) in ${b.name}`,
    })
  }

  const bulkCertForBatch = (b: Batch) => {
    const batchStudents = students.filter((s) => s.batch === b.name)
    if (!batchStudents.length) {
      toast.error('No students in this batch')
      return
    }
    let generated = 0
    for (const s of batchStudents) {
      const passed = results.filter(
        (r) => r.studentId === s.id && r.status === 'passed'
      )
      for (const r of passed) {
        const existing = certificates.find(
          (c) =>
            c.studentId === s.id &&
            c.chapterName === r.chapterName &&
            c.examTitle === r.examTitle
        )
        if (!existing) {
          generateCertificate(
            s.id,
            s.name,
            r.chapterName,
            r.examTitle,
            r.percentage
          )
          generated++
        }
      }
    }
    if (generated === 0) {
      toast.info('No new certificates to generate')
    } else {
      toast.success('Certificates generated', {
        description: `${generated} new certificate(s) for ${b.name}`,
      })
    }
  }

  // v3.39 — derive the live batch object from the store so the detail page
  // always reflects the latest data (after an edit / assignment / delete)
  // instead of showing a stale snapshot captured when the row was clicked.
  const viewingBatch = viewing
    ? batches.find((b) => b.id === viewing.id) ?? null
    : null

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      {!viewing && (
        <>
      <PageHeader
        title={pageTitle}
        description="Cohort management — assign chapters, exams, students; track progress, scores and certificates per batch."
        icon={<Layers className="h-5 w-5" />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="btn-premium-outline h-9"
              onClick={() => {
                setLastSync(new Date())
                toast.success('Batch data refreshed')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Sync</span>
            </Button>
            <Button
              variant="outline"
              className="btn-premium-outline h-9"
              onClick={() => exportCSV(batches)}
            >
              <Download className="h-4 w-4" /> Export
            </Button>
            <Button className="btn-premium-primary h-9" onClick={openAdd}>
              <Plus className="h-4 w-4" /> New Batch
            </Button>
          </>
        }
      />

      {/* Last synced line */}
      <div className="-mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative inline-flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          All systems operational
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span>
          Last synced{' '}
          {lastSync.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
          })}
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{batches.length} batches</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{totalStudentsInBatches} students assigned</span>
      </div>

      {/* ── Hierarchy info banner (v3.38.0) ──
          Makes the existing Level → Chapters → Students hierarchy explicit.
          The data model already supports all four relationships; this banner
          visualises them so the admin understands the structure at a glance. */}
      <div className="flex flex-col gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4 sm:flex-row sm:items-center">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
          <Network className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground">
            {pageTitle} Hierarchy
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1 rounded-md bg-primary/10 px-2 py-0.5 font-medium text-primary">
              <Layers className="h-3 w-3" /> Level
            </span>
            <span className="text-muted-foreground/50">→</span>
            <span className="inline-flex items-center gap-1 rounded-md bg-muted px-2 py-0.5 font-medium">
              <BookOpen className="h-3 w-3" /> Chapters
            </span>
            <span className="text-muted-foreground/50">→</span>
            <span className="inline-flex items-center gap-1 rounded-md bg-muted px-2 py-0.5 font-medium">
              <Users className="h-3 w-3" /> Students
            </span>
            <span className="text-muted-foreground/50">→</span>
            <span className="inline-flex items-center gap-1 rounded-md bg-muted px-2 py-0.5 font-medium">
              <BookCheck className="h-3 w-3" /> Individual chapter assignments
            </span>
          </div>
          <p className="mt-1.5 text-xs text-muted-foreground">
            Chapters are assigned to a Level (inherited by every student in it). Students are enrolled
            into a Level and can also be assigned specific chapters within their Level for targeted
            progress tracking.
          </p>
        </div>
      </div>

      {/* ── Premium stat cards (4) ── */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard
          title="Total Levels"
          value={<AnimatedNumber value={totalBatches} />}
          icon={Layers}
          accent="emerald"
          subtitle="All cohorts"
          trend={{ value: '+1', positive: true }}
          delay={0}
        />
        <StatCard
          title="Active Levels"
          value={<AnimatedNumber value={activeBatches} />}
          icon={PlayCircle}
          accent="teal"
          subtitle="Currently running"
          trend={{ value: '+1', positive: true }}
          delay={0.05}
        />
        <StatCard
          title="Chapters Assigned"
          value={<AnimatedNumber value={totalUniqueChapters} />}
          icon={BookOpen}
          accent="amber"
          subtitle="Unique chapter pool"
          trend={{ value: '+2', positive: true }}
          delay={0.1}
        />
        <StatCard
          title="Exams Assigned"
          value={<AnimatedNumber value={totalUniqueExams} />}
          icon={BookCheck}
          accent="rose"
          subtitle="Unique exam pool"
          trend={{ value: '+1', positive: true }}
          delay={0.15}
        />
      </div>

      {/* ── Sticky filter bar ── */}
      <div className="sticky top-2 z-30">
        <div className="glass-filter-bar rounded-xl p-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                placeholder="Search by level name, code or description…"
                className="input-premium h-9 pl-9"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={yearFilter}
                onValueChange={(v) => {
                  setYearFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All years</SelectItem>
                  {academicYears.map((y) => (
                    <SelectItem key={y} value={y}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="created">Newest first</SelectItem>
                  <SelectItem value="name">Name (A–Z)</SelectItem>
                  <SelectItem value="students">Most students</SelectItem>
                  <SelectItem value="score">Highest score</SelectItem>
                </SelectContent>
              </Select>
              {activeFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-9"
                  onClick={clearFilters}
                >
                  <X className="h-4 w-4" /> Clear
                </Button>
              )}
              <Separator orientation="vertical" className="mx-1 h-6" />
              <Button
                className="btn-premium-primary h-9"
                onClick={openAdd}
              >
                <Plus className="h-4 w-4" /> Create Batch
              </Button>
            </div>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>
              Showing{' '}
              <span className="font-semibold text-foreground num-premium">
                {filtered.length === 0 ? 0 : start + 1}–{end}
              </span>{' '}
              of{' '}
              <span className="font-semibold text-foreground num-premium">
                {filtered.length}
              </span>{' '}
              batches
            </span>
            {selected.size > 0 && (
              <span className="num-premium font-semibold text-emerald-600 dark:text-emerald-400">
                {selected.size} selected
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ── Batch table ── */}
      <Card className="card-premium rounded-xl p-0">
        {loading ? (
          <div className="space-y-2 p-5">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="flex animate-pulse items-center gap-4 rounded-lg border border-border/40 p-3"
              >
                <div className="h-4 w-4 rounded bg-muted" />
                <div className="h-10 w-10 rounded-full bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-1/3 rounded bg-muted" />
                  <div className="h-2 w-1/2 rounded bg-muted" />
                </div>
                <div className="h-6 w-16 rounded bg-muted" />
                <div className="h-2 w-24 rounded bg-muted" />
                <div className="h-6 w-10 rounded bg-muted" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={Layers}
            title="No batches found"
            description={
              activeFilters
                ? 'Try adjusting your filters or search query.'
                : 'Create your first batch to start grouping students, chapters and exams.'
            }
            action={
              <Button className="btn-premium-primary h-9" onClick={openAdd}>
                <Plus className="h-4 w-4" /> Create your first batch
              </Button>
            }
            className="py-20"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 bg-muted/30 hover:bg-muted/30">
                  <TableHead className="w-10 pl-5">
                    <Checkbox
                      checked={
                        rows.length > 0 &&
                        rows.every((r) => selected.has(r.id))
                      }
                      onCheckedChange={togglePage}
                      aria-label="Select page"
                    />
                  </TableHead>
                  <TableHead className="min-w-[260px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Batch
                  </TableHead>
                  <TableHead className="hidden md:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Academic Year
                  </TableHead>
                  <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Status
                  </TableHead>
                  <TableHead className="min-w-[140px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Students
                  </TableHead>
                  <TableHead className="hidden lg:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Chapters
                  </TableHead>
                  <TableHead className="hidden lg:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Exams
                  </TableHead>
                  <TableHead className="hidden sm:table-cell min-w-[150px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Avg Progress
                  </TableHead>
                  <TableHead className="hidden sm:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Avg Score
                  </TableHead>
                  <TableHead className="w-[180px] pr-5 text-right text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Actions
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((b) => {
                  const st = batchStats[b.id]
                  const pct = b.maxStudents
                    ? Math.round(
                        ((st?.studentCount ?? 0) / b.maxStudents) * 100
                      )
                    : 0
                  const capColor =
                    pct >= 100
                      ? 'bg-rose-500'
                      : pct >= 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  return (
                    <TableRow
                      key={b.id}
                      data-state={selected.has(b.id) ? 'selected' : undefined}
                      onClick={() => openDrawer(b)}
                      className="row-premium group cursor-pointer border-border/40 transition-all hover:shadow-sm"
                    >
                      <TableCell
                        className="pl-5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Checkbox
                          checked={selected.has(b.id)}
                          onCheckedChange={() => toggleRow(b.id)}
                          aria-label={`Select ${b.name}`}
                        />
                      </TableCell>
                      {/* Batch identity */}
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div
                            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
                              b.status === 'archived'
                                ? 'border-zinc-500/30 bg-zinc-500/10 text-zinc-600 dark:text-zinc-300'
                                : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                            }`}
                          >
                            <Layers className="h-5 w-5" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="truncate text-sm font-semibold text-foreground">
                                {b.name}
                              </span>
                              <Badge
                                variant="outline"
                                className="chip-premium border-emerald-500/30 bg-emerald-500/10 font-mono text-[10px] text-emerald-700 dark:text-emerald-300"
                              >
                                {b.code}
                              </Badge>
                            </div>
                            <p className="truncate text-xs text-muted-foreground max-w-[280px]">
                              {b.description || 'No description'}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      {/* Academic year */}
                      <TableCell className="hidden md:table-cell">
                        <span className="chip-premium border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-violet-300">
                          <CalendarRange className="h-3 w-3" />
                          {b.academicYear}
                        </span>
                      </TableCell>
                      {/* Status */}
                      <TableCell>
                        <span
                          className={`badge-status ${statusBadge[b.status]}`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${statusDot[b.status]}`}
                          />
                          <span className="capitalize">{b.status}</span>
                        </span>
                      </TableCell>
                      {/* Students + capacity bar */}
                      <TableCell>
                        <div className="space-y-1.5">
                          <div className="flex items-baseline gap-1.5 text-xs">
                            <span className="num-premium font-bold text-foreground">
                              {st?.studentCount ?? 0}
                            </span>
                            <span className="text-muted-foreground">
                              / {b.maxStudents}
                            </span>
                          </div>
                          <div className="h-1.5 w-24 overflow-hidden rounded-full bg-muted">
                            <span
                              className={`block h-full rounded-full ${capColor}`}
                              style={{ width: `${Math.min(100, pct)}%` }}
                            />
                          </div>
                        </div>
                      </TableCell>
                      {/* Chapters */}
                      <TableCell className="hidden lg:table-cell">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            openDrawer(b, 'chapters')
                          }}
                          className="chip-premium border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:scale-105"
                        >
                          <BookOpen className="h-3 w-3" />
                          {b.chapterIds.length} chapter
                          {b.chapterIds.length === 1 ? '' : 's'}
                        </button>
                      </TableCell>
                      {/* Exams */}
                      <TableCell className="hidden lg:table-cell">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            openDrawer(b, 'exams')
                          }}
                          className="chip-premium border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300 hover:scale-105"
                        >
                          <BookCheck className="h-3 w-3" />
                          {b.examIds.length} exam
                          {b.examIds.length === 1 ? '' : 's'}
                        </button>
                      </TableCell>
                      {/* Avg progress */}
                      <TableCell className="hidden sm:table-cell">
                        <div className="flex items-center gap-2">
                          <div className="progress-premium h-1.5 w-20">
                            <div
                              className="progress-premium-fill"
                              style={{
                                width: `${st?.avgProgress ?? 0}%`,
                              }}
                            />
                          </div>
                          <span className="num-premium text-xs font-semibold">
                            {st?.avgProgress ?? 0}%
                          </span>
                        </div>
                      </TableCell>
                      {/* Avg score */}
                      <TableCell className="hidden sm:table-cell">
                        <div className="flex items-center gap-2">
                          <span
                            className={`num-premium text-base font-bold ${
                              (st?.avgScore ?? 0) >= 80
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : (st?.avgScore ?? 0) >= 60
                                ? 'text-amber-600 dark:text-amber-400'
                                : (st?.avgScore ?? 0) > 0
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-muted-foreground'
                            }`}
                          >
                            {st?.avgScore ?? 0}%
                          </span>
                          {(st?.trend.length ?? 0) >= 2 && (
                            <div className="sparkline-glow">
                              <Sparkline
                                data={st?.trend ?? []}
                                positive={(st?.avgScore ?? 0) >= 50}
                              />
                            </div>
                          )}
                        </div>
                      </TableCell>
                      {/* Quick actions */}
                      <TableCell
                        className="pr-5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end gap-0.5 opacity-50 transition-all duration-200 group-hover:opacity-100">
                          <IconAction
                            icon={Eye}
                            label="View"
                            onClick={() => openDrawer(b)}
                          />
                          <IconAction
                            icon={Pencil}
                            label="Edit"
                            onClick={() => openEdit(b)}
                          />
                          <IconAction
                            icon={Users}
                            label="Students"
                            onClick={() => openDrawer(b, 'students')}
                          />
                          <IconAction
                            icon={BookOpen}
                            label="Chapters"
                            onClick={() => openDrawer(b, 'chapters')}
                          />
                          <IconAction
                            icon={BarChart3}
                            label="Analytics"
                            onClick={() => openDrawer(b, 'analytics')}
                          />
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button
                                aria-label="More actions"
                                className="icon-btn-premium"
                              >
                                <MoreHorizontal className="h-4 w-4" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent
                              align="end"
                              className="w-48"
                            >
                              <DropdownMenuLabel className="text-xs text-muted-foreground">
                                {b.code} actions
                              </DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => openDrawer(b, 'exams')}
                              >
                                <BookCheck className="h-4 w-4" /> Manage exams
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => openDrawer(b, 'leaderboard')}
                              >
                                <Trophy className="h-4 w-4" /> Leaderboard
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => bulkEmailBatch(b)}
                              >
                                <Mail className="h-4 w-4" /> Email batch
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => bulkCertForBatch(b)}
                              >
                                <Award className="h-4 w-4" /> Generate certs
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() =>
                                  toast.success('Batch link copied', {
                                    description: b.code,
                                  })
                                }
                              >
                                <Copy className="h-4 w-4" /> Copy code
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() =>
                                  updateBatch(b.id, {
                                    status:
                                      b.status === 'active'
                                        ? 'inactive'
                                        : 'active',
                                  })
                                }
                              >
                                <PlayCircle className="h-4 w-4" />
                                {b.status === 'active'
                                  ? 'Deactivate'
                                  : 'Activate'}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onClick={() => setDeleteTarget(b)}
                              >
                                <Trash2 className="h-4 w-4" /> Delete batch
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}

        {/* ── Pagination footer ── */}
        {!loading && filtered.length > 0 && (
          <div className="flex flex-col items-center justify-between gap-3 border-t border-border/50 px-5 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="font-semibold text-foreground num-premium">
                  {start + 1}–{end}
                </span>{' '}
                of{' '}
                <span className="font-semibold text-foreground num-premium">
                  {filtered.length}
                </span>{' '}
                batches
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => {
                  setRowsPerPage(Number(v))
                  setPage(0)
                }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[5, 10, 20].map((n) => (
                    <SelectItem key={n} value={String(n)}>
                      {n} / page
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="flex items-center gap-1 px-1">
                {Array.from({ length: Math.min(5, pageCount) }).map((_, i) => {
                  let p = i
                  if (pageCount > 5) {
                    p = Math.max(0, Math.min(pageCount - 5, currentPage - 2)) + i
                  }
                  return (
                    <button
                      key={p}
                      data-active={p === currentPage}
                      onClick={() => setPage(p)}
                      className="page-btn-premium num-premium flex h-7 w-7 items-center justify-center rounded-lg border border-border bg-background text-xs font-semibold text-muted-foreground hover:border-primary/30 hover:text-foreground"
                    >
                      {p + 1}
                    </button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage >= pageCount - 1}
                onClick={() =>
                  setPage((p) => Math.min(pageCount - 1, p + 1))
                }
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Floating Add Batch FAB ── */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.4, type: 'spring' }}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.94 }}
        onClick={openAdd}
        className="fab-premium fixed bottom-6 right-6 z-30 flex h-14 items-center gap-2 rounded-full px-5 transition-all"
        aria-label="Add new batch"
      >
        <Plus className="h-5 w-5" />
        <span className="hidden font-semibold sm:inline">Add Batch</span>
      </motion.button>

      {/* ── Floating bulk action bar ── */}
      <AnimatePresence>
        {selected.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="bulk-bar-premium fixed inset-x-0 bottom-6 z-40 mx-auto flex w-fit max-w-[calc(100vw-2rem)] items-center gap-1 rounded-2xl px-3 py-2"
          >
            <span className="num-premium px-2 text-sm font-bold">
              {selected.size} selected
            </span>
            <div className="h-4 w-px bg-border" />
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setBulkAssignChaptersOpen(true)}
            >
              <BookOpen className="h-4 w-4" /> Chapters
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setBulkAssignExamsOpen(true)}
            >
              <BookCheck className="h-4 w-4" /> Exams
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkActivate}>
              <UserCheck className="h-4 w-4" /> Activate
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkArchive}>
              <Layers className="h-4 w-4" /> Archive
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="ghost">
                  <Download className="h-4 w-4" /> Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={() =>
                    exportCSV(
                      batches.filter((b) => selected.has(b.id))
                    )
                  }
                >
                  <FileText className="h-4 w-4" /> Export CSV
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    toast.info('Excel export coming soon')
                  }
                >
                  <FileSpreadsheet className="h-4 w-4" /> Export Excel
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.print()}>
                  <FileText className="h-4 w-4" /> Export PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              size="sm"
              variant="ghost"
              className="text-destructive hover:text-destructive"
              onClick={() => setBulkDeleteOpen(true)}
            >
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
            <div className="h-4 w-px bg-border" />
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setSelected(new Set())}
            >
              Clear
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
        </>
      )}

      {/* ── Add/Edit batch dialog ── */}
      <BatchFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        mode="add"
        suggestCode={suggestCode}
        chapters={chapters}
        exams={exams}
        students={students}
        batch={null}
      />
      <BatchFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        mode="edit"
        suggestCode={suggestCode}
        chapters={chapters}
        exams={exams}
        students={students}
        batch={batches.find((b) => b.id === editing.id) ?? null}
      />

      {/* ── Batch detail full page (v3.39 — was a side Sheet) ── */}
      <BatchDetailSheet
        batch={viewingBatch}
        tab={drawerTab}
        onTabChange={setDrawerTab}
        onBack={() => {
          setViewing(null)
          setDrawerOpen(false)
        }}
        pageTitle={pageTitle}
        batches={batches}
        students={students}
        chapters={chapters}
        exams={exams}
        results={results}
        certificates={certificates}
        activityLogs={activityLogs}
        stat={viewingBatch ? batchStats[viewingBatch.id] : undefined}
        onEdit={(b) => {
          // Keep the detail page mounted behind the edit dialog; after save
          // the live `viewingBatch` recomputes so the page shows fresh data.
          openEdit(b)
        }}
        onDelete={(b) => setDeleteTarget(b)}
        onAssignChapters={assignChapters}
        onRemoveChapter={removeChapter}
        onAssignExams={assignExams}
        onRemoveExam={removeExam}
        onAddStudents={addStudents}
        onRemoveStudent={removeStudent}
        onMoveStudent={moveStudent}
        onBulkEmail={bulkEmailBatch}
        onBulkCert={bulkCertForBatch}
        logActivity={logActivity}
        updateStudent={updateStudent}
      />

      {/* ── Bulk assign chapters ── */}
      <Dialog
        open={bulkAssignChaptersOpen}
        onOpenChange={setBulkAssignChaptersOpen}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              Assign chapters to {selected.size} batch(es)
            </DialogTitle>
            <DialogDescription>
              Pick one or more chapters. Each will be added to every selected
              batch and auto-applied to all students in those batches.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[50vh] space-y-2 overflow-y-auto pr-1">
            {chapters.map((c) => {
              const Icon = getChapterIcon(c.icon)
              const checked = bulkChapterSelection.has(c.id)
              return (
                <label
                  key={c.id}
                  className={`flex cursor-pointer items-center gap-3 rounded-lg border p-2.5 transition-colors ${
                    checked
                      ? 'border-emerald-500/40 bg-emerald-500/5'
                      : 'border-border hover:bg-muted/50'
                  }`}
                >
                  <Checkbox
                    checked={checked}
                    onCheckedChange={() => {
                      setBulkChapterSelection((prev) => {
                        const next = new Set(prev)
                        if (next.has(c.id)) next.delete(c.id)
                        else next.add(c.id)
                        return next
                      })
                    }}
                  />
                  <Icon className="h-4 w-4 shrink-0 text-emerald-500" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">
                      {c.name}
                    </div>
                    <div className="truncate text-xs text-muted-foreground">
                      Order {c.order}
                    </div>
                  </div>
                </label>
              )
            })}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setBulkAssignChaptersOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="btn-premium-primary"
              onClick={bulkAssignChapters}
            >
              <BookOpen className="h-4 w-4" /> Assign to {selected.size}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Bulk assign exams ── */}
      <Dialog open={bulkAssignExamsOpen} onOpenChange={setBulkAssignExamsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              Assign exams to {selected.size} batch(es)
            </DialogTitle>
            <DialogDescription>
              Pick one or more exams. They will be tracked at the batch level.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[50vh] space-y-2 overflow-y-auto pr-1">
            {exams.map((ex) => {
              const checked = bulkExamSelection.has(ex.id)
              return (
                <label
                  key={ex.id}
                  className={`flex cursor-pointer items-center gap-3 rounded-lg border p-2.5 transition-colors ${
                    checked
                      ? 'border-rose-500/40 bg-rose-500/5'
                      : 'border-border hover:bg-muted/50'
                  }`}
                >
                  <Checkbox
                    checked={checked}
                    onCheckedChange={() => {
                      setBulkExamSelection((prev) => {
                        const next = new Set(prev)
                        if (next.has(ex.id)) next.delete(ex.id)
                        else next.add(ex.id)
                        return next
                      })
                    }}
                  />
                  <BookCheck className="h-4 w-4 shrink-0 text-rose-500" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">
                      {ex.title}
                    </div>
                    <div className="truncate text-xs text-muted-foreground">
                      {examTypeLabel[ex.type]} · {ex.marks} marks ·{' '}
                      {ex.duration} min
                    </div>
                  </div>
                </label>
              )
            })}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setBulkAssignExamsOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="btn-premium-primary"
              onClick={bulkAssignExams}
            >
              <BookCheck className="h-4 w-4" /> Assign to {selected.size}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete confirmation (single) ── */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete batch?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove{' '}
              <strong>{deleteTarget?.name}</strong> ({deleteTarget?.code}).
              Students in this batch will keep their progress but lose the
              batch grouping. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Bulk delete confirmation ── */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {selected.size} batches?
            </AlertDialogTitle>
            <AlertDialogDescription>
              All selected batches will be permanently removed. Students in
              those batches will lose their batch grouping. This action cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={bulkDelete}
            >
              Delete {selected.size}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Small presentational helpers
// ────────────────────────────────────────────────────────────────────────────

function IconAction({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Eye
  label: string
  onClick: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          aria-label={label}
          className="icon-btn-premium"
        >
          <Icon className="h-4 w-4" />
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Add/Edit Batch form dialog
// ────────────────────────────────────────────────────────────────────────────

function BatchFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  mode,
  suggestCode,
  chapters,
  exams,
  students,
  batch,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: BatchFormState
  setForm: React.Dispatch<React.SetStateAction<BatchFormState>>
  onSubmit: (e: React.FormEvent) => void
  mode: 'add' | 'edit'
  suggestCode: (name: string) => string
  chapters: Chapter[]
  exams: Exam[]
  students: Student[]
  batch?: Batch | null
}) {
  const [formTab, setFormTab] = useState<'details' | 'chapters' | 'exams' | 'students'>(
    'details'
  )

  // ── helpers for the assignment tabs ──
  const toggleChapter = (id: string) =>
    setForm((p) => ({
      ...p,
      chapterIds: p.chapterIds.includes(id)
        ? p.chapterIds.filter((x) => x !== id)
        : [...p.chapterIds, id],
    }))
  const toggleExam = (id: string) =>
    setForm((p) => ({
      ...p,
      examIds: p.examIds.includes(id)
        ? p.examIds.filter((x) => x !== id)
        : [...p.examIds, id],
    }))
  const toggleStudent = (id: string) =>
    setForm((p) => ({
      ...p,
      studentIds: p.studentIds.includes(id)
        ? p.studentIds.filter((x) => x !== id)
        : [...p.studentIds, id],
    }))

  // Students shown in the Students tab:
  //  • everyone currently in THIS batch (edit mode — pre-checked)
  //  • everyone not yet in any batch (available to enroll)
  // Students already in OTHER batches are hidden here — cross-batch moves
  // are done from the dedicated detail page's "Move" action.
  const availableStudents = useMemo(() => {
    const inThis = new Set(
      mode === 'edit' && batch
        ? students.filter((s) => s.batch === batch.name).map((s) => s.id)
        : []
    )
    return students.filter(
      (s) => inThis.has(s.id) || !s.batch || s.batch === ''
    )
  }, [students, mode, batch])

  // Reset to the Details tab whenever the dialog (re)opens.  Using the
  // render-time prop-change pattern (see react.dev/learn/you-might-not-need-
  // an-effect#adjusting-some-state-when-a-prop-changes) rather than an effect
  // so we don't trigger a cascading re-render.
  const [prevOpen, setPrevOpen] = useState(open)
  if (open !== prevOpen) {
    setPrevOpen(open)
    if (open) setFormTab('details')
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'add' ? 'Create new Level' : 'Edit Level'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'add'
              ? 'Define the level and assign chapters, exams and students — all in one place. Assignments are applied the moment the level is created.'
              : 'Update level details and assignments together. Chapter / exam / student changes are reconciled automatically when you save.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <Tabs value={formTab} onValueChange={(v) => setFormTab(v as typeof formTab)}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="details" className="text-xs">
                <Layers className="mr-1 h-3.5 w-3.5" /> Details
              </TabsTrigger>
              <TabsTrigger value="chapters" className="text-xs">
                <BookOpen className="mr-1 h-3.5 w-3.5" /> Chapters
                <span className="num-premium ml-1 rounded-full bg-muted px-1.5 text-[10px]">
                  {form.chapterIds.length}
                </span>
              </TabsTrigger>
              <TabsTrigger value="exams" className="text-xs">
                <BookCheck className="mr-1 h-3.5 w-3.5" /> Exams
                <span className="num-premium ml-1 rounded-full bg-muted px-1.5 text-[10px]">
                  {form.examIds.length}
                </span>
              </TabsTrigger>
              <TabsTrigger value="students" className="text-xs">
                <Users className="mr-1 h-3.5 w-3.5" /> Students
                <span className="num-premium ml-1 rounded-full bg-muted px-1.5 text-[10px]">
                  {form.studentIds.length}
                </span>
              </TabsTrigger>
            </TabsList>

            {/* ─── Details tab ─── */}
            <TabsContent value="details" className="mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 space-y-1.5">
                  <Label htmlFor="batch-name">Level Name *</Label>
                  <Input
                    id="batch-name"
                    value={form.name}
                    onChange={(e) => {
                      const name = e.target.value
                      setForm((p) => ({
                        ...p,
                        name,
                        code:
                          mode === 'add' && !p.code ? suggestCode(name) : p.code,
                      }))
                    }}
                    placeholder="e.g. Level One"
                    className="input-premium"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-code">Level Code *</Label>
                  <Input
                    id="batch-code"
                    value={form.code}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, code: e.target.value }))
                    }
                    placeholder="e.g. PM26-A"
                    className="input-premium font-mono"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-year">Academic Year</Label>
                  <Input
                    id="batch-year"
                    value={form.academicYear}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, academicYear: e.target.value }))
                    }
                    placeholder="2026-2027"
                    className="input-premium"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-start">Start Date</Label>
                  <Input
                    id="batch-start"
                    type="date"
                    value={form.startDate}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, startDate: e.target.value }))
                    }
                    className="input-premium"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-end">End Date</Label>
                  <Input
                    id="batch-end"
                    type="date"
                    value={form.endDate}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, endDate: e.target.value }))
                    }
                    className="input-premium"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-status">Status</Label>
                  <Select
                    value={form.status}
                    onValueChange={(v) =>
                      setForm((p) => ({ ...p, status: v as BatchStatus }))
                    }
                  >
                    <SelectTrigger id="batch-status" className="input-premium">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="batch-max">Max Students</Label>
                  <Input
                    id="batch-max"
                    type="number"
                    min={1}
                    value={form.maxStudents}
                    onChange={(e) =>
                      setForm((p) => ({
                        ...p,
                        maxStudents: Number(e.target.value) || 0,
                      }))
                    }
                    className="input-premium"
                  />
                </div>
                <div className="col-span-2 space-y-1.5">
                  <Label htmlFor="batch-desc">Description</Label>
                  <Textarea
                    id="batch-desc"
                    rows={2}
                    value={form.description}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, description: e.target.value }))
                    }
                    placeholder="Short description of this level…"
                    className="input-premium"
                  />
                </div>
                <div className="col-span-2 space-y-1.5">
                  <Label htmlFor="batch-notes">Notes</Label>
                  <Textarea
                    id="batch-notes"
                    rows={2}
                    value={form.notes}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, notes: e.target.value }))
                    }
                    placeholder="Internal notes (visible to admins only)…"
                    className="input-premium"
                  />
                </div>
              </div>
            </TabsContent>

            {/* ─── Chapters tab ─── */}
            <TabsContent value="chapters" className="mt-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Assign Chapters</h4>
                  <p className="text-xs text-muted-foreground">
                    Tick every chapter this level should cover. Selected
                    chapters are inherited by every student enrolled in the
                    level.
                  </p>
                </div>
                <Badge variant="outline" className="chip-premium">
                  {form.chapterIds.length} / {chapters.length} selected
                </Badge>
              </div>
              {chapters.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  No chapters exist yet. Create chapters first in the Chapters
                  page.
                </p>
              ) : (
                <ScrollArea className="max-h-[40vh] rounded-lg border border-border/50">
                  <div className="space-y-1 p-2">
                    {chapters.map((c) => {
                      const Icon = getChapterIcon(c.icon)
                      const checked = form.chapterIds.includes(c.id)
                      return (
                        <label
                          key={c.id}
                          className={`flex cursor-pointer items-center gap-3 rounded-lg p-2.5 transition-colors ${
                            checked
                              ? 'bg-emerald-500/10'
                              : 'hover:bg-muted/60'
                          }`}
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => toggleChapter(c.id)}
                          />
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">
                              {c.name}
                            </div>
                            <div className="text-[10px] text-muted-foreground">
                              Order {c.order}
                              {c.description
                                ? ` · ${c.description.slice(0, 60)}${
                                    c.description.length > 60 ? '…' : ''
                                  }`
                                : ''}
                            </div>
                          </div>
                        </label>
                      )
                    })}
                  </div>
                </ScrollArea>
              )}
            </TabsContent>

            {/* ─── Exams tab ─── */}
            <TabsContent value="exams" className="mt-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Assign Exams</h4>
                  <p className="text-xs text-muted-foreground">
                    Pick the exams that belong to this level. Students will see
                    these in their exam list.
                  </p>
                </div>
                <Badge variant="outline" className="chip-premium">
                  {form.examIds.length} / {exams.length} selected
                </Badge>
              </div>
              {exams.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  No exams exist yet. Create exams first in the Exams page.
                </p>
              ) : (
                <ScrollArea className="max-h-[40vh] rounded-lg border border-border/50">
                  <div className="space-y-1 p-2">
                    {exams.map((ex) => {
                      const checked = form.examIds.includes(ex.id)
                      return (
                        <label
                          key={ex.id}
                          className={`flex cursor-pointer items-center gap-3 rounded-lg p-2.5 transition-colors ${
                            checked ? 'bg-rose-500/10' : 'hover:bg-muted/60'
                          }`}
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => toggleExam(ex.id)}
                          />
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-rose-500/10 text-rose-700 dark:text-rose-300">
                            <BookCheck className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">
                              {ex.title}
                            </div>
                            <div className="text-[10px] text-muted-foreground">
                              {examTypeLabel[ex.type]} · {ex.marks} marks ·{' '}
                              {ex.duration} min · pass {ex.passingPercentage}%
                            </div>
                          </div>
                          <span
                            className={`badge-status shrink-0 ${
                              ex.status === 'published'
                                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                                : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300'
                            }`}
                          >
                            {ex.status}
                          </span>
                        </label>
                      )
                    })}
                  </div>
                </ScrollArea>
              )}
            </TabsContent>

            {/* ─── Students tab ─── */}
            <TabsContent value="students" className="mt-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">
                    {mode === 'add' ? 'Pre-enroll Students' : 'Enrolled Students'}
                  </h4>
                  <p className="text-xs text-muted-foreground">
                    {mode === 'add'
                      ? 'Optionally enroll existing students into this level now. You can also add them later from the level detail page.'
                      : 'Tick = enrolled in this level. Untick = removed. Students already in other levels are managed from their level page.'}
                  </p>
                </div>
                <Badge variant="outline" className="chip-premium">
                  {form.studentIds.length} selected
                </Badge>
              </div>
              {availableStudents.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  No students available to enroll. All existing students are
                  already in other levels.
                </p>
              ) : (
                <ScrollArea className="max-h-[40vh] rounded-lg border border-border/50">
                  <div className="space-y-1 p-2">
                    {availableStudents.map((s) => {
                      const checked = form.studentIds.includes(s.id)
                      const inThisBatch =
                        mode === 'edit' &&
                        batch &&
                        s.batch === batch.name
                      return (
                        <label
                          key={s.id}
                          className={`flex cursor-pointer items-center gap-3 rounded-lg p-2.5 transition-colors ${
                            checked
                              ? 'bg-emerald-500/10'
                              : 'hover:bg-muted/60'
                          }`}
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => toggleStudent(s.id)}
                          />
                          <Avatar className="avatar-premium h-8 w-8">
                            {s.photo ? (
                              <AvatarImage src={s.photo} alt={s.name} />
                            ) : null}
                            <AvatarFallback
                              className={avatarColorClasses(s.avatarColor)}
                            >
                              {initials(s.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">
                              {s.name}
                            </div>
                            <div className="truncate text-[10px] text-muted-foreground">
                              {s.id} · {s.email}
                            </div>
                          </div>
                          {inThisBatch && (
                            <Badge
                              variant="outline"
                              className="shrink-0 border-emerald-500/30 bg-emerald-500/10 text-[10px] text-emerald-700 dark:text-emerald-300"
                            >
                              current
                            </Badge>
                          )}
                        </label>
                      )
                    })}
                  </div>
                </ScrollArea>
              )}
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <div className="mr-auto flex flex-wrap gap-1.5 text-[10px] text-muted-foreground">
              <span className="num-premium rounded-full bg-muted px-2 py-0.5">
                {form.chapterIds.length} chapters
              </span>
              <span className="num-premium rounded-full bg-muted px-2 py-0.5">
                {form.examIds.length} exams
              </span>
              <span className="num-premium rounded-full bg-muted px-2 py-0.5">
                {form.studentIds.length} students
              </span>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" className="btn-premium-primary">
              {mode === 'add' ? (
                <>
                  <Plus className="h-4 w-4" /> Create Level
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" /> Save Changes
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Batch detail full-page view (v3.39 — was a side Sheet, now renders inline
//  as a real page so all the important options have room to breathe and the
//  admin never has to deal with a cramped popup).
// ────────────────────────────────────────────────────────────────────────────

function BatchDetailSheet({
  batch,
  tab,
  onTabChange,
  onBack,
  pageTitle,
  batches,
  students,
  chapters,
  exams,
  results,
  certificates,
  activityLogs,
  stat,
  onEdit,
  onDelete,
  onAssignChapters,
  onRemoveChapter,
  onAssignExams,
  onRemoveExam,
  onAddStudents,
  onRemoveStudent,
  onMoveStudent,
  onBulkEmail,
  onBulkCert,
  logActivity,
  updateStudent,
}: {
  batch: Batch | null
  tab: string
  onTabChange: (t: string) => void
  onBack: () => void
  pageTitle: string
  batches: Batch[]
  students: Student[]
  chapters: Chapter[]
  exams: Exam[]
  results: Result[]
  certificates: Certificate[]
  activityLogs: ActivityLog[]
  stat?: BatchStat
  onEdit: (b: Batch) => void
  onDelete: (b: Batch) => void
  onAssignChapters: (batchId: string, chapterIds: string[]) => void
  onRemoveChapter: (batchId: string, chapterId: string) => void
  onAssignExams: (batchId: string, examIds: string[]) => void
  onRemoveExam: (batchId: string, examId: string) => void
  onAddStudents: (batchId: string, studentIds: string[]) => void
  onRemoveStudent: (batchId: string, studentId: string) => void
  onMoveStudent: (studentId: string, toBatchId: string) => void
  onBulkEmail: (b: Batch) => void
  onBulkCert: (b: Batch) => void
  logActivity: (log: {
    user: string
    role: 'admin' | 'student' | 'system'
    action: string
    target: string
    type: 'create' | 'update' | 'delete' | 'login' | 'submit' | 'system'
  }) => void
  updateStudent: (id: string, patch: Partial<Student>) => void
}) {
  const [studentSearch, setStudentSearch] = useState('')
  const [addStudentsOpen, setAddStudentsOpen] = useState(false)
  const [addStudentsSel, setAddStudentsSel] = useState<Set<string>>(new Set())
  const [assignChapSel, setAssignChapSel] = useState<Set<string>>(new Set())
  const [assignExamSel, setAssignExamSel] = useState<Set<string>>(new Set())

  if (!batch) return null

  const batchStudents = students.filter((s) => s.batch === batch.name)
  const batchStudentIds = batchStudents.map((s) => s.id)
  const batchResults = stat?.results ?? []
  const batchCerts = stat?.certificates ?? []

  const assignedChapters = batch.chapterIds
    .map((id) => chapters.find((c) => c.id === id))
    .filter((c): c is NonNullable<typeof c> => Boolean(c))
  const assignedExams = batch.examIds
    .map((id) => exams.find((e) => e.id === id))
    .filter((e): e is NonNullable<typeof e> => Boolean(e))

  const availableChapters = chapters.filter(
    (c) => !batch.chapterIds.includes(c.id)
  )
  const availableExams = exams.filter((e) => !batch.examIds.includes(e.id))
  const availableStudents = students.filter(
    (s) => s.batch !== batch.name && s.status !== 'suspended'
  )

  const filteredStudents = batchStudents.filter((s) => {
    const q = studentSearch.trim().toLowerCase()
    if (!q) return true
    return (
      s.name.toLowerCase().includes(q) ||
      s.email.toLowerCase().includes(q) ||
      s.id.toLowerCase().includes(q)
    )
  })

  // Leaderboard sorted by avg score desc
  const leaderboard = batchStudents
    .map((s) => ({
      student: s,
      avg: studentAvg(s.id, results),
      progress: studentProgress(s, results, chapters),
      examsTaken: results.filter((r) => r.studentId === s.id).length,
      certs: certificates.filter(
        (c) => c.studentId === s.id && c.status === 'issued'
      ).length,
    }))
    .sort((a, b) => b.avg - a.avg)

  // Recent activity for this batch
  const recentActivity = activityLogs
    .filter(
      (l) =>
        l.target === batch.name ||
        l.target === batch.code ||
        l.action.includes('batch')
    )
    .slice(0, 5)

  // Chapter progress across batch
  const chapterProgress = assignedChapters.map((c) => {
    const completed = batchStudents.filter((s) =>
      results.some(
        (r) =>
          r.studentId === s.id &&
          r.chapterName === c.name &&
          r.status === 'passed'
      )
    ).length
    return {
      chapter: c,
      completed,
      total: batchStudents.length,
      pct: batchStudents.length
        ? Math.round((completed / batchStudents.length) * 100)
        : 0,
    }
  })

  // Analytics dataset
  const studentScoreData = batchStudents
    .map((s) => ({
      name: initials(s.name),
      score: studentAvg(s.id, results),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)

  const passFail = [
    { name: 'Passed', value: stat?.passed ?? 0, color: '#10b981' },
    { name: 'Failed', value: stat?.failed ?? 0, color: '#f43f5e' },
  ]

  const confirmAddStudents = () => {
    onAddStudents(batch.id, Array.from(addStudentsSel))
    setAddStudentsSel(new Set())
    setAddStudentsOpen(false)
  }
  const confirmAssignChap = () => {
    onAssignChapters(batch.id, Array.from(assignChapSel))
    setAssignChapSel(new Set())
  }
  const confirmAssignExam = () => {
    onAssignExams(batch.id, Array.from(assignExamSel))
    setAssignExamSel(new Set())
  }

  return (
    <div className="space-y-4">
      {/* Back to list */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button
          variant="outline"
          size="sm"
          className="btn-premium-outline h-9"
          onClick={onBack}
        >
          <ChevronLeft className="h-4 w-4" /> Back to {pageTitle}
        </Button>
        <div className="text-xs text-muted-foreground">
          You are viewing a level detail page. Use the tabs below to manage
          students, chapters, exams, analytics and certificates.
        </div>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="drawer-header-premium p-5 pb-4">
          <div className="flex items-start gap-4">
            <div
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border ${
                batch.status === 'archived'
                  ? 'border-zinc-500/30 bg-zinc-500/10 text-zinc-600 dark:text-zinc-300'
                  : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
              }`}
            >
              <Layers className="h-7 w-7" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="flex flex-wrap items-center gap-2 text-lg font-semibold leading-tight">
                <span className="truncate font-bold">{batch.name}</span>
                <Badge
                  variant="outline"
                  className="chip-premium border-emerald-500/30 bg-emerald-500/10 font-mono text-[10px] text-emerald-700 dark:text-emerald-300"
                >
                  {batch.code}
                </Badge>
                <span className={`badge-status ${statusBadge[batch.status]}`}>
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${statusDot[batch.status]}`}
                  />
                  <span className="capitalize">{batch.status}</span>
                </span>
              </h2>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <CalendarRange className="h-3 w-3" />
                  {batch.academicYear}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {batch.startDate || '—'} → {batch.endDate || '—'}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {batchStudents.length}/{batch.maxStudents} students
                </span>
              </div>
              {batch.description && (
                <p className="mt-2 text-xs text-muted-foreground">
                  {batch.description}
                </p>
              )}
            </div>
          </div>
          {/* Quick actions */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            <Button
              size="sm"
              className="btn-premium-outline h-8"
              variant="outline"
              onClick={() => onEdit(batch)}
            >
              <Pencil className="h-3.5 w-3.5" /> Edit
            </Button>
            <Button
              size="sm"
              className="btn-premium-outline h-8"
              variant="outline"
              onClick={() => setAddStudentsOpen(true)}
            >
              <UserPlus className="h-3.5 w-3.5" /> Add Students
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="btn-premium-outline h-8"
              onClick={() => onTabChange('chapters')}
            >
              <BookOpen className="h-3.5 w-3.5" /> Assign Chapters
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="btn-premium-outline h-8"
              onClick={() => onTabChange('exams')}
            >
              <BookCheck className="h-3.5 w-3.5" /> Assign Exams
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="btn-premium-outline h-8"
              onClick={() => onBulkEmail(batch)}
            >
              <Mail className="h-3.5 w-3.5" /> Email
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="btn-premium-outline h-8"
              onClick={() => onBulkCert(batch)}
            >
              <Award className="h-3.5 w-3.5" /> Certs
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-8 text-destructive hover:text-destructive"
              onClick={() => onDelete(batch)}
            >
              <Trash2 className="h-3.5 w-3.5" /> Delete
            </Button>
          </div>
        </div>

        <Tabs
          value={tab}
          onValueChange={onTabChange}
          className="flex w-full flex-col"
        >
          <div className="border-b border-border/50 px-3">
            <TabsList className="h-auto justify-start gap-0 overflow-x-auto bg-transparent p-0">
              <TabsTrigger
                value="overview"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <LayoutDashboard className="h-3.5 w-3.5" /> Overview
              </TabsTrigger>
              <TabsTrigger
                value="students"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <Users className="h-3.5 w-3.5" /> Students
                <span className="ml-1 num-premium rounded-full bg-muted px-1.5 text-[10px]">
                  {batchStudents.length}
                </span>
              </TabsTrigger>
              <TabsTrigger
                value="chapters"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <BookOpen className="h-3.5 w-3.5" /> Chapters
                <span className="ml-1 num-premium rounded-full bg-muted px-1.5 text-[10px]">
                  {assignedChapters.length}
                </span>
              </TabsTrigger>
              <TabsTrigger
                value="exams"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <BookCheck className="h-3.5 w-3.5" /> Exams
                <span className="ml-1 num-premium rounded-full bg-muted px-1.5 text-[10px]">
                  {assignedExams.length}
                </span>
              </TabsTrigger>
              <TabsTrigger
                value="analytics"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <BarChart3 className="h-3.5 w-3.5" /> Analytics
              </TabsTrigger>
              <TabsTrigger
                value="leaderboard"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <Trophy className="h-3.5 w-3.5" /> Leaderboard
              </TabsTrigger>
              <TabsTrigger
                value="certificates"
                className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-emerald-500"
              >
                <Award className="h-3.5 w-3.5" /> Certificates
                <span className="ml-1 num-premium rounded-full bg-muted px-1.5 text-[10px]">
                  {batchCerts.length}
                </span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* ─── Overview tab ─── */}
          <TabsContent
            value="overview"
            className="m-0 flex-1 space-y-4 p-5"
          >
            {/* Info grid */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <InfoTile label="Level Code" value={batch.code} icon={Layers} />
              <InfoTile
                label="Academic Year"
                value={batch.academicYear}
                icon={CalendarRange}
              />
              <InfoTile
                label="Status"
                value={
                  <span className="capitalize">{batch.status}</span>
                }
                icon={PlayCircle}
              />
              <InfoTile
                label="Start Date"
                value={batch.startDate || '—'}
                icon={Calendar}
              />
              <InfoTile
                label="End Date"
                value={batch.endDate || '—'}
                icon={Calendar}
              />
              <InfoTile
                label="Max Students"
                value={String(batch.maxStudents)}
                icon={Users}
              />
              <InfoTile
                label="Created"
                value={batch.createdAt}
                icon={Clock}
              />
              <InfoTile
                label="Capacity Used"
                value={`${batchStudents.length}/${batch.maxStudents}`}
                icon={TrendingUp}
              />
              <InfoTile
                label="Pass Rate"
                value={`${
                  batchResults.length
                    ? Math.round(
                        ((stat?.passed ?? 0) / batchResults.length) * 100
                      )
                    : 0
                }%`}
                icon={CheckCircle2}
              />
            </div>

            {/* Mini stat cards */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <MiniStat
                icon={Users}
                label="Students"
                value={stat?.studentCount ?? 0}
                accent="emerald"
              />
              <MiniStat
                icon={BookOpen}
                label="Chapters"
                value={assignedChapters.length}
                accent="amber"
              />
              <MiniStat
                icon={BookCheck}
                label="Exams"
                value={assignedExams.length}
                accent="rose"
              />
              <MiniStat
                icon={TrendingUp}
                label="Avg Score"
                value={`${stat?.avgScore ?? 0}%`}
                accent="teal"
              />
            </div>

            {/* Notes */}
            {batch.notes && (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
                <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-300">
                  <Sparkles className="h-3.5 w-3.5" /> Admin notes
                </div>
                <p className="text-xs text-muted-foreground">{batch.notes}</p>
              </div>
            )}

            {/* Chapter progress across batch */}
            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Chapter Progress (across batch)
              </h4>
              {chapterProgress.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  No chapters assigned yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {chapterProgress.map(({ chapter, completed, total, pct }) => {
                    const Icon = getChapterIcon(chapter.icon)
                    return (
                      <div
                        key={chapter.id}
                        className="flex items-center gap-3 rounded-lg border border-border/50 p-2"
                      >
                        <Icon className="h-4 w-4 shrink-0 text-emerald-500" />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-xs font-medium">
                            {chapter.name}
                          </div>
                          <div className="progress-premium mt-1 h-1.5">
                            <div
                              className="progress-premium-fill"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                        <span className="num-premium shrink-0 text-xs font-semibold">
                          {completed}/{total}
                        </span>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Recent activity */}
            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Recent Activity
              </h4>
              {recentActivity.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  No recent activity for this batch.
                </p>
              ) : (
                <div className="space-y-2">
                  {recentActivity.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-start gap-2 rounded-lg border border-border/40 p-2 text-xs"
                    >
                      <Activity className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate">
                          <span className="font-semibold">{a.user}</span>{' '}
                          {a.action}{' '}
                          {a.target && (
                            <span className="text-muted-foreground">
                              → {a.target}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          {a.time}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* ─── Students tab ─── */}
          <TabsContent
            value="students"
            className="m-0 flex-1 space-y-3 p-5"
          >
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search students…"
                  className="input-premium h-9 pl-9"
                />
              </div>
              <Button
                size="sm"
                className="btn-premium-primary h-9"
                onClick={() => setAddStudentsOpen(true)}
              >
                <UserPlus className="h-4 w-4" /> Add Students
              </Button>
            </div>
            <div className="text-xs text-muted-foreground">
              <span className="num-premium font-semibold text-foreground">
                {filteredStudents.length}
              </span>{' '}
              of {batchStudents.length} students
            </div>
            {filteredStudents.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No students in this batch yet. Click “Add Students” to enroll.
              </p>
            ) : (
              <div className="overflow-hidden rounded-lg border border-border/50">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30">
                      <TableHead className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        Student
                      </TableHead>
                      <TableHead className="hidden sm:table-cell text-[11px] uppercase tracking-wide text-muted-foreground">
                        Status
                      </TableHead>
                      <TableHead className="hidden sm:table-cell text-[11px] uppercase tracking-wide text-muted-foreground">
                        Progress
                      </TableHead>
                      <TableHead className="hidden sm:table-cell text-[11px] uppercase tracking-wide text-muted-foreground">
                        Avg
                      </TableHead>
                      <TableHead className="text-right text-[11px] uppercase tracking-wide text-muted-foreground">
                        Actions
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((s) => {
                      const avg = studentAvg(s.id, results)
                      const prog = studentProgress(s, results, chapters)
                      const login = timeAgo(s.lastLogin)
                      return (
                        <TableRow
                          key={s.id}
                          className="border-border/40 hover:bg-muted/30"
                        >
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="avatar-premium h-8 w-8">
                                {s.photo ? (
                                  <AvatarImage src={s.photo} alt={s.name} />
                                ) : null}
                                <AvatarFallback
                                  className={avatarColorClasses(s.avatarColor)}
                                >
                                  {initials(s.name)}
                                </AvatarFallback>
                              </Avatar>
                              <div className="min-w-0">
                                <div className="truncate text-xs font-semibold">
                                  {s.name}
                                </div>
                                <div className="truncate text-[10px] text-muted-foreground">
                                  {s.id} · {login.rel}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <span
                              className={`badge-status ${
                                s.status === 'active'
                                  ? statusBadge.active
                                  : s.status === 'inactive'
                                  ? statusBadge.inactive
                                  : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                              }`}
                            >
                              <span
                                className={`h-1.5 w-1.5 rounded-full ${
                                  s.status === 'active'
                                    ? 'bg-emerald-500'
                                    : s.status === 'inactive'
                                    ? 'bg-amber-500'
                                    : 'bg-rose-500'
                                }`}
                              />
                              <span className="capitalize">{s.status}</span>
                            </span>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <div className="flex items-center gap-2">
                              <div className="progress-premium h-1.5 w-14">
                                <div
                                  className="progress-premium-fill"
                                  style={{ width: `${prog}%` }}
                                />
                              </div>
                              <span className="num-premium text-[10px] font-semibold">
                                {prog}%
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <span
                              className={`num-premium text-xs font-bold ${
                                avg >= 80
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : avg >= 60
                                  ? 'text-amber-600 dark:text-amber-400'
                                  : avg > 0
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : 'text-muted-foreground'
                              }`}
                            >
                              {avg}%
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Select
                                onValueChange={(toId) =>
                                  onMoveStudent(s.id, toId)
                                }
                              >
                                <SelectTrigger size="sm" className="h-7 w-[100px]">
                                  <span className="inline-flex items-center gap-1 text-[10px]">
                                    <Layers className="h-3 w-3" /> Move
                                  </span>
                                </SelectTrigger>
                                <SelectContent>
                                  {batches
                                    .filter(
                                      (b) =>
                                        b.id !== batch.id &&
                                        b.status !== 'archived'
                                    )
                                    .map((b) => (
                                      <SelectItem key={b.id} value={b.id}>
                                        {b.code}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <button
                                    onClick={() =>
                                      onRemoveStudent(batch.id, s.id)
                                    }
                                    aria-label="Remove from batch"
                                    className="icon-btn-premium"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                </TooltipTrigger>
                                <TooltipContent>Remove from batch</TooltipContent>
                              </Tooltip>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </TabsContent>

          {/* ─── Chapters tab ─── */}
          <TabsContent
            value="chapters"
            className="m-0 flex-1 space-y-3 p-5"
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-semibold">Assigned Chapters</h4>
                <p className="text-xs text-muted-foreground">
                  Inherited by every student in this batch.
                </p>
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    className="btn-premium-primary h-9"
                    disabled={availableChapters.length === 0}
                  >
                    <BookOpen className="h-4 w-4" /> Assign Chapters
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  className="w-80 p-0"
                  align="end"
                >
                  <div className="border-b border-border/50 p-3">
                    <div className="text-sm font-semibold">
                      Pick chapters to assign
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {availableChapters.length} available
                    </div>
                  </div>
                  <ScrollArea className="max-h-[280px]">
                    <div className="space-y-1 p-2">
                      {availableChapters.map((c) => {
                        const Icon = getChapterIcon(c.icon)
                        const checked = assignChapSel.has(c.id)
                        return (
                          <label
                            key={c.id}
                            className={`flex cursor-pointer items-center gap-2 rounded-lg p-2 transition-colors ${
                              checked
                                ? 'bg-emerald-500/10'
                                : 'hover:bg-muted/60'
                            }`}
                          >
                            <Checkbox
                              checked={checked}
                              onCheckedChange={() => {
                                setAssignChapSel((prev) => {
                                  const next = new Set(prev)
                                  if (next.has(c.id)) next.delete(c.id)
                                  else next.add(c.id)
                                  return next
                                })
                              }}
                            />
                            <Icon className="h-4 w-4 shrink-0 text-emerald-500" />
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-xs font-medium">
                                {c.name}
                              </div>
                              <div className="text-[10px] text-muted-foreground">
                                Order {c.order}
                              </div>
                            </div>
                          </label>
                        )
                      })}
                    </div>
                  </ScrollArea>
                  <div className="flex items-center justify-between gap-2 border-t border-border/50 p-3">
                    <span className="num-premium text-xs text-muted-foreground">
                      {assignChapSel.size} selected
                    </span>
                    <Button
                      size="sm"
                      className="btn-premium-primary h-8"
                      onClick={confirmAssignChap}
                      disabled={assignChapSel.size === 0}
                    >
                      Assign
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            {assignedChapters.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No chapters assigned. Click “Assign Chapters” to start.
              </p>
            ) : (
              <div className="space-y-2">
                {assignedChapters.map((c) => {
                  const Icon = getChapterIcon(c.icon)
                  const completed = batchStudents.filter((s) =>
                    results.some(
                      (r) =>
                        r.studentId === s.id &&
                        r.chapterName === c.name &&
                        r.status === 'passed'
                    )
                  ).length
                  const pct = batchStudents.length
                    ? Math.round((completed / batchStudents.length) * 100)
                    : 0
                  return (
                    <div
                      key={c.id}
                      className="flex items-center gap-3 rounded-lg border border-border/50 p-3"
                    >
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-sm font-semibold">
                            {c.name}
                          </span>
                          <Badge
                            variant="outline"
                            className="text-[10px]"
                          >
                            Order {c.order}
                          </Badge>
                        </div>
                        <div className="mt-1 flex items-center gap-2">
                          <div className="progress-premium h-1.5 flex-1">
                            <div
                              className="progress-premium-fill"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="num-premium shrink-0 text-[10px] text-muted-foreground">
                            {completed}/{batchStudents.length} done
                          </span>
                        </div>
                      </div>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            onClick={() => onRemoveChapter(batch.id, c.id)}
                            aria-label="Remove chapter"
                            className="icon-btn-premium"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>Remove from batch</TooltipContent>
                      </Tooltip>
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>

          {/* ─── Exams tab ─── */}
          <TabsContent
            value="exams"
            className="m-0 flex-1 space-y-3 p-5"
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-semibold">Assigned Exams</h4>
                <p className="text-xs text-muted-foreground">
                  Tracked at the batch level for notifications.
                </p>
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    className="btn-premium-primary h-9"
                    disabled={availableExams.length === 0}
                  >
                    <BookCheck className="h-4 w-4" /> Assign Exams
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  className="w-80 p-0"
                  align="end"
                >
                  <div className="border-b border-border/50 p-3">
                    <div className="text-sm font-semibold">
                      Pick exams to assign
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {availableExams.length} available
                    </div>
                  </div>
                  <ScrollArea className="max-h-[280px]">
                    <div className="space-y-1 p-2">
                      {availableExams.map((ex) => {
                        const checked = assignExamSel.has(ex.id)
                        return (
                          <label
                            key={ex.id}
                            className={`flex cursor-pointer items-center gap-2 rounded-lg p-2 transition-colors ${
                              checked
                                ? 'bg-rose-500/10'
                                : 'hover:bg-muted/60'
                            }`}
                          >
                            <Checkbox
                              checked={checked}
                              onCheckedChange={() => {
                                setAssignExamSel((prev) => {
                                  const next = new Set(prev)
                                  if (next.has(ex.id)) next.delete(ex.id)
                                  else next.add(ex.id)
                                  return next
                                })
                              }}
                            />
                            <BookCheck className="h-4 w-4 shrink-0 text-rose-500" />
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-xs font-medium">
                                {ex.title}
                              </div>
                              <div className="text-[10px] text-muted-foreground">
                                {examTypeLabel[ex.type]} · {ex.marks} marks
                              </div>
                            </div>
                          </label>
                        )
                      })}
                    </div>
                  </ScrollArea>
                  <div className="flex items-center justify-between gap-2 border-t border-border/50 p-3">
                    <span className="num-premium text-xs text-muted-foreground">
                      {assignExamSel.size} selected
                    </span>
                    <Button
                      size="sm"
                      className="btn-premium-primary h-8"
                      onClick={confirmAssignExam}
                      disabled={assignExamSel.size === 0}
                    >
                      Assign
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            {assignedExams.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No exams assigned. Click “Assign Exams” to start.
              </p>
            ) : (
              <div className="space-y-2">
                {assignedExams.map((ex) => (
                  <div
                    key={ex.id}
                    className="flex items-center gap-3 rounded-lg border border-border/50 p-3"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-rose-500/10 text-rose-700 dark:text-rose-300">
                      <BookCheck className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="truncate text-sm font-semibold">
                          {ex.title}
                        </span>
                        <span
                          className={`badge-status ${examTypeBadge[ex.type]}`}
                        >
                          {examTypeLabel[ex.type]}
                        </span>
                        <span
                          className={`badge-status ${
                            ex.status === 'published'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300'
                          }`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${
                              ex.status === 'published'
                                ? 'bg-emerald-500'
                                : 'bg-zinc-400'
                            }`}
                          />
                          {ex.status}
                        </span>
                      </div>
                      <div className="mt-1 text-[10px] text-muted-foreground">
                        {ex.marks} marks · {ex.duration} min ·{' '}
                        {ex.questionIds.length} questions · pass{' '}
                        {ex.passingPercentage}%
                      </div>
                    </div>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => onRemoveExam(batch.id, ex.id)}
                          aria-label="Remove exam"
                          className="icon-btn-premium"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>Remove from batch</TooltipContent>
                    </Tooltip>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* ─── Analytics tab ─── */}
          <TabsContent
            value="analytics"
            className="m-0 flex-1 space-y-4 p-5"
          >
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <MiniStat
                icon={TrendingUp}
                label="Avg Progress"
                value={`${stat?.avgProgress ?? 0}%`}
                accent="emerald"
              />
              <MiniStat
                icon={TrendingUp}
                label="Avg Score"
                value={`${stat?.avgScore ?? 0}%`}
                accent="teal"
              />
              <MiniStat
                icon={Star}
                label="Highest Score"
                value={`${stat?.highest ?? 0}%`}
                accent="amber"
              />
              <MiniStat
                icon={Flame}
                label="Lowest Score"
                value={`${stat?.lowest ?? 0}%`}
                accent="rose"
              />
              <MiniStat
                icon={CheckCircle2}
                label="Pass Rate"
                value={`${
                  batchResults.length
                    ? Math.round(
                        ((stat?.passed ?? 0) / batchResults.length) * 100
                      )
                    : 0
                }%`}
                accent="emerald"
              />
              <MiniStat
                icon={Award}
                label="Certificates"
                value={stat?.certsIssued ?? 0}
                accent="violet"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-border/50 p-3">
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Student Scores (top 8)
                </h4>
                {studentScoreData.length === 0 ? (
                  <p className="py-6 text-center text-xs text-muted-foreground">
                    No results yet.
                  </p>
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={studentScoreData}
                      margin={{ top: 5, right: 5, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        className="stroke-border"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="name"
                        tickLine={false}
                        axisLine={false}
                        className="text-[10px] text-muted-foreground"
                      />
                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        className="text-[10px] text-muted-foreground"
                        width={28}
                      />
                      <RTooltip
                        contentStyle={{
                          background: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Bar
                        dataKey="score"
                        fill="#10b981"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
              <div className="rounded-lg border border-border/50 p-3">
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Pass / Fail Distribution
                </h4>
                {(stat?.passed ?? 0) + (stat?.failed ?? 0) === 0 ? (
                  <p className="py-6 text-center text-xs text-muted-foreground">
                    No results yet.
                  </p>
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={passFail}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={70}
                        innerRadius={40}
                        label={(d) => `${d.value}`}
                      >
                        {passFail.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <RTooltip
                        contentStyle={{
                          background: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
          </TabsContent>

          {/* ─── Leaderboard tab ─── */}
          <TabsContent
            value="leaderboard"
            className="m-0 flex-1 space-y-2 p-5"
          >
            <h4 className="text-sm font-semibold">Batch Leaderboard</h4>
            <p className="text-xs text-muted-foreground">
              Ranked by average score across all attempts.
            </p>
            {leaderboard.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No students in this batch yet.
              </p>
            ) : (
              <div className="space-y-2">
                {leaderboard.map((row, i) => {
                  const tier = tierFor(row.avg)
                  const TierIcon = tier.icon
                  const medal =
                    i === 0
                      ? { icon: Crown, color: 'text-amber-500' }
                      : i === 1
                      ? { icon: Medal, color: 'text-zinc-400' }
                      : i === 2
                      ? { icon: Award, color: 'text-orange-500' }
                      : null
                  const MedalIcon = medal?.icon
                  return (
                    <div
                      key={row.student.id}
                      className={`flex items-center gap-3 rounded-lg border p-3 ${
                        i < 3
                          ? 'border-emerald-500/30 bg-emerald-500/5'
                          : 'border-border/50'
                      }`}
                    >
                      <div
                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                          i === 0
                            ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                            : i === 1
                            ? 'bg-zinc-400/15 text-zinc-700 dark:text-zinc-300'
                            : i === 2
                            ? 'bg-orange-500/15 text-orange-700 dark:text-orange-300'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {MedalIcon ? (
                          <MedalIcon
                            className={`h-4 w-4 ${medal?.color}`}
                          />
                        ) : (
                          <span className="num-premium">#{i + 1}</span>
                        )}
                      </div>
                      <Avatar className="avatar-premium h-9 w-9">
                        {row.student.photo ? (
                          <AvatarImage
                            src={row.student.photo}
                            alt={row.student.name}
                          />
                        ) : null}
                        <AvatarFallback
                          className={avatarColorClasses(
                            row.student.avatarColor
                          )}
                        >
                          {initials(row.student.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-sm font-semibold">
                            {row.student.name}
                          </span>
                          <span
                            className={`inline-flex items-center gap-0.5 text-[10px] font-semibold ${tier.className}`}
                          >
                            <TierIcon className="h-3 w-3" />
                            {tier.label}
                          </span>
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          {row.examsTaken} exam
                          {row.examsTaken === 1 ? '' : 's'} · {row.certs} cert
                          {row.certs === 1 ? '' : 's'} · {row.progress}% progress
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`num-premium text-base font-bold ${
                            row.avg >= 80
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : row.avg >= 60
                              ? 'text-amber-600 dark:text-amber-400'
                              : row.avg > 0
                              ? 'text-rose-600 dark:text-rose-400'
                              : 'text-muted-foreground'
                          }`}
                        >
                          {row.avg}%
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          avg score
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>

          {/* ─── Certificates tab ─── */}
          <TabsContent
            value="certificates"
            className="m-0 flex-1 space-y-2 p-5"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold">
                Certificates Earned by Batch Students
              </h4>
              <Button
                size="sm"
                variant="outline"
                className="btn-premium-outline h-8"
                onClick={() => onBulkCert(batch)}
              >
                <Award className="h-3.5 w-3.5" /> Generate missing
              </Button>
            </div>
            {batchCerts.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No certificates yet. Students earn certificates by passing
                chapter exams.
              </p>
            ) : (
              <div className="space-y-2">
                {batchCerts.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-3 rounded-lg border border-border/50 p-3"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-300">
                      <Award className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold">
                        {c.studentName}
                      </div>
                      <div className="truncate text-[10px] text-muted-foreground">
                        {c.chapterName} · {c.examTitle}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="num-premium text-sm font-bold text-emerald-600 dark:text-emerald-400">
                        {c.score}%
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {c.certificateNumber}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {c.issuedAt}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </Card>

      {/* v3.39 — Add-Students dialog (was previously declared but never
          rendered, so the "Add Students" button did nothing.  Now wired up
          so the detail page is fully functional.) */}
      <Dialog open={addStudentsOpen} onOpenChange={setAddStudentsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add students to {batch.name}</DialogTitle>
            <DialogDescription>
              Pick one or more students to enroll. They will immediately
              inherit the {batch.chapterIds.length} chapter
              {batch.chapterIds.length === 1 ? '' : 's'} assigned to this
              level.
            </DialogDescription>
          </DialogHeader>
          {availableStudents.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No students available. Every student is already in this or
              another level.
            </p>
          ) : (
            <ScrollArea className="max-h-[50vh]">
              <div className="space-y-1 p-1">
                {availableStudents.map((s) => {
                  const checked = addStudentsSel.has(s.id)
                  return (
                    <label
                      key={s.id}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg p-2.5 transition-colors ${
                        checked ? 'bg-emerald-500/10' : 'hover:bg-muted/60'
                      }`}
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={() => {
                          setAddStudentsSel((prev) => {
                            const next = new Set(prev)
                            if (next.has(s.id)) next.delete(s.id)
                            else next.add(s.id)
                            return next
                          })
                        }}
                      />
                      <Avatar className="avatar-premium h-8 w-8">
                        {s.photo ? (
                          <AvatarImage src={s.photo} alt={s.name} />
                        ) : null}
                        <AvatarFallback
                          className={avatarColorClasses(s.avatarColor)}
                        >
                          {initials(s.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium">
                          {s.name}
                        </div>
                        <div className="truncate text-[10px] text-muted-foreground">
                          {s.id} · {s.email}
                          {s.batch ? ` · currently in ${s.batch}` : ''}
                        </div>
                      </div>
                    </label>
                  )
                })}
              </div>
            </ScrollArea>
          )}
          <DialogFooter>
            <span className="num-premium mr-auto text-xs text-muted-foreground">
              {addStudentsSel.size} selected
            </span>
            <Button
              variant="outline"
              onClick={() => {
                setAddStudentsSel(new Set())
                setAddStudentsOpen(false)
              }}
            >
              Cancel
            </Button>
            <Button
              className="btn-premium-primary"
              disabled={addStudentsSel.size === 0}
              onClick={confirmAddStudents}
            >
              <UserPlus className="h-4 w-4" /> Add{' '}
              {addStudentsSel.size > 0 ? addStudentsSel.size : ''} Student
              {addStudentsSel.size === 1 ? '' : 's'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Tiny sub-components
// ────────────────────────────────────────────────────────────────────────────

function InfoTile({
  label,
  value,
  icon: Icon,
}: {
  label: string
  value: React.ReactNode
  icon: typeof Layers
}) {
  return (
    <div className="rounded-lg border border-border/50 bg-muted/20 p-2.5">
      <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <div className="mt-1 truncate text-sm font-semibold text-foreground">
        {value}
      </div>
    </div>
  )
}

function MiniStat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: typeof Layers
  label: string
  value: React.ReactNode
  accent: 'emerald' | 'amber' | 'rose' | 'teal' | 'violet'
}) {
  const accentClass: Record<typeof accent, string> = {
    emerald:
      'border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-300',
    amber:
      'border-amber-500/30 bg-amber-500/5 text-amber-700 dark:text-amber-300',
    rose: 'border-rose-500/30 bg-rose-500/5 text-rose-700 dark:text-rose-300',
    teal: 'border-teal-500/30 bg-teal-500/5 text-teal-700 dark:text-teal-300',
    violet:
      'border-violet-500/30 bg-violet-500/5 text-violet-700 dark:text-violet-300',
  }
  return (
    <div
      className={`rounded-lg border p-3 ${accentClass[accent]}`}
    >
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-wide opacity-80">
          {label}
        </span>
        <Icon className="h-3.5 w-3.5 opacity-80" />
      </div>
      <div className="num-premium mt-1 text-lg font-bold">{value}</div>
    </div>
  )
}
