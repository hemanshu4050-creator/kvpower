'use client'

import * as React from 'react'
import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Bell, BellRing, BellOff, Send, Plus, Search, Eye, Pencil, Copy,
  Trash2, RefreshCw, Clock, CheckCheck, CheckCircle2, AlertTriangle,
  CalendarClock, Users, User, UserPlus, Layers, Megaphone, BookOpen,
  BookCheck, Award, Wrench, MessageSquare, Info, FileText, Filter,
  ChevronDown, ChevronLeft, ChevronRight, X, Mail, Download,
  TrendingUp, Activity, Reply, type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Bar, BarChart, CartesianGrid, Cell, Pie, PieChart,
  ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis,
  Area, AreaChart, RadialBar, RadialBarChart, PolarAngleAxis,
} from 'recharts'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { MathInput, MessageBody } from '@/components/shared/math-input'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '@/components/ui/sheet'
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs'
import {
  Tooltip, TooltipContent, TooltipTrigger,
} from '@/components/ui/tooltip'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  useDataStore,
  type AppNotification,
  type NotificationCategory,
  type NotificationPriority,
  type NotificationStatus,
  type NotificationAudience,
  type Student,
  type Message,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { avatarColorClasses, initials } from './lib/helpers'
import { cn } from '@/lib/utils'

// ────────────────────────────────────────────────────────────────────────────
//  Category / Priority / Status / Audience metadata
// ────────────────────────────────────────────────────────────────────────────

interface CatMeta { icon: LucideIcon; label: string; bg: string; ring: string; dot: string }

const CATEGORY_META: Record<NotificationCategory, CatMeta> = {
  system: {
    icon: Info, label: 'System',
    bg: 'bg-zinc-500/15 text-zinc-600 dark:text-zinc-300',
    ring: 'ring-zinc-500/20', dot: 'bg-zinc-500',
  },
  chapter_assigned: {
    icon: BookOpen, label: 'Chapter Assigned',
    bg: 'bg-violet-500/15 text-violet-600 dark:text-violet-400',
    ring: 'ring-violet-500/20', dot: 'bg-violet-500',
  },
  exam_available: {
    icon: BookCheck, label: 'Exam Available',
    bg: 'bg-sky-500/15 text-sky-600 dark:text-sky-400',
    ring: 'ring-sky-500/20', dot: 'bg-sky-500',
  },
  exam_result: {
    icon: FileText, label: 'Exam Result',
    bg: 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
    ring: 'ring-amber-500/20', dot: 'bg-amber-500',
  },
  certificate: {
    icon: Award, label: 'Certificate',
    bg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400',
    ring: 'ring-emerald-500/20', dot: 'bg-emerald-500',
  },
  announcement: {
    icon: Megaphone, label: 'Announcement',
    bg: 'bg-teal-500/15 text-teal-600 dark:text-teal-400',
    ring: 'ring-teal-500/20', dot: 'bg-teal-500',
  },
  reminder: {
    icon: Clock, label: 'Reminder',
    bg: 'bg-orange-500/15 text-orange-600 dark:text-orange-400',
    ring: 'ring-orange-500/20', dot: 'bg-orange-500',
  },
  maintenance: {
    icon: Wrench, label: 'Maintenance',
    bg: 'bg-rose-500/15 text-rose-600 dark:text-rose-400',
    ring: 'ring-rose-500/20', dot: 'bg-rose-500',
  },
  message: {
    icon: MessageSquare, label: 'Personal Message',
    bg: 'bg-fuchsia-500/15 text-fuchsia-600 dark:text-fuchsia-400',
    ring: 'ring-fuchsia-500/20', dot: 'bg-fuchsia-500',
  },
  general: {
    icon: Bell, label: 'General Notice',
    bg: 'bg-primary/15 text-primary',
    ring: 'ring-primary/20', dot: 'bg-primary',
  },
}

const PRIORITY_META: Record<NotificationPriority, { label: string; badge: string; dot: string }> = {
  low:    { label: 'Low',    badge: 'border-zinc-500/30 bg-zinc-500/10 text-zinc-600 dark:text-zinc-300', dot: 'bg-zinc-400' },
  normal: { label: 'Normal', badge: 'border-sky-500/30 bg-sky-500/10 text-sky-600 dark:text-sky-400', dot: 'bg-sky-500' },
  high:   { label: 'High',   badge: 'border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400', dot: 'bg-amber-500' },
  urgent: { label: 'Urgent', badge: 'border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400', dot: 'bg-rose-500' },
}

const STATUS_META: Record<NotificationStatus, { label: string; badge: string; dot: string }> = {
  draft:     { label: 'Draft',     badge: 'border-zinc-500/30 bg-zinc-500/10 text-zinc-600 dark:text-zinc-300', dot: 'bg-zinc-400' },
  scheduled: { label: 'Scheduled', badge: 'border-violet-500/30 bg-violet-500/10 text-violet-600 dark:text-violet-400', dot: 'bg-violet-500' },
  sent:      { label: 'Sent',      badge: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400', dot: 'bg-emerald-500' },
  expired:   { label: 'Expired',   badge: 'border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400', dot: 'bg-rose-500' },
}

const AUDIENCE_META: Record<NotificationAudience, { label: string; icon: LucideIcon }> = {
  individual: { label: 'Individual', icon: User },
  multiple:   { label: 'Multiple Students', icon: Users },
  batch:      { label: 'Entire Batch', icon: Layers },
  all:        { label: 'All Students', icon: Megaphone },
}

const CHART_COLORS = ['#10b981', '#0ea5e9', '#f59e0b', '#8b5cf6', '#ef4444', '#14b8a6', '#f97316', '#ec4899', '#6366f1', '#84cc16']

// ────────────────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────────────────

/** Animated count-up number. */
function AnimatedNumber({ value, duration = 600 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(value * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, duration])
  return <span className="tabular-nums">{display}</span>
}

function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60_000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  if (d < 30) return `${d}d ago`
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

function formatDateTime(iso?: string): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true,
  })
}

function formatDateShort(iso?: string): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

/** Resolves the list of student IDs a notification was delivered to. */
function resolveRecipientIds(n: AppNotification, students: Student[]): string[] {
  if (n.audience === 'all') return students.map((s) => s.id)
  if (n.audience === 'batch') return students.filter((s) => s.batch === n.recipientBatch).map((s) => s.id)
  return n.recipientIds
}

/** Renders markdown-ish body text: **bold**, *italic*, line breaks. */
function renderBody(body: string): React.ReactNode {
  const lines = body.split('\n')
  return lines.map((line, i) => {
    // Split by **bold** and *italic* markers
    const parts: React.ReactNode[] = []
    let remaining = line
    let key = 0
    while (remaining.length) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/)
      const italicMatch = remaining.match(/\*(.+?)\*/)
      if (boldMatch && boldMatch.index !== undefined && (italicMatch?.index === undefined || boldMatch.index <= italicMatch.index)) {
        if (boldMatch.index > 0) parts.push(<span key={key++}>{remaining.slice(0, boldMatch.index)}</span>)
        parts.push(<strong key={key++} className="font-semibold text-foreground">{boldMatch[1]}</strong>)
        remaining = remaining.slice(boldMatch.index + boldMatch[0].length)
      } else if (italicMatch && italicMatch.index !== undefined) {
        if (italicMatch.index > 0) parts.push(<span key={key++}>{remaining.slice(0, italicMatch.index)}</span>)
        parts.push(<em key={key++} className="italic">{italicMatch[1]}</em>)
        remaining = remaining.slice(italicMatch.index + italicMatch[0].length)
      } else {
        parts.push(<span key={key++}>{remaining}</span>)
        remaining = ''
      }
    }
    return <p key={i} className={i > 0 ? 'mt-2' : ''}>{parts.length ? parts : '\u00A0'}</p>
  })
}

// ────────────────────────────────────────────────────────────────────────────
//  Form state
// ────────────────────────────────────────────────────────────────────────────

interface NotificationFormState {
  id?: string
  title: string
  description: string
  body: string
  category: NotificationCategory
  priority: NotificationPriority
  audience: NotificationAudience
  recipientIds: string[]
  recipientBatch: string
  scheduledAt: string
  expiresAt: string
  status: NotificationStatus
}

const emptyForm: NotificationFormState = {
  title: '',
  description: '',
  body: '',
  category: 'announcement',
  priority: 'normal',
  audience: 'all',
  recipientIds: [],
  recipientBatch: '',
  scheduledAt: '',
  expiresAt: '',
  status: 'sent',
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminNotifications() {
  const pageTitle = useNavLabel('notifications', 'Notifications Center')
  const {
    notifications, students, batches, activityLogs,
    messages, replyToStudent, markMessageRead, deleteMessageThread,
    addNotification, updateNotification, deleteNotification,
    duplicateNotification, sendNotification,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [tab, setTab] = useState<'all' | 'inbox' | 'sent' | 'scheduled' | 'drafts' | 'expired' | 'analytics'>('all')
  const [filterCategory, setFilterCategory] = useState<NotificationCategory | 'all'>('all')
  const [filterPriority, setFilterPriority] = useState<NotificationPriority | 'all'>('all')
  const [filterAudience, setFilterAudience] = useState<NotificationAudience | 'all'>('all')
  const [showFilters, setShowFilters] = useState(false)
  const [page, setPage] = useState(0)
  const PAGE_SIZE = 8

  const [formOpen, setFormOpen] = useState(false)
  const [formData, setFormData] = useState<NotificationFormState>(emptyForm)
  const [isEditing, setIsEditing] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<AppNotification | null>(null)
  const [detailTarget, setDetailTarget] = useState<AppNotification | null>(null)

  // ── Student inbox: messages sent BY students (not the auto-reply) ──
  // A message with direction='out' was sent FROM the student TO the teacher.
  // These are the replies + questions the admin needs to see in the Inbox tab.
  const inboxMessages = useMemo(() => {
    return messages
      .filter((m) => m.direction === 'out')
      .sort((a, b) => (a.time < b.time ? 1 : -1))
  }, [messages])

  // ── Derived stats ──
  const stats = useMemo(() => {
    const sent = notifications.filter((n) => n.status === 'sent')
    const scheduled = notifications.filter((n) => n.status === 'scheduled')
    const drafts = notifications.filter((n) => n.status === 'draft')
    const expired = notifications.filter((n) => n.status === 'expired')
    const today = new Date().toISOString().slice(0, 10)
    const todays = sent.filter((n) => (n.sentAt ?? '').slice(0, 10) === today)
    // Total read = sum of readBy lengths across sent notifications
    const totalRead = sent.reduce((acc, n) => acc + n.readBy.length, 0)
    const totalRecipients = sent.reduce((acc, n) => acc + resolveRecipientIds(n, students).length, 0)
    const unreadCount = Math.max(0, totalRecipients - totalRead)
    const readPct = totalRecipients > 0 ? Math.round((totalRead / totalRecipients) * 100) : 0
    return {
      total: notifications.length,
      sent: sent.length,
      scheduled: scheduled.length,
      drafts: drafts.length,
      expired: expired.length,
      todays: todays.length,
      totalRead,
      unreadCount,
      readPct,
      // v3.33 — student inbox: messages FROM students (direction='out',
      // from is the student name, not the teacher). These are replies +
      // new questions the admin needs to see.
      inboxTotal: inboxMessages.length,
      inboxUnread: inboxMessages.filter((m) => !m.read).length,
    }
  }, [notifications, students, inboxMessages])

  const [inboxReplyTo, setInboxReplyTo] = useState<string | null>(null)
  const [inboxReplyBody, setInboxReplyBody] = useState('')
  // v3.35 — delete confirmation dialog for Inbox items.
  const [inboxDeleteTarget, setInboxDeleteTarget] = useState<Message | null>(null)

  const handleInboxReply = (studentMessage: typeof messages[number]) => {
    if (!inboxReplyBody.trim()) {
      toast.error('Reply cannot be empty')
      return
    }
    replyToStudent({
      studentId: studentMessage.studentId,
      from: 'Prof. Kalpesh Vyas',
      to: studentMessage.from,
      subject: studentMessage.subject.startsWith('Re:') ? studentMessage.subject : `Re: ${studentMessage.subject}`,
      body: inboxReplyBody.trim(),
      preview: inboxReplyBody.trim().slice(0, 80),
      // v3.35 — link the reply to the original student message so the
      // Inbox can show the full thread (question + reply) under one card.
      replyToId: studentMessage.id,
    })
    // Mark the student's original message as read so the unread count drops.
    if (!studentMessage.read) markMessageRead(studentMessage.id)
    setInboxReplyTo(null)
    setInboxReplyBody('')
    toast.success('Reply sent to ' + studentMessage.from)
  }

  const handleMarkInboxRead = (id: string) => {
    markMessageRead(id)
  }

  // v3.35 — Delete the entire thread (student's original question + all
  // teacher replies). Removes it from BOTH the admin Inbox AND the
  // student's Messages page.
  const handleDeleteInboxThread = () => {
    if (!inboxDeleteTarget) return
    const studentName = inboxDeleteTarget.from
    deleteMessageThread(inboxDeleteTarget.id)
    setInboxDeleteTarget(null)
    toast.success(`Deleted conversation with ${studentName}`, {
      description: 'Removed from your Inbox and the student\'s Messages page.',
    })
  }

  // ── Filtered + paginated list ──
  const filtered = useMemo(() => {
    let list = notifications
    if (tab === 'sent') list = list.filter((n) => n.status === 'sent')
    else if (tab === 'scheduled') list = list.filter((n) => n.status === 'scheduled')
    else if (tab === 'drafts') list = list.filter((n) => n.status === 'draft')
    else if (tab === 'expired') list = list.filter((n) => n.status === 'expired')

    if (filterCategory !== 'all') list = list.filter((n) => n.category === filterCategory)
    if (filterPriority !== 'all') list = list.filter((n) => n.priority === filterPriority)
    if (filterAudience !== 'all') list = list.filter((n) => n.audience === filterAudience)

    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter((n) =>
        n.title.toLowerCase().includes(q) ||
        n.description.toLowerCase().includes(q) ||
        n.sender.toLowerCase().includes(q) ||
        n.body.toLowerCase().includes(q)
      )
    }

    return [...list].sort((a, b) =>
      new Date(b.sentAt ?? b.createdAt).getTime() - new Date(a.sentAt ?? a.createdAt).getTime()
    )
  }, [notifications, tab, filterCategory, filterPriority, filterAudience, search])

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)

  // Reset to page 0 whenever the active filter combination changes. Done during
  // render (not in an effect) to avoid cascading renders — the React-recommended
  // pattern for adjusting state based on props/state changes.
  const filterKey = `${tab}·${search}·${filterCategory}·${filterPriority}·${filterAudience}`
  const [prevFilterKey, setPrevFilterKey] = useState(filterKey)
  if (prevFilterKey !== filterKey) {
    setPrevFilterKey(filterKey)
    setPage(0)
  }

  // ── Form handlers ──
  const openCreate = () => {
    setFormData(emptyForm)
    setIsEditing(false)
    setFormOpen(true)
  }
  const openEdit = (n: AppNotification) => {
    setFormData({
      id: n.id,
      title: n.title,
      description: n.description,
      body: n.body,
      category: n.category,
      priority: n.priority,
      audience: n.audience,
      recipientIds: n.recipientIds,
      recipientBatch: n.recipientBatch ?? '',
      scheduledAt: n.scheduledAt ? n.scheduledAt.slice(0, 16) : '',
      expiresAt: n.expiresAt ? n.expiresAt.slice(0, 16) : '',
      status: n.status,
    })
    setIsEditing(true)
    setFormOpen(true)
  }
  const openDuplicate = (n: AppNotification) => {
    const copy = duplicateNotification(n.id)
    if (copy) {
      toast.success('Notification duplicated', { description: 'A draft copy has been created.' })
      openEdit(copy)
    }
  }

  const handleSave = () => {
    if (!formData.title.trim()) {
      toast.error('Title is required')
      return
    }
    if (!formData.description.trim()) {
      toast.error('Short description is required')
      return
    }
    if (formData.audience === 'individual' && formData.recipientIds.length !== 1) {
      toast.error('Select exactly one student for individual audience')
      return
    }
    if (formData.audience === 'multiple' && formData.recipientIds.length < 2) {
      toast.error('Select at least two students for multiple audience')
      return
    }
    if (formData.audience === 'batch' && !formData.recipientBatch) {
      toast.error('Select a batch for batch audience')
      return
    }

    const payload = {
      title: formData.title.trim(),
      description: formData.description.trim(),
      body: formData.body.trim() || formData.description.trim(),
      category: formData.category,
      priority: formData.priority,
      audience: formData.audience,
      recipientIds: formData.audience === 'individual' || formData.audience === 'multiple' ? formData.recipientIds : [],
      recipientBatch: formData.audience === 'batch' ? formData.recipientBatch : undefined,
      sender: 'Prof. Kalpesh Vyas',
      senderId: 'ADMIN001',
      scheduledAt: formData.status === 'scheduled' && formData.scheduledAt ? new Date(formData.scheduledAt).toISOString() : undefined,
      expiresAt: formData.expiresAt ? new Date(formData.expiresAt).toISOString() : undefined,
      links: [] as string[],
    }

    if (isEditing && formData.id) {
      updateNotification(formData.id, payload as Partial<AppNotification>)
      toast.success('Notification updated', { description: formData.title })
    } else {
      addNotification({ ...payload, status: formData.status })
      const verb = formData.status === 'scheduled' ? 'scheduled' : formData.status === 'draft' ? 'saved as draft' : 'sent'
      toast.success(`Notification ${verb}`, { description: formData.title })
    }
    setFormOpen(false)
  }

  const handleSendNow = (n: AppNotification) => {
    sendNotification(n.id)
    toast.success('Notification sent', { description: n.title })
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    deleteNotification(deleteTarget.id)
    toast.success('Notification deleted', { description: deleteTarget.title })
    setDeleteTarget(null)
  }

  const activeFilters = filterCategory !== 'all' || filterPriority !== 'all' || filterAudience !== 'all'
  const clearFilters = () => {
    setFilterCategory('all')
    setFilterPriority('all')
    setFilterAudience('all')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Create, schedule, send and track notifications across your portal."
        icon={<BellRing className="h-5 w-5" />}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setTab('analytics')} className="gap-2">
              <TrendingUp className="h-4 w-4" /> Analytics
            </Button>
            <Button size="sm" onClick={openCreate} className="gap-2">
              <Plus className="h-4 w-4" /> Create Notification
            </Button>
          </div>
        }
      />

      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard title="Total" value={<AnimatedNumber value={stats.total} />} icon={Bell} accent="emerald" subtitle="all notifications" delay={0} />
        <StatCard title="Unread" value={<AnimatedNumber value={stats.unreadCount} />} icon={BellOff} accent="rose" subtitle="across recipients" delay={0.05} />
        <StatCard title="Read" value={<AnimatedNumber value={stats.totalRead} />} icon={CheckCheck} accent="teal" subtitle={`${stats.readPct}% read rate`} delay={0.1} />
        <StatCard title="Today" value={<AnimatedNumber value={stats.todays} />} icon={Activity} accent="violet" subtitle="sent today" delay={0.15} />
        <StatCard title="Scheduled" value={<AnimatedNumber value={stats.scheduled} />} icon={CalendarClock} accent="amber" subtitle="upcoming" delay={0.2} />
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <TabsList className="flex w-full flex-wrap sm:w-auto">
            <TabsTrigger value="all" className="gap-1.5">All <Badge variant="secondary" className="text-[10px]">{notifications.length}</Badge></TabsTrigger>
            <TabsTrigger value="inbox" className="gap-1.5">
              Inbox
              {stats.inboxUnread > 0
                ? <Badge variant="destructive" className="text-[10px]">{stats.inboxUnread}</Badge>
                : <Badge variant="secondary" className="text-[10px]">{stats.inboxTotal}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="sent" className="gap-1.5">Sent <Badge variant="secondary" className="text-[10px]">{stats.sent}</Badge></TabsTrigger>
            <TabsTrigger value="scheduled" className="gap-1.5">Scheduled <Badge variant="secondary" className="text-[10px]">{stats.scheduled}</Badge></TabsTrigger>
            <TabsTrigger value="drafts" className="gap-1.5">Drafts <Badge variant="secondary" className="text-[10px]">{stats.drafts}</Badge></TabsTrigger>
            <TabsTrigger value="expired" className="gap-1.5">Expired <Badge variant="secondary" className="text-[10px]">{stats.expired}</Badge></TabsTrigger>
          </TabsList>
        </div>

        {/* ── Search + Filters (hidden on analytics + inbox tabs) ── */}
        {tab !== 'analytics' && tab !== 'inbox' && (
          <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by title, sender, or body..."
                className="pl-9"
              />
            </div>
            <Button
              variant={showFilters || activeFilters ? 'secondary' : 'outline'}
              size="sm"
              onClick={() => setShowFilters((v) => !v)}
              className="gap-2"
            >
              <Filter className="h-4 w-4" /> Filters
              {activeFilters && <span className="flex h-2 w-2 rounded-full bg-primary" />}
            </Button>
            {activeFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-1.5 text-muted-foreground">
                <X className="h-3.5 w-3.5" /> Clear
              </Button>
            )}
          </div>
        )}

        <AnimatePresence>
          {showFilters && tab !== 'analytics' && tab !== 'inbox' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <Card className="mt-2 grid grid-cols-1 gap-3 p-4 sm:grid-cols-3">
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Category</Label>
                  <Select value={filterCategory} onValueChange={(v) => setFilterCategory(v as NotificationCategory | 'all')}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {Object.entries(CATEGORY_META).map(([k, m]) => (
                        <SelectItem key={k} value={k}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Priority</Label>
                  <Select value={filterPriority} onValueChange={(v) => setFilterPriority(v as NotificationPriority | 'all')}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All priorities</SelectItem>
                      {Object.entries(PRIORITY_META).map(([k, m]) => (
                        <SelectItem key={k} value={k}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Audience</Label>
                  <Select value={filterAudience} onValueChange={(v) => setFilterAudience(v as NotificationAudience | 'all')}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All audiences</SelectItem>
                      {Object.entries(AUDIENCE_META).map(([k, m]) => (
                        <SelectItem key={k} value={k}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── List tab ── */}
        {tab !== 'analytics' && tab !== 'inbox' && (
          <TabsContent value={tab} className="mt-4">
            {paged.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="No notifications found"
                description={search || activeFilters ? 'Try adjusting your search or filters.' : 'Create your first notification to get started.'}
                action={<Button size="sm" onClick={openCreate} className="gap-2"><Plus className="h-4 w-4" /> Create Notification</Button>}
              />
            ) : (
              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {paged.map((n, idx) => (
                    <NotificationCard
                      key={n.id}
                      notification={n}
                      students={students}
                      index={idx}
                      onView={() => setDetailTarget(n)}
                      onEdit={() => openEdit(n)}
                      onDuplicate={() => openDuplicate(n)}
                      onSendNow={() => handleSendNow(n)}
                      onDelete={() => setDeleteTarget(n)}
                    />
                  ))}
                </AnimatePresence>

                {/* Pagination */}
                {pageCount > 1 && (
                  <div className="flex items-center justify-between pt-2">
                    <p className="text-xs text-muted-foreground">
                      Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
                    </p>
                    <div className="flex items-center gap-1">
                      <Button variant="outline" size="icon" className="h-8 w-8" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <span className="px-2 text-xs font-medium">{page + 1} / {pageCount}</span>
                      <Button variant="outline" size="icon" className="h-8 w-8" disabled={page >= pageCount - 1} onClick={() => setPage((p) => p + 1)}>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        )}

        {/* ── Analytics tab ── */}
        <TabsContent value="analytics" className="mt-4">
          <NotificationAnalytics
            notifications={notifications}
            students={students}
            activityLogs={activityLogs}
          />
        </TabsContent>

        {/* ── Inbox tab (v3.33) — student replies + questions ── */}
        <TabsContent value="inbox" className="mt-4">
          <StudentInbox
            messages={inboxMessages}
            allMessages={messages}
            students={students}
            replyToId={inboxReplyTo}
            replyBody={inboxReplyBody}
            onReplyBodyChange={setInboxReplyBody}
            onOpenReply={setInboxReplyTo}
            onCancelReply={() => { setInboxReplyTo(null); setInboxReplyBody('') }}
            onSendReply={handleInboxReply}
            onMarkRead={handleMarkInboxRead}
            onDeleteRequest={setInboxDeleteTarget}
          />
        </TabsContent>
      </Tabs>

      {/* ── Create / Edit Dialog ── */}
      <NotificationFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        formData={formData}
        setFormData={setFormData}
        isEditing={isEditing}
        students={students}
        batches={batches}
        onSave={handleSave}
      />

      {/* ── Detail Sheet ── */}
      <NotificationDetailSheet
        notification={detailTarget}
        onOpenChange={(open) => !open && setDetailTarget(null)}
        students={students}
        onEdit={(n) => { setDetailTarget(null); openEdit(n) }}
        onSendNow={(n) => { setDetailTarget(null); handleSendNow(n) }}
      />

      {/* ── Delete confirmation ── */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete notification?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove <strong>{deleteTarget?.title}</strong> and its read-tracking data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* v3.35 — Inbox thread delete confirmation */}
      <AlertDialog open={!!inboxDeleteTarget} onOpenChange={(open) => !open && setInboxDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this conversation?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove <strong>{inboxDeleteTarget?.from}</strong>'s question
              {inboxDeleteTarget?.subject ? ` (${inboxDeleteTarget.subject})` : ''} AND all your
              replies to it. The conversation will be deleted from <strong>both</strong> your Inbox
              and the student's Messages page. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteInboxThread}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete conversation
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Notification Card (timeline item)
// ────────────────────────────────────────────────────────────────────────────

interface NotificationCardProps {
  notification: AppNotification
  students: Student[]
  index: number
  onView: () => void
  onEdit: () => void
  onDuplicate: () => void
  onSendNow: () => void
  onDelete: () => void
}

function NotificationCard({ notification: n, students, index, onView, onEdit, onDuplicate, onSendNow, onDelete }: NotificationCardProps) {
  const catMeta = CATEGORY_META[n.category]
  const prioMeta = PRIORITY_META[n.priority]
  const statusMeta = STATUS_META[n.status]
  const audMeta = AUDIENCE_META[n.audience]
  const CatIcon = catMeta.icon
  const AudIcon = audMeta.icon

  const recipientIds = resolveRecipientIds(n, students)
  const readCount = n.readBy.length
  const totalRecipients = recipientIds.length
  const readPct = totalRecipients > 0 ? Math.round((readCount / totalRecipients) * 100) : 0

  const recipientLabel = n.audience === 'all'
    ? 'All Students'
    : n.audience === 'batch'
    ? n.recipientBatch ?? 'Batch'
    : totalRecipients === 1
    ? students.find((s) => s.id === n.recipientIds[0])?.name ?? '1 student'
    : `${totalRecipients} students`

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.25, delay: index * 0.03 }}
    >
      <Card className="group relative overflow-hidden rounded-xl p-0 transition-all hover:shadow-md">
        {/* Left accent stripe — category colour */}
        <div className={cn('absolute left-0 top-0 h-full w-1', catMeta.dot)} />
        <div className="flex gap-3 p-3 pl-4">
          {/* Icon */}
          <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ring-1', catMeta.bg, catMeta.ring)}>
            <CatIcon className="h-4 w-4" />
          </div>

          {/* Body */}
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-sm font-semibold leading-tight">{n.title}</h3>
                  <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', statusMeta.badge)}>
                    <span className={cn('h-1.5 w-1.5 rounded-full', statusMeta.dot)} />
                    {statusMeta.label}
                  </span>
                  <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', prioMeta.badge)}>
                    {prioMeta.label}
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-1">{n.description}</p>
              </div>
              {/* Quick actions */}
              <div className="flex shrink-0 items-center gap-0.5">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 opacity-60 transition-opacity group-hover:opacity-100">
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-44">
                    <DropdownMenuLabel className="text-[11px] text-muted-foreground">Actions</DropdownMenuLabel>
                    <DropdownMenuItem onClick={onView} className="gap-2 text-xs"><Eye className="h-3.5 w-3.5" /> View Details</DropdownMenuItem>
                    <DropdownMenuItem onClick={onEdit} className="gap-2 text-xs"><Pencil className="h-3.5 w-3.5" /> Edit</DropdownMenuItem>
                    <DropdownMenuItem onClick={onDuplicate} className="gap-2 text-xs"><Copy className="h-3.5 w-3.5" /> Duplicate</DropdownMenuItem>
                    {n.status !== 'sent' && (
                      <DropdownMenuItem onClick={onSendNow} className="gap-2 text-xs"><Send className="h-3.5 w-3.5" /> Send Now</DropdownMenuItem>
                    )}
                    {n.status === 'sent' && (
                      <DropdownMenuItem onClick={onDuplicate} className="gap-2 text-xs"><RefreshCw className="h-3.5 w-3.5" /> Send Again</DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={onDelete} className="gap-2 text-xs text-destructive focus:text-destructive">
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {/* Meta row */}
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <span className={cn('h-2 w-2 rounded-full', catMeta.dot)} />
                {catMeta.label}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <AudIcon className="h-3.5 w-3.5" />
                {recipientLabel}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <User className="h-3.5 w-3.5" />
                {n.sender}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />
                {n.status === 'scheduled' ? `Scheduled ${formatDateTime(n.scheduledAt)}` : relativeTime(n.sentAt ?? n.createdAt)}
              </span>
            </div>

            {/* Read tracking mini-bar (only for sent notifications) */}
            {n.status === 'sent' && totalRecipients > 0 && (
              <button onClick={onView} className="mt-3 w-full text-left">
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCheck className="h-3.5 w-3.5 text-emerald-500" />
                    {readCount} of {totalRecipients} read
                  </span>
                  <span className="font-medium text-foreground">{readPct}%</span>
                </div>
                <Progress value={readPct} className="mt-1 h-1.5" />
              </button>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Notification Form Dialog (Create / Edit)
// ────────────────────────────────────────────────────────────────────────────

interface FormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  formData: NotificationFormState
  setFormData: React.Dispatch<React.SetStateAction<NotificationFormState>>
  isEditing: boolean
  students: Student[]
  batches: { id: string; name: string }[]
  onSave: () => void
}

function NotificationFormDialog({ open, onOpenChange, formData, setFormData, isEditing, students, batches, onSave }: FormDialogProps) {
  const update = <K extends keyof NotificationFormState>(key: K, value: NotificationFormState[K]) =>
    setFormData((prev) => ({ ...prev, [key]: value }))

  const toggleStudent = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      recipientIds: prev.recipientIds.includes(id)
        ? prev.recipientIds.filter((x) => x !== id)
        : [...prev.recipientIds, id],
    }))
  }

  const [studentSearch, setStudentSearch] = useState('')
  const filteredStudents = useMemo(() => {
    const q = studentSearch.toLowerCase()
    return students.filter((s) => s.name.toLowerCase().includes(q) || s.batch.toLowerCase().includes(q))
  }, [students, studentSearch])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BellRing className="h-5 w-5 text-primary" />
            {isEditing ? 'Edit Notification' : 'Create Notification'}
          </DialogTitle>
          <DialogDescription>
            {isEditing ? 'Update the notification details below.' : 'Compose a new notification and choose who receives it.'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Title */}
          <div>
            <Label htmlFor="notif-title">Title <span className="text-destructive">*</span></Label>
            <Input
              id="notif-title"
              value={formData.title}
              onChange={(e) => update('title', e.target.value)}
              placeholder="e.g. Trigonometry Chapter Test — Schedule Released"
              className="mt-1"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="notif-desc">Short Description <span className="text-destructive">*</span></Label>
            <Input
              id="notif-desc"
              value={formData.description}
              onChange={(e) => update('description', e.target.value)}
              placeholder="One-line preview shown in the bell dropdown and list"
              className="mt-1"
            />
            <p className="mt-1 text-[11px] text-muted-foreground">Max ~100 characters. Shown as a preview in the notification list.</p>
          </div>

          {/* Body */}
          <div>
            <Label htmlFor="notif-body">Message Body</Label>
            <Textarea
              id="notif-body"
              value={formData.body}
              onChange={(e) => update('body', e.target.value)}
              placeholder="Write the full message. Use **bold** and *italic* for emphasis."
              className="mt-1 min-h-[120px]"
            />
            <p className="mt-1 text-[11px] text-muted-foreground">Supports **bold**, *italic* and line breaks. If left empty, the short description is used.</p>
          </div>

          {/* Category + Priority */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(v) => update('category', v as NotificationCategory)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_META).map(([k, m]) => (
                    <SelectItem key={k} value={k}>
                      <span className="inline-flex items-center gap-2">
                        <m.icon className="h-3.5 w-3.5" /> {m.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Priority</Label>
              <Select value={formData.priority} onValueChange={(v) => update('priority', v as NotificationPriority)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(PRIORITY_META).map(([k, m]) => (
                    <SelectItem key={k} value={k}>
                      <span className="inline-flex items-center gap-2">
                        <span className={cn('h-2 w-2 rounded-full', m.dot)} /> {m.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Audience */}
          <div>
            <Label>Recipients</Label>
            <div className="mt-1 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {Object.entries(AUDIENCE_META).map(([k, m]) => {
                const active = formData.audience === k as NotificationAudience
                const Icon = m.icon
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => update('audience', k as NotificationAudience)}
                    className={cn(
                      'flex flex-col items-center gap-1.5 rounded-lg border p-3 text-center transition-all',
                      active
                        ? 'border-primary bg-primary/5 ring-1 ring-primary'
                        : 'border-border hover:border-muted-foreground/40 hover:bg-muted/40'
                    )}
                  >
                    <Icon className={cn('h-4 w-4', active ? 'text-primary' : 'text-muted-foreground')} />
                    <span className="text-[11px] font-medium leading-tight">{m.label}</span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Recipient picker — individual / multiple */}
          {(formData.audience === 'individual' || formData.audience === 'multiple') && (
            <div className="rounded-lg border border-border p-3">
              <div className="mb-2 flex items-center justify-between">
                <Label className="text-xs font-medium">
                  Select {formData.audience === 'individual' ? 'one student' : 'students'}
                </Label>
                {formData.audience === 'multiple' && formData.recipientIds.length > 0 && (
                  <Button variant="ghost" size="sm" className="h-6 text-[11px]" onClick={() => update('recipientIds', [])}>
                    Clear ({formData.recipientIds.length})
                  </Button>
                )}
              </div>
              <div className="relative mb-2">
                <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search students..."
                  className="h-8 pl-8 text-xs"
                />
              </div>
              <ScrollArea className="h-44 rounded-md border border-border">
                <div className="divide-y divide-border">
                  {filteredStudents.map((s) => {
                    const checked = formData.recipientIds.includes(s.id)
                    return (
                      <label
                        key={s.id}
                        className={cn(
                          'flex cursor-pointer items-center gap-2.5 px-3 py-2 text-xs transition-colors hover:bg-muted/50',
                          checked && 'bg-primary/5'
                        )}
                      >
                        <Checkbox checked={checked} onCheckedChange={() => toggleStudent(s.id)} />
                        <Avatar className="h-6 w-6">
                          <AvatarFallback className={cn('text-[10px] font-semibold', avatarColorClasses(s.avatarColor))}>
                            {initials(s.name)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="flex-1 truncate font-medium">{s.name}</span>
                        <Badge variant="outline" className="text-[10px]">{s.batch}</Badge>
                      </label>
                    )
                  })}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Recipient picker — batch */}
          {formData.audience === 'batch' && (
            <div>
              <Label>Select Batch</Label>
              <Select value={formData.recipientBatch} onValueChange={(v) => update('recipientBatch', v)}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Choose a batch..." /></SelectTrigger>
                <SelectContent>
                  {batches.map((b) => (
                    <SelectItem key={b.id} value={b.name}>{b.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Schedule + Expiry + Status */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <Label>Delivery</Label>
              <Select value={formData.status} onValueChange={(v) => update('status', v as NotificationStatus)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sent">Send Now</SelectItem>
                  <SelectItem value="scheduled">Schedule</SelectItem>
                  <SelectItem value="draft">Save as Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.status === 'scheduled' && (
              <div>
                <Label htmlFor="notif-schedule">Schedule Date &amp; Time</Label>
                <Input
                  id="notif-schedule"
                  type="datetime-local"
                  value={formData.scheduledAt}
                  onChange={(e) => update('scheduledAt', e.target.value)}
                  className="mt-1"
                />
              </div>
            )}
            <div className={cn(formData.status !== 'scheduled' && 'sm:col-span-2')}>
              <Label htmlFor="notif-expiry">Expiry Date (optional)</Label>
              <Input
                id="notif-expiry"
                type="datetime-local"
                value={formData.expiresAt}
                onChange={(e) => update('expiresAt', e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onSave} className="gap-2">
            {formData.status === 'sent' && !isEditing ? <Send className="h-4 w-4" /> : null}
            {formData.status === 'scheduled' && !isEditing ? <CalendarClock className="h-4 w-4" /> : null}
            {isEditing ? 'Save Changes' : formData.status === 'scheduled' ? 'Schedule Notification' : formData.status === 'draft' ? 'Save Draft' : 'Send Notification'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Notification Detail Sheet (with read tracking)
// ────────────────────────────────────────────────────────────────────────────

interface DetailSheetProps {
  notification: AppNotification | null
  onOpenChange: (open: boolean) => void
  students: Student[]
  onEdit: (n: AppNotification) => void
  onSendNow: (n: AppNotification) => void
}

function NotificationDetailSheet({ notification: n, onOpenChange, students, onEdit, onSendNow }: DetailSheetProps) {
  const [readFilter, setReadFilter] = useState<'all' | 'read' | 'unread'>('all')

  if (!n) return null
  const catMeta = CATEGORY_META[n.category]
  const prioMeta = PRIORITY_META[n.priority]
  const statusMeta = STATUS_META[n.status]
  const audMeta = AUDIENCE_META[n.audience]
  const CatIcon = catMeta.icon

  const recipientIds = resolveRecipientIds(n, students)
  const recipients = students.filter((s) => recipientIds.includes(s.id))
  const readSet = new Set(n.readBy.map((r) => r.studentId))
  const readCount = n.readBy.length
  const totalRecipients = recipientIds.length
  const readPct = totalRecipients > 0 ? Math.round((readCount / totalRecipients) * 100) : 0

  const filteredRecipients = recipients.filter((s) => {
    if (readFilter === 'read') return readSet.has(s.id)
    if (readFilter === 'unread') return !readSet.has(s.id)
    return true
  })

  const getReadTime = (studentId: string) => n.readBy.find((r) => r.studentId === studentId)?.readAt

  return (
    <Sheet open={!!n} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col overflow-hidden sm:max-w-2xl">
        <SheetHeader className="border-b border-border pb-4">
          <div className="flex items-start gap-3">
            <div className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ring-1', catMeta.bg, catMeta.ring)}>
              <CatIcon className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <SheetTitle className="text-base leading-tight">{n.title}</SheetTitle>
              <SheetDescription className="mt-1 line-clamp-1">{n.description}</SheetDescription>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', statusMeta.badge)}>
                  <span className={cn('h-1.5 w-1.5 rounded-full', statusMeta.dot)} /> {statusMeta.label}
                </span>
                <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', prioMeta.badge)}>{prioMeta.label}</span>
                <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', catMeta.bg, catMeta.ring)}>{catMeta.label}</span>
              </div>
            </div>
          </div>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-5 p-4">
            {/* Meta grid */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Sender</p>
                <p className="mt-0.5 font-medium">{n.sender}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Recipients</p>
                <p className="mt-0.5 font-medium">
                  {n.audience === 'all' ? 'All Students' : n.audience === 'batch' ? n.recipientBatch : `${totalRecipients} student(s)`}
                </p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">{n.status === 'scheduled' ? 'Scheduled For' : 'Sent At'}</p>
                <p className="mt-0.5 font-medium">{formatDateTime(n.status === 'scheduled' ? n.scheduledAt : n.sentAt)}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Created</p>
                <p className="mt-0.5 font-medium">{formatDateTime(n.createdAt)}</p>
              </div>
              {n.expiresAt && (
                <div className="rounded-lg border border-border p-3">
                  <p className="text-muted-foreground">Expires</p>
                  <p className="mt-0.5 font-medium">{formatDateTime(n.expiresAt)}</p>
                </div>
              )}
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Audience Type</p>
                <p className="mt-0.5 font-medium">{audMeta.label}</p>
              </div>
            </div>

            {/* Body */}
            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Message</h4>
              <Card className="bg-muted/30 p-4">
                <div className="text-sm leading-relaxed text-foreground">
                  {renderBody(n.body)}
                </div>
              </Card>
            </div>

            {/* Read tracking */}
            {n.status === 'sent' && (
              <div>
                <div className="mb-3 flex items-center justify-between">
                  <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Read Tracking</h4>
                  <div className="flex items-center gap-1">
                    {(['all', 'read', 'unread'] as const).map((f) => (
                      <Button
                        key={f}
                        variant={readFilter === f ? 'secondary' : 'ghost'}
                        size="sm"
                        className="h-7 px-2 text-[11px] capitalize"
                        onClick={() => setReadFilter(f)}
                      >
                        {f}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Progress hero */}
                <Card className="mb-3 overflow-hidden">
                  <div className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs font-medium text-muted-foreground">Notification Read Status</p>
                        <p className="mt-1 text-2xl font-bold tabular-nums">{readPct}%</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground">
                        <p className="font-medium text-emerald-600 dark:text-emerald-400">{readCount} read</p>
                        <p className="mt-0.5 text-rose-600 dark:text-rose-400">{totalRecipients - readCount} pending</p>
                      </div>
                    </div>
                    <Progress value={readPct} className="mt-3 h-2" />
                  </div>
                </Card>

                {/* Recipient table */}
                <Card className="overflow-hidden">
                  <div className="max-h-72 overflow-y-auto scrollbar-thin">
                    <Table>
                      <TableHeader className="sticky top-0 bg-background">
                        <TableRow>
                          <TableHead className="text-xs">Student</TableHead>
                          <TableHead className="text-xs">Batch</TableHead>
                          <TableHead className="text-xs">Status</TableHead>
                          <TableHead className="text-xs">Read Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredRecipients.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={4} className="py-6 text-center text-xs text-muted-foreground">
                              No students match this filter.
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredRecipients.map((s) => {
                            const isRead = readSet.has(s.id)
                            const readAt = getReadTime(s.id)
                            return (
                              <TableRow key={s.id}>
                                <TableCell className="py-2">
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-6 w-6">
                                      <AvatarFallback className={cn('text-[10px] font-semibold', avatarColorClasses(s.avatarColor))}>
                                        {initials(s.name)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span className="text-xs font-medium">{s.name}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="py-2 text-xs text-muted-foreground">{s.batch}</TableCell>
                                <TableCell className="py-2">
                                  {isRead ? (
                                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                                      <CheckCircle2 className="h-3.5 w-3.5" /> Read
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-muted-foreground">
                                      <Clock className="h-3.5 w-3.5" /> Unread
                                    </span>
                                  )}
                                </TableCell>
                                <TableCell className="py-2 text-xs text-muted-foreground">
                                  {readAt ? formatDateTime(readAt) : '—'}
                                </TableCell>
                              </TableRow>
                            )
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Footer actions */}
        <div className="flex items-center gap-2 border-t border-border p-3">
          <Button variant="outline" size="sm" onClick={() => onEdit(n)} className="gap-2">
            <Pencil className="h-4 w-4" /> Edit
          </Button>
          {n.status !== 'sent' && (
            <Button variant="outline" size="sm" onClick={() => onSendNow(n)} className="gap-2">
              <Send className="h-4 w-4" /> Send Now
            </Button>
          )}
          <div className="flex-1" />
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>Close</Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Analytics
// ────────────────────────────────────────────────────────────────────────────

interface AnalyticsProps {
  notifications: AppNotification[]
  students: Student[]
  activityLogs: { id: string; user: string; action: string; target: string; time: string; timestamp: number; type: string; role: string }[]
}

function NotificationAnalytics({ notifications, students, activityLogs }: AnalyticsProps) {
  const sent = notifications.filter((n) => n.status === 'sent')

  // ── Read rate radial ──
  const totalRead = sent.reduce((a, n) => a + n.readBy.length, 0)
  const totalRecipients = sent.reduce((a, n) => a + resolveRecipientIds(n, students).length, 0)
  const readPct = totalRecipients > 0 ? Math.round((totalRead / totalRecipients) * 100) : 0

  // ── By category ──
  const byCategory = useMemo(() => {
    const counts: Record<string, number> = {}
    sent.forEach((n) => { counts[n.category] = (counts[n.category] ?? 0) + 1 })
    return Object.entries(counts).map(([k, v]) => ({
      name: CATEGORY_META[k as NotificationCategory]?.label ?? k,
      value: v,
      key: k,
    }))
  }, [sent])

  // ── By priority ──
  const byPriority = useMemo(() => {
    const counts: Record<string, number> = {}
    sent.forEach((n) => { counts[n.priority] = (counts[n.priority] ?? 0) + 1 })
    return (['urgent', 'high', 'normal', 'low'] as NotificationPriority[]).map((p) => ({
      name: PRIORITY_META[p].label,
      count: counts[p] ?? 0,
      fill: CHART_COLORS[['urgent', 'high', 'normal', 'low'].indexOf(p) % CHART_COLORS.length],
    }))
  }, [sent])

  // ── Last 6 months trend ──
  const monthlyTrend = useMemo(() => {
    const months: { label: string; sent: number; read: number }[] = []
    const now = new Date()
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const label = d.toLocaleString('en-IN', { month: 'short' })
      const monthStart = d.getTime()
      const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime()
      const monthSent = sent.filter((n) => {
        const t = new Date(n.sentAt ?? n.createdAt).getTime()
        return t >= monthStart && t < monthEnd
      })
      const monthRead = monthSent.reduce((a, n) => a + n.readBy.length, 0)
      months.push({ label, sent: monthSent.length, read: monthRead })
    }
    return months
  }, [sent])

  // ── Activity timeline (notification-related logs) ──
  const notifActivity = useMemo(() => {
    return activityLogs
      .filter((l) => l.action.includes('notification'))
      .slice(0, 12)
  }, [activityLogs])

  return (
    <div className="space-y-4">
      {/* Charts grid */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Read rate radial */}
        <Card className="p-4">
          <h3 className="text-sm font-semibold">Read Rate</h3>
          <p className="text-xs text-muted-foreground">Across all sent notifications</p>
          <div className="relative mx-auto mt-2 h-40 w-40">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart innerRadius="70%" outerRadius="100%" data={[{ value: readPct, fill: '#10b981' }]} startAngle={90} endAngle={-270}>
                <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                <RadialBar background dataKey="value" cornerRadius={20} />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold tabular-nums">{readPct}%</span>
              <span className="text-[10px] text-muted-foreground">read</span>
            </div>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-emerald-600 dark:text-emerald-400">{totalRead} read</span>
            <span className="text-rose-600 dark:text-rose-400">{totalRecipients - totalRead} unread</span>
          </div>
        </Card>

        {/* By category pie */}
        <Card className="p-4 lg:col-span-2">
          <h3 className="text-sm font-semibold">Notifications by Category</h3>
          <p className="text-xs text-muted-foreground">Distribution of sent notifications</p>
          {byCategory.length === 0 ? (
            <EmptyState icon={Bell} title="No data" description="No sent notifications yet." className="py-8" />
          ) : (
            <div className="mt-2 flex flex-col items-center gap-4 sm:flex-row">
              <div className="h-44 w-44 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={byCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2}>
                      {byCategory.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <RTooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid flex-1 grid-cols-2 gap-1.5">
                {byCategory.map((c, i) => (
                  <div key={c.key} className="flex items-center gap-2 text-xs">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                    <span className="flex-1 truncate text-muted-foreground">{c.name}</span>
                    <span className="font-medium tabular-nums">{c.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* Trend + priority */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Monthly trend */}
        <Card className="p-4 lg:col-span-2">
          <h3 className="text-sm font-semibold">Notifications Over Time</h3>
          <p className="text-xs text-muted-foreground">Sent vs read — last 6 months</p>
          <div className="mt-2 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyTrend}>
                <defs>
                  <linearGradient id="sentGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="readGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0 0)" className="dark:opacity-20" />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="oklch(0.55 0 0)" />
                <YAxis tick={{ fontSize: 11 }} stroke="oklch(0.55 0 0)" allowDecimals={false} />
                <RTooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="sent" stroke="#10b981" strokeWidth={2} fill="url(#sentGrad)" name="Sent" />
                <Area type="monotone" dataKey="read" stroke="#0ea5e9" strokeWidth={2} fill="url(#readGrad)" name="Read" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* By priority */}
        <Card className="p-4">
          <h3 className="text-sm font-semibold">By Priority</h3>
          <p className="text-xs text-muted-foreground">Sent notifications</p>
          <div className="mt-2 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byPriority} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0 0)" className="dark:opacity-20" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} stroke="oklch(0.55 0 0)" allowDecimals={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} stroke="oklch(0.55 0 0)" width={60} />
                <RTooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="count" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Activity timeline */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold">Notification Activity Timeline</h3>
        <p className="text-xs text-muted-foreground">Recent notification events</p>
        {notifActivity.length === 0 ? (
          <EmptyState icon={Activity} title="No activity yet" description="Notification events will appear here." className="py-8" />
        ) : (
          <ScrollArea className="mt-3 max-h-72">
            <div className="space-y-2">
              {notifActivity.map((log, i) => (
                <div key={log.id} className="flex items-start gap-3">
                  <div className="relative flex flex-col items-center">
                    <span className={cn(
                      'mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full',
                      log.type === 'create' ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                        : log.type === 'delete' ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                        : log.type === 'submit' ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                        : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                    )}>
                      {log.type === 'create' ? <Plus className="h-3.5 w-3.5" />
                        : log.type === 'delete' ? <Trash2 className="h-3.5 w-3.5" />
                        : log.type === 'submit' ? <Send className="h-3.5 w-3.5" />
                        : <Pencil className="h-3.5 w-3.5" />}
                    </span>
                    {i < notifActivity.length - 1 && <span className="mt-1 h-full w-px bg-border" />}
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="text-xs">
                      <span className="font-medium">{log.user}</span>{' '}
                      <span className="text-muted-foreground">{log.action}</span>{' '}
                      <span className="font-medium">{log.target}</span>
                    </p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground">{log.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </Card>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Student Inbox (v3.33.0)
//  Shows messages sent BY students (replies + new questions) so the admin
//  (Prof. Kalpesh Vyas) can see and reply to them directly from the
//  Notifications Center's "Inbox" tab.
//
//  In the data store, student-sent messages have `direction: 'out'` (the
//  student is the sender). The auto-reply from the teacher has
//  `direction: 'in'`. We filter to only 'out' messages here so the admin
//  sees exactly what each student wrote.
// ────────────────────────────────────────────────────────────────────────────

function StudentInbox({
  messages, allMessages, students, replyToId, replyBody, onReplyBodyChange,
  onOpenReply, onCancelReply, onSendReply, onMarkRead, onDeleteRequest,
}: {
  messages: Message[]
  allMessages: Message[]
  students: Student[]
  replyToId: string | null
  replyBody: string
  onReplyBodyChange: (v: string) => void
  onOpenReply: (id: string | null) => void
  onCancelReply: () => void
  onSendReply: (m: Message) => void
  onMarkRead: (id: string) => void
  onDeleteRequest: (m: Message) => void
}) {
  if (messages.length === 0) {
    return (
      <EmptyState
        icon={MessageSquare}
        title="No student messages yet"
        description="When a student replies to your message or asks a new question, it will appear here."
      />
    )
  }

  // v3.35 — For each student message, find all teacher replies linked to it.
  // A reply is linked if (a) replyToId === m.id (v3.35+ explicit link), or
  // (b) fallback: direction='in' for the same student with a matching subject
  // (covers replies sent before v3.35). Sorted oldest-first so the thread
  // reads top-to-bottom: question → reply → reply → …
  const findReplies = (studentMsg: Message): Message[] => {
    const baseSubject = studentMsg.subject.replace(/^Re:\s*/i, '').trim()
    return allMessages
      .filter((r) => {
        if (r.id === studentMsg.id) return false
        if (r.replyToId === studentMsg.id) return true
        return (
          r.direction === 'in' &&
          r.studentId === studentMsg.studentId &&
          r.subject.replace(/^Re:\s*/i, '').trim() === baseSubject
        )
      })
      .sort((a, b) => (a.time < b.time ? -1 : 1))
  }

  return (
    <div className="space-y-3">
      <Card className="bg-muted/30 p-3">
        <div className="flex items-start gap-2 text-xs text-muted-foreground">
          <MessageSquare className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            These are messages <strong>from students</strong> — their replies to your
            notifications and any new questions they ask via the Messages page. Your
            replies appear inline below each question. Click <strong>Reply</strong> to
            respond, or <strong>Delete</strong> to remove the whole conversation from
            both your Inbox and the student's Messages page.
          </p>
        </div>
      </Card>

      <AnimatePresence mode="popLayout">
        {messages.map((m, idx) => {
          const student = students.find((s) => s.id === m.studentId)
          const isUnread = !m.read
          const isReplying = replyToId === m.id
          const replies = findReplies(m)
          const hasReplies = replies.length > 0
          return (
            <motion.div
              key={m.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.25, delay: idx * 0.03 }}
            >
              <Card
                className={cn(
                  'relative overflow-hidden rounded-xl p-0',
                  isUnread && 'ring-1 ring-primary/30'
                )}
              >
                {/* Left accent stripe */}
                <div className="absolute left-0 top-0 h-full w-1 bg-fuchsia-500" />
                {isUnread && (
                  <div className="absolute right-3 top-3 flex h-2 w-2 rounded-full bg-primary">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                  </div>
                )}
                <div className="flex gap-4 p-4 pl-5">
                  {/* Avatar */}
                  <Avatar className="h-10 w-10 shrink-0">
                    <AvatarFallback
                      className={cn(
                        'text-xs font-semibold',
                        avatarColorClasses[student?.avatarColor || 'emerald'] || 'bg-primary/15 text-primary'
                      )}
                    >
                      {initials(m.from)}
                    </AvatarFallback>
                  </Avatar>

                  {/* Body */}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className={cn('text-sm leading-tight', isUnread ? 'font-semibold' : 'font-medium text-muted-foreground')}>
                        {m.from}
                      </h3>
                      <Badge variant="outline" className="gap-1 border-fuchsia-500/30 bg-fuchsia-500/5 text-fuchsia-700 dark:text-fuchsia-400">
                        <MessageSquare className="h-3 w-3" /> Student message
                      </Badge>
                      {hasReplies && (
                        <Badge variant="outline" className="gap-1 border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400">
                          <Reply className="h-3 w-3" /> {replies.length} {replies.length === 1 ? 'reply' : 'replies'}
                        </Badge>
                      )}
                      {student && (
                        <span className="text-[11px] text-muted-foreground">
                          {student.batch} · {student.email}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm font-medium">{m.subject}</p>
                    <div className="mt-2 rounded-lg border bg-muted/30 p-3">
                      <MessageBody body={m.body} />
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {m.time}
                      </span>
                      <span>from {m.from}</span>
                    </div>

                    {/* v3.35 — Threaded replies (teacher's sent replies to THIS question) */}
                    {hasReplies && (
                      <div className="mt-3 space-y-2 border-l-2 border-emerald-500/30 pl-3">
                        {replies.map((r) => (
                          <div key={r.id} className="rounded-lg border border-emerald-500/20 bg-emerald-500/[0.03] p-3">
                            <div className="mb-1 flex flex-wrap items-center gap-2">
                              <Badge variant="outline" className="gap-1 border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">
                                <Reply className="h-3 w-3" /> Your reply
                              </Badge>
                              <span className="text-[11px] text-muted-foreground">
                                <Clock className="mr-1 inline h-3 w-3" />
                                {r.time}
                              </span>
                            </div>
                            <div className="rounded border bg-background/60 p-2">
                              <MessageBody body={r.body} />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Reply box */}
                    {isReplying && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-3 space-y-2"
                      >
                        <MathInput
                          placeholder={`Reply to ${m.from}... (use $...$ for math, e.g. $2(x^2 - 4)$)`}
                          value={replyBody}
                          onChange={onReplyBodyChange}
                          rows={3}
                          autoFocus
                        />
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={onCancelReply}>Cancel</Button>
                          <Button size="sm" onClick={() => onSendReply(m)} className="gap-1.5">
                            <Send className="h-3.5 w-3.5" /> Send Reply
                          </Button>
                        </div>
                      </motion.div>
                    )}

                    {/* Actions */}
                    {!isReplying && (
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            onOpenReply(m.id)
                            if (isUnread) onMarkRead(m.id)
                          }}
                          className="gap-1.5"
                        >
                          <Reply className="h-3.5 w-3.5" /> {hasReplies ? 'Reply again' : 'Reply'}
                        </Button>
                        {isUnread && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onMarkRead(m.id)}
                            className="gap-1.5 text-muted-foreground"
                          >
                            <CheckCheck className="h-3.5 w-3.5" /> Mark as read
                          </Button>
                        )}
                        {/* v3.35 — Delete the entire thread */}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteRequest(m)}
                          className="gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Delete
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </motion.div>
          )
        })}
      </AnimatePresence>
    </div>
  )
}
