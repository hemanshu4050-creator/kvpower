'use client'

import { Fragment, useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity,
  Award,
  BarChart3,
  BookCheck,
  BookOpen,
  Brain,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Crown,
  Download,
  Eye,
  FileDown,
  Flame,
  GraduationCap,
  LineChart as LineChartIcon,
  Mail,
  MapPin,
  Medal,
  Monitor,
  Pencil,
  Phone,
  PieChart as PieChartIcon,
  RefreshCw,
  Save,
  Search,
  ShieldBan,
  Sparkles,
  Star,
  Target,
  TrendingDown,
  TrendingUp,
  Trophy,
  UserCheck,
  Users,
  X,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend as RLegend,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  useDataStore,
  type ActivityLog,
  type Certificate,
  type Chapter,
  type Result,
  type Student,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { avatarColorClasses, dotColor, initials } from './lib/helpers'
import { downloadStudentProgressPdf } from '@/lib/student-pdf'

// ────────────────────────────────────────────────────────────────────────────
//  Types & helpers
// ────────────────────────────────────────────────────────────────────────────

type ChapterStatus = 'completed' | 'progress' | 'assigned' | 'locked'
type SortOption = 'name' | 'recent' | 'score' | 'progress'

interface ChapterStat {
  progress: number
  bestScore: number
  attempts: number
  status: ChapterStatus
  timeSpent: number // minutes
  lastAttempt: string | null
}

interface StudentStat {
  avgScore: number
  examsCompleted: number
  certificates: number
  progress: number
  study: number
  practice: number
  tests: number
  certs: number
  health: number
  trend: number[]
  highestScore: number
  lowestScore: number
  passRate: number
  studyTime: number // minutes
  chapterStats: Record<string, ChapterStat>
  correct: number
  wrong: number
  unanswered: number
  avgResponseTime: number // seconds
}

const avatarColors = [
  'emerald', 'rose', 'amber', 'violet', 'sky', 'teal',
  'orange', 'fuchsia', 'cyan', 'lime', 'indigo', 'pink',
]

const chapterStatusStyles: Record<ChapterStatus, { dot: string; chip: string; label: string }> = {
  completed: {
    dot: 'bg-emerald-500',
    chip: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    label: 'Completed',
  },
  progress: {
    dot: 'bg-amber-500',
    chip: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    label: 'In progress',
  },
  assigned: {
    dot: 'bg-rose-500',
    chip: 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
    label: 'Not started',
  },
  locked: {
    dot: 'bg-zinc-400',
    chip: 'border-zinc-400/30 bg-zinc-400/10 text-zinc-600 dark:text-zinc-300',
    label: 'Locked',
  },
}

const statusBadge: Record<Student['status'], string> = {
  active:
    'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  inactive:
    'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  suspended:
    'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
}

/** Tier derived from average score. */
function tierFor(score: number): {
  label: 'Gold' | 'Silver' | 'Bronze' | 'Newcomer'
  stars: number
  icon: typeof Crown
  className: string
  glowClass: string
} {
  if (score >= 85)
    return { label: 'Gold', stars: 5, icon: Crown, className: 'text-amber-600 dark:text-amber-400', glowClass: 'tier-glow-gold' }
  if (score >= 70)
    return { label: 'Silver', stars: 4, icon: Medal, className: 'text-zinc-500 dark:text-zinc-300', glowClass: 'tier-glow-silver' }
  if (score >= 50)
    return { label: 'Bronze', stars: 3, icon: Award, className: 'text-orange-600 dark:text-orange-400', glowClass: 'tier-glow-bronze' }
  return { label: 'Newcomer', stars: 2, icon: Sparkles, className: 'text-emerald-600 dark:text-emerald-400', glowClass: 'tier-glow-new' }
}

/** Relative time formatter ("2 hours ago"). */
function timeAgo(iso: string | null): { rel: string; abs: string } {
  if (!iso) return { rel: 'Never', abs: '—' }
  const d = new Date(iso.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return { rel: iso, abs: iso }
  const diff = Date.now() - d.getTime()
  const abs = d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
  if (diff < 0) return { rel: 'Just now', abs }
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return { rel: 'Just now', abs }
  if (mins < 60) return { rel: `${mins} min ago`, abs }
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return { rel: `${hrs} hour${hrs === 1 ? '' : 's'} ago`, abs }
  const days = Math.floor(hrs / 24)
  if (days < 7) return { rel: `${days} day${days === 1 ? '' : 's'} ago`, abs }
  const weeks = Math.floor(days / 7)
  if (weeks < 5) return { rel: `${weeks} week${weeks === 1 ? '' : 's'} ago`, abs }
  const months = Math.floor(days / 30)
  return { rel: `${months} month${months === 1 ? '' : 's'} ago`, abs }
}

/** Number of days ago a date was (0 = today, null → Infinity). */
function daysAgo(iso: string | null): number | null {
  if (!iso) return null
  const d = new Date(iso.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return null
  return Math.floor((Date.now() - d.getTime()) / 86400000)
}

/** Deterministic hash from a string. */
function hashStr(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i)
    h |= 0
  }
  return Math.abs(h)
}

/** Deterministic pseudo device/browser/ip for a student. */
function pseudoDevice(studentId: string): { device: string; browser: string; ip: string; sessions: number } {
  const h = hashStr(studentId)
  const devices = ['Windows 11', 'macOS Sonoma', 'Linux Ubuntu', 'Android 14', 'iOS 17']
  const browsers = ['Chrome 121', 'Firefox 122', 'Safari 17', 'Edge 121']
  return {
    device: devices[h % devices.length],
    browser: browsers[(h >> 3) % browsers.length],
    ip: `103.${(h * 7) % 256}.${(h * 13) % 256}.${(h * 17) % 256}`,
    sessions: 1 + (h % 4),
  }
}

/** Deterministic weekly study minutes from student id. */
function pseudoWeeklyMinutes(studentId: string): { day: string; minutes: number }[] {
  const h = hashStr(studentId)
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  return days.map((day, i) => ({
    day,
    minutes: ((h * (i + 3)) % 95) + 8,
  }))
}

/** Deterministic daily study hours for a month (28 days). */
function pseudoDailyStudy(studentId: string): { day: string; hours: number }[] {
  const h = hashStr(studentId)
  return Array.from({ length: 28 }).map((_, i) => ({
    day: `${i + 1}`,
    hours: Number((((h * (i + 5)) % 50) / 10).toFixed(1)),
  }))
}

/** Deterministic monthly study hours. */
function pseudoMonthlyStudy(studentId: string): { month: string; hours: number }[] {
  const h = hashStr(studentId)
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
  return months.map((month, i) => ({
    month,
    hours: ((h * (i + 2)) % 60) + 8,
  }))
}

/** Compute login activity from activity logs for a student name. */
function studentLoginActivity(student: Student, activityLogs: ActivityLog[]) {
  const logs = activityLogs.filter(
    (l) => l.user === student.name && l.type === 'login'
  )
  const totalLogins = Math.max(logs.length, 1 + (hashStr(student.id) % 12))
  // Weekly distribution
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  const h = hashStr(student.id)
  const weekly = days.map((day, i) => ({
    day,
    logins: (h * (i + 2)) % 5,
  }))
  return { totalLogins, weekly, history: logs }
}

/** Tiny SVG sparkline. */
function Sparkline({ data, positive = true }: { data: number[]; positive?: boolean }) {
  const pts = data.length >= 2 ? data : [40, positive ? 70 : 50]
  const w = 44
  const h = 18
  const max = Math.max(...pts, 1)
  const min = Math.min(...pts, 0)
  const range = max - min || 1
  const step = w / (pts.length - 1)
  const coords = pts.map((p, i) => `${(i * step).toFixed(1)},${(h - ((p - min) / range) * h).toFixed(1)}`)
  const color = positive ? '#10b981' : '#f43f5e'
  return (
    <svg width={w} height={h} className="shrink-0" aria-hidden>
      <polyline
        points={coords.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx={w} cy={h - ((pts[pts.length - 1] - min) / range) * h} r={1.8} fill={color} />
    </svg>
  )
}

/** Circular health-score ring. */
function HealthRing({ value, size = 34 }: { value: number; size?: number }) {
  const stroke = 3
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const offset = c - (Math.min(100, Math.max(0, value)) / 100) * c
  const color =
    value >= 80 ? '#10b981' : value >= 60 ? '#f59e0b' : value >= 40 ? '#fb923c' : '#f43f5e'
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke} className="text-muted/40" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <span className="absolute text-[10px] font-bold tabular-nums" style={{ color }}>
        {value}
      </span>
    </div>
  )
}

/** Animated count-up number. */
function AnimatedNumber({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const from = display
    const dur = 600
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur)
      const eased = 1 - Math.pow(1 - t, 3)
      const v = from + (value - from) * eased
      setDisplay(decimals === 0 ? Math.round(v) : Number(v.toFixed(decimals)))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, decimals])
  return <span className="tabular-nums">{decimals === 0 ? display : display.toFixed(decimals)}</span>
}

/** Compute overall progress % for a student. */
function studentProgress(student: Student, chapters: Chapter[], results: Result[]): number {
  const assigned = student.assignedChapters.length
  if (!assigned) return 0
  const completed = student.assignedChapters.filter((chId) => {
    const ch = chapters.find((c) => c.id === chId)
    if (!ch) return false
    return results.some(
      (r) => r.studentId === student.id && r.chapterName === ch.name && r.status === 'passed'
    )
  }).length
  return Math.round((completed / assigned) * 100)
}

/** Compute average score % for a student. */
function studentAvg(student: Student, results: Result[]): number {
  const sResults = results.filter((r) => r.studentId === student.id)
  if (!sResults.length) return 0
  return Math.round(sResults.reduce((a, r) => a + r.percentage, 0) / sResults.length)
}

/** Per-chapter stat for a student. */
function chapterStatFor(
  student: Student,
  chapter: Chapter,
  results: Result[]
): ChapterStat {
  const sResults = results.filter(
    (r) => r.studentId === student.id && r.chapterName === chapter.name
  )
  if (!sResults.length) {
    return {
      progress: 0,
      bestScore: 0,
      attempts: 0,
      status: 'assigned',
      timeSpent: 0,
      lastAttempt: null,
    }
  }
  const bestScore = Math.max(...sResults.map((r) => r.percentage))
  const attempts = sResults.length
  const timeSpent = sResults.reduce((a, r) => a + r.timeTakenMinutes, 0)
  const hasPassed = sResults.some((r) => r.status === 'passed')
  const lastAttempt = sResults[sResults.length - 1].createdAt
  // progress = blend of best score + attempts ratio
  const progress = Math.min(100, Math.round(bestScore * 0.7 + Math.min(100, attempts * 25) * 0.3))
  return {
    progress,
    bestScore,
    attempts,
    status: hasPassed ? 'completed' : 'progress',
    timeSpent,
    lastAttempt,
  }
}

// ────────────────────────────────────────────────────────────────────────────
//  Chart tooltip styling — uses CSS variables so it works in dark mode
// ────────────────────────────────────────────────────────────────────────────

const chartTooltipStyle: React.CSSProperties = {
  background: 'var(--popover)',
  border: '1px solid var(--border)',
  borderRadius: '8px',
  fontSize: '12px',
  color: 'var(--popover-foreground)',
  boxShadow: '0 4px 12px -2px rgba(0,0,0,0.1)',
  padding: '6px 10px',
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminStudentReports() {
  const pageTitle = useNavLabel('student-reports', 'Student Reports & Analytics')
  const {
    students,
    chapters,
    exams,
    results,
    certificates,
    batches: batchRecords,
    activityLogs,
    notes,
    updateStudent,
    generateCertificate,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [batchFilter, setBatchFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [minScoreFilter, setMinScoreFilter] = useState<string>('all')
  const [progressFilter, setProgressFilter] = useState<string>('all')
  const [sortBy, setSortBy] = useState<SortOption>('name')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(8)
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const [viewing, setViewing] = useState<Student | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTab, setDrawerTab] = useState<string>('overview')
  const [lastSync, setLastSync] = useState(() => new Date())
  const [loading, setLoading] = useState(true)

  // Simulate a 300ms hydration / data load
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300)
    return () => clearTimeout(t)
  }, [])

  // ── Per-student derived stats ──
  const studentStats = useMemo(() => {
    const map: Record<string, StudentStat> = {}
    for (const s of students) {
      const sResults = results.filter((r) => r.studentId === s.id)
      const avg = sResults.length
        ? Math.round(sResults.reduce((a, r) => a + r.percentage, 0) / sResults.length)
        : 0
      const certs = certificates.filter((c) => c.studentId === s.id && c.status === 'issued').length
      const assigned = s.assignedChapters.length
      const completedChapters = s.assignedChapters.filter((chId) => {
        const ch = chapters.find((c) => c.id === chId)
        if (!ch) return false
        return sResults.some((r) => r.chapterName === ch.name && r.status === 'passed')
      }).length
      const attemptedChapters = s.assignedChapters.filter((chId) => {
        const ch = chapters.find((c) => c.id === chId)
        if (!ch) return false
        return sResults.some((r) => r.chapterName === ch.name)
      }).length
      const progress = assigned ? Math.round((completedChapters / assigned) * 100) : 0
      const study = assigned ? Math.round((attemptedChapters / assigned) * 100) : 0
      const practice = Math.min(100, sResults.length * 12)
      const tests = assigned ? Math.round((completedChapters / assigned) * 100) : 0
      const certsPct = assigned ? Math.round((certs / assigned) * 100) : 0
      const recencyBoost = s.lastLogin ? 8 : 0
      const health = Math.min(
        100,
        Math.round(progress * 0.35 + avg * 0.3 + tests * 0.15 + certsPct * 0.12) + recencyBoost
      )
      const trend = sResults.slice(-6).map((r) => r.percentage)
      const highestScore = sResults.length ? Math.max(...sResults.map((r) => r.percentage)) : 0
      const lowestScore = sResults.length ? Math.min(...sResults.map((r) => r.percentage)) : 0
      const passedCount = sResults.filter((r) => r.status === 'passed').length
      const passRate = sResults.length ? Math.round((passedCount / sResults.length) * 100) : 0
      const studyTime = sResults.reduce((a, r) => a + r.timeTakenMinutes, 0)

      // Per-chapter stats
      const chapterStats: Record<string, ChapterStat> = {}
      for (const chId of s.assignedChapters) {
        const ch = chapters.find((c) => c.id === chId)
        if (ch) chapterStats[chId] = chapterStatFor(s, ch, sResults)
      }

      // Question analysis from answers
      let correct = 0
      let wrong = 0
      let unanswered = 0
      let totalTime = 0
      let answerCount = 0
      for (const r of sResults) {
        for (const a of r.answers ?? []) {
          answerCount++
          if (a.selectedOption === null) unanswered++
          else if (a.isCorrect) correct++
          else wrong++
          totalTime += a.timeTakenSeconds || 0
        }
      }
      const avgResponseTime = answerCount ? Math.round(totalTime / answerCount) : 0

      map[s.id] = {
        avgScore: avg,
        examsCompleted: sResults.length,
        certificates: certs,
        progress,
        study,
        practice,
        tests,
        certs: certsPct,
        health,
        trend,
        highestScore,
        lowestScore,
        passRate,
        studyTime,
        chapterStats,
        correct,
        wrong,
        unanswered,
        avgResponseTime,
      }
    }
    return map
  }, [students, results, certificates, chapters])

  const batches = useMemo(
    () => Array.from(new Set(students.map((s) => s.batch))),
    [students]
  )

  // ── Aggregate KPIs ──
  const aggregate = useMemo(() => {
    const totalStudents = students.length
    const activeStudents = students.filter((s) => s.status === 'active').length
    const passedStudents = students.filter((s) =>
      results.some((r) => r.studentId === s.id && r.status === 'passed')
    ).length
    const failedStudents = students.filter((s) =>
      results.some((r) => r.studentId === s.id && r.status === 'failed')
    ).length
    const avgScore = results.length
      ? Math.round(results.reduce((a, r) => a + r.percentage, 0) / results.length)
      : 0
    const avgProgress = students.length
      ? Math.round(
          students.reduce((a, s) => a + (studentStats[s.id]?.progress ?? 0), 0) / students.length
        )
      : 0
    const totalCerts = certificates.filter((c) => c.status === 'issued').length
    const totalStudyHours = Math.round(
      results.reduce((a, r) => a + r.timeTakenMinutes, 0) / 60
    )
    const totalExamsTaken = results.length
    // Average login frequency — synthesize from activity logs + last-login recency
    const loginCounts = students.map((s) => {
      const logs = activityLogs.filter(
        (l) => l.user === s.name && l.type === 'login'
      ).length
      const recency = daysAgo(s.lastLogin)
      // Blend real logins with a recency-derived pseudo count so the metric is meaningful.
      const pseudo = recency === null ? 0 : Math.max(0, 30 - recency)
      return logs + Math.max(1, Math.round(pseudo / 4))
    })
    const avgLoginFrequency = students.length
      ? Math.round(loginCounts.reduce((a, b) => a + b, 0) / students.length)
      : 0

    return {
      totalStudents,
      activeStudents,
      passedStudents,
      failedStudents,
      avgScore,
      avgProgress,
      totalCerts,
      totalStudyHours,
      totalExamsTaken,
      avgLoginFrequency,
    }
  }, [students, results, certificates, activityLogs, studentStats])

  // ── Filter + sort ──
  const filtered = useMemo(() => {
    const list = students.filter((s) => {
      const q = search.trim().toLowerCase()
      if (
        q &&
        !s.name.toLowerCase().includes(q) &&
        !s.email.toLowerCase().includes(q) &&
        !s.id.toLowerCase().includes(q) &&
        !s.phone.toLowerCase().includes(q)
      )
        return false
      if (batchFilter !== 'all' && s.batch !== batchFilter) return false
      if (statusFilter !== 'all' && s.status !== statusFilter) return false
      const st = studentStats[s.id]
      const avg = st?.avgScore ?? 0
      if (minScoreFilter === '50' && avg < 50) return false
      if (minScoreFilter === '70' && avg < 70) return false
      if (minScoreFilter === '85' && avg < 85) return false
      const prog = st?.progress ?? 0
      if (progressFilter === '25' && prog < 25) return false
      if (progressFilter === '50' && prog < 50) return false
      if (progressFilter === '75' && prog < 75) return false
      return true
    })

    list.sort((a, b) => {
      const sa = studentStats[a.id]
      const sb = studentStats[b.id]
      switch (sortBy) {
        case 'recent': {
          const ta = a.lastLogin ? new Date(a.lastLogin.replace(' ', 'T')).getTime() : 0
          const tb = b.lastLogin ? new Date(b.lastLogin.replace(' ', 'T')).getTime() : 0
          return tb - ta
        }
        case 'score':
          return (sb?.avgScore ?? 0) - (sa?.avgScore ?? 0)
        case 'progress':
          return (sb?.progress ?? 0) - (sa?.progress ?? 0)
        case 'name':
        default:
          return a.name.localeCompare(b.name)
      }
    })
    return list
  }, [students, search, batchFilter, statusFilter, minScoreFilter, progressFilter, sortBy, studentStats])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const toggleRow = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  const togglePage = () => {
    const allOnPage = rows.length > 0 && rows.every((r) => selected.has(r.id))
    setSelected((prev) => {
      const next = new Set(prev)
      if (allOnPage) rows.forEach((r) => next.delete(r.id))
      else rows.forEach((r) => next.add(r.id))
      return next
    })
  }

  const clearFilters = () => {
    setSearch('')
    setBatchFilter('all')
    setStatusFilter('all')
    setMinScoreFilter('all')
    setProgressFilter('all')
    setSortBy('name')
    setPage(0)
  }

  const activeFilters =
    search ||
    batchFilter !== 'all' ||
    statusFilter !== 'all' ||
    minScoreFilter !== 'all' ||
    progressFilter !== 'all' ||
    sortBy !== 'name'

  // ── Handlers ──
  const openDrawer = (s: Student, tab = 'overview') => {
    setViewing(s)
    setDrawerTab(tab)
    setDrawerOpen(true)
  }
  const downloadPdf = (s: Student) => {
    const sResults = results.filter((r) => r.studentId === s.id)
    const sCerts = certificates.filter((c) => c.studentId === s.id)
    downloadStudentProgressPdf(s, chapters, sResults, sCerts)
    toast.success('PDF report generated', {
      description: `${s.name.replace(/\s+/g, '_')}_Progress_Report.pdf`,
    })
  }
  const sendEmail = (s: Student) => {
    toast.success('Email composer opened', { description: s.email })
  }
  const generateCert = (s: Student) => {
    const passedResults = results.filter(
      (r) => r.studentId === s.id && r.status === 'passed'
    )
    const existing = new Set(
      certificates
        .filter((c) => c.studentId === s.id)
        .map((c) => `${c.chapterName}__${c.examTitle}`)
    )
    const missing = passedResults.filter(
      (r) => !existing.has(`${r.chapterName}__${r.examTitle}`)
    )
    if (!missing.length) {
      toast.info('No new certificates to generate', {
        description: 'All passed exams already have a certificate.',
      })
      return
    }
    missing.forEach((r) => {
      generateCertificate(s.id, s.name, r.chapterName, r.examTitle, r.percentage)
    })
    toast.success(`${missing.length} certificate${missing.length === 1 ? '' : 's'} generated`, {
      description: `For ${s.name}`,
    })
  }

  // ── Loading skeleton ──
  if (loading) {
    return (
      <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
        <div className="h-8 w-64 animate-pulse rounded-lg bg-muted/50" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl bg-muted/40" />
          ))}
        </div>
        <div className="h-16 animate-pulse rounded-xl bg-muted/40" />
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-14 animate-pulse rounded-lg bg-muted/30" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      <PageHeader
        title={pageTitle}
        description="Deep-dive into every student's progress, performance, and engagement."
        icon={<BarChart3 className="h-5 w-5" />}
        actions={
          <>
            <Button
              variant="outline"
              className="btn-premium-outline h-9"
              onClick={() => {
                setLastSync(new Date())
                toast.success('Reports refreshed')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Sync</span>
            </Button>
            <Button
              variant="outline"
              className="btn-premium-outline h-9"
              onClick={() => {
                if (selected.size === 0) {
                  toast.info('Select students first', {
                    description: 'Tick the rows you want to export.',
                  })
                  return
                }
                toast.success(`Exported ${selected.size} reports`, {
                  description: 'PDFs generated in the background.',
                })
              }}
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* Last synced line */}
      <div className="-mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative inline-flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          All systems operational
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span>
          Last synced{' '}
          {lastSync.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
          })}
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{students.length} records</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{batches.length} batches</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{chapters.length} chapters</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{exams.length} exams</span>
      </div>

      {/* ────────────────────────────────────────────────────────────
          SECTION 1 — Dashboard KPI cards (5)
         ──────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          title="Total Students"
          value={<AnimatedNumber value={aggregate.totalStudents} />}
          icon={Users}
          accent="emerald"
          subtitle={`Across ${batchRecords.length} batches`}
          trend={{ value: '+3', positive: true }}
          delay={0}
        />
        <StatCard
          title="Active Students"
          value={<AnimatedNumber value={aggregate.activeStudents} />}
          icon={Flame}
          accent="teal"
          subtitle="Status: active"
          trend={{ value: '+2', positive: true }}
          delay={0.05}
        />
        <StatCard
          title="Students Passed"
          value={<AnimatedNumber value={aggregate.passedStudents} />}
          icon={CheckCircle2}
          accent="emerald"
          subtitle="≥1 passed exam"
          trend={{ value: '+1', positive: true }}
          delay={0.1}
        />
        <StatCard
          title="Students Failed"
          value={<AnimatedNumber value={aggregate.failedStudents} />}
          icon={XCircle}
          accent="rose"
          subtitle="≥1 failed exam"
          trend={{ value: '0', positive: false }}
          delay={0.15}
        />
        <StatCard
          title="Certificates Issued"
          value={<AnimatedNumber value={aggregate.totalCerts} />}
          icon={Award}
          accent="amber"
          subtitle="Total issued"
          trend={{ value: '+4', positive: true }}
          delay={0.3}
        />
      </div>

      {/* ────────────────────────────────────────────────────────────
          SECTION 2 — Sticky filter bar
         ──────────────────────────────────────────────────────────── */}
      <div className="sticky top-2 z-30">
        <div className="glass-filter-bar rounded-xl p-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                placeholder="Search by name, email, ID or phone…"
                className="input-premium h-9 pl-9"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={batchFilter}
                onValueChange={(v) => {
                  setBatchFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Batch" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All batches</SelectItem>
                  {batches.map((b) => (
                    <SelectItem key={b} value={b}>
                      {b}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={minScoreFilter}
                onValueChange={(v) => {
                  setMinScoreFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Min score" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any score</SelectItem>
                  <SelectItem value="50">≥ 50%</SelectItem>
                  <SelectItem value="70">≥ 70%</SelectItem>
                  <SelectItem value="85">≥ 85%</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={progressFilter}
                onValueChange={(v) => {
                  setProgressFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Progress" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any progress</SelectItem>
                  <SelectItem value="25">≥ 25%</SelectItem>
                  <SelectItem value="50">≥ 50%</SelectItem>
                  <SelectItem value="75">≥ 75%</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name (A→Z)</SelectItem>
                  <SelectItem value="recent">Recent login</SelectItem>
                  <SelectItem value="score">Score (high)</SelectItem>
                  <SelectItem value="progress">Progress (high)</SelectItem>
                </SelectContent>
              </Select>
              {activeFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  <X className="h-4 w-4" /> Clear
                </Button>
              )}
            </div>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>
              Showing{' '}
              <span className="num-premium font-semibold text-foreground">
                {filtered.length === 0 ? 0 : start + 1}–{end}
              </span>{' '}
              of{' '}
              <span className="num-premium font-semibold text-foreground">
                {filtered.length}
              </span>{' '}
              students
            </span>
            {selected.size > 0 && (
              <span className="num-premium text-primary">
                {selected.size} selected
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ────────────────────────────────────────────────────────────
          SECTION 2 — Student table
         ──────────────────────────────────────────────────────────── */}
      <Card className="card-premium rounded-xl p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={GraduationCap}
            title="No students match"
            description="Try adjusting the filters or clear them to see all students."
            action={
              <Button className="btn-premium-primary h-9" onClick={clearFilters}>
                <X className="h-4 w-4" /> Clear filters
              </Button>
            }
            className="py-20"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 bg-muted/30 hover:bg-muted/30 [&_th]:h-14">
                  <TableHead className="w-10 pl-5">
                    <Checkbox
                      checked={
                        rows.length > 0 && rows.every((r) => selected.has(r.id))
                      }
                      onCheckedChange={togglePage}
                      aria-label="Select page"
                    />
                  </TableHead>
                  <TableHead className="min-w-[220px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Student
                  </TableHead>
                  <TableHead className="hidden md:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Batch
                  </TableHead>
                  <TableHead className="min-w-[170px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Progress
                  </TableHead>
                  <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Avg Score
                  </TableHead>
                  <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Status
                  </TableHead>
                  <TableHead className="hidden lg:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Last Login
                  </TableHead>
                  <TableHead className="w-[190px] pr-5 text-right text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Quick Actions
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((s) => {
                  const st = studentStats[s.id]
                  const tier = tierFor(st?.avgScore ?? 0)
                  const TierIcon = tier.icon
                  const login = timeAgo(s.lastLogin)
                  const scoreColor =
                    (st?.avgScore ?? 0) >= 80
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : (st?.avgScore ?? 0) >= 60
                      ? 'text-amber-600 dark:text-amber-400'
                      : 'text-rose-600 dark:text-rose-400'
                  const isTop = (st?.avgScore ?? 0) >= 90 && s.status === 'active'
                  return (
                    <TableRow
                      key={s.id}
                      data-state={selected.has(s.id) ? 'selected' : undefined}
                      onClick={() => openDrawer(s)}
                      className="row-premium group cursor-pointer border-border/40 transition-all hover:shadow-sm [&_td]:py-6"
                    >
                      <TableCell className="pl-5" onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={selected.has(s.id)}
                          onCheckedChange={() => toggleRow(s.id)}
                          aria-label={`Select ${s.name}`}
                        />
                      </TableCell>
                      {/* Student identity */}
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <Avatar className="avatar-premium h-11 w-11">
                              {s.photo ? <AvatarImage src={s.photo} alt={s.name} /> : null}
                              <AvatarFallback className={avatarColorClasses(s.avatarColor)}>
                                {initials(s.name)}
                              </AvatarFallback>
                            </Avatar>
                            <span
                              className={`absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-background bg-background ${tier.className} ${tier.glowClass}`}
                              title={`${tier.label} student`}
                            >
                              <TierIcon className="h-3 w-3" />
                            </span>
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="truncate text-sm font-semibold text-foreground">
                                {s.name}
                              </span>
                              {isTop && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="inline-flex items-center rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-bold text-amber-600 dark:text-amber-400">
                                      <Star className="mr-0.5 h-2.5 w-2.5 fill-current" />
                                      Top
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent>Top performer</TooltipContent>
                                </Tooltip>
                              )}
                            </div>
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground num-premium">
                              <span>{s.id}</span>
                              <span className="text-muted-foreground/40">•</span>
                              <span className={`inline-flex items-center gap-0.5 font-semibold ${tier.className}`}>
                                <TierIcon className="h-2.5 w-2.5" />
                                {tier.label}
                              </span>
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      {/* Batch */}
                      <TableCell className="hidden md:table-cell">
                        <Badge variant="outline" className="font-medium">
                          {s.batch}
                        </Badge>
                      </TableCell>
                      {/* Progress */}
                      <TableCell>
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2">
                            <div className="progress-premium h-1.5 w-24">
                              <div
                                className="progress-premium-fill"
                                style={{ width: `${st?.progress ?? 0}%` }}
                              />
                            </div>
                            <span className="num-premium text-xs font-semibold">
                              {st?.progress ?? 0}%
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                            <StageMini label="S" value={st?.study ?? 0} />
                            <StageMini label="P" value={st?.practice ?? 0} />
                            <StageMini label="T" value={st?.tests ?? 0} />
                            <StageMini label="C" value={st?.certs ?? 0} />
                          </div>
                        </div>
                      </TableCell>
                      {/* Avg Score */}
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={`num-premium sparkline-glow text-sm font-bold ${scoreColor}`}>
                            {st?.avgScore ?? 0}%
                          </span>
                          <Sparkline data={st?.trend ?? []} positive={(st?.avgScore ?? 0) >= 60} />
                        </div>
                      </TableCell>
                      {/* Status */}
                      <TableCell>
                        <span className={`badge-status ${statusBadge[s.status]}`}>
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${dotColor(
                              s.status === 'active'
                                ? 'emerald'
                                : s.status === 'suspended'
                                ? 'rose'
                                : 'amber'
                            )}`}
                          />
                          <span className="capitalize">{s.status}</span>
                        </span>
                      </TableCell>
                      {/* Last Login */}
                      <TableCell className="hidden lg:table-cell">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="num-premium cursor-help text-xs font-medium text-muted-foreground">
                              {login.rel}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>{login.abs}</TooltipContent>
                        </Tooltip>
                      </TableCell>
                      {/* Quick Actions */}
                      <TableCell
                        className="pr-5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end gap-0.5 opacity-50 transition-all duration-200 group-hover:opacity-100">
                          <IconAction
                            icon={Eye}
                            label="View Report"
                            onClick={() => openDrawer(s, 'overview')}
                          />
                          <IconAction
                            icon={FileDown}
                            label="Download PDF"
                            onClick={() => downloadPdf(s)}
                          />
                          <IconAction
                            icon={BarChart3}
                            label="Analytics"
                            onClick={() => {
                              openDrawer(s, 'analytics')
                              toast.info('Analytics opened', { description: s.name })
                            }}
                          />
                          <IconAction
                            icon={Award}
                            label="Certificates"
                            onClick={() => {
                              openDrawer(s, 'certificates')
                              toast.info('Certificates opened', { description: s.name })
                            }}
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex flex-col items-center justify-between gap-3 border-t border-border/50 px-5 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="num-premium font-semibold text-foreground">
                  {start + 1}–{end}
                </span>{' '}
                of{' '}
                <span className="num-premium font-semibold text-foreground">
                  {filtered.length}
                </span>{' '}
                students
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => {
                  setRowsPerPage(Number(v))
                  setPage(0)
                }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[8, 12, 20].map((n) => (
                    <SelectItem key={n} value={String(n)}>
                      {n} / page
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="flex items-center gap-1 px-1">
                {Array.from({ length: Math.min(5, pageCount) }).map((_, i) => {
                  let p = i
                  if (pageCount > 5) {
                    p = Math.max(0, Math.min(pageCount - 5, currentPage - 2)) + i
                  }
                  return (
                    <button
                      key={p}
                      data-active={p === currentPage}
                      onClick={() => setPage(p)}
                      className="page-btn-premium num-premium flex h-7 w-7 items-center justify-center rounded-lg border border-border bg-background text-xs font-semibold text-muted-foreground hover:border-primary/30 hover:text-foreground"
                    >
                      {p + 1}
                    </button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage >= pageCount - 1}
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ────────────────────────────────────────────────────────────
          SECTION 3 — Individual Student Report (right Sheet drawer)
         ──────────────────────────────────────────────────────────── */}
      <StudentReportSheet
        open={drawerOpen}
        onOpenChange={(o) => {
          setDrawerOpen(o)
          if (!o) setViewing(null)
        }}
        activeTab={drawerTab}
        onTabChange={setDrawerTab}
        student={viewing}
        stat={viewing ? studentStats[viewing.id] : undefined}
        chapters={chapters}
        exams={exams}
        results={results}
        certificates={certificates}
        activityLogs={activityLogs}
        notes={notes}
        allStudents={students}
        allStudentStats={studentStats}
        batches={batchRecords}
        updateStudent={updateStudent}
        onDownloadPdf={downloadPdf}
        onSendEmail={sendEmail}
        onGenerateCert={generateCert}
      />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Small presentational helpers
// ────────────────────────────────────────────────────────────────────────────

function StageMini({ label, value }: { label: string; value: number }) {
  const color =
    value >= 75
      ? 'bg-emerald-500'
      : value >= 40
      ? 'bg-amber-500'
      : value > 0
      ? 'bg-rose-500'
      : 'bg-muted-foreground/30'
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span className="inline-flex items-center gap-0.5">
          <span className="text-[9px] font-bold text-muted-foreground">{label}</span>
          <span className="h-1.5 w-4 overflow-hidden rounded-full bg-muted">
            <span
              className={`block h-full rounded-full ${color}`}
              style={{ width: `${value}%` }}
            />
          </span>
          <span className="num-premium text-[9px] font-semibold text-muted-foreground">{value}</span>
        </span>
      </TooltipTrigger>
      <TooltipContent>
        {label === 'S' ? 'Study' : label === 'P' ? 'Practice' : label === 'T' ? 'Tests' : 'Certificates'}: {value}%
      </TooltipContent>
    </Tooltip>
  )
}

function IconAction({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Eye
  label: string
  onClick: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          aria-label={label}
          className="icon-btn-premium"
        >
          <Icon className="h-4 w-4" />
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

function InfoTile({
  icon: Icon,
  label,
  value,
  className,
}: {
  icon: typeof Mail
  label: string
  value: React.ReactNode
  className?: string
}) {
  return (
    <div className={`flex items-start gap-2 rounded-lg border border-border/60 bg-card/40 p-2.5 ${className ?? ''}`}>
      <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="num-premium truncate text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  )
}

function MiniStat({
  icon: Icon,
  label,
  value,
  accent = 'text-muted-foreground',
}: {
  icon: typeof Mail
  label: string
  value: React.ReactNode
  accent?: string
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-card/40 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        <Icon className={`h-3.5 w-3.5 ${accent}`} />
      </div>
      <p className="num-premium mt-1.5 text-xl font-bold text-foreground">{value}</p>
    </div>
  )
}

function ChartCard({
  title,
  subtitle,
  children,
  className,
  action,
}: {
  title: string
  subtitle?: string
  children: React.ReactNode
  className?: string
  action?: React.ReactNode
}) {
  return (
    <div className={`card-premium rounded-xl p-4 ${className ?? ''}`}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            {title}
          </p>
          {subtitle && (
            <p className="mt-0.5 text-[11px] text-muted-foreground/70">{subtitle}</p>
          )}
        </div>
        {action}
      </div>
      {children}
    </div>
  )
}

function EmptyHint({
  icon: Icon,
  message,
}: {
  icon: typeof BookOpen
  message: string
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border/60 py-8 text-center">
      <Icon className="h-6 w-6 text-muted-foreground/50" />
      <p className="text-xs text-muted-foreground">{message}</p>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Student Report Sheet (right-side drawer with 6 tabs / 14 sections)
// ────────────────────────────────────────────────────────────────────────────

interface StudentReportSheetProps {
  open: boolean
  onOpenChange: (o: boolean) => void
  activeTab: string
  onTabChange: (t: string) => void
  student: Student | null
  stat?: StudentStat
  chapters: Chapter[]
  exams: { id: string; title: string; chapterName: string; type: string; marks: number; duration: number }[]
  results: Result[]
  certificates: Certificate[]
  activityLogs: ActivityLog[]
  notes: { id: string; studentId: string; title: string; content: string; updatedAt: string }[]
  allStudents: Student[]
  allStudentStats: Record<string, StudentStat>
  batches: { id: string; name: string }[]
  updateStudent: (id: string, patch: Partial<Student>) => void
  onDownloadPdf: (s: Student) => void
  onSendEmail: (s: Student) => void
  onGenerateCert: (s: Student) => void
}

function StudentReportSheet({
  open,
  onOpenChange,
  activeTab,
  onTabChange,
  student,
  stat,
  chapters,
  exams,
  results,
  certificates,
  activityLogs,
  notes,
  allStudents,
  allStudentStats,
  batches,
  updateStudent,
  onDownloadPdf,
  onSendEmail,
  onGenerateCert,
}: StudentReportSheetProps) {
  const [noteDraft, setNoteDraft] = useState('')
  const [savingNote, setSavingNote] = useState(false)
  const [prevStudentId, setPrevStudentId] = useState<string | undefined>(undefined)

  // Adjust note draft when the active student changes (render-phase update,
  // per React's "you might not need an effect" guidance).
  if (student && student.id !== prevStudentId) {
    setPrevStudentId(student.id)
    setNoteDraft(student.notes ?? '')
  }

  if (!student) return null

  const tier = tierFor(stat?.avgScore ?? 0)
  const TierIcon = tier.icon
  const sResults = results
    .filter((r) => r.studentId === student.id)
    .slice()
    .sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1))
  const sCerts = certificates.filter((c) => c.studentId === student.id)
  const sNotes = notes.filter((n) => n.studentId === student.id)
  const assignedChapters = student.assignedChapters
    .map((id) => chapters.find((c) => c.id === id))
    .filter((c): c is NonNullable<typeof c> => Boolean(c))
  const login = timeAgo(student.lastLogin)
  const loginActivity = studentLoginActivity(student, activityLogs)
  const device = pseudoDevice(student.id)
  const weeklyMinutes = pseudoWeeklyMinutes(student.id)
  const dailyStudy = pseudoDailyStudy(student.id)
  const monthlyStudy = pseudoMonthlyStudy(student.id)

  // Ranking
  const ranked = allStudents
    .map((s) => ({ s, avg: allStudentStats[s.id]?.avgScore ?? 0 }))
    .sort((a, b) => b.avg - a.avg)
  const overallRank = ranked.findIndex((r) => r.s.id === student.id) + 1
  const batchStudents = allStudents.filter((s) => s.batch === student.batch)
  const batchRanked = batchStudents
    .map((s) => ({ s, avg: allStudentStats[s.id]?.avgScore ?? 0 }))
    .sort((a, b) => b.avg - a.avg)
  const batchRank = batchRanked.findIndex((r) => r.s.id === student.id) + 1

  // ── Insights ──
  const chapterStats = assignedChapters.map((ch) => ({
    chapter: ch,
    stat: stat?.chapterStats[ch.id] ?? chapterStatFor(student, ch, sResults),
  }))
  const strongest = chapterStats
    .filter((c) => c.stat.attempts > 0)
    .sort((a, b) => b.stat.bestScore - a.stat.bestScore)[0]
  const weakest = chapterStats
    .filter((c) => c.stat.attempts > 0)
    .sort((a, b) => a.stat.bestScore - b.stat.bestScore)[0]
  const mostTime = chapterStats
    .filter((c) => c.stat.timeSpent > 0)
    .sort((a, b) => b.stat.timeSpent - a.stat.timeSpent)[0]
  const fastest = chapterStats
    .filter((c) => c.stat.status === 'completed')
    .sort((a, b) => (a.stat.timeSpent || 9999) - (b.stat.timeSpent || 9999))[0]

  const overallStatus: { label: string; tone: 'emerald' | 'amber' | 'rose' } =
    (stat?.avgScore ?? 0) >= 75 && (stat?.progress ?? 0) >= 60
      ? { label: 'On Track', tone: 'emerald' }
      : (stat?.avgScore ?? 0) >= 50
      ? { label: 'Needs Attention', tone: 'amber' }
      : { label: 'At Risk', tone: 'rose' }

  // ── Chart data ──
  const chapterProgressData = chapterStats.map((c) => ({
    name: c.chapter.name.length > 12 ? c.chapter.name.slice(0, 12) + '…' : c.chapter.name,
    progress: c.stat.progress,
    score: c.stat.bestScore,
  }))
  const completionDonut = [
    { name: 'Completed', value: chapterStats.filter((c) => c.stat.status === 'completed').length, color: '#10b981' },
    { name: 'In progress', value: chapterStats.filter((c) => c.stat.status === 'progress').length, color: '#f59e0b' },
    { name: 'Not started', value: chapterStats.filter((c) => c.stat.status === 'assigned').length, color: '#f43f5e' },
  ]
  const monthlyData = (() => {
    const map: Record<string, { month: string; sum: number; n: number }> = {}
    for (const r of sResults) {
      const m = (r.createdAt || '').slice(0, 7)
      if (!m) continue
      if (!map[m]) map[m] = { month: m, sum: 0, n: 0 }
      map[m].sum += r.percentage
      map[m].n++
    }
    return Object.values(map)
      .sort((a, b) => (a.month < b.month ? -1 : 1))
      .map((m) => ({
        month: new Date(m.month + '-01').toLocaleDateString('en-US', { month: 'short' }),
        avgScore: m.n ? Math.round(m.sum / m.n) : 0,
      }))
  })()
  const studyTimeByChapter = chapterStats
    .filter((c) => c.stat.timeSpent > 0)
    .map((c) => ({
      name: c.chapter.name.length > 12 ? c.chapter.name.slice(0, 12) + '…' : c.chapter.name,
      minutes: c.stat.timeSpent,
    }))
  const marksTrend = sResults.map((r, i) => ({
    name: `#${i + 1}`,
    score: r.percentage,
  }))
  const rollingAvg = sResults.map((r, i) => {
    const slice = sResults.slice(0, i + 1)
    const avg = slice.reduce((a, x) => a + x.percentage, 0) / slice.length
    return { name: `#${i + 1}`, avg: Math.round(avg) }
  })
  const examAttemptsOverTime = sResults.map((r, i) => ({
    name: r.createdAt.slice(5),
    cumulative: i + 1,
  }))
  const questionPie = [
    { name: 'Correct', value: stat?.correct ?? 0, color: '#10b981' },
    { name: 'Wrong', value: stat?.wrong ?? 0, color: '#f43f5e' },
    { name: 'Unanswered', value: stat?.unanswered ?? 0, color: '#a1a1aa' },
  ]
  // Batch comparison: this student vs batch avg per chapter
  const batchCompare = assignedChapters.map((ch) => {
    const myScore = stat?.chapterStats[ch.id]?.bestScore ?? 0
    const batchMates = allStudents.filter(
      (s) => s.batch === student.batch && s.id !== student.id
    )
    let sum = 0
    let n = 0
    for (const mate of batchMates) {
      const mateStat = allStudentStats[mate.id]?.chapterStats[ch.id]
      if (mateStat && mateStat.bestScore > 0) {
        sum += mateStat.bestScore
        n++
      }
    }
    return {
      name: ch.name.length > 10 ? ch.name.slice(0, 10) + '…' : ch.name,
      you: myScore,
      batch: n ? Math.round(sum / n) : 0,
    }
  })

  // Activity timeline
  const studentActivities = activityLogs
    .filter((l) => l.user === student.name)
    .slice()
    .sort((a, b) => b.timestamp - a.timestamp)

  // Learning timeline
  const learningTimeline = [
    {
      icon: Users,
      label: `Joined ${student.batch}`,
      time: student.enrolledAt,
      done: true,
    },
    {
      icon: BookOpen,
      label: `Assigned ${assignedChapters.length} chapter${assignedChapters.length === 1 ? '' : 's'}`,
      time: student.enrolledAt,
      done: assignedChapters.length > 0,
    },
    {
      icon: Brain,
      label: 'Completed first worksheet',
      time: sResults[0]?.createdAt ?? '—',
      done: sResults.length > 0,
    },
    {
      icon: CheckCircle2,
      label: 'Passed first exam',
      time: sResults.find((r) => r.status === 'passed')?.createdAt ?? '—',
      done: sResults.some((r) => r.status === 'passed'),
    },
    {
      icon: Award,
      label: 'Certificate generated',
      time: sCerts[0]?.issuedAt ?? '—',
      done: sCerts.length > 0,
    },
    {
      icon: Flame,
      label: 'Logged in recently',
      time: login.abs,
      done: !!student.lastLogin,
    },
  ]

  const handleSaveNote = () => {
    if (!noteDraft.trim()) {
      toast.error('Note cannot be empty')
      return
    }
    setSavingNote(true)
    setTimeout(() => {
      updateStudent(student.id, { notes: noteDraft.trim() })
      setSavingNote(false)
      toast.success('Teacher note saved', { description: student.name })
    }, 500)
  }

  const batchObj = batches.find((b) => b.name === student.batch)
  const totalLoginCount = loginActivity.totalLogins + studentActivities.filter((a) => a.type === 'login').length
  const avgSession = stat?.studyTime && totalLoginCount ? Math.round(stat.studyTime / totalLoginCount) : 0
  const pdfReadingTime = assignedChapters.reduce(
    (a, ch) => a + (ch.studyMaterials?.length || 0) * 12,
    0
  )

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto p-0 sm:max-w-2xl">
        {/* Premium drawer header */}
        <SheetHeader className="drawer-header-premium p-5 pb-4">
          <div className="flex items-start gap-4">
            <div className="relative">
              <Avatar className="avatar-premium h-16 w-16">
                {student.photo ? <AvatarImage src={student.photo} alt={student.name} /> : null}
                <AvatarFallback className={avatarColorClasses(student.avatarColor)}>
                  {initials(student.name)}
                </AvatarFallback>
              </Avatar>
              <span
                className={`absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-background bg-background ${tier.className} ${tier.glowClass}`}
              >
                <TierIcon className="h-3.5 w-3.5" />
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <SheetTitle className="flex flex-wrap items-center gap-2 text-lg">
                <span className="truncate font-bold">{student.name}</span>
                <span className={`badge-status ${statusBadge[student.status]}`}>
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${dotColor(
                      student.status === 'active'
                        ? 'emerald'
                        : student.status === 'suspended'
                        ? 'rose'
                        : 'amber'
                    )}`}
                  />
                  <span className="capitalize">{student.status}</span>
                </span>
              </SheetTitle>
              <SheetDescription className="flex flex-wrap items-center gap-2 num-premium">
                <span>{student.id}</span>
                <span className="text-muted-foreground/40">•</span>
                <span className={`inline-flex items-center gap-1 font-semibold ${tier.className}`}>
                  <TierIcon className="h-3 w-3" />
                  {tier.label} Student
                </span>
                <span className="text-muted-foreground/40">•</span>
                <Badge variant="outline" className="font-medium">
                  {student.batch}
                </Badge>
                <span className="text-muted-foreground/40">•</span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" /> {login.rel}
                </span>
              </SheetDescription>
            </div>
          </div>
          {/* Quick actions */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            <Button size="sm" className="btn-premium-primary h-8" onClick={() => onDownloadPdf(student)}>
              <FileDown className="h-3.5 w-3.5" /> Download PDF
            </Button>
            <Button size="sm" className="btn-premium-outline h-8" variant="outline" onClick={() => onSendEmail(student)}>
              <Mail className="h-3.5 w-3.5" /> Email
            </Button>
            <Button size="sm" className="btn-premium-outline h-8" variant="outline" onClick={() => onGenerateCert(student)}>
              <Award className="h-3.5 w-3.5" /> Cert
            </Button>
          </div>
        </SheetHeader>

        <Tabs value={activeTab} onValueChange={onTabChange} className="flex flex-col">
          <div className="border-b border-border/50 px-3">
            <TabsList className="h-auto w-full justify-start gap-0 overflow-x-auto bg-transparent p-0">
              <TabsTrigger value="overview" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Overview
              </TabsTrigger>
              <TabsTrigger value="analytics" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Analytics
              </TabsTrigger>
              <TabsTrigger value="chapters" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Chapters
              </TabsTrigger>
              <TabsTrigger value="exams" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Exams
              </TabsTrigger>
              <TabsTrigger value="certificates" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Certificates
              </TabsTrigger>
              <TabsTrigger value="insights" className="rounded-none border-b-2 border-transparent px-3 py-2 text-xs data-[state=active]:border-primary">
                Insights
              </TabsTrigger>
            </TabsList>
          </div>

          {/* ════════════ OVERVIEW TAB ════════════ */}
          <TabsContent value="overview" className="m-0 space-y-5 p-5">
            {/* ── Section 1: Student Information ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Student Information
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <InfoTile icon={Mail} label="Email" value={<span className="truncate">{student.email}</span>} className="col-span-2 sm:col-span-1" />
                <InfoTile icon={Phone} label="Mobile" value={student.phone} />
                <InfoTile icon={MapPin} label="Address" value={student.address || '—'} />
                <InfoTile icon={Calendar} label="Registration" value={student.enrolledAt} />
                <InfoTile icon={ShieldBan} label="Status" value={<span className="capitalize">{student.status}</span>} />
                <InfoTile icon={Clock} label="Last Login" value={login.rel} />
                <InfoTile icon={Activity} label="Total Logins" value={totalLoginCount} />
                <InfoTile icon={Calendar} label="Valid Until" value={student.validityEnd || '—'} />
                <InfoTile icon={Users} label="Batch" value={student.batch} />
                {batchObj && (
                  <InfoTile icon={BookOpen} label="Chapters in Batch" value={batchObj.id} />
                )}
              </div>
            </div>

            {/* ── Section 2: Performance Overview (12 KPI mini-cards) ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Performance Overview
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <MiniStat icon={LineChartIcon} label="Overall Progress" value={`${stat?.progress ?? 0}%`} accent="text-emerald-500" />
                <MiniStat icon={TrendingUp} label="Overall Average" value={`${stat?.avgScore ?? 0}%`} accent="text-violet-500" />
                <MiniStat icon={TrendingUp} label="Highest Score" value={`${stat?.highestScore ?? 0}%`} accent="text-emerald-500" />
                <MiniStat icon={TrendingDown} label="Lowest Score" value={`${stat?.lowestScore ?? 0}%`} accent="text-rose-500" />
                <MiniStat icon={CheckCircle2} label="Pass %" value={`${stat?.passRate ?? 0}%`} accent="text-emerald-500" />
                <MiniStat icon={XCircle} label="Fail %" value={`${100 - (stat?.passRate ?? 0)}%`} accent="text-rose-500" />
                <MiniStat icon={BookOpen} label="Chapters Done" value={chapterStats.filter((c) => c.stat.status === 'completed').length} accent="text-emerald-500" />
                <MiniStat icon={BookOpen} label="Remaining" value={chapterStats.filter((c) => c.stat.status !== 'completed').length} accent="text-amber-500" />
                <MiniStat icon={Award} label="Certs Earned" value={stat?.certificates ?? 0} accent="text-amber-500" />
                <MiniStat icon={BookCheck} label="Exams Taken" value={stat?.examsCompleted ?? 0} accent="text-rose-500" />
                <MiniStat icon={Clock} label="Study Time" value={`${Math.round((stat?.studyTime ?? 0) / 60)}h`} accent="text-teal-500" />
                <MiniStat icon={Clock} label="Avg / Chapter" value={`${assignedChapters.length ? Math.round((stat?.studyTime ?? 0) / assignedChapters.length) : 0}m`} accent="text-teal-500" />
              </div>
            </div>

            {/* ── Section 7: Learning Timeline ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Learning Timeline
              </p>
              <div className="relative pl-2">
                <div className="absolute left-[7px] top-1 h-full w-px bg-border" />
                {learningTimeline.map((t, i) => {
                  const TIcon = t.icon
                  return (
                    <div key={i} className="relative flex items-start gap-3 pb-4">
                      <span
                        className={`relative z-10 flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-background ${
                          t.done ? 'bg-emerald-500' : 'bg-muted-foreground/30'
                        }`}
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 text-sm font-medium">
                          <TIcon className="h-3 w-3 text-muted-foreground" />
                          {t.label}
                        </div>
                        <div className="num-premium text-xs text-muted-foreground">{t.time}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </TabsContent>

          {/* ════════════ ANALYTICS TAB ════════════ */}
          <TabsContent value="analytics" className="m-0 space-y-4 p-5">
            {/* ── Section 3: Progress Analytics charts ── */}
            <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
              <ChartCard title="Chapter-wise Progress" subtitle="Per chapter completion %">
                {chapterProgressData.length === 0 ? (
                  <EmptyHint icon={BookOpen} message="No chapters assigned yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={chapterProgressData} layout="vertical" margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                      <XAxis type="number" domain={[0, 100]} tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={90} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Bar dataKey="progress" fill="#10b981" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Chapter Completion" subtitle="Completed vs in progress vs not started">
                {assignedChapters.length === 0 ? (
                  <EmptyHint icon={BookOpen} message="No chapters assigned yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={completionDonut} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} innerRadius={45}>
                        {completionDonut.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <RLegend wrapperStyle={{ fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Weekly Learning Progress" subtitle="Study minutes per day">
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={weeklyMinutes} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="weekFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                    <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                    <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                    <RTooltip contentStyle={chartTooltipStyle} />
                    <Area type="monotone" dataKey="minutes" stroke="#10b981" strokeWidth={2} fill="url(#weekFill)" />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard title="Monthly Progress" subtitle="Avg score per month">
                {monthlyData.length === 0 ? (
                  <EmptyHint icon={LineChartIcon} message="No exam attempts yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={monthlyData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="month" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis domain={[0, 100]} tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Line type="monotone" dataKey="avgScore" stroke="#8b5cf6" strokeWidth={2.5} dot={{ r: 3, fill: '#8b5cf6' }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Study Time by Chapter" subtitle="Minutes spent per chapter">
                {studyTimeByChapter.length === 0 ? (
                  <EmptyHint icon={Clock} message="No study time logged yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={studyTimeByChapter} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Bar dataKey="minutes" fill="#14b8a6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Marks Trend" subtitle="Score per attempt over time">
                {marksTrend.length === 0 ? (
                  <EmptyHint icon={TrendingUp} message="No exam attempts yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={marksTrend} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis domain={[0, 100]} tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3, fill: '#10b981' }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Average Marks Trend" subtitle="Rolling average across attempts">
                {rollingAvg.length === 0 ? (
                  <EmptyHint icon={TrendingUp} message="No exam attempts yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={rollingAvg} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="rollFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis domain={[0, 100]} tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Area type="monotone" dataKey="avg" stroke="#8b5cf6" strokeWidth={2.5} fill="url(#rollFill)" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>

              <ChartCard title="Login Activity" subtitle="Logins per day of week">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={loginActivity.weekly} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                    <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                    <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                    <RTooltip contentStyle={chartTooltipStyle} />
                    <Bar dataKey="logins" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartCard>

              <ChartCard title="Exam Attempts Over Time" subtitle="Cumulative attempts">
                {examAttemptsOverTime.length === 0 ? (
                  <EmptyHint icon={BookCheck} message="No attempts yet." />
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={examAttemptsOverTime} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Line type="monotone" dataKey="cumulative" stroke="#f43f5e" strokeWidth={2.5} dot={{ r: 3, fill: '#f43f5e' }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>
            </div>

            {/* ── Section 8: Login Analytics ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Login Analytics
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <MiniStat icon={Activity} label="Total Logins" value={totalLoginCount} accent="text-violet-500" />
                <MiniStat icon={Clock} label="Last Login" value={login.rel} accent="text-emerald-500" />
                <MiniStat icon={Monitor} label="Device" value={device.device} accent="text-teal-500" />
                <MiniStat icon={Monitor} label="Browser" value={device.browser} accent="text-teal-500" />
                <MiniStat icon={Activity} label="Sessions" value={device.sessions} accent="text-amber-500" />
                <MiniStat icon={Clock} label="Avg Session" value={`${avgSession}m`} accent="text-emerald-500" />
                <MiniStat icon={Monitor} label="IP Address" value={device.ip} accent="text-muted-foreground" />
                <MiniStat icon={Activity} label="Study Sessions" value={Math.max(1, Math.floor(totalLoginCount / 3))} accent="text-rose-500" />
              </div>
              {loginActivity.history.length > 0 && (
                <div className="mt-3 rounded-lg border border-border/60 p-3">
                  <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Recent Login History
                  </p>
                  <div className="max-h-32 space-y-1 overflow-y-auto">
                    {loginActivity.history.map((l) => (
                      <div key={l.id} className="flex items-center justify-between text-xs">
                        <span className="inline-flex items-center gap-1.5">
                          <Activity className="h-3 w-3 text-muted-foreground" />
                          {l.action} {l.target}
                        </span>
                        <span className="num-premium text-muted-foreground">{l.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* ── Section 9: Study Analytics ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Study Analytics
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <MiniStat icon={Clock} label="Total Hours" value={`${Math.round((stat?.studyTime ?? 0) / 60)}h`} accent="text-teal-500" />
                <MiniStat icon={BookOpen} label="PDF Reading" value={`${Math.round(pdfReadingTime / 60)}h`} accent="text-emerald-500" />
                <MiniStat icon={Brain} label="Practice Time" value={`${Math.round((stat?.studyTime ?? 0) * 0.4)}m`} accent="text-violet-500" />
                <MiniStat icon={BookCheck} label="Exam Time" value={`${stat?.studyTime ?? 0}m`} accent="text-rose-500" />
              </div>
              <div className="mt-3 grid grid-cols-1 gap-3 lg:grid-cols-3">
                <ChartCard title="Daily Learning Time" subtitle="Hours per day (last 28 days)">
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={dailyStudy} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-[9px] text-muted-foreground" interval={3} />
                      <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Bar dataKey="hours" fill="#14b8a6" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>
                <ChartCard title="Weekly Learning Time" subtitle="Minutes per day this week">
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={weeklyMinutes} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Bar dataKey="minutes" fill="#10b981" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>
                <ChartCard title="Monthly Learning Time" subtitle="Hours per month">
                  <ResponsiveContainer width="100%" height={180}>
                    <AreaChart data={monthlyStudy} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="monthFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="month" tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" />
                      <YAxis tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                      <RTooltip contentStyle={chartTooltipStyle} />
                      <Area type="monotone" dataKey="hours" stroke="#f59e0b" strokeWidth={2} fill="url(#monthFill)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </ChartCard>
              </div>
            </div>
          </TabsContent>

          {/* ════════════ CHAPTERS TAB ════════════ */}
          <TabsContent value="chapters" className="m-0 space-y-3 p-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Chapter Performance ({assignedChapters.length})
            </p>
            {assignedChapters.length === 0 ? (
              <EmptyHint icon={BookOpen} message="No chapters assigned to this student yet." />
            ) : (
              <div className="space-y-2">
                {chapterStats.map(({ chapter, stat: cStat }) => {
                  const cs = chapterStatusStyles[cStat.status]
                  return (
                    <div key={chapter.id} className="card-premium rounded-xl p-4">
                      <div className="mb-3 flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="chip-premium inline-flex items-center gap-1 border-border bg-muted/40 text-muted-foreground">
                            CH {chapter.order}
                          </span>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{chapter.name}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {cStat.attempts} attempt{cStat.attempts === 1 ? '' : 's'} · {cStat.timeSpent}m spent
                            </p>
                          </div>
                        </div>
                        <span className={`badge-status ${cs.chip}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${cs.dot}`} />
                          {cs.label}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-muted-foreground">Study progress</span>
                            <span className="num-premium font-semibold">{cStat.progress}%</span>
                          </div>
                          <div className="progress-premium h-1.5">
                            <div className="progress-premium-fill" style={{ width: `${cStat.progress}%` }} />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-muted-foreground">Best exam score</span>
                            <span className="num-premium font-semibold">{cStat.bestScore}%</span>
                          </div>
                          <div className="progress-premium h-1.5">
                            <div
                              className="progress-premium-fill"
                              style={{
                                width: `${cStat.bestScore}%`,
                                background: cStat.bestScore >= 80 ? 'linear-gradient(90deg, oklch(0.62 0.13 160), oklch(0.65 0.15 175))' : cStat.bestScore >= 60 ? 'linear-gradient(90deg, oklch(0.72 0.16 70), oklch(0.75 0.16 75))' : 'linear-gradient(90deg, oklch(0.62 0.2 20), oklch(0.65 0.2 25))',
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>

          {/* ════════════ EXAMS TAB ════════════ */}
          <TabsContent value="exams" className="m-0 space-y-4 p-5">
            {/* ── Section 5: Exam History ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Exam History
              </p>
              {sResults.length === 0 ? (
                <EmptyHint icon={BookCheck} message="No exam attempts yet." />
              ) : (
                <div className="overflow-x-auto rounded-lg border border-border/50">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border/50 bg-muted/30 hover:bg-muted/30 [&_th]:h-14">
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Exam</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Attempt</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Date</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Time</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Marks</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">%</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Status</TableHead>
                        <TableHead className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Cert</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sResults
                        .slice()
                        .reverse()
                        .map((r) => {
                          const hasCert = sCerts.some(
                            (c) => c.chapterName === r.chapterName && c.examTitle === r.examTitle
                          )
                          return (
                            <TableRow key={r.id} className="border-border/40 [&_td]:py-5">
                              <TableCell>
                                <div className="text-xs font-medium">{r.examTitle}</div>
                                <div className="text-[10px] text-muted-foreground">{r.chapterName}</div>
                              </TableCell>
                              <TableCell className="num-premium text-xs">#{r.attemptNumber}</TableCell>
                              <TableCell className="num-premium text-xs">{r.createdAt}</TableCell>
                              <TableCell className="num-premium text-xs">{r.timeTakenMinutes}m</TableCell>
                              <TableCell className="num-premium text-xs">
                                {r.marksObtained}/{r.totalMarks}
                              </TableCell>
                              <TableCell>
                                <span
                                  className={`num-premium text-xs font-bold ${
                                    r.percentage >= 80
                                      ? 'text-emerald-600 dark:text-emerald-400'
                                      : r.percentage >= 60
                                      ? 'text-amber-600 dark:text-amber-400'
                                      : 'text-rose-600 dark:text-rose-400'
                                  }`}
                                >
                                  {r.percentage}%
                                </span>
                              </TableCell>
                              <TableCell>
                                <span
                                  className={`badge-status ${
                                    r.status === 'passed'
                                      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                                      : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                                  }`}
                                >
                                  <span className={`h-1.5 w-1.5 rounded-full ${r.status === 'passed' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                                  <span className="capitalize">{r.status}</span>
                                </span>
                              </TableCell>
                              <TableCell>
                                {hasCert ? (
                                  <Award className="h-4 w-4 text-amber-500" />
                                ) : (
                                  <X className="h-3.5 w-3.5 text-muted-foreground/40" />
                                )}
                              </TableCell>
                            </TableRow>
                          )
                        })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>

            {/* ── Section 6: Question Analysis ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Question Analysis
              </p>
              <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                <ChartCard title="Correct / Wrong / Unanswered" subtitle="Across all exam attempts">
                  {stat?.correct === 0 && (stat?.wrong ?? 0) === 0 && (stat?.unanswered ?? 0) === 0 ? (
                    <EmptyHint icon={PieChartIcon} message="No question-level data available." />
                  ) : (
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie data={questionPie} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                          {questionPie.map((entry, i) => (
                            <Cell key={i} fill={entry.color} />
                          ))}
                        </Pie>
                        <RTooltip contentStyle={chartTooltipStyle} />
                        <RLegend wrapperStyle={{ fontSize: 11 }} />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </ChartCard>

                <div className="space-y-2">
                  <MiniStat
                    icon={Target}
                    label="Accuracy"
                    value={
                      stat && (stat.correct + stat.wrong) > 0
                        ? `${Math.round((stat.correct / (stat.correct + stat.wrong)) * 100)}%`
                        : '—'
                    }
                    accent="text-emerald-500"
                  />
                  <MiniStat
                    icon={Clock}
                    label="Avg Response Time"
                    value={stat?.avgResponseTime ? `${stat.avgResponseTime}s` : '—'}
                    accent="text-violet-500"
                  />
                  <MiniStat icon={CheckCircle2} label="Correct Answers" value={stat?.correct ?? 0} accent="text-emerald-500" />
                  <MiniStat icon={XCircle} label="Wrong Answers" value={stat?.wrong ?? 0} accent="text-rose-500" />
                </div>
              </div>

              {/* Weak topics */}
              <div className="mt-3">
                <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Weak Topics (chapters with lowest scores)
                </p>
                {chapterStats.filter((c) => c.stat.attempts > 0).length === 0 ? (
                  <EmptyHint icon={BookOpen} message="No chapter attempts yet." />
                ) : (
                  <div className="space-y-1.5">
                    {chapterStats
                      .filter((c) => c.stat.attempts > 0)
                      .sort((a, b) => a.stat.bestScore - b.stat.bestScore)
                      .slice(0, 3)
                      .map(({ chapter, stat: cStat }) => (
                        <div
                          key={chapter.id}
                          className="flex items-center justify-between rounded-lg border border-border/60 bg-card/40 p-2.5"
                        >
                          <span className="text-sm font-medium">{chapter.name}</span>
                          <span
                            className={`num-premium text-sm font-bold ${
                              cStat.bestScore >= 80
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : cStat.bestScore >= 60
                                ? 'text-amber-600 dark:text-amber-400'
                                : 'text-rose-600 dark:text-rose-400'
                            }`}
                          >
                            {cStat.bestScore}%
                          </span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* ════════════ CERTIFICATES TAB ════════════ */}
          <TabsContent value="certificates" className="m-0 space-y-3 p-5">
            {/* ── Section 10: Certificate Section ── */}
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Certificates ({sCerts.filter((c) => c.status === 'issued').length} issued)
              </p>
              <Button
                size="sm"
                variant="outline"
                className="btn-premium-outline h-8"
                onClick={() => onGenerateCert(student)}
              >
                <Award className="h-3.5 w-3.5" /> Generate New
              </Button>
            </div>
            {sCerts.length === 0 ? (
              <EmptyHint icon={Award} message="No certificates earned yet." />
            ) : (
              <div className="space-y-2">
                {sCerts.map((c) => (
                  <div
                    key={c.id}
                    className="card-premium rounded-xl p-4"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400">
                          <Award className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold">{c.chapterName}</p>
                          <p className="text-[11px] text-muted-foreground">{c.examTitle}</p>
                          <p className="num-premium mt-0.5 text-[10px] text-muted-foreground">
                            {c.certificateNumber} · Issued {c.issuedAt}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="num-premium text-lg font-bold text-amber-600 dark:text-amber-400">
                          {c.score}%
                        </span>
                        <span
                          className={`badge-status ${
                            c.status === 'issued'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                          }`}
                        >
                          <span className={`h-1.5 w-1.5 rounded-full ${c.status === 'issued' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                          <span className="capitalize">{c.status}</span>
                        </span>
                      </div>
                    </div>
                    <div className="mt-3 flex gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        className="btn-premium-outline h-7 text-xs"
                        onClick={() => toast.success('Certificate preview opened', { description: c.certificateNumber })}
                      >
                        <Eye className="h-3 w-3" /> View
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="btn-premium-outline h-7 text-xs"
                        onClick={() => toast.success('Certificate download started', { description: c.certificateNumber })}
                      >
                        <Download className="h-3 w-3" /> Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* ════════════ INSIGHTS TAB ════════════ */}
          <TabsContent value="insights" className="m-0 space-y-5 p-5">
            {/* ── Section 13: Performance Insights ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Performance Insights
              </p>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <InsightCard
                  icon={Trophy}
                  label="Strongest Subject"
                  value={strongest?.chapter.name ?? '—'}
                  sub={strongest ? `Best score: ${strongest.stat.bestScore}%` : 'No attempts yet'}
                  tone="emerald"
                />
                <InsightCard
                  icon={Target}
                  label="Weakest Subject"
                  value={weakest?.chapter.name ?? '—'}
                  sub={weakest ? `Best score: ${weakest.stat.bestScore}%` : 'No attempts yet'}
                  tone="rose"
                />
                <InsightCard
                  icon={Clock}
                  label="Most Time Spent"
                  value={mostTime?.chapter.name ?? '—'}
                  sub={mostTime ? `${mostTime.stat.timeSpent} minutes` : 'No data'}
                  tone="violet"
                />
                <InsightCard
                  icon={TrendingUp}
                  label="Fastest Completed"
                  value={fastest?.chapter.name ?? '—'}
                  sub={fastest ? `${fastest.stat.timeSpent} minutes` : 'None completed yet'}
                  tone="teal"
                />
                <InsightCard
                  icon={BookOpen}
                  label="Lowest Performing"
                  value={weakest?.chapter.name ?? '—'}
                  sub={weakest ? `${weakest.stat.attempts} attempts` : '—'}
                  tone="amber"
                />
                <InsightCard
                  icon={Award}
                  label="Highest Performing"
                  value={strongest?.chapter.name ?? '—'}
                  sub={strongest ? `${strongest.stat.attempts} attempts` : '—'}
                  tone="emerald"
                />
                <InsightCard
                  icon={BookOpen}
                  label="Recommended Revision"
                  value={chapterStats.filter((c) => c.stat.bestScore > 0 && c.stat.bestScore < 70).map((c) => c.chapter.name).join(', ') || 'None — all chapters above 70%'}
                  sub="Chapters scoring below 70%"
                  tone="amber"
                />
                <InsightCard
                  icon={Activity}
                  label="Overall Status"
                  value={overallStatus.label}
                  sub={`Based on ${(stat?.avgScore ?? 0)}% avg & ${(stat?.progress ?? 0)}% progress`}
                  tone={overallStatus.tone}
                />
              </div>
            </div>

            {/* ── Section 12: Student Ranking ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Student Ranking
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <MiniStat icon={Trophy} label="Overall Rank" value={`#${overallRank}`} accent="text-amber-500" />
                <MiniStat icon={Users} label="Batch Rank" value={`#${batchRank}`} accent="text-emerald-500" />
                <MiniStat icon={Calendar} label="Monthly Rank" value={`#${Math.max(1, overallRank - 1)}`} accent="text-violet-500" />
                <MiniStat icon={Calendar} label="Weekly Rank" value={`#${Math.max(1, overallRank)}`} accent="text-teal-500" />
              </div>
              <div className="mt-3">
                <ChartCard title="You vs Batch Average" subtitle="Per-chapter score comparison">
                  {batchCompare.length === 0 ? (
                    <EmptyHint icon={BarChart3} message="No chapter data to compare." />
                  ) : (
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={batchCompare} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                        <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-[9px] text-muted-foreground" />
                        <YAxis domain={[0, 100]} tickLine={false} axisLine={false} className="text-[10px] text-muted-foreground" width={28} />
                        <RTooltip contentStyle={chartTooltipStyle} />
                        <RLegend wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="you" fill="#10b981" radius={[3, 3, 0, 0]} name="You" />
                        <Bar dataKey="batch" fill="#a1a1aa" radius={[3, 3, 0, 0]} name="Batch Avg" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </ChartCard>
              </div>
            </div>

            {/* ── Section 11: Teacher Notes ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Teacher Notes
              </p>
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
                <Textarea
                  rows={4}
                  value={noteDraft}
                  onChange={(e) => setNoteDraft(e.target.value)}
                  placeholder="Add private notes about this student (visible only to admins)…"
                  className="border-amber-500/20 bg-background/60"
                />
                <div className="mt-3 flex items-center justify-between">
                  <p className="text-[11px] text-muted-foreground">
                    {sNotes.length} note{sNotes.length === 1 ? '' : 's'} saved · Last saved{' '}
                    {student.notes ? 'just now' : 'never'}
                  </p>
                  <Button
                    size="sm"
                    className="btn-premium-primary h-8"
                    onClick={handleSaveNote}
                    disabled={savingNote}
                  >
                    {savingNote ? (
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Save className="h-3.5 w-3.5" />
                    )}
                    Save Note
                  </Button>
                </div>
              </div>
            </div>

            {/* ── Section 14: Activity Timeline ── */}
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Activity Timeline
              </p>
              {studentActivities.length === 0 ? (
                <EmptyHint icon={Activity} message="No recent activity for this student." />
              ) : (
                <div className="relative pl-2">
                  <div className="absolute left-[7px] top-1 h-full w-px bg-border" />
                  {studentActivities.slice(0, 12).map((a) => {
                    const iconMap = {
                      login: { icon: Activity, color: 'bg-violet-500' },
                      submit: { icon: BookCheck, color: 'bg-emerald-500' },
                      create: { icon: Sparkles, color: 'bg-amber-500' },
                      update: { icon: Pencil, color: 'bg-sky-500' },
                      delete: { icon: XCircle, color: 'bg-rose-500' },
                      system: { icon: ShieldBan, color: 'bg-zinc-400' },
                    }
                    const entry = iconMap[a.type] ?? iconMap.system
                    const EIcon = entry.icon
                    return (
                      <div key={a.id} className="relative flex items-start gap-3 pb-3">
                        <span
                          className={`relative z-10 flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-background ${entry.color}`}
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-1.5 text-sm font-medium">
                            <EIcon className="h-3 w-3 text-muted-foreground" />
                            {a.action}
                          </div>
                          {a.target && (
                            <p className="text-xs text-muted-foreground">{a.target}</p>
                          )}
                          <p className="num-premium text-[11px] text-muted-foreground/70">{a.time}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Insight card
// ────────────────────────────────────────────────────────────────────────────

function InsightCard({
  icon: Icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: typeof Trophy
  label: string
  value: string
  sub: string
  tone: 'emerald' | 'rose' | 'amber' | 'violet' | 'teal'
}) {
  const toneMap = {
    emerald: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    rose: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
    amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
    violet: 'bg-violet-500/10 text-violet-600 dark:text-violet-400',
    teal: 'bg-teal-500/10 text-teal-600 dark:text-teal-400',
  }
  return (
    <div className="card-premium rounded-xl p-4">
      <div className="flex items-start gap-3">
        <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${toneMap[tone]}`}>
          <Icon className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            {label}
          </p>
          <p className="truncate text-sm font-semibold text-foreground">{value}</p>
          <p className="text-[11px] text-muted-foreground">{sub}</p>
        </div>
      </div>
    </div>
  )
}
