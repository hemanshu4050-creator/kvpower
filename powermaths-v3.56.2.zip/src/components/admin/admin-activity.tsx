'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  CheckCircle2,
  Clock,
  Download,
  LogIn,
  Pencil,
  Plus,
  Search,
  Settings2,
  Sparkles,
  Trash2,
  type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useDataStore, type ActivityLog } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'

const typeMeta: Record<
  ActivityLog['type'],
  { icon: LucideIcon; color: string; label: string }
> = {
  create: { icon: Plus, color: 'bg-emerald-500', label: 'Created' },
  update: { icon: Pencil, color: 'bg-sky-500', label: 'Updated' },
  delete: { icon: Trash2, color: 'bg-rose-500', label: 'Deleted' },
  login: { icon: LogIn, color: 'bg-violet-500', label: 'Login' },
  submit: { icon: CheckCircle2, color: 'bg-amber-500', label: 'Submitted' },
  system: { icon: Sparkles, color: 'bg-zinc-400', label: 'System' },
}

/** Group logs by time period header (heuristic based on the time string). */
function timeGroup(time: string): string {
  if (/just now|min ago|hour ago|hours ago/i.test(time)) return 'Today'
  if (/^1 day ago$|^yesterday$/i.test(time)) return 'Yesterday'
  if (/day ago|days ago/i.test(time)) return 'Earlier this week'
  return 'Older'
}

const groupOrder = ['Today', 'Yesterday', 'Earlier this week', 'Older']

export function AdminActivity() {
  const pageTitle = useNavLabel('activity', 'Activity Logs')
  const { activityLogs } = useDataStore()
  const [search, setSearch] = useState('')
  const [type, setType] = useState('all')
  const [role, setRole] = useState('all')

  const filtered = useMemo(() => {
    return activityLogs.filter((l) => {
      const q = search.trim().toLowerCase()
      if (
        q &&
        !l.user.toLowerCase().includes(q) &&
        !l.action.toLowerCase().includes(q) &&
        !l.target.toLowerCase().includes(q)
      )
        return false
      if (type !== 'all' && l.type !== type) return false
      if (role !== 'all' && l.role !== role) return false
      return true
    })
  }, [activityLogs, search, type, role])

  const grouped = useMemo(() => {
    const groups: Record<string, ActivityLog[]> = {}
    for (const log of filtered) {
      const g = timeGroup(log.time)
      if (!groups[g]) groups[g] = []
      groups[g].push(log)
    }
    return groups
  }, [filtered])

  const clearFilters = () => {
    setSearch('')
    setType('all')
    setRole('all')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="An audit trail of every action taken across the portal."
        icon={<Activity className="h-5 w-5" />}
        actions={
          <Button
            variant="outline"
            onClick={() =>
              toast.success('Export started', {
                description: 'CSV will download shortly.',
              })
            }
          >
            <Download className="h-4 w-4" /> Export
          </Button>
        }
      />

      {/* v3.36.0 — 30-day auto-delete retention notice. */}
      <div className="flex items-start gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-sm">
        <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
        <div>
          <p className="font-medium text-foreground">Auto-deleted after 30 days</p>
          <p className="mt-0.5 text-muted-foreground">
            Activity log entries are automatically and permanently deleted{' '}
            <span className="font-medium text-foreground">30 days</span> after they are recorded to
            keep the audit trail lightweight. Export to CSV if you need a permanent record.
          </p>
        </div>
      </div>

      {/* Filter bar */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by user, action, target…"
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={type} onValueChange={setType}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="create">Created</SelectItem>
                <SelectItem value="update">Updated</SelectItem>
                <SelectItem value="delete">Deleted</SelectItem>
                <SelectItem value="login">Login</SelectItem>
                <SelectItem value="submit">Submitted</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All roles</SelectItem>
                <SelectItem value="admin">Admins</SelectItem>
                <SelectItem value="student">Students</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
            {(search || type !== 'all' || role !== 'all') && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Timeline */}
      {filtered.length === 0 ? (
        <Card className="card-elevated">
          <EmptyState
            icon={Activity}
            title="No activity found"
            description="Try adjusting your search or filters."
            action={
              <Button variant="outline" onClick={clearFilters}>
                Reset filters
              </Button>
            }
          />
        </Card>
      ) : (
        <Card className="card-elevated p-5 sm:p-6">
          <ol className="relative space-y-8">
            {groupOrder.map((group) => {
              const logs = grouped[group]
              if (!logs?.length) return null
              return (
                <li key={group} className="relative">
                  <div className="sticky top-0 z-10 mb-3 -ml-2 inline-flex items-center gap-2 rounded-full bg-background/95 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground shadow-sm backdrop-blur">
                    <Settings2 className="h-3 w-3" />
                    {group}
                    <Badge variant="secondary" className="tabular-nums">
                      {logs.length}
                    </Badge>
                  </div>
                  <ol className="relative space-y-1">
                    {logs.map((log, i, arr) => {
                      const meta = typeMeta[log.type]
                      const Icon = meta.icon
                      const isLast = i === arr.length - 1
                      return (
                        <motion.li
                          key={log.id}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.25, delay: i * 0.02 }}
                          className="relative flex gap-3 pb-5"
                        >
                          {!isLast && (
                            <span
                              className="absolute left-[15px] top-8 h-[calc(100%-1rem)] w-px bg-border"
                              aria-hidden
                            />
                          )}
                          <div
                            className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white shadow-sm ${meta.color}`}
                          >
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1 pt-0.5">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                              <span className="text-sm font-medium">
                                {log.user}
                              </span>
                              <Badge
                                variant="outline"
                                className="px-1.5 py-0 text-[10px] capitalize"
                              >
                                {log.role}
                              </Badge>
                              <Badge
                                variant="outline"
                                className="px-1.5 py-0 text-[10px]"
                              >
                                {meta.label}
                              </Badge>
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">
                              {log.action}
                              {log.target && (
                                <>
                                  {' '}
                                  <span className="font-medium text-foreground">
                                    {log.target}
                                  </span>
                                </>
                              )}
                            </p>
                            <p className="mt-0.5 text-xs text-muted-foreground">
                              {log.time}
                            </p>
                          </div>
                        </motion.li>
                      )
                    })}
                  </ol>
                </li>
              )
            })}
          </ol>
        </Card>
      )}
    </div>
  )
}
