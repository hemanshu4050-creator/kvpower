'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Award,
  Ban,
  Calendar,
  Download,
  GraduationCap,
  LayoutGrid,
  Layers,
  List,
  Lock,
  MoreHorizontal,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { useDataStore, type Certificate } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { printCertificate } from '@/components/student/student-certificates'
import { avatarColorClasses, initials } from './lib/helpers'

// v3.48.0 — Build a Level / Batch label for the generate dropdown WITHOUT
// duplicating "Level N" when the batch name already starts with it (e.g. a
// batch literally named "Level 1" must NOT render as "Level 1 — Level 1").
// When the name does not already carry the level number, we keep the helpful
// "Level N —" prefix so the admin can see the path order at a glance.
const levelLabel = (levelNumber: number, name: string): string => {
  const trimmed = (name || '').trim()
  return /^level\s*\d/i.test(trimmed) ? trimmed : `Level ${levelNumber} — ${trimmed}`
}

export function AdminCertificates() {
  const pageTitle = useNavLabel('certificates', 'Certificates')
  const {
    certificates,
    students,
    exams,
    results,
    batches,
    chapters,
    generateCertificate,
    generateLevelCertificate,
    revokeCertificate,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [view, setView] = useState<'grid' | 'table'>('grid')
  const [genOpen, setGenOpen] = useState(false)
  const [genStudent, setGenStudent] = useState<string>(students[0]?.id ?? '')
  // v3.46.0 — Level/Batch dropdown. Empty string = "no level" (use Exam flow).
  const [genLevel, setGenLevel] = useState<string>('')
  const [genExam, setGenExam] = useState<string>(exams[0]?.id ?? '')
  const [genScore, setGenScore] = useState<string>('')
  const [revokeTarget, setRevokeTarget] = useState<Certificate | null>(null)

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return certificates
    return certificates.filter(
      (c) =>
        c.studentName.toLowerCase().includes(q) ||
        c.chapterName.toLowerCase().includes(q) ||
        c.examTitle.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q)
    )
  }, [certificates, search])

  const issuedThisMonth = certificates.filter((c) => {
    const d = new Date(c.issuedAt)
    const now = new Date()
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
  }).length
  const revokedCount = certificates.filter((c) => c.status === 'revoked').length

  // Suggest best score for the selected student + exam
  const suggestedScore = useMemo(() => {
    if (!genStudent || !genExam) return ''
    const rs = results.filter((r) => r.studentId === genStudent && r.examId === genExam)
    if (!rs.length) return ''
    return String(Math.max(...rs.map((r) => r.percentage)))
  }, [genStudent, genExam, results])

  const selectedStudent = students.find((s) => s.id === genStudent)
  const selectedExam = exams.find((e) => e.id === genExam)

  // v3.46.0 — Resolve the Level/Batch options for the currently-selected
  // student. Same derive strategy as the student Level/Batch page: use the
  // student's assignedBatchIds if present; otherwise own batch first then
  // other active batches by name. We also compute the chapter list for the
  // selected level so the preview + the level cert body can show it.
  const studentLevels = useMemo(() => {
    if (!selectedStudent) return [] as { id: string; name: string; code: string; levelNumber: number }[]
    const activeBatches = batches
      .filter((b) => b.status === 'active')
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
    const pathIds =
      selectedStudent.assignedBatchIds && selectedStudent.assignedBatchIds.length > 0
        ? selectedStudent.assignedBatchIds
        : (() => {
            const own = activeBatches.find((b) => b.name === selectedStudent.batch)
            const others = activeBatches.filter((b) => b.name !== selectedStudent.batch)
            return own ? [own.id, ...others.map((b) => b.id)] : others.map((b) => b.id)
          })()
    return pathIds
      .map((id, idx) => {
        const b = batches.find((x) => x.id === id)
        if (!b) return null
        return { id: b.id, name: b.name, code: b.code, levelNumber: idx + 1 }
      })
      .filter((x): x is { id: string; name: string; code: string; levelNumber: number } => !!x)
  }, [selectedStudent, batches])

  const selectedLevelBatch = useMemo(
    () => batches.find((b) => b.id === genLevel) || null,
    [batches, genLevel],
  )
  const selectedLevelChapters = useMemo(() => {
    if (!selectedLevelBatch) return [] as { id: string; name: string; order: number }[]
    return (selectedLevelBatch.chapterIds || [])
      .map((cid) => chapters.find((c) => c.id === cid))
      .filter((c): c is NonNullable<typeof c> => !!c)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
      .map((c) => ({ id: c.id, name: c.name, order: c.order }))
  }, [selectedLevelBatch, chapters])

  // True when the admin has picked a Level → exam cert flow is replaced by
  // the level-completion flow.
  const isLevelMode = !!genLevel

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedStudent) {
      toast.error('Pick a student')
      return
    }

    // ── v3.46.0 — Level / Batch Completion Certificate branch ──
    if (isLevelMode) {
      if (!selectedLevelBatch) {
        toast.error('Pick a level')
        return
      }
      // v3.48.0 — Use the batch's own name as the level name (the admin named
      // it e.g. "Level 1" / "Beginner English"). This avoids synthesising a
      // redundant "Level N" prefix that duplicated the name in the certificate.
      const levelName = selectedLevelBatch.name
      const chapterNames = selectedLevelChapters.map((c) => c.name)
      if (chapterNames.length === 0) {
        toast.error('Selected level has no chapters', {
          description: 'Assign chapters to this batch before issuing a level certificate.',
        })
        return
      }
      generateLevelCertificate(
        selectedStudent.id,
        selectedStudent.name,
        levelName,
        chapterNames,
      )
      toast.success('Level certificate generated', {
        description: `${selectedStudent.name} · ${levelName} · ${chapterNames.length} chapters`,
      })
      setGenOpen(false)
      setGenScore('')
      return
    }

    // ── Existing Exam Certificate flow ──
    if (!selectedExam) {
      toast.error('Pick an exam')
      return
    }
    const score = Number(genScore || suggestedScore || '0')
    if (!score && !suggestedScore) {
      toast.error('Enter a score')
      return
    }
    generateCertificate(
      selectedStudent.id,
      selectedStudent.name,
      selectedExam.chapterName,
      selectedExam.title,
      score || Number(suggestedScore)
    )
    toast.success('Certificate generated', { description: `${selectedStudent.name} · ${selectedExam.title}` })
    setGenOpen(false)
    setGenScore('')
  }

  const handleRevoke = () => {
    if (!revokeTarget) return
    revokeCertificate(revokeTarget.id)
    toast.error('Certificate revoked', { description: revokeTarget.id })
    setRevokeTarget(null)
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Issue, manage and revoke completion certificates for your students."
        icon={<Award className="h-5 w-5" />}
        actions={
          <Button onClick={() => { setGenStudent(students[0]?.id ?? ''); setGenLevel(''); setGenExam(exams[0]?.id ?? ''); setGenScore(''); setGenOpen(true) }}>
            <Plus className="h-4 w-4" /> Generate
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard title="Total Issued" value={certificates.filter((c) => c.status === 'issued').length} icon={Award} accent="emerald" delay={0} />
        <StatCard title="Issued This Month" value={issuedThisMonth} icon={Sparkles} accent="teal" delay={0.05} />
        <StatCard title="Revoked" value={revokedCount} icon={Ban} accent="rose" delay={0.1} />
      </div>

      {/* Filter + view toggle */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search certificates…"
              className="pl-9"
            />
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as 'grid' | 'table')}>
            <TabsList>
              <TabsTrigger value="grid">
                <LayoutGrid className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Grid</span>
              </TabsTrigger>
              <TabsTrigger value="table">
                <List className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Table</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card className="card-elevated">
          <EmptyState
            icon={Award}
            title="No certificates found"
            description="Generate a new certificate or adjust your search."
          />
        </Card>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c, i) => (
            <CertificateCard
              key={c.id}
              cert={c}
              delay={i * 0.04}
              onRevoke={() => setRevokeTarget(c)}
              onDownload={() => printCertificate(c)}
              student={students.find((s) => s.id === c.studentId)}
            />
          ))}
        </div>
      ) : (
        <Card className="card-elevated p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40">
                  <TableHead className="pl-4">ID</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead className="hidden md:table-cell">Chapter / Level</TableHead>
                  <TableHead className="hidden lg:table-cell">Exam / Type</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead className="hidden sm:table-cell">Issued</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="pr-4" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => {
                  const student = students.find((s) => s.id === c.studentId)
                  return (
                    <TableRow key={c.id}>
                      <TableCell className="pl-4 text-xs tabular-nums text-muted-foreground">
                        {c.id}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold ${avatarColorClasses(
                              student?.avatarColor
                            )}`}
                          >
                            {initials(c.studentName)}
                          </div>
                          <span className="text-sm font-medium">{c.studentName}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {c.certificateType === 'level' ? (
                          <Badge variant="secondary" className="gap-1 border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                            <Layers className="h-3 w-3" />
                            {c.levelName ?? c.chapterName}
                          </Badge>
                        ) : (
                          <Badge variant="secondary">{c.chapterName}</Badge>
                        )}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                        {c.certificateType === 'level'
                          ? `Level Completion · ${(c.chapterNames?.length ?? 0)} chapters`
                          : c.examTitle}
                      </TableCell>
                      <TableCell className="text-right tabular-nums font-medium">
                        {c.certificateType === 'level' ? (
                          <span className="text-muted-foreground">—</span>
                        ) : (
                          <span>{c.score}%</span>
                        )}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-xs text-muted-foreground tabular-nums">
                        {c.issuedAt}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            c.status === 'issued'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                          }
                        >
                          <span className="capitalize">{c.status}</span>
                        </Badge>
                      </TableCell>
                      <TableCell className="pr-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuItem
                              onClick={() => printCertificate(c)}
                            >
                              <Download className="h-4 w-4" /> Download
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              variant="destructive"
                              onClick={() => setRevokeTarget(c)}
                            >
                              <Ban className="h-4 w-4" /> Revoke
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Generate dialog */}
      <Dialog open={genOpen} onOpenChange={setGenOpen}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Generate certificate</DialogTitle>
            <DialogDescription>
              {isLevelMode
                ? 'Level / Batch mode — the certificate will list every chapter in the selected level.'
                : 'Pick a student and an exam they passed. Score is auto-filled from their best attempt. Pick a Level / Batch to issue a level completion certificate instead.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="c-student">Student</Label>
              <Select value={genStudent} onValueChange={(v) => { setGenStudent(v); setGenLevel(''); setGenScore('') }}>
                <SelectTrigger id="c-student" className="w-full">
                  <SelectValue placeholder="Select student" />
                </SelectTrigger>
                <SelectContent>
                  {students.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name} — {s.id}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* v3.46.0 — Level / Batch dropdown (optional) */}
            <div className="space-y-2">
              <Label htmlFor="c-level" className="flex items-center justify-between">
                <span>Level / Batch <span className="text-xs font-normal text-muted-foreground">(optional)</span></span>
                {isLevelMode && (
                  <button
                    type="button"
                    onClick={() => { setGenLevel(''); setGenScore('') }}
                    className="text-xs font-medium text-emerald-600 hover:underline dark:text-emerald-400"
                  >
                    Clear · use exam
                  </button>
                )}
              </Label>
              <Select
                value={genLevel}
                onValueChange={(v) => { setGenLevel(v); setGenScore('') }}
                disabled={!selectedStudent || studentLevels.length === 0}
              >
                <SelectTrigger id="c-level" className="w-full">
                  <SelectValue placeholder={
                    !selectedStudent
                      ? 'Select a student first'
                      : studentLevels.length === 0
                      ? 'No levels assigned'
                      : 'None — issue exam certificate'
                  } />
                </SelectTrigger>
                <SelectContent>
                  {studentLevels.map((l) => (
                    <SelectItem key={l.id} value={l.id}>
                      <span className="flex items-center gap-2">
                        <Layers className="h-3.5 w-3.5 text-emerald-500" />
                        {levelLabel(l.levelNumber, l.name)}
                        <span className="text-xs text-muted-foreground">({l.code})</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedStudent && studentLevels.length === 0 && (
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  This student has no Level / Batch assignments.
                </p>
              )}
            </div>

            {/* Exam dropdown — disabled (locked) when a Level is selected */}
            <div className="space-y-2">
              <Label htmlFor="c-exam" className="flex items-center gap-1.5">
                Exam
                {isLevelMode && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    <Lock className="h-3 w-3" /> Locked
                  </span>
                )}
              </Label>
              <Select
                value={isLevelMode ? '' : genExam}
                onValueChange={(v) => { setGenExam(v); setGenScore('') }}
                disabled={isLevelMode}
              >
                <SelectTrigger id="c-exam" className="w-full">
                  <SelectValue placeholder={isLevelMode ? 'Level mode — exam disabled' : 'Select exam'} />
                </SelectTrigger>
                <SelectContent>
                  {exams.map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Score field — hidden in level mode */}
            {!isLevelMode && (
              <div className="space-y-2">
                <Label htmlFor="c-score">Score (%) {suggestedScore && <span className="text-xs text-muted-foreground">· best attempt: {suggestedScore}%</span>}</Label>
                <Input
                  id="c-score"
                  type="number"
                  min={0}
                  max={100}
                  value={genScore || suggestedScore}
                  onChange={(e) => setGenScore(e.target.value)}
                  placeholder={suggestedScore || '0'}
                />
              </div>
            )}

            {/* Preview — adapts to the selected mode */}
            {isLevelMode ? (
              <div className="rounded-xl border bg-gradient-to-br from-emerald-50 to-teal-50 p-5 text-center dark:from-emerald-950/30 dark:to-teal-950/30">
                <div className="flex items-center justify-center gap-2 text-emerald-700 dark:text-emerald-300">
                  <Layers className="h-5 w-5" />
                  <span className="text-xs font-semibold uppercase tracking-wide">
                    Level Completion Certificate
                  </span>
                </div>
                <p className="mt-3 text-xs text-muted-foreground">This is to certify that</p>
                <p className="mt-1 text-lg font-bold text-gradient-brand">
                  {selectedStudent?.name ?? '[Student Name]'}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">has successfully completed</p>
                <p className="mt-1 text-sm font-semibold">
                  {selectedLevelBatch
                    ? selectedLevelBatch.name
                    : '[Level]'}
                </p>
                {selectedLevelChapters.length > 0 && (
                  <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 text-left text-xs text-muted-foreground">
                    {selectedLevelChapters.slice(0, 8).map((c, i) => (
                      <div key={c.id} className="flex items-center gap-1.5 truncate">
                        <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400">{String(i + 1).padStart(2, '0')}</span>
                        <span className="truncate">{c.name}</span>
                      </div>
                    ))}
                    {selectedLevelChapters.length > 8 && (
                      <div className="col-span-2 text-center text-[10px] italic">
                        + {selectedLevelChapters.length - 8} more chapters
                      </div>
                    )}
                  </div>
                )}
                <Separator className="my-3" />
                <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  Verified by Power Maths
                </div>
              </div>
            ) : (
              <div className="rounded-xl border bg-gradient-to-br from-emerald-50 to-teal-50 p-5 text-center dark:from-emerald-950/30 dark:to-teal-950/30">
                <div className="flex items-center justify-center gap-2 text-emerald-700 dark:text-emerald-300">
                  <GraduationCap className="h-5 w-5" />
                  <span className="text-xs font-semibold uppercase tracking-wide">
                    Certificate of completion
                  </span>
                </div>
                <p className="mt-3 text-xs text-muted-foreground">This is to certify that</p>
                <p className="mt-1 text-lg font-bold text-gradient-brand">
                  {selectedStudent?.name ?? '[Student Name]'}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  has successfully completed
                </p>
                <p className="mt-1 text-sm font-semibold">{selectedExam?.title ?? '[Exam Title]'}</p>
                <Separator className="my-3" />
                <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  Verified by Power Maths
                </div>
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setGenOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">
                {isLevelMode ? 'Generate level certificate' : 'Generate certificate'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Revoke confirmation */}
      <AlertDialog open={!!revokeTarget} onOpenChange={(o) => !o && setRevokeTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke certificate?</AlertDialogTitle>
            <AlertDialogDescription>
              Certificate <strong>{revokeTarget?.id}</strong> for {revokeTarget?.studentName} will be marked as revoked. The student will no longer see it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleRevoke}
            >
              Revoke
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function CertificateCard({
  cert,
  delay,
  onRevoke,
  onDownload,
  student,
}: {
  cert: Certificate
  delay: number
  onRevoke: () => void
  onDownload: () => void
  student?: { avatarColor: string }
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
    >
      <Card className="card-elevated relative overflow-hidden p-0">
        {/* Top ribbon */}
        <div className="relative h-16 bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-500 px-4">
          <div className="absolute inset-0 bg-grid opacity-10" aria-hidden />
          <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-white/15 blur-2xl" aria-hidden />
          <div className="relative flex h-full items-center justify-between text-white">
            <div className="flex items-center gap-2">
              {cert.certificateType === 'level' ? (
                <Layers className="h-5 w-5" />
              ) : (
                <GraduationCap className="h-5 w-5" />
              )}
              <div className="leading-tight">
                <div className="text-[10px] uppercase tracking-widest text-emerald-50/80">
                  Power Maths
                </div>
                <div className="text-xs font-semibold">
                  {cert.certificateType === 'level'
                    ? 'Level Completion Certificate'
                    : 'Certificate of Completion'}
                </div>
              </div>
            </div>
            <Badge
              className="bg-white/15 text-white hover:bg-white/25"
              variant="secondary"
            >
              {cert.certificateType === 'level' ? (
                <>
                  <Layers className="h-3 w-3" />
                  {cert.chapterNames?.length ?? 0} ch
                </>
              ) : (
                <>
                  <Award className="h-3 w-3" />
                  {cert.score}%
                </>
              )}
            </Badge>
          </div>
        </div>

        {/* Body */}
        <div className="space-y-2.5 p-4">
          <div className="flex items-center gap-2.5">
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold ${avatarColorClasses(
                student?.avatarColor
              )}`}
            >
              {initials(cert.studentName)}
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold">{cert.studentName}</div>
              <div className="text-xs text-muted-foreground tabular-nums">{cert.id}</div>
            </div>
          </div>

          {cert.certificateType === 'level' ? (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="col-span-2">
                <div className="text-muted-foreground">Level</div>
                <div className="font-medium text-emerald-700 dark:text-emerald-400">
                  {cert.levelName ?? cert.chapterName}
                </div>
              </div>
              <div className="col-span-2">
                <div className="text-muted-foreground">Chapters included</div>
                <div className="font-medium tabular-nums">{cert.chapterNames?.length ?? 0} chapters</div>
                {cert.chapterNames && cert.chapterNames.length > 0 && (
                  <div className="mt-1 line-clamp-2 text-[11px] text-muted-foreground">
                    {cert.chapterNames.join(' · ')}
                  </div>
                )}
              </div>
              <div className="col-span-2">
                <div className="text-muted-foreground">Issued on</div>
                <div className="flex items-center gap-1.5 font-medium tabular-nums">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  {cert.issuedAt}
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <div className="text-muted-foreground">Chapter</div>
                <div className="font-medium">{cert.chapterName}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Score</div>
                <div className="font-medium tabular-nums">{cert.score}%</div>
              </div>
              <div className="col-span-2">
                <div className="text-muted-foreground">Exam</div>
                <div className="line-clamp-1 font-medium">{cert.examTitle}</div>
              </div>
              <div className="col-span-2">
                <div className="text-muted-foreground">Issued on</div>
                <div className="flex items-center gap-1.5 font-medium tabular-nums">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  {cert.issuedAt}
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between gap-2 border-t pt-2.5">
            <Badge
              variant="outline"
              className={
                cert.status === 'issued'
                  ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                  : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
              }
            >
              <span className="capitalize">{cert.status}</span>
            </Badge>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="outline"
                onClick={onDownload}
                disabled={cert.status === 'revoked'}
              >
                <Download className="h-3.5 w-3.5" /> Download
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={onRevoke}
                disabled={cert.status === 'revoked'}
              >
                <Ban className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
