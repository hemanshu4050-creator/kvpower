'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Archive,
  Calendar,
  Megaphone,
  MoreHorizontal,
  Pencil,
  Pin,
  Plus,
  RotateCcw,
  Search,
  Trash2,
  Users,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useDataStore, type Announcement } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'

const priorityDot: Record<Announcement['priority'], string> = {
  high: 'bg-rose-500',
  normal: 'bg-amber-500',
  low: 'bg-zinc-400',
}

const priorityBadge: Record<Announcement['priority'], string> = {
  high: 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
  normal: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  low: 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300',
}

const audienceLabel: Record<Announcement['audience'], string> = {
  all: 'Everyone',
  students: 'Students',
  admins: 'Admins',
}

interface AnnForm {
  id?: string
  title: string
  body: string
  audience: Announcement['audience']
  priority: Announcement['priority']
}

const emptyForm: AnnForm = {
  title: '',
  body: '',
  audience: 'all',
  priority: 'normal',
}

export function AdminAnnouncements() {
  const pageTitle = useNavLabel('announcements', 'Announcements')
  const {
    announcements,
    addAnnouncement,
    updateAnnouncement,
    deleteAnnouncement,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [audience, setAudience] = useState('all-audiences')
  const [priority, setPriority] = useState('all')
  const [status, setStatus] = useState('all')
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [editing, setEditing] = useState<AnnForm>(emptyForm)
  const [deleteTarget, setDeleteTarget] = useState<Announcement | null>(null)

  const filtered = useMemo(() => {
    return announcements.filter((a) => {
      const q = search.trim().toLowerCase()
      if (q && !a.title.toLowerCase().includes(q) && !a.body.toLowerCase().includes(q)) return false
      if (audience !== 'all-audiences' && a.audience !== audience) return false
      if (priority !== 'all' && a.priority !== priority) return false
      if (status !== 'all' && a.status !== status) return false
      return true
    })
  }, [announcements, search, audience, priority, status])

  const openAdd = () => {
    setEditing(emptyForm)
    setAddOpen(true)
  }
  const openEdit = (a: Announcement) => {
    setEditing({ id: a.id, title: a.title, body: a.body, audience: a.audience, priority: a.priority })
    setEditOpen(true)
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.title.trim() || !editing.body.trim()) {
      toast.error('Title and body are required')
      return
    }
    addAnnouncement({
      title: editing.title.trim(),
      body: editing.body.trim(),
      audience: editing.audience,
      priority: editing.priority,
      status: 'active',
      author: 'Prof. Kalpesh Vyas',
    })
    toast.success('Announcement published', { description: editing.title })
    setAddOpen(false)
  }

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    updateAnnouncement(editing.id, {
      title: editing.title.trim(),
      body: editing.body.trim(),
      audience: editing.audience,
      priority: editing.priority,
    })
    toast.success('Announcement updated', { description: editing.title })
    setEditOpen(false)
  }

  const toggleArchive = (a: Announcement) => {
    const next = a.status === 'active' ? 'archived' : 'active'
    updateAnnouncement(a.id, { status: next })
    toast.success(next === 'archived' ? 'Announcement archived' : 'Announcement restored', { description: a.title })
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    deleteAnnouncement(deleteTarget.id)
    toast.error('Announcement deleted', { description: deleteTarget.title })
    setDeleteTarget(null)
  }

  const clearFilters = () => {
    setSearch('')
    setAudience('all-audiences')
    setPriority('all')
    setStatus('all')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Broadcast updates, exam schedules and important notices."
        icon={<Megaphone className="h-5 w-5" />}
        actions={
          <Button onClick={openAdd}>
            <Plus className="h-4 w-4" /> New Announcement
          </Button>
        }
      />

      {/* Filter bar */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search announcements…"
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={audience} onValueChange={setAudience}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Audience" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-audiences">All audiences</SelectItem>
                <SelectItem value="all">Everyone</SelectItem>
                <SelectItem value="students">Students</SelectItem>
                <SelectItem value="admins">Admins</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All priorities</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
            {(search || audience !== 'all-audiences' || priority !== 'all' || status !== 'all') && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* List */}
      {filtered.length === 0 ? (
        <Card className="card-elevated">
          <EmptyState
            icon={Megaphone}
            title="No announcements found"
            description="Adjust your filters or publish a new announcement."
            action={
              <Button variant="outline" onClick={clearFilters}>
                Reset filters
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((a, i) => (
            <motion.div
              key={a.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
            >
              <Card className="card-elevated gap-0 p-5">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="relative mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Megaphone className="h-4 w-4" />
                      <span
                        className={`absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-background ${priorityDot[a.priority]}`}
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-semibold leading-tight">{a.title}</h3>
                        {a.priority === 'high' && (
                          <Pin className="h-3.5 w-3.5 text-rose-500" />
                        )}
                      </div>
                      <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                        {a.body}
                      </p>
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="gap-1">
                          <Users className="h-3 w-3" />
                          {audienceLabel[a.audience]}
                        </Badge>
                        <Badge variant="outline" className={`capitalize ${priorityBadge[a.priority]}`}>
                          {a.priority}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            a.status === 'active'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300'
                          }
                        >
                          <span className="capitalize">{a.status}</span>
                        </Badge>
                      </div>
                      <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                        <span>By {a.author}</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {a.createdAt}
                        </span>
                      </div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-44">
                      <DropdownMenuItem onClick={() => openEdit(a)}>
                        <Pencil className="h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toggleArchive(a)}>
                        {a.status === 'active' ? <Archive className="h-4 w-4" /> : <RotateCcw className="h-4 w-4" />}
                        {a.status === 'active' ? 'Archive' : 'Restore'}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        variant="destructive"
                        onClick={() => setDeleteTarget(a)}
                      >
                        <Trash2 className="h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add / Edit dialog */}
      <AnnouncementFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        mode="add"
      />
      <AnnouncementFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        mode="edit"
      />

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete announcement?</AlertDialogTitle>
            <AlertDialogDescription>
              “{deleteTarget?.title}” will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function AnnouncementFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  mode,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: AnnForm
  setForm: React.Dispatch<React.SetStateAction<AnnForm>>
  onSubmit: (e: React.FormEvent) => void
  mode: 'add' | 'edit'
}) {
  const update = (patch: Partial<AnnForm>) => setForm((p) => ({ ...p, ...patch }))
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'New announcement' : 'Edit announcement'}</DialogTitle>
          <DialogDescription>
            Compose a message and choose who should see it.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="a-title">Title</Label>
            <Input id="a-title" value={form.title} onChange={(e) => update({ title: e.target.value })} placeholder="What is this about?" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-body">Body</Label>
            <Textarea id="a-body" rows={4} value={form.body} onChange={(e) => update({ body: e.target.value })} placeholder="Write the announcement…" required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="a-audience">Audience</Label>
              <Select value={form.audience} onValueChange={(v) => update({ audience: v as Announcement['audience'] })}>
                <SelectTrigger id="a-audience" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Everyone</SelectItem>
                  <SelectItem value="students">Students</SelectItem>
                  <SelectItem value="admins">Admins</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="a-priority">Priority</Label>
              <Select value={form.priority} onValueChange={(v) => update({ priority: v as Announcement['priority'] })}>
                <SelectTrigger id="a-priority" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit">{mode === 'add' ? 'Publish' : 'Save changes'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
