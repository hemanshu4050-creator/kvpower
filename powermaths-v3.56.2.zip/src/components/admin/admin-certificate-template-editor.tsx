'use client'

/**
 * Admin — Certificate Template Editor (v3.29.0).
 *
 * Embedded inside Settings → Certificates. Lets the admin edit every visual
 * aspect of the student Certificate of Achievement: wording, layout,
 * colors, fonts, score-tier thresholds, seal, signature, serial prefix,
 * watermark / corner-flourish / score-badge / date / serial / QR toggles.
 *
 * A live preview (using the SAME `CertificateArtwork` component students see)
 * updates instantly as the admin edits — the preview shows a sample cert
 * (Diya Patel · Number System · 100%) so the admin can see how a real
 * distinction-tier cert looks.
 *
 * Save writes the template to `settings.certificateTemplate` in the store,
 * which is persisted + used by both the on-screen artwork and the print
 * window. Reset restores the default template.
 */

import * as React from 'react'
import {
  Award, RotateCcw, Save, Eye, Printer, Sparkles,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useDataStore, defaultSettings, type CertificateTemplate, type Certificate } from '@/lib/data-store'
import { CertificateArtwork } from '@/components/student/student-certificates'
import { printCertificate } from '@/components/student/student-certificates'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

// Sample certificate used for the live preview — picked to show a
// distinction-tier score (100%) so the admin sees the "best" badge.
const SAMPLE_CERT: Certificate = {
  id: 'PREVIEW',
  studentId: 'STU-PREVIEW',
  studentName: 'Diya Patel',
  chapterName: 'Number System',
  examTitle: 'Number System — Chapter Test',
  score: 100,
  certificateNumber: 'PM-2026-PREVIEW',
  issuedAt: new Date().toISOString().slice(0, 10),
  status: 'issued',
}

const FONT_OPTIONS = [
  'Playfair Display', 'Cormorant Garamond', 'Lora', 'Merriweather',
  'Source Serif Pro', 'EB Garamond', 'Georgia',
]
const BODY_FONT_OPTIONS = [
  'Inter', 'Poppins', 'Source Sans Pro', 'Roboto', 'Open Sans', 'Lato', 'Nunito',
]

// Curated color presets the admin can apply with one click.
const COLOR_PRESETS: Array<{
  name: string
  patch: Partial<Pick<CertificateTemplate,
    'primaryColor' | 'accentColor' | 'backgroundFrom' | 'backgroundVia' | 'backgroundTo' |
    'borderOuterColor' | 'borderInnerColor' | 'nameColor'>>
  swatch: string
}> = [
  {
    name: 'Emerald & Amber (Default)',
    swatch: 'linear-gradient(135deg,#059669 0%,#d97706 100%)',
    patch: {
      primaryColor: '#059669', accentColor: '#d97706', nameColor: '#047857',
      backgroundFrom: '#ecfdf5', backgroundVia: '#ffffff', backgroundTo: '#fffbeb',
      borderOuterColor: '#d97706', borderInnerColor: '#059669',
    },
  },
  {
    name: 'Royal Blue & Gold',
    swatch: 'linear-gradient(135deg,#1e40af 0%,#ca8a04 100%)',
    patch: {
      primaryColor: '#1e40af', accentColor: '#ca8a04', nameColor: '#1e3a8a',
      backgroundFrom: '#eff6ff', backgroundVia: '#ffffff', backgroundTo: '#fefce8',
      borderOuterColor: '#ca8a04', borderInnerColor: '#1e40af',
    },
  },
  {
    name: 'Crimson & Slate',
    swatch: 'linear-gradient(135deg,#b91c1c 0%,#475569 100%)',
    patch: {
      primaryColor: '#b91c1c', accentColor: '#475569', nameColor: '#991b1b',
      backgroundFrom: '#fef2f2', backgroundVia: '#ffffff', backgroundTo: '#f8fafc',
      borderOuterColor: '#475569', borderInnerColor: '#b91c1c',
    },
  },
  {
    name: 'Violet & Rose',
    swatch: 'linear-gradient(135deg,#7c3aed 0%,#e11d48 100%)',
    patch: {
      primaryColor: '#7c3aed', accentColor: '#e11d48', nameColor: '#6d28d9',
      backgroundFrom: '#f5f3ff', backgroundVia: '#ffffff', backgroundTo: '#fff1f2',
      borderOuterColor: '#e11d48', borderInnerColor: '#7c3aed',
    },
  },
  {
    name: 'Forest & Bronze',
    swatch: 'linear-gradient(135deg,#166534 0%,#92400e 100%)',
    patch: {
      primaryColor: '#166534', accentColor: '#92400e', nameColor: '#14532d',
      backgroundFrom: '#f0fdf4', backgroundVia: '#ffffff', backgroundTo: '#fef3c7',
      borderOuterColor: '#92400e', borderInnerColor: '#166534',
    },
  },
  {
    name: 'Midnight & Teal',
    swatch: 'linear-gradient(135deg,#0f172a 0%,#0d9488 100%)',
    patch: {
      primaryColor: '#0f172a', accentColor: '#0d9488', nameColor: '#0f766e',
      backgroundFrom: '#f8fafc', backgroundVia: '#ffffff', backgroundTo: '#f0fdfa',
      borderOuterColor: '#0d9488', borderInnerColor: '#0f172a',
    },
  },
]

export function AdminCertificateTemplateEditor({ variant = 'inline' }: { variant?: 'inline' | 'standalone' }) {
  const settings = useDataStore((s) => s.settings)
  const updateSettings = useDataStore((s) => s.updateSettings)

  // Local editable copy — saved to the store on "Save changes".
  const [draft, setDraft] = React.useState<CertificateTemplate>(
    settings.certificateTemplate ?? defaultSettings.certificateTemplate,
  )

  // Re-sync from store when the store value changes externally (e.g. reset).
  React.useEffect(() => {
    setDraft(settings.certificateTemplate ?? defaultSettings.certificateTemplate)
  }, [settings.certificateTemplate])

  const patch = (p: Partial<CertificateTemplate>) => setDraft((d) => ({ ...d, ...p }))

  const handleSave = () => {
    updateSettings({ certificateTemplate: draft })
    toast.success('Certificate template saved', {
      description: 'New certificates will use this design immediately.',
    })
  }

  const handleReset = () => {
    setDraft(defaultSettings.certificateTemplate)
    updateSettings({ certificateTemplate: defaultSettings.certificateTemplate })
    toast.success('Template reset to default', {
      description: 'The Power Maths default certificate design has been restored.',
    })
  }

  const handlePrintSample = () => {
    // Use the draft (not the saved store) so the admin can print their
    // unsaved edits to compare side-by-side.
    if (typeof window === 'undefined') return
    const printWin = window.open('', '_blank', 'width=900,height=650')
    if (!printWin) {
      toast.error('Pop-up blocked', { description: 'Allow pop-ups to print the sample certificate.' })
      return
    }
    // Lazy-load the HTML builder so we don't pull it into the bundle until needed.
    import('@/lib/certificate-template').then(({ buildCertificateHtml }) => {
      printWin.document.write(buildCertificateHtml({ cert: SAMPLE_CERT, template: draft }))
      printWin.document.close()
      toast.success('Opening print preview…', { description: 'Sample certificate with your current edits.' })
    })
  }

  return (
    <div className={cn(variant === 'standalone' && 'space-y-4')}>
      <Tabs defaultValue="design" className="gap-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="design"><Sparkles className="mr-1.5 h-4 w-4" /> Design</TabsTrigger>
          <TabsTrigger value="preview"><Eye className="mr-1.5 h-4 w-4" /> Live Preview</TabsTrigger>
        </TabsList>

        {/* ─── Design tab ─── */}
        <TabsContent value="design" className="mt-4 space-y-4">
          {/* Color presets */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Award className="h-4 w-4 text-primary" /> Color presets
              </CardTitle>
              <CardDescription>Apply a curated palette in one click, then fine-tune below.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {COLOR_PRESETS.map((p) => {
                  const active =
                    draft.primaryColor === p.patch.primaryColor &&
                    draft.accentColor === p.patch.accentColor
                  return (
                    <button
                      key={p.name}
                      onClick={() => patch(p.patch)}
                      className={cn(
                        'group relative overflow-hidden rounded-lg border p-3 text-left transition-all hover:shadow-md',
                        active ? 'border-primary ring-2 ring-primary/30' : 'border-border',
                      )}
                    >
                      <div className="mb-2 h-8 w-full rounded" style={{ background: p.swatch }} />
                      <p className="text-xs font-medium leading-tight">{p.name}</p>
                      {active && (
                        <span className="absolute right-2 top-2 rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">
                          Active
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Wording */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="text-base">Wording</CardTitle>
              <CardDescription>The text shown on every certificate.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Certificate title</Label>
                  <Input value={draft.title} onChange={(e) => patch({ title: e.target.value })} placeholder="Certificate of Achievement" />
                </div>
                <div className="space-y-2">
                  <Label>Subtitle</Label>
                  <Input value={draft.subtitle} onChange={(e) => patch({ subtitle: e.target.value })} placeholder="This certificate is proudly presented to" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Completion line</Label>
                <Input value={draft.completionLine} onChange={(e) => patch({ completionLine: e.target.value })} placeholder="has successfully completed" />
                <p className="text-xs text-muted-foreground">Shown between the student name and the chapter name. The chapter name follows this line.</p>
              </div>
              <Separator />
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Brand name</Label>
                  <Input value={draft.brandName} onChange={(e) => patch({ brandName: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Brand subtitle</Label>
                  <Input value={draft.brandSub} onChange={(e) => patch({ brandSub: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Instructor name</Label>
                  <Input value={draft.instructorName} onChange={(e) => patch({ instructorName: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Instructor title</Label>
                  <Input value={draft.instructorTitle} onChange={(e) => patch({ instructorTitle: e.target.value })} />
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label>Seal emoji</Label>
                  <Input value={draft.sealEmoji} onChange={(e) => patch({ sealEmoji: e.target.value })} maxLength={4} />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label>Seal text</Label>
                  <Input value={draft.sealText} onChange={(e) => patch({ sealText: e.target.value })} placeholder="SEAL OF EXCELLENCE" />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Serial prefix</Label>
                  <Input value={draft.serialPrefix} onChange={(e) => patch({ serialPrefix: e.target.value })} placeholder="PM-" />
                  <p className="text-xs text-muted-foreground">New certificate numbers become <code className="rounded bg-muted px-1">{draft.serialPrefix || 'PM-'}2026-0008</code></p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Layout & toggles */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="text-base">Layout &amp; elements</CardTitle>
              <CardDescription>Choose the border style and which decorative elements to show.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1">
              <div className="space-y-2 py-2">
                <Label>Border style</Label>
                <Select value={draft.layout} onValueChange={(v) => patch({ layout: v as CertificateTemplate['layout'] })}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="classic">Classic — ornate double border + corners</SelectItem>
                    <SelectItem value="modern">Modern — single clean frame</SelectItem>
                    <SelectItem value="minimal">Minimal — no border</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <ToggleRow label="Central watermark" description="Faint graduation-cap watermark behind the text" checked={draft.showWatermark} onChange={(v) => patch({ showWatermark: v })} />
              <ToggleRow label="Corner flourishes" description="Decorative L-shaped corners (classic layout only)" checked={draft.showCornerFlourishes} onChange={(v) => patch({ showCornerFlourishes: v })} />
              <ToggleRow label="Score badge" description="Distinction / Merit / Passed pill below the chapter name" checked={draft.showScoreBadge} onChange={(v) => patch({ showScoreBadge: v })} />
              <ToggleRow label="Issue date" description="Date issued in the bottom-left footer" checked={draft.showDate} onChange={(v) => patch({ showDate: v })} />
              <ToggleRow label="Serial number" description="Certificate serial at the very bottom" checked={draft.showSerial} onChange={(v) => patch({ showSerial: v })} />
              <ToggleRow label="QR code" description="Placeholder QR for verification (bottom-center)" checked={draft.showQrCode} onChange={(v) => patch({ showQrCode: v })} />
            </CardContent>
          </Card>

          {/* Score tiers */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="text-base">Score-tier thresholds</CardTitle>
              <CardDescription>Percentage cutoffs for the Distinction and Merit badges.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Distinction ≥ (%)</Label>
                <Input type="number" min={0} max={100} value={draft.distinctionThreshold} onChange={(e) => patch({ distinctionThreshold: Number(e.target.value) })} />
              </div>
              <div className="space-y-2">
                <Label>Merit ≥ (%)</Label>
                <Input type="number" min={0} max={100} value={draft.meritThreshold} onChange={(e) => patch({ meritThreshold: Number(e.target.value) })} />
              </div>
            </CardContent>
          </Card>

          {/* Colors */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="text-base">Colors</CardTitle>
              <CardDescription>Hex color strings. Use the presets above for quick start.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <ColorField label="Primary" value={draft.primaryColor} onChange={(v) => patch({ primaryColor: v })} />
                <ColorField label="Accent" value={draft.accentColor} onChange={(v) => patch({ accentColor: v })} />
                <ColorField label="Text" value={draft.textColor} onChange={(v) => patch({ textColor: v })} />
                <ColorField label="Student name" value={draft.nameColor} onChange={(v) => patch({ nameColor: v })} />
                <ColorField label="Border (outer)" value={draft.borderOuterColor} onChange={(v) => patch({ borderOuterColor: v })} />
                <ColorField label="Border (inner)" value={draft.borderInnerColor} onChange={(v) => patch({ borderInnerColor: v })} />
              </div>
              <Separator />
              <p className="text-xs font-medium text-muted-foreground">Background gradient (top → middle → bottom)</p>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <ColorField label="Background from" value={draft.backgroundFrom} onChange={(v) => patch({ backgroundFrom: v })} />
                <ColorField label="Background via" value={draft.backgroundVia} onChange={(v) => patch({ backgroundVia: v })} />
                <ColorField label="Background to" value={draft.backgroundTo} onChange={(v) => patch({ backgroundTo: v })} />
              </div>
            </CardContent>
          </Card>

          {/* Typography */}
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="text-base">Typography</CardTitle>
              <CardDescription>Fonts are loaded from Google Fonts in the print window.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Title font (serif display)</Label>
                <Select value={draft.titleFont} onValueChange={(v) => patch({ titleFont: v })}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {FONT_OPTIONS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Body font (sans)</Label>
                <Select value={draft.bodyFont} onValueChange={(v) => patch({ bodyFont: v })}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {BODY_FONT_OPTIONS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Save row */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-muted/30 p-3">
            <p className="text-xs text-muted-foreground">
              Changes apply to all new and existing certificates the next time they are viewed or printed.
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RotateCcw className="h-4 w-4" /> Reset to default
              </Button>
              <Button size="sm" onClick={handleSave}>
                <Save className="h-4 w-4" /> Save template
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* ─── Live Preview tab ─── */}
        <TabsContent value="preview" className="mt-4 space-y-4">
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Eye className="h-4 w-4 text-primary" /> Live preview
              </CardTitle>
              <CardDescription>
                Sample certificate rendered with your current edits — exactly what the student sees.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div
                className="mx-auto aspect-[1.414/1] w-full max-w-2xl overflow-hidden rounded-lg shadow-xl"
                style={{
                  background: `linear-gradient(135deg, ${draft.backgroundFrom} 0%, ${draft.backgroundVia} 50%, ${draft.backgroundTo} 100%)`,
                }}
              >
                <CertificateArtwork cert={SAMPLE_CERT} template={draft} />
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2">
                <Button variant="outline" size="sm" onClick={handlePrintSample}>
                  <Printer className="h-4 w-4" /> Print sample
                </Button>
                <Button variant="outline" size="sm" onClick={() => {
                  // Toggle the sample score between tiers so the admin can
                  // see all three badges (Distinction / Merit / Passed).
                  const next = SAMPLE_CERT.score >= 90 ? 80 : SAMPLE_CERT.score >= 75 ? 60 : 100
                  SAMPLE_CERT.score = next
                  // Force a re-render by toggling draft identity.
                  setDraft((d) => ({ ...d }))
                }}>
                  <Sparkles className="h-4 w-4" /> Cycle sample score ({SAMPLE_CERT.score}%)
                </Button>
              </div>
              <p className="text-center text-xs text-muted-foreground">
                Showing sample: {SAMPLE_CERT.studentName} · {SAMPLE_CERT.chapterName} · {SAMPLE_CERT.score}%
              </p>
            </CardContent>
          </Card>

          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-muted/30 p-3">
            <p className="text-xs text-muted-foreground">
              Happy with the design? Save it to apply to every certificate.
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RotateCcw className="h-4 w-4" /> Reset to default
              </Button>
              <Button size="sm" onClick={handleSave}>
                <Save className="h-4 w-4" /> Save template
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ─────────────────────────── Sub-components ───────────────────────────

function ToggleRow({
  label, description, checked, onChange,
}: {
  label: string
  description: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-lg px-1 py-2.5">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  )
}

function ColorField({
  label, value, onChange,
}: {
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value.startsWith('#') ? value : '#000000'}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-12 shrink-0 cursor-pointer rounded border bg-transparent"
          aria-label={`${label} color picker`}
        />
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 font-mono text-xs"
        />
      </div>
    </div>
  )
}

// Re-export printCertificate so the Settings page can print a real cert if
// ever needed (currently used internally for the sample print).
export { printCertificate }
