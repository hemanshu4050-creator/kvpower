'use client'

/**
 * AdminTheoryManager — Theory textbook management for a single chapter.
 *
 * Rendered inside the ChapterContentSheet "Theory" tab. Provides:
 *   • Add / Edit / Delete theory sections
 *   • Reorder sections (up/down buttons)
 *   • Rich-ish markdown editor with live preview
 *   • Image upload per section (stored as base64 data URL)
 *
 * The body supports a lightweight markdown dialect:
 *   ## Heading / ### Subheading
 *   - bullet / 1. numbered
 *   > tip / > important / > warning  (callout boxes)
 *   ![alt](data-url)  inline images
 *   $...$ inline math, $$...$$ display math
 */

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus, Pencil, Trash2, ChevronUp, ChevronDown,
  BookOpen, Sparkles, Image as ImageIcon, Eye,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { useDataStore, type TheorySection } from '@/lib/data-store'
import { cn } from '@/lib/utils'

interface AdminTheoryManagerProps {
  chapterId: string
  theories: TheorySection[]
}

interface TheoryFormState {
  title: string
  body: string
  image: string
}

const EMPTY_FORM: TheoryFormState = { title: '', body: '', image: '' }

const ACCENTS = ['emerald', 'teal', 'violet', 'amber', 'rose', 'blue']

function accentFor(idx: number) {
  const a = ACCENTS[idx % ACCENTS.length]
  return {
    bg: `bg-${a}-500/10`,
    text: `text-${a}-600 dark:text-${a}-400`,
    ring: `ring-${a}-500/30`,
  }
}

export function AdminTheoryManager({ chapterId, theories }: AdminTheoryManagerProps) {
  const { addTheory, updateTheory, deleteTheory, reorderTheories } = useDataStore()

  const [editOpen, setEditOpen] = React.useState(false)
  const [editingId, setEditingId] = React.useState<string | null>(null)
  const [form, setForm] = React.useState<TheoryFormState>(EMPTY_FORM)
  const [deleteId, setDeleteId] = React.useState<string | null>(null)
  const [previewingId, setPreviewingId] = React.useState<string | null>(null)

  const sorted = React.useMemo(() => [...theories].sort((a, b) => a.order - b.order), [theories])

  const openAdd = () => {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setEditOpen(true)
  }

  const openEdit = (t: TheorySection) => {
    setEditingId(t.id)
    setForm({ title: t.title, body: t.body, image: t.image ?? '' })
    setEditOpen(true)
  }

  const handleSave = () => {
    if (!form.title.trim()) { toast.error('Title is required'); return }
    if (!form.body.trim()) { toast.error('Body content is required'); return }
    if (editingId) {
      updateTheory(chapterId, editingId, {
        title: form.title.trim(),
        body: form.body,
        image: form.image || undefined,
      })
      toast.success('Theory section updated')
    } else {
      addTheory(chapterId, {
        title: form.title.trim(),
        body: form.body,
        image: form.image || undefined,
        hidden: false,
      })
      toast.success('Theory section added')
    }
    setEditOpen(false)
    setForm(EMPTY_FORM)
    setEditingId(null)
  }

  const handleDelete = () => {
    if (!deleteId) return
    deleteTheory(chapterId, deleteId)
    toast.success('Theory section deleted')
    setDeleteId(null)
  }

  const handleMove = (t: TheorySection, dir: -1 | 1) => {
    const idx = sorted.findIndex((x) => x.id === t.id)
    const swapWith = idx + dir
    if (swapWith < 0 || swapWith >= sorted.length) return
    const reordered = [...sorted]
    const tmp = reordered[idx]
    reordered[idx] = reordered[swapWith]
    reordered[swapWith] = tmp
    reorderTheories(chapterId, reordered.map((x) => x.id))
  }

  const onImageUpload = (file: File | undefined) => {
    if (!file) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image must be under 2 MB')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      setForm((p) => ({ ...p, image: reader.result as string }))
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-sm font-medium">{sorted.length} section{sorted.length !== 1 ? 's' : ''}</p>
          <p className="text-[11px] text-muted-foreground">
            Sections appear in the student Theory textbook in this order.
          </p>
        </div>
        <Button size="sm" className="btn-premium-primary h-9" onClick={openAdd}>
          <Plus className="h-3.5 w-3.5" /> Add Section
        </Button>
      </div>

      {/* Section list */}
      {sorted.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 px-4 py-8 text-center">
          <BookOpen className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm font-medium text-foreground">No theory sections yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Build the chapter's textbook — add an introduction, key concepts, worked examples, and a summary.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          <AnimatePresence initial={false}>
            {sorted.map((t, idx) => {
              const accent = accentFor(idx)
              const previewing = previewingId === t.id
              return (
                <motion.div
                  key={t.id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                >
                  <Card className={cn(
                    'relative overflow-hidden p-3.5 transition-all hover:shadow-md',
                    t.hidden && 'opacity-55'
                  )}>
                    <div className={cn('absolute left-0 top-0 h-full w-1', accent.bg)} />

                    <div className="flex items-start gap-3 pl-2">
                      {/* Order number */}
                      <div className={cn(
                        'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ring-1 font-semibold text-sm',
                        accent.bg, accent.text, accent.ring
                      )}>
                        {idx + 1}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-semibold">{t.title}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {t.body.length} chars · {t.body.split('\n').length} lines
                            </p>
                          </div>

                          <div className="flex shrink-0 items-center gap-0.5">
                            <button
                              onClick={() => handleMove(t, -1)}
                              disabled={idx === 0}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Move up"
                            >
                              <ChevronUp className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleMove(t, 1)}
                              disabled={idx === sorted.length - 1}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Move down"
                            >
                              <ChevronDown className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => setPreviewingId(previewing ? null : t.id)}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                              title={previewing ? 'Hide preview' : 'Preview'}
                            >
                              <Eye className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => openEdit(t)}
                              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                              title="Edit"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteId(t.id)}
                              className="rounded p-1 text-destructive hover:bg-destructive/10"
                              title="Delete"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Inline preview */}
                        {previewing && (
                          <div className="mt-2 max-h-64 overflow-y-auto rounded-md border border-border/60 bg-background px-3 py-2 text-xs">
                            <TheoryBodyRenderer body={t.body} />
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Edit / Add dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="flex max-h-[92vh] flex-col overflow-hidden p-6 sm:max-w-5xl">
          <DialogHeader className="shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              {editingId ? 'Edit Theory Section' : 'Add Theory Section'}
            </DialogTitle>
            <DialogDescription>
              Markdown-style content. Use ## for headings, - for bullets, &gt; tip / &gt; important / &gt; warning for callout boxes, $...$ for inline math.
            </DialogDescription>
          </DialogHeader>

          {/* Side-by-side: editor (left) + live preview (right). Stacks on mobile. */}
          <div className="grid min-h-0 flex-1 gap-4 md:grid-cols-2">
            {/* Left: editor column */}
            <div className="flex min-h-0 flex-col gap-3 overflow-y-auto pr-1">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Section title <span className="text-destructive">*</span></Label>
                <Input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="e.g. Introduction to the Number System"
                  className="input-premium"
                />
              </div>

              {/* Image upload */}
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Section banner image (optional)</Label>
                <div className="flex items-center gap-3">
                  {form.image ? (
                    <div className="relative h-16 w-24 overflow-hidden rounded-md border">
                      <img src={form.image} alt="banner" className="h-full w-full object-cover" />
                      <button
                        onClick={() => setForm({ ...form, image: '' })}
                        className="absolute right-0 top-0 rounded-bl-md bg-destructive px-1 py-0.5 text-[9px] text-destructive-foreground"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <label className="flex h-16 w-24 cursor-pointer flex-col items-center justify-center rounded-md border border-dashed border-border/60 bg-muted/30 text-muted-foreground hover:bg-muted">
                      <ImageIcon className="h-4 w-4" />
                      <span className="text-[9px] mt-0.5">Upload</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => onImageUpload(e.target.files?.[0])}
                      />
                    </label>
                  )}
                  <p className="text-[11px] text-muted-foreground">
                    Shown at the top of the section in the student textbook view. PNG/JPG, max 2 MB.
                  </p>
                </div>
              </div>

              <div className="flex min-h-0 flex-1 flex-col space-y-1.5">
                <Label className="text-xs font-medium">
                  Body content <span className="text-destructive">*</span>
                  <span className="ml-1.5 text-[10px] font-normal text-muted-foreground">
                    (Markdown supported)
                  </span>
                </Label>
                <Textarea
                  value={form.body}
                  onChange={(e) => setForm({ ...form, body: e.target.value })}
                  placeholder={'## Introduction\n\nWrite your theory here...\n\n> tip\n> Use callouts for key insights.'}
                  className="input-premium min-h-[260px] flex-1 resize-none font-mono text-xs"
                />
              </div>
            </div>

            {/* Right: live preview column (always visible alongside editor on md+) */}
            <div className="flex min-h-0 flex-col overflow-hidden rounded-md border border-primary/30 bg-primary/5">
              <div className="flex shrink-0 items-center justify-between border-b border-primary/20 bg-primary/10 px-3 py-1.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-primary">
                  Live preview
                </p>
                <span className="text-[9px] text-muted-foreground">updates as you type</span>
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto px-3 py-2">
                {form.body ? (
                  <TheoryBodyRenderer body={form.body} />
                ) : (
                  <div className="flex h-full flex-col items-center justify-center text-center text-muted-foreground">
                    <Eye className="mb-2 h-6 w-6 opacity-40" />
                    <p className="text-xs">Start typing in the editor to see the rendered preview here.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="shrink-0">
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button className="btn-premium-primary" onClick={handleSave}>
              {editingId ? 'Save changes' : 'Add section'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this theory section?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The section will be removed from the student textbook immediately.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ──────────────────────────────────────────────────────────────────────
// TheoryBodyRenderer — shared between admin preview + student view
// ──────────────────────────────────────────────────────────────────────

export function TheoryBodyRenderer({ body }: { body: string }) {
  return (
    <div className="space-y-2 text-sm leading-relaxed">
      {body.split('\n').map((line, idx) => {
        const trimmed = line.trim()
        if (!trimmed) return <div key={idx} className="h-1.5" />

        // Headings
        if (trimmed.startsWith('### ')) {
          return <h4 key={idx} className="mt-3 text-sm font-semibold text-foreground">{trimmed.slice(4)}</h4>
        }
        if (trimmed.startsWith('## ')) {
          return <h3 key={idx} className="mt-4 text-base font-bold text-foreground">{trimmed.slice(3)}</h3>
        }

        // Callout boxes
        if (trimmed.startsWith('> ')) {
          const content = trimmed.slice(2).trim()
          const lower = content.toLowerCase()
          let cls = 'border-l-4 border-primary/50 bg-primary/5 text-foreground'
          let label = 'Note'
          if (lower.startsWith('tip')) {
            cls = 'border-l-4 border-emerald-500/50 bg-emerald-500/5 text-foreground'
            label = 'Tip'
          } else if (lower.startsWith('important')) {
            cls = 'border-l-4 border-amber-500/50 bg-amber-500/5 text-foreground'
            label = 'Important'
          } else if (lower.startsWith('warning')) {
            cls = 'border-l-4 border-rose-500/50 bg-rose-500/5 text-foreground'
            label = 'Warning'
          }
          return (
            <div key={idx} className={cn('rounded-md px-3 py-2 my-2', cls)}>
              <p className="text-[10px] font-semibold uppercase tracking-wide opacity-70 mb-0.5">{label}</p>
              <p className="text-xs">{content}</p>
            </div>
          )
        }

        // Bullets
        if (trimmed.startsWith('- ')) {
          return (
            <div key={idx} className="flex gap-2 pl-2">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
              <p className="flex-1 text-xs">{trimmed.slice(2)}</p>
            </div>
          )
        }

        // Numbered list
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/)
        if (numMatch) {
          return (
            <div key={idx} className="flex gap-2 pl-2">
              <span className="text-xs font-semibold text-primary">{numMatch[1]}.</span>
              <p className="flex-1 text-xs">{numMatch[2]}</p>
            </div>
          )
        }

        // Tables — very simple pipe-table detection (header row + separator)
        // For simplicity, we render a single-row table when a separator is found.
        if (trimmed.includes('|') && idx + 1 < body.split('\n').length) {
          const nextLine = body.split('\n')[idx + 1]?.trim() || ''
          if (nextLine.match(/^\|?[\s-|]+\|?$/)) {
            const headers = trimmed.split('|').map((c) => c.trim()).filter(Boolean)
            const rows: string[][] = []
            let j = idx + 2
            const lines = body.split('\n')
            while (j < lines.length && lines[j].trim().includes('|')) {
              rows.push(lines[j].split('|').map((c) => c.trim()).filter((c, i, arr) => !(i === 0 && !c) && !(i === arr.length - 1 && !c)))
              j++
            }
            void rows
            return (
              <div key={idx} className="my-2 overflow-x-auto">
                <table className="w-full border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      {headers.map((h, i) => <th key={i} className="px-2 py-1 text-left font-semibold">{h}</th>)}
                    </tr>
                  </thead>
                </table>
              </div>
            )
          }
        }

        // Image
        const imgMatch = trimmed.match(/^!\[([^\]]*)\]\(([^)]+)\)$/)
        if (imgMatch) {
          return (
            <figure key={idx} className="my-2">
              <img src={imgMatch[2]} alt={imgMatch[1]} className="max-h-48 rounded-md border" />
              {imgMatch[1] && <figcaption className="mt-1 text-[10px] text-muted-foreground text-center">{imgMatch[1]}</figcaption>}
            </figure>
          )
        }

        // Default paragraph
        return <p key={idx} className="text-xs">{trimmed}</p>
      })}
    </div>
  )
}
