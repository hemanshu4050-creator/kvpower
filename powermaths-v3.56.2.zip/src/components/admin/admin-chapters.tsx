'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  BookOpen,
  Box,
  Brain,
  ChevronLeft,
  ChevronRight,
  Copy,
  FileCheck2,
  FileText,
  FolderTree,
  Hash,
  LayoutGrid,
  Layers,
  Lightbulb,
  List as ListIcon,
  MoreHorizontal,
  Pencil,
  Plus,
  RefreshCw,
  Rows3,
  Search,
  Sigma,
  Sparkles,
  Trash2,
  Triangle,
  Compass,
  BarChart3,
  Upload,
  Users,
  X,
  FileStack,
  GraduationCap,
  ClipboardCheck,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  Download,
  Eye,
  EyeOff,
  GripVertical,
  LayoutPanelTop,
  Check,
  RotateCcw,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useDataStore, type Chapter, type UploadedFile, type ContentTab, resolveContentTabs, resolveTabLabel, DEFAULT_TAB_LABELS, type Exam } from '@/lib/data-store'
// v3.53.2 — reuse the exact same create-exam dialog inside Manage Content
// so the admin can add an exam to the current chapter without navigating
// to the Exams page.
import { ExamFormDialog, emptyExamForm, type ExamForm } from '@/components/admin/admin-exams'
import { useNavLabel } from '@/lib/nav-helpers'
import { avatarColorClasses, getChapterIcon } from './lib/helpers'
import { AdminFormulaManager } from './admin-formula-manager'
import { AdminTheoryManager } from './admin-theory-manager'

// ────────────────────────────────────────────────────────────────────────────
//  Constants & types
// ────────────────────────────────────────────────────────────────────────────

const iconOptions = [
  { key: 'Hash', Icon: Hash },
  { key: 'Sigma', Icon: Sigma },
  { key: 'Triangle', Icon: Triangle },
  { key: 'Compass', Icon: Compass },
  { key: 'Box', Icon: Box },
  { key: 'BarChart3', Icon: BarChart3 },
  { key: 'BookOpen', Icon: BookOpen },
  { key: 'Layers', Icon: Layers },
  // v3.54.1 — 3 new chapter icons for the real curriculum
  { key: 'Brain', Icon: Brain },
  { key: 'Lightbulb', Icon: Lightbulb },
  { key: 'Sparkles', Icon: Sparkles },
] as const

const chapterAccentMap: Record<string, { ring: string; bg: string; text: string; gradient: string }> = {
  Hash: {
    ring: 'ring-emerald-500/30',
    bg: 'bg-gradient-to-br from-emerald-500/20 to-emerald-500/5',
    text: 'text-emerald-600 dark:text-emerald-400',
    gradient: 'from-emerald-500/15 via-emerald-500/5 to-transparent',
  },
  Sigma: {
    ring: 'ring-violet-500/30',
    bg: 'bg-gradient-to-br from-violet-500/20 to-violet-500/5',
    text: 'text-violet-600 dark:text-violet-400',
    gradient: 'from-violet-500/15 via-violet-500/5 to-transparent',
  },
  Triangle: {
    ring: 'ring-amber-500/30',
    bg: 'bg-gradient-to-br from-amber-500/20 to-amber-500/5',
    text: 'text-amber-600 dark:text-amber-400',
    gradient: 'from-amber-500/15 via-amber-500/5 to-transparent',
  },
  Compass: {
    ring: 'ring-sky-500/30',
    bg: 'bg-gradient-to-br from-sky-500/20 to-sky-500/5',
    text: 'text-sky-600 dark:text-sky-400',
    gradient: 'from-sky-500/15 via-sky-500/5 to-transparent',
  },
  Box: {
    ring: 'ring-rose-500/30',
    bg: 'bg-gradient-to-br from-rose-500/20 to-rose-500/5',
    text: 'text-rose-600 dark:text-rose-400',
    gradient: 'from-rose-500/15 via-rose-500/5 to-transparent',
  },
  BarChart3: {
    ring: 'ring-teal-500/30',
    bg: 'bg-gradient-to-br from-teal-500/20 to-teal-500/5',
    text: 'text-teal-600 dark:text-teal-400',
    gradient: 'from-teal-500/15 via-teal-500/5 to-transparent',
  },
  BookOpen: {
    ring: 'ring-orange-500/30',
    bg: 'bg-gradient-to-br from-orange-500/20 to-orange-500/5',
    text: 'text-orange-600 dark:text-orange-400',
    gradient: 'from-orange-500/15 via-orange-500/5 to-transparent',
  },
  Layers: {
    ring: 'ring-fuchsia-500/30',
    bg: 'bg-gradient-to-br from-fuchsia-500/20 to-fuchsia-500/5',
    text: 'text-fuchsia-600 dark:text-fuchsia-400',
    gradient: 'from-fuchsia-500/15 via-fuchsia-500/5 to-transparent',
  },
  // v3.54.1 — 3 new chapter icons for the real curriculum
  Brain: {
    ring: 'ring-pink-500/30',
    bg: 'bg-gradient-to-br from-pink-500/20 to-pink-500/5',
    text: 'text-pink-600 dark:text-pink-400',
    gradient: 'from-pink-500/15 via-pink-500/5 to-transparent',
  },
  Lightbulb: {
    ring: 'ring-yellow-500/30',
    bg: 'bg-gradient-to-br from-yellow-500/20 to-yellow-500/5',
    text: 'text-yellow-600 dark:text-yellow-400',
    gradient: 'from-yellow-500/15 via-yellow-500/5 to-transparent',
  },
  Sparkles: {
    ring: 'ring-cyan-500/30',
    bg: 'bg-gradient-to-br from-cyan-500/20 to-cyan-500/5',
    text: 'text-cyan-600 dark:text-cyan-400',
    gradient: 'from-cyan-500/15 via-cyan-500/5 to-transparent',
  },
}

function accentFor(icon: string) {
  return chapterAccentMap[icon] ?? chapterAccentMap.Hash
}

interface ChapterForm {
  id?: string
  name: string
  description: string
  icon: string
  status: Chapter['status']
  // v3.55.0 — soft tag for Level filter (Option A: filtering only)
  batchId?: string
}

const emptyChapter: ChapterForm = {
  name: '',
  description: '',
  icon: 'BookOpen',
  status: 'active',
  batchId: undefined,
}

// ────────────────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────────────────

/** Animated count-up number. */
function AnimatedNumber({ value, duration = 600 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const from = display
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (value - from) * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value])
  return <span className="tabular-nums">{display}</span>
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminChapters() {
  const pageTitle = useNavLabel('chapters', 'Chapters')
  const {
    chapters,
    students,
    results,
    addChapter,
    updateChapter,
    deleteChapter,
    addStudyMaterial,
    updateStudyMaterial,
    deleteStudyMaterial,
    reorderStudyMaterials,
    addPracticeSheet,
    updatePracticeSheet,
    deletePracticeSheet,
    reorderPracticeSheets,
    updateChapterContentTabs,
    // v3.53.2 — exam management inside Manage Content >> Exams tab
    exams,
    questions,
    addExam,
    updateExam,
    // v3.55.0 — batches for the Level filter + chapter form Level picker
    batches,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  // v3.55.0 — Level filter for the Chapters page
  const [levelFilter, setLevelFilter] = useState('all')
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(8)
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  // v3.13.0 — Manage Content is now a FULL-PAGE view (not a slide-in Sheet).
  // `manageContentId` holds the id of the chapter currently being managed.
  // When set, AdminChapters short-circuits and renders the full-page
  // AdminChapterContentManager instead of the chapters list.
  const [manageContentId, setManageContentId] = useState<string | null>(null)
  const [editing, setEditing] = useState<ChapterForm>(emptyChapter)
  const [deleteTarget, setDeleteTarget] = useState<Chapter | null>(null)
  const [newMaterialTitle, setNewMaterialTitle] = useState('')
  const [newSheetTitle, setNewSheetTitle] = useState('')
  const [newMaterialFile, setNewMaterialFile] = useState<UploadedFile | null>(null)
  const [newWorksheetFile, setNewWorksheetFile] = useState<UploadedFile | null>(null)
  const [newSolutionFile, setNewSolutionFile] = useState<UploadedFile | null>(null)
  const [lastSync, setLastSync] = useState(() => new Date())

  const resetContentStaging = () => {
    setNewMaterialTitle('')
    setNewSheetTitle('')
    setNewMaterialFile(null)
    setNewWorksheetFile(null)
    setNewSolutionFile(null)
  }

  const activeChapter = manageContentId ? chapters.find((c) => c.id === manageContentId) ?? null : null

  const filtered = useMemo(() => {
    return chapters
      .filter((c) => {
        const q = search.trim().toLowerCase()
        if (q && !c.name.toLowerCase().includes(q) && !c.description.toLowerCase().includes(q)) return false
        if (statusFilter !== 'all' && c.status !== statusFilter) return false
        // v3.55.0 — Level filter (soft tag on chapter.batchId)
        if (levelFilter !== 'all' && c.batchId !== levelFilter) return false
        return true
      })
      .sort((a, b) => a.order - b.order)
  }, [chapters, search, statusFilter, levelFilter])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const enrolledCount = (chId: string) =>
    students.filter((s) => s.assignedChapters.includes(chId)).length

  const enrolledStudents = (chId: string) =>
    students.filter((s) => s.assignedChapters.includes(chId)).slice(0, 4)

  const completionPct = (chId: string) => {
    const ch = chapters.find((c) => c.id === chId)
    if (!ch) return 0
    const enrolled = students.filter((s) => s.assignedChapters.includes(chId))
    if (enrolled.length === 0) return 0
    const passed = enrolled.filter((s) =>
      results.some((r) => r.studentId === s.id && r.chapterName === ch.name && r.status === 'passed')
    ).length
    return Math.round((passed / enrolled.length) * 100)
  }

  // ── Aggregate analytics ──
  const totalMaterials = useMemo(
    () => chapters.reduce((a, c) => a + c.studyMaterials.length, 0),
    [chapters]
  )
  const totalSheets = useMemo(
    () => chapters.reduce((a, c) => a + c.practiceSheets.length, 0),
    [chapters]
  )
  // v3.53.2 — renamed from totalTests to totalExams. Now counts the
  // actual exams in the global exams array (the chapter.tests stub was
  // always empty and disconnected from the Exams module).
  const totalExams = useMemo(() => exams.length, [exams])
  const activeChapters = useMemo(
    () => chapters.filter((c) => c.status === 'active').length,
    [chapters]
  )
  const totalEnrolled = useMemo(
    () => students.filter((s) => s.assignedChapters.length > 0).length,
    [students]
  )

  const activeFilters = !!search || statusFilter !== 'all' || levelFilter !== 'all'

  const clearFilters = () => {
    setSearch('')
    setStatusFilter('all')
    setLevelFilter('all')
    setPage(0)
  }

  // ── Handlers ──
  const openAdd = () => {
    setEditing({ ...emptyChapter, icon: iconOptions[Math.floor(Math.random() * iconOptions.length)].key })
    setAddOpen(true)
  }
  const openEdit = (c: Chapter) => {
    setEditing({ id: c.id, name: c.name, description: c.description, icon: c.icon, status: c.status, batchId: c.batchId })
    setEditOpen(true)
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.name.trim()) {
      toast.error('Chapter name is required')
      return
    }
    addChapter({ name: editing.name.trim(), description: editing.description.trim(), icon: editing.icon, batchId: editing.batchId })
    toast.success('Chapter created', { description: editing.name })
    setAddOpen(false)
  }
  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    updateChapter(editing.id, { name: editing.name.trim(), description: editing.description.trim(), icon: editing.icon, status: editing.status, batchId: editing.batchId })
    toast.success('Chapter updated', { description: editing.name })
    setEditOpen(false)
  }
  const handleDelete = () => {
    if (!deleteTarget) return
    deleteChapter(deleteTarget.id)
    toast.error('Chapter deleted', { description: `${deleteTarget.name} and its exams/questions were removed.` })
    setDeleteTarget(null)
  }
  const handleDuplicate = (c: Chapter) => {
    addChapter({
      name: `${c.name} (copy)`,
      description: c.description,
      icon: c.icon,
    })
    toast.success('Chapter duplicated', { description: `${c.name} (copy)` })
  }

  const handleAddMaterial = () => {
    if (!activeChapter) return
    let title = newMaterialTitle.trim()
    if (!title && newMaterialFile) {
      title = newMaterialFile.name.replace(/\.pdf$/i, '')
    }
    if (!title) {
      toast.error('Enter a title or upload a PDF')
      return
    }
    if (!newMaterialFile) {
      toast.error('Upload a PDF file')
      return
    }
    addStudyMaterial(activeChapter.id, title, newMaterialFile)
    toast.success('Study material added', { description: title })
    setNewMaterialTitle('')
    setNewMaterialFile(null)
  }
  const handleAddSheet = () => {
    if (!activeChapter) return
    let title = newSheetTitle.trim()
    if (!title && newWorksheetFile) {
      title = newWorksheetFile.name.replace(/\.pdf$/i, '')
    }
    if (!title) {
      toast.error('Enter a title or upload a worksheet PDF')
      return
    }
    if (!newWorksheetFile) {
      toast.error('Upload a worksheet PDF')
      return
    }
    addPracticeSheet(
      activeChapter.id,
      title,
      newWorksheetFile,
      newSolutionFile ?? undefined,
    )
    toast.success('Practice sheet added', { description: title })
    setNewSheetTitle('')
    setNewWorksheetFile(null)
    setNewSolutionFile(null)
  }

  // v3.13.0 — FULL-PAGE Manage Content view. When the admin clicks
  // "Manage content" on a chapter, we short-circuit the chapters list and
  // render a dedicated full-page manager (no more narrow slide-in Sheet).
  // This mirrors the student ChapterLearningPage pattern: a back button,
  // premium header, per-chapter tab visibility/order editor, then the five
  // content tabs spread across the full content width.
  if (activeChapter) {
    return (
      <AdminChapterContentManager
        chapter={activeChapter}
        onBack={() => { setManageContentId(null); resetContentStaging() }}
        onEdit={() => { setManageContentId(null); openEdit(activeChapter) }}
        updateContentTabs={(tabs) => updateChapterContentTabs(activeChapter.id, tabs)}
        newMaterialTitle={newMaterialTitle}
        setNewMaterialTitle={setNewMaterialTitle}
        newMaterialFile={newMaterialFile}
        setNewMaterialFile={setNewMaterialFile}
        onAddMaterial={handleAddMaterial}
        newSheetTitle={newSheetTitle}
        setNewSheetTitle={setNewSheetTitle}
        newWorksheetFile={newWorksheetFile}
        setNewWorksheetFile={setNewWorksheetFile}
        newSolutionFile={newSolutionFile}
        setNewSolutionFile={setNewSolutionFile}
        onAddSheet={handleAddSheet}
        onDeleteMaterial={(mid, title) => {
          deleteStudyMaterial(activeChapter.id, mid)
          toast.error('Material removed', { description: title })
        }}
        onDeleteSheet={(sid, title) => {
          deletePracticeSheet(activeChapter.id, sid)
          toast.error('Sheet removed', { description: title })
        }}
        onMoveMaterial={(idx, dir) => reorderStudyMaterials(activeChapter.id, idx, idx + dir)}
        onRenameMaterial={(mid, title) => {
          updateStudyMaterial(activeChapter.id, mid, { title })
          toast.success('Material renamed', { description: title })
        }}
        onMoveSheet={(idx, dir) => reorderPracticeSheets(activeChapter.id, idx, idx + dir)}
        onRenameSheet={(sid, title) => {
          updatePracticeSheet(activeChapter.id, sid, { title })
          toast.success('Practice sheet renamed', { description: title })
        }}
        // v3.53.2 — exam management props for the renamed Exams tab
        chapterExams={exams.filter((e) => e.chapterId === activeChapter.id)}
        allExams={exams}
        allQuestions={questions}
        allChapters={chapters}
        onAddExam={(examPayload) => {
          addExam(examPayload)
          toast.success('Exam added to chapter', { description: examPayload.title })
        }}
        onRenameExam={(eid, title) => {
          updateExam(eid, { title })
          toast.success('Exam renamed', { description: title })
        }}
        onDeleteExam={(eid, title) => {
          // v3.53.3 — "Remove from chapter" (unlink). The exam stays in the
          // global exams array (visible in the Exams manager) but its
          // chapterId is cleared so it no longer appears in this chapter's
          // Exams tab. The admin can re-link it from the Exams manager.
          updateExam(eid, { chapterId: '', chapterName: '—' })
          toast.success('Exam removed from chapter', {
            description: `${title} — still available in the Exams manager`,
          })
        }}
      />
    )
  }

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      <PageHeader
        title={pageTitle}
        description="Organize your curriculum into chapters with study materials, practice sheets and exams."
        icon={<BookOpen className="h-5 w-5" />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="btn-premium-outline h-9"
              onClick={() => {
                setLastSync(new Date())
                toast.success('Chapter data refreshed')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Sync</span>
            </Button>
            <Button className="btn-premium-primary h-9" onClick={openAdd}>
              <Plus className="h-4 w-4" /> Add Chapter
            </Button>
          </>
        }
      />

      {/* Last synced status strip */}
      <div className="-mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative inline-flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          Curriculum up to date
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span>Last synced{' '}
          {lastSync.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{chapters.length} chapters</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{totalMaterials} materials</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{totalExams} exams</span>
      </div>

      {/* ── Premium stat cards ── */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
        <StatCard
          title="Total Chapters"
          value={<AnimatedNumber value={chapters.length} />}
          icon={BookOpen}
          accent="emerald"
          subtitle="In curriculum"
          trend={{ value: '+1', positive: true }}
          delay={0}
        />
        {/* v3.55.1 — Total Levels card (moved to position 2, was Enrolled Students) */}
        <StatCard
          title="Total Levels"
          value={<AnimatedNumber value={batches.length} />}
          icon={Layers}
          accent="teal"
          subtitle="Available"
          delay={0.05}
        />
        <StatCard
          title="Active"
          value={<AnimatedNumber value={activeChapters} />}
          icon={Sparkles}
          accent="teal"
          subtitle="Published"
          trend={{ value: '+2', positive: true }}
          delay={0.1}
        />
        <StatCard
          title="Study Materials"
          value={<AnimatedNumber value={totalMaterials} />}
          icon={FileText}
          accent="violet"
          subtitle="PDFs uploaded"
          trend={{ value: '+5', positive: true }}
          delay={0.15}
        />
        <StatCard
          title="Practice Sheets"
          value={<AnimatedNumber value={totalSheets} />}
          icon={FileStack}
          accent="amber"
          subtitle="With solutions"
          trend={{ value: '+3', positive: true }}
          delay={0.2}
        />
        <StatCard
          title="Chapter Exams"
          value={<AnimatedNumber value={totalExams} />}
          icon={ClipboardCheck}
          accent="rose"
          subtitle="Scheduled"
          trend={{ value: '+1', positive: true }}
          delay={0.25}
        />
      </div>

      {/* ── Sticky filter bar ── */}
      <div className="sticky top-2 z-30">
        <div className="glass-filter-bar rounded-xl p-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                placeholder="Search by chapter name or description…"
                className="input-premium h-9 pl-9"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="h-9 w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
              {/* v3.55.0 — Level filter dropdown */}
              <Select
                value={levelFilter}
                onValueChange={(v) => {
                  setLevelFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="h-9 w-[140px]">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All levels</SelectItem>
                  {batches.map((b) => (
                    <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex h-9 items-center rounded-lg border bg-background/60 p-0.5">
                <button
                  type="button"
                  aria-label="Grid view"
                  onClick={() => setView('grid')}
                  className={`page-btn-premium inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition ${
                    view === 'grid'
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <LayoutGrid className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Grid</span>
                </button>
                <button
                  type="button"
                  aria-label="List view"
                  onClick={() => setView('list')}
                  className={`page-btn-premium inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition ${
                    view === 'list'
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Rows3 className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">List</span>
                </button>
              </div>
              {activeFilters && (
                <Button variant="ghost" size="sm" className="h-9" onClick={clearFilters}>
                  <X className="h-4 w-4" /> Clear
                </Button>
              )}
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
            <span>
              Showing{' '}
              <span className="font-medium text-foreground tabular-nums">
                {filtered.length === 0 ? 0 : start + 1}–{end}
              </span>{' '}
              of{' '}
              <span className="font-medium text-foreground tabular-nums">
                {filtered.length}
              </span>{' '}
              chapters
            </span>
            <Separator orientation="vertical" className="mx-1 h-4" />
            <span className="num-premium">{activeChapters} active</span>
            <span className="text-muted-foreground/40">·</span>
            <span className="num-premium">{chapters.length - activeChapters} draft</span>
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      {filtered.length === 0 ? (
        <Card className="card-premium">
          <EmptyState
            icon={BookOpen}
            title="No chapters found"
            description="Try adjusting your search or add a new chapter to get started."
            action={
              <Button className="btn-premium-primary" onClick={openAdd}>
                <Plus className="h-4 w-4" /> Add your first chapter
              </Button>
            }
          />
        </Card>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c, i) => {
            const Icon = getChapterIcon(c.icon)
            const accent = accentFor(c.icon)
            const enrolled = enrolledCount(c.id)
            const completion = completionPct(c.id)
            const enrolledPreview = enrolledStudents(c.id)
            return (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: Math.min(i * 0.04, 0.4), ease: [0.16, 1, 0.3, 1] }}
              >
                <Card className="card-premium group relative h-full overflow-hidden rounded-xl p-0">
                  {/* Accent gradient header strip */}
                  <div className={`pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b ${accent.gradient}`} />

                  <div className="relative p-5">
                    {/* Header: icon + title + actions */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0">
                        <div
                          className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ring-1 ${accent.bg} ${accent.text} ${accent.ring}`}
                        >
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold leading-tight tracking-tight">{c.name}</h3>
                          {/* v3.55.2 — Level name in bold on its own line, then small #1 · CH001 below */}
                          {c.batchId && (
                            <p className="mt-1.5 text-sm font-bold text-foreground">
                              {batches.find((b) => b.id === c.batchId)?.name ?? '—'}
                            </p>
                          )}
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            <span className="num-premium">#{c.order}</span> · {c.id}
                          </p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="icon-btn-premium h-8 w-8 shrink-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem onClick={() => setManageContentId(c.id)}>
                            <FolderTree className="h-4 w-4" /> Manage content
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEdit(c)}>
                            <Pencil className="h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDuplicate(c)}>
                            <Copy className="h-4 w-4" /> Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            variant="destructive"
                            onClick={() => setDeleteTarget(c)}
                          >
                            <Trash2 className="h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    {/* Description */}
                    <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">
                      {c.description || 'No description provided.'}
                    </p>

                    {/* Chips row */}
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className="chip-premium border-border bg-background text-muted-foreground">
                        <Layers className="h-3 w-3" /> Order {c.order}
                      </span>
                      <span
                        className={`badge-status ${
                          c.status === 'active'
                            ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                            : 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        <span
                          className={`inline-flex h-1.5 w-1.5 rounded-full ${
                            c.status === 'active' ? 'bg-emerald-500' : 'bg-amber-500'
                          }`}
                        />
                        <span className="capitalize">{c.status}</span>
                      </span>
                    </div>

                    {/* Premium stat tiles */}
                    <div className="mt-4 grid grid-cols-3 gap-2">
                      <StatTile
                        icon={FileText}
                        label="Materials"
                        value={c.studyMaterials.length}
                        accent="text-violet-600 dark:text-violet-400"
                        bg="bg-violet-500/10"
                      />
                      <StatTile
                        icon={Box}
                        label="Sheets"
                        value={c.practiceSheets.length}
                        accent="text-amber-600 dark:text-amber-400"
                        bg="bg-amber-500/10"
                      />
                      <StatTile
                        icon={ClipboardCheck}
                        label="Exams"
                        // v3.53.2 — count exams linked to this chapter from
                        // the global exams array (was c.tests.length stub)
                        value={exams.filter((e) => e.chapterId === c.id).length}
                        accent="text-rose-600 dark:text-rose-400"
                        bg="bg-rose-500/10"
                      />
                    </div>

                    {/* Premium progress bar */}
                    <div className="mt-4 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1.5 text-muted-foreground">
                          <GraduationCap className="h-3.5 w-3.5" />
                          <span className="num-premium">{enrolled}</span> enrolled
                        </span>
                        <span className="font-semibold tabular-nums">{completion}% complete</span>
                      </div>
                      <div className="progress-premium h-2">
                        <div
                          className="progress-premium-fill"
                          style={{ width: `${Math.max(4, completion)}%` }}
                        />
                      </div>
                    </div>

                    {/* Avatar stack */}
                    {enrolledPreview.length > 0 && (
                      <div className="mt-3 flex items-center gap-2">
                        <div className="flex -space-x-2">
                          {enrolledPreview.map((s) => (
                            <div
                              key={s.id}
                              className={`avatar-premium flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold ${avatarColorClasses(s.avatarColor)}`}
                              title={s.name}
                            >
                              {s.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                            </div>
                          ))}
                        </div>
                        {enrolled > enrolledPreview.length && (
                          <span className="text-xs text-muted-foreground">
                            +<span className="num-premium">{enrolled - enrolledPreview.length}</span> more
                          </span>
                        )}
                      </div>
                    )}

                    {/* Footer actions */}
                    <div className="mt-4 flex items-center gap-2 border-t border-border/60 pt-3">
                      <Button
                        variant="outline"
                        size="sm"
                        className="btn-premium-outline h-8 flex-1"
                        onClick={() => setManageContentId(c.id)}
                      >
                        <FolderTree className="h-3.5 w-3.5" /> Manage content
                      </Button>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="icon-btn-premium h-8 w-8"
                            onClick={() => openEdit(c)}
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Edit chapter</TooltipContent>
                      </Tooltip>
                    </div>
                  </div>
                </Card>
              </motion.div>
            )
          })}
        </div>
      ) : (
        <Card className="card-premium overflow-hidden p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/40 bg-muted/30 hover:bg-muted/30">
                  <TableHead className="pl-4">Chapter</TableHead>
                  <TableHead className="hidden md:table-cell">Status</TableHead>
                  <TableHead className="hidden sm:table-cell text-center">Materials</TableHead>
                  <TableHead className="hidden sm:table-cell text-center">Sheets</TableHead>
                  <TableHead className="hidden lg:table-cell text-center">Exams</TableHead>
                  <TableHead className="hidden md:table-cell">Enrolled</TableHead>
                  <TableHead className="hidden lg:table-cell">Completion</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((c) => {
                  const Icon = getChapterIcon(c.icon)
                  const accent = accentFor(c.icon)
                  const enrolled = enrolledCount(c.id)
                  const completion = completionPct(c.id)
                  return (
                    <TableRow key={c.id} className="row-premium group border-border/40">
                      <TableCell className="pl-4 max-w-[320px]">
                        <div className="flex items-start gap-3">
                          <div
                            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ring-1 ${accent.bg} ${accent.text} ${accent.ring}`}
                          >
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0">
                            <p className="font-medium leading-tight">{c.name}</p>
                            {c.batchId && (
                              <p className="mt-1 text-sm font-bold text-foreground">
                                {batches.find((b) => b.id === c.batchId)?.name ?? '—'}
                              </p>
                            )}
                            <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">
                              <span className="num-premium">#{c.order}</span> · {c.id} · {c.description || 'No description'}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <span
                          className={`badge-status ${
                            c.status === 'active'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'
                          }`}
                        >
                          <span
                            className={`inline-flex h-1.5 w-1.5 rounded-full ${
                              c.status === 'active' ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                          />
                          <span className="capitalize">{c.status}</span>
                        </span>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-center">
                        <span className="num-premium font-semibold">{c.studyMaterials.length}</span>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-center">
                        <span className="num-premium font-semibold">{c.practiceSheets.length}</span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-center">
                        {/* v3.53.2 — count exams linked to this chapter */}
                        <span className="num-premium font-semibold">{exams.filter((e) => e.chapterId === c.id).length}</span>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <span className="num-premium font-semibold">{enrolled}</span>
                        <span className="text-xs text-muted-foreground"> students</span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-2">
                          <div className="progress-premium h-1.5 w-20">
                            <div
                              className="progress-premium-fill"
                              style={{ width: `${Math.max(4, completion)}%` }}
                            />
                          </div>
                          <span className="num-premium text-xs text-muted-foreground">{completion}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="pr-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="icon-btn-premium h-8 w-8"
                            onClick={() => setManageContentId(c.id)}
                          >
                            <FolderTree className="h-4 w-4" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuItem onClick={() => setManageContentId(c.id)}>
                                <FolderTree className="h-4 w-4" /> Manage content
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openEdit(c)}>
                                <Pencil className="h-4 w-4" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDuplicate(c)}>
                                <Copy className="h-4 w-4" /> Duplicate
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                variant="destructive"
                                onClick={() => setDeleteTarget(c)}
                              >
                                <Trash2 className="h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {/* List pagination */}
          <div className="flex flex-col items-center justify-between gap-3 border-t border-border/60 px-4 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="font-medium text-foreground tabular-nums">{start + 1}–{end}</span>{' '}
                of{' '}
                <span className="font-medium text-foreground tabular-nums">{filtered.length}</span>
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => { setRowsPerPage(Number(v)); setPage(0) }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[8, 12, 20, 50].map((n) => (
                    <SelectItem key={n} value={String(n)}>{n} / page</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="px-2 text-xs text-muted-foreground tabular-nums">
                Page {currentPage + 1} of {pageCount}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage >= pageCount - 1}
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* ── Form dialogs ── */}
      <ChapterFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        mode="add"
        batches={batches.map((b) => ({ id: b.id, name: b.name }))}
      />
      <ChapterFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        mode="edit"
        batches={batches.map((b) => ({ id: b.id, name: b.name }))}
      />

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400">
                <Trash2 className="h-4 w-4" />
              </span>
              Delete chapter?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Deleting <strong>{deleteTarget?.name}</strong> will also remove its{' '}
              <span className="num-premium font-medium text-foreground">{deleteTarget?.studyMaterials.length ?? 0}</span> materials,{' '}
              <span className="num-premium font-medium text-foreground">{deleteTarget?.practiceSheets.length ?? 0}</span> sheets and any linked exams/questions. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete chapter
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Floating add FAB (mobile-friendly shortcut) */}
      <button
        type="button"
        onClick={openAdd}
        className="fab-premium fixed bottom-6 right-6 z-30 flex h-14 items-center gap-2 rounded-full px-5 transition-all hover:scale-105 active:scale-95"
        aria-label="Add chapter"
      >
        <Plus className="h-5 w-5" />
        <span className="hidden pr-1 text-sm font-semibold sm:inline">New Chapter</span>
      </button>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Sub-components
// ────────────────────────────────────────────────────────────────────────────

function StatTile({
  icon: Icon,
  label,
  value,
  accent,
  bg,
}: {
  icon: typeof FileText
  label: string
  value: number
  accent: string
  bg: string
}) {
  return (
    <div className="rounded-lg border border-border/50 bg-background/60 px-2.5 py-2 text-center">
      <div className={`mx-auto mb-1 flex h-6 w-6 items-center justify-center rounded-md ${bg} ${accent}`}>
        <Icon className="h-3.5 w-3.5" />
      </div>
      <div className="num-premium text-base font-bold">{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  AdminChapterContentManager — FULL-PAGE chapter content manager (v3.13.0)
//
//  Replaces the old narrow slide-in Sheet. Renders as a full page inside the
//  admin content area with:
//    • Back button + breadcrumb
//    • Premium page header (chapter icon, name, description, status, edit)
//    • KPI stat tiles (materials / sheets / tests / formulas / theory)
//    • Content Tabs editor — per-chapter tab visibility + drag-to-reorder
//      (admin unchecks a tab → students never see it, and it is excluded
//       from the chapter completion calculation so the chapter is still
//       completable without it)
//    • The five content tabs (Materials / Sheets / Tests / Formula / Theory)
//      rendered full-width in the admin's chosen order.
// ────────────────────────────────────────────────────────────────────────────

/** Canonical display metadata for each content tab. The KEY is the canonical
 *  contentTab id (matches `ContentTabId` in data-store). The admin TabsContent
 *  values now use these same ids so the tab strip order is driven entirely by
 *  `chapter.contentTabs`. */
const ADMIN_TAB_META: Record<string, {
  label: string
  icon: typeof FileText
  accent: string
  bg: string
  description: string
  countFor: (ch: Chapter) => number
}> = {
  theory: {
    label: 'Theory',
    icon: BookOpen,
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
    description: 'Structured theory textbook — sections, callouts, examples and math.',
    countFor: (c) => (c.theories ?? []).length,
  },
  materials: {
    label: 'Materials',
    icon: FileText,
    accent: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-500/10',
    description: 'Study material PDFs students read to build foundation.',
    countFor: (c) => c.studyMaterials.length,
  },
  formula: {
    label: 'Formula',
    icon: Sigma,
    accent: 'text-teal-600 dark:text-teal-400',
    bg: 'bg-teal-500/10',
    description: 'Formula notebook — LaTeX-rendered expressions with examples.',
    countFor: (c) => (c.formulas ?? []).length,
  },
  practice: {
    label: 'Practice',
    icon: Box,
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
    description: 'Practice worksheets with optional solution PDFs.',
    countFor: (c) => c.practiceSheets.length,
  },
  test: {
    // v3.53.2 — renamed from "Tests" to "Exams" so the Manage Content
    // tab matches the standalone Exams module vocabulary.
    label: 'Exams',
    icon: ClipboardCheck,
    accent: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-500/10',
    description: 'Exams linked to this chapter — created here or on the Exams page.',
    countFor: () => 0, // overridden at render-time via chapterExams prop
  },
}

function AdminChapterContentManager({
  chapter,
  onBack,
  onEdit,
  updateContentTabs,
  newMaterialTitle,
  setNewMaterialTitle,
  newMaterialFile,
  setNewMaterialFile,
  onAddMaterial,
  newSheetTitle,
  setNewSheetTitle,
  newWorksheetFile,
  setNewWorksheetFile,
  newSolutionFile,
  setNewSolutionFile,
  onAddSheet,
  onDeleteMaterial,
  onDeleteSheet,
  onMoveMaterial,
  onRenameMaterial,
  onMoveSheet,
  onRenameSheet,
  // v3.53.2 — exam management props for the renamed Exams tab
  chapterExams,
  allExams,
  allQuestions,
  allChapters,
  onAddExam,
  onRenameExam,
  onDeleteExam,
}: {
  chapter: Chapter
  onBack: () => void
  onEdit: () => void
  updateContentTabs: (tabs: ContentTab[]) => void
  newMaterialTitle: string
  setNewMaterialTitle: (v: string) => void
  newMaterialFile: UploadedFile | null
  setNewMaterialFile: (f: UploadedFile | null) => void
  onAddMaterial: () => void
  newSheetTitle: string
  setNewSheetTitle: (v: string) => void
  newWorksheetFile: UploadedFile | null
  setNewWorksheetFile: (f: UploadedFile | null) => void
  newSolutionFile: UploadedFile | null
  setNewSolutionFile: (f: UploadedFile | null) => void
  onAddSheet: () => void
  onDeleteMaterial: (id: string, title: string) => void
  onDeleteSheet: (id: string, title: string) => void
  onMoveMaterial: (index: number, dir: -1 | 1) => void
  onRenameMaterial: (id: string, title: string) => void
  onMoveSheet: (index: number, dir: -1 | 1) => void
  onRenameSheet: (id: string, title: string) => void
  // v3.53.2 — exam props
  chapterExams: Exam[]
  allExams: Exam[]
  allQuestions: { id: string; chapterId: string; text: string; type: string; marks: number }[]
  allChapters: { id: string; name: string }[]
  onAddExam: (exam: Omit<Exam, 'id' | 'attempts' | 'createdAt'>) => void
  onRenameExam: (id: string, title: string) => void
  onDeleteExam: (id: string, title: string) => void
}) {
  // Resolve the chapter's content tab config (visibility + order). Falls back
  // to the canonical defaults if the chapter somehow has none.
  const tabs = useMemo(() => resolveContentTabs(chapter), [chapter])

  // Default the open tab to the first VISIBLE tab. We keep a user-clicked
  // `activeTab` in state, but DERIVE the effective tab during render so we
  // never need a setState-in-effect: if the admin hides the tab the user was
  // on, `effectiveTab` transparently falls back to the first visible tab.
  const firstVisible = tabs.find((t) => t.visible)?.id ?? tabs[0]?.id ?? 'theory'
  const [activeTab, setActiveTab] = useState(firstVisible)
  const effectiveTab = tabs.some((t) => t.id === activeTab && t.visible)
    ? activeTab
    : firstVisible

  // PDF preview popup state (View button on materials & practice sheets).
  const [viewingPdf, setViewingPdf] = useState<{ title: string; data?: string; path?: string } | null>(null)

  // v3.53.2 — inline rename state for Materials, Practice and Exams rows.
  // Each list keeps its own `editingId` + `draftTitle` pair so the admin can
  // click the pencil, edit the title in-place, then commit (✓) or cancel (✕).
  const [editingMaterialId, setEditingMaterialId] = useState<string | null>(null)
  const [draftMaterialTitle, setDraftMaterialTitle] = useState('')
  const [editingSheetId, setEditingSheetId] = useState<string | null>(null)
  const [draftSheetTitle, setDraftSheetTitle] = useState('')
  const [editingExamId, setEditingExamId] = useState<string | null>(null)
  const [draftExamTitle, setDraftExamTitle] = useState('')

  // v3.53.2 — ExamFormDialog state for the "Add Exam" button inside the
  // Exams tab. Reuses the exact same dialog component from admin-exams.tsx.
  const [examDialogOpen, setExamDialogOpen] = useState(false)
  const [examForm, setExamForm] = useState<ExamForm>(() => emptyExamForm(chapter.id))

  const handleExamDialogSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const title = examForm.title.trim()
    if (!title) {
      toast.error('Title is required')
      return
    }
    const chapterName = allChapters.find((c) => c.id === examForm.chapterId)?.name ?? '—'
    onAddExam({
      title,
      chapterId: examForm.chapterId,
      chapterName,
      type: examForm.type,
      marks: examForm.marks,
      duration: examForm.duration,
      passingPercentage: examForm.passingPercentage,
      negativeMarking: examForm.negativeMarking,
      shuffleQuestions: examForm.shuffleQuestions,
      shuffleOptions: examForm.shuffleOptions,
      showResultImmediately: examForm.showResultImmediately,
      instructions: examForm.instructions.trim(),
      questionIds: examForm.questionIds,
      status: examForm.status,
      proctored: examForm.proctored,
      questionPoolIds: examForm.questionPoolIds.length > 0 ? examForm.questionPoolIds : undefined,
      questionsToPick: examForm.questionPoolIds.length > 0 ? examForm.questionsToPick : undefined,
      poolSeedByStudent: examForm.poolSeedByStudent,
    })
    setExamDialogOpen(false)
    setExamForm(emptyExamForm(chapter.id))
  }

  const openAddExamDialog = () => {
    setExamForm(emptyExamForm(chapter.id))
    setExamDialogOpen(true)
  }

  // v3.53.2 — commit/cancel helpers for the three inline rename flows.
  const commitMaterialRename = (id: string) => {
    const trimmed = draftMaterialTitle.trim()
    if (!trimmed) { setEditingMaterialId(null); return }
    onRenameMaterial(id, trimmed)
    setEditingMaterialId(null)
    setDraftMaterialTitle('')
  }
  const commitSheetRename = (id: string) => {
    const trimmed = draftSheetTitle.trim()
    if (!trimmed) { setEditingSheetId(null); return }
    onRenameSheet(id, trimmed)
    setEditingSheetId(null)
    setDraftSheetTitle('')
  }
  const commitExamRename = (id: string) => {
    const trimmed = draftExamTitle.trim()
    if (!trimmed) { setEditingExamId(null); return }
    onRenameExam(id, trimmed)
    setEditingExamId(null)
    setDraftExamTitle('')
  }

  // ── Tab editor handlers ──
  const moveTab = (idx: number, dir: -1 | 1) => {
    const next = idx + dir
    if (next < 0 || next >= tabs.length) return
    const reordered = [...tabs]
    const [moved] = reordered.splice(idx, 1)
    reordered.splice(next, 0, moved)
    updateContentTabs(reordered)
  }
  const toggleVisible = (id: string) => {
    // Prevent hiding the last visible tab — a chapter must have at least one
    // visible tab for students to interact with.
    const visibleCount = tabs.filter((t) => t.visible).length
    const target = tabs.find((t) => t.id === id)
    if (target?.visible && visibleCount <= 1) {
      toast.error('Keep at least one tab visible', {
        description: 'A chapter needs at least one visible content tab for students.',
      })
      return
    }
    updateContentTabs(tabs.map((t) => (t.id === id ? { ...t, visible: !t.visible } : t)))
  }

  // v3.36.0 — per-chapter tab RENAME. The admin can give each of the 5 content
  // tabs a custom display name (e.g. "Theory" → "Concepts"). An empty/blank
  // label falls back to the canonical default, so clearing the input "resets"
  // the name. State is a single `editingTabId` + `draftLabel` pair; inline
  // edit replaces the label text with an Input.
  const [editingTabId, setEditingTabId] = useState<string | null>(null)
  const [draftLabel, setDraftLabel] = useState('')
  const startRename = (tab: ContentTab) => {
    setEditingTabId(tab.id)
    setDraftLabel(resolveTabLabel(tab))
  }
  const cancelRename = () => {
    setEditingTabId(null)
    setDraftLabel('')
  }
  const commitRename = (id: string) => {
    const trimmed = draftLabel.trim()
    const target = tabs.find((t) => t.id === id)
    if (!target) return
    // If the trimmed draft equals the canonical default (or is empty), drop
    // the custom label entirely so the tab "resets" to its default name.
    const isDefault = !trimmed || trimmed === DEFAULT_TAB_LABELS[target.id as keyof typeof DEFAULT_TAB_LABELS]
    const nextTabs = tabs.map((t) =>
      t.id === id ? { ...t, label: isDefault ? undefined : trimmed } : t
    )
    updateContentTabs(nextTabs)
    setEditingTabId(null)
    setDraftLabel('')
    if (isDefault) {
      toast.success(`Reset to "${DEFAULT_TAB_LABELS[target.id as keyof typeof DEFAULT_TAB_LABELS]}"`)
    } else {
      toast.success(`Tab renamed to "${trimmed}"`, {
        description: 'Students will see this name in the chapter.',
      })
    }
  }

  const ui = {
    Icon: getChapterIcon(chapter.icon),
    accent: accentFor(chapter.icon),
  }
  const visibleCount = tabs.filter((t) => t.visible).length

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      {/* ── Back button + breadcrumb ── */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Button variant="ghost" size="sm" className="gap-1.5 px-2 text-muted-foreground hover:text-foreground" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" /> Back to Chapters
        </Button>
        <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />
        <span className="font-medium text-foreground">{chapter.name}</span>
        <span className="text-muted-foreground/60">·</span>
        <span>Manage Content</span>
      </div>

      {/* ── Premium page header ── */}
      <Card className="card-elevated overflow-hidden">
        <CardContent className="p-5 sm:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-4 min-w-0">
              <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ring-1 ${ui.accent.bg} ${ui.accent.text} ${ui.accent.ring}`}>
                <ui.Icon className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{chapter.name}</h1>
                <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
                  {chapter.description || 'No description provided.'}
                </p>
                <div className="mt-2.5 flex flex-wrap items-center gap-2">
                  <span className="chip-premium border-border bg-background text-muted-foreground">
                    <Hash className="h-3 w-3" /> Order {chapter.order}
                  </span>
                  <span className={`badge-status ${chapter.status === 'active' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'}`}>
                    <span className={`inline-flex h-1.5 w-1.5 rounded-full ${chapter.status === 'active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                    <span className="capitalize">{chapter.status}</span>
                  </span>
                  <span className="chip-premium border-border bg-background text-muted-foreground">
                    <LayoutPanelTop className="h-3 w-3" /> {visibleCount}/{tabs.length} tabs visible
                  </span>
                </div>
              </div>
            </div>
            <div className="flex shrink-0 gap-2">
              <Button variant="outline" size="sm" className="gap-1.5" onClick={onBack}>
                <ArrowLeft className="h-3.5 w-3.5" /> Back
              </Button>
              <Button size="sm" className="btn-premium-primary gap-1.5" onClick={onEdit}>
                <Pencil className="h-3.5 w-3.5" /> Edit chapter
              </Button>
            </div>
          </div>

          {/* Stat tiles */}
          <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {tabs.map((t) => {
              const meta = ADMIN_TAB_META[t.id]
              if (!meta) return null
              const Icon = meta.icon
              // v3.53.2 — the Exams tab counts linked exams (from the
              // global exams array), not the old chapter.tests stub.
              const count = t.id === 'test' ? chapterExams.length : meta.countFor(chapter)
              return (
                <div key={t.id} className="rounded-lg border border-border/50 bg-background/60 px-3 py-2.5 text-center">
                  <div className={`mx-auto mb-1 flex h-7 w-7 items-center justify-center rounded-md ${meta.bg} ${meta.accent}`}>
                    <Icon className="h-3.5 w-3.5" />
                  </div>
                  <div className="num-premium text-lg font-bold">{count}</div>
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{resolveTabLabel(t)}</div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Content Tabs editor (visibility + order) ── */}
      <Card className="card-elevated">
        <CardContent className="p-5 sm:p-6">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-base font-semibold">
                <LayoutPanelTop className="h-4 w-4 text-primary" />
                Content Tabs — Visibility, Order &amp; Rename
              </h2>
              <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
                Control which tabs students see for this chapter, in what order, and what they are
                called. A hidden tab is removed from the student view entirely AND excluded from
                the chapter completion calculation — so students can complete the chapter without
                it. Use the arrows to reorder (top-to-bottom here = left-to-right for students),
                the eye to show/hide, and the pencil to rename a tab (e.g. "Theory" → "Concepts").
                Clear the name field to reset it to the default.
              </p>
            </div>
          </div>

          <ul className="space-y-2">
            {tabs.map((t, idx) => {
              const meta = ADMIN_TAB_META[t.id]
              if (!meta) return null
              const Icon = meta.icon
              return (
                <li
                  key={t.id}
                  className={`row-premium flex items-center gap-3 rounded-lg border px-3 py-2.5 transition-colors ${
                    t.visible
                      ? 'border-border/60 bg-background/60'
                      : 'border-dashed border-border/50 bg-muted/30 opacity-70'
                  }`}
                >
                  {/* Grip + position */}
                  <div className="flex items-center gap-1 text-muted-foreground/60">
                    <GripVertical className="h-4 w-4" />
                    <span className="num-premium w-4 text-center text-xs font-semibold">{idx + 1}</span>
                  </div>

                  {/* Icon */}
                  <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${meta.bg} ${meta.accent}`}>
                    <Icon className="h-4 w-4" />
                  </div>

                  {/* Label + description (or inline rename input when editing) */}
                  <div className="min-w-0 flex-1">
                    {editingTabId === t.id ? (
                      <div className="flex items-center gap-1.5">
                        <Input
                          value={draftLabel}
                          onChange={(e) => setDraftLabel(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault()
                              commitRename(t.id)
                            } else if (e.key === 'Escape') {
                              e.preventDefault()
                              cancelRename()
                            }
                          }}
                          autoFocus
                          placeholder={DEFAULT_TAB_LABELS[t.id as keyof typeof DEFAULT_TAB_LABELS]}
                          className="input-premium h-8 w-44 text-sm"
                        />
                        <span className="text-[10px] text-muted-foreground">Enter ↵ · Esc</span>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm font-medium">
                          {resolveTabLabel(t)}
                          {t.label && t.label.trim() && (
                            <span className="ml-2 rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">
                              renamed
                            </span>
                          )}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">{meta.description}</p>
                      </>
                    )}
                  </div>

                  {/* Count badge */}
                  <span className="num-premium hidden text-xs text-muted-foreground sm:inline">
                    {meta.countFor(chapter)} items
                  </span>

                  {/* Rename / confirm-cancel (v3.36.0) */}
                  {editingTabId === t.id ? (
                    <div className="flex items-center gap-0.5">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-emerald-600 hover:bg-emerald-500/10 hover:text-emerald-700 dark:text-emerald-400"
                            onClick={() => commitRename(t.id)}
                            aria-label="Save name"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Save name (Enter)</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:bg-muted"
                            onClick={cancelRename}
                            aria-label="Cancel rename"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Cancel (Esc)</TooltipContent>
                      </Tooltip>
                    </div>
                  ) : (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="icon-btn-premium h-8 w-8"
                          onClick={() => startRename(t)}
                          aria-label={`Rename ${meta.label} tab`}
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Rename tab</TooltipContent>
                    </Tooltip>
                  )}

                  {/* Up / Down arrows */}
                  <div className="flex items-center gap-0.5">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="icon-btn-premium h-7 w-7"
                          disabled={idx === 0}
                          onClick={() => moveTab(idx, -1)}
                        >
                          <ArrowUp className="h-3.5 w-3.5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Move up</TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="icon-btn-premium h-7 w-7"
                          disabled={idx === tabs.length - 1}
                          onClick={() => moveTab(idx, 1)}
                        >
                          <ArrowDown className="h-3.5 w-3.5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Move down</TooltipContent>
                    </Tooltip>
                  </div>

                  {/* Visibility toggle */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${
                          t.visible
                            ? 'text-emerald-600 hover:bg-emerald-500/10 hover:text-emerald-700 dark:text-emerald-400'
                            : 'text-muted-foreground hover:bg-muted'
                        }`}
                        onClick={() => toggleVisible(t.id)}
                        aria-label={t.visible ? 'Hide from students' : 'Show to students'}
                      >
                        {t.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      {t.visible ? 'Visible to students — click to hide' : 'Hidden from students — click to show'}
                    </TooltipContent>
                  </Tooltip>
                </li>
              )
            })}
          </ul>
        </CardContent>
      </Card>

      {/* ── Content tabs (full width, in admin's chosen order) ── */}
      <Tabs value={effectiveTab} onValueChange={setActiveTab}>
        <TabsList
          className="grid w-full"
          style={{ gridTemplateColumns: `repeat(${visibleCount || 1}, minmax(0, 1fr))` }}
        >
          {tabs.filter((t) => t.visible).map((t) => {
            const meta = ADMIN_TAB_META[t.id]
            if (!meta) return null
            const Icon = meta.icon
            // v3.53.2 — Exams tab counts linked exams, not the old tests stub
            const tabCount = t.id === 'test' ? chapterExams.length : meta.countFor(chapter)
            return (
              <TabsTrigger key={t.id} value={t.id}>
                <Icon className="mr-1.5 h-3.5 w-3.5" />
                {resolveTabLabel(t)} <span className="num-premium ml-1">({tabCount})</span>
              </TabsTrigger>
            )
          })}
        </TabsList>

        {/* ── Materials ── */}
        <TabsContent value="materials" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="space-y-3 p-5 sm:p-6">
              <div className="rounded-lg border border-border/60 bg-muted/20 p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Add new material
                </p>
                <PdfFilePicker
                  id="material-pdf"
                  label="Study material PDF"
                  file={newMaterialFile}
                  onSelect={(f) => setNewMaterialFile(f)}
                  onClear={() => setNewMaterialFile(null)}
                />
                <div className="mt-2 flex items-center gap-2">
                  <Input
                    value={newMaterialTitle}
                    onChange={(e) => setNewMaterialTitle(e.target.value)}
                    placeholder="Title (auto-fills from file name if blank)"
                    className="input-premium h-9"
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), onAddMaterial())}
                  />
                  <Button size="sm" className="btn-premium-primary h-9" onClick={onAddMaterial}>
                    <Plus className="h-3.5 w-3.5" /> Add
                  </Button>
                </div>
              </div>

              {chapter.studyMaterials.length === 0 ? (
                <div className="rounded-lg border border-dashed border-border/60 px-4 py-8 text-center">
                  <FileText className="mx-auto mb-2 h-6 w-6 text-muted-foreground/60" />
                  <p className="text-sm text-muted-foreground">No materials uploaded yet</p>
                  <p className="mt-1 text-xs text-muted-foreground/70">Upload your first PDF above.</p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {chapter.studyMaterials.map((m, mIdx) => (
                    <li
                      key={m.id}
                      className="row-premium flex items-center justify-between rounded-lg border border-border/60 bg-background/60 px-3 py-2.5 text-sm"
                    >
                      <span className="flex items-center gap-2.5 min-w-0">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-rose-500/10 text-rose-600 dark:text-rose-400">
                          <FileText className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          {editingMaterialId === m.id ? (
                            // v3.53.2 — inline rename input (replaces title text)
                            <div className="flex items-center gap-1">
                              <Input
                                value={draftMaterialTitle}
                                onChange={(e) => setDraftMaterialTitle(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') { e.preventDefault(); commitMaterialRename(m.id) }
                                  if (e.key === 'Escape') { setEditingMaterialId(null); setDraftMaterialTitle('') }
                                }}
                                className="input-premium h-7 w-48 text-sm"
                                autoFocus
                              />
                            </div>
                          ) : (
                            <>
                              <p className="truncate font-medium">{m.title}</p>
                              <div className="mt-0.5 flex items-center gap-1.5">
                                {m.fileData || m.filePath ? (
                                  <>
                                    <span className="chip-premium border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300">
                                      <FileCheck2 className="h-3 w-3" /> {m.filePath ? 'PDF (preset)' : 'PDF'}
                                    </span>
                                    <span className="num-premium text-[10px] text-muted-foreground">
                                      {formatFileSize(m.fileSize)}
                                    </span>
                                  </>
                                ) : (
                                  <span className="text-[10px] italic text-muted-foreground">No file attached</span>
                                )}
                                <span className="num-premium text-[10px] text-muted-foreground">· {m.uploadedAt}</span>
                              </div>
                            </>
                          )}
                        </div>
                      </span>
                      <div className="flex items-center gap-1">
                        {/* v3.53.2 — Move Up / Move Down / Rename buttons */}
                        {editingMaterialId === m.id ? (
                          <>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7 text-emerald-600 hover:text-emerald-700" onClick={() => commitMaterialRename(m.id)}>
                                  <Check className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Save rename</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => { setEditingMaterialId(null); setDraftMaterialTitle('') }}>
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Cancel</TooltipContent>
                            </Tooltip>
                          </>
                        ) : (
                          <>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  disabled={mIdx === 0}
                                  onClick={() => onMoveMaterial(mIdx, -1)}
                                >
                                  <ArrowUp className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Move up</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  disabled={mIdx === chapter.studyMaterials.length - 1}
                                  onClick={() => onMoveMaterial(mIdx, 1)}
                                >
                                  <ArrowDown className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Move down</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  onClick={() => { setEditingMaterialId(m.id); setDraftMaterialTitle(m.title) }}
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Rename</TooltipContent>
                            </Tooltip>
                          </>
                        )}
                        {(m.fileData || m.filePath) && editingMaterialId !== m.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => setViewingPdf({ title: m.title, data: m.fileData, path: m.filePath })}>
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>View PDF</TooltipContent>
                          </Tooltip>
                        )}
                        {(m.fileData || m.filePath) && editingMaterialId !== m.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => {
                                const a = document.createElement('a')
                                a.href = m.filePath ?? m.fileData!
                                a.download = m.fileName || `${m.title}.pdf`
                                if (m.filePath) a.target = '_blank'
                                document.body.appendChild(a)
                                a.click()
                                document.body.removeChild(a)
                              }}>
                                <Download className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Download</TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="icon-btn-premium h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => onDeleteMaterial(m.id, m.title)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Practice (Sheets) ── */}
        <TabsContent value="practice" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="space-y-3 p-5 sm:p-6">
              <div className="rounded-lg border border-border/60 bg-muted/20 p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Add new practice sheet
                </p>
                <div className="space-y-2">
                  <PdfFilePicker
                    id="worksheet-pdf"
                    label="Worksheet PDF"
                    file={newWorksheetFile}
                    onSelect={(f) => setNewWorksheetFile(f)}
                    onClear={() => setNewWorksheetFile(null)}
                  />
                  <PdfFilePicker
                    id="solution-pdf"
                    label="Solutions PDF (optional)"
                    file={newSolutionFile}
                    onSelect={(f) => setNewSolutionFile(f)}
                    onClear={() => setNewSolutionFile(null)}
                  />
                  <div className="flex items-center gap-2">
                    <Input
                      value={newSheetTitle}
                      onChange={(e) => setNewSheetTitle(e.target.value)}
                      placeholder="Title (auto-fills from file name if blank)"
                      className="input-premium h-9"
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), onAddSheet())}
                    />
                    <Button size="sm" className="btn-premium-primary h-9" onClick={onAddSheet}>
                      <Plus className="h-3.5 w-3.5" /> Add
                    </Button>
                  </div>
                </div>
              </div>

              {chapter.practiceSheets.length === 0 ? (
                <div className="rounded-lg border border-dashed border-border/60 px-4 py-8 text-center">
                  <Box className="mx-auto mb-2 h-6 w-6 text-muted-foreground/60" />
                  <p className="text-sm text-muted-foreground">No practice sheets yet</p>
                  <p className="mt-1 text-xs text-muted-foreground/70">Upload a worksheet PDF above.</p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {chapter.practiceSheets.map((p, pIdx) => (
                    <li
                      key={p.id}
                      className="row-premium flex items-center justify-between rounded-lg border border-border/60 bg-background/60 px-3 py-2.5 text-sm"
                    >
                      <span className="flex min-w-0 items-center gap-2.5">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400">
                          <Box className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          {editingSheetId === p.id ? (
                            // v3.53.2 — inline rename input
                            <div className="flex items-center gap-1">
                              <Input
                                value={draftSheetTitle}
                                onChange={(e) => setDraftSheetTitle(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') { e.preventDefault(); commitSheetRename(p.id) }
                                  if (e.key === 'Escape') { setEditingSheetId(null); setDraftSheetTitle('') }
                                }}
                                className="input-premium h-7 w-48 text-sm"
                                autoFocus
                              />
                            </div>
                          ) : (
                            <>
                              <p className="truncate font-medium">{p.title}</p>
                              <div className="mt-0.5 flex items-center gap-1.5">
                                {p.fileData || p.filePath ? (
                                  <span className="chip-premium border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300">
                                    <FileCheck2 className="h-3 w-3" /> {p.filePath ? 'WS (preset)' : 'WS'}
                                  </span>
                                ) : (
                                  <span className="text-[10px] italic text-muted-foreground">No file</span>
                                )}
                                {(p.hasSolution && (p.solutionFileData || p.solutionFilePath)) && (
                                  <span className="chip-premium border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                                    <FileCheck2 className="h-3 w-3" /> Solutions {p.solutionFilePath ? '(preset)' : ''}
                                  </span>
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      </span>
                      <div className="flex items-center gap-1">
                        {/* v3.53.2 — Move Up / Move Down / Rename buttons */}
                        {editingSheetId === p.id ? (
                          <>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7 text-emerald-600 hover:text-emerald-700" onClick={() => commitSheetRename(p.id)}>
                                  <Check className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Save rename</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => { setEditingSheetId(null); setDraftSheetTitle('') }}>
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Cancel</TooltipContent>
                            </Tooltip>
                          </>
                        ) : (
                          <>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  disabled={pIdx === 0}
                                  onClick={() => onMoveSheet(pIdx, -1)}
                                >
                                  <ArrowUp className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Move up</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  disabled={pIdx === chapter.practiceSheets.length - 1}
                                  onClick={() => onMoveSheet(pIdx, 1)}
                                >
                                  <ArrowDown className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Move down</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="icon-btn-premium h-7 w-7"
                                  onClick={() => { setEditingSheetId(p.id); setDraftSheetTitle(p.title) }}
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Rename</TooltipContent>
                            </Tooltip>
                          </>
                        )}
                        {(p.fileData || p.filePath) && editingSheetId !== p.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => setViewingPdf({ title: p.title, data: p.fileData, path: p.filePath })}>
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>View worksheet PDF</TooltipContent>
                          </Tooltip>
                        )}
                        {(p.solutionFileData || p.solutionFilePath) && editingSheetId !== p.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => setViewingPdf({ title: `${p.title} — Solutions`, data: p.solutionFileData, path: p.solutionFilePath })}>
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>View solutions PDF</TooltipContent>
                          </Tooltip>
                        )}
                        {(p.fileData || p.filePath) && editingSheetId !== p.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => {
                                const a = document.createElement('a')
                                a.href = p.filePath ?? p.fileData!
                                a.download = p.fileName || `${p.title}.pdf`
                                if (p.filePath) a.target = '_blank'
                                document.body.appendChild(a)
                                a.click()
                                document.body.removeChild(a)
                              }}>
                                <Download className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Download worksheet</TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="icon-btn-premium h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => onDeleteSheet(p.id, p.title)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Exams (was "Tests" — v3.53.2) ── */}
        <TabsContent value="test" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="space-y-3 p-5 sm:p-6">
              {/* v3.53.2 — Add Exam button + helper */}
              <div className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/20 p-3">
                <div className="min-w-0">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Exams linked to this chapter
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground/70">
                    Create an exam here or on the Exams page — either way, pick this chapter in the form.
                  </p>
                </div>
                <Button size="sm" className="btn-premium-primary h-9 shrink-0" onClick={openAddExamDialog}>
                  <Plus className="h-3.5 w-3.5" /> Add Exam
                </Button>
              </div>

              {chapterExams.length === 0 ? (
                <div className="rounded-lg border border-dashed border-border/60 px-4 py-8 text-center">
                  <ClipboardCheck className="mx-auto mb-2 h-6 w-6 text-muted-foreground/60" />
                  <p className="text-sm text-muted-foreground">No exams linked to this chapter yet</p>
                  <p className="mt-1 text-xs text-muted-foreground/70">Click “Add Exam” above, or create one from the Exams page.</p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {chapterExams.map((exam) => (
                    <li
                      key={exam.id}
                      className="row-premium flex items-center justify-between rounded-lg border border-border/60 bg-background/60 px-3 py-2.5 text-sm"
                    >
                      <span className="flex items-center gap-2.5 min-w-0">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-rose-500/10 text-rose-600 dark:text-rose-400">
                          <ClipboardCheck className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          {editingExamId === exam.id ? (
                            // v3.53.2 — inline rename input
                            <Input
                              value={draftExamTitle}
                              onChange={(e) => setDraftExamTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') { e.preventDefault(); commitExamRename(exam.id) }
                                if (e.key === 'Escape') { setEditingExamId(null); setDraftExamTitle('') }
                              }}
                              className="input-premium h-7 w-48 text-sm"
                              autoFocus
                            />
                          ) : (
                            <>
                              <p className="truncate font-medium">{exam.title}</p>
                              <div className="mt-0.5 flex items-center gap-1.5">
                                <span className="chip-premium border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300">
                                  {exam.type.replace('_', ' ')}
                                </span>
                                <span className="num-premium text-[10px] text-muted-foreground">
                                  {exam.duration} min · pass {exam.passingPercentage}%
                                </span>
                                <span className={`chip-premium ${exam.status === 'published' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'}`}>
                                  {exam.status}
                                </span>
                              </div>
                            </>
                          )}
                        </div>
                      </span>
                      <div className="flex items-center gap-1">
                        {/* v3.53.2 — Rename (commit/cancel) + Delete buttons */}
                        {editingExamId === exam.id ? (
                          <>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7 text-emerald-600 hover:text-emerald-700" onClick={() => commitExamRename(exam.id)}>
                                  <Check className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Save rename</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="icon-btn-premium h-7 w-7" onClick={() => { setEditingExamId(null); setDraftExamTitle('') }}>
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Cancel</TooltipContent>
                            </Tooltip>
                          </>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="icon-btn-premium h-7 w-7"
                                onClick={() => { setEditingExamId(exam.id); setDraftExamTitle(exam.title) }}
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Rename exam</TooltipContent>
                          </Tooltip>
                        )}
                        {editingExamId !== exam.id && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                // v3.53.3 — amber (not red) to signal this is
                                // an "unlink" action, not a permanent delete.
                                className="icon-btn-premium h-7 w-7 text-amber-600 hover:text-amber-700 dark:text-amber-400"
                                onClick={() => onDeleteExam(exam.id, exam.title)}
                              >
                                <X className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Remove from chapter (keeps exam in Exams manager)</TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                      {editingExamId !== exam.id && (
                        <span className="badge-status border-border bg-background text-foreground ml-1 shrink-0">
                          <span className="num-premium font-bold">{exam.marks}</span> marks
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Formula ── */}
        <TabsContent value="formula" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="p-5 sm:p-6">
              <div className="mb-3 rounded-lg border border-teal-500/30 bg-teal-500/5 px-3 py-2">
                <div className="flex items-center gap-2">
                  <Sigma className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                  <p className="text-xs text-foreground">
                    <span className="font-semibold">Formula notebook.</span>{' '}
                    Add the chapter&apos;s key formulas with LaTeX-rendered expressions. Students see them in a beautiful, DRM-protected card view.
                  </p>
                </div>
              </div>
              <AdminFormulaManager chapterId={chapter.id} formulas={chapter.formulas ?? []} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Theory ── */}
        <TabsContent value="theory" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="p-5 sm:p-6">
              <div className="mb-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2">
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  <p className="text-xs text-foreground">
                    <span className="font-semibold">Theory textbook.</span>{' '}
                    Build the chapter&apos;s structured theory — sections, callouts, examples and math. Renders as a premium digital textbook for students.
                  </p>
                </div>
              </div>
              <AdminTheoryManager chapterId={chapter.id} theories={chapter.theories ?? []} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* PDF preview popup — View button on materials & practice sheets */}
      <Dialog open={!!viewingPdf} onOpenChange={(o) => !o && setViewingPdf(null)}>
        <DialogContent className="flex h-[90vh] max-w-5xl flex-col gap-0 overflow-hidden p-0">
          <DialogHeader className="shrink-0 border-b border-border px-5 py-3">
            <DialogTitle className="flex items-center gap-2 truncate pr-8 text-base">
              <FileText className="h-4 w-4 shrink-0 text-rose-500" />
              <span className="truncate">{viewingPdf?.title ?? 'PDF Preview'}</span>
            </DialogTitle>
          </DialogHeader>
          <div className="min-h-0 flex-1 bg-muted/30">
            {(viewingPdf?.data || viewingPdf?.path) && (
              <iframe
                src={viewingPdf.path ?? viewingPdf.data}
                title={viewingPdf.title}
                className="h-full w-full border-0"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* v3.53.2 — Add Exam dialog (reuses the exact same ExamFormDialog
          from admin-exams.tsx so the 17-field create-exam form is identical
          to the one on the Exams page. The chapter is pre-selected so the
          exam is automatically linked to this chapter.) */}
      <ExamFormDialog
        open={examDialogOpen}
        onOpenChange={setExamDialogOpen}
        form={examForm}
        setForm={setExamForm}
        onSubmit={handleExamDialogSubmit}
        chapters={allChapters}
        questions={allQuestions.map((q) => ({ id: q.id, chapterId: q.chapterId, text: q.text, type: q.type, marks: q.marks, difficulty: q.difficulty }))}
        mode="add"
        batches={allChapters.map((c) => ({ id: c.id, name: c.name }))}
      />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Chapter form dialog (add / edit) — premium
// ────────────────────────────────────────────────────────────────────────────

function ChapterFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  mode,
  batches,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: ChapterForm
  setForm: React.Dispatch<React.SetStateAction<ChapterForm>>
  onSubmit: (e: React.FormEvent) => void
  mode: 'add' | 'edit'
  // v3.55.0 — batches for the Level picker dropdown
  batches: { id: string; name: string }[]
}) {
  const update = (patch: Partial<ChapterForm>) => setForm((p) => ({ ...p, ...patch }))

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              {mode === 'add' ? <Plus className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
            </span>
            {mode === 'add' ? 'Add new chapter' : 'Edit chapter'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'add'
              ? 'Create a new chapter in your curriculum. You can attach materials and sheets after creation.'
              : 'Update the chapter details below.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="ch-name" className="flex items-center gap-1.5">
              <BookOpen className="h-3.5 w-3.5 text-muted-foreground" /> Chapter name
            </Label>
            <Input
              id="ch-name"
              value={form.name}
              onChange={(e) => update({ name: e.target.value })}
              placeholder="e.g. Number System"
              className="input-premium"
              required
              autoFocus
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="ch-desc" className="flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5 text-muted-foreground" /> Description
            </Label>
            <Textarea
              id="ch-desc"
              value={form.description}
              onChange={(e) => update({ description: e.target.value })}
              placeholder="Brief description of what this chapter covers"
              className="input-premium resize-none"
              rows={3}
            />
          </div>

          {/* v3.55.0 — Level picker (soft tag for Chapters page filter) */}
          <div className="space-y-2">
            <Label htmlFor="ch-level" className="flex items-center gap-1.5">
              <Layers className="h-3.5 w-3.5 text-muted-foreground" /> Level
              <span className="text-[10px] font-normal text-muted-foreground">(optional — for filtering)</span>
            </Label>
            <Select
              value={form.batchId ?? 'none'}
              onValueChange={(v) => update({ batchId: v === 'none' ? undefined : v })}
            >
              <SelectTrigger id="ch-level" className="input-premium">
                <SelectValue placeholder="No level assigned" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— No level —</SelectItem>
                {batches.map((b) => (
                  <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Icon picker — visual grid */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-muted-foreground" /> Chapter icon
            </Label>
            <div className="grid grid-cols-8 gap-1.5">
              {iconOptions.map(({ key, Icon }) => {
                const accent = accentFor(key)
                const selected = form.icon === key
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => update({ icon: key })}
                    title={key}
                    className={`flex aspect-square items-center justify-center rounded-lg border transition-all ${
                      selected
                        ? `${accent.bg} ${accent.text} border-current shadow-sm ring-2 ring-current/20`
                        : 'border-border/60 bg-background text-muted-foreground hover:bg-muted/40 hover:text-foreground'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                  </button>
                )
              })}
            </div>
          </div>

          {/* Status picker — visual cards */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <Layers className="h-3.5 w-3.5 text-muted-foreground" /> Status
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => update({ status: 'active' })}
                className={`flex items-start gap-3 rounded-lg border p-3 text-left transition-all ${
                  form.status === 'active'
                    ? 'border-emerald-500/50 bg-emerald-500/5 ring-2 ring-emerald-500/20'
                    : 'border-border/60 bg-background hover:bg-muted/40'
                }`}
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium">Active</p>
                  <p className="text-[11px] text-muted-foreground">Visible to students</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => update({ status: 'draft' })}
                className={`flex items-start gap-3 rounded-lg border p-3 text-left transition-all ${
                  form.status === 'draft'
                    ? 'border-amber-500/50 bg-amber-500/5 ring-2 ring-amber-500/20'
                    : 'border-border/60 bg-background hover:bg-muted/40'
                }`}
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <Pencil className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium">Draft</p>
                  <p className="text-[11px] text-muted-foreground">Hidden, in progress</p>
                </div>
              </button>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="btn-premium-outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="btn-premium-primary">
              {mode === 'add' ? (
                <>
                  <Plus className="h-4 w-4" /> Create chapter
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" /> Save changes
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// ───────────────────────────────────────────────────────
//  PDF upload helpers
// ───────────────────────────────────────────────────────

const MAX_PDF_BYTES = 2 * 1024 * 1024 // 2 MB (localStorage has a ~5MB cap)

/** Format a byte count into a compact human-readable string. */
export function formatFileSize(bytes: number | undefined): string {
  if (!bytes || bytes <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit++
  }
  const decimals = unit === 0 ? 0 : value < 10 ? 1 : 0
  return `${value.toFixed(decimals)} ${units[unit]}`
}

interface PdfFilePickerProps {
  id: string
  label: string
  file: UploadedFile | null
  onSelect: (file: UploadedFile) => void
  onClear: () => void
}

/**
 * A self-contained PDF file picker with premium styling.
 */
function PdfFilePicker({ id, label, file, onSelect, onClear }: PdfFilePickerProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  const handleFile = (raw: File | null | undefined) => {
    if (!raw) return
    if (raw.type !== 'application/pdf') {
      toast.error('Only PDF files are allowed', {
        description: `Selected file type: ${raw.type || 'unknown'}`,
      })
      return
    }
    if (raw.size > MAX_PDF_BYTES) {
      toast.error('File is too large', {
        description: `Max 2 MB. Selected file is ${formatFileSize(raw.size)}.`,
      })
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const data = reader.result
      if (typeof data !== 'string') {
        toast.error('Could not read the PDF file')
        return
      }
      onSelect({ data, name: raw.name, size: raw.size })
    }
    reader.onerror = () => {
      toast.error('Could not read the PDF file')
    }
    reader.readAsDataURL(raw)
  }

  return (
    <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 p-2.5">
      <input
        ref={inputRef}
        id={id}
        type="file"
        accept="application/pdf"
        className="sr-only"
        onChange={(e) => {
          handleFile(e.target.files?.[0])
          e.target.value = ''
        }}
      />
      <AnimatePresence mode="wait">
        {file ? (
          <motion.div
            key="file"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="flex items-center justify-between gap-2"
          >
            <div className="flex min-w-0 items-center gap-2.5">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-rose-500/10 text-rose-600 dark:text-rose-400">
                <FileText className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="truncate text-xs font-medium">{file.name}</p>
                <p className="num-premium text-[10px] text-muted-foreground">
                  {label} · {formatFileSize(file.size)}
                </p>
              </div>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="icon-btn-premium h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive"
              onClick={onClear}
              aria-label={`Remove ${label}`}
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          </motion.div>
        ) : (
          <motion.button
            key="empty"
            type="button"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => inputRef.current?.click()}
            className="group flex w-full items-center justify-center gap-3 rounded-lg border-2 border-dashed border-primary/40 bg-primary/5 px-4 py-4 text-center transition hover:border-primary hover:bg-primary/10"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm transition group-hover:scale-110">
              <Upload className="h-4 w-4" />
            </div>
            <div className="min-w-0 text-left">
              <p className="text-sm font-semibold text-primary">Click to upload PDF</p>
              <p className="text-[10px] text-muted-foreground">{label} · max 2 MB</p>
            </div>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  )
}
