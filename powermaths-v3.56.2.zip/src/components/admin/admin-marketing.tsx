'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  Images, Plus, Search, Pencil, Copy, Trash2, Pause, Play, Eye,
  ImageIcon, Youtube, Calendar, Users, Layers, Globe, ArrowUpRight,
  Filter, AlertCircle, CheckCircle2, Clock, XCircle,
  Type as TypeIcon, Sparkles, Variable,
} from 'lucide-react'
import { useDataStore, type MarketingCampaign, type Student, type Batch } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Checkbox } from '@/components/ui/checkbox'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

// ─────────────────────── YouTube URL helpers ───────────────────────
// Parse any common YouTube URL format into a clean embed URL.
// Supports: watch?v=ID, youtu.be/ID, /embed/ID, /shorts/ID, with extra params.
function youtubeEmbedUrl(raw: string): string | null {
  if (!raw) return null
  const url = raw.trim()
  // Already an embed URL
  const embedMatch = url.match(/youtube\.com\/embed\/([\w-]{6,})/)
  if (embedMatch) return `https://www.youtube.com/embed/${embedMatch[1]}`
  // youtu.be short link
  const shortMatch = url.match(/youtu\.be\/([\w-]{6,})/)
  if (shortMatch) return `https://www.youtube.com/embed/${shortMatch[1]}`
  // Shorts
  const shortsMatch = url.match(/youtube\.com\/shorts\/([\w-]{6,})/)
  if (shortsMatch) return `https://www.youtube.com/embed/${shortsMatch[1]}`
  // Standard watch?v=ID
  const watchMatch = url.match(/[?&]v=([\w-]{6,})/)
  if (watchMatch) return `https://www.youtube.com/embed/${watchMatch[1]}`
  return null
}

function youtubeThumb(raw: string): string | null {
  const embed = youtubeEmbedUrl(raw)
  if (!embed) return null
  const id = embed.split('/embed/')[1]
  return `https://img.youtube.com/vi/${id}/hqdefault.jpg`
}

// ─────────────────────── Form type ───────────────────────
interface CampaignForm {
  title: string
  description: string
  type: 'banner' | 'video' | 'text'
  image: string
  videoUrl: string
  // v3.52.0 — type === 'text': rich message body with dynamic placeholders.
  messageContent: string
  audience: 'all' | 'batch' | 'individual'
  targetBatches: string[]
  targetStudentIds: string[]
  startDate: string
  endDate: string
  priority: number
  status: 'draft' | 'published' | 'paused'
  ctaText: string
  ctaUrl: string
}

const emptyForm: CampaignForm = {
  title: '',
  description: '',
  type: 'banner',
  image: '',
  videoUrl: '',
  messageContent: '',
  audience: 'all',
  targetBatches: [],
  targetStudentIds: [],
  startDate: '',
  endDate: '',
  priority: 1,
  status: 'draft',
  ctaText: '',
  ctaUrl: '',
}

function campaignToForm(c: MarketingCampaign): CampaignForm {
  return {
    title: c.title,
    description: c.description,
    type: c.type,
    image: c.image ?? '',
    videoUrl: c.videoUrl ?? '',
    messageContent: c.messageContent ?? '',
    audience: c.audience,
    targetBatches: c.targetBatches ?? [],
    targetStudentIds: c.targetStudentIds ?? [],
    startDate: c.startDate,
    endDate: c.endDate,
    priority: c.priority,
    status: c.status,
    ctaText: c.ctaText ?? '',
    ctaUrl: c.ctaUrl ?? '',
  }
}

// ─────────────────────── Status helpers ───────────────────────
function statusBadge(s: MarketingCampaign['status']) {
  switch (s) {
    case 'published':
      return <Badge className="gap-1 bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/40 dark:text-emerald-300"><CheckCircle2 className="h-3 w-3" /> Published</Badge>
    case 'paused':
      return <Badge variant="secondary" className="gap-1"><Pause className="h-3 w-3" /> Paused</Badge>
    case 'draft':
      return <Badge variant="outline" className="gap-1"><Pencil className="h-3 w-3" /> Draft</Badge>
  }
}

function audienceLabel(c: MarketingCampaign): string {
  switch (c.audience) {
    case 'all':
      return 'All Students'
    case 'batch':
      return c.targetBatches?.length ? `${c.targetBatches.length} batch${c.targetBatches.length > 1 ? 'es' : ''}` : 'No batches'
    case 'individual':
      return c.targetStudentIds?.length ? `${c.targetStudentIds.length} student${c.targetStudentIds.length > 1 ? 's' : ''}` : 'No students'
  }
}

function dateRangeLabel(c: MarketingCampaign): string {
  if (!c.startDate && !c.endDate) return 'Always active'
  if (c.startDate && !c.endDate) return `From ${c.startDate}`
  if (!c.startDate && c.endDate) return `Until ${c.endDate}`
  return `${c.startDate} → ${c.endDate}`
}

// ─────────────────────── v3.52.0 — Text Banner helpers ───────────────────────
// Resolve dynamic placeholders against a sample student (used in the admin
// form's live preview). Mirrors the resolver in student-marketing.tsx but
// takes raw name/batch strings instead of a full Student object so the admin
// form can preview without needing a real student record.
function resolvePreviewPlaceholders(
  raw: string,
  sampleName: string,
  sampleBatch: string,
): string {
  if (!raw) return ''
  const parts = sampleName.trim().split(/\s+/)
  const firstName = parts[0] || sampleName
  const lastName = parts.length > 1 ? parts.slice(1).join(' ') : ''
  let level = sampleBatch
  const levelMatch = sampleBatch.match(/([A-Za-z])\s*$/)
  if (levelMatch) level = `Level ${levelMatch[1].toUpperCase()}`
  const today = new Date().toLocaleDateString()
  const vars: Record<string, string> = {
    student_name: sampleName,
    first_name: firstName,
    last_name: lastName,
    level,
    batch: sampleBatch,
    today_date: today,
  }
  return raw.replace(/\{\{\s*(\w+)\s*\}\}/g, (full, key: string) =>
    Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : full,
  )
}

// Inline message renderer for the admin form's live preview. Same paragraph /
// bullet-list logic as the student-facing TextMessageBody component.
function MessagePreview({
  content,
  sampleName,
  sampleBatch,
}: {
  content: string
  sampleName: string
  sampleBatch: string
}) {
  const resolved = resolvePreviewPlaceholders(content, sampleName, sampleBatch)
  const blocks = resolved
    .replace(/\r\n/g, '\n')
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((para) => {
      const lines = para.split('\n')
      const bulletRe = /^\s*([-•*—])\s+/
      const isList = lines.length > 0 && lines.every((l) => bulletRe.test(l))
      if (isList) {
        return { type: 'list' as const, items: lines.map((l) => l.replace(bulletRe, '').trim()) }
      }
      return { type: 'para' as const, lines }
    })

  return (
    <div className="space-y-2">
      {blocks.map((block, i) =>
        block.type === 'list' ? (
          <ul key={i} className="space-y-1">
            {block.items.map((item, j) => (
              <li key={j} className="flex items-start gap-2 text-xs text-foreground/90">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-500" aria-hidden />
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p key={i} className="text-xs leading-relaxed text-foreground/90">
            {block.lines.map((line, k) => (
              <React.Fragment key={k}>
                {k > 0 && <br />}
                {line}
              </React.Fragment>
            ))}
          </p>
        ),
      )}
    </div>
  )
}

// ─────────────────────── Main component ───────────────────────
export function AdminMarketing() {
  const pageTitle = useNavLabel('marketing', 'Marketing')
  const {
    marketingCampaigns, addMarketingCampaign, updateMarketingCampaign,
    deleteMarketingCampaign, duplicateMarketingCampaign,
    students, batches,
  } = useDataStore()

  const [search, setSearch] = React.useState('')
  const [statusFilter, setStatusFilter] = React.useState<'all' | 'published' | 'paused' | 'draft'>('all')
  const [typeFilter, setTypeFilter] = React.useState<'all' | 'banner' | 'video' | 'text'>('all')
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [editing, setEditing] = React.useState<MarketingCampaign | null>(null)
  const [form, setForm] = React.useState<CampaignForm>(emptyForm)
  const [deleteTarget, setDeleteTarget] = React.useState<MarketingCampaign | null>(null)
  const [studentSearch, setStudentSearch] = React.useState('')

  // Filtered campaigns (newest first for the table)
  const filtered = React.useMemo(() => {
    return marketingCampaigns
      .filter((c) => {
        if (statusFilter !== 'all' && c.status !== statusFilter) return false
        if (typeFilter !== 'all' && c.type !== typeFilter) return false
        if (search) {
          const q = search.toLowerCase()
          if (!c.title.toLowerCase().includes(q) && !c.description.toLowerCase().includes(q)) return false
        }
        return true
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  }, [marketingCampaigns, search, statusFilter, typeFilter])

  // Stats summary
  const stats = React.useMemo(() => {
    const published = marketingCampaigns.filter((c) => c.status === 'published').length
    const drafts = marketingCampaigns.filter((c) => c.status === 'draft').length
    const paused = marketingCampaigns.filter((c) => c.status === 'paused').length
    return { total: marketingCampaigns.length, published, drafts, paused }
  }, [marketingCampaigns])

  function openAdd() {
    setEditing(null)
    setForm(emptyForm)
    setStudentSearch('')
    setDialogOpen(true)
  }

  function openEdit(c: MarketingCampaign) {
    setEditing(c)
    setForm(campaignToForm(c))
    setStudentSearch('')
    setDialogOpen(true)
  }

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 4 * 1024 * 1024) {
      toast.error('Image too large', { description: 'Please use an image under 4 MB.' })
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = String(reader.result || '')
      setForm((f) => ({ ...f, image: dataUrl }))
      toast.success('Banner uploaded', { description: file.name })
    }
    reader.onerror = () => toast.error('Could not read the image file.')
    reader.readAsDataURL(file)
  }

  function toggleBatch(name: string) {
    setForm((f) => ({
      ...f,
      targetBatches: f.targetBatches.includes(name)
        ? f.targetBatches.filter((b) => b !== name)
        : [...f.targetBatches, name],
    }))
  }

  function toggleStudent(id: string) {
    setForm((f) => ({
      ...f,
      targetStudentIds: f.targetStudentIds.includes(id)
        ? f.targetStudentIds.filter((s) => s !== id)
        : [...f.targetStudentIds, id],
    }))
  }

  function handleSave() {
    // Validation
    if (!form.title.trim()) {
      toast.error('Title is required')
      return
    }
    if (form.type === 'banner' && !form.image) {
      toast.error('Please upload a banner image')
      return
    }
    if (form.type === 'video' && !youtubeEmbedUrl(form.videoUrl)) {
      toast.error('Please enter a valid YouTube URL')
      return
    }
    if (form.type === 'text' && !form.messageContent.trim()) {
      toast.error('Please write the message content')
      return
    }
    if (form.audience === 'batch' && form.targetBatches.length === 0) {
      toast.error('Select at least one batch for targeting')
      return
    }
    if (form.audience === 'individual' && form.targetStudentIds.length === 0) {
      toast.error('Select at least one student for targeting')
      return
    }
    if (form.startDate && form.endDate && form.startDate > form.endDate) {
      toast.error('End date must be after start date')
      return
    }
    if (form.ctaText && !form.ctaUrl) {
      toast.error('CTA URL is required when CTA text is set')
      return
    }

    const payload = {
      title: form.title.trim(),
      description: form.description.trim(),
      type: form.type,
      image: form.type === 'banner' ? form.image : undefined,
      videoUrl: form.type === 'video' ? form.videoUrl.trim() : undefined,
      messageContent: form.type === 'text' ? form.messageContent.trim() : undefined,
      audience: form.audience,
      targetBatches: form.audience === 'batch' ? form.targetBatches : undefined,
      targetStudentIds: form.audience === 'individual' ? form.targetStudentIds : undefined,
      startDate: form.startDate,
      endDate: form.endDate,
      priority: Number(form.priority) || 1,
      status: form.status,
      ctaText: form.ctaText.trim() || undefined,
      ctaUrl: form.ctaUrl.trim() || undefined,
      author: 'Prof. Kalpesh Vyas',
    }

    if (editing) {
      updateMarketingCampaign(editing.id, payload)
      toast.success('Campaign updated', { description: form.title })
    } else {
      addMarketingCampaign(payload)
      toast.success('Campaign created', { description: form.title })
    }
    setDialogOpen(false)
  }

  function handleTogglePause(c: MarketingCampaign) {
    const next = c.status === 'published' ? 'paused' : 'published'
    updateMarketingCampaign(c.id, { status: next })
    toast.success(next === 'published' ? 'Campaign published' : 'Campaign paused', { description: c.title })
  }

  function handleDelete() {
    if (!deleteTarget) return
    deleteMarketingCampaign(deleteTarget.id)
    toast.success('Campaign deleted', { description: deleteTarget.title })
    setDeleteTarget(null)
  }

  // Filtered students for the individual-target picker
  const filteredStudents = React.useMemo(() => {
    if (!studentSearch) return students
    const q = studentSearch.toLowerCase()
    return students.filter((s) =>
      s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q) || s.id.toLowerCase().includes(q),
    )
  }, [students, studentSearch])

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Promote courses, offers & events on the student dashboard"
        icon={<Images className="h-5 w-5" />}
        actions={
          <Button onClick={openAdd} className="gap-2">
            <Plus className="h-4 w-4" /> Add Campaign
          </Button>
        }
      />

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card className="card-elevated">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Images className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold leading-none">{stats.total}</p>
              <p className="mt-1 text-xs text-muted-foreground">Total Campaigns</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-elevated">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold leading-none">{stats.published}</p>
              <p className="mt-1 text-xs text-muted-foreground">Published</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-elevated">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold leading-none">{stats.drafts}</p>
              <p className="mt-1 text-xs text-muted-foreground">Drafts</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-elevated">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-muted text-muted-foreground">
              <Pause className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold leading-none">{stats.paused}</p>
              <p className="mt-1 text-xs text-muted-foreground">Paused</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search campaigns..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="banner">Banner Image</SelectItem>
              <SelectItem value="video">YouTube Video</SelectItem>
              <SelectItem value="text">Text Banner</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Campaign list */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Images}
          title={marketingCampaigns.length === 0 ? 'No marketing campaigns yet' : 'No campaigns match your filters'}
          description={marketingCampaigns.length === 0
            ? 'Create your first campaign to promote courses, offers, or events on student dashboards.'
            : 'Try adjusting your search or filters.'}
          action={marketingCampaigns.length === 0 ? (
            <Button onClick={openAdd} className="gap-2">
              <Plus className="h-4 w-4" /> Add your first campaign
            </Button>
          ) : undefined}
        />
      ) : (
        <Card className="card-elevated overflow-hidden p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[220px]">Campaign</TableHead>
                  <TableHead className="min-w-[110px]">Type</TableHead>
                  <TableHead className="min-w-[130px]">Target</TableHead>
                  <TableHead className="min-w-[160px]">Duration</TableHead>
                  <TableHead className="min-w-[80px]">Priority</TableHead>
                  <TableHead className="min-w-[110px]">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        {/* Thumbnail */}
                        <div className="h-11 w-16 shrink-0 overflow-hidden rounded-lg border bg-muted">
                          {c.type === 'banner' && c.image ? (
                            <img src={c.image} alt="" className="h-full w-full object-cover" />
                          ) : c.type === 'video' && youtubeThumb(c.videoUrl || '') ? (
                            <img src={youtubeThumb(c.videoUrl || '') || ''} alt="" className="h-full w-full object-cover" />
                          ) : c.type === 'text' ? (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-100 to-teal-100 text-emerald-600 dark:from-emerald-950/40 dark:to-teal-950/40 dark:text-emerald-300">
                              <Sparkles className="h-4 w-4" />
                            </div>
                          ) : (
                            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                              {c.type === 'video' ? <Youtube className="h-4 w-4" /> : <ImageIcon className="h-4 w-4" />}
                            </div>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="truncate font-medium">{c.title}</p>
                          <p className="truncate text-xs text-muted-foreground">
                            {c.type === 'text'
                              ? (c.messageContent?.slice(0, 80) || 'No message')
                              : (c.description || 'No description')}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="gap-1">
                        {c.type === 'banner' && <ImageIcon className="h-3 w-3" />}
                        {c.type === 'video' && <Youtube className="h-3 w-3" />}
                        {c.type === 'text' && <Sparkles className="h-3 w-3" />}
                        {c.type === 'banner' ? 'Banner' : c.type === 'video' ? 'Video' : 'Text'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-sm">
                        {c.audience === 'all' && <Globe className="h-3.5 w-3.5 text-muted-foreground" />}
                        {c.audience === 'batch' && <Layers className="h-3.5 w-3.5 text-muted-foreground" />}
                        {c.audience === 'individual' && <Users className="h-3.5 w-3.5 text-muted-foreground" />}
                        <span>{audienceLabel(c)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Calendar className="h-3.5 w-3.5" />
                        <span>{dateRangeLabel(c)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="tabular-nums">#{c.priority}</Badge>
                    </TableCell>
                    <TableCell>{statusBadge(c.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Filter className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(c)}>
                            <Pencil className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => duplicateMarketingCampaign(c.id)}>
                            <Copy className="mr-2 h-4 w-4" /> Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleTogglePause(c)}>
                            {c.status === 'published' ? (
                              <><Pause className="mr-2 h-4 w-4" /> Pause</>
                            ) : (
                              <><Play className="mr-2 h-4 w-4" /> Publish</>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => setDeleteTarget(c)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* ───────────── Add / Edit Dialog ───────────── */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Campaign' : 'Add Marketing Campaign'}</DialogTitle>
            <DialogDescription>
              {editing
                ? 'Update the campaign details below.'
                : 'Create a banner or video campaign shown on the student dashboard.'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="mc-title">Campaign Title <span className="text-destructive">*</span></Label>
              <Input
                id="mc-title"
                placeholder="e.g. New IELTS Batch — Enrollments Open"
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="mc-desc">Description</Label>
              <Textarea
                id="mc-desc"
                placeholder="Short description shown under the banner / video"
                rows={2}
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              />
            </div>

            {/* Type selector */}
            <div className="space-y-2">
              <Label>Campaign Type <span className="text-destructive">*</span></Label>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, type: 'banner' }))}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border-2 p-4 text-center transition hover:bg-accent',
                    form.type === 'banner' ? 'border-primary bg-primary/5' : 'border-border',
                  )}
                >
                  <ImageIcon className="h-6 w-6 text-primary" />
                  <span className="text-sm font-medium">Banner Image</span>
                  <span className="text-xs text-muted-foreground">Upload a promotional image</span>
                </button>
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, type: 'video' }))}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border-2 p-4 text-center transition hover:bg-accent',
                    form.type === 'video' ? 'border-primary bg-primary/5' : 'border-border',
                  )}
                >
                  <Youtube className="h-6 w-6 text-red-500" />
                  <span className="text-sm font-medium">YouTube Video</span>
                  <span className="text-xs text-muted-foreground">Embed a YouTube link</span>
                </button>
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, type: 'text' }))}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border-2 p-4 text-center transition hover:bg-accent',
                    form.type === 'text' ? 'border-primary bg-primary/5' : 'border-border',
                  )}
                >
                  <Sparkles className="h-6 w-6 text-emerald-500" />
                  <span className="text-sm font-medium">Text Banner</span>
                  <span className="text-xs text-muted-foreground">Personalized text message</span>
                </button>
              </div>
            </div>

            {/* Banner upload */}
            {form.type === 'banner' && (
              <div className="space-y-2">
                <Label>Banner Image <span className="text-destructive">*</span></Label>
                {form.image ? (
                  <div className="relative overflow-hidden rounded-xl border">
                    <img src={form.image} alt="Banner preview" className="max-h-56 w-full object-cover" />
                    <div className="absolute right-2 top-2 flex gap-2">
                      <label>
                        <span className="inline-flex cursor-pointer items-center gap-1 rounded-md bg-black/70 px-2.5 py-1 text-xs text-white backdrop-blur hover:bg-black/80">
                          <Pencil className="h-3 w-3" /> Replace
                        </span>
                        <input type="file" accept="image/*" className="sr-only" onChange={handleImageUpload} />
                      </label>
                      <Button
                        type="button"
                        size="sm"
                        variant="destructive"
                        className="h-7 px-2 text-xs"
                        onClick={() => setForm((f) => ({ ...f, image: '' }))}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-8 text-center transition hover:bg-accent">
                    <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Click to upload banner</p>
                      <p className="text-xs text-muted-foreground">PNG / JPG up to 4 MB</p>
                    </div>
                    <input type="file" accept="image/*" className="sr-only" onChange={handleImageUpload} />
                  </label>
                )}
              </div>
            )}

            {/* YouTube URL */}
            {form.type === 'video' && (
              <div className="space-y-2">
                <Label htmlFor="mc-video">YouTube URL <span className="text-destructive">*</span></Label>
                <Input
                  id="mc-video"
                  placeholder="https://www.youtube.com/watch?v=..."
                  value={form.videoUrl}
                  onChange={(e) => setForm((f) => ({ ...f, videoUrl: e.target.value }))}
                />
                {form.videoUrl && youtubeEmbedUrl(form.videoUrl) ? (
                  <div className="mt-2 overflow-hidden rounded-xl border bg-black">
                    <div className="aspect-video w-full">
                      <iframe
                        src={youtubeEmbedUrl(form.videoUrl) || ''}
                        title="Video preview"
                        className="h-full w-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  </div>
                ) : form.videoUrl ? (
                  <p className="flex items-center gap-1.5 text-xs text-destructive">
                    <AlertCircle className="h-3.5 w-3.5" /> Invalid YouTube URL
                  </p>
                ) : null}
                <p className="text-xs text-muted-foreground">
                  Supports youtube.com/watch, youtu.be, /embed/, and /shorts/ links.
                </p>
              </div>
            )}

            {/* v3.52.0 — Text Banner message content */}
            {form.type === 'text' && (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="mc-message-content">
                    Message Content <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    id="mc-message-content"
                    placeholder={'Hello {{student_name}} 👋\n\nCongratulations on completing your current level! 🎉\n\nWe are excited to invite you to the next batch.\n\n• Exclusive early-bird discount\n• Limited seats — reserve today\n\nRegister now to continue your learning journey. ✨'}
                    rows={9}
                    className="font-mono text-sm leading-relaxed"
                    value={form.messageContent}
                    onChange={(e) => setForm((f) => ({ ...f, messageContent: e.target.value }))}
                  />
                  <p className="text-xs text-muted-foreground">
                    Write your promotional message. Supports paragraphs, line breaks,
                    bullet lists (lines starting with •, -, * or —), and emoji.
                  </p>
                </div>

                {/* Dynamic variables reference */}
                <div className="rounded-lg border border-emerald-200/60 bg-emerald-50/50 p-3 dark:border-emerald-900/40 dark:bg-emerald-950/20">
                  <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                    <Variable className="h-3.5 w-3.5" />
                    Dynamic Variables
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { token: '{{student_name}}', desc: 'Full name' },
                      { token: '{{first_name}}', desc: 'First name' },
                      { token: '{{last_name}}', desc: 'Last name' },
                      { token: '{{level}}', desc: 'Level' },
                      { token: '{{batch}}', desc: 'Batch' },
                      { token: '{{today_date}}', desc: "Today's date" },
                    ].map((v) => (
                      <button
                        key={v.token}
                        type="button"
                        onClick={() =>
                          setForm((f) => ({
                            ...f,
                            messageContent: f.messageContent + (f.messageContent && !f.messageContent.endsWith(' ') ? ' ' : '') + v.token,
                          }))
                        }
                        className="inline-flex items-center gap-1 rounded-md border border-emerald-200 bg-white px-2 py-1 text-xs font-medium text-emerald-700 transition hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 dark:hover:bg-emerald-900/40"
                        title={`Click to insert ${v.token} — ${v.desc}`}
                      >
                        <code className="font-mono">{v.token}</code>
                        <span className="text-muted-foreground">{v.desc}</span>
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Click any variable to insert it. Placeholders are replaced
                    automatically for each student when the campaign renders.
                  </p>
                </div>

                {/* Live preview */}
                {form.messageContent.trim() && (
                  <div className="space-y-1.5">
                    <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                      Live Preview (with sample student “Aarav Sharma, Batch 2026-A”)
                    </Label>
                    <div className="overflow-hidden rounded-xl border border-emerald-200/60 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 p-4 dark:border-emerald-900/40 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-cyan-950/20">
                      <div className="mb-2 flex items-center gap-2">
                        <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-300">
                          <Sparkles className="h-3.5 w-3.5" />
                        </span>
                        <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
                          {form.title || 'Special Announcement'}
                        </span>
                      </div>
                      <MessagePreview
                        content={form.messageContent}
                        sampleName="Aarav Sharma"
                        sampleBatch="Batch 2026-A"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Audience */}
            <div className="space-y-2">
              <Label>Target Audience <span className="text-destructive">*</span></Label>
              <Select
                value={form.audience}
                onValueChange={(v) => setForm((f) => ({ ...f, audience: v as CampaignForm['audience'] }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    <span className="flex items-center gap-2"><Globe className="h-4 w-4" /> All Students</span>
                  </SelectItem>
                  <SelectItem value="batch">
                    <span className="flex items-center gap-2"><Layers className="h-4 w-4" /> Specific Batch / Level</span>
                  </SelectItem>
                  <SelectItem value="individual">
                    <span className="flex items-center gap-2"><Users className="h-4 w-4" /> Specific Student(s)</span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Batch picker */}
            {form.audience === 'batch' && (
              <div className="space-y-2">
                <Label>Select Batches / Levels</Label>
                {batches.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No levels found. Create levels first in Levels Management.</p>
                ) : (
                  <div className="grid grid-cols-1 gap-2 rounded-lg border p-3 sm:grid-cols-2">
                    {batches.map((b: Batch) => (
                      <label
                        key={b.id}
                        className="flex cursor-pointer items-center gap-2.5 rounded-md p-2 transition hover:bg-accent"
                      >
                        <Checkbox
                          checked={form.targetBatches.includes(b.name)}
                          onCheckedChange={() => toggleBatch(b.name)}
                        />
                        <span className="text-sm">{b.name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Student picker */}
            {form.audience === 'individual' && (
              <div className="space-y-2">
                <Label>Select Students</Label>
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, email, or ID..."
                    value={studentSearch}
                    onChange={(e) => setStudentSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <ScrollArea className="h-56 rounded-lg border">
                  <div className="divide-y">
                    {filteredStudents.map((s: Student) => (
                      <label
                        key={s.id}
                        className="flex cursor-pointer items-center gap-3 p-2.5 transition hover:bg-accent"
                      >
                        <Checkbox
                          checked={form.targetStudentIds.includes(s.id)}
                          onCheckedChange={() => toggleStudent(s.id)}
                        />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">{s.name}</p>
                          <p className="truncate text-xs text-muted-foreground">{s.email} · {s.batch}</p>
                        </div>
                      </label>
                    ))}
                    {filteredStudents.length === 0 && (
                      <p className="p-4 text-center text-sm text-muted-foreground">No students found.</p>
                    )}
                  </div>
                </ScrollArea>
                {form.targetStudentIds.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {form.targetStudentIds.length} student{form.targetStudentIds.length > 1 ? 's' : ''} selected
                  </p>
                )}
              </div>
            )}

            {/* Duration + Priority */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="mc-start">Start Date</Label>
                <Input
                  id="mc-start"
                  type="date"
                  value={form.startDate}
                  onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mc-end">End Date</Label>
                <Input
                  id="mc-end"
                  type="date"
                  value={form.endDate}
                  onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mc-prio">Display Priority</Label>
                <Input
                  id="mc-prio"
                  type="number"
                  min={1}
                  value={form.priority}
                  onChange={(e) => setForm((f) => ({ ...f, priority: Number(e.target.value) }))}
                />
                <p className="text-xs text-muted-foreground">Lower = shown first</p>
              </div>
            </div>

            {/* CTA */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="mc-cta-text">CTA Button Text <span className="text-muted-foreground">(optional)</span></Label>
                <Input
                  id="mc-cta-text"
                  placeholder="e.g. Enroll Now"
                  value={form.ctaText}
                  onChange={(e) => setForm((f) => ({ ...f, ctaText: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mc-cta-url">CTA Button URL <span className="text-muted-foreground">(optional)</span></Label>
                <Input
                  id="mc-cta-url"
                  placeholder="https://..."
                  value={form.ctaUrl}
                  onChange={(e) => setForm((f) => ({ ...f, ctaUrl: e.target.value }))}
                />
              </div>
            </div>

            {/* Status */}
            <div className="space-y-2">
              <Label htmlFor="mc-status">Campaign Status</Label>
              <Select
                value={form.status}
                onValueChange={(v) => setForm((f) => ({ ...f, status: v as CampaignForm['status'] }))}
              >
                <SelectTrigger id="mc-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">
                    <span className="flex items-center gap-2"><Pencil className="h-4 w-4" /> Draft (hidden from students)</span>
                  </SelectItem>
                  <SelectItem value="published">
                    <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Published (live on dashboard)</span>
                  </SelectItem>
                  <SelectItem value="paused">
                    <span className="flex items-center gap-2"><Pause className="h-4 w-4" /> Paused (temporarily hidden)</span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Live preview */}
            {(form.type === 'banner' ? form.image : youtubeEmbedUrl(form.videoUrl)) && (
              <div className="space-y-2">
                <Label>Live Preview</Label>
                <div className="overflow-hidden rounded-xl border bg-muted/30">
                  <div className="p-4">
                    <CampaignPreview form={form} />
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>
              {editing ? 'Save Changes' : 'Create Campaign'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete campaign?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete &ldquo;{deleteTarget?.title}&rdquo;. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete Campaign
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ─────────────────────── Campaign Preview (used in the admin dialog) ───────────────────────
function CampaignPreview({ form }: { form: CampaignForm }) {
  if (form.type === 'banner' && form.image) {
    return (
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        {form.ctaUrl ? (
          <a href={form.ctaUrl} target="_blank" rel="noopener noreferrer">
            <img src={form.image} alt={form.title} className="block max-h-48 w-full object-cover" />
          </a>
        ) : (
          <img src={form.image} alt={form.title} className="block max-h-48 w-full object-cover" />
        )}
        {(form.title || form.description || form.ctaText) && (
          <div className="space-y-2 p-4">
            {form.title && <h4 className="font-semibold leading-tight">{form.title}</h4>}
            {form.description && <p className="text-sm text-muted-foreground">{form.description}</p>}
            {form.ctaText && form.ctaUrl && (
              <Button size="sm" className="gap-1.5">
                {form.ctaText} <ArrowUpRight className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        )}
      </div>
    )
  }
  if (form.type === 'video' && youtubeEmbedUrl(form.videoUrl)) {
    return (
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <div className="aspect-video w-full bg-black">
          <iframe
            src={youtubeEmbedUrl(form.videoUrl) || ''}
            title={form.title}
            className="h-full w-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
        {(form.title || form.description || form.ctaText) && (
          <div className="space-y-2 p-4">
            {form.title && <h4 className="font-semibold leading-tight">{form.title}</h4>}
            {form.description && <p className="text-sm text-muted-foreground">{form.description}</p>}
            {form.ctaText && form.ctaUrl && (
              <Button size="sm" className="gap-1.5">
                {form.ctaText} <ArrowUpRight className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        )}
      </div>
    )
  }
  return null
}
