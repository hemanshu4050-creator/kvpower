'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowUpRight,
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  Database,
  FileQuestion,
  Hash,
  Image as ImageIcon,
  ImagePlus,
  Lightbulb,
  ListChecks,
  Minus,
  MoreHorizontal,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Sigma,
  Sparkles,
  Target,
  ToggleLeft,
  Trash2,
  Type,
  Upload,
  X,
  Award,
  Flame,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useDataStore, type Question, type QuestionLevel, QUESTION_LEVELS } from '@/lib/data-store'
// v3.53.6 — Import-from-Word/PDF feature
import { ImportQuestionsDialog } from '@/components/admin/import-questions-dialog'
import { FileUp } from 'lucide-react'
import { useNavLabel } from '@/lib/nav-helpers'

// ────────────────────────────────────────────────────────────────────────────
//  Constants & types
// ────────────────────────────────────────────────────────────────────────────

const typeBadge: Record<Question['type'], string> = {
  mcq: 'border-sky-500/30 bg-sky-500/10 text-sky-700 dark:text-sky-300',
  numerical: 'border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-violet-300',
  'true-false': 'border-teal-500/30 bg-teal-500/10 text-teal-700 dark:text-teal-300',
}

// v3.54.0 — 12 levels (was 4 difficulty tiers). Color ramp goes
// sky → cyan → emerald → lime → amber → orange → rose across the 12
// levels so the admin gets a visual sense of progression.
const difficultyBadge: Record<Question['difficulty'], string> = {
  'level-1':  'border-sky-500/30 bg-sky-500/10 text-sky-700 dark:text-sky-300',
  'level-2':  'border-sky-500/30 bg-sky-500/10 text-sky-700 dark:text-sky-300',
  'level-3':  'border-cyan-500/30 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300',
  'level-4':  'border-cyan-500/30 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300',
  'level-5':  'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  'level-6':  'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  'level-7':  'border-lime-500/30 bg-lime-500/10 text-lime-700 dark:text-lime-300',
  'level-8':  'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  'level-9':  'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  'level-10': 'border-orange-500/30 bg-orange-500/10 text-orange-700 dark:text-orange-300',
  'level-11': 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
  'level-12': 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
}

// v3.54.0 — dot color for each level (matches the badge color ramp).
const levelDotColor: Record<Question['difficulty'], string> = {
  'level-1':  'bg-sky-500',
  'level-2':  'bg-sky-500',
  'level-3':  'bg-cyan-500',
  'level-4':  'bg-cyan-500',
  'level-5':  'bg-emerald-500',
  'level-6':  'bg-emerald-500',
  'level-7':  'bg-lime-500',
  'level-8':  'bg-amber-500',
  'level-9':  'bg-amber-500',
  'level-10': 'bg-orange-500',
  'level-11': 'bg-rose-500',
  'level-12': 'bg-rose-500',
}

const typeLabels: Record<Question['type'], string> = {
  mcq: 'MCQ',
  numerical: 'Numerical',
  'true-false': 'True / False',
}

const typeFullLabels: Record<Question['type'], string> = {
  mcq: 'Multiple Choice',
  numerical: 'Numerical',
  'true-false': 'True / False',
}

const typeDescriptions: Record<Question['type'], string> = {
  mcq: '4 options, pick the correct one',
  numerical: '4 answer options',
  'true-false': 'Binary choice question',
}

const typeIcons: Record<Question['type'], typeof Type> = {
  mcq: ListChecks,
  numerical: Hash,
  'true-false': ToggleLeft,
}

// v3.54.0 — 12 level descriptions (was 4 difficulty descriptions).
const difficultyDescriptions: Record<Question['difficulty'], string> = {
  'level-1':  'Foundational / entry',
  'level-2':  'Basic recall',
  'level-3':  'Warm-up level',
  'level-4':  'Guided practice',
  'level-5':  'Standard practice',
  'level-6':  'Confident practice',
  'level-7':  'Independent practice',
  'level-8':  'Application level',
  'level-9':  'Multi-step problems',
  'level-10': 'Challenge level',
  'level-11': 'Stretch / advanced',
  'level-12': 'Mastery / extension',
}

interface QuestionForm {
  id?: string
  chapterIds: string[]
  type: Question['type']
  difficulty: Question['difficulty']
  text: string
  imageData?: string
  imageName?: string
  explanationImage?: string
  explanationImageName?: string
  options: string[]
  correctAnswer: number
  explanation: string
  marks: number
}

const emptyForm = (chapterIds: string[]): QuestionForm => ({
  chapterIds,
  type: 'mcq',
  difficulty: 'level-6',
  text: '',
  options: ['', '', '', ''],
  correctAnswer: 0,
  explanation: '',
  marks: 2,
})

// Max image payload (bytes) — keeps localStorage budget under control.
const MAX_IMAGE_BYTES = 800 * 1024 // 800 KB

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']

// ────────────────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────────────────

/** Animated count-up number. */
function AnimatedNumber({ value, duration = 600 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const from = display
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (value - from) * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value])
  return <span className="tabular-nums">{display}</span>
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminQuestions() {
  const pageTitle = useNavLabel('questions', 'Question Bank')
  const {
    chapters,
    questions,
    exams,
    results,
    addQuestion,
    addQuestions,
    updateQuestion,
    deleteQuestion,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [chapterFilter, setChapterFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')
  const [difficultyFilter, setDifficultyFilter] = useState('all')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(8)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  // v3.53.6 — Import-from-Word/PDF dialog state
  const [importOpen, setImportOpen] = useState(false)
  const [editing, setEditing] = useState<QuestionForm>(emptyForm(chapters[0] ? [chapters[0].id] : []))
  const [deleteTarget, setDeleteTarget] = useState<Question | null>(null)
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false)
  const [lastSync, setLastSync] = useState(() => new Date())

  const chapterName = (id: string) =>
    chapters.find((c) => c.id === id)?.name ?? '—'

  const questionChapters = (q: Question): string[] =>
    q.chapterIds?.length ? q.chapterIds : [q.chapterId]

  const filtered = useMemo(() => {
    return questions.filter((q) => {
      const s = search.trim().toLowerCase()
      if (s && !q.text.toLowerCase().includes(s) && !q.id.toLowerCase().includes(s)) return false
      if (chapterFilter !== 'all' && !questionChapters(q).includes(chapterFilter)) return false
      if (typeFilter !== 'all' && q.type !== typeFilter) return false
      if (difficultyFilter !== 'all' && q.difficulty !== difficultyFilter) return false
      return true
    })
  }, [questions, search, chapterFilter, typeFilter, difficultyFilter])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const toggleRow = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  const togglePage = () => {
    const allOnPage = rows.length > 0 && rows.every((r) => selected.has(r.id))
    setSelected((prev) => {
      const next = new Set(prev)
      if (allOnPage) rows.forEach((r) => next.delete(r.id))
      else rows.forEach((r) => next.add(r.id))
      return next
    })
  }

  const clearFilters = () => {
    setSearch('')
    setChapterFilter('all')
    setTypeFilter('all')
    setDifficultyFilter('all')
    setPage(0)
  }

  const usageCount = (qid: string) =>
    exams.filter((e) => e.questionIds.includes(qid)).length

  const successRate = (qid: string) => {
    let total = 0
    let correct = 0
    for (const r of results) {
      for (const a of r.answers) {
        if (a.questionId === qid) {
          total++
          if (a.isCorrect) correct++
        }
      }
    }
    return total ? Math.round((correct / total) * 100) : 0
  }

  // ── Aggregate analytics ──
  // Per-chapter question counts so the chapter filter dropdown can show
  // "(N)" next to each chapter — instantly shows how many questions live
  // in each chapter without the admin having to select it first.
  const chapterQuestionCount = useMemo(() => {
    const map: Record<string, number> = {}
    for (const q of questions) {
      const ids = q.chapterIds?.length ? q.chapterIds : [q.chapterId]
      for (const cid of ids) map[cid] = (map[cid] || 0) + 1
    }
    return map
  }, [questions])
  const totalQuestionCount = questions.length
  const mcqCount = useMemo(() => questions.filter((q) => q.type === 'mcq').length, [questions])
  const numericalCount = useMemo(() => questions.filter((q) => q.type === 'numerical').length, [questions])
  const tfCount = useMemo(() => questions.filter((q) => q.type === 'true-false').length, [questions])
  const inExams = useMemo(
    () => questions.filter((q) => exams.some((e) => e.questionIds.includes(q.id))).length,
    [questions, exams]
  )
  const avgSuccess = useMemo(() => {
    let total = 0
    let count = 0
    for (const q of questions) {
      const sr = successRate(q.id)
      if (sr > 0) {
        total += sr
        count++
      }
    }
    return count ? Math.round(total / count) : 0
  }, [questions, results])

  const activeFilters = !!search || chapterFilter !== 'all' || typeFilter !== 'all' || difficultyFilter !== 'all'

  // ── Handlers ──
  const openAdd = () => {
    setEditing(
      emptyForm(
        chapterFilter !== 'all'
          ? [chapterFilter]
          : chapters[0]
            ? [chapters[0].id]
            : [],
      ),
    )
    setAddOpen(true)
  }
  const openEdit = (q: Question) => {
    setEditing({
      id: q.id,
      chapterIds: q.chapterIds?.length ? [...q.chapterIds] : [q.chapterId],
      type: q.type,
      difficulty: q.difficulty,
      text: q.text,
      imageData: q.imageData,
      imageName: q.imageName,
      explanationImage: q.explanationImage,
      explanationImageName: q.explanationImageName,
      options: [...q.options],
      correctAnswer: q.correctAnswer,
      explanation: q.explanation,
      marks: q.marks,
    })
    setEditOpen(true)
  }

  const buildQuestionFromForm = (f: QuestionForm): Omit<Question, 'id' | 'createdAt'> => {
    let options = f.options
    if (f.type === 'true-false') {
      options = ['True', 'False', '', '']
    } else {
      options = f.options.length === 4 ? f.options : [...f.options, '', '', '', ''].slice(0, 4)
    }
    const correct = Math.min(Math.max(0, f.correctAnswer), options.length - 1)
    const payload: Omit<Question, 'id' | 'createdAt'> = {
      chapterId: f.chapterIds[0],
      chapterIds: f.chapterIds,
      type: f.type,
      difficulty: f.difficulty,
      text: f.text.trim(),
      options,
      correctAnswer: correct,
      explanation: f.explanation.trim(),
      marks: f.marks,
    }
    if (f.imageData) {
      payload.imageData = f.imageData
      payload.imageName = f.imageName
    }
    if (f.explanationImage) {
      payload.explanationImage = f.explanationImage
      payload.explanationImageName = f.explanationImageName
    }
    return payload
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.text.trim()) {
      toast.error('Question text is required')
      return
    }
    if (editing.chapterIds.length === 0) {
      toast.error('Please select at least one chapter')
      return
    }
    if (editing.type === 'mcq' && editing.options.some((o) => !o.trim())) {
      toast.error('All 4 MCQ options must be filled')
      return
    }
    addQuestion(buildQuestionFromForm(editing))
    toast.success('Question added to bank')
    setAddOpen(false)
  }

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    if (!editing.text.trim()) {
      toast.error('Question text is required')
      return
    }
    updateQuestion(editing.id, buildQuestionFromForm(editing))
    toast.success('Question updated')
    setEditOpen(false)
  }

  const handleDuplicate = (q: Question) => {
    const payload: Omit<Question, 'id' | 'createdAt'> = {
      chapterId: q.chapterId,
      chapterIds: q.chapterIds?.length ? [...q.chapterIds] : [q.chapterId],
      type: q.type,
      difficulty: q.difficulty,
      text: q.text,
      options: [...q.options],
      correctAnswer: q.correctAnswer,
      explanation: q.explanation,
      marks: q.marks,
    }
    if (q.imageData) {
      payload.imageData = q.imageData
      payload.imageName = q.imageName
    }
    if (q.explanationImage) {
      payload.explanationImage = q.explanationImage
      payload.explanationImageName = q.explanationImageName
    }
    addQuestion(payload)
    toast.success('Question duplicated', { description: q.id })
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    deleteQuestion(deleteTarget.id)
    toast.error('Question deleted', { description: deleteTarget.id })
    setDeleteTarget(null)
  }

  const handleBulkDelete = () => {
    let n = 0
    selected.forEach((id) => {
      deleteQuestion(id)
      n++
    })
    toast.error(`${n} question${n === 1 ? '' : 's'} deleted`)
    setSelected(new Set())
    setBulkDeleteOpen(false)
  }

  const exportCsv = () => {
    toast.success('Question bank exported', {
      description: `${filtered.length} questions → CSV`,
    })
  }

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      <PageHeader
        title={pageTitle}
        description="A shared pool of questions you can reuse across exams and practice sheets."
        icon={<Database className="h-5 w-5" />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="btn-premium-outline h-9"
              onClick={() => {
                setLastSync(new Date())
                toast.success('Question bank refreshed')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Sync</span>
            </Button>
            <Button variant="outline" className="btn-premium-outline h-9" onClick={exportCsv}>
              <Upload className="h-4 w-4" /> Export
            </Button>
            {/* v3.53.6 — Import from Word / PDF / txt */}
            <Button
              variant="outline"
              className="btn-premium-outline h-9"
              onClick={() => setImportOpen(true)}
              disabled={chapters.length === 0}
            >
              <FileUp className="h-4 w-4" /> <span className="hidden sm:inline">Import</span>
            </Button>
            <Button className="btn-premium-primary h-9" onClick={openAdd} disabled={chapters.length === 0}>
              <Plus className="h-4 w-4" /> Add Question
            </Button>
          </>
        }
      />

      {/* Status strip */}
      <div className="-mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative inline-flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          Question bank synced
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span>Last synced{' '}
          {lastSync.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{questions.length} questions</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{inExams} used in exams</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{avgSuccess}% avg success</span>
      </div>

      {/* ── Premium stat cards ── */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        <StatCard
          title="Total Questions"
          value={<AnimatedNumber value={questions.length} />}
          icon={Database}
          accent="emerald"
          subtitle="In bank"
          trend={{ value: '+12', positive: true }}
          delay={0}
        />
        <StatCard
          title="MCQ"
          value={<AnimatedNumber value={mcqCount} />}
          icon={ListChecks}
          accent="blue"
          subtitle="Multiple choice"
          trend={{ value: '+5', positive: true }}
          delay={0.05}
        />
        <StatCard
          title="Numerical"
          value={<AnimatedNumber value={numericalCount} />}
          icon={Hash}
          accent="violet"
          subtitle="Numeric answers"
          trend={{ value: '+3', positive: true }}
          delay={0.1}
        />
        <StatCard
          title="True / False"
          value={<AnimatedNumber value={tfCount} />}
          icon={ToggleLeft}
          accent="teal"
          subtitle="Binary choice"
          trend={{ value: '+2', positive: true }}
          delay={0.15}
        />
        <StatCard
          title="Used in Exams"
          value={<AnimatedNumber value={inExams} />}
          icon={Target}
          accent="amber"
          subtitle="Linked to exams"
          trend={{ value: '+4', positive: true }}
          delay={0.2}
        />
      </div>

      {/* ── Sticky filter bar ── */}
      <div className="sticky top-2 z-30">
        <div className="glass-filter-bar rounded-xl p-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                placeholder="Search by question text or ID…"
                className="input-premium h-9 pl-9"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={chapterFilter}
                onValueChange={(v) => { setChapterFilter(v); setPage(0) }}
              >
                <SelectTrigger className="h-9 w-[220px]">
                  <SelectValue placeholder="Chapter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All chapters ({totalQuestionCount})</SelectItem>
                  {chapters.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name} ({chapterQuestionCount[c.id] || 0})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setPage(0) }}>
                <SelectTrigger className="h-9 w-[130px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  <SelectItem value="mcq">MCQ</SelectItem>
                  <SelectItem value="numerical">Numerical</SelectItem>
                  <SelectItem value="true-false">True / False</SelectItem>
                </SelectContent>
              </Select>
              <Select value={difficultyFilter} onValueChange={(v) => { setDifficultyFilter(v); setPage(0) }}>
                <SelectTrigger className="h-9 w-[140px]">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All levels</SelectItem>
                  {QUESTION_LEVELS.map((lvl) => (
                    <SelectItem key={lvl} value={lvl}>Level {lvl.replace('level-', '')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {activeFilters && (
                <Button variant="ghost" size="sm" className="h-9" onClick={clearFilters}>
                  <X className="h-4 w-4" /> Clear
                </Button>
              )}
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
            <span>
              Showing{' '}
              <span className="font-medium text-foreground tabular-nums">
                {filtered.length === 0 ? 0 : start + 1}–{end}
              </span>{' '}
              of{' '}
              <span className="font-medium text-foreground tabular-nums">{filtered.length}</span>{' '}
              questions
            </span>
            <Separator orientation="vertical" className="mx-1 h-4" />
            <span className="num-premium">{mcqCount} MCQ</span>
            <span className="text-muted-foreground/40">·</span>
            <span className="num-premium">{numericalCount} numerical</span>
            <span className="text-muted-foreground/40">·</span>
            <span className="num-premium">{tfCount} true/false</span>
          </div>
        </div>
      </div>

      {/* ── Bulk action bar ── */}
      <AnimatePresence>
        {selected.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bulk-bar-premium sticky top-2 z-40 flex flex-wrap items-center gap-3 rounded-xl px-4 py-3"
          >
            <span className="badge-status border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
              <span className="num-premium font-bold">{selected.size}</span> selected
            </span>
            <Separator orientation="vertical" className="h-5" />
            <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
              <X className="h-4 w-4" /> Clear
            </Button>
            <div className="ml-auto flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="btn-premium-outline h-8"
                onClick={() => {
                  toast.success(`Duplicated ${selected.size} questions`)
                  setSelected(new Set())
                }}
              >
                <Copy className="h-3.5 w-3.5" /> Duplicate
              </Button>
              <Button
                size="sm"
                variant="destructive"
                className="h-8"
                onClick={() => setBulkDeleteOpen(true)}
              >
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Table ── */}
      <Card className="card-premium overflow-hidden p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={Database}
            title="No questions found"
            description="Adjust your filters or add a new question to the bank."
            action={
              <div className="flex gap-2">
                <Button variant="outline" className="btn-premium-outline" onClick={clearFilters}>
                  Reset filters
                </Button>
                <Button className="btn-premium-primary" onClick={openAdd} disabled={chapters.length === 0}>
                  <Plus className="h-4 w-4" /> Add question
                </Button>
              </div>
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/40 bg-muted/30 hover:bg-muted/30">
                  <TableHead className="w-[40px] pl-4">
                    <Checkbox
                      checked={rows.length > 0 && rows.every((r) => selected.has(r.id))}
                      onCheckedChange={togglePage}
                      aria-label="Select all on page"
                    />
                  </TableHead>
                  <TableHead>Question</TableHead>
                  <TableHead className="hidden md:table-cell">Chapter</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead className="text-right">Marks</TableHead>
                  <TableHead className="hidden lg:table-cell text-right">Usage</TableHead>
                  <TableHead className="hidden xl:table-cell">Success rate</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((q) => {
                  const usage = usageCount(q.id)
                  const sr = successRate(q.id)
                  const qChapters = questionChapters(q)
                  const shownChapters = qChapters.slice(0, 2)
                  const extraChapters = qChapters.slice(2)
                  const isSelected = selected.has(q.id)
                  const TypeIcon = typeIcons[q.type]
                  return (
                    <TableRow
                      key={q.id}
                      className={`row-premium group border-border/40 ${isSelected ? 'bg-primary/[0.03]' : ''}`}
                    >
                      <TableCell className="pl-4">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleRow(q.id)}
                          aria-label={`Select question ${q.id}`}
                        />
                      </TableCell>
                      <TableCell className="max-w-[360px]">
                        <div className="flex items-start gap-2.5">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted/40 text-muted-foreground">
                            <TypeIcon className="h-3.5 w-3.5" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="shrink-0 text-[10px] tabular-nums text-muted-foreground">
                                {q.id}
                              </Badge>
                              {q.imageData && (
                                <img
                                  src={q.imageData}
                                  alt=""
                                  className="h-8 w-8 shrink-0 rounded-md border object-cover"
                                />
                              )}
                            </div>
                            <p className="mt-1 line-clamp-2 text-sm leading-snug">{q.text}</p>
                            {q.imageData && (
                              <span className="chip-premium mt-1.5 border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                                <ImageIcon className="h-3 w-3" /> Has image
                              </span>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div className="flex flex-wrap items-center gap-1">
                          {shownChapters.map((chId) => (
                            <span key={chId} className="chip-premium border-border bg-background text-muted-foreground">
                              {chapterName(chId)}
                            </span>
                          ))}
                          {extraChapters.length > 0 && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="chip-premium cursor-help border-border bg-muted/40 text-muted-foreground tabular-nums">
                                  +{extraChapters.length} more
                                </span>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-[220px]">
                                {extraChapters.map((chId) => (
                                  <div key={chId} className="truncate">{chapterName(chId)}</div>
                                ))}
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`badge-status ${typeBadge[q.type]}`}>
                          <TypeIcon className="h-3 w-3" />
                          {typeLabels[q.type]}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={`badge-status capitalize ${difficultyBadge[q.difficulty]}`}>
                          <span
                            className={`inline-flex h-1.5 w-1.5 rounded-full ${levelDotColor[q.difficulty]}`}
                          />
                          {q.difficulty.replace('-', ' ')}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="num-premium font-semibold">{q.marks}</span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-right">
                        <span className="num-premium text-muted-foreground">{usage}</span>
                        <span className="text-xs text-muted-foreground/70"> exams</span>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell">
                        <div className="flex items-center gap-2">
                          <div className="progress-premium h-1.5 w-16">
                            <div
                              className="progress-premium-fill"
                              style={{ width: `${Math.max(3, sr)}%` }}
                            />
                          </div>
                          <span className="num-premium text-xs text-muted-foreground">{sr}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="pr-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="icon-btn-premium h-8 w-8"
                                onClick={() => openEdit(q)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Edit question</TooltipContent>
                          </Tooltip>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="icon-btn-premium h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuItem onClick={() => openEdit(q)}>
                                <Pencil className="h-4 w-4" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDuplicate(q)}>
                                <Copy className="h-4 w-4" /> Duplicate
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                variant="destructive"
                                onClick={() => setDeleteTarget(q)}
                              >
                                <Trash2 className="h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}

        {filtered.length > 0 && (
          <div className="flex flex-col items-center justify-between gap-3 border-t border-border/60 px-4 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="font-medium text-foreground tabular-nums">{start + 1}–{end}</span>{' '}
                of{' '}
                <span className="font-medium text-foreground tabular-nums">{filtered.length}</span>
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => { setRowsPerPage(Number(v)); setPage(0) }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[8, 12, 20, 50].map((n) => (
                    <SelectItem key={n} value={String(n)}>{n} / page</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="flex items-center gap-1 px-1">
                {Array.from({ length: Math.min(5, pageCount) }).map((_, idx) => {
                  let pageNum = idx
                  if (pageCount > 5) {
                    if (currentPage < 3) pageNum = idx
                    else if (currentPage > pageCount - 3) pageNum = pageCount - 5 + idx
                    else pageNum = currentPage - 2 + idx
                  }
                  const isActive = pageNum === currentPage
                  if (pageNum < 0 || pageNum >= pageCount) return null
                  return (
                    <button
                      key={pageNum}
                      type="button"
                      onClick={() => setPage(pageNum)}
                      data-active={isActive}
                      className="page-btn-premium inline-flex h-8 min-w-8 items-center justify-center rounded-md px-2 text-xs font-medium tabular-nums"
                    >
                      {pageNum + 1}
                    </button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage >= pageCount - 1}
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Question form dialogs ── */}
      <QuestionFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        chapters={chapters}
        mode="add"
      />
      <QuestionFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        chapters={chapters}
        mode="edit"
      />

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400">
                <Trash2 className="h-4 w-4" />
              </span>
              Delete question?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove question{' '}
              <span className="font-mono text-xs font-medium text-foreground">{deleteTarget?.id}</span>{' '}
              from the bank and from any exams that include it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete question
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk delete */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400">
                <Trash2 className="h-4 w-4" />
              </span>
              Delete {selected.size} questions?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the selected{' '}
              <span className="num-premium font-medium text-foreground">{selected.size}</span>{' '}
              question{selected.size === 1 ? '' : 's'} from the bank and from any exams that include them.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleBulkDelete}
            >
              Delete {selected.size} question{selected.size === 1 ? '' : 's'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Floating add FAB */}
      <button
        type="button"
        onClick={openAdd}
        disabled={chapters.length === 0}
        className="fab-premium fixed bottom-6 right-6 z-30 flex h-14 items-center gap-2 rounded-full px-5 transition-all hover:scale-105 active:scale-95 disabled:opacity-50"
        aria-label="Add question"
      >
        <Plus className="h-5 w-5" />
        <span className="hidden pr-1 text-sm font-semibold sm:inline">New Question</span>
      </button>

      {/* v3.53.6 — Import Questions from Word / PDF / txt */}
      <ImportQuestionsDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        chapters={chapters.map((c) => ({ id: c.id, name: c.name }))}
        preselectedChapterIds={chapterFilter !== 'all' ? [chapterFilter] : []}
        onImport={(qs) => addQuestions(qs)}
      />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Question form dialog (add / edit) — premium
// ────────────────────────────────────────────────────────────────────────────

function QuestionFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  chapters,
  mode,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: QuestionForm
  setForm: React.Dispatch<React.SetStateAction<QuestionForm>>
  onSubmit: (e: React.FormEvent) => void
  chapters: { id: string; name: string }[]
  mode: 'add' | 'edit'
}) {
  const update = (patch: Partial<QuestionForm>) => setForm((p) => ({ ...p, ...patch }))

  const setOption = (i: number, val: string) => {
    setForm((p) => {
      const next = [...p.options]
      next[i] = val
      return { ...p, options: next }
    })
  }

  const chapterNameLocal = (id: string) =>
    chapters.find((c) => c.id === id)?.name ?? '—'

  const toggleChapter = (id: string) => {
    setForm((p) => {
      const has = p.chapterIds.includes(id)
      return {
        ...p,
        chapterIds: has ? p.chapterIds.filter((x) => x !== id) : [...p.chapterIds, id],
      }
    })
  }

  const handleImagePick = (
    file: File | undefined,
    kind: 'image' | 'explanationImage',
  ) => {
    if (!file) return
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      toast.error('Only JPG, PNG, GIF, WebP, or SVG images are allowed')
      return
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast.error('Image is too large (max 800 KB)', {
        description: `Selected file is ${(file.size / 1024).toFixed(0)} KB`,
      })
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : ''
      if (!dataUrl) return
      if (kind === 'image') {
        setForm((p) => ({ ...p, imageData: dataUrl, imageName: file.name }))
      } else {
        setForm((p) => ({ ...p, explanationImage: dataUrl, explanationImageName: file.name }))
      }
      toast.success('Image attached')
    }
    reader.onerror = () => toast.error('Could not read that file')
    reader.readAsDataURL(file)
  }

  const marksStepper = (delta: number) =>
    update({ marks: Math.max(1, Math.min(100, form.marks + delta)) })

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              {mode === 'add' ? <Plus className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
            </span>
            {mode === 'add' ? 'Add new question' : 'Edit question'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'add'
              ? 'Create a new question and link it to one or more chapters.'
              : 'Update the question details below.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-5">
          {/* Type selector — visual cards */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <Type className="h-3.5 w-3.5 text-muted-foreground" /> Question type
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(typeIcons) as Question['type'][]).map((t) => {
                const Icon = typeIcons[t]
                const selected = form.type === t
                const accent =
                  t === 'mcq'
                    ? 'border-sky-500/50 bg-sky-500/5 ring-2 ring-sky-500/20'
                    : t === 'numerical'
                      ? 'border-violet-500/50 bg-violet-500/5 ring-2 ring-violet-500/20'
                      : 'border-teal-500/50 bg-teal-500/5 ring-2 ring-teal-500/20'
                const iconColor =
                  t === 'mcq'
                    ? 'bg-sky-500/10 text-sky-600 dark:text-sky-400'
                    : t === 'numerical'
                      ? 'bg-violet-500/10 text-violet-600 dark:text-violet-400'
                      : 'bg-teal-500/10 text-teal-600 dark:text-teal-400'
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => update({ type: t })}
                    className={`flex flex-col items-start gap-1.5 rounded-lg border p-3 text-left transition-all ${
                      selected ? accent : 'border-border/60 bg-background hover:bg-muted/40'
                    }`}
                  >
                    <div className={`flex h-7 w-7 items-center justify-center rounded-md ${iconColor}`}>
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold">{typeFullLabels[t]}</p>
                      <p className="text-[10px] text-muted-foreground">{typeDescriptions[t]}</p>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Level selector (v3.54.0 — was "Difficulty" with 4 cards, now 12 levels in a dropdown) */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5" htmlFor="q-level">
              <Target className="h-3.5 w-3.5 text-muted-foreground" /> Level
            </Label>
            <Select value={form.difficulty} onValueChange={(v) => update({ difficulty: v as Question['difficulty'] })}>
              <SelectTrigger id="q-level" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {QUESTION_LEVELS.map((lvl) => (
                  <SelectItem key={lvl} value={lvl}>
                    Level {lvl.replace('level-', '')} — {difficultyDescriptions[lvl]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground">
              {difficultyDescriptions[form.difficulty]}
            </p>
          </div>

          {/* Chapter multi-select */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <Sigma className="h-3.5 w-3.5 text-muted-foreground" /> Chapters
              <span className="ml-1 text-[10px] font-normal text-muted-foreground">
                ({form.chapterIds.length} selected)
              </span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  className="input-premium h-9 w-full justify-between"
                  aria-haspopup="listbox"
                >
                  <span className="truncate">
                    {form.chapterIds.length === 0
                      ? 'Pick chapters…'
                      : `${form.chapterIds.length} chapter${form.chapterIds.length === 1 ? '' : 's'} selected`}
                  </span>
                  <ChevronRight className="h-4 w-4 rotate-90 text-muted-foreground" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                <div className="max-h-60 overflow-y-auto p-1" role="listbox" aria-multiselectable="true">
                  {chapters.length === 0 ? (
                    <div className="px-3 py-6 text-center text-xs text-muted-foreground">
                      No chapters yet. Add a chapter first.
                    </div>
                  ) : (
                    chapters.map((c) => {
                      const checked = form.chapterIds.includes(c.id)
                      return (
                        <label
                          key={c.id}
                          role="option"
                          aria-selected={checked}
                          className="flex cursor-pointer items-center gap-2.5 rounded-md px-3 py-2 text-sm hover:bg-muted/50"
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => toggleChapter(c.id)}
                          />
                          <span className="truncate">{c.name}</span>
                        </label>
                      )
                    })
                  )}
                </div>
              </PopoverContent>
            </Popover>
            {form.chapterIds.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {form.chapterIds.map((chId) => (
                  <span key={chId} className="chip-premium border-primary/30 bg-primary/10 text-primary">
                    <span className="truncate max-w-[180px]">{chapterNameLocal(chId)}</span>
                    <button
                      type="button"
                      onClick={() => toggleChapter(chId)}
                      className="ml-0.5 inline-flex h-4 w-4 items-center justify-center rounded-full hover:bg-background/80"
                      aria-label={`Remove ${chapterNameLocal(chId)}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Question text */}
          <div className="space-y-2">
            <Label htmlFor="q-text" className="flex items-center gap-1.5">
              <FileQuestion className="h-3.5 w-3.5 text-muted-foreground" /> Question text
            </Label>
            <Textarea
              id="q-text"
              rows={3}
              value={form.text}
              onChange={(e) => update({ text: e.target.value })}
              placeholder="Enter the question…"
              className="input-premium resize-none"
              required
            />
          </div>

          <ImageUploader
            label="Question image (optional)"
            imageData={form.imageData}
            imageName={form.imageName}
            onPick={(f) => handleImagePick(f, 'image')}
            onClear={() => update({ imageData: undefined, imageName: undefined })}
          />

          {/* Options & correct answer */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <ListChecks className="h-3.5 w-3.5 text-muted-foreground" /> Options & correct answer
            </Label>
            {form.type === 'true-false' ? (
              <RadioGroup
                value={String(form.correctAnswer)}
                onValueChange={(v) => update({ correctAnswer: Number(v) })}
                className="space-y-2"
              >
                {[0, 1].map((i) => {
                  const isCorrect = form.correctAnswer === i
                  return (
                    <label
                      key={i}
                      className={`flex items-center gap-2.5 rounded-lg border px-3 py-2.5 text-sm cursor-pointer transition-all ${
                        isCorrect
                          ? 'border-emerald-500/50 bg-emerald-500/5 ring-2 ring-emerald-500/20'
                          : 'border-border/60 hover:bg-muted/40'
                      }`}
                    >
                      <RadioGroupItem value={String(i)} />
                      <span className="font-medium">{i === 0 ? 'True' : 'False'}</span>
                      {isCorrect && (
                        <span className="ml-auto chip-premium border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                          <Check className="h-3 w-3" /> Correct
                        </span>
                      )}
                    </label>
                  )
                })}
              </RadioGroup>
            ) : (
              <RadioGroup
                value={String(form.correctAnswer)}
                onValueChange={(v) => update({ correctAnswer: Number(v) })}
                className="space-y-2"
              >
                {[0, 1, 2, 3].map((i) => {
                  const isCorrect = form.correctAnswer === i
                  return (
                    <label
                      key={i}
                      className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 transition-all ${
                        isCorrect
                          ? 'border-emerald-500/50 bg-emerald-500/5 ring-2 ring-emerald-500/20'
                          : 'border-border/60 hover:bg-muted/40'
                      }`}
                    >
                      <RadioGroupItem value={String(i)} />
                      <span className="text-[10px] font-semibold text-muted-foreground">
                        {String.fromCharCode(65 + i)}
                      </span>
                      <Input
                        value={form.options[i] ?? ''}
                        onChange={(e) => setOption(i, e.target.value)}
                        placeholder={`Option ${String.fromCharCode(65 + i)}`}
                        className="input-premium h-8 flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
                        required={form.type === 'mcq'}
                      />
                      {isCorrect && (
                        <span className="chip-premium border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                          <Check className="h-3 w-3" /> Correct
                        </span>
                      )}
                    </label>
                  )
                })}
              </RadioGroup>
            )}
            <p className="text-xs text-muted-foreground">
              {form.type === 'true-false'
                ? 'Select the radio to mark the correct answer.'
                : 'Fill in all 4 options and select the radio to mark the correct one.'}
            </p>
          </div>

          {/* Marks stepper */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="q-marks" className="flex items-center gap-1.5">
                <Award className="h-3.5 w-3.5 text-muted-foreground" /> Marks
              </Label>
              <div className="flex items-center gap-1">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="btn-premium-outline h-9 w-9"
                  onClick={() => marksStepper(-1)}
                  disabled={form.marks <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Input
                  id="q-marks"
                  type="number"
                  min={1}
                  value={form.marks}
                  onChange={(e) => update({ marks: Math.max(1, Number(e.target.value) || 1) })}
                  className="input-premium h-9 text-center tabular-nums"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="btn-premium-outline h-9 w-9"
                  onClick={() => marksStepper(1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Explanation */}
          <div className="space-y-2">
            <Label htmlFor="q-expl" className="flex items-center gap-1.5">
              <Lightbulb className="h-3.5 w-3.5 text-muted-foreground" /> Explanation
            </Label>
            <Textarea
              id="q-expl"
              rows={2}
              value={form.explanation}
              onChange={(e) => update({ explanation: e.target.value })}
              placeholder="Brief explanation shown after the exam"
              className="input-premium resize-none"
            />
          </div>

          <ImageUploader
            label="Explanation image (optional)"
            imageData={form.explanationImage}
            imageName={form.explanationImageName}
            onPick={(f) => handleImagePick(f, 'explanationImage')}
            onClear={() => update({ explanationImage: undefined, explanationImageName: undefined })}
          />

          {/* Preview summary */}
          <div className="rounded-lg border border-border/60 bg-muted/20 p-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Live summary
              </span>
              <Sparkles className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className={`badge-status ${typeBadge[form.type]}`}>
                {typeLabels[form.type]}
              </span>
              <span className={`badge-status capitalize ${difficultyBadge[form.difficulty]}`}>
                {form.difficulty.replace('-', ' ')}
              </span>
              <span className="badge-status border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300">
                <Award className="h-3 w-3" />
                <span className="num-premium font-bold">{form.marks}</span> marks
              </span>
              <span className="badge-status border-primary/30 bg-primary/10 text-primary">
                <Sigma className="h-3 w-3" />
                <span className="num-premium font-bold">{form.chapterIds.length}</span> chapter{form.chapterIds.length === 1 ? '' : 's'}
              </span>
              <span className="badge-status border-border bg-background text-muted-foreground">
                {form.type === 'true-false' ? '2' : '4'} options
              </span>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="btn-premium-outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="btn-premium-primary">
              {mode === 'add' ? (
                <>
                  <Plus className="h-4 w-4" /> Add question
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" /> Save changes
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// ───────────────────────────────────────────────────────
//  Image uploader (shared, premium)
// ───────────────────────────────────────────────────────

function ImageUploader({
  label,
  imageData,
  imageName,
  onPick,
  onClear,
}: {
  label: string
  imageData?: string
  imageName?: string
  onPick: (file: File | undefined) => void
  onClear: () => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  return (
    <div className="space-y-2">
      <Label className="flex items-center gap-1.5 text-muted-foreground">
        <ImageIcon className="h-3.5 w-3.5" /> {label}
      </Label>
      {imageData ? (
        <div className="flex items-start gap-3 rounded-lg border border-border/60 bg-muted/20 p-3">
          <img
            src={imageData}
            alt={imageName ?? 'Uploaded image'}
            className="h-20 w-20 max-w-[200px] shrink-0 rounded-md border object-cover"
          />
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-medium">{imageName ?? 'image'}</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              Will render above the options in the exam.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="btn-premium-outline h-7"
                onClick={() => inputRef.current?.click()}
              >
                <ImagePlus className="h-3.5 w-3.5" /> Replace
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 text-rose-600 hover:bg-rose-500/10 hover:text-rose-700 dark:text-rose-400"
                onClick={() => {
                  onClear()
                  if (inputRef.current) inputRef.current.value = ''
                }}
              >
                <X className="h-3.5 w-3.5" /> Remove
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="group flex w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border/60 bg-muted/20 px-4 py-6 text-center transition hover:border-primary/40 hover:bg-primary/[0.03]"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary transition group-hover:scale-110">
            <ImagePlus className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-medium">Click to upload image</p>
            <p className="text-[11px] text-muted-foreground">JPG, PNG, GIF, WebP, SVG · max 800 KB</p>
          </div>
          <ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/gif,image/webp,image/svg+xml"
        className="hidden"
        onChange={(e) => {
          onPick(e.target.files?.[0])
          if (e.target.value) e.target.value = ''
        }}
      />
    </div>
  )
}
