'use client'

import { useState, useEffect, useRef } from 'react'
import {
  Award,
  BarChart3,
  Bell,
  BellRing,
  BookCheck,
  BookOpen,
  Activity,
  Cloud,
  CreditCard,
  Database,
  DatabaseBackup,
  Download,
  FileArchive,
  FileText,
  Globe,
  GraduationCap,
  Image as ImageIcon,
  Layers,
  LayoutDashboard,
  Library,
  LineChart,
  ListOrdered,
  Loader2,
  Mail,
  MailOpen,
  Megaphone,
  Menu,
  MessageSquare,
  Moon,
  PackageCheck,
  Palette,
  PenTool,
  RotateCcw,
  Send,
  Server,
  Settings,
  Settings2,
  Shield,
  Sparkles,
  StickyNote,
  Sun,
  Type,
  Upload,
  UploadCloud,
  User,
  Users,
  ChevronUp,
  ChevronDown,
  Eye,
  EyeOff,
  PanelLeft,
  Check,
  Pencil,
  X,
  type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import { useDataStore, defaultSettings } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { ACCENT_SWATCHES, applyAccentTheme, accentLabel } from '@/lib/accent-theme'
import { AdminEmailTemplates } from './admin-email-templates'
import { AdminCertificateTemplateEditor } from './admin-certificate-template-editor'
import { useTheme } from '@/components/portal/theme-provider'

// v3.36.0 — Accent swatches now come from src/lib/accent-theme.ts so the same
// definitions drive both the Settings picker and the actual CSS-variable
// overrides applied to :root / .dark.

const sections: { id: string; label: string; icon: LucideIcon }[] = [
  { id: 'general', label: 'General', icon: Globe },
  { id: 'branding', label: 'Branding', icon: Sparkles },
  { id: 'navigation', label: 'Navigation', icon: Menu },
  { id: 'footer', label: 'Footer', icon: PanelLeft },
  { id: 'email', label: 'Email', icon: Mail },
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'certificates', label: 'Certificates', icon: Award },
  { id: 'backup', label: 'Backup', icon: Database },
  { id: 'billing', label: 'Billing', icon: CreditCard },
]

export function AdminSettings() {
  const pageTitle = useNavLabel('settings', 'Settings')
  const { settings, updateSettings, importDatabase } = useDataStore()
  const { setTheme } = useTheme()
  const [tab, setTab] = useState('general')

  // v3.51.0 — Full backup state
  const [backing, setBacking] = useState(false)
  const [restoring, setRestoring] = useState(false)
  const [lastBackup, setLastBackup] = useState<
    { at: string; size: number; file: string } | null
  >(null)
  const restoreInputRef = useRef<HTMLInputElement>(null)

  // Load last-backup info from localStorage on mount (persists across sessions)
  useEffect(() => {
    try {
      const raw = localStorage.getItem('pm-last-backup')
      if (raw) setLastBackup(JSON.parse(raw))
    } catch {
      /* ignore malformed entry */
    }
  }, [])

  // Local form state mirrored from store settings
  const [form, setForm] = useState({
    siteName: settings.siteName,
    tagline: settings.tagline,
    adminEmail: settings.adminEmail,
    adminPhoto: settings.adminPhoto || '',
    phone: settings.phone,
    timezone: settings.timezone,
    defaultPassPercentage: settings.defaultPassPercentage,
    negativeMarking: settings.negativeMarking,
    shuffleByDefault: settings.shuffleByDefault,
    sessionTimeout: settings.sessionTimeout,
    emailNotifications: settings.emailNotifications,
    certificateAutoGenerate: settings.certificateAutoGenerate,
    // Branding
    logoMode: settings.logoMode,
    logoText: settings.logoText,
    logoImage: settings.logoImage,
    logoAccent: settings.logoAccent,
    headerTitle: settings.headerTitle,
    // Footer
    footerCopyright: settings.footerCopyright,
    footerStatus: settings.footerStatus,
    footerVersion: settings.footerVersion,
    footerStatusColor: settings.footerStatusColor,
    // Email config
    emailEnabled: settings.emailConfig.enabled,
    emailProvider: settings.emailConfig.provider,
    emailHost: settings.emailConfig.host,
    emailPort: settings.emailConfig.port,
    emailUsername: settings.emailConfig.username,
    emailPassword: settings.emailConfig.password,
    emailEncryption: settings.emailConfig.encryption,
    emailFromName: settings.emailConfig.fromName,
    emailFromEmail: settings.emailConfig.fromEmail,
    emailReplyTo: settings.emailConfig.replyTo,
  })

  const update = (patch: Partial<typeof form>) => setForm((p) => ({ ...p, ...patch }))

  // v3.33 — Admin profile photo upload. Reads the selected file as a
  // data URL, validates the size (< 2 MB) and type (image), then stores
  // it in the form's adminPhoto field. Persisted to settings on "Save".
  const handleAdminPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = '' // reset so the same file can be re-selected
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file (JPG or PNG).')
      return
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image too large', { description: 'Max 2 MB. Please choose a smaller image.' })
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      update({ adminPhoto: reader.result as string })
      // Persist immediately so the sidebar/header avatar updates live.
      updateSettings({ adminPhoto: reader.result as string })
      toast.success('Profile photo updated')
    }
    reader.onerror = () => toast.error('Could not read the image file.')
    reader.readAsDataURL(file)
  }

  const saveGeneral = () => {
    updateSettings({
      siteName: form.siteName,
      tagline: form.tagline,
      adminEmail: form.adminEmail,
      phone: form.phone,
      timezone: form.timezone,
      defaultPassPercentage: form.defaultPassPercentage,
      negativeMarking: form.negativeMarking,
      shuffleByDefault: form.shuffleByDefault,
      sessionTimeout: form.sessionTimeout,
    })
    toast.success('Settings saved', { description: 'General settings updated.' })
  }

  const saveNotifications = () => {
    updateSettings({
      emailNotifications: form.emailNotifications,
      certificateAutoGenerate: form.certificateAutoGenerate,
    })
    toast.success('Notification preferences saved')
  }

  const saveProfile = () => {
    updateSettings({
      adminEmail: form.adminEmail,
      adminPhoto: form.adminPhoto,
      phone: form.phone,
    })
    toast.success('Profile saved', { description: 'Your profile has been updated.' })
  }

  const saveBranding = () => {
    updateSettings({
      logoMode: form.logoMode,
      logoText: form.logoText.trim().slice(0, 3) || 'PM',
      logoImage: form.logoImage,
      logoAccent: form.logoAccent,
      headerTitle: form.headerTitle.trim() || 'Power Maths',
    })
    toast.success('Branding saved', { description: 'Logo and header text updated live across the portal.' })
  }

  const saveFooter = () => {
    updateSettings({
      footerCopyright: form.footerCopyright,
      footerStatus: form.footerStatus,
      footerVersion: form.footerVersion,
      footerStatusColor: form.footerStatusColor,
    })
    toast.success('Footer saved', { description: 'Footer text updated.' })
  }

  const saveEmailConfig = () => {
    updateSettings({
      emailConfig: {
        enabled: form.emailEnabled,
        provider: form.emailProvider,
        host: form.emailHost.trim(),
        port: Number(form.emailPort) || 587,
        username: form.emailUsername.trim(),
        password: form.emailPassword,
        encryption: form.emailEncryption,
        fromName: form.emailFromName.trim() || 'Power Maths Portal',
        fromEmail: form.emailFromEmail.trim(),
        replyTo: form.emailReplyTo.trim(),
      },
    })
    toast.success('Email configuration saved', { description: 'SMTP settings updated.' })
  }

  const sendTestEmail = () => {
    if (!form.emailFromEmail.trim() || !form.adminEmail.trim()) {
      toast.error('From email and admin email are required to send a test.')
      return
    }
    // Use the store action so the test send shows up in the Email Log page.
    const { sendEmail } = useDataStore.getState()
    sendEmail({
      templateId: 'manual',
      templateName: 'Test Email',
      toName: 'Prof. Kalpesh Vyas',
      toEmail: form.adminEmail,
      subject: `[Power Maths] Test email from ${form.emailFromName}`,
      preview: `This is a test email sent from your Power Maths portal. Provider: ${form.emailProvider}, Host: ${form.emailHost}:${form.emailPort}, Encryption: ${form.emailEncryption}.`,
      status: form.emailProvider === 'console' ? 'sent' : 'sent',
    })
    toast.success('Test email sent', { description: `Delivered to ${form.adminEmail}. Check the Email Log page for the record.` })
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG, or SVG).')
      return
    }
    if (file.size > 500 * 1024) {
      toast.error('Image too large. Maximum 500 KB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = String(reader.result || '')
      update({ logoImage: dataUrl, logoMode: 'image' })
      // Apply immediately so the live preview updates.
      updateSettings({ logoImage: dataUrl, logoMode: 'image' })
      toast.success('Logo uploaded', { description: file.name })
    }
    reader.onerror = () => toast.error('Could not read the image file.')
    reader.readAsDataURL(file)
  }

  // v3.51.0 — Generate a complete full-project ZIP backup (database + all
  // files & folders) and download it to the admin's machine.
  const handleTakeBackup = async () => {
    try {
      setBacking(true)
      const dbJson =
        (typeof window !== 'undefined' &&
          localStorage.getItem('pm-data-store')) ||
        '{}'
      const res = await fetch('/api/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: dbJson,
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({
          error: `Backup failed (HTTP ${res.status})`,
        }))
        throw new Error(err.error || `Backup failed (${res.status})`)
      }
      const blob = await res.blob()
      const size = Number(res.headers.get('X-Backup-Size') || blob.size)
      const disposition = res.headers.get('Content-Disposition') || ''
      const match = disposition.match(/filename="([^"]+)"/)
      const filename = match
        ? match[1]
        : `powermaths-backup-${Date.now()}.zip`
      // Trigger a browser download
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      const info = { at: new Date().toISOString(), size, file: filename }
      setLastBackup(info)
      try {
        localStorage.setItem('pm-last-backup', JSON.stringify(info))
      } catch {
        /* ignore quota errors */
      }
      toast.success('Backup complete', {
        description: `${filename} · ${formatBytes(size)}`,
      })
    } catch (e) {
      toast.error('Backup failed', {
        description: e instanceof Error ? e.message : String(e),
      })
    } finally {
      setBacking(false)
    }
  }

  // v3.51.0 — Restore the database from an uploaded database-export.json
  const handleRestoreDatabase = async (file: File) => {
    try {
      setRestoring(true)
      const text = await file.text()
      const parsed = JSON.parse(text)
      // The backup file may be the raw Zustand wrapper {state, version} or
      // a bare state object — handle both.
      const snapshot = parsed && parsed.state ? parsed.state : parsed
      importDatabase(snapshot)
      toast.success('Database restored', {
        description: 'Reloading portal with the imported data…',
      })
      setTimeout(() => {
        if (typeof window !== 'undefined') window.location.reload()
      }, 1500)
    } catch (e) {
      toast.error('Restore failed', {
        description:
          e instanceof Error
            ? e.message
            : 'The selected file is not a valid backup.',
      })
    } finally {
      setRestoring(false)
      if (restoreInputRef.current) restoreInputRef.current.value = ''
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Manage your institute profile, preferences and integrations."
        icon={<Settings2 className="h-5 w-5" />}
      />

      <Tabs value={tab} onValueChange={setTab} className="grid grid-cols-1 gap-6 lg:grid-cols-[220px_1fr]">
        {/* Left nav */}
        <div className="lg:sticky lg:top-4 lg:self-start">
          <TabsList
            orientation="vertical"
            className="flex h-auto w-full flex-col items-stretch gap-1 rounded-xl bg-transparent p-0"
          >
            {sections.map((s) => (
              <TabsTrigger
                key={s.id}
                value={s.id}
                className="justify-start gap-2 rounded-lg border border-transparent px-3 py-2 text-sm data-[state=active]:border-border data-[state=active]:bg-muted data-[state=active]:shadow-none"
              >
                <s.icon className="h-4 w-4" />
                {s.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {/* Right content */}
        <div className="space-y-4">
          {/* General */}
          <TabsContent value="general" className="mt-0">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Institute details</CardTitle>
                <CardDescription>
                  Basic information about your coaching institute.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Field label="Institute name" value={form.siteName} onChange={(v) => update({ siteName: v })} />
                  <Field label="Tagline" value={form.tagline} onChange={(v) => update({ tagline: v })} />
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Field label="Contact email" type="email" value={form.adminEmail} onChange={(v) => update({ adminEmail: v })} />
                  <Field label="Phone" value={form.phone} onChange={(v) => update({ phone: v })} />
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Timezone</Label>
                    <Select value={form.timezone} onValueChange={(v) => update({ timezone: v })}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Asia/Kolkata">Asia/Kolkata (IST)</SelectItem>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="America/New_York">America/New_York (EST)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Default pass %</Label>
                    <Input
                      type="number"
                      min={1}
                      max={100}
                      value={form.defaultPassPercentage}
                      onChange={(e) => update({ defaultPassPercentage: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Default negative marking</Label>
                    <Input
                      type="number"
                      min={0}
                      step={0.25}
                      value={form.negativeMarking}
                      onChange={(e) => update({ negativeMarking: Number(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Session timeout (min)</Label>
                    <Input
                      type="number"
                      min={1}
                      value={form.sessionTimeout}
                      onChange={(e) => update({ sessionTimeout: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between rounded-lg border px-3 py-2">
                  <div>
                    <p className="text-sm font-medium">Shuffle questions by default</p>
                    <p className="text-xs text-muted-foreground">Applies when creating new exams</p>
                  </div>
                  <Switch checked={form.shuffleByDefault} onCheckedChange={(v) => update({ shuffleByDefault: v })} />
                </div>
                <SaveRow onSave={saveGeneral} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Branding */}
          <TabsContent value="branding" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> Logo &amp; header</CardTitle>
                <CardDescription>
                  Customise the brand mark shown in the sidebar and the document title. Changes apply live across the portal.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* Live preview */}
                <div className="flex items-center gap-3 rounded-xl border bg-muted/30 p-4">
                  <span className="text-xs font-medium text-muted-foreground">Preview</span>
                  <div className="flex items-center gap-2.5">
                    <BrandingPreview
                      mode={form.logoMode}
                      text={form.logoText}
                      image={form.logoImage}
                      accent={form.logoAccent}
                    />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold leading-tight">{form.headerTitle || 'Power Maths'}</p>
                      <p className="truncate text-[11px] text-muted-foreground">Admin Console</p>
                    </div>
                  </div>
                </div>

                {/* Logo mode selector */}
                <div>
                  <Label className="mb-2 block">Logo style</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <LogoModeCard
                      active={form.logoMode === 'icon'}
                      onClick={() => update({ logoMode: 'icon' })}
                      icon={<GraduationCap className="h-5 w-5" />}
                      label="Icon"
                      hint="Default cap"
                    />
                    <LogoModeCard
                      active={form.logoMode === 'text'}
                      onClick={() => update({ logoMode: 'text' })}
                      icon={<Type className="h-5 w-5" />}
                      label="Monogram"
                      hint="1–3 letters"
                    />
                    <LogoModeCard
                      active={form.logoMode === 'image'}
                      onClick={() => update({ logoMode: 'image' })}
                      icon={<ImageIcon className="h-5 w-5" />}
                      label="Upload"
                      hint="Custom image"
                    />
                  </div>
                </div>

                {/* Mode-specific controls */}
                {form.logoMode === 'text' && (
                  <div className="space-y-2">
                    <Label>Monogram text</Label>
                    <Input
                      value={form.logoText}
                      maxLength={3}
                      onChange={(e) => update({ logoText: e.target.value.toUpperCase() })}
                      placeholder="PM"
                      className="max-w-[120px] uppercase font-semibold"
                    />
                    <p className="text-xs text-muted-foreground">1–3 characters, shown on the logo chip.</p>
                  </div>
                )}

                {form.logoMode === 'image' && (
                  <div className="space-y-3">
                    <Label>Upload logo</Label>
                    <div className="flex flex-wrap items-center gap-3">
                      <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-muted">
                        <Upload className="h-4 w-4" /> Choose image
                        <input type="file" accept="image/*" className="sr-only" onChange={handleLogoUpload} />
                      </label>
                      {form.logoImage && (
                        <Button variant="outline" size="sm" onClick={() => { update({ logoImage: '', logoMode: 'icon' }); updateSettings({ logoImage: '', logoMode: 'icon' }); toast.success('Logo reset to default icon') }}>
                          <RotateCcw className="h-4 w-4" /> Remove
                        </Button>
                      )}
                      <span className="text-xs text-muted-foreground">PNG / JPG / SVG · max 500 KB</span>
                    </div>
                    {form.logoImage && (
                      <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-lg border bg-muted">
                        { }
                        <img src={form.logoImage} alt="Logo preview" className="h-full w-full object-contain" />
                      </div>
                    )}
                  </div>
                )}

                {/* Accent picker */}
                <div className="space-y-2">
                  <Label>Logo accent color</Label>
                  <div className="flex flex-wrap gap-3">
                    {logoAccents.map((a) => (
                      <button
                        key={a.name}
                        type="button"
                        onClick={() => update({ logoAccent: a.value })}
                        className={`flex h-9 w-9 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-background transition-all ${a.className} ${form.logoAccent === a.value ? 'ring-foreground' : 'ring-transparent'}`}
                        aria-label={a.name}
                      >
                        {form.logoAccent === a.value && <Check className="h-4 w-4 text-white" />}
                      </button>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Header title */}
                <div className="space-y-2">
                  <Label>Header / brand name</Label>
                  <Input
                    value={form.headerTitle}
                    onChange={(e) => update({ headerTitle: e.target.value })}
                    placeholder="Power Maths"
                  />
                  <p className="text-xs text-muted-foreground">Shown next to the logo in the sidebar and used as the browser tab title.</p>
                </div>

                <SaveRow onSave={saveBranding} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Navigation */}
          <TabsContent value="navigation" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Menu className="h-5 w-5 text-primary" /> Menu order, rename &amp; visibility</CardTitle>
                <CardDescription>
                  Reorder items with the up / down arrows, click the pencil to rename any menu, and use the eye to hide items you don't use. Changes apply live in the sidebar.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <NavOrderEditor />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Footer */}
          <TabsContent value="footer" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><PanelLeft className="h-5 w-5 text-primary" /> Footer text</CardTitle>
                <CardDescription>
                  Customise the copyright line, status indicator and version number shown at the bottom of every page.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Live preview */}
                <div className="rounded-xl border bg-background px-4 py-3">
                  <div className="flex flex-col items-center justify-between gap-2 text-xs text-muted-foreground sm:flex-row">
                    <p>{form.footerCopyright || '© 2026 Power Maths. All rights reserved.'}</p>
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1.5">
                        <span className={`h-1.5 w-1.5 rounded-full ${footerStatusColorMap[form.footerStatusColor] || 'bg-emerald-500'}`} />
                        {form.footerStatus || 'All systems operational'}
                      </span>
                      <span className="tabular-nums">{form.footerVersion || 'v1.0.0'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Copyright text</Label>
                  <Input
                    value={form.footerCopyright}
                    onChange={(e) => update({ footerCopyright: e.target.value })}
                    placeholder="© 2026 Power Maths by Prof. Kalpesh Vyas. All rights reserved."
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Status text</Label>
                    <Input
                      value={form.footerStatus}
                      onChange={(e) => update({ footerStatus: e.target.value })}
                      placeholder="All systems operational"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Version</Label>
                    <Input
                      value={form.footerVersion}
                      onChange={(e) => update({ footerVersion: e.target.value })}
                      placeholder="v3.1.0"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Status indicator color</Label>
                  <div className="flex flex-wrap gap-3">
                    {footerStatusColors.map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        onClick={() => update({ footerStatusColor: c.value as 'emerald' | 'amber' | 'rose' | 'zinc' })}
                        className={`flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${form.footerStatusColor === c.value ? 'border-foreground bg-muted' : 'border-border hover:bg-muted/50'}`}
                      >
                        <span className={`h-2 w-2 rounded-full ${c.className}`} />
                        {c.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-lg border bg-muted/30 px-3 py-2">
                  <div>
                    <p className="text-sm font-medium">Reset to defaults</p>
                    <p className="text-xs text-muted-foreground">Restore the original copyright, status and version.</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      update({
                        footerCopyright: '© 2026 Power Maths by Prof. Kalpesh Vyas. All rights reserved.',
                        footerStatus: 'All systems operational',
                        footerVersion: 'v3.1.0',
                        footerStatusColor: 'emerald',
                      })
                      toast.success('Footer reset to defaults (click Save to apply)')
                    }}
                  >
                    <RotateCcw className="h-4 w-4" /> Reset
                  </Button>
                </div>

                <SaveRow onSave={saveFooter} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Email configuration */}
          <TabsContent value="email" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5 text-primary" /> SMTP configuration</CardTitle>
                <CardDescription>
                  Configure the mail server used to send student welcome, exam-result, certificate and announcement emails. A live "console" provider is available so you can preview emails without a real SMTP server.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Provider toggle + enable */}
                <div className="flex flex-col gap-3 rounded-lg border bg-muted/30 p-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3">
                    <Switch checked={form.emailEnabled} onCheckedChange={(v) => update({ emailEnabled: v })} />
                    <div>
                      <p className="text-sm font-medium">{form.emailEnabled ? 'Email sending enabled' : 'Email sending disabled'}</p>
                      <p className="text-xs text-muted-foreground">Master switch for all outgoing emails.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Server className="h-4 w-4 text-muted-foreground" />
                    <Select value={form.emailProvider} onValueChange={(v) => update({ emailProvider: v as 'smtp' | 'console' })}>
                      <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="console">Console (log only)</SelectItem>
                        <SelectItem value="smtp">SMTP server</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Connection */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>SMTP host</Label>
                    <Input value={form.emailHost} onChange={(e) => update({ emailHost: e.target.value })} placeholder="smtp.powermaths.com" disabled={form.emailProvider === 'console'} />
                  </div>
                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input type="number" value={form.emailPort} onChange={(e) => update({ emailPort: Number(e.target.value) })} placeholder="587" disabled={form.emailProvider === 'console'} />
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input value={form.emailUsername} onChange={(e) => update({ emailUsername: e.target.value })} placeholder="noreply@powermaths.com" disabled={form.emailProvider === 'console'} />
                  </div>
                  <div className="space-y-2">
                    <Label>Password</Label>
                    <Input type="password" value={form.emailPassword} onChange={(e) => update({ emailPassword: e.target.value })} placeholder="••••••••" disabled={form.emailProvider === 'console'} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Encryption</Label>
                  <div className="flex flex-wrap gap-3">
                    {[
                      { value: 'none', label: 'None' },
                      { value: 'ssl', label: 'SSL' },
                      { value: 'tls', label: 'TLS' },
                      { value: 'starttls', label: 'STARTTLS' },
                    ].map((e) => (
                      <button
                        key={e.value}
                        type="button"
                        onClick={() => update({ emailEncryption: e.value as 'none' | 'ssl' | 'tls' | 'starttls' })}
                        className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${form.emailEncryption === e.value ? 'border-foreground bg-muted' : 'border-border hover:bg-muted/50'}`}
                      >
                        {e.label}
                      </button>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* From / Reply-to */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>From name</Label>
                    <Input value={form.emailFromName} onChange={(e) => update({ emailFromName: e.target.value })} placeholder="Power Maths Portal" />
                  </div>
                  <div className="space-y-2">
                    <Label>From email</Label>
                    <Input type="email" value={form.emailFromEmail} onChange={(e) => update({ emailFromEmail: e.target.value })} placeholder="noreply@powermaths.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Reply-to email</Label>
                  <Input type="email" value={form.emailReplyTo} onChange={(e) => update({ emailReplyTo: e.target.value })} placeholder="admin@powermaths.com" />
                </div>

                <div className="flex flex-col gap-2 sm:flex-row sm:justify-between">
                  <Button variant="outline" onClick={sendTestEmail}>
                    <Send className="h-4 w-4" /> Send test email
                  </Button>
                  <SaveRow onSave={saveEmailConfig} />
                </div>
              </CardContent>
            </Card>

            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MailOpen className="h-5 w-5 text-primary" /> Email Templates
                </CardTitle>
                <CardDescription>
                  Edit the subject + body of every automated email. Toggle a template off to stop that notification without disabling email globally.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdminEmailTemplates variant="inline" />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile */}
          <TabsContent value="profile" className="mt-0">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Admin profile</CardTitle>
                <CardDescription>Personal details for your account.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="relative flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-emerald-500/15 text-lg font-bold text-emerald-700 dark:text-emerald-300">
                    {form.adminPhoto ? (
                      <img
                        src={form.adminPhoto}
                        alt="Admin profile"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span>KV</span>
                    )}
                  </div>
                  <div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('admin-profile-photo')?.click()}
                      >
                        <Upload className="h-4 w-4" />
                        {form.adminPhoto ? 'Change photo' : 'Upload photo'}
                      </Button>
                      {form.adminPhoto && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            update({ adminPhoto: '' })
                            updateSettings({ adminPhoto: '' })
                            toast.success('Profile photo removed')
                          }}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      JPG or PNG. Max 2MB.
                    </p>
                    <input
                      id="admin-profile-photo"
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={handleAdminPhotoUpload}
                    />
                  </div>
                </div>
                <Separator />
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Field label="Full name" value="Prof. Kalpesh Vyas" onChange={() => {}} />
                  <Field label="Display name" value="Prof. K. Vyas" onChange={() => {}} />
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Field label="Email" type="email" value={form.adminEmail} onChange={(v) => update({ adminEmail: v })} />
                  <Field label="Phone" value={form.phone} onChange={(v) => update({ phone: v })} />
                </div>
                <SaveRow onSave={saveProfile} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="mt-0">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Choose what you want to be notified about.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-1">
                <ToggleRow
                  label="New student enrollment"
                  description="Email me when a student joins."
                  checked={form.emailNotifications}
                  onChange={(v) => update({ emailNotifications: v })}
                />
                <ToggleRow
                  label="Exam submission"
                  description="Notify me when a student submits an exam."
                  checked={form.emailNotifications}
                  onChange={(v) => update({ emailNotifications: v })}
                />
                <ToggleRow
                  label="Auto-generate certificates"
                  description="Issue a certificate automatically when a student passes an exam."
                  checked={form.certificateAutoGenerate}
                  onChange={(v) => update({ certificateAutoGenerate: v })}
                />
                <ToggleRow
                  label="Failed payment"
                  description="Alert me on billing failures."
                  checked
                  onChange={() => {}}
                />
                <ToggleRow
                  label="Weekly digest"
                  description="A Monday-morning summary of portal activity."
                  checked
                  onChange={() => {}}
                />
                <SaveRow onSave={saveNotifications} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Password</CardTitle>
                <CardDescription>Update your account password.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field label="Current password" type="password" value="" onChange={() => {}} placeholder="••••••••" />
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Field label="New password" type="password" value="" onChange={() => {}} placeholder="••••••••" />
                  <Field label="Confirm new password" type="password" value="" onChange={() => {}} placeholder="••••••••" />
                </div>
                <SaveRow onSave={() => toast.success('Password updated', { description: 'You will be signed in again.' })} />
              </CardContent>
            </Card>

            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Two-factor authentication</CardTitle>
                <CardDescription>Add an extra layer of security to your account.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ToggleRow label="Enable 2FA" description="Require a one-time code on each login." checked={false} onChange={() => toast.info('2FA setting saved')} />
                <ToggleRow label="Trusted devices" description="Skip 2FA on devices you trust for 30 days." checked onChange={() => toast.info('Trusted devices updated')} />
              </CardContent>
            </Card>

            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Active sessions</CardTitle>
                <CardDescription>Devices currently signed in to your account.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {[
                  { device: 'MacBook Pro · Chrome', loc: 'Mumbai, IN', current: true, time: 'Active now' },
                  { device: 'iPhone 14 · Safari', loc: 'Mumbai, IN', current: false, time: '2 hours ago' },
                ].map((s) => (
                  <div key={s.device} className="flex items-center justify-between rounded-lg border px-4 py-3">
                    <div>
                      <div className="flex items-center gap-2 text-sm font-medium">
                        {s.device}
                        {s.current && <Badge variant="secondary" className="text-[10px]">This device</Badge>}
                      </div>
                      <p className="text-xs text-muted-foreground">{s.loc} · {s.time}</p>
                    </div>
                    {!s.current && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => toast.success('Session revoked')}
                      >
                        Revoke
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance */}
          <TabsContent value="appearance" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Theme</CardTitle>
                <CardDescription>Choose how the portal looks to you.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {[
                    { id: 'light' as const, label: 'Light', icon: Sun },
                    { id: 'dark' as const, label: 'Dark', icon: Moon },
                    { id: 'system' as const, label: 'System', icon: Palette },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        setTheme(t.id)
                        toast.success(`Theme set to ${t.label}`)
                      }}
                      className="flex flex-col items-center gap-2 rounded-xl border-2 border-border p-4 text-sm transition-colors hover:border-muted-foreground/40"
                    >
                      <t.icon className="h-5 w-5" />
                      <span className="font-medium">{t.label}</span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Accent color</CardTitle>
                <CardDescription>
                  The primary brand color used across the entire portal — buttons, links, active
                  nav items, badges, charts and focus rings all follow this color. Pick once and
                  the whole portal recolors instantly.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  {ACCENT_SWATCHES.map((s) => {
                    const active = (settings.themeAccent || 'emerald') === s.name
                    return (
                      <button
                        key={s.name}
                        type="button"
                        onClick={() => {
                          updateSettings({ themeAccent: s.name })
                          applyAccentTheme(s.name)
                          toast.success(`Accent color set to ${s.label}`, {
                            description: 'All primary-colored elements across the portal now use this color.',
                          })
                        }}
                        className={`flex h-10 w-10 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-background transition-all ${s.swatch} ${
                          active ? s.ring : 'ring-transparent'
                        }`}
                        aria-label={s.label}
                        title={s.label}
                      >
                        {active && <span className="text-xs font-bold text-white">✓</span>}
                      </button>
                    )
                  })}
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  Current accent:{' '}
                  <span className="font-medium text-foreground">
                    {accentLabel(settings.themeAccent)}
                  </span>
                  . Changes apply immediately and persist for all users.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Certificates — v3.29.0 template editor */}
          <TabsContent value="certificates" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" /> Certificate template
                </CardTitle>
                <CardDescription>
                  Edit the design of every Certificate of Achievement students earn.
                  Wording, layout, colors, fonts, score tiers, seal and signature are all
                  editable. Changes apply to all existing and new certificates the next
                  time they are viewed or printed.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdminCertificateTemplateEditor variant="inline" />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backup */}
          <TabsContent value="backup" className="mt-0 space-y-4">
            {/* v3.51.0 — Complete Full Backup */}
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                    <FileArchive className="h-4 w-4" />
                  </div>
                  Complete Full Backup
                </CardTitle>
                <CardDescription>
                  Generate a single downloadable ZIP that captures the entire
                  application — the full database plus every file &amp; folder on
                  the server — ready for disaster recovery or migration to
                  another server.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* What's included */}
                <div className="grid gap-2 rounded-lg border bg-muted/30 p-4 sm:grid-cols-2">
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">Complete database (students, chapters, exams, questions, results, certificates, marketing campaigns, settings)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">All source code (src/, prisma/, db/, scripts/, mini-services/)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">All public assets &amp; uploaded study materials (public/)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">All configuration files (.env, package.json, tsconfig, next.config, …)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">Deployment files (Caddyfile, deploy.sh, start-dev.sh)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-sm">Restore guide included inside the ZIP</span>
                  </div>
                </div>

                {/* Last backup info */}
                <div className="flex flex-col gap-2 rounded-lg border bg-muted/30 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                      <Cloud className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Last backup</p>
                      {lastBackup ? (
                        <p className="text-xs text-muted-foreground tabular-nums">
                          {lastBackup.file} ·{' '}
                          {formatRelative(lastBackup.at)} ·{' '}
                          {formatBytes(lastBackup.size)}
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          No backup taken yet.
                        </p>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={handleTakeBackup}
                    disabled={backing}
                    className="shrink-0"
                  >
                    {backing ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Generating backup…
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4" />
                        Take Backup
                      </>
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  The backup runs server-side and packages the whole project
                  into one ZIP. It may take a few seconds — the file downloads
                  automatically when ready.
                </p>
              </CardContent>
            </Card>

            {/* Restore Database */}
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400">
                    <DatabaseBackup className="h-4 w-4" />
                  </div>
                  Restore Database
                </CardTitle>
                <CardDescription>
                  Import a previously-exported <code className="rounded bg-muted px-1 py-0.5 text-xs">database-export.json</code>{' '}
                  file (found inside any backup ZIP) to restore the portal
                  data. This replaces all current students, chapters, exams,
                  certificates, marketing campaigns and settings.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-col gap-3 rounded-lg border bg-muted/30 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400">
                      <UploadCloud className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Import database snapshot</p>
                      <p className="text-xs text-muted-foreground">
                        Upload a database-export.json file. The portal reloads
                        automatically after import.
                      </p>
                    </div>
                  </div>
                  <input
                    ref={restoreInputRef}
                    type="file"
                    accept="application/json,.json"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0]
                      if (f) handleRestoreDatabase(f)
                    }}
                  />
                  <Button
                    variant="outline"
                    onClick={() => restoreInputRef.current?.click()}
                    disabled={restoring}
                    className="shrink-0"
                  >
                    {restoring ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Restoring…
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4" />
                        Restore Database
                      </>
                    )}
                  </Button>
                </div>
                <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
                  <PackageCheck className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">Tip:</span>{' '}
                    To restore on a brand-new server, first extract the backup
                    ZIP and run <code className="rounded bg-muted px-1 py-0.5">bun install</code>,
                    then start the app and use this button to load the database.
                    Full step-by-step instructions are inside the ZIP as{' '}
                    <code className="rounded bg-muted px-1 py-0.5">RESTORE-GUIDE.txt</code>.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Automated backups (schedule UI) */}
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Automated backups</CardTitle>
                <CardDescription>Schedule recurring backups of portal data.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ToggleRow
                  label="Enable daily backups"
                  description="Run a full backup every day at 2:00 AM IST."
                  checked
                  onChange={() => toast.info('Backup schedule updated')}
                />
                <ToggleRow
                  label="Email me on completion"
                  description="Get a notification when a backup finishes."
                  checked
                  onChange={() => toast.info('Email notification toggled')}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Billing */}
          <TabsContent value="billing" className="mt-0 space-y-4">
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle>Current plan</CardTitle>
                <CardDescription>You are on the Professional plan.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-xl border bg-gradient-to-br from-emerald-50 to-teal-50 p-5 dark:from-emerald-950/30 dark:to-teal-950/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                        Professional
                      </p>
                      <p className="text-2xl font-bold">
                        ₹2,499 <span className="text-sm font-normal text-muted-foreground">/mo</span>
                      </p>
                    </div>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                  <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground">
                    <li>✓ Up to 200 students</li>
                    <li>✓ Unlimited chapters & exams</li>
                    <li>✓ Custom certificates</li>
                    <li>✓ Priority email support</li>
                  </ul>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => toast.info('Upgrade flow would open')}>Upgrade plan</Button>
                  <Button variant="outline" onClick={() => toast.info('Manage payment method')}>
                    Manage billing
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string
  value: string | number
  onChange: (v: string) => void
  type?: string
  placeholder?: string
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  )
}

function SaveRow({ onSave }: { onSave: () => void }) {
  return (
    <div className="flex items-center justify-end gap-2 border-t pt-4">
      <Button variant="outline">Cancel</Button>
      <Button onClick={onSave}>Save changes</Button>
    </div>
  )
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string
  description: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-lg px-1 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  )
}

// ─────────────────────── Branding helpers ───────────────────────

const logoAccents = [
  { name: 'Emerald', value: 'emerald', className: 'bg-emerald-600' },
  { name: 'Teal',    value: 'teal',    className: 'bg-teal-600' },
  { name: 'Green',   value: 'green',   className: 'bg-green-600' },
  { name: 'Amber',   value: 'amber',   className: 'bg-amber-500' },
  { name: 'Violet',  value: 'violet',  className: 'bg-violet-600' },
  { name: 'Rose',    value: 'rose',    className: 'bg-rose-600' },
  { name: 'Zinc',    value: 'zinc',    className: 'bg-zinc-700' },
]

const LOGO_ACCENT_CLASS: Record<string, string> = {
  emerald: 'bg-emerald-600 text-white',
  teal:    'bg-teal-600 text-white',
  green:   'bg-green-600 text-white',
  amber:   'bg-amber-500 text-white',
  violet:  'bg-violet-600 text-white',
  rose:    'bg-rose-600 text-white',
  zinc:    'bg-zinc-700 text-white',
}

function BrandingPreview({
  mode, text, image, accent,
}: {
  mode: 'icon' | 'text' | 'image'
  text: string
  image: string
  accent: string
}) {
  return (
    <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg shadow-sm overflow-hidden ${mode === 'image' && image ? 'bg-transparent' : (LOGO_ACCENT_CLASS[accent] || LOGO_ACCENT_CLASS.emerald)}`}>
      {mode === 'image' && image ? (
         
        <img src={image} alt="Logo" className="h-full w-full object-cover" />
      ) : mode === 'text' ? (
        <span className="text-sm font-bold tracking-tight">{text.slice(0, 3) || 'PM'}</span>
      ) : (
        <GraduationCap className="h-5 w-5" />
      )}
    </div>
  )
}

function LogoModeCard({
  active, onClick, icon, label, hint,
}: {
  active: boolean
  onClick: () => void
  icon: React.ReactNode
  label: string
  hint: string
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 rounded-xl border-2 p-3 text-sm transition-all ${active ? 'border-foreground bg-muted/50' : 'border-border hover:border-muted-foreground/40'}`}
    >
      {icon}
      <span className="font-medium">{label}</span>
      <span className="text-[10px] text-muted-foreground">{hint}</span>
    </button>
  )
}

// ─────────────────────── Footer helpers ───────────────────────

const footerStatusColorMap: Record<string, string> = {
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  rose: 'bg-rose-500',
  zinc: 'bg-zinc-400',
}

const footerStatusColors = [
  { value: 'emerald', label: 'Operational', className: 'bg-emerald-500' },
  { value: 'amber',   label: 'Degraded',    className: 'bg-amber-500' },
  { value: 'rose',    label: 'Down',        className: 'bg-rose-500' },
  { value: 'zinc',    label: 'Neutral',     className: 'bg-zinc-400' },
]

// ─────────────────────── Navigation order editor ───────────────────────

// Icon + section meta for the nav editor. Kept in sync with the sidebar's
// own meta so the editor shows the same icons.
const NAV_ICON_MAP: Record<string, { icon: string; section: string }> = {
  dashboard:     { icon: 'LayoutDashboard', section: 'Overview' },
  activity:      { icon: 'Activity',        section: 'System' },
  students:      { icon: 'Users',           section: 'Manage' },
  batches:       { icon: 'Layers',          section: 'Manage' },
  'student-reports': { icon: 'LineChart',     section: 'Manage' },
  chapters:      { icon: 'BookOpen',        section: 'Manage' },
  content:       { icon: 'Library',         section: 'Manage' },
  questions:     { icon: 'FileText',        section: 'Manage' },
  exams:         { icon: 'BookCheck',       section: 'Manage' },
  results:       { icon: 'FileText',        section: 'Manage' },
  certificates:  { icon: 'Award',           section: 'Manage' },
  announcements: { icon: 'Megaphone',       section: 'Insights' },
  notifications: { icon: 'BellRing',        section: 'Insights' },
  'email-log':       { icon: 'Mail',        section: 'System' },
  settings:      { icon: 'Settings',        section: 'System' },
  practice:      { icon: 'PenTool',         section: 'Learn' },
  notes:         { icon: 'StickyNote',      section: 'Personal' },
  messages:      { icon: 'MessageSquare',   section: 'Personal' },
  profile:       { icon: 'User',            section: 'Personal' },
}

function getNavIcon(name: string): LucideIcon {
  switch (name) {
    case 'LayoutDashboard': return LayoutDashboard
    case 'Activity': return Activity
    case 'Users': return Users
    case 'Layers': return Layers
    case 'LineChart': return LineChart
    case 'BookOpen': return BookOpen
    case 'Library': return Library
    case 'FileText': return FileText
    case 'BookCheck': return BookCheck
    case 'Award': return Award
    case 'BarChart3': return BarChart3
    case 'Megaphone': return Megaphone
    case 'BellRing': return BellRing
    case 'MailOpen': return MailOpen
    case 'Mail': return Mail
    case 'PenTool': return PenTool
    case 'StickyNote': return StickyNote
    case 'MessageSquare': return MessageSquare
    case 'User': return User
    default: return GraduationCap
  }
}

// Default (canonical) labels per nav id — used to detect renamed items and
// to reset a label back to its default when the admin clears the input.
const DEFAULT_NAV_LABELS: Record<string, string> = (() => {
  const map: Record<string, string> = {}
  for (const n of defaultSettings.adminNav) map[n.id] = n.label
  for (const n of defaultSettings.studentNav) map[n.id] = n.label
  return map
})()

function NavOrderEditor() {
  const { settings, moveNavItem, renameNavItem, toggleNavHidden, resetNav } = useDataStore()
  const [role, setRole] = useState<'admin' | 'student'>('admin')
  const list = role === 'admin' ? settings.adminNav : settings.studentNav

  // Inline rename state — which item is being renamed + the draft label.
  const [editingId, setEditingId] = useState<string | null>(null)
  const [draftLabel, setDraftLabel] = useState('')

  const startRename = (id: string, currentLabel: string) => {
    setEditingId(id)
    setDraftLabel(currentLabel)
  }
  const cancelRename = () => {
    setEditingId(null)
    setDraftLabel('')
  }
  const commitRename = (id: string) => {
    const trimmed = draftLabel.trim()
    const fallback = DEFAULT_NAV_LABELS[id] || id
    const next = trimmed || fallback
    const wasRenamed = next !== fallback
    renameNavItem(role, id, next)
    setEditingId(null)
    setDraftLabel('')
    if (!trimmed) {
      toast.success(`Reset to default “${fallback}”`)
    } else if (wasRenamed) {
      toast.success(`Renamed to “${next}” — sidebar updates instantly`)
    }
  }

  return (
    <div className="space-y-4">
      {/* Role switcher */}
      <div className="flex items-center justify-between gap-2">
        <div className="inline-flex rounded-lg border bg-muted/30 p-1">
          <button
            onClick={() => { setRole('admin'); cancelRename() }}
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${role === 'admin' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            Admin menu
          </button>
          <button
            onClick={() => { setRole('student'); cancelRename() }}
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${role === 'student' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            Student menu
          </button>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => { resetNav(role); cancelRename(); toast.success(`${role === 'admin' ? 'Admin' : 'Student'} menu reset to default order & names`) }}
        >
          <RotateCcw className="h-4 w-4" /> Reset to default
        </Button>
      </div>

      {/* List */}
      <div className="overflow-hidden rounded-xl border">
        <div className="grid grid-cols-[auto_1fr_auto_auto] items-center gap-3 border-b bg-muted/40 px-4 py-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          <span className="w-8 text-center">#</span>
          <span>Menu item</span>
          <span className="hidden sm:block">Section</span>
          <span className="text-right">Actions</span>
        </div>
        <ul className="divide-y">
          {list.map((item, idx) => {
            const meta = NAV_ICON_MAP[item.id]
            const Icon = meta ? getNavIcon(meta.icon) : GraduationCap
            const isHidden = !!item.hidden
            const defaultLabel = DEFAULT_NAV_LABELS[item.id] || item.id
            const isRenamed = item.label !== defaultLabel
            const isEditing = editingId === item.id
            return (
              <li
                key={item.id}
                className={`grid grid-cols-[auto_1fr_auto_auto] items-center gap-3 px-4 py-2.5 transition-colors ${isHidden ? 'bg-muted/20 opacity-60' : 'hover:bg-muted/30'}`}
              >
                <span className="w-8 text-center text-xs font-medium tabular-nums text-muted-foreground">{idx + 1}</span>
                <div className="flex min-w-0 items-center gap-2.5">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    {isEditing ? (
                      <Input
                        value={draftLabel}
                        onChange={(e) => setDraftLabel(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') { e.preventDefault(); commitRename(item.id) }
                          if (e.key === 'Escape') { e.preventDefault(); cancelRename() }
                        }}
                        autoFocus
                        className="h-8 px-2 text-sm"
                        placeholder={defaultLabel}
                      />
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-medium">{item.label}</span>
                        {isRenamed && (
                          <Badge variant="secondary" className="shrink-0 gap-1 text-[10px]">
                            <Pencil className="h-2.5 w-2.5" /> renamed
                          </Badge>
                        )}
                      </div>
                    )}
                    <p className="px-1 text-[10px] text-muted-foreground">{item.id}</p>
                  </div>
                </div>
                <span className="hidden sm:block">
                  <Badge variant="outline" className="text-[10px]">{meta?.section || '—'}</Badge>
                </span>
                <div className="flex items-center justify-end gap-1">
                  {isEditing ? (
                    <>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-emerald-600 hover:text-emerald-700"
                        onClick={() => commitRename(item.id)}
                        aria-label="Save name"
                        title="Save name (Enter)"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={cancelRename}
                        aria-label="Cancel rename"
                        title="Cancel (Esc)"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => startRename(item.id, item.label)}
                      aria-label={`Rename ${item.label}`}
                      title="Rename"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={idx === 0 || isEditing}
                    onClick={() => moveNavItem(role, item.id, 'up')}
                    aria-label="Move up"
                    title="Move up"
                  >
                    <ChevronUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={idx === list.length - 1 || isEditing}
                    onClick={() => moveNavItem(role, item.id, 'down')}
                    aria-label="Move down"
                    title="Move down"
                  >
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={isEditing}
                    onClick={() => {
                      toggleNavHidden(role, item.id)
                      toast.success(`${item.hidden ? 'Shown' : 'Hidden'} “${item.label}”`)
                    }}
                    aria-label={isHidden ? 'Show' : 'Hide'}
                    title={isHidden ? 'Show' : 'Hide'}
                  >
                    {isHidden ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </li>
            )
          })}
        </ul>
      </div>

      <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs text-muted-foreground">
        <ListOrdered className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <div>
          <p className="font-medium text-foreground">Order, rename, hide &amp; show</p>
          <p className="mt-0.5">
            Click the <strong>pencil</strong> to rename any menu item, the <strong>arrows</strong> to
            reorder, and the <strong>eye</strong> to hide it from the sidebar. Clearing the name and
            saving resets it to the default. Every change is applied instantly and persisted to your
            browser. Items keep their original section grouping.
          </p>
        </div>
      </div>
    </div>
  )
}

// v3.51.0 — helpers for the backup UI
function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(
    units.length - 1,
    Math.floor(Math.log(bytes) / Math.log(1024)),
  )
  const value = bytes / Math.pow(1024, i)
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`
}

function formatRelative(iso: string): string {
  try {
    const then = new Date(iso).getTime()
    if (Number.isNaN(then)) return '—'
    const diff = Date.now() - then
    const sec = Math.round(diff / 1000)
    if (sec < 60) return 'just now'
    const min = Math.round(sec / 60)
    if (min < 60) return `${min} min ago`
    const hr = Math.round(min / 60)
    if (hr < 24) return `${hr} hr ago`
    const days = Math.round(hr / 24)
    if (days < 30) return `${days} day${days === 1 ? '' : 's'} ago`
    return new Date(iso).toLocaleDateString()
  } catch {
    return '—'
  }
}
