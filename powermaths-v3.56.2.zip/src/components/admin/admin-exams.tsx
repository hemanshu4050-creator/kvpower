'use client'

import { useMemo, useState } from 'react'
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  Clock,
  Eye,
  FileBarChart,
  LayoutGrid,
  List as ListIcon,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { useDataStore, type Exam, QUESTION_LEVELS } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'

// v3.53.2 — exported so the Manage Content >> Exams tab can reuse the
// same create-exam dialog without duplicating the 17-field form.
export interface ExamForm {
  id?: string
  title: string
  chapterId: string
  type: Exam['type']
  marks: number
  duration: number
  passingPercentage: number
  negativeMarking: number
  shuffleQuestions: boolean
  shuffleOptions: boolean
  showResultImmediately: boolean
  instructions: string
  questionIds: string[]
  status: Exam['status']
  // v3.27.0 proctoring
  proctored: boolean
  questionPoolIds: string[]
  questionsToPick: number
  poolSeedByStudent: boolean
  // v3.56.0 — Level (Batch) soft tag for the Exams page Level filter
  batchId: string
}

// v3.53.2 — exported for reuse by the Manage Content >> Exams tab.
export const examTypes: { value: Exam['type']; label: string }[] = [
  { value: 'chapter_test', label: 'Chapter Test' },
  { value: 'worksheet_test', label: 'Worksheet Test' },
  { value: 'cumulative', label: 'Cumulative' },
  { value: 'semi', label: 'Semi-Annual' },
  { value: 'final', label: 'Final' },
]

// v3.53.2 — exported for reuse by the Manage Content >> Exams tab.
export const emptyExamForm = (chapterId: string): ExamForm => ({
  title: '',
  chapterId,
  type: 'chapter_test',
  marks: 20,
  duration: 30,
  passingPercentage: 50,
  negativeMarking: 0,
  shuffleQuestions: true,
  shuffleOptions: false,
  showResultImmediately: true,
  instructions: '',
  questionIds: [],
  status: 'draft',
  proctored: false,
  questionPoolIds: [],
  questionsToPick: 0,
  poolSeedByStudent: true,
  batchId: '',
})

export function AdminExams() {
  const pageTitle = useNavLabel('exams', 'Exams')
  const {
    exams,
    chapters,
    questions,
    results,
    addExam,
    updateExam,
    deleteExam,
    // v3.56.0 — batches for the Level filter + Exam form Level picker
    batches,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  // v3.55.2 — Chapter filter, Type filter, and Grid/List view toggle
  const [chapterFilter, setChapterFilter] = useState('all')
  // v3.56.0 — Level filter
  const [levelFilter, setLevelFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(8)
  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [editing, setEditing] = useState<ExamForm>(emptyExamForm(chapters[0]?.id ?? ''))
  const [deleteTarget, setDeleteTarget] = useState<Exam | null>(null)
  const [viewResultsFor, setViewResultsFor] = useState<Exam | null>(null)

  const filtered = useMemo(() => {
    return exams.filter((e) => {
      const q = search.trim().toLowerCase()
      if (q && !e.title.toLowerCase().includes(q) && !e.id.toLowerCase().includes(q)) return false
      if (statusFilter !== 'all' && e.status !== statusFilter) return false
      // v3.55.2 — Chapter + Type filters
      if (chapterFilter !== 'all' && e.chapterId !== chapterFilter) return false
      if (typeFilter !== 'all' && e.type !== typeFilter) return false
      // v3.56.0 — Level filter (soft tag on exam.batchId)
      if (levelFilter !== 'all' && e.batchId !== levelFilter) return false
      return true
    })
  }, [exams, search, statusFilter, chapterFilter, typeFilter, levelFilter])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const publishedCount = exams.filter((e) => e.status === 'published').length
  const draftCount = exams.filter((e) => e.status === 'draft').length
  const avgAttempts = exams.length ? Math.round(exams.reduce((a, e) => a + e.attempts, 0) / exams.length) : 0

  // Avg score per exam from results
  const examAvgScore = (examId: string) => {
    const rs = results.filter((r) => r.examId === examId)
    return rs.length ? Math.round(rs.reduce((a, r) => a + r.percentage, 0) / rs.length) : 0
  }

  // v3.55.2 — active filters + clear all
  const activeFilters = !!search || statusFilter !== 'all' || chapterFilter !== 'all' || typeFilter !== 'all' || levelFilter !== 'all'
  const clearFilters = () => {
    setSearch('')
    setStatusFilter('all')
    setChapterFilter('all')
    setLevelFilter('all')
    setTypeFilter('all')
    setPage(0)
  }

  // v3.55.2 — helper to get exam type label
  const examTypeLabel = (type: string) => examTypes.find((t) => t.value === type)?.label ?? type

  const openAdd = () => {
    setEditing(emptyExamForm(chapters[0]?.id ?? ''))
    setAddOpen(true)
  }
  const openEdit = (e: Exam) => {
    setEditing({
      id: e.id,
      title: e.title,
      chapterId: e.chapterId,
      type: e.type,
      marks: e.marks,
      duration: e.duration,
      passingPercentage: e.passingPercentage,
      negativeMarking: e.negativeMarking,
      shuffleQuestions: e.shuffleQuestions,
      shuffleOptions: e.shuffleOptions,
      showResultImmediately: e.showResultImmediately,
      instructions: e.instructions,
      questionIds: [...e.questionIds],
      status: e.status,
      proctored: e.proctored ?? false,
      questionPoolIds: [...(e.questionPoolIds ?? [])],
      questionsToPick: e.questionsToPick ?? 0,
      poolSeedByStudent: e.poolSeedByStudent ?? true,
      batchId: e.batchId ?? '',
    })
    setEditOpen(true)
  }

  const buildExamFromForm = (f: ExamForm): Omit<Exam, 'id' | 'attempts' | 'createdAt'> => {
    const chapter = chapters.find((c) => c.id === f.chapterId)
    return {
      title: f.title.trim(),
      chapterId: f.chapterId,
      chapterName: chapter?.name ?? '—',
      type: f.type,
      marks: f.marks,
      duration: f.duration,
      passingPercentage: f.passingPercentage,
      negativeMarking: f.negativeMarking,
      shuffleQuestions: f.shuffleQuestions,
      shuffleOptions: f.shuffleOptions,
      showResultImmediately: f.showResultImmediately,
      instructions: f.instructions.trim(),
      questionIds: f.questionIds,
      status: f.status,
      proctored: f.proctored,
      questionPoolIds: f.questionPoolIds.length > 0 ? f.questionPoolIds : undefined,
      questionsToPick: f.questionPoolIds.length > 0 ? f.questionsToPick : undefined,
      poolSeedByStudent: f.poolSeedByStudent,
      // v3.56.0 — pass batchId as undefined when empty (keeps Exam object clean)
      ...(f.batchId ? { batchId: f.batchId } : {}),
    }
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.title.trim()) {
      toast.error('Title is required')
      return
    }
    addExam(buildExamFromForm(editing))
    toast.success('Exam created', { description: editing.title })
    setAddOpen(false)
  }
  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    updateExam(editing.id, buildExamFromForm(editing))
    toast.success('Exam updated', { description: editing.title })
    setEditOpen(false)
  }
  const handleDelete = () => {
    if (!deleteTarget) return
    deleteExam(deleteTarget.id)
    toast.error('Exam deleted', { description: deleteTarget.title })
    setDeleteTarget(null)
  }
  const togglePublish = (e: Exam) => {
    const next = e.status === 'published' ? 'draft' : 'published'
    updateExam(e.id, { status: next })
    toast.success(next === 'published' ? 'Exam published' : 'Exam unpublished', { description: e.title })
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Build, schedule and publish exams across chapters."
        icon={<ClipboardList className="h-5 w-5" />}
        actions={
          <Button onClick={openAdd} disabled={chapters.length === 0}>
            <Plus className="h-4 w-4" /> Create Exam
          </Button>
        }
      />

      {/* Summary line — replaces the 4 stat cards for a cleaner, more compact look */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-xl border border-border/60 bg-card/50 px-4 py-2.5 text-sm">
        <span className="inline-flex items-center gap-2">
          <ClipboardList className="h-4 w-4 text-emerald-500" />
          <span className="font-semibold tabular-nums">{exams.length}</span>
          <span className="text-muted-foreground">Total Exams</span>
        </span>
        <span className="h-4 w-px bg-border/60" />
        <span className="inline-flex items-center gap-2">
          <Send className="h-4 w-4 text-teal-500" />
          <span className="font-semibold tabular-nums">{publishedCount}</span>
          <span className="text-muted-foreground">Published</span>
        </span>
        <span className="h-4 w-px bg-border/60" />
        <span className="inline-flex items-center gap-2">
          <FileBarChart className="h-4 w-4 text-amber-500" />
          <span className="font-semibold tabular-nums">{draftCount}</span>
          <span className="text-muted-foreground">Drafts</span>
        </span>
      </div>

      {/* Filter bar — v3.55.2: Chapter + Type filters + Grid/List toggle */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0) }}
              placeholder="Search exams by title or ID…"
              className="pl-9"
            />
          </div>
          <Select value={chapterFilter} onValueChange={(v) => { setChapterFilter(v); setPage(0) }}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Chapter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All chapters</SelectItem>
              {chapters.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {/* v3.56.0 — Level filter dropdown */}
          <Select value={levelFilter} onValueChange={(v) => { setLevelFilter(v); setPage(0) }}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All levels</SelectItem>
              {batches.map((b) => (
                <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(0) }}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setPage(0) }}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {examTypes.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {activeFilters && (
            <Button variant="ghost" size="sm" className="h-9" onClick={clearFilters}>
              <X className="h-4 w-4" /> Clear
            </Button>
          )}
          <div className="flex h-9 items-center rounded-lg border bg-background/60 p-0.5">
            <button
              type="button"
              aria-label="Grid view"
              onClick={() => setView('grid')}
              className={`inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition ${
                view === 'grid' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              aria-label="List view"
              onClick={() => setView('list')}
              className={`inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition ${
                view === 'list' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <ListIcon className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </Card>

      {/* v3.55.2 — Grid view (default) */}
      {filtered.length === 0 ? (
        <Card className="card-elevated p-0">
          <EmptyState
            icon={ClipboardList}
            title="No exams found"
            description="Adjust your filters or create a new exam."
            action={
              <Button variant="outline" onClick={clearFilters}>
                Reset filters
              </Button>
            }
          />
        </Card>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {rows.map((e) => (
            <Card key={e.id} className="card-elevated group relative overflow-hidden">
              <CardContent className="p-4">
                {/* Title + status */}
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold leading-tight tracking-tight line-clamp-2">{e.title}</h3>
                    <p className="mt-0.5 text-xs text-muted-foreground tabular-nums">{e.id}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={`shrink-0 ${
                      e.status === 'published'
                        ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                        : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300'
                    }`}
                  >
                    <span className="capitalize">{e.status}</span>
                  </Badge>
                </div>

                {/* Chapter + Type + Level */}
                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  <Badge variant="secondary" className="text-[10px]">{e.chapterName}</Badge>
                  <Badge variant="outline" className="text-[10px] capitalize">{examTypeLabel(e.type)}</Badge>
                  {e.batchId && (
                    <Badge variant="outline" className="text-[10px] border-teal-500/30 bg-teal-500/10 text-teal-700 dark:text-teal-300">
                      {batches.find((b) => b.id === e.batchId)?.name ?? '—'}
                    </Badge>
                  )}
                  {e.proctored && (
                    <Badge variant="outline" className="text-[9px] border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-400">
                      <ShieldCheck className="mr-0.5 h-2.5 w-2.5" /> PROCTORED
                    </Badge>
                  )}
                </div>

                {/* Stats row */}
                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg border border-border/50 bg-background/60 px-2 py-1.5">
                    <div className="text-sm font-bold tabular-nums">{e.marks}</div>
                    <div className="text-[9px] uppercase text-muted-foreground">Marks</div>
                  </div>
                  <div className="rounded-lg border border-border/50 bg-background/60 px-2 py-1.5">
                    <div className="text-sm font-bold tabular-nums">{e.duration}</div>
                    <div className="text-[9px] uppercase text-muted-foreground">Min</div>
                  </div>
                  <div className="rounded-lg border border-border/50 bg-background/60 px-2 py-1.5">
                    <div className="text-sm font-bold tabular-nums">{e.questionIds.length}</div>
                    <div className="text-[9px] uppercase text-muted-foreground">Questions</div>
                  </div>
                </div>

                {/* Actions */}
                <div className="mt-3 flex items-center gap-1">
                  <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setViewResultsFor(e)}>
                    <FileBarChart className="mr-1 h-3 w-3" /> Results
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(e)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => togglePublish(e)}>
                    <Send className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(e)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        /* v3.55.2 — List view (table, no Attempts/Avg score/Created date) */
        <Card className="card-elevated p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40 [&_th]:h-14">
                  <TableHead className="pl-4">Exam</TableHead>
                  <TableHead className="hidden md:table-cell">Chapter</TableHead>
                  <TableHead className="hidden sm:table-cell">Type</TableHead>
                  <TableHead className="hidden lg:table-cell">Level</TableHead>
                  <TableHead className="text-right">Marks</TableHead>
                  <TableHead className="text-right hidden sm:table-cell">
                    <Clock className="inline h-3.5 w-3.5" /> Min
                  </TableHead>
                  <TableHead className="text-right hidden lg:table-cell">Questions</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="pr-4" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((e) => (
                  <TableRow key={e.id} className="[&_td]:py-5">
                    <TableCell className="pl-4 max-w-[280px]">
                      <div className="font-medium leading-tight">{e.title}</div>
                      <div className="mt-0.5 flex items-center gap-1.5">
                        <span className="text-xs text-muted-foreground tabular-nums">{e.id}</span>
                        {e.proctored && (
                          <Badge variant="outline" className="border-rose-500/30 bg-rose-500/10 text-[9px] text-rose-700 dark:text-rose-400">
                            <ShieldCheck className="mr-0.5 h-2.5 w-2.5" /> PROCTORED
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <Badge variant="secondary">{e.chapterName}</Badge>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant="outline" className="text-[10px] capitalize">{examTypeLabel(e.type)}</Badge>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      {e.batchId ? (
                        <Badge variant="outline" className="text-[10px] border-teal-500/30 bg-teal-500/10 text-teal-700 dark:text-teal-300">
                          {batches.find((b) => b.id === e.batchId)?.name ?? '—'}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{e.marks}</TableCell>
                    <TableCell className="hidden sm:table-cell text-right tabular-nums">{e.duration}</TableCell>
                    <TableCell className="hidden lg:table-cell text-right tabular-nums">{e.questionIds.length}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          e.status === 'published'
                            ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                            : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300'
                        }
                      >
                        <span className="capitalize">{e.status}</span>
                      </Badge>
                    </TableCell>
                    <TableCell className="pr-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem onClick={() => setViewResultsFor(e)}>
                            <FileBarChart className="h-4 w-4" /> View Results
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEdit(e)}>
                            <Pencil className="h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => togglePublish(e)}>
                            <Send className="h-4 w-4" />
                            {e.status === 'published' ? 'Unpublish' : 'Publish'}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            variant="destructive"
                            onClick={() => setDeleteTarget(e)}
                          >
                            <Trash2 className="h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Pagination */}
      {filtered.length > 0 && (
        <Card className="card-elevated p-0">
          <div className="flex flex-col items-center justify-between gap-3 border-t px-4 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="font-medium text-foreground tabular-nums">
                  {start + 1}–{end}
                </span>{' '}
                of{' '}
                <span className="font-medium text-foreground tabular-nums">
                  {filtered.length}
                </span>
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => { setRowsPerPage(Number(v)); setPage(0) }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[8, 12, 20, 50].map((n) => (
                    <SelectItem key={n} value={String(n)}>{n} / page</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="px-2 text-xs text-muted-foreground tabular-nums">
                Page {currentPage + 1} of {pageCount}
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage >= pageCount - 1}
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Create/Edit exam dialog */}
      <ExamFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        chapters={chapters}
        questions={questions}
        mode="add"
        batches={batches.map((b) => ({ id: b.id, name: b.name }))}
      />
      <ExamFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        chapters={chapters}
        questions={questions}
        mode="edit"
        batches={batches.map((b) => ({ id: b.id, name: b.name }))}
      />

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete exam?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove <strong>{deleteTarget?.title}</strong>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Results dialog */}
      <Dialog open={!!viewResultsFor} onOpenChange={(o) => !o && setViewResultsFor(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Results — {viewResultsFor?.title}</DialogTitle>
            <DialogDescription>
              All attempts recorded for this exam.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh] pr-2">
            {viewResultsFor && results.filter((r) => r.examId === viewResultsFor.id).length === 0 ? (
              <p className="rounded-lg border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
                No attempts yet.
              </p>
            ) : (
              <ul className="space-y-2 pr-2">
                {viewResultsFor && results.filter((r) => r.examId === viewResultsFor.id).map((r) => (
                  <li key={r.id} className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{r.studentName}</div>
                      <div className="text-xs text-muted-foreground tabular-nums">
                        Attempt #{r.attemptNumber} · {r.createdAt} · {r.timeTakenMinutes}m
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="tabular-nums font-semibold">{r.percentage}%</span>
                      <Badge variant="outline" className={r.status === 'passed' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'}>
                        <span className="capitalize">{r.status}</span>
                      </Badge>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewResultsFor(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// v3.53.2 — exported so the Manage Content >> Exams tab can open the
// exact same create-exam dialog with the chapter pre-selected.
export function ExamFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  chapters,
  questions,
  mode,
  batches,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: ExamForm
  setForm: React.Dispatch<React.SetStateAction<ExamForm>>
  onSubmit: (e: React.FormEvent) => void
  chapters: { id: string; name: string }[]
  questions: { id: string; chapterId: string; text: string; type: string; marks: number; difficulty: string }[]
  mode: 'add' | 'edit'
  // v3.56.0 — batches for the Level picker dropdown
  batches: { id: string; name: string }[]
}) {
  const update = (patch: Partial<ExamForm>) => setForm((p) => ({ ...p, ...patch }))

  const chapterQuestions = questions.filter((q) => q.chapterId === form.chapterId)

  // v3.53.3 — Question picker filters. The admin can now search by text,
  // filter by difficulty, type and marks. "Select all" selects all
  // FILTERED questions, not all chapter questions, so the filters are
  // actually useful for large question banks.
  const [qSearch, setQSearch] = useState('')
  const [qDifficulty, setQDifficulty] = useState('all')
  const [qType, setQType] = useState('all')
  const [qMarks, setQMarks] = useState('all')

  // Unique marks values for the marks filter dropdown (sorted ascending).
  const availableMarks = useMemo(() => {
    const set = new Set(chapterQuestions.map((q) => q.marks))
    return Array.from(set).sort((a, b) => a - b)
  }, [chapterQuestions])

  const filteredQuestions = useMemo(() => {
    const q = qSearch.trim().toLowerCase()
    return chapterQuestions.filter((question) => {
      if (q && !question.text.toLowerCase().includes(q)) return false
      if (qDifficulty !== 'all' && question.difficulty !== qDifficulty) return false
      if (qType !== 'all' && question.type !== qType) return false
      if (qMarks !== 'all' && String(question.marks) !== qMarks) return false
      return true
    })
  }, [chapterQuestions, qSearch, qDifficulty, qType, qMarks])

  const resetFilters = () => {
    setQSearch('')
    setQDifficulty('all')
    setQType('all')
    setQMarks('all')
  }

  const hasActiveFilters = qSearch !== '' || qDifficulty !== 'all' || qType !== 'all' || qMarks !== 'all'

  const toggleQuestion = (qid: string) => {
    setForm((p) => {
      const has = p.questionIds.includes(qid)
      return {
        ...p,
        questionIds: has ? p.questionIds.filter((x) => x !== qid) : [...p.questionIds, qid],
      }
    })
  }

  const totalMarks = form.questionIds.reduce((acc, qid) => {
    const q = questions.find((x) => x.id === qid)
    return acc + (q?.marks ?? 0)
  }, 0)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Create exam' : 'Edit exam'}</DialogTitle>
          <DialogDescription>
            Define the exam parameters and pick which questions to include.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="e-title">Title</Label>
            <Input id="e-title" value={form.title} onChange={(e) => update({ title: e.target.value })} placeholder="e.g. Algebra — Final Test" required />
          </div>
          {/* v3.56.0 — extended to 3 cols: Chapter + Type + Level */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="e-chapter">Chapter</Label>
              <Select value={form.chapterId} onValueChange={(v) => update({ chapterId: v, questionIds: [] })}>
                <SelectTrigger id="e-chapter" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {chapters.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-type">Type</Label>
              <Select value={form.type} onValueChange={(v) => update({ type: v as Exam['type'] })}>
                <SelectTrigger id="e-type" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {examTypes.map((t) => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {/* v3.56.0 — Level picker (soft tag for Exams page Level filter) */}
            <div className="space-y-2">
              <Label htmlFor="e-level">Level</Label>
              <Select value={form.batchId || 'none'} onValueChange={(v) => update({ batchId: v === 'none' ? '' : v })}>
                <SelectTrigger id="e-level" className="w-full">
                  <SelectValue placeholder="No level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— No level —</SelectItem>
                  {batches.map((b) => (
                    <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="e-marks">Total marks</Label>
              <Input id="e-marks" type="number" min={1} value={form.marks} onChange={(e) => update({ marks: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-duration">Duration (min)</Label>
              <Input id="e-duration" type="number" min={1} value={form.duration} onChange={(e) => update({ duration: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-pass">Passing %</Label>
              <Input id="e-pass" type="number" min={1} max={100} value={form.passingPercentage} onChange={(e) => update({ passingPercentage: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-neg">Negative</Label>
              <Input id="e-neg" type="number" min={0} step={0.25} value={form.negativeMarking} onChange={(e) => update({ negativeMarking: Number(e.target.value) })} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="e-instructions">Instructions</Label>
            <Textarea id="e-instructions" rows={3} value={form.instructions} onChange={(e) => update({ instructions: e.target.value })} placeholder="Exam-day instructions shown to students" />
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <SwitchRow label="Shuffle questions" checked={form.shuffleQuestions} onChange={(v) => update({ shuffleQuestions: v })} />
            <SwitchRow label="Shuffle options" checked={form.shuffleOptions} onChange={(v) => update({ shuffleOptions: v })} />
            <SwitchRow label="Show result immediately" checked={form.showResultImmediately} onChange={(v) => update({ showResultImmediately: v })} />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>
                Questions ({form.questionIds.length} selected · {totalMarks} marks)
                {hasActiveFilters && (
                  <span className="ml-1.5 text-xs font-normal text-muted-foreground">
                    · {filteredQuestions.length} of {chapterQuestions.length} shown
                  </span>
                )}
              </Label>
              {chapterQuestions.length > 0 && (
                <Button type="button" variant="ghost" size="sm" onClick={() => update({ questionIds: form.questionIds.length === chapterQuestions.length ? [] : chapterQuestions.map((q) => q.id) })}>
                  {form.questionIds.length === chapterQuestions.length ? 'Clear all' : 'Select all'}
                </Button>
              )}
            </div>

            {/* v3.53.3 — Filter bar: search + difficulty + type + marks */}
            {chapterQuestions.length > 0 && (
              <div className="rounded-lg border bg-muted/20 p-2.5 space-y-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search questions by text..."
                    value={qSearch}
                    onChange={(e) => setQSearch(e.target.value)}
                    className="h-8 pl-8 text-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                  <Select value={qDifficulty} onValueChange={setQDifficulty}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All levels</SelectItem>
                      {QUESTION_LEVELS.map((lvl) => (
                        <SelectItem key={lvl} value={lvl}>Level {lvl.replace('level-', '')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={qType} onValueChange={setQType}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All types</SelectItem>
                      <SelectItem value="mcq">MCQ</SelectItem>
                      <SelectItem value="numerical">Numerical</SelectItem>
                      <SelectItem value="true-false">True / False</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={qMarks} onValueChange={setQMarks}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All marks</SelectItem>
                      {availableMarks.map((m) => (
                        <SelectItem key={m} value={String(m)}>{m} marks</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {hasActiveFilters ? (
                    <Button type="button" variant="ghost" size="sm" className="h-8 text-xs" onClick={resetFilters}>
                      <X className="mr-1 h-3 w-3" /> Clear filters
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 text-xs"
                      disabled={filteredQuestions.length === 0}
                      onClick={() => update({ questionIds: filteredQuestions.every((q) => form.questionIds.includes(q.id)) ? form.questionIds.filter((id) => !filteredQuestions.some((q) => q.id === id)) : Array.from(new Set([...form.questionIds, ...filteredQuestions.map((q) => q.id)])) })}
                    >
                      {filteredQuestions.length > 0 && filteredQuestions.every((q) => form.questionIds.includes(q.id)) ? 'Unselect filtered' : 'Select filtered'}
                    </Button>
                  )}
                </div>
              </div>
            )}

            <div className="rounded-lg border max-h-56 overflow-y-auto">
              {chapterQuestions.length === 0 ? (
                <p className="px-4 py-6 text-center text-xs text-muted-foreground">No questions in this chapter yet.</p>
              ) : filteredQuestions.length === 0 ? (
                <p className="px-4 py-6 text-center text-xs text-muted-foreground">No questions match your filters.</p>
              ) : (
                <ul className="divide-y">
                  {filteredQuestions.map((q) => (
                    <li key={q.id} className="flex items-center gap-2 px-3 py-2 hover:bg-muted/40">
                      <Checkbox
                        checked={form.questionIds.includes(q.id)}
                        onCheckedChange={() => toggleQuestion(q.id)}
                      />
                      <span className="flex-1 line-clamp-1 text-sm">{q.text}</span>
                      <Badge variant="outline" className="text-[10px] capitalize">{q.type}</Badge>
                      <Badge variant="outline" className="text-[10px] capitalize hidden sm:inline-flex">{q.difficulty.replace('-', ' ')}</Badge>
                      <span className="text-xs tabular-nums text-muted-foreground">{q.marks}m</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* ── v3.27.0 Proctoring (Theme 6 — Exam Integrity) ── */}
          <div className="rounded-lg border border-rose-500/20 bg-rose-500/5 p-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-rose-600 dark:text-rose-400" />
              <p className="text-sm font-semibold text-rose-700 dark:text-rose-400">Proctoring &amp; Anti-Cheating (Power Maths Pro)</p>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Lockdown mode, tab-switch detection, question randomization and question pools. Each student sees a different exam.</p>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <SwitchRow label="Proctored (lockdown)" checked={form.proctored} onChange={(v) => update({ proctored: v })} />
              <SwitchRow label="Use question pool" checked={form.questionPoolIds.length > 0} onChange={(v) => update({ questionPoolIds: v ? [...form.questionIds] : [], questionsToPick: v ? Math.min(5, form.questionIds.length) : 0 })} />
              <SwitchRow label="Same questions on retake" checked={form.poolSeedByStudent} onChange={(v) => update({ poolSeedByStudent: v })} />
            </div>

            {form.questionPoolIds.length > 0 && (
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="e-pick">Questions to pick (per student)</Label>
                  <Input id="e-pick" type="number" min={1} max={form.questionPoolIds.length} value={form.questionsToPick} onChange={(e) => update({ questionsToPick: Math.min(Number(e.target.value), form.questionPoolIds.length) })} />
                </div>
                <div className="flex items-end">
                  <p className="text-xs text-muted-foreground">Pool size: <strong>{form.questionPoolIds.length}</strong> questions · Each student gets <strong>{form.questionsToPick}</strong> random ones (seeded by student ID).</p>
                </div>
              </div>
            )}
            {form.proctored && (
              <p className="mt-3 text-xs text-rose-700/80 dark:text-rose-300/80">
                Lockdown enabled: fullscreen, copy/right-click/drag blocked, 3 tab-switches = auto-submit, device fingerprint checked.
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="e-status">Status</Label>
              <Select value={form.status} onValueChange={(v) => update({ status: v as Exam['status'] })}>
                <SelectTrigger id="e-status" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="published">Published</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit">{mode === 'add' ? 'Create exam' : 'Save changes'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function SwitchRow({
  label,
  checked,
  onChange,
}: {
  label: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <label className="flex items-center justify-between gap-2 rounded-lg border px-3 py-2 cursor-pointer hover:bg-muted/40">
      <span className="text-sm">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  )
}
