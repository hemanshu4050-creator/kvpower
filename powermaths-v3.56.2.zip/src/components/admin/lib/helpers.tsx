'use client'

import {
  Hash,
  Sigma,
  Triangle,
  Compass,
  Box,
  BarChart3,
  BookOpen,
  Layers,
  Brain,
  Lightbulb,
  Sparkles,
  type LucideIcon,
} from 'lucide-react'

/** Maps the chapter.icon string from mock-data to a Lucide icon component. */
export const chapterIconMap: Record<string, LucideIcon> = {
  Hash,
  Sigma,
  Triangle,
  Compass,
  Box,
  BarChart3,
  BookOpen,
  Layers,
  Brain,
  Lightbulb,
  Sparkles,
}

export function getChapterIcon(name: string): LucideIcon {
  return chapterIconMap[name] ?? Hash
}

const avatarBgMap: Record<string, string> = {
  emerald: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300',
  rose: 'bg-rose-500/15 text-rose-700 dark:text-rose-300',
  amber: 'bg-amber-500/15 text-amber-700 dark:text-amber-300',
  violet: 'bg-violet-500/15 text-violet-700 dark:text-violet-300',
  sky: 'bg-sky-500/15 text-sky-700 dark:text-sky-300',
  teal: 'bg-teal-500/15 text-teal-700 dark:text-teal-300',
  orange: 'bg-orange-500/15 text-orange-700 dark:text-orange-300',
  fuchsia: 'bg-fuchsia-500/15 text-fuchsia-700 dark:text-fuchsia-300',
  cyan: 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-300',
  lime: 'bg-lime-500/15 text-lime-700 dark:text-lime-300',
  indigo: 'bg-indigo-500/15 text-indigo-700 dark:text-indigo-300',
  pink: 'bg-pink-500/15 text-pink-700 dark:text-pink-300',
}

export function avatarColorClasses(color: string | undefined): string {
  if (!color) return avatarBgMap.emerald
  return avatarBgMap[color] ?? avatarBgMap.emerald
}

/** Returns initials from a name like "Aarav Sharma" → "AS". */
export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('')
}

const dotColorMap: Record<string, string> = {
  emerald: 'bg-emerald-500',
  rose: 'bg-rose-500',
  amber: 'bg-amber-500',
  violet: 'bg-violet-500',
  sky: 'bg-sky-500',
  teal: 'bg-teal-500',
  orange: 'bg-orange-500',
  fuchsia: 'bg-fuchsia-500',
  cyan: 'bg-cyan-500',
  lime: 'bg-lime-500',
  indigo: 'bg-indigo-500',
  pink: 'bg-pink-500',
}

export function dotColor(color: string | undefined): string {
  if (!color) return dotColorMap.emerald
  return dotColorMap[color] ?? dotColorMap.emerald
}
