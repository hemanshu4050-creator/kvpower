'use client'

import { Fragment, useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Award,
  BookCheck,
  BookOpen,
  Brain,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Crown,
  Download,
  Eye,
  Flame,
  GraduationCap,
  Layers,
  LineChart,
  Mail,
  MapPin,
  Medal,
  MoreHorizontal,
  Pencil,
  Phone,
  FileDown,
  RefreshCw,
  Search,
  ShieldBan,
  ShieldCheck,
  Sparkles,
  Star,
  TrendingUp,
  Trash2,
  Upload,
  UserCheck,
  UserPlus,
  UserX,
  Users,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useDataStore, type Student } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { avatarColorClasses, dotColor, initials } from './lib/helpers'
import { downloadStudentProgressPdf } from '@/lib/student-pdf'

// ────────────────────────────────────────────────────────────────────────────
//  Types & helpers
// ────────────────────────────────────────────────────────────────────────────

const avatarColors = [
  'emerald', 'rose', 'amber', 'violet', 'sky', 'teal',
  'orange', 'fuchsia', 'cyan', 'lime', 'indigo', 'pink',
]

type ChapterStatus = 'completed' | 'progress' | 'assigned' | 'locked'

interface StudentStat {
  avgScore: number
  examsCompleted: number
  certificates: number
  progress: number
  study: number
  practice: number
  tests: number
  certs: number
  health: number
  trend: number[]
}

interface StudentFormState {
  id?: string
  name: string
  email: string
  phone: string
  address: string
  batch: string
  status: Student['status']
  validityEnd: string
  photo: string
  assignedChapters: string[]
  notes: string
  /** Admin-only: when non-empty, the student's password is reset to this
   * value when the form is saved (no reset-link email is sent). Only used
   * in edit mode — ignored in add mode. */
  newPassword: string
}

const emptyForm: StudentFormState = {
  name: '',
  email: '',
  phone: '',
  address: '',
  batch: 'Batch 2026-A',
  status: 'active',
  validityEnd: '',
  photo: '',
  assignedChapters: [],
  notes: '',
  newPassword: '',
}

/** Compute chapter completion status for a student. */
function chapterStatusFor(
  student: Student,
  chapterId: string,
  results: { studentId: string; chapterName: string; status: string }[],
  chapterName: string
): ChapterStatus {
  const r = results.filter(
    (x) => x.studentId === student.id && x.chapterName === chapterName
  )
  if (r.some((x) => x.status === 'passed')) return 'completed'
  if (r.length > 0) return 'progress'
  return 'assigned'
}

const chapterStatusStyles: Record<ChapterStatus, { dot: string; chip: string; label: string }> = {
  completed: {
    dot: 'bg-emerald-500',
    chip: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    label: 'Completed',
  },
  progress: {
    dot: 'bg-amber-500',
    chip: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    label: 'In progress',
  },
  assigned: {
    dot: 'bg-rose-500',
    chip: 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
    label: 'Not started',
  },
  locked: {
    dot: 'bg-zinc-400',
    chip: 'border-zinc-400/30 bg-zinc-400/10 text-zinc-600 dark:text-zinc-300',
    label: 'Locked',
  },
}

const statusBadge: Record<Student['status'], string> = {
  active:
    'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  inactive:
    'border-zinc-500/30 bg-zinc-500/10 text-zinc-700 dark:text-zinc-300',
  suspended:
    'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300',
}

/** Tier derived from average score. */
function tierFor(score: number): {
  label: string
  stars: number
  icon: typeof Crown
  className: string
} {
  if (score >= 85)
    return { label: 'Gold', stars: 5, icon: Crown, className: 'text-amber-600 dark:text-amber-400' }
  if (score >= 70)
    return { label: 'Silver', stars: 4, icon: Medal, className: 'text-zinc-500 dark:text-zinc-300' }
  if (score >= 50)
    return { label: 'Bronze', stars: 3, icon: Award, className: 'text-orange-600 dark:text-orange-400' }
  return { label: 'Newcomer', stars: 2, icon: Sparkles, className: 'text-emerald-600 dark:text-emerald-400' }
}

/** Relative time formatter ("2 hours ago"). */
function timeAgo(iso: string | null): { rel: string; abs: string } {
  if (!iso) return { rel: 'Never', abs: '—' }
  const d = new Date(iso.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return { rel: iso, abs: iso }
  const diff = Date.now() - d.getTime()
  const abs = d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
  if (diff < 0) return { rel: 'Just now', abs }
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return { rel: 'Just now', abs }
  if (mins < 60) return { rel: `${mins} min ago`, abs }
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return { rel: `${hrs} hour${hrs === 1 ? '' : 's'} ago`, abs }
  const days = Math.floor(hrs / 24)
  if (days < 7) return { rel: `${days} day${days === 1 ? '' : 's'} ago`, abs }
  const weeks = Math.floor(days / 7)
  if (weeks < 5) return { rel: `${weeks} week${weeks === 1 ? '' : 's'} ago`, abs }
  const months = Math.floor(days / 30)
  return { rel: `${months} month${months === 1 ? '' : 's'} ago`, abs }
}

/** Tiny SVG sparkline. */
function Sparkline({ data, positive = true }: { data: number[]; positive?: boolean }) {
  const pts = data.length >= 2 ? data : [40, positive ? 70 : 50]
  const w = 44
  const h = 18
  const max = Math.max(...pts, 1)
  const min = Math.min(...pts, 0)
  const range = max - min || 1
  const step = w / (pts.length - 1)
  const coords = pts.map((p, i) => `${(i * step).toFixed(1)},${(h - ((p - min) / range) * h).toFixed(1)}`)
  const color = positive ? '#10b981' : '#f43f5e'
  return (
    <svg width={w} height={h} className="shrink-0" aria-hidden>
      <polyline
        points={coords.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx={w} cy={h - ((pts[pts.length - 1] - min) / range) * h} r={1.8} fill={color} />
    </svg>
  )
}

/** Circular health-score ring. */
function HealthRing({ value, size = 34 }: { value: number; size?: number }) {
  const stroke = 3
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const offset = c - (Math.min(100, Math.max(0, value)) / 100) * c
  const color =
    value >= 80 ? '#10b981' : value >= 60 ? '#f59e0b' : value >= 40 ? '#fb923c' : '#f43f5e'
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke} className="text-muted/40" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <span className="absolute text-[10px] font-bold tabular-nums" style={{ color }}>
        {value}
      </span>
    </div>
  )
}

/** Animated count-up number. */
function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const from = display
    const dur = 600
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (value - from) * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value])
  return <span className="tabular-nums">{display}</span>
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function AdminStudents() {
  const pageTitle = useNavLabel('students', 'Students')
  const {
    students,
    chapters,
    results,
    certificates,
    batches: batchRecords,
    exams,
    addStudent,
    updateStudent,
    deleteStudent,
    assignChapters,
  } = useDataStore()

  const [search, setSearch] = useState('')
  const [batchFilter, setBatchFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [chapterFilter, setChapterFilter] = useState<string>('all')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(8)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [showAdvanced, setShowAdvanced] = useState(false)

  const [addOpen, setAddOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [importOpen, setImportOpen] = useState(false)
  const [editing, setEditing] = useState<StudentFormState>(emptyForm)
  const [viewing, setViewing] = useState<Student | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null)
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false)
  const [bulkAssignOpen, setBulkAssignOpen] = useState(false)
  const [bulkAssignChapter, setBulkAssignChapter] = useState<string>('')
  const [csvText, setCsvText] = useState('')
  const [lastSync, setLastSync] = useState(() => new Date())

  // ── Derived stats per student ──
  const studentStats = useMemo(() => {
    const map: Record<string, StudentStat> = {}
    for (const s of students) {
      const sResults = results.filter((r) => r.studentId === s.id)
      const avg = sResults.length
        ? Math.round(sResults.reduce((a, r) => a + r.percentage, 0) / sResults.length)
        : 0
      const certs = certificates.filter((c) => c.studentId === s.id && c.status === 'issued').length
      const assigned = s.assignedChapters.length
      const completedChapters = s.assignedChapters.filter((chId) => {
        const ch = chapters.find((c) => c.id === chId)
        if (!ch) return false
        return sResults.some((r) => r.chapterName === ch.name && r.status === 'passed')
      }).length
      const attemptedChapters = s.assignedChapters.filter((chId) => {
        const ch = chapters.find((c) => c.id === chId)
        if (!ch) return false
        return sResults.some((r) => r.chapterName === ch.name)
      }).length
      const progress = assigned ? Math.round((completedChapters / assigned) * 100) : 0
      const study = assigned ? Math.round((attemptedChapters / assigned) * 100) : 0
      const practice = Math.min(100, sResults.length * 12)
      const tests = assigned ? Math.round((completedChapters / assigned) * 100) : 0
      const certsPct = assigned ? Math.round((certs / assigned) * 100) : 0
      // Health = weighted blend
      const recencyBoost = s.lastLogin ? 8 : 0
      const health = Math.min(
        100,
        Math.round(progress * 0.35 + avg * 0.3 + tests * 0.15 + certsPct * 0.12) + recencyBoost
      )
      const trend = sResults.slice(-6).map((r) => r.percentage)
      map[s.id] = {
        avgScore: avg,
        examsCompleted: sResults.length,
        certificates: certs,
        progress,
        study,
        practice,
        tests,
        certs: certsPct,
        health,
        trend,
      }
    }
    return map
  }, [students, results, certificates, chapters])

  // Unique batch names for the filter dropdown. Filter out empty / falsy
  // names because Radix Select forbids an empty-string `value` prop on
  // <SelectItem> (it reserves "" to clear the selection + show the
  // placeholder). A student with a missing `batch` field would otherwise
  // crash the page.
  const batches = useMemo(
    () =>
      Array.from(
        new Set(
          students
            .map((s) => s.batch)
            .filter((b): b is string => typeof b === 'string' && b.trim() !== ''),
        ),
      ),
    [students],
  )

  const filtered = useMemo(() => {
    return students.filter((s) => {
      const q = search.trim().toLowerCase()
      if (
        q &&
        !s.name.toLowerCase().includes(q) &&
        !s.email.toLowerCase().includes(q) &&
        !s.id.toLowerCase().includes(q) &&
        !s.phone.toLowerCase().includes(q)
      )
        return false
      if (batchFilter !== 'all' && s.batch !== batchFilter) return false
      if (statusFilter !== 'all' && s.status !== statusFilter) return false
      if (chapterFilter !== 'all' && !s.assignedChapters.includes(chapterFilter)) return false
      return true
    })
  }, [students, search, batchFilter, statusFilter, chapterFilter])

  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage))
  const currentPage = Math.min(page, pageCount - 1)
  const start = currentPage * rowsPerPage
  const end = Math.min(start + rowsPerPage, filtered.length)
  const rows = filtered.slice(start, end)

  const toggleRow = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  const togglePage = () => {
    const allOnPage = rows.length > 0 && rows.every((r) => selected.has(r.id))
    setSelected((prev) => {
      const next = new Set(prev)
      if (allOnPage) rows.forEach((r) => next.delete(r.id))
      else rows.forEach((r) => next.add(r.id))
      return next
    })
  }

  const clearFilters = () => {
    setSearch('')
    setBatchFilter('all')
    setStatusFilter('all')
    setChapterFilter('all')
    setPage(0)
  }

  // ── Aggregate analytics ──
  const totalCerts = certificates.filter((c) => c.status === 'issued').length
  const examsCount = exams.length
  // "Active today" — students whose lastLogin falls on the most-recent login day
  const latestDay = useMemo(() => {
    const days = students
      .map((s) => s.lastLogin?.slice(0, 10))
      .filter(Boolean)
      .sort()
    return days[days.length - 1] ?? null
  }, [students])
  const activeToday = students.filter((s) => s.lastLogin?.slice(0, 10) === latestDay).length

  const activeFilters =
    search || batchFilter !== 'all' || statusFilter !== 'all' || chapterFilter !== 'all'

  // ── Handlers ──
  const openAdd = () => {
    setEditing(emptyForm)
    setAddOpen(true)
  }
  const openEdit = (s: Student) => {
    setEditing({
      id: s.id,
      name: s.name,
      email: s.email,
      phone: s.phone,
      address: s.address ?? '',
      batch: s.batch,
      status: s.status,
      validityEnd: s.validityEnd ?? '',
      photo: s.photo ?? '',
      assignedChapters: [...s.assignedChapters],
      notes: s.notes ?? '',
      newPassword: '',
    })
    setEditOpen(true)
  }
  const openDrawer = (s: Student) => {
    setViewing(s)
    setDrawerOpen(true)
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.name.trim() || !editing.email.trim()) {
      toast.error('Name and email are required')
      return
    }
    addStudent({
      name: editing.name.trim(),
      email: editing.email.trim(),
      phone: editing.phone.trim(),
      address: editing.address.trim() || undefined,
      batch: editing.batch,
      status: editing.status,
      avatarColor: avatarColors[Math.floor(Math.random() * avatarColors.length)],
      photo: editing.photo || undefined,
      assignedChapters: editing.assignedChapters,
      notes: editing.notes.trim() || undefined,
      validityEnd: editing.validityEnd || undefined,
    })
    toast.success('Student added', {
      description: `${editing.name} has been enrolled.`,
    })
    setAddOpen(false)
    setEditing(emptyForm)
    setLastSync(new Date())
  }

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editing.id) return
    const patch: Partial<Student> = {
      name: editing.name.trim(),
      email: editing.email.trim(),
      phone: editing.phone.trim(),
      address: editing.address.trim() || undefined,
      batch: editing.batch,
      status: editing.status,
      validityEnd: editing.validityEnd || undefined,
      notes: editing.notes.trim() || undefined,
      photo: editing.photo || undefined,
    }
    // Admin-only "Reset password" — when a non-empty value is entered, the
    // student's password is set directly (no reset-link email is sent).
    // Validation: minimum 6 characters.
    if (editing.newPassword) {
      if (editing.newPassword.length < 6) {
        toast.error('Password too short', { description: 'Minimum 6 characters.' })
        return
      }
      patch.password = editing.newPassword
    }
    updateStudent(editing.id, patch)
    assignChapters(editing.id, editing.assignedChapters)
    toast.success(
      'Student updated',
      {
        description: editing.newPassword
          ? `${editing.name} — password has been reset.`
          : editing.name,
      },
    )
    setEditOpen(false)
    setLastSync(new Date())
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    deleteStudent(deleteTarget.id)
    toast.error('Student deleted', { description: deleteTarget.name })
    setDeleteTarget(null)
  }

  const toggleStatus = (s: Student) => {
    const next: Student['status'] = s.status === 'suspended' ? 'active' : 'suspended'
    updateStudent(s.id, { status: next })
    toast.success(
      next === 'active' ? 'Student reactivated' : 'Student suspended',
      { description: s.name }
    )
  }

  // ── Reset password ──
  // The admin resets a student's password directly from the Edit Student
  // dialog's "Reset password" field — no reset-link email is sent. The
  // dropdown / drawer "Reset password" action simply opens the Edit dialog
  // so the admin can type the new password there.
  const resetPassword = (s: Student) => {
    openEdit(s)
    toast.info('Set a new password', {
      description: 'Type the new password in the “Reset password” field below.',
    })
  }

  const sendEmail = (s: Student) => {
    toast.success('Email composer opened', { description: s.email })
  }

  const downloadPdf = (s: Student) => {
    try {
      const sResults = results.filter((r) => r.studentId === s.id)
      const sCerts = certificates.filter((c) => c.studentId === s.id)
      downloadStudentProgressPdf(s, chapters, sResults, sCerts)
      toast.success('PDF report generated', {
        description: `${s.name}_Progress_Report.pdf`,
      })
    } catch {
      toast.error('Could not generate PDF', { description: s.name })
    }
  }

  const bulkActivate = () => {
    selected.forEach((id) => updateStudent(id, { status: 'active' }))
    toast.success(`${selected.size} students activated`)
    setSelected(new Set())
  }
  const bulkSuspend = () => {
    selected.forEach((id) => updateStudent(id, { status: 'suspended' }))
    toast.success(`${selected.size} students suspended`)
    setSelected(new Set())
  }
  const bulkDelete = () => {
    selected.forEach((id) => deleteStudent(id))
    toast.error(`${selected.size} students deleted`)
    setSelected(new Set())
    setBulkDeleteOpen(false)
  }
  const bulkExport = () => {
    toast.success('Export started', { description: `${selected.size} students` })
  }
  const bulkCertificate = () => {
    toast.success('Certificate generation queued', {
      description: `${selected.size} students`,
    })
    setSelected(new Set())
  }
  const bulkAssign = () => {
    if (!bulkAssignChapter) {
      toast.error('Pick a chapter to assign')
      return
    }
    const ch = chapters.find((c) => c.id === bulkAssignChapter)
    selected.forEach((id) => {
      const s = students.find((x) => x.id === id)
      if (s && !s.assignedChapters.includes(bulkAssignChapter)) {
        assignChapters(id, [...s.assignedChapters, bulkAssignChapter])
      }
    })
    toast.success('Chapter assigned', {
      description: `${ch?.name} → ${selected.size} students`,
    })
    setSelected(new Set())
    setBulkAssignOpen(false)
    setBulkAssignChapter('')
  }

  const handleImport = (e: React.FormEvent) => {
    e.preventDefault()
    const lines = csvText.trim().split(/\r?\n/).filter(Boolean)
    if (!lines.length) {
      toast.error('Paste at least one row')
      return
    }
    let added = 0
    for (const line of lines) {
      const [name, email, phone, batch] = line.split(',').map((c) => c.trim())
      if (!name || !email) continue
      addStudent({
        name,
        email,
        phone: phone || '',
        batch: batch || 'Batch 2026-A',
        status: 'active',
        avatarColor: avatarColors[Math.floor(Math.random() * avatarColors.length)],
        assignedChapters: [],
      })
      added++
    }
    toast.success(`${added} student${added === 1 ? '' : 's'} imported`)
    setCsvText('')
    setImportOpen(false)
  }

  const toggleAssignedChapter = (chId: string) => {
    setEditing((prev) => {
      const has = prev.assignedChapters.includes(chId)
      return {
        ...prev,
        assignedChapters: has
          ? prev.assignedChapters.filter((c) => c !== chId)
          : [...prev.assignedChapters, chId],
      }
    })
  }

  return (
    <div className="bg-premium-page min-h-[calc(100vh-4rem)] space-y-5 rounded-xl p-1">
      <PageHeader
        title={pageTitle}
        description="Manage enrolled students, batches, progress, exam performance and certificates."
        icon={<Users className="h-5 w-5" />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="btn-premium-outline h-9"
              onClick={() => {
                setLastSync(new Date())
                toast.success('Student data refreshed')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Sync</span>
            </Button>
            <Button variant="outline" className="btn-premium-outline h-9" onClick={() => setImportOpen(true)}>
              <Upload className="h-4 w-4" /> Import
            </Button>
            <Button className="btn-premium-primary h-9" onClick={openAdd}>
              <UserPlus className="h-4 w-4" /> Add Student
            </Button>
          </>
        }
      />

      {/* Last synced line */}
      <div className="-mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative inline-flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          All systems operational
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span>Last synced{' '}
          {lastSync.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
          })}
        </span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{students.length} records</span>
        <span className="text-muted-foreground/40">·</span>
        <span className="num-premium">{batches.length} batches</span>
      </div>

      {/* ── Richer analytics strip ── */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
        <StatCard
          title="Total Students"
          value={<AnimatedNumber value={students.length} />}
          icon={Users}
          accent="emerald"
          subtitle={`Across ${batchRecords.length} batches`}
          trend={{ value: '+3', positive: true }}
          delay={0}
        />
        <StatCard
          title="Total Chapters"
          value={<AnimatedNumber value={chapters.length} />}
          icon={BookOpen}
          accent="teal"
          subtitle="In curriculum"
          trend={{ value: '+1', positive: true }}
          delay={0.05}
        />
        <StatCard
          title="Total Exams"
          value={<AnimatedNumber value={examsCount} />}
          icon={BookCheck}
          accent="violet"
          subtitle="Published + draft"
          trend={{ value: '+2', positive: true }}
          delay={0.1}
        />
        <StatCard
          title="Total Batches"
          value={<AnimatedNumber value={batchRecords.length} />}
          icon={Layers}
          accent="amber"
          subtitle="Active cohorts"
          trend={{ value: '+1', positive: true }}
          delay={0.15}
        />
        <StatCard
          title="Certificates"
          value={<AnimatedNumber value={totalCerts} />}
          icon={Award}
          accent="rose"
          subtitle="Issued total"
          trend={{ value: '+4', positive: true }}
          delay={0.2}
        />
        <StatCard
          title="Active Today"
          value={<AnimatedNumber value={activeToday} />}
          icon={Flame}
          accent="emerald"
          subtitle="Logged in today"
          trend={{ value: '+5', positive: true }}
          delay={0.25}
        />
      </div>

      {/* ── Sticky filter bar ── */}
      <div className="sticky top-2 z-30">
        <div className="glass-filter-bar rounded-xl p-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                placeholder="Search by name, email, ID or phone…"
                className="input-premium h-9 pl-9"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={batchFilter}
                onValueChange={(v) => {
                  setBatchFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Batch" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All batches</SelectItem>
                  {batches.map((b) => (
                    <SelectItem key={b} value={b}>
                      {b}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={chapterFilter}
                onValueChange={(v) => {
                  setChapterFilter(v)
                  setPage(0)
                }}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Chapter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All chapters</SelectItem>
                  {chapters.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant={showAdvanced ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setShowAdvanced((s) => !s)}
              >
                <Sparkles className="h-4 w-4" />
                <span className="hidden sm:inline">Filters</span>
              </Button>
              {activeFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  <X className="h-4 w-4" /> Clear
                </Button>
              )}
            </div>
          </div>
          {showAdvanced && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/50 pt-3"
            >
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Quick views
              </span>
              {[
                { k: 'top', label: 'Top performers', icon: Crown },
                { k: 'at-risk', label: 'Needs attention', icon: UserX },
                { k: 'new', label: 'Recently joined', icon: Sparkles },
                { k: 'certified', label: 'Certified', icon: Award },
              ].map((q) => (
                <Button
                  key={q.k}
                  variant="outline"
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => toast.info(`${q.label} view applied`)}
                >
                  <q.icon className="h-3 w-3" /> {q.label}
                </Button>
              ))}
              <Separator orientation="vertical" className="mx-1 h-5" />
              <span className="text-xs text-muted-foreground">
                {filtered.length} of {students.length} students
              </span>
            </motion.div>
          )}
        </div>
      </div>

      {/* ── Table ── */}
      <Card className="card-premium rounded-xl p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={GraduationCap}
            title="No students yet"
            description="Create your first student to start tracking progress, exams and certificates."
            action={
              <Button className="btn-premium-primary h-9" onClick={openAdd}>
                <UserPlus className="h-4 w-4" /> Add Student
              </Button>
            }
            className="py-20"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 bg-muted/30 hover:bg-muted/30 [&_th]:h-14">
                  <TableHead className="w-10 pl-5">
                    <Checkbox
                      checked={
                        rows.length > 0 && rows.every((r) => selected.has(r.id))
                      }
                      onCheckedChange={togglePage}
                      aria-label="Select page"
                    />
                  </TableHead>
                  <TableHead className="min-w-[240px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Student</TableHead>
                  <TableHead className="hidden md:table-cell min-w-[180px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Contact</TableHead>
                  <TableHead className="hidden lg:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Batch</TableHead>
                  <TableHead className="min-w-[160px] text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Progress</TableHead>
                  <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Status</TableHead>
                  <TableHead className="hidden lg:table-cell text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Last Login</TableHead>
                  <TableHead className="w-[170px] pr-5 text-right text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((s) => {
                  const st = studentStats[s.id]
                  const tier = tierFor(st?.avgScore ?? 0)
                  const TierIcon = tier.icon
                  const assignedChapters = s.assignedChapters
                    .map((id) => chapters.find((c) => c.id === id))
                    .filter((c): c is NonNullable<typeof c> => Boolean(c))
                  const visibleChips = assignedChapters.slice(0, 3)
                  const hiddenChips = assignedChapters.slice(3)
                  const login = timeAgo(s.lastLogin)
                  const isTop = (st?.avgScore ?? 0) >= 90 && s.status === 'active'
                  return (
                    <Fragment key={s.id}>
                      <TableRow
                        data-state={selected.has(s.id) ? 'selected' : undefined}
                        onClick={() => openDrawer(s)}
                        className="row-premium group cursor-pointer border-border/40 transition-all hover:shadow-sm [&_td]:py-6"
                      >
                        <TableCell className="pl-5" onClick={(e) => e.stopPropagation()}>
                          <Checkbox
                            checked={selected.has(s.id)}
                            onCheckedChange={() => toggleRow(s.id)}
                            aria-label={`Select ${s.name}`}
                          />
                        </TableCell>
                        {/* Student identity */}
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <Avatar className="avatar-premium h-11 w-11">
                                {s.photo ? (
                                  <AvatarImage src={s.photo} alt={s.name} />
                                ) : null}
                                <AvatarFallback
                                  className={avatarColorClasses(s.avatarColor)}
                                >
                                  {initials(s.name)}
                                </AvatarFallback>
                              </Avatar>
                              {/* Tier ring badge */}
                              <span
                                className={`absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-background bg-background ${tier.className} ${
                                  tier.label === 'Gold' ? 'tier-glow-gold' : tier.label === 'Silver' ? 'tier-glow-silver' : tier.label === 'Bronze' ? 'tier-glow-bronze' : 'tier-glow-new'
                                }`}
                                title={`${tier.label} student`}
                              >
                                <TierIcon className="h-3 w-3" />
                              </span>
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="truncate text-sm font-semibold text-foreground">
                                  {s.name}
                                </span>
                                {isTop && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span className="inline-flex items-center rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-bold text-amber-600 dark:text-amber-400">
                                        <Star className="mr-0.5 h-2.5 w-2.5 fill-current" />
                                        Top
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>Top performer</TooltipContent>
                                  </Tooltip>
                                )}
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-muted-foreground num-premium">
                                <span>{s.id}</span>
                                <span className="text-muted-foreground/40">•</span>
                                <span className={`inline-flex items-center gap-0.5 font-semibold ${tier.className}`}>
                                  <TierIcon className="h-2.5 w-2.5" />
                                  {tier.label}
                                </span>
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        {/* Contact */}
                        <TableCell className="hidden md:table-cell">
                          <div className="flex flex-col gap-0.5">
                            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Mail className="h-3 w-3" />
                              <span className="truncate max-w-[160px]">{s.email}</span>
                            </span>
                            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              {s.phone}
                            </span>
                          </div>
                        </TableCell>
                        {/* Batch */}
                        <TableCell className="hidden lg:table-cell">
                          <Badge variant="outline" className="font-medium">
                            {s.batch}
                          </Badge>
                        </TableCell>
                        {/* Progress (overall + stage chips) */}
                        <TableCell>
                          <div className="space-y-1.5">
                            <div className="flex items-center gap-2">
                              <div className="progress-premium h-1.5 w-24">
                                <div
                                  className="progress-premium-fill"
                                  style={{ width: `${st?.progress ?? 0}%` }}
                                />
                              </div>
                              <span className="text-xs font-semibold num-premium">
                                {st?.progress ?? 0}%
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                              <StageMini label="S" value={st?.study ?? 0} />
                              <StageMini label="P" value={st?.practice ?? 0} />
                              <StageMini label="T" value={st?.tests ?? 0} />
                              <StageMini label="C" value={st?.certs ?? 0} />
                            </div>
                          </div>
                        </TableCell>
                        {/* Status */}
                        <TableCell>
                          <span className={`badge-status ${statusBadge[s.status]}`}>
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${dotColor(
                                s.status === 'active'
                                  ? 'emerald'
                                  : s.status === 'suspended'
                                  ? 'rose'
                                  : 'amber'
                              )}`}
                            />
                            <span className="capitalize">{s.status}</span>
                          </span>
                        </TableCell>
                        {/* Last login (relative + hover) */}
                        <TableCell className="hidden lg:table-cell">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="num-premium cursor-help text-xs font-medium text-muted-foreground">
                                {login.rel}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>{login.abs}</TooltipContent>
                          </Tooltip>
                        </TableCell>
                        {/* Quick action icons */}
                        <TableCell
                          className="pr-5"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="flex items-center justify-end gap-0.5 opacity-50 transition-all duration-200 group-hover:opacity-100">
                            <IconAction
                              icon={Eye}
                              label="View"
                              onClick={() => openDrawer(s)}
                            />
                            <IconAction
                              icon={FileDown}
                              label="Download PDF"
                              onClick={() => downloadPdf(s)}
                            />
                            <IconAction
                              icon={Pencil}
                              label="Edit"
                              onClick={() => openEdit(s)}
                            />
                            <IconAction
                              icon={Award}
                              label="Certificate"
                              onClick={() =>
                                toast.success('Certificate manager', {
                                  description: s.name,
                                })
                              }
                            />
                            <IconAction
                              icon={Mail}
                              label="Email"
                              onClick={() => sendEmail(s)}
                            />
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button
                                  aria-label="More actions"
                                  className="icon-btn-premium"
                                >
                                  <MoreHorizontal className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-44">
                                <DropdownMenuItem onClick={() => openDrawer(s)}>
                                  <Eye className="h-4 w-4" /> View profile
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => openEdit(s)}>
                                  <Pencil className="h-4 w-4" /> Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => sendEmail(s)}>
                                  <Mail className="h-4 w-4" /> Send email
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => downloadPdf(s)}>
                                  <FileDown className="h-4 w-4" /> Download PDF
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => resetPassword(s)}
                                >
                                  <ShieldBan className="h-4 w-4" /> Reset password
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => toggleStatus(s)}>
                                  <ShieldBan className="h-4 w-4" />
                                  {s.status === 'suspended'
                                    ? 'Activate'
                                    : 'Suspend'}
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  variant="destructive"
                                  onClick={() => setDeleteTarget(s)}
                                >
                                  <Trash2 className="h-4 w-4" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                      {/* ── Assigned chapters sub-row (compact chips + +N More) ── */}
                      {assignedChapters.length > 0 && (
                        <TableRow
                          className="hover:bg-transparent"
                          onClick={() => openDrawer(s)}
                        >
                          <TableCell
                            colSpan={8}
                            className="border-t-0 bg-muted/20 pb-3 pt-0"
                          >
                            <div className="flex flex-wrap items-center gap-1.5 pl-[60px]">
                              <span className="mr-1 inline-flex items-center gap-1 rounded-md bg-primary/5 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary">
                                <BookOpen className="h-3 w-3" /> {assignedChapters.length}
                              </span>
                              <span className="mr-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                                {assignedChapters.length === 1 ? 'chapter' : 'chapters'}
                              </span>
                              {visibleChips.map((ch) => {
                                const status = chapterStatusFor(
                                  s,
                                  ch.id,
                                  results,
                                  ch.name
                                )
                                const cs = chapterStatusStyles[status]
                                return (
                                  <Tooltip key={ch.id}>
                                    <TooltipTrigger asChild>
                                      <span
                                        className={`chip-premium ${cs.chip}`}
                                      >
                                        <span
                                          className={`h-1.5 w-1.5 rounded-full ${cs.dot}`}
                                        />
                                        {ch.name}
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="font-semibold">{ch.name}</p>
                                      <p className="text-primary-foreground/70">
                                        {cs.label}
                                      </p>
                                    </TooltipContent>
                                  </Tooltip>
                                )
                              })}
                              {hiddenChips.length > 0 && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="chip-premium inline-flex cursor-help items-center border-border bg-background text-muted-foreground hover:bg-muted">
                                      +{hiddenChips.length} more
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent className="max-w-[220px]">
                                    <div className="space-y-1">
                                      {hiddenChips.map((ch) => {
                                        const status = chapterStatusFor(
                                          s,
                                          ch.id,
                                          results,
                                          ch.name
                                        )
                                        const cs = chapterStatusStyles[status]
                                        return (
                                          <div
                                            key={ch.id}
                                            className="flex items-center gap-1.5 text-xs"
                                          >
                                            <span
                                              className={`h-1.5 w-1.5 rounded-full ${cs.dot}`}
                                            />
                                            <span>{ch.name}</span>
                                            <span className="text-primary-foreground/50">
                                              · {cs.label}
                                            </span>
                                          </div>
                                        )
                                      })}
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              )}
                              {/* Legend */}
                              <span className="ml-auto hidden items-center gap-3 text-[10px] text-muted-foreground lg:flex">
                                <LegendDot color="bg-emerald-500" label="Done" />
                                <LegendDot color="bg-amber-500" label="Progress" />
                                <LegendDot color="bg-rose-500" label="Not started" />
                              </span>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}

        {/* ── Pagination footer ── */}
        {filtered.length > 0 && (
          <div className="flex flex-col items-center justify-between gap-3 border-t border-border/50 px-5 py-3 sm:flex-row">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>
                Showing{' '}
                <span className="font-semibold text-foreground num-premium">
                  {start + 1}–{end}
                </span>{' '}
                of{' '}
                <span className="font-semibold text-foreground num-premium">
                  {filtered.length}
                </span>{' '}
                students
              </span>
              <Select
                value={String(rowsPerPage)}
                onValueChange={(v) => {
                  setRowsPerPage(Number(v))
                  setPage(0)
                }}
              >
                <SelectTrigger size="sm" className="h-7 w-[90px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[8, 12, 20, 50].map((n) => (
                    <SelectItem key={n} value={String(n)}>
                      {n} / page
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <div className="flex items-center gap-1 px-1">
                {Array.from({ length: Math.min(5, pageCount) }).map((_, i) => {
                  let p = i
                  if (pageCount > 5) {
                    p = Math.max(0, Math.min(pageCount - 5, currentPage - 2)) + i
                  }
                  return (
                    <button
                      key={p}
                      data-active={p === currentPage}
                      onClick={() => setPage(p)}
                      className="page-btn-premium num-premium flex h-7 w-7 items-center justify-center rounded-lg border border-border bg-background text-xs font-semibold text-muted-foreground hover:border-primary/30 hover:text-foreground"
                    >
                      {p + 1}
                    </button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="btn-premium-outline h-8"
                disabled={currentPage >= pageCount - 1}
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
              >
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Floating Add Student FAB ── */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.4, type: 'spring' }}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.94 }}
        onClick={openAdd}
        className="fab-premium fixed bottom-6 right-6 z-30 flex h-14 items-center gap-2 rounded-full px-5 transition-all"
        aria-label="Add student"
      >
        <UserPlus className="h-5 w-5" />
        <span className="hidden font-semibold sm:inline">Add Student</span>
      </motion.button>

      {/* ── Floating bulk action bar ── */}
      <AnimatePresence>
        {selected.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="bulk-bar-premium fixed inset-x-0 bottom-6 z-40 mx-auto flex w-fit max-w-[calc(100vw-2rem)] items-center gap-1 rounded-2xl px-3 py-2"
          >
            <span className="num-premium px-2 text-sm font-bold">
              {selected.size} selected
            </span>
            <div className="h-4 w-px bg-border" />
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setBulkAssignOpen(true)}
            >
              <BookOpen className="h-4 w-4" /> Assign
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkCertificate}>
              <Award className="h-4 w-4" /> Certificate
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkActivate}>
              <UserCheck className="h-4 w-4" /> Activate
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkSuspend}>
              <UserX className="h-4 w-4" /> Suspend
            </Button>
            <Button size="sm" variant="ghost" onClick={bulkExport}>
              <Download className="h-4 w-4" /> Export
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-destructive hover:text-destructive"
              onClick={() => setBulkDeleteOpen(true)}
            >
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
            <div className="h-4 w-px bg-border" />
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setSelected(new Set())}
            >
              Clear
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Add student dialog ── */}
      <StudentFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleAdd}
        chapters={chapters}
        toggleChapter={toggleAssignedChapter}
        batches={batches}
        mode="add"
      />

      {/* ── Edit student dialog ── */}
      <StudentFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        form={editing}
        setForm={setEditing}
        onSubmit={handleEdit}
        chapters={chapters}
        toggleChapter={toggleAssignedChapter}
        batches={batches}
        mode="edit"
      />

      {/* ── Student detail drawer (right Sheet) ── */}
      <StudentDetailSheet
        open={drawerOpen}
        onOpenChange={(o) => {
          setDrawerOpen(o)
          if (!o) setViewing(null)
        }}
        student={viewing}
        stat={viewing ? studentStats[viewing.id] : undefined}
        chapters={chapters}
        results={results}
        certificates={certificates}
        onEdit={(s) => {
          setDrawerOpen(false)
          openEdit(s)
        }}
        onEmail={sendEmail}
        onResetPassword={resetPassword}
        onToggleStatus={toggleStatus}
        onDownloadPdf={downloadPdf}
      />

      {/* ── Import dialog ── */}
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Import students</DialogTitle>
            <DialogDescription>
              Paste CSV rows in the format: name, email, phone, batch. One per line.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleImport} className="space-y-4">
            <Textarea
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder={
                'Aarav Sharma,aarav@example.com,+91 98xxx xxxxx,Batch 2026-A\nDiya Patel,diya@example.com,+91 98xxx xxxxx,Batch 2026-B'
              }
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setImportOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">
                <Upload className="h-4 w-4" /> Import
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* ── Bulk assign chapter ── */}
      <Dialog open={bulkAssignOpen} onOpenChange={setBulkAssignOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Assign chapter to {selected.size} students</DialogTitle>
            <DialogDescription>
              Pick a chapter. It will be added to every selected student who does
              not already have it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Select
              value={bulkAssignChapter}
              onValueChange={setBulkAssignChapter}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a chapter" />
              </SelectTrigger>
              <SelectContent>
                {chapters.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setBulkAssignOpen(false)}
            >
              Cancel
            </Button>
            <Button type="button" onClick={bulkAssign}>
              <BookOpen className="h-4 w-4" /> Assign to {selected.size}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete confirmation ── */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete student?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove{' '}
              <strong>{deleteTarget?.name}</strong> ({deleteTarget?.id}). This
              action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Bulk delete confirmation ── */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selected.size} students?</AlertDialogTitle>
            <AlertDialogDescription>
              All selected students will be permanently removed. This action
              cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={bulkDelete}
            >
              Delete {selected.size}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Small presentational helpers
// ────────────────────────────────────────────────────────────────────────────

function StageMini({ label, value }: { label: string; value: number }) {
  const color =
    value >= 75
      ? 'bg-emerald-500'
      : value >= 40
      ? 'bg-amber-500'
      : value > 0
      ? 'bg-rose-500'
      : 'bg-muted-foreground/30'
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span className="inline-flex items-center gap-0.5">
          <span className="text-[9px] font-bold text-muted-foreground">{label}</span>
          <span className="h-1.5 w-4 overflow-hidden rounded-full bg-muted">
            <span
              className={`block h-full rounded-full ${color}`}
              style={{ width: `${value}%` }}
            />
          </span>
          <span className="num-premium text-[9px] font-semibold text-muted-foreground">{value}</span>
        </span>
      </TooltipTrigger>
      <TooltipContent>
        {label === 'S' ? 'Study' : label === 'P' ? 'Practice' : label === 'T' ? 'Tests' : 'Certificates'}: {value}%
      </TooltipContent>
    </Tooltip>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1">
      <span className={`h-1.5 w-1.5 rounded-full ${color}`} />
      {label}
    </span>
  )
}

function IconAction({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Eye
  label: string
  onClick: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          aria-label={label}
          className="icon-btn-premium"
        >
          <Icon className="h-4 w-4" />
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Student detail right-side drawer
// ────────────────────────────────────────────────────────────────────────────

function StudentDetailSheet({
  open,
  onOpenChange,
  student,
  stat,
  chapters,
  results,
  certificates,
  onEdit,
  onEmail,
  onResetPassword,
  onToggleStatus,
  onDownloadPdf,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  student: Student | null
  stat?: StudentStat
  chapters: { id: string; name: string }[]
  results: {
    id: string
    studentId: string
    examTitle: string
    chapterName: string
    percentage: number
    status: string
    attemptNumber: number
    createdAt: string
  }[]
  certificates: {
    id: string
    studentId: string
    chapterName: string
    certificateNumber: string
    score: number
    issuedAt: string
    status: string
  }[]
  onEdit: (s: Student) => void
  onEmail: (s: Student) => void
  onResetPassword: (s: Student) => void
  onToggleStatus: (s: Student) => void
  onDownloadPdf: (s: Student) => void
}) {
  if (!student) return null
  const tier = tierFor(stat?.avgScore ?? 0)
  const TierIcon = tier.icon
  const sResults = results.filter((r) => r.studentId === student.id)
  const sCerts = certificates.filter(
    (c) => c.studentId === student.id && c.status === 'issued'
  )
  const assignedChapters = student.assignedChapters
    .map((id) => chapters.find((c) => c.id === id))
    .filter((c): c is NonNullable<typeof c> => Boolean(c))
  const login = timeAgo(student.lastLogin)

  // Build a synthetic timeline
  const timeline: { icon: typeof CheckCircle2; label: string; time: string; done: boolean }[] = [
    {
      icon: UserPlus,
      label: `Joined ${student.batch}`,
      time: student.enrolledAt,
      done: true,
    },
    {
      icon: BookOpen,
      label: `Assigned ${assignedChapters.length} chapter${assignedChapters.length === 1 ? '' : 's'}`,
      time: student.enrolledAt,
      done: assignedChapters.length > 0,
    },
    {
      icon: Brain,
      label: 'Completed first worksheet',
      time: sResults[0]?.createdAt ?? '—',
      done: sResults.length > 0,
    },
    {
      icon: CheckCircle2,
      label: 'Passed first exam',
      time: sResults.find((r) => r.status === 'passed')?.createdAt ?? '—',
      done: sResults.some((r) => r.status === 'passed'),
    },
    {
      icon: Award,
      label: 'Certificate generated',
      time: sCerts[0]?.issuedAt ?? '—',
      done: sCerts.length > 0,
    },
    {
      icon: Flame,
      label: 'Logged in recently',
      time: login.abs,
      done: !!student.lastLogin,
    },
  ]

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto p-0">
        <SheetHeader className="drawer-header-premium p-5 pb-4">
          <div className="flex items-start gap-4">
            <div className="relative">
              <Avatar className="avatar-premium h-16 w-16">
                {student.photo ? (
                  <AvatarImage src={student.photo} alt={student.name} />
                ) : null}
                <AvatarFallback className={avatarColorClasses(student.avatarColor)}>
                  {initials(student.name)}
                </AvatarFallback>
              </Avatar>
              <span
                className={`absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-background bg-background ${tier.className} ${
                  tier.label === 'Gold' ? 'tier-glow-gold' : tier.label === 'Silver' ? 'tier-glow-silver' : tier.label === 'Bronze' ? 'tier-glow-bronze' : 'tier-glow-new'
                }`}
              >
                <TierIcon className="h-3.5 w-3.5" />
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <SheetTitle className="flex items-center gap-2 text-lg">
                <span className="truncate font-bold">{student.name}</span>
                <span className={`badge-status ${statusBadge[student.status]}`}>
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${dotColor(
                      student.status === 'active'
                        ? 'emerald'
                        : student.status === 'suspended'
                        ? 'rose'
                        : 'amber'
                    )}`}
                  />
                  <span className="capitalize">{student.status}</span>
                </span>
              </SheetTitle>
              <SheetDescription className="flex items-center gap-2 num-premium">
                <span>{student.id}</span>
                <span className="text-muted-foreground/40">•</span>
                <span className={`inline-flex items-center gap-1 font-semibold ${tier.className}`}>
                  <TierIcon className="h-3 w-3" />
                  {tier.label} Student
                </span>
              </SheetDescription>
              <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                <Badge variant="outline" className="font-medium">
                  {student.batch}
                </Badge>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" /> {login.rel}
                </span>
              </div>
            </div>
          </div>
          {/* Quick actions */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            <Button size="sm" className="btn-premium-primary h-8" onClick={() => onDownloadPdf(student)}>
              <FileDown className="h-3.5 w-3.5" /> Download PDF
            </Button>
            <Button size="sm" className="btn-premium-outline h-8" variant="outline" onClick={() => onEdit(student)}>
              <Pencil className="h-3.5 w-3.5" /> Edit
            </Button>
            <Button size="sm" className="btn-premium-outline h-8" variant="outline" onClick={() => onEmail(student)}>
              <Mail className="h-3.5 w-3.5" /> Email
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onResetPassword(student)}
            >
              <ShieldBan className="h-3.5 w-3.5" /> Reset
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onToggleStatus(student)}
            >
              {student.status === 'suspended' ? (
                <>
                  <UserCheck className="h-3.5 w-3.5" /> Activate
                </>
              ) : (
                <>
                  <UserX className="h-3.5 w-3.5" /> Suspend
                </>
              )}
            </Button>
          </div>
        </SheetHeader>

        <div className="space-y-5 p-5">
          {/* Contact + meta */}
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex items-center gap-2 truncate">
              <Mail className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <span className="truncate">{student.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              {student.phone}
            </div>
            {student.address && (
              <div className="flex items-center gap-2 col-span-2">
                <MapPin className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                {student.address}
              </div>
            )}
            <div className="flex items-center gap-2">
              <Calendar className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              Joined {student.enrolledAt}
            </div>
            {student.validityEnd && (
              <div className="flex items-center gap-2">
                <ShieldBan className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                Valid until {student.validityEnd}
              </div>
            )}
          </div>

          {/* Health + score summary */}
          <div className="grid grid-cols-3 gap-3">
            <div className="flex flex-col items-center justify-center rounded-xl border bg-card p-3">
              <HealthRing value={stat?.health ?? 0} size={48} />
              <span className="mt-1 text-[10px] font-medium text-muted-foreground">
                Health
              </span>
            </div>
            <div className="flex flex-col items-center justify-center rounded-xl border bg-card p-3">
              <span
                className={`text-2xl font-bold tabular-nums ${
                  (stat?.avgScore ?? 0) >= 80
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : (stat?.avgScore ?? 0) >= 60
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {stat?.avgScore ?? 0}%
              </span>
              <span className="mt-0.5 text-[10px] font-medium text-muted-foreground">
                Avg score
              </span>
            </div>
            <div className="flex flex-col items-center justify-center rounded-xl border bg-card p-3">
              <span className="text-2xl font-bold tabular-nums">
                {stat?.progress ?? 0}%
              </span>
              <span className="mt-0.5 text-[10px] font-medium text-muted-foreground">
                Progress
              </span>
            </div>
          </div>

          {/* Stage breakdown */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Stage progress
            </p>
            {[
              { label: 'Study', value: stat?.study ?? 0, icon: BookOpen },
              { label: 'Practice', value: stat?.practice ?? 0, icon: Brain },
              { label: 'Tests', value: stat?.tests ?? 0, icon: CheckCircle2 },
              { label: 'Certificates', value: stat?.certs ?? 0, icon: Award },
            ].map((row) => (
              <div key={row.label} className="flex items-center gap-3">
                <row.icon className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="w-20 text-xs font-medium">{row.label}</span>
                <Progress value={row.value} className="h-1.5 flex-1" />
                <span className="w-8 text-right text-xs tabular-nums text-muted-foreground">
                  {row.value}%
                </span>
              </div>
            ))}
          </div>

          {/* Assigned chapters with status */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Assigned chapters ({assignedChapters.length})
            </p>
            {assignedChapters.length === 0 ? (
              <p className="rounded-lg border border-dashed px-4 py-4 text-center text-xs text-muted-foreground">
                No chapters assigned yet.
              </p>
            ) : (
              <div className="space-y-1.5">
                {assignedChapters.map((ch) => {
                  const status = chapterStatusFor(student, ch.id, results, ch.name)
                  const cs = chapterStatusStyles[status]
                  return (
                    <div
                      key={ch.id}
                      className="flex items-center justify-between rounded-lg border px-3 py-1.5"
                    >
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-sm font-medium">{ch.name}</span>
                      </div>
                      <span
                        className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${cs.chip}`}
                      >
                        <span className={`h-1.5 w-1.5 rounded-full ${cs.dot}`} />
                        {cs.label}
                      </span>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Tabs: timeline / results / certificates */}
          <Tabs defaultValue="timeline">
            <TabsList className="w-full">
              <TabsTrigger value="timeline" className="flex-1 text-xs">
                Timeline
              </TabsTrigger>
              <TabsTrigger value="results" className="flex-1 text-xs">
                Results ({sResults.length})
              </TabsTrigger>
              <TabsTrigger value="certs" className="flex-1 text-xs">
                Certs ({sCerts.length})
              </TabsTrigger>
            </TabsList>

            {/* Timeline */}
            <TabsContent value="timeline" className="mt-3 space-y-3">
              <div className="relative pl-2">
                <div className="absolute left-[7px] top-1 h-full w-px bg-border" />
                {timeline.map((t, i) => {
                  const TIcon = t.icon
                  return (
                    <div key={i} className="relative flex items-start gap-3 pb-3">
                      <span
                        className={`relative z-10 flex h-3.5 w-3.5 items-center justify-center rounded-full border-2 border-background ${
                          t.done ? 'bg-emerald-500' : 'bg-muted-foreground/30'
                        }`}
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 text-sm font-medium">
                          <TIcon className="h-3 w-3 text-muted-foreground" />
                          {t.label}
                        </div>
                        <div className="text-xs text-muted-foreground tabular-nums">
                          {t.time}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </TabsContent>

            {/* Results */}
            <TabsContent
              value="results"
              className="mt-3 max-h-72 space-y-2 overflow-y-auto"
            >
              {sResults.length === 0 ? (
                <p className="rounded-lg border border-dashed px-4 py-6 text-center text-xs text-muted-foreground">
                  No results yet
                </p>
              ) : (
                sResults
                  .slice()
                  .reverse()
                  .map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm"
                    >
                      <div className="min-w-0">
                        <div className="truncate font-medium">{r.examTitle}</div>
                        <div className="text-xs text-muted-foreground tabular-nums">
                          {r.createdAt} · Attempt #{r.attemptNumber}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="tabular-nums text-sm font-semibold">
                          {r.percentage}%
                        </span>
                        <Badge
                          variant="outline"
                          className={
                            r.status === 'passed'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                          }
                        >
                          <span className="capitalize">{r.status}</span>
                        </Badge>
                      </div>
                    </div>
                  ))
              )}
            </TabsContent>

            {/* Certificates */}
            <TabsContent
              value="certs"
              className="mt-3 max-h-72 space-y-2 overflow-y-auto"
            >
              {sCerts.length === 0 ? (
                <p className="rounded-lg border border-dashed px-4 py-6 text-center text-xs text-muted-foreground">
                  No certificates yet
                </p>
              ) : (
                sCerts.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm"
                  >
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-amber-500" />
                      <div className="min-w-0">
                        <div className="truncate font-medium">{c.chapterName}</div>
                        <div className="text-xs text-muted-foreground tabular-nums">
                          {c.certificateNumber}
                        </div>
                      </div>
                    </div>
                    <span className="tabular-nums text-sm font-semibold">
                      {c.score}%
                    </span>
                  </div>
                ))
              )}
            </TabsContent>
          </Tabs>

          {student.notes && (
            <div className="rounded-lg border bg-muted/30 p-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Notes
              </p>
              <p className="mt-1 text-sm">{student.notes}</p>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Add / edit student form dialog
// ────────────────────────────────────────────────────────────────────────────

function StudentFormDialog({
  open,
  onOpenChange,
  form,
  setForm,
  onSubmit,
  chapters,
  toggleChapter,
  batches,
  mode,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  form: StudentFormState
  setForm: React.Dispatch<React.SetStateAction<StudentFormState>>
  onSubmit: (e: React.FormEvent) => void
  chapters: { id: string; name: string }[]
  toggleChapter: (id: string) => void
  batches: string[]
  mode: 'add' | 'edit'
}) {
  const update = (patch: Partial<StudentFormState>) =>
    setForm((p) => ({ ...p, ...patch }))

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG, or SVG).')
      return
    }
    if (file.size > 800 * 1024) {
      toast.error('Image too large. Maximum 800 KB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = String(reader.result || '')
      update({ photo: dataUrl })
      toast.success('Photo added', { description: file.name })
    }
    reader.onerror = () => toast.error('Could not read the image file.')
    reader.readAsDataURL(file)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'add' ? 'Add a new student' : 'Edit student'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'add'
              ? 'They will receive an invite email with onboarding instructions.'
              : 'Update the student profile and assigned chapters.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          {/* Photo uploader */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2 border-border">
              {form.photo ? (
                <AvatarImage src={form.photo} alt={form.name || 'Student'} />
              ) : null}
              <AvatarFallback className="bg-primary/10 text-sm font-bold text-primary">
                {form.name ? (
                  form.name
                    .split(' ')
                    .map((p) => p[0])
                    .join('')
                    .slice(0, 2)
                    .toUpperCase()
                ) : (
                  <Users className="h-5 w-5" />
                )}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    document.getElementById('student-photo-input')?.click()
                  }
                >
                  <Upload className="h-4 w-4" />
                  {form.photo ? 'Change photo' : 'Upload photo'}
                </Button>
                {form.photo && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => update({ photo: '' })}
                  >
                    <X className="h-4 w-4" /> Remove
                  </Button>
                )}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                JPG, PNG or SVG. Max 800 KB.
              </p>
              <input
                id="student-photo-input"
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={handlePhotoUpload}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Full name</Label>
            <Input
              id="name"
              value={form.name}
              onChange={(e) => update({ name: e.target.value })}
              placeholder="e.g. Aarav Sharma"
              required
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => update({ email: e.target.value })}
                placeholder="student@powermaths.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={form.phone}
                onChange={(e) => update({ phone: e.target.value })}
                placeholder="+91 98xxx xxxxx"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input
              id="address"
              value={form.address}
              onChange={(e) => update({ address: e.target.value })}
              placeholder="City, State"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="batch">Batch</Label>
              <Select value={form.batch} onValueChange={(v) => update({ batch: v })}>
                <SelectTrigger id="batch" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from(
                    new Set([
                      ...batches,
                      'Batch 2026-A',
                      'Batch 2026-B',
                      'Batch 2026-C',
                    ])
                  ).map((b) => (
                    <SelectItem key={b} value={b}>
                      {b}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={form.status}
                onValueChange={(v) => update({ status: v as Student['status'] })}
              >
                <SelectTrigger id="status" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="validity">Validity end date (optional)</Label>
            <Input
              id="validity"
              type="date"
              value={form.validityEnd}
              onChange={(e) => update({ validityEnd: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Assigned chapters ({form.assignedChapters.length})</Label>
            <div className="rounded-lg border p-3 max-h-40 overflow-y-auto space-y-2">
              {chapters.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  No chapters available.
                </p>
              ) : (
                chapters.map((c) => (
                  <label
                    key={c.id}
                    className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/40 rounded px-2 py-1"
                  >
                    <Checkbox
                      checked={form.assignedChapters.includes(c.id)}
                      onCheckedChange={() => toggleChapter(c.id)}
                    />
                    <span>{c.name}</span>
                  </label>
                ))
              )}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea
              id="notes"
              rows={2}
              value={form.notes}
              onChange={(e) => update({ notes: e.target.value })}
              placeholder="Internal notes about this student"
            />
          </div>

          {/* ── Reset password (admin-only, edit mode) ──
              The admin can set a new password directly without sending a
              reset-link email. Leave empty to keep the current password. */}
          {mode === 'edit' && (
            <div className="space-y-2 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
              <Label htmlFor="newPassword" className="flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
                <ShieldCheck className="h-3.5 w-3.5" />
                Reset password (optional)
              </Label>
              <Input
                id="newPassword"
                type="password"
                value={form.newPassword}
                onChange={(e) => update({ newPassword: e.target.value })}
                placeholder="Leave empty to keep the current password"
                autoComplete="new-password"
              />
              <p className="text-[11px] text-muted-foreground">
                Enter a new password (min. 6 characters) to reset it instantly.
                No reset-link email is sent. The student can use the new password
                on their next login.
              </p>
            </div>
          )}
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              {mode === 'add' ? 'Add student' : 'Save changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
