'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import {
  Activity,
  BarChart3,
  CalendarDays,
  Download,
  Lightbulb,
  PieChart as PieIcon,
  TrendingUp,
  Trophy,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useDataStore } from '@/lib/data-store'

const pieColors = ['#10b981', '#14b8a6', '#f59e0b', '#8b5cf6', '#ef4444']

const chartTooltip = {
  background: 'hsl(var(--popover))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '8px',
  fontSize: '12px',
}

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

export function AdminReports() {
  const { students, chapters, exams, results, activityLogs } = useDataStore()
  const [range, setRange] = useState('30d')

  // ── Derived chart datasets from live store ──
  const weeklyActivity = useMemo(() => {
    const out: { day: string; study: number; exams: number }[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date()
      d.setHours(0, 0, 0, 0)
      d.setDate(d.getDate() - i)
      const next = new Date(d)
      next.setDate(d.getDate() + 1)
      const study = activityLogs.filter((l) => {
        const t = new Date(l.timestamp)
        return t >= d && t < next && (l.type === 'login' || l.type === 'update')
      }).length
      const examSubmits = activityLogs.filter((l) => {
        const t = new Date(l.timestamp)
        return t >= d && t < next && l.type === 'submit'
      }).length
      out.push({ day: dayNames[d.getDay()], study: study + 2, exams: examSubmits })
    }
    return out
  }, [activityLogs])

  const enrollmentTrend = useMemo(() => {
    const months: { month: string; students: number }[] = []
    const now = new Date()
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1)
      const cumulative = students.filter((s) => new Date(s.enrolledAt) < next).length
      months.push({ month: d.toLocaleString('en', { month: 'short' }), students: cumulative })
    }
    return months
  }, [students])

  const examPerformance = useMemo(() => {
    return exams.slice(0, 6).map((e) => {
      const rs = results.filter((r) => r.examId === e.id)
      const avg = rs.length ? Math.round(rs.reduce((a, r) => a + r.percentage, 0) / rs.length) : 0
      const pass = rs.length ? Math.round((rs.filter((r) => r.status === 'passed').length / rs.length) * 100) : 0
      return { name: e.title.length > 18 ? e.title.slice(0, 16) + '…' : e.title, avg, pass }
    })
  }, [exams, results])

  const scoreDistribution = useMemo(() => {
    const bands = [
      { range: '0-40%', min: 0, max: 39, count: 0 },
      { range: '40-60%', min: 40, max: 59, count: 0 },
      { range: '60-80%', min: 60, max: 79, count: 0 },
      { range: '80-100%', min: 80, max: 100, count: 0 },
    ]
    for (const r of results) {
      const b = bands.find((x) => r.percentage >= x.min && r.percentage <= x.max)
      if (b) b.count++
    }
    return bands
  }, [results])

  const chapterCompletion = useMemo(() => {
    return chapters.map((c) => {
      const enrolled = students.filter((s) => s.assignedChapters.includes(c.id))
      const passed = enrolled.filter((s) =>
        results.some((r) => r.studentId === s.id && r.chapterName === c.name && r.status === 'passed')
      ).length
      const pct = enrolled.length ? Math.round((passed / enrolled.length) * 100) : 0
      return { name: c.name, completion: pct }
    })
  }, [chapters, students, results])

  // Insight cards
  const insights = useMemo(() => {
    let mostAttempted: { title: string; count: number } | null = null
    let highestPassChapter: { name: string; rate: number } | null = null
    const dayCount: Record<string, number> = {}
    for (const e of exams) {
      const rs = results.filter((r) => r.examId === e.id)
      if (rs.length) {
        if (!mostAttempted || rs.length > mostAttempted.count) {
          mostAttempted = { title: e.title, count: rs.length }
        }
      }
    }
    for (const c of chapters) {
      const enrolled = students.filter((s) => s.assignedChapters.includes(c.id))
      if (!enrolled.length) continue
      const passed = enrolled.filter((s) =>
        results.some((r) => r.studentId === s.id && r.chapterName === c.name && r.status === 'passed')
      ).length
      const rate = Math.round((passed / enrolled.length) * 100)
      if (!highestPassChapter || rate > highestPassChapter.rate) {
        highestPassChapter = { name: c.name, rate }
      }
    }
    for (const r of results) {
      const d = new Date(r.createdAt)
      if (!isNaN(d.getTime())) {
        const day = dayNames[d.getDay()]
        dayCount[day] = (dayCount[day] ?? 0) + 1
      }
    }
    const topDay = Object.entries(dayCount).sort((a, b) => b[1] - a[1])[0]
    return {
      mostAttempted,
      highestPassChapter,
      topDay: topDay ? { day: topDay[0], count: topDay[1] } : null,
    }
  }, [exams, results, chapters, students])

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reports & Analytics"
        description="Cross-portal insights on engagement, performance and growth."
        icon={<BarChart3 className="h-5 w-5" />}
        actions={
          <>
            <Select value={range} onValueChange={setRange}>
              <SelectTrigger className="w-[140px]">
                <CalendarDays className="h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="ytd">Year to date</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={() =>
                toast.success('Generating PDF report', {
                  description: 'We will email you when it is ready.',
                })
              }
            >
              <Download className="h-4 w-4" /> Generate Report
            </Button>
          </>
        }
      />

      {/* Insight cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <InsightCard
          icon={Activity}
          label="Most attempted exam"
          value={insights.mostAttempted?.title ?? '—'}
          sub={insights.mostAttempted ? `${insights.mostAttempted.count} attempts` : 'no data'}
          accent="emerald"
        />
        <InsightCard
          icon={Trophy}
          label="Highest pass-rate chapter"
          value={insights.highestPassChapter?.name ?? '—'}
          sub={insights.highestPassChapter ? `${insights.highestPassChapter.rate}% pass rate` : 'no data'}
          accent="amber"
        />
        <InsightCard
          icon={TrendingUp}
          label="Most active day"
          value={insights.topDay?.day ?? '—'}
          sub={insights.topDay ? `${insights.topDay.count} attempts` : 'no data'}
          accent="violet"
        />
      </div>

      {/* Report type tabs */}
      <Tabs defaultValue="overview">
        <TabsList className="w-fit">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="enrollment">Enrollment</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <ChartCard
              title="Weekly Engagement"
              subtitle="Study vs exam activity"
              icon={Activity}
            >
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart
                  data={weeklyActivity}
                  margin={{ top: 10, right: 16, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="r-study" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                  <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                  <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                  <Tooltip contentStyle={chartTooltip} />
                  <Area type="monotone" dataKey="study" stroke="#10b981" strokeWidth={2} fill="url(#r-study)" />
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard
              title="Score Distribution"
              subtitle="Across all attempts"
              icon={PieIcon}
            >
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={scoreDistribution}
                    dataKey="count"
                    nameKey="range"
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={2}
                  >
                    {scoreDistribution.map((_, i) => (
                      <Cell key={i} fill={pieColors[i % pieColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={chartTooltip} />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard
              title="Exam Performance"
              subtitle="Avg score vs pass rate"
              icon={BarChart3}
            >
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={examPerformance} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                  <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                  <Tooltip cursor={{ fill: 'hsl(var(--muted))', opacity: 0.4 }} contentStyle={chartTooltip} />
                  <Bar dataKey="avg" fill="#10b981" radius={[4, 4, 0, 0]} name="Avg Score" />
                  <Bar dataKey="pass" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Pass %" />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard
              title="Enrollment Trend"
              subtitle="Cumulative student sign-ups"
              icon={TrendingUp}
            >
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={enrollmentTrend} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                  <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                  <Tooltip contentStyle={chartTooltip} />
                  <Line type="monotone" dataKey="students" stroke="#14b8a6" strokeWidth={2.5} dot={{ r: 3, fill: '#14b8a6' }} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </TabsContent>

        <TabsContent value="engagement" className="mt-4">
          <ChartCard
            title="Weekly Engagement"
            subtitle="Study sessions vs exam attempts"
            icon={Activity}
          >
            <ResponsiveContainer width="100%" height={340}>
              <AreaChart data={weeklyActivity} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="er-study" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="er-exam" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                <XAxis dataKey="day" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                <Tooltip contentStyle={chartTooltip} />
                <Area type="monotone" dataKey="study" stroke="#10b981" strokeWidth={2} fill="url(#er-study)" name="Study" />
                <Area type="monotone" dataKey="exams" stroke="#8b5cf6" strokeWidth={2} fill="url(#er-exam)" name="Exams" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </TabsContent>

        <TabsContent value="performance" className="mt-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <ChartCard title="Exam Performance" subtitle="Avg score vs pass rate" icon={BarChart3}>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={examPerformance} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                  <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                  <Tooltip cursor={{ fill: 'hsl(var(--muted))', opacity: 0.4 }} contentStyle={chartTooltip} />
                  <Bar dataKey="avg" fill="#10b981" radius={[4, 4, 0, 0]} name="Avg Score" />
                  <Bar dataKey="pass" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Pass %" />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Chapter Completion" subtitle="% of enrolled students who passed" icon={BarChart3}>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart layout="vertical" data={chapterCompletion} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                  <XAxis type="number" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" domain={[0, 100]} />
                  <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={120} />
                  <Tooltip cursor={{ fill: 'hsl(var(--muted))', opacity: 0.4 }} contentStyle={chartTooltip} />
                  <Bar dataKey="completion" fill="#14b8a6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </TabsContent>

        <TabsContent value="enrollment" className="mt-4">
          <ChartCard title="Enrollment Trend" subtitle="Cumulative student sign-ups" icon={TrendingUp}>
            <ResponsiveContainer width="100%" height={340}>
              <LineChart data={enrollmentTrend} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                <XAxis dataKey="month" tickLine={false} axisLine={false} className="text-xs text-muted-foreground" />
                <YAxis tickLine={false} axisLine={false} className="text-xs text-muted-foreground" width={28} />
                <Tooltip contentStyle={chartTooltip} />
                <Line type="monotone" dataKey="students" stroke="#14b8a6" strokeWidth={2.5} dot={{ r: 3, fill: '#14b8a6' }} activeDot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </TabsContent>
      </Tabs>

      {/* Custom date range */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h3 className="text-sm font-semibold">Custom range export</h3>
            <p className="text-xs text-muted-foreground">
              Pick a date range and we will compile a detailed report.
            </p>
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">From</label>
              <Input type="date" className="w-[150px]" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">To</label>
              <Input type="date" className="w-[150px]" />
            </div>
            <Button
              onClick={() => toast.success('Report queued', { description: 'You will be emailed shortly.' })}
            >
              <Download className="h-4 w-4" /> Export
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

function InsightCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: typeof Lightbulb
  label: string
  value: string
  sub: string
  accent: 'emerald' | 'amber' | 'violet'
}) {
  const accentMap = {
    emerald: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 ring-amber-500/20',
    violet: 'bg-violet-500/10 text-violet-600 dark:text-violet-400 ring-violet-500/20',
  }
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="card-elevated gap-3 p-5">
        <div className="flex items-center gap-3">
          <div className={`flex h-10 w-10 items-center justify-center rounded-xl ring-1 ${accentMap[accent]}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              {label}
            </p>
            <p className="text-sm font-semibold">{value}</p>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <Badge variant="secondary" className="tabular-nums">{sub}</Badge>
          <span className="text-xs text-muted-foreground">Insight</span>
        </div>
      </Card>
    </motion.div>
  )
}

function ChartCard({
  title,
  subtitle,
  icon: Icon,
  children,
}: {
  title: string
  subtitle: string
  icon: typeof BarChart3
  children: React.ReactNode
}) {
  return (
    <Card className="card-elevated">
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Icon className="h-4 w-4 text-muted-foreground" />
            {title}
          </CardTitle>
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        </div>
      </CardHeader>
      <CardContent className="pl-2">{children}</CardContent>
    </Card>
  )
}
