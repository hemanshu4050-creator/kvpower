'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  BookOpen,
  CheckCircle2,
  Layers,
  Loader2,
  LogIn,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
  Trophy,
  Upload,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useDataStore, getDashboardStats, type ActivityLog } from '@/lib/data-store'
import { avatarColorClasses, dotColor, initials } from './lib/helpers'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'
import { generateAdminSnapshotPdf } from '@/lib/admin-snapshot-pdf'

const typeIconMap: Record<ActivityLog['type'], typeof Plus> = {
  create: Plus,
  update: Pencil,
  delete: Trash2,
  login: LogIn,
  submit: CheckCircle2,
  system: Sparkles,
}

const typeColorMap: Record<ActivityLog['type'], string> = {
  create: 'bg-emerald-500',
  update: 'bg-sky-500',
  delete: 'bg-rose-500',
  login: 'bg-violet-500',
  submit: 'bg-amber-500',
  system: 'bg-zinc-400',
}

export function AdminDashboard() {
  const setAdminPage = useAppStore((s) => s.setAdminPage)
  const user = useAppStore((s) => s.user)
  const {
    students,
    batches,
    chapters,
    questions,
    exams,
    results,
    certificates,
    activityLogs,
  } = useDataStore()

  const [snapshotBusy, setSnapshotBusy] = useState(false)

  const stats = useMemo(() => getDashboardStats(), [students, chapters, exams, results, certificates])

  // Export a multi-page PDF snapshot of the entire portal (students,
  // batches, chapters, content, exams, certifications).
  const handleExportSnapshot = async () => {
    if (snapshotBusy) return
    setSnapshotBusy(true)
    const tid = toast.loading('Generating portal snapshot PDF…', {
      description: 'Collecting students, chapters, content & exams.',
    })
    try {
      await generateAdminSnapshotPdf({
        students,
        batches,
        chapters,
        questions,
        exams,
        results,
        certificates,
        adminName: user?.name || 'Prof. Kalpesh Vyas',
      })
      toast.success('Snapshot PDF generated', {
        id: tid,
        description: 'Check your downloads folder.',
      })
    } catch (err) {
      console.error('[Export Snapshot]', err)
      toast.error('Could not generate snapshot', {
        id: tid,
        description: err instanceof Error ? err.message : 'Unexpected error.',
      })
    } finally {
      setSnapshotBusy(false)
    }
  }

  // Top performers: avg score from results
  const topPerformers = useMemo(() => {
    return students
      .map((s) => {
        const rs = results.filter((r) => r.studentId === s.id)
        const avg = rs.length ? Math.round(rs.reduce((a, r) => a + r.percentage, 0) / rs.length) : 0
        const certs = certificates.filter((c) => c.studentId === s.id && c.status === 'issued').length
        return { ...s, avgScore: avg, examsCompleted: rs.length, certificates: certs }
      })
      .sort((a, b) => b.avgScore - a.avgScore)
      .slice(0, 5)
  }, [students, results, certificates])

  // Chapter-wise Content Breakdown — mirrors the same table that appears
  // in the Export Snapshot PDF. Per-chapter content counts (theory,
  // materials, formulas, practice, tests) + questions linked to it.
  const chapterBreakdown = useMemo(() => {
    return [...chapters]
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((c) => {
        const qCount = questions.filter(
          (q) => Array.isArray(q.chapterIds) && q.chapterIds.includes(c.id),
        ).length
        return {
          id: c.id,
          name: c.name,
          status: c.status,
          theory: c.theories?.length || 0,
          materials: c.studyMaterials?.length || 0,
          formulas: c.formulas?.length || 0,
          practice: c.practiceSheets?.length || 0,
          tests: c.tests?.length || 0,
          questions: qCount,
        }
      })
  }, [chapters, questions])

  const chapterTotals = useMemo(() => ({
    theory: chapterBreakdown.reduce((a, r) => a + r.theory, 0),
    materials: chapterBreakdown.reduce((a, r) => a + r.materials, 0),
    formulas: chapterBreakdown.reduce((a, r) => a + r.formulas, 0),
    practice: chapterBreakdown.reduce((a, r) => a + r.practice, 0),
    tests: chapterBreakdown.reduce((a, r) => a + r.tests, 0),
    questions: chapterBreakdown.reduce((a, r) => a + r.questions, 0),
  }), [chapterBreakdown])

  // For the per-chapter question-coverage bar: max questions across all
  // chapters (so bars are scaled relative to the heaviest chapter).
  const maxChapterQuestions = useMemo(
    () => Math.max(1, ...chapterBreakdown.map((r) => r.questions)),
    [chapterBreakdown],
  )

  // Level / Batch wise Content Breakdown — mirrors the same table that
  // appears in the Export Snapshot PDF. Aggregates chapters, students,
  // exams, materials, formulas, practice sheets and questions per batch.
  const batchBreakdown = useMemo(() => {
    return [...batches]
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
      .map((b) => {
        const cIds = Array.isArray(b.chapterIds) ? b.chapterIds : []
        const eIds = Array.isArray(b.examIds) ? b.examIds : []
        const assignedChapters = chapters.filter((c) => cIds.includes(c.id))
        const studentCount = students.filter((s) => s.batch === b.name).length
        const materials = assignedChapters.reduce((a, c) => a + (c.studyMaterials?.length || 0), 0)
        const formulas = assignedChapters.reduce((a, c) => a + (c.formulas?.length || 0), 0)
        const practice = assignedChapters.reduce((a, c) => a + (c.practiceSheets?.length || 0), 0)
        const tests = assignedChapters.reduce((a, c) => a + (c.tests?.length || 0), 0)
        const qCount = questions.filter(
          (q) => Array.isArray(q.chapterIds) && q.chapterIds.some((id) => cIds.includes(id)),
        ).length
        return {
          id: b.id,
          name: b.name,
          code: b.code,
          status: b.status,
          chapters: cIds.length,
          students: studentCount,
          exams: eIds.length,
          materials,
          formulas,
          practice,
          tests,
          questions: qCount,
        }
      })
  }, [batches, chapters, students, questions])

  const batchTotals = useMemo(() => ({
    chapters: batchBreakdown.reduce((a, r) => a + r.chapters, 0),
    students: batchBreakdown.reduce((a, r) => a + r.students, 0),
    exams: batchBreakdown.reduce((a, r) => a + r.exams, 0),
    materials: batchBreakdown.reduce((a, r) => a + r.materials, 0),
    formulas: batchBreakdown.reduce((a, r) => a + r.formulas, 0),
    practice: batchBreakdown.reduce((a, r) => a + r.practice, 0),
    questions: batchBreakdown.reduce((a, r) => a + r.questions, 0),
  }), [batchBreakdown])

  // For the per-level chapter-coverage bar: max chapters across all
  // levels (so bars are scaled relative to the largest level).
  const maxBatchChapters = useMemo(
    () => Math.max(1, ...batchBreakdown.map((r) => r.chapters)),
    [batchBreakdown],
  )

  const today = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })

  const recentResults = useMemo(
    () => [...results].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)).slice(0, 5),
    [results]
  )

  const greeting = (() => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  })()

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative overflow-hidden rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-500 p-6 text-white shadow-lg sm:p-8"
      >
        <div className="absolute inset-0 bg-grid opacity-[0.12]" aria-hidden />
        <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-white/10 blur-3xl" aria-hidden />
        <div className="absolute -bottom-24 right-24 h-56 w-56 rounded-full bg-teal-300/20 blur-3xl" aria-hidden />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-emerald-50/80">
              <Sparkles className="h-3.5 w-3.5" />
              {today}
            </div>
            <h2 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
              {greeting}, {user?.name?.split(' ').slice(0, 2).join(' ')} 👋
            </h2>
            <p className="mt-1 max-w-xl text-sm text-emerald-50/90">
              Your portal is healthy. {stats.activeToday} students
              logged in today and{' '}
              {results.filter((r) => r.status === 'passed').length} exams were
              passed.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="secondary"
                className="bg-white/15 text-white hover:bg-white/25 hover:text-white"
                onClick={handleExportSnapshot}
                disabled={snapshotBusy}
              >
                {snapshotBusy ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Generating…
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" /> Export Snapshot
                  </>
                )}
              </Button>
            </div>
          </div>
          <div className="grid shrink-0 grid-cols-3 gap-3 sm:gap-4">
            {[
              { label: 'Students', value: stats.totalStudents },
              { label: 'Exams', value: stats.totalExams },
              { label: 'Pass rate', value: `${stats.passRate}%` },
            ].map((s) => (
              <div
                key={s.label}
                className="rounded-xl bg-white/10 px-3 py-2.5 text-center backdrop-blur-sm ring-1 ring-white/15"
              >
                <div className="text-xl font-bold tabular-nums sm:text-2xl">
                  {s.value}
                </div>
                <div className="text-[10px] uppercase tracking-wide text-emerald-50/80">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Chapter-wise Content Breakdown — mirrors the PDF table */}
      <Card className="card-elevated">
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-emerald-500" />
              Chapter-wise Content Breakdown
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Theory, materials, formulas, practice, tests &amp; questions in each chapter
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAdminPage('chapters')}
          >
            Manage chapters
          </Button>
        </CardHeader>
        <CardContent className="px-0">
          {chapterBreakdown.length === 0 ? (
            <div className="px-6 py-10 text-center text-sm text-muted-foreground">
              No chapters configured yet. Create one from Chapter Management to see the breakdown here.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-4 py-2.5 font-medium">#</th>
                    <th className="px-4 py-2.5 font-medium">Chapter</th>
                    <th className="px-4 py-2.5 text-center font-medium">Theory</th>
                    <th className="px-4 py-2.5 text-center font-medium">Materials</th>
                    <th className="px-4 py-2.5 text-center font-medium">Formula</th>
                    <th className="px-4 py-2.5 text-center font-medium">Practice</th>
                    <th className="px-4 py-2.5 text-center font-medium">Tests</th>
                    <th className="px-4 py-2.5 text-center font-medium">Questions</th>
                  </tr>
                </thead>
                <tbody>
                  {chapterBreakdown.map((row, i) => {
                    const coveragePct = Math.round((row.questions / maxChapterQuestions) * 100)
                    const isDraft = row.status === 'draft'
                    return (
                      <tr
                        key={row.id}
                        className="border-b last:border-0 hover:bg-muted/40"
                      >
                        <td className="px-4 py-3 tabular-nums text-muted-foreground">
                          {i + 1}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${
                                isDraft
                                  ? 'bg-muted text-muted-foreground'
                                  : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              }`}
                            >
                              <BookOpen className="h-3.5 w-3.5" />
                            </span>
                            <div className="min-w-0">
                              <p className={`truncate text-sm font-medium ${isDraft ? 'text-muted-foreground' : ''}`}>
                                {row.name}
                              </p>
                              {isDraft && (
                                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                                  draft
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.theory === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.theory}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.materials === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.materials}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.formulas === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.formulas}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.practice === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.practice}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.tests === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.tests}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-sm font-bold tabular-nums">{row.questions}</span>
                            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500"
                                style={{ width: `${coveragePct}%` }}
                              />
                            </div>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 bg-emerald-500/5">
                    <td className="px-4 py-3" colSpan={2}>
                      <span className="text-sm font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                        Total
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.theory}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.materials}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.formulas}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.practice}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.tests}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {chapterTotals.questions}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Level / Batch wise Content Breakdown — mirrors the PDF table */}
      <Card className="card-elevated">
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-emerald-500" />
              Level / Batch wise Content Breakdown
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Chapters, students, exams &amp; content assigned to each level / batch
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAdminPage('batches')}
          >
            Manage levels
          </Button>
        </CardHeader>
        <CardContent className="px-0">
          {batchBreakdown.length === 0 ? (
            <div className="px-6 py-10 text-center text-sm text-muted-foreground">
              No levels / batches configured yet. Create one from Level Management to see the breakdown here.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-4 py-2.5 font-medium">#</th>
                    <th className="px-4 py-2.5 font-medium">Level / Batch</th>
                    <th className="px-4 py-2.5 text-center font-medium">Chapters</th>
                    <th className="px-4 py-2.5 text-center font-medium">Students</th>
                    <th className="px-4 py-2.5 text-center font-medium">Exams</th>
                    <th className="px-4 py-2.5 text-center font-medium">Materials</th>
                    <th className="px-4 py-2.5 text-center font-medium">Formulas</th>
                    <th className="px-4 py-2.5 text-center font-medium">Practice</th>
                    <th className="px-4 py-2.5 text-center font-medium">Questions</th>
                  </tr>
                </thead>
                <tbody>
                  {batchBreakdown.map((row, i) => {
                    const coveragePct = Math.round((row.chapters / maxBatchChapters) * 100)
                    const isArchived = row.status === 'archived'
                    return (
                      <tr
                        key={row.id}
                        className="border-b last:border-0 hover:bg-muted/40"
                      >
                        <td className="px-4 py-3 tabular-nums text-muted-foreground">
                          {i + 1}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[10px] font-bold ${
                                isArchived
                                  ? 'bg-muted text-muted-foreground'
                                  : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              }`}
                            >
                              <Layers className="h-3.5 w-3.5" />
                            </span>
                            <div className="min-w-0">
                              <p className={`truncate text-sm font-medium ${isArchived ? 'text-muted-foreground line-through' : ''}`}>
                                {row.name}
                              </p>
                              {row.code && (
                                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                                  {row.code}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-sm font-bold tabular-nums">{row.chapters}</span>
                            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500"
                                style={{ width: `${coveragePct}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.students === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.students}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.exams === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.exams}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.materials === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.materials}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.formulas === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.formulas}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.practice === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.practice}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center tabular-nums">
                          <span className={`text-sm font-semibold ${row.questions === 0 ? 'text-muted-foreground' : ''}`}>
                            {row.questions}
                          </span>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 bg-emerald-500/5">
                    <td className="px-4 py-3" colSpan={2}>
                      <span className="text-sm font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                        Total
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.chapters}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.students}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.exams}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.materials}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.formulas}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.practice}
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                      {batchTotals.questions}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Activity + Top Performers */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Activity</CardTitle>
              <p className="text-sm text-muted-foreground">
                Latest events across the portal
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAdminPage('activity')}
            >
              View all
            </Button>
          </CardHeader>
          <CardContent>
            {activityLogs.length === 0 ? (
              <p className="text-sm text-muted-foreground">No activity yet.</p>
            ) : (
              <ol className="relative space-y-1">
                {activityLogs.slice(0, 7).map((log, i, arr) => {
                  const Icon = typeIconMap[log.type]
                  const color = typeColorMap[log.type]
                  return (
                    <li key={log.id} className="relative flex gap-3 pb-4">
                      {i < arr.length - 1 && (
                        <span
                          className="absolute left-[14px] top-7 h-[calc(100%-1rem)] w-px bg-border"
                          aria-hidden
                        />
                      )}
                      <div
                        className={`relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-white ${color}`}
                      >
                        <Icon className="h-3.5 w-3.5" />
                      </div>
                      <div className="min-w-0 flex-1 pt-0.5">
                        <p className="text-sm">
                          <span className="font-medium">{log.user}</span>{' '}
                          <span className="text-muted-foreground">
                            {log.action}
                          </span>
                          {log.target && (
                            <>
                              {' '}
                              <span className="font-medium">{log.target}</span>
                            </>
                          )}
                        </p>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          {log.time} ·{' '}
                          <Badge
                            variant="outline"
                            className="px-1.5 py-0 text-[10px] capitalize"
                          >
                            {log.role}
                          </Badge>
                        </p>
                      </div>
                    </li>
                  )
                })}
              </ol>
            )}
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Top Performers</CardTitle>
              <p className="text-sm text-muted-foreground">By average score</p>
            </div>
            <Trophy className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent className="space-y-1">
            {topPerformers.length === 0 ? (
              <p className="text-sm text-muted-foreground">No results yet.</p>
            ) : (
              topPerformers.map((s, i) => (
                <div
                  key={s.id}
                  className="flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-muted/60"
                >
                  <div
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                      i === 0
                        ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                        : i === 1
                        ? 'bg-zinc-400/15 text-zinc-700 dark:text-zinc-300'
                        : i === 2
                        ? 'bg-orange-500/15 text-orange-700 dark:text-orange-300'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {i + 1}
                  </div>
                  <div
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${avatarColorClasses(
                      s.avatarColor
                    )}`}
                  >
                    {initials(s.name)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{s.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {s.examsCompleted} exams · {s.certificates} certs
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold tabular-nums">
                      {s.avgScore}%
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent results table */}
      <Card className="card-elevated">
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Results</CardTitle>
            <p className="text-sm text-muted-foreground">
              Latest submitted exam attempts
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAdminPage('results')}
          >
            View all
          </Button>
        </CardHeader>
        <CardContent className="px-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-6 py-2 font-medium">Student</th>
                  <th className="px-6 py-2 font-medium">Exam</th>
                  <th className="px-6 py-2 font-medium">Score</th>
                  <th className="px-6 py-2 font-medium">Percentage</th>
                  <th className="px-6 py-2 font-medium">Date</th>
                  <th className="px-6 py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentResults.map((r) => {
                  const student = students.find((s) => s.id === r.studentId)
                  return (
                    <tr
                      key={r.id}
                      className="border-b last:border-0 hover:bg-muted/40"
                    >
                      <td className="px-6 py-3">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-semibold ${avatarColorClasses(
                              student?.avatarColor
                            )}`}
                          >
                            {initials(r.studentName)}
                          </div>
                          <span className="font-medium">{r.studentName}</span>
                        </div>
                      </td>
                      <td className="px-6 py-3 text-muted-foreground">
                        {r.examTitle}
                      </td>
                      <td className="px-6 py-3 tabular-nums">
                        {r.marksObtained}/{r.totalMarks}
                      </td>
                      <td className="px-6 py-3 tabular-nums">
                        {r.percentage}%
                      </td>
                      <td className="px-6 py-3 text-muted-foreground tabular-nums">
                        {r.createdAt}
                      </td>
                      <td className="px-6 py-3">
                        <Badge
                          variant="outline"
                          className={
                            r.status === 'passed'
                              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                          }
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${dotColor(
                              r.status === 'passed' ? 'emerald' : 'rose'
                            )}`}
                          />
                          {r.status === 'passed' ? 'Passed' : 'Failed'}
                        </Badge>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
