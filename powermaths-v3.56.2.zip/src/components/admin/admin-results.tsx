'use client'

import { useMemo, useState } from 'react'
import {
  Award,
  Calendar,
  CheckCircle2,
  Download,
  Eye,
  FileBarChart,
  Goal,
  MoreHorizontal,
  Search,
  Target,
  TrendingUp,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useDataStore, type Result } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { downloadResultScorecardPdf } from '@/lib/student-pdf'
import { avatarColorClasses, dotColor, initials } from './lib/helpers'

function percentageBadge(p: number): string {
  if (p >= 80)
    return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
  if (p >= 60)
    return 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300'
  return 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
}

export function AdminResults() {
  const pageTitle = useNavLabel('results', 'Results')
  const { results, exams, students } = useDataStore()

  const [search, setSearch] = useState('')
  const [examFilter, setExamFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [viewing, setViewing] = useState<Result | null>(null)

  const filtered = useMemo(() => {
    return results
      .filter((r) => {
        const q = search.trim().toLowerCase()
        if (
          q &&
          !r.studentName.toLowerCase().includes(q) &&
          !r.examTitle.toLowerCase().includes(q)
        )
          return false
        if (examFilter !== 'all' && r.examId !== examFilter) return false
        if (statusFilter !== 'all' && r.status !== statusFilter) return false
        if (from && r.createdAt < from) return false
        if (to && r.createdAt > to) return false
        return true
      })
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
  }, [results, search, examFilter, statusFilter, from, to])

  const totalAttempts = results.length
  const passRate = totalAttempts
    ? Math.round((results.filter((r) => r.status === 'passed').length / totalAttempts) * 100)
    : 0
  const avgScore = totalAttempts
    ? Math.round(results.reduce((a, r) => a + r.percentage, 0) / totalAttempts)
    : 0
  const topScorer = [...results].sort((a, b) => b.percentage - a.percentage)[0]

  // Hardest / best / most-attempted
  const examStats = useMemo(() => {
    if (!exams.length) return null
    let hardest: { title: string; avg: number } | null = null
    let best: { title: string; avg: number } | null = null
    let mostAttempts: { title: string; count: number } | null = null
    for (const e of exams) {
      const rs = results.filter((r) => r.examId === e.id)
      if (!rs.length) continue
      const avg = Math.round(rs.reduce((a, r) => a + r.percentage, 0) / rs.length)
      if (!hardest || avg < hardest.avg) hardest = { title: e.title, avg }
      if (!best || avg > best.avg) best = { title: e.title, avg }
      if (!mostAttempts || rs.length > mostAttempts.count) mostAttempts = { title: e.title, count: rs.length }
    }
    return { hardest, best, mostAttempts }
  }, [exams, results])

  const clearFilters = () => {
    setSearch('')
    setExamFilter('all')
    setStatusFilter('all')
    setFrom('')
    setTo('')
  }

  // ── Download a single result as a PDF scorecard. Admins get the full
  // breakdown: every question, the student's chosen answer AND the correct
  // answer. Works for both pass and fail attempts.
  const handleDownload = (r: Result) => {
    try {
      downloadResultScorecardPdf({
        id: r.id,
        studentName: r.studentName,
        studentId: r.studentId,
        examTitle: r.examTitle,
        chapterName: r.chapterName,
        attemptNumber: r.attemptNumber,
        createdAt: r.createdAt,
        timeTakenMinutes: r.timeTakenMinutes,
        totalQuestions: r.totalQuestions,
        attempted: r.attempted,
        correct: r.correct,
        wrong: r.wrong,
        marksObtained: r.marksObtained,
        totalMarks: r.totalMarks,
        percentage: r.percentage,
        status: r.status,
        answers: r.answers.map((a) => ({
          questionText: a.questionText,
          options: a.options,
          selectedOption: a.selectedOption,
          correctOption: a.correctOption,
          isCorrect: a.isCorrect,
          marksAwarded: a.marksAwarded,
          maxMarks: a.maxMarks,
          explanation: a.explanation,
          timeTakenSeconds: a.timeTakenSeconds,
        })),
        // Admin view shows BOTH the student's selected answer AND the
        // correct answer for every question (per requirement #6).
        showAnswers: true,
      })
      toast.success('Scorecard downloaded', {
        description: `${r.studentName} — ${r.examTitle} — ${r.percentage}%`,
      })
    } catch {
      toast.error('Could not generate PDF', { description: r.examTitle })
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Track every exam attempt, score and outcome."
        icon={<FileBarChart className="h-5 w-5" />}
        actions={
          <Button
            variant="outline"
            onClick={() => toast.success('Export started', { description: 'CSV will download shortly.' })}
          >
            <Download className="h-4 w-4" /> Export
          </Button>
        }
      />

      {/* Summary */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Attempts" value={totalAttempts} icon={Goal} accent="emerald" delay={0} />
        <StatCard title="Pass Rate" value={`${passRate}%`} icon={CheckCircle2} accent="teal" delay={0.05} />
        <StatCard title="Avg Score" value={`${avgScore}%`} icon={TrendingUp} accent="amber" delay={0.1} />
        <StatCard
          title="Top Scorer"
          value={topScorer ? `${topScorer.percentage}%` : 0}
          icon={Award}
          accent="violet"
          delay={0.15}
        />
      </div>

      {/* Filter bar */}
      <Card className="card-elevated p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by student or exam…"
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={examFilter} onValueChange={setExamFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Exam" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All exams</SelectItem>
                {exams.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="passed">Passed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-[140px]"
              aria-label="From date"
            />
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-[140px]"
              aria-label="To date"
            />
            {(search || examFilter !== 'all' || statusFilter !== 'all' || from || to) && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Table — full width */}
      <Card className="card-elevated p-0">
          {filtered.length === 0 ? (
            <EmptyState
              icon={FileBarChart}
              title="No results found"
              description="Adjust your filters to see exam attempts."
              action={
                <Button variant="outline" onClick={clearFilters}>
                  Reset filters
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="pl-4">Student</TableHead>
                    <TableHead className="hidden md:table-cell">Exam</TableHead>
                    <TableHead className="text-right">Score</TableHead>
                    <TableHead>%</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden lg:table-cell">Date</TableHead>
                    <TableHead className="hidden xl:table-cell text-right">Min</TableHead>
                    <TableHead className="pr-4" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((r) => {
                    const student = students.find((s) => s.id === r.studentId)
                    return (
                      <TableRow key={r.id}>
                        <TableCell className="pl-4">
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold ${avatarColorClasses(
                                student?.avatarColor
                              )}`}
                            >
                              {initials(r.studentName)}
                            </div>
                            <div className="min-w-0">
                              <div className="truncate text-sm font-medium">
                                {r.studentName}
                              </div>
                              <div className="text-xs text-muted-foreground tabular-nums">
                                {r.id}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell max-w-[220px]">
                          <span className="line-clamp-1 text-sm text-muted-foreground">
                            {r.examTitle}
                          </span>
                        </TableCell>
                        <TableCell className="text-right tabular-nums">
                          <span className="font-medium">
                            {r.marksObtained}
                          </span>
                          <span className="text-muted-foreground">/{r.totalMarks}</span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={percentageBadge(r.percentage)}>
                            {r.percentage}%
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              r.status === 'passed'
                                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                                : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300'
                            }
                          >
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${dotColor(
                                r.status === 'passed' ? 'emerald' : 'rose'
                              )}`}
                            />
                            <span className="capitalize">{r.status}</span>
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-xs text-muted-foreground tabular-nums">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {r.createdAt}
                          </span>
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-right tabular-nums text-muted-foreground">
                          {r.timeTakenMinutes}m
                        </TableCell>
                        <TableCell className="pr-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuItem onClick={() => setViewing(r)}>
                                <Eye className="h-4 w-4" /> View detail
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDownload(r)}>
                                <Download className="h-4 w-4" /> Download PDF
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}

        </Card>

      {/* Insight strip */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Insight
          icon={Target}
          label="Hardest exam"
          value={examStats?.hardest?.title ?? '—'}
          sub={examStats?.hardest ? `${examStats.hardest.avg}% avg` : 'no data'}
        />
        <Insight
          icon={TrendingUp}
          label="Best exam"
          value={examStats?.best?.title ?? '—'}
          sub={examStats?.best ? `${examStats.best.avg}% avg` : 'no data'}
        />
        <Insight
          icon={Award}
          label="Most attempts"
          value={examStats?.mostAttempts?.title ?? '—'}
          sub={examStats?.mostAttempts ? `${examStats.mostAttempts.count} attempts` : 'no data'}
        />
      </div>

      {/* View detail dialog */}
      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between gap-2 pr-8">
                  <span>Result detail</span>
                  <span className="flex items-center gap-2">
                    {viewing.status === 'passed' ? (
                      <Badge className="border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                        <CheckCircle2 className="h-3 w-3" /> Passed
                      </Badge>
                    ) : (
                      <Badge className="border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-300">
                        <XCircle className="h-3 w-3" /> Failed
                      </Badge>
                    )}
                  </span>
                </DialogTitle>
                <DialogDescription>
                  {viewing.studentName} · {viewing.examTitle} · Attempt #{viewing.attemptNumber}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 mb-4">
                <Tile label="Score" value={`${viewing.marksObtained}/${viewing.totalMarks}`} />
                <Tile label="Percentage" value={`${viewing.percentage}%`} />
                <Tile label="Correct" value={`${viewing.correct}/${viewing.totalQuestions}`} />
                <Tile label="Time" value={`${viewing.timeTakenMinutes}m`} />
              </div>
              <ScrollArea className="max-h-[50vh] pr-2">
                {viewing.answers.length === 0 ? (
                  <p className="rounded-lg border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
                    No answer-level breakdown was recorded for this attempt.
                  </p>
                ) : (
                  <ol className="space-y-3 pr-2">
                    {viewing.answers.map((a, i) => (
                      <li key={a.questionId} className="rounded-lg border p-3">
                        <div className="flex items-start gap-2">
                          <Badge variant="outline" className="mt-0.5 shrink-0 text-[10px]">Q{i + 1}</Badge>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium">{a.questionText}</p>
                            <div className="mt-1.5 grid gap-1 text-xs">
                              {a.options.filter(Boolean).map((opt, idx) => {
                                const isCorrect = idx === a.correctOption
                                const isSelected = idx === a.selectedOption
                                return (
                                  <div
                                    key={idx}
                                    className={`flex items-center justify-between gap-2 rounded px-2 py-1 ${
                                      isCorrect
                                        ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                                        : isSelected
                                        ? 'bg-rose-500/10 text-rose-700 dark:text-rose-300'
                                        : 'text-muted-foreground'
                                    }`}
                                  >
                                    <span className="flex items-center gap-1.5">
                                      <span className="font-mono text-[10px] font-bold opacity-70">
                                        {String.fromCharCode(65 + idx)}
                                      </span>
                                      {opt}
                                    </span>
                                    <span className="flex items-center gap-1.5 text-[10px] font-semibold">
                                      {isCorrect && (
                                        <span className="flex items-center gap-0.5">
                                          <CheckCircle2 className="h-3 w-3" /> Correct answer
                                        </span>
                                      )}
                                      {isSelected && (
                                        <span className={isCorrect ? 'text-emerald-700 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-300'}>
                                          {isCorrect ? '· Student chose this' : '· Student chose this'}
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                )
                              })}
                            </div>
                            {a.explanation && (
                              <p className="mt-1.5 text-xs text-muted-foreground">
                                <strong>Explanation:</strong> {a.explanation}
                              </p>
                            )}
                            <p className="mt-1 text-[10px] text-muted-foreground tabular-nums">
                              {a.marksAwarded}/{a.maxMarks} marks · {a.timeTakenSeconds}s
                            </p>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ol>
                )}
              </ScrollArea>
              <DialogFooter className="gap-2 sm:justify-between">
                <Button variant="outline" onClick={() => handleDownload(viewing)}>
                  <Download className="h-4 w-4" /> Download PDF
                </Button>
                <Button variant="outline" onClick={() => setViewing(null)}>Close</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Tile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-muted/30 px-3 py-2 text-center">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-base font-bold tabular-nums">{value}</div>
    </div>
  )
}

function Insight({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: typeof Target
  label: string
  value: string
  sub: string
}) {
  return (
    <Card className="card-elevated flex-row items-center gap-2.5 p-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="truncate text-sm font-semibold">{value}</p>
        <p className="text-xs text-muted-foreground tabular-nums">{sub}</p>
      </div>
    </Card>
  )
}
