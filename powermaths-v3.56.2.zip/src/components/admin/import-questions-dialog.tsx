'use client'

/**
 * v3.53.6 — Import Questions Dialog.
 *
 * Lets the admin bulk-import questions from a .docx / .pdf / .txt file.
 * The file is parsed entirely in the browser (mammoth / pdf-parse) — the
 * raw file never leaves the user's machine.
 *
 * Flow:
 *   1. Pick target chapter(s) — multi-select checkboxes (same UX as the
 *      Create Question form).
 *   2. Upload a file (.docx / .pdf / .txt).
 *   3. Auto-parse → preview table of detected questions with inline edit.
 *   4. Review → toggle which questions to import, fix any parsing mistakes.
 *   5. [Import N questions] → bulk-add to the question bank.
 */

import * as React from 'react'
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileText,
  FileUp,
  Loader2,
  Pencil,
  Check,
  X,
  Upload,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  parseQuestions,
  extractTextFromFile,
  type ParsedQuestion,
} from '@/lib/question-parser'
import type { Question, QuestionLevel } from '@/lib/data-store'
import { QUESTION_LEVELS } from '@/lib/data-store'

/** Chapter metadata for the multi-select list. */
interface ChapterOption {
  id: string
  name: string
}

/** A question row in the preview, with an editable flag and selected flag. */
interface PreviewRow extends ParsedQuestion {
  /** Whether the admin wants to import this row. Skipped ones are ignored. */
  selected: boolean
  /** Whether the row is in edit mode (inline). */
  editing: boolean
}

interface ImportQuestionsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** All chapters available for selection. */
  chapters: ChapterOption[]
  /** Chapter IDs to pre-check (e.g. the currently filtered chapter). */
  preselectedChapterIds?: string[]
  /** Called when the admin confirms the import. Returns the count added. */
  onImport: (questions: Omit<Question, 'id' | 'createdAt'>[]) => number
}

export function ImportQuestionsDialog({
  open,
  onOpenChange,
  chapters,
  preselectedChapterIds = [],
  onImport,
}: ImportQuestionsDialogProps) {
  // ── Step 1 state: chapter selection ──
  const [selectedChapters, setSelectedChapters] = React.useState<string[]>(preselectedChapterIds)

  // v3.53.8 — Step 1b: default Marks/Level/Type for all imported
  // questions. The admin sets these once in the popup instead of putting
  // them in every question in the Word/PDF file. If a question in the file
  // DOES specify Marks/Level/Type, the file's value takes priority.
  // v3.54.0 — "Difficulty" renamed to "Level", 12 levels (was 4 difficulty tiers).
  const [defaultMarks, setDefaultMarks] = React.useState(2)
  const [defaultDifficulty, setDefaultDifficulty] = React.useState<QuestionLevel>('level-6')
  const [defaultType, setDefaultType] = React.useState<'mcq' | 'numerical' | 'true-false'>('mcq')

  // ── Step 2 state: file + parsing ──
  const [fileName, setFileName] = React.useState<string | null>(null)
  const [parsing, setParsing] = React.useState(false)
  const [parseError, setParseError] = React.useState<string | null>(null)

  // ── Step 3 state: preview rows ──
  const [rows, setRows] = React.useState<PreviewRow[]>([])

  // Reset state when the dialog closes
  React.useEffect(() => {
    if (!open) {
      setFileName(null)
      setParsing(false)
      setParseError(null)
      setRows([])
      setSelectedChapters(preselectedChapterIds)
      // v3.53.8 — reset defaults
      setDefaultMarks(2)
      setDefaultDifficulty('level-6')
      setDefaultType('mcq')
    }
  }, [open, preselectedChapterIds])

  // ── Chapter multi-select handlers ──
  const toggleChapter = (id: string) => {
    setSelectedChapters((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id],
    )
  }
  const selectAllChapters = () => setSelectedChapters(chapters.map((c) => c.id))
  const clearAllChapters = () => setSelectedChapters([])

  // ── File picker + parser ──
  const handleFileSelect = async (file: File) => {
    setParsing(true)
    setParseError(null)
    setFileName(file.name)
    try {
      const text = await extractTextFromFile(file)
      const parsed = parseQuestions(text)
      if (parsed.length === 0) {
        setParseError('No questions were detected. Please check the file format.')
        setRows([])
      } else {
        setRows(parsed.map((q) => ({ ...q, selected: !q.warning, editing: false })))
      }
    } catch (err) {
      setParseError(err instanceof Error ? err.message : 'Failed to parse file.')
      setRows([])
    } finally {
      setParsing(false)
    }
  }

  // ── Preview row handlers ──
  const toggleRow = (idx: number) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, selected: !r.selected } : r)))
  }
  const startEditRow = (idx: number) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, editing: true } : r)))
  }
  const saveEditRow = (idx: number) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, editing: false } : r)))
  }
  const updateRowField = (idx: number, field: keyof ParsedQuestion, value: unknown) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r)))
  }
  const updateRowOption = (idx: number, optIdx: number, value: string) => {
    setRows((prev) =>
      prev.map((r, i) => {
        if (i !== idx) return r
        const options = [...r.options]
        options[optIdx] = value
        return { ...r, options }
      }),
    )
  }

  // ── Import handler ──
  const selectedCount = rows.filter((r) => r.selected).length
  const skippedCount = rows.filter((r) => !r.selected).length

  const handleImport = () => {
    if (selectedChapters.length === 0) {
      toast.error('Select at least one chapter', {
        description: 'Questions need to be linked to a chapter.',
      })
      return
    }
    const toImport = rows.filter((r) => r.selected)
    if (toImport.length === 0) {
      toast.error('No questions selected', {
        description: 'Tick at least one question to import.',
      })
      return
    }

    const questions: Omit<Question, 'id' | 'createdAt'>[] = toImport.map((r) => ({
      chapterId: selectedChapters[0], // primary chapter (legacy field)
      chapterIds: [...selectedChapters], // all selected chapters
      // v3.53.8 — use the file's value if present, else the dialog's default
      type: r.type ?? defaultType,
      difficulty: r.difficulty ?? defaultDifficulty,
      text: r.text,
      options: (r.type ?? defaultType) === 'numerical' ? [] : r.options,
      correctAnswer: r.correctAnswer < 0 ? 0 : r.correctAnswer,
      explanation: r.explanation,
      marks: r.marks ?? defaultMarks,
    }))

    const count = onImport(questions)
    toast.success(`Imported ${count} question${count !== 1 ? 's' : ''}`, {
      description:
        skippedCount > 0
          ? `${skippedCount} skipped. Linked to ${selectedChapters.length} chapter${selectedChapters.length !== 1 ? 's' : ''}.`
          : `Linked to ${selectedChapters.length} chapter${selectedChapters.length !== 1 ? 's' : ''}.`,
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileUp className="h-5 w-5 text-primary" />
            Import Questions from File
          </DialogTitle>
          <DialogDescription>
            Bulk-import MCQ / numerical / true-false questions from a Word (.docx), PDF (.pdf), or text (.txt) file. The file is parsed entirely in your browser — nothing is uploaded to a server.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* ── Step 1: Chapter selection ── */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold">
                1. Pick target chapter(s) for all imported questions
              </Label>
              <div className="flex gap-2">
                <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={selectAllChapters}>
                  Select all
                </Button>
                <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={clearAllChapters}>
                  Clear
                </Button>
              </div>
            </div>
            <div className="rounded-lg border border-border/60 bg-muted/20 p-3 max-h-32 overflow-y-auto">
              {chapters.length === 0 ? (
                <p className="py-2 text-center text-xs text-muted-foreground">
                  No chapters exist yet. Create chapters first.
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                  {chapters.map((c) => (
                    <label
                      key={c.id}
                      className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-background/60"
                    >
                      <Checkbox
                        checked={selectedChapters.includes(c.id)}
                        onCheckedChange={() => toggleChapter(c.id)}
                      />
                      <span className="truncate">{c.name}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
            {selectedChapters.length > 0 && (
              <p className="text-xs text-muted-foreground">
                💡 Questions will be linked to{' '}
                <strong>{selectedChapters.length}</strong> chapter
                {selectedChapters.length !== 1 ? 's' : ''} — same as the Create Question form.
              </p>
            )}
          </div>

          {/* ── Step 1b: Default Marks / Difficulty / Type (v3.53.8) ── */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold">
              2. Set default Marks / Level / Type
              <span className="ml-1.5 text-xs font-normal text-muted-foreground">
                (applied to all questions; file values override if present)
              </span>
            </Label>
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label htmlFor="def-marks" className="text-xs text-muted-foreground">Marks</Label>
                <Input
                  id="def-marks"
                  type="number"
                  min={1}
                  value={defaultMarks}
                  onChange={(e) => setDefaultMarks(Number(e.target.value))}
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="def-diff" className="text-xs text-muted-foreground">Level</Label>
                <Select value={defaultDifficulty} onValueChange={(v) => setDefaultDifficulty(v as QuestionLevel)}>
                  <SelectTrigger id="def-diff" className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {QUESTION_LEVELS.map((lvl) => (
                      <SelectItem key={lvl} value={lvl}>Level {lvl.replace('level-', '')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="def-type" className="text-xs text-muted-foreground">Type</Label>
                <Select value={defaultType} onValueChange={(v) => setDefaultType(v as typeof defaultType)}>
                  <SelectTrigger id="def-type" className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mcq">MCQ</SelectItem>
                    <SelectItem value="numerical">Numerical</SelectItem>
                    <SelectItem value="true-false">True / False</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* ── Step 2: File upload ── */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold">3. Upload your file (.docx / .pdf / .txt)</Label>
            <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border/60 bg-muted/20 px-4 py-6 text-center transition-colors hover:border-primary/40 hover:bg-muted/40">
              <input
                type="file"
                accept=".docx,.pdf,.txt"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) handleFileSelect(f)
                  e.target.value = '' // allow re-selecting the same file
                }}
              />
              {parsing ? (
                <>
                  <Loader2 className="mx-auto mb-2 h-6 w-6 animate-spin text-primary" />
                  <p className="text-sm font-medium">Parsing {fileName}…</p>
                </>
              ) : (
                <>
                  <FileUp className="mx-auto mb-2 h-6 w-6 text-muted-foreground" />
                  <p className="text-sm font-medium">
                    {fileName ? fileName : 'Click to upload or drag & drop'}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Supports .docx, .pdf, .txt · max ~5 MB
                  </p>
                </>
              )}
            </label>
            {parseError && (
              <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-2 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{parseError}</span>
              </div>
            )}
          </div>

          {/* ── Step 3: Preview parsed questions ── */}
          {rows.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">
                  4. Review parsed questions
                  <span className="ml-1.5 text-xs font-normal text-muted-foreground">
                    ({selectedCount} of {rows.length} selected · {skippedCount} skipped)
                  </span>
                </Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => setRows((prev) => prev.map((r) => ({ ...r, selected: true })))}
                  >
                    Select all
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => setRows((prev) => prev.map((r) => ({ ...r, selected: false })))}
                  >
                    Clear
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border max-h-64 overflow-y-auto">
                <ul className="divide-y">
                  {rows.map((r, idx) => (
                    <li key={idx} className={`p-3 ${r.selected ? 'bg-background' : 'bg-muted/30 opacity-60'}`}>
                      <div className="flex items-start gap-2">
                        <Checkbox
                          checked={r.selected}
                          onCheckedChange={() => toggleRow(idx)}
                          className="mt-1"
                        />
                        <div className="flex-1 min-w-0 space-y-1">
                          {r.editing ? (
                            /* ── Inline edit mode ── */
                            <div className="space-y-2">
                              <Input
                                value={r.text}
                                onChange={(e) => updateRowField(idx, 'text', e.target.value)}
                                className="text-sm"
                                placeholder="Question text"
                              />
                              {r.type !== 'numerical' && (
                                <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
                                  {r.options.map((opt, oi) => (
                                    <Input
                                      key={oi}
                                      value={opt}
                                      onChange={(e) => updateRowOption(idx, oi, e.target.value)}
                                      className="h-8 text-xs"
                                      placeholder={`Option ${String.fromCharCode(65 + oi)}`}
                                    />
                                  ))}
                                </div>
                              )}
                              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                                {r.type !== 'numerical' && (
                                  <Select
                                    value={String.fromCharCode(65 + r.correctAnswer)}
                                    onValueChange={(v) => updateRowField(idx, 'correctAnswer', v.charCodeAt(0) - 65)}
                                  >
                                    <SelectTrigger className="h-8 text-xs">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {r.options.map((_, oi) => (
                                        <SelectItem key={oi} value={String.fromCharCode(65 + oi)}>
                                          {String.fromCharCode(65 + oi)}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                )}
                                <Input
                                  type="number"
                                  value={r.marks ?? defaultMarks}
                                  onChange={(e) => updateRowField(idx, 'marks', Number(e.target.value))}
                                  className="h-8 text-xs"
                                  placeholder="Marks"
                                />
                                <Select
                                  value={r.difficulty ?? defaultDifficulty}
                                  onValueChange={(v) => updateRowField(idx, 'difficulty', v as QuestionLevel)}
                                >
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {QUESTION_LEVELS.map((lvl) => (
                                      <SelectItem key={lvl} value={lvl}>Level {lvl.replace('level-', '')}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <Select
                                  value={r.type ?? defaultType}
                                  onValueChange={(v) => updateRowField(idx, 'type', v)}
                                >
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="mcq">MCQ</SelectItem>
                                    <SelectItem value="numerical">Numerical</SelectItem>
                                    <SelectItem value="true-false">True/False</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <Textarea
                                value={r.explanation}
                                onChange={(e) => updateRowField(idx, 'explanation', e.target.value)}
                                className="text-xs"
                                rows={2}
                                placeholder="Explanation"
                              />
                              <div className="flex justify-end">
                                <Button size="sm" variant="ghost" className="h-7 text-xs text-emerald-600" onClick={() => saveEditRow(idx)}>
                                  <Check className="mr-1 h-3 w-3" /> Done
                                </Button>
                              </div>
                            </div>
                          ) : (
                            /* ── Read-only preview ── */
                            <>
                              <div className="flex items-start justify-between gap-2">
                                <p className="text-sm font-medium line-clamp-2">
                                  <span className="text-muted-foreground">#{idx + 1}.</span> {r.text || <span className="italic text-destructive">(no question text)</span>}
                                </p>
                                <div className="flex shrink-0 items-center gap-1">
                                  <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => startEditRow(idx)}>
                                    <Pencil className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                              {r.type !== 'numerical' && r.options.length > 0 && (
                                <p className="text-xs text-muted-foreground">
                                  {r.options.map((o, oi) => (
                                    <span key={oi} className={oi === r.correctAnswer ? 'font-semibold text-emerald-600' : ''}>
                                      {String.fromCharCode(65 + oi)}) {o || '—'}
                                      {oi < r.options.length - 1 ? '  ·  ' : ''}
                                    </span>
                                  ))}
                                </p>
                              )}
                              {r.explanation && (
                                <div className="mt-0.5 rounded bg-muted/40 px-2 py-1 text-xs italic text-muted-foreground">
                                  <span className="font-semibold not-italic">Solution:</span>{' '}
                                  <span className="whitespace-pre-wrap">{r.explanation}</span>
                                </div>
                              )}
                              <div className="flex flex-wrap items-center gap-1.5">
                                <Badge variant="outline" className="text-[10px] capitalize">{(r.type ?? defaultType).replace('-', ' ')}</Badge>
                                <Badge variant="outline" className="text-[10px] capitalize">{(r.difficulty ?? defaultDifficulty).replace('-', ' ')}</Badge>
                                <Badge variant="outline" className="text-[10px]">{r.marks ?? defaultMarks}m</Badge>
                                {r.warning ? (
                                  <Badge variant="outline" className="text-[10px] border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300">
                                    <AlertCircle className="mr-0.5 h-2.5 w-2.5" /> {r.warning}
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="text-[10px] border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                                    <CheckCircle2 className="mr-0.5 h-2.5 w-2.5" /> OK
                                  </Badge>
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* ── Format help ── */}
          {rows.length === 0 && !parsing && (
            <details className="rounded-lg border border-border/60 bg-muted/20 p-3 text-xs">
              <summary className="cursor-pointer font-semibold text-muted-foreground">
                📋 Expected file format (click to expand)
              </summary>
              <pre className="mt-2 overflow-x-auto whitespace-pre-wrap rounded bg-background p-2 text-[11px] leading-relaxed">{`Q: What is the value of 2 + 3?
A) 4
B) 5
C) 6
D) 7
Correct: B
Solution:
2 + 3 = 5.

Q: Is the square root of 16 equal to 4?
A) True
B) False
Correct: A
Solution: √16 = 4.`}</pre>
              <p className="mt-2 text-muted-foreground">
                • Use <strong>Solution:</strong> (or <strong>Explanation:</strong>) for the solution text — may span multiple lines<br />
                • <strong>Marks / Level / Type</strong> are optional in the file — set them in the popup above (step 2). If the file does include them, the file's values take priority.<br />
                • Blank line separates questions
              </p>
            </details>
          )}
        </div>

        <DialogFooter>
          <div className="mr-auto text-xs text-muted-foreground">
            {selectedCount > 0 && (
              <span>
                {selectedCount} question{selectedCount !== 1 ? 's' : ''} ready
                {skippedCount > 0 && ` · ${skippedCount} skipped`}
              </span>
            )}
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={selectedCount === 0 || selectedChapters.length === 0}
          >
            <Download className="mr-1.5 h-4 w-4 rotate-180" />
            Import {selectedCount > 0 ? selectedCount : ''} question{selectedCount !== 1 ? 's' : ''}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** Re-export the Upload icon so the parent Question Bank header can use it
 *  for the Import button without an extra import. */
export { Upload }
