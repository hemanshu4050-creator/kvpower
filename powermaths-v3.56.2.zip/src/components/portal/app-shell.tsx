'use client'

import * as React from 'react'
import { useAppStore } from '@/lib/store'
import { useDataStore } from '@/lib/data-store'
import { applyAccentTheme } from '@/lib/accent-theme'
import { Sidebar } from './sidebar'
import { Header } from './header'
import { CommandPalette } from './command-palette'
import { AdminRouter } from '@/components/admin/admin-router'
import { StudentRouter } from '@/components/student/student-router'
import { ChatWidget } from '@/components/shared/chat-widget'
import { cn } from '@/lib/utils'

const STATUS_COLORS: Record<string, string> = {
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  rose: 'bg-rose-500',
  zinc: 'bg-zinc-400',
}

export function AppShell() {
  const user = useAppStore((s) => s.user)
  const settings = useDataStore((s) => s.settings)

  // Keep the document title in sync with the brand name.
  React.useEffect(() => {
    if (typeof document !== 'undefined') {
      document.title = `${settings.headerTitle} — ${user?.role === 'admin' ? 'Admin Console' : 'Student Portal'}`
    }
  }, [settings.headerTitle, user?.role])

  // v3.36.0 — Apply the portal-wide accent (primary) color theme whenever the
  // setting changes. Overrides the :root / .dark CSS variables so every
  // bg-primary / text-primary / ring / btn-premium-primary element recolors.
  React.useEffect(() => {
    applyAccentTheme(settings.themeAccent)
  }, [settings.themeAccent])

  return (
    <div className="flex min-h-screen w-full bg-background">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header />
        <AnnouncementBar />
        <main className="flex-1 px-4 py-5 sm:px-6 sm:py-6">
          <div key={`${user?.role}-${user?.role === 'admin' ? useAppStore.getState().adminPage : useAppStore.getState().studentPage}`} className="animate-page-enter">
            {user?.role === 'admin' ? <AdminRouter /> : <StudentRouter />}
          </div>
        </main>
        <Footer
          copyright={settings.footerCopyright}
          status={settings.footerStatus}
          version={settings.footerVersion}
          statusColor={settings.footerStatusColor}
        />
      </div>
      <CommandPalette />
      {/* Friend chatbot — student mode only. Hidden during exams via the
          examInProgress flag in the app store. */}
      {user?.role === 'student' && <ChatWidget audience="student" />}
    </div>
  )
}

function AnnouncementBar() {
  const items = [
    '🎉 Trigonometry Chapter Test scheduled for Jan 20 — 10:00 AM',
    '📚 New Statistics & Probability chapter coming this month',
    '🔧 Scheduled maintenance on Jan 18, 2–4 AM IST',
  ]
  return (
    <div className="border-b border-border bg-primary/5 px-4 py-1.5 sm:px-6">
      <div className="flex items-center gap-3 overflow-hidden">
        <span className="hidden shrink-0 rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary sm:inline">
          Updates
        </span>
        <div className="relative flex-1 overflow-hidden">
          <div className="flex w-max animate-marquee gap-12 whitespace-nowrap text-xs text-muted-foreground">
            {[...items, ...items].map((t, i) => (
              <span key={i} className="flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-primary/50" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function Footer({
  copyright, status, version, statusColor,
}: {
  copyright: string
  status: string
  version: string
  statusColor: 'emerald' | 'amber' | 'rose' | 'zinc'
}) {
  return (
    <footer className="mt-auto border-t border-border bg-background/50 px-4 py-4 sm:px-6">
      <div className="flex flex-col items-center justify-between gap-2 text-xs text-muted-foreground sm:flex-row">
        <p>{copyright}</p>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className={cn('h-1.5 w-1.5 rounded-full pulse-dot', STATUS_COLORS[statusColor] || STATUS_COLORS.emerald)} />
            {status}
          </span>
          <span className="tabular-nums">{version}</span>
        </div>
      </div>
    </footer>
  )
}
