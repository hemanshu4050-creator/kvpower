'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Users, BookOpen, Library, FileText, Award,
  BarChart3, Megaphone, Activity, Settings, GraduationCap,
  ChevronLeft, ChevronRight, ChevronDown, LogOut, BookCheck,
  StickyNote, MessageSquare, User, PenTool, Hash, X,
  Mail, Layers, LineChart, BellRing, Images, type LucideIcon,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { useDataStore, type NavItemConfig } from '@/lib/data-store'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'

interface NavItem {
  id: string
  label: string
  icon: LucideIcon
  badge?: string | number
  badgeVariant?: 'default' | 'secondary' | 'destructive' | 'outline'
  section: string
  children?: { id: string; label: string; badge?: string | number }[]
}

// Canonical icon + section map for each nav id. The label / order / hidden
// state is owned by the data store, but the icon and section grouping stay
// fixed here so the sidebar always knows how to render each item.
//
// Badge COUNTS are no longer hardcoded here — they are computed live from the
// data store by `useNavBadges()` below, so the sidebar always reflects the
// real number of students / chapters / questions / exams etc. Only the
// badgeVariant (presentation) stays on the meta.
//
// v9 layout:
//   • `notifications` moved to the Insights section (so it groups with
//     Announcements when ordered right after it).
//   • `activity` (Activity Logs) moved to the System section so the SYSTEM
//     block contains exactly: Activity Logs · Email Log · Settings.
//   • `email-templates` removed — it's now embedded inside Settings → Email.
const ADMIN_ITEM_META: Record<string, { icon: LucideIcon; section: string; badgeVariant?: 'default' | 'secondary' | 'destructive' | 'outline'; children?: { id: string; label: string }[] }> = {
  dashboard:    { icon: LayoutDashboard, section: 'Overview' },
  activity:     { icon: Activity,        section: 'System' },
  students:     { icon: Users,           section: 'Manage',   badgeVariant: 'secondary' },
  chapters:     { icon: BookOpen,        section: 'Manage',   badgeVariant: 'secondary' },
  content: {
    icon: Library, section: 'Manage',
    children: [
      { id: 'questions', label: 'Question Bank' },
      { id: 'exams',     label: 'Exams' },
    ],
  },
  // `questions` + `exams` are also valid top-level ids (rendered via the
  // "content" submenu) — give them meta so they can still be found if the
  // admin reorders them out of the submenu.
  questions:       { icon: FileText,   section: 'Manage',   badgeVariant: 'secondary' },
  exams:           { icon: BookCheck,  section: 'Manage',   badgeVariant: 'secondary' },
  batches:         { icon: Layers,     section: 'Manage',   badgeVariant: 'secondary' },
  'student-reports': { icon: LineChart, section: 'Manage' },
  notifications:   { icon: BellRing,   section: 'Insights',  badgeVariant: 'destructive' },
  results:         { icon: FileText,   section: 'Manage',   badgeVariant: 'secondary' },
  certificates:    { icon: Award,      section: 'Manage',   badgeVariant: 'outline' },
  announcements:   { icon: Megaphone,  section: 'Insights', badgeVariant: 'secondary' },
  marketing:       { icon: Images,     section: 'Insights', badgeVariant: 'secondary' },
  'email-log':       { icon: Mail,      section: 'System', badgeVariant: 'secondary' },
  settings:     { icon: Settings,  section: 'System' },
}

const STUDENT_ITEM_META: Record<string, { icon: LucideIcon; section: string; badgeVariant?: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  dashboard:    { icon: LayoutDashboard, section: 'Overview' },
  levels:       { icon: Layers,    section: 'Learn',     badgeVariant: 'secondary' },
  chapters:     { icon: BookOpen,   section: 'Learn',     badgeVariant: 'secondary' },
  practice:     { icon: PenTool,    section: 'Learn' },
  exams:        { icon: BookCheck,  section: 'Learn',     badgeVariant: 'destructive' },
  results:      { icon: BarChart3,  section: 'Progress',  badgeVariant: 'secondary' },
  certificates: { icon: Award,      section: 'Progress',  badgeVariant: 'outline' },
  notifications: { icon: BellRing,  section: 'Personal',  badgeVariant: 'destructive' },
  notes:        { icon: StickyNote, section: 'Personal' },
  messages:     { icon: MessageSquare, section: 'Personal', badgeVariant: 'secondary' },
  profile:      { icon: User,       section: 'Personal' },
  settings:     { icon: Settings,   section: 'Personal' },
}

// ─────────────────────── Live badge counts ───────────────────────
// Computes the badge number for every nav item directly from the data store
// so the sidebar always reflects reality (e.g. adding a student updates the
// Students badge instantly). Admin sees global totals; students see counts
// scoped to their own record (their chapters, their exams, their unread
// notifications, etc.).
function useNavBadges(isAdmin: boolean, studentId?: string): Record<string, number> {
  const students = useDataStore((s) => s.students)
  const chapters = useDataStore((s) => s.chapters)
  const questions = useDataStore((s) => s.questions)
  const exams = useDataStore((s) => s.exams)
  const results = useDataStore((s) => s.results)
  const certificates = useDataStore((s) => s.certificates)
  const announcements = useDataStore((s) => s.announcements)
  const marketingCampaigns = useDataStore((s) => s.marketingCampaigns)
  const activityLogs = useDataStore((s) => s.activityLogs)
  const notifications = useDataStore((s) => s.notifications)
  const emailLogs = useDataStore((s) => s.emailLogs)
  const batches = useDataStore((s) => s.batches)
  const messages = useDataStore((s) => s.messages)

  return React.useMemo(() => {
    if (isAdmin) {
      // Admin badges — global totals across the whole portal.
      return {
        students: students.length,
        chapters: chapters.length,
        questions: questions.length,
        exams: exams.length,
        batches: batches.length,
        results: results.length,
        certificates: certificates.filter((c) => c.status === 'issued').length,
        announcements: announcements.filter((a) => a.status === 'active').length,
        marketing: marketingCampaigns.filter((c) => c.status === 'published').length,
        notifications: notifications.filter((n) => n.status === 'sent').length,
        'email-log': emailLogs.length,
        activity: activityLogs.length,
      } as Record<string, number>
    }
    // Student badges — scoped to this student's own record.
    const sid = studentId || ''
    const student = students.find((s) => s.id === sid)
    const assignedChapters = student?.assignedChapters ?? []
    // Exams available to this student: published exams whose chapter is in
    // the student's assigned chapter list.
    const myExams = exams.filter(
      (e) => e.status === 'published' && assignedChapters.includes(e.chapterId)
    ).length
    const myResults = results.filter((r) => r.studentId === sid).length
    const myCerts = certificates.filter(
      (c) => c.studentId === sid && c.status === 'issued'
    ).length
    // Unread notifications: sent to this student (or 'all') and not yet read.
    const myUnreadNotifs = notifications.filter((n) => {
      if (n.status !== 'sent') return false
      const targeted =
        n.audience === 'all' ||
        (n.audience === 'individual' && n.recipientIds.includes(sid)) ||
        (n.audience === 'multiple' && n.recipientIds.includes(sid)) ||
        (n.audience === 'batch' && n.recipientBatch === student?.batch)
      if (!targeted) return false
      return !n.readBy?.some((r) => r.studentId === sid)
    }).length
    const myUnreadMsgs = messages.filter(
      (m) => m.studentId === sid && m.direction === 'in' && !m.read
    ).length
    return {
      chapters: assignedChapters.length,
      exams: myExams,
      results: myResults,
      certificates: myCerts,
      notifications: myUnreadNotifs,
      messages: myUnreadMsgs,
    } as Record<string, number>
  }, [isAdmin, studentId, students, chapters, questions, exams, batches, results, certificates, announcements, marketingCampaigns, notifications, emailLogs, activityLogs, messages])
}

// Build a grouped nav structure from the stored ordered list. Items that are
// marked `hidden` are skipped. The stored order is the single source of truth:
// we walk the list top-to-bottom and start a new section group whenever the
// canonical section changes between two adjacent items. This means an item
// moved across sections (e.g. "Activity Logs" dragged below "Students")
// actually appears at that position in the sidebar — it is NOT silently
// regrouped back into its canonical section.
function buildNav(
  stored: NavItemConfig[],
  meta: typeof ADMIN_ITEM_META,
  badgeMap: Record<string, number>,
): { section: string; items: NavItem[] }[] {
  const visible = stored.filter((n) => !n.hidden)
  const groups: { section: string; items: NavItem[] }[] = []
  const seen = new Set<string>()
  let currentSection: string | null = null
  let currentItems: NavItem[] = []

  for (const entry of visible) {
    const m = meta[entry.id]
    if (!m) continue
    // De-duplicate (e.g. "questions" can appear both as a child of "content"
    // and as its own top-level id). Only the first occurrence is rendered.
    if (seen.has(entry.id)) continue
    seen.add(entry.id)

    const section = m.section
    if (section !== currentSection) {
      if (currentItems.length) groups.push({ section: currentSection!, items: currentItems })
      currentSection = section
      currentItems = []
    }
    // Attach the live badge count (if any) for this nav id. Zero counts are
    // hidden so the sidebar stays clean when there's nothing to show.
    const liveBadge = badgeMap[entry.id]
    currentItems.push({
      id: entry.id,
      label: entry.label,
      icon: m.icon,
      badge: liveBadge && liveBadge > 0 ? liveBadge : undefined,
      badgeVariant: m.badgeVariant,
      section,
      children: m.children?.map((c) => ({
        ...c,
        badge: badgeMap[c.id] && badgeMap[c.id] > 0 ? badgeMap[c.id] : undefined,
      })),
    })
  }
  if (currentItems.length) groups.push({ section: currentSection!, items: currentItems })
  return groups
}

const LOGO_ACCENTS: Record<string, string> = {
  emerald: 'bg-emerald-600 text-white',
  teal:    'bg-teal-600 text-white',
  green:   'bg-green-600 text-white',
  amber:   'bg-amber-500 text-white',
  violet:  'bg-violet-600 text-white',
  rose:    'bg-rose-600 text-white',
  zinc:    'bg-zinc-700 text-white',
}

export function Sidebar() {
  const {
    user, sidebarCollapsed, toggleSidebar,
    adminPage, setAdminPage, studentPage, setStudentPage,
    mobileSidebarOpen, setMobileSidebarOpen,
  } = useAppStore()
  const settings = useDataStore((s) => s.settings)

  const isAdmin = user?.role === 'admin'
  const storedNav = isAdmin ? settings.adminNav : settings.studentNav
  const meta = isAdmin ? ADMIN_ITEM_META : STUDENT_ITEM_META
  // Live badge counts pulled from the data store (students count, chapters
  // count, question bank count, etc.) so every menu item reflects reality.
  const badgeMap = useNavBadges(isAdmin, user?.id)
  const nav = React.useMemo(() => buildNav(storedNav, meta, badgeMap), [storedNav, meta, badgeMap])

  const currentPage = isAdmin ? adminPage : studentPage
  const setPage = isAdmin ? setAdminPage : setStudentPage

  const collapsed = sidebarCollapsed
  const [expanded, setExpanded] = React.useState<Record<string, boolean>>({ content: true })

  const handleNavigate = (id: string) => {
    setPage(id as never)
    setMobileSidebarOpen(false)
  }

  const logoAccentClass = LOGO_ACCENTS[settings.logoAccent] || LOGO_ACCENTS.emerald

  const BrandLogo = (
    <div className={cn(
      'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg shadow-sm overflow-hidden',
      settings.logoMode === 'image' && settings.logoImage ? 'bg-white ring-1 ring-black/5' : logoAccentClass,
    )}>
      {settings.logoMode === 'image' && settings.logoImage ? (
        // v3.31 — object-contain (not cover) so the circular Power Maths
        // badge logo renders whole inside the sidebar chip without being
        // cropped to a square.
        <img src={settings.logoImage} alt="Logo" className="h-full w-full object-contain" />
      ) : settings.logoMode === 'text' && settings.logoText ? (
        <span className="text-sm font-bold tracking-tight">{settings.logoText.slice(0, 3)}</span>
      ) : (
        <GraduationCap className="h-5 w-5" />
      )}
    </div>
  )

  const sidebarContent = (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className={cn(
        'flex h-16 items-center gap-2.5 border-b border-sidebar-border px-4',
        collapsed && 'justify-center px-2'
      )}>
        {BrandLogo}
        {!collapsed && (
          <div className="min-w-0 animate-fade-in">
            <p className="truncate text-sm font-semibold leading-tight">{settings.headerTitle}</p>
            <p className="truncate text-[11px] text-muted-foreground">
              {isAdmin ? 'Admin Console' : 'Student Portal'}
            </p>
          </div>
        )}
        {/* Mobile close */}
        <button
          onClick={() => setMobileSidebarOpen(false)}
          className="ml-auto rounded-md p-1.5 text-muted-foreground hover:bg-sidebar-accent lg:hidden"
          aria-label="Close menu"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Nav — scrolls independently. We use a plain overflow-y-auto div
          (not Radix ScrollArea) because `flex-1` on ScrollArea doesn't
          constrain its height in a flex column without `min-h-0`, which
          caused the bottom nav items to be unreachable on short screens. */}
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto scrollbar-thin px-2 py-3">
        <nav className="space-y-5">
          {nav.map((group) => (
            <div key={group.section}>
              {!collapsed && (
                <p className="px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                  {group.section}
                </p>
              )}
              {collapsed && <div className="mx-3 mb-1.5 border-t border-sidebar-border/60" />}
              <ul className="space-y-0.5">
                {group.items.map((item) => {
                  const isActive = currentPage === item.id
                  const hasChildren = !!item.children?.length
                  const isExpanded = expanded[item.id]
                  const isChildActive = item.children?.some((c) => c.id === currentPage)

                  const linkEl = (
                    <button
                      onClick={() => hasChildren ? setExpanded((p) => ({ ...p, [item.id]: !p[item.id] })) : handleNavigate(item.id)}
                      className={cn(
                        'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all',
                        collapsed && 'justify-center px-0',
                        isActive
                          ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm'
                          : isChildActive
                          ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                          : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                      )}
                    >
                      {isActive && !collapsed && <span className="nav-link-indicator" style={{ background: 'currentColor' }} />}
                      <item.icon className={cn('h-[18px] w-[18px] shrink-0', isActive && 'text-sidebar-primary-foreground')} />
                      {!collapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
                      {!collapsed && item.badge && (
                        <Badge variant={isActive ? 'secondary' : (item.badgeVariant || 'secondary')} className="h-5 px-1.5 text-[10px]">
                          {item.badge}
                        </Badge>
                      )}
                      {!collapsed && hasChildren && (
                        <ChevronDown className={cn('h-4 w-4 shrink-0 transition-transform', isExpanded && 'rotate-180')} />
                      )}
                    </button>
                  )

                  return (
                    <li key={item.id}>
                      {collapsed ? (
                        <TooltipProvider delayDuration={0}>
                          <Tooltip>
                            <TooltipTrigger asChild>{linkEl}</TooltipTrigger>
                            <TooltipContent side="right" className="font-medium">
                              {item.label}
                              {item.badge ? ` · ${item.badge}` : ''}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ) : (
                        linkEl
                      )}

                      {/* Submenu */}
                      {hasChildren && !collapsed && (
                        <AnimatePresence initial={false}>
                          {isExpanded && (
                            <motion.ul
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                              className="ml-6 mt-0.5 space-y-0.5 overflow-hidden border-l border-sidebar-border pl-3"
                            >
                              {item.children!.map((child) => {
                                const childActive = currentPage === child.id
                                return (
                                  <li key={child.id}>
                                    <button
                                      onClick={() => handleNavigate(child.id)}
                                      className={cn(
                                        'flex w-full items-center gap-2 rounded-md px-3 py-1.5 text-[13px] transition-colors',
                                        childActive
                                          ? 'bg-sidebar-accent font-medium text-sidebar-accent-foreground'
                                          : 'text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/60'
                                      )}
                                    >
                                      <Hash className="h-3 w-3 shrink-0 opacity-50" />
                                      <span className="flex-1 text-left truncate">{child.label}</span>
                                      {child.badge && (
                                        <span className="text-[10px] text-muted-foreground">{child.badge}</span>
                                      )}
                                    </button>
                                  </li>
                                )
                              })}
                            </motion.ul>
                          )}
                        </AnimatePresence>
                      )}
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
          {nav.length === 0 && (
            <div className="px-3 py-8 text-center text-xs text-muted-foreground">
              All menu items are hidden. Enable some in Settings → Navigation.
            </div>
          )}
        </nav>
      </div>

      {/* Footer: upgrade card + collapse */}
      {!collapsed && user?.role === 'student' && (
        <div className="px-3 pb-2">
          <div className="rounded-xl border border-sidebar-border bg-gradient-to-br from-sidebar-accent/80 to-sidebar-accent/40 p-3">
            <div className="flex items-center gap-2 mb-1.5">
              <Award className="h-4 w-4 text-primary" />
              <p className="text-xs font-semibold">Keep it up!</p>
            </div>
            <p className="text-[11px] text-muted-foreground mb-2">You're ranked #3 this week. Complete 1 more exam to reach top 2.</p>
            <div className="h-1.5 w-full rounded-full bg-sidebar-border overflow-hidden">
              <div className="h-full w-2/3 rounded-full bg-primary" />
            </div>
          </div>
        </div>
      )}

      <div className="border-t border-sidebar-border p-2">
        <button
          onClick={() => useAppStore.getState().logout()}
          className={cn(
            'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors',
            collapsed && 'justify-center px-0'
          )}
        >
          <LogOut className="h-[18px] w-[18px]" />
          {!collapsed && <span>Sign out</span>}
        </button>

        {/* Collapse toggle (desktop) */}
        <button
          onClick={toggleSidebar}
          className="mt-1 hidden w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground transition-colors lg:flex"
        >
          {collapsed ? <ChevronRight className="h-[18px] w-[18px]" /> : <ChevronLeft className="h-[18px] w-[18px]" />}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          'sidebar-transition sticky top-0 hidden h-screen shrink-0 border-r border-sidebar-border bg-sidebar lg:block',
          collapsed ? 'w-[72px]' : 'w-[256px]'
        )}
      >
        {sidebarContent}
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileSidebarOpen(false)}
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 260 }}
              className="fixed inset-y-0 left-0 z-50 w-[280px] border-r border-sidebar-border bg-sidebar lg:hidden"
            >
              {sidebarContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
