'use client'

import * as React from 'react'
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList, CommandSeparator, CommandShortcut,
} from '@/components/ui/command'
import {
  LayoutDashboard, Users, BookOpen, FileText, Award, BarChart3,
  Megaphone, Activity, Settings, Library, BookCheck, StickyNote,
  MessageSquare, User, PenTool, LogOut, GraduationCap, Layers,
  LineChart,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'

export function CommandPalette() {
  const { commandOpen, setCommandOpen, user, setAdminPage, setStudentPage, logout } = useAppStore()
  const isAdmin = user?.role === 'admin'

  const adminItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'chapters', label: 'Chapters', icon: BookOpen },
    { id: 'questions', label: 'Question Bank', icon: Library },
    { id: 'exams', label: 'Exams', icon: FileText },
    { id: 'batches', label: 'Levels Management', icon: Layers },
    { id: 'student-reports', label: 'Student Reports', icon: LineChart },
    { id: 'results', label: 'Results', icon: BarChart3 },
    { id: 'certificates', label: 'Certificates', icon: Award },
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'activity', label: 'Activity Logs', icon: Activity },
    { id: 'settings', label: 'Settings', icon: Settings },
  ]
  const studentItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'chapters', label: 'My Chapters', icon: BookOpen },
    { id: 'practice', label: 'Practice', icon: PenTool },
    { id: 'exams', label: 'Exams', icon: BookCheck },
    { id: 'results', label: 'Results', icon: BarChart3 },
    { id: 'certificates', label: 'Certificates', icon: Award },
    { id: 'notes', label: 'My Notes', icon: StickyNote },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ]
  const items = isAdmin ? adminItems : studentItems

  const go = (id: string) => {
    if (isAdmin) setAdminPage(id as never)
    else setStudentPage(id as never)
    setCommandOpen(false)
  }

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setCommandOpen(!commandOpen)
      }
    }
    document.addEventListener('keydown', down)
    return () => document.removeEventListener('keydown', down)
  }, [commandOpen, setCommandOpen])

  return (
    <CommandDialog open={commandOpen} onOpenChange={setCommandOpen}>
      <CommandInput placeholder="Search pages, actions..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Navigation">
          {items.map((it) => (
            <CommandItem key={it.id} onSelect={() => go(it.id)} className="capitalize">
              <it.icon className="mr-2 h-4 w-4" />
              {it.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Actions">
          <CommandItem onSelect={() => { toast.success('Export started', { description: 'You will be notified when ready.' }); setCommandOpen(false) }}>
            <FileText className="mr-2 h-4 w-4" />
            Export data
            <CommandShortcut>⌘E</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => { logout(); setCommandOpen(false) }}>
            <LogOut className="mr-2 h-4 w-4" />
            Sign out
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
