'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  GraduationCap, Mail, Lock, Eye, EyeOff, ArrowRight, ShieldCheck,
  BookOpen, Sparkles, TrendingUp, Users,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'
import { ChatWidget } from '@/components/shared/chat-widget'

export function LoginScreen() {
  const loginAs = useAppStore((s) => s.loginAs)
  const [role, setRole] = React.useState<'admin' | 'student'>('admin')
  const [email, setEmail] = React.useState('admin@powermaths.com')
  const [password, setPassword] = React.useState('powermaths')
  const [showPass, setShowPass] = React.useState(false)
  const [loading, setLoading] = React.useState(false)

  const selectRole = (r: 'admin' | 'student') => {
    setRole(r)
    if (r === 'admin') {
      setEmail('admin@powermaths.com')
    } else {
      setEmail('aarav.sharma@student.com')
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      loginAs(role)
      toast.success(`Welcome back!`, {
        description: `Signed in as ${role === 'admin' ? 'Administrator' : 'Student'}`,
      })
    }, 900)
  }

  return (
    <div className="min-h-screen w-full lg:grid lg:grid-cols-2">
      {/* ── Left brand panel ── */}
      <div className="relative hidden lg:flex flex-col justify-between overflow-hidden bg-mesh p-12 border-r border-border">
        <div className="absolute inset-0 bg-grid opacity-60" />
        <div className="relative z-10 flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white shadow-lg ring-1 ring-primary/10">
            <img
              src="/branding/power-maths-logo.png"
              alt="Power Maths logo"
              className="h-full w-full object-contain"
            />
          </div>
          <div>
            <p className="text-lg font-semibold tracking-tight">Power Maths</p>
            <p className="text-xs text-muted-foreground">by Prof. Kalpesh Vyas</p>
          </div>
        </div>

        <div className="relative z-10 max-w-md">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium text-primary mb-6">
              <Sparkles className="h-3.5 w-3.5" />
              Premium learning platform
            </div>
            <h1 className="text-4xl font-bold tracking-tight leading-tight">
              Master mathematics, <span className="text-gradient-brand">one chapter</span> at a time.
            </h1>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              A complete learning ecosystem with structured chapters, practice sheets,
              exams and verified certificates — built for serious learners.
            </p>
          </motion.div>

          <div className="mt-10 grid grid-cols-3 gap-4">
            {[
              { icon: Users, label: 'Students', value: '52+' },
              { icon: BookOpen, label: 'Chapters', value: '6' },
              { icon: TrendingUp, label: 'Pass rate', value: '82%' },
            ].map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 + i * 0.1 }}
                className="rounded-xl border border-border bg-card/60 p-4 backdrop-blur-sm"
              >
                <s.icon className="h-5 w-5 text-primary mb-2" />
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="relative z-10 text-xs text-muted-foreground">
          © 2026 Power Maths. Crafted for excellence.
        </div>
      </div>

      {/* ── Right form panel ── */}
      <div className="flex items-center justify-center p-6 sm:p-12">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-sm"
        >
          {/* Mobile brand */}
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-primary/10">
              <img
                src="/branding/power-maths-logo.png"
                alt="Power Maths logo"
                className="h-full w-full object-contain"
              />
            </div>
            <div>
              <p className="font-semibold">Power Maths</p>
              <p className="text-xs text-muted-foreground">by Prof. Kalpesh Vyas</p>
            </div>
          </div>

          <h2 className="text-2xl font-bold tracking-tight">Welcome back</h2>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Sign in to your account to continue learning.
          </p>

          {/* Role selector */}
          <div className="mt-6 grid grid-cols-2 gap-2 rounded-lg bg-muted p-1">
            {(['admin', 'student'] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => selectRole(r)}
                className={`relative rounded-md px-3 py-2 text-sm font-medium transition-all ${
                  role === r
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {r === 'admin' ? 'Administrator' : 'Student'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="pl-9"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button
                  type="button"
                  className="text-xs font-medium text-primary hover:underline"
                  onClick={() => toast.info('Password reset link sent to your email')}
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pl-9 pr-9"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPass ? 'Hide password' : 'Show password'}
                >
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox id="remember" defaultChecked />
              <Label htmlFor="remember" className="text-sm text-muted-foreground font-normal cursor-pointer">
                Keep me signed in for 30 days
              </Label>
            </div>

            <Button type="submit" className="w-full h-10" disabled={loading}>
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground" />
                  Signing in...
                </>
              ) : (
                <>
                  Sign in
                  <ArrowRight className="ml-1.5 h-4 w-4" />
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 flex items-center gap-2 rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 shrink-0 text-primary" />
            <span>
              Demo portal — credentials are pre-filled. Just pick a role and press
              <span className="font-medium text-foreground"> Sign in</span>.
            </span>
          </div>
        </motion.div>
      </div>
      {/* Friend chatbot — visitor mode (lead capture + WhatsApp handoff). */}
      <ChatWidget audience="visitor" />
    </div>
  )
}
