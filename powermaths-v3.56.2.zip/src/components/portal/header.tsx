'use client'

import * as React from 'react'
import {
  Search, Bell, Menu, Sun, Moon, Settings, ChevronRight,
  User, LogOut, UserCircle, CreditCard, Keyboard, HelpCircle,
  GraduationCap, Command, Maximize2, Minimize2, MoreHorizontal,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { useDataStore } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useTheme } from '@/components/portal/theme-provider'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuShortcut,
} from '@/components/ui/dropdown-menu'
import {
  Popover, PopoverContent, PopoverTrigger,
} from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'

const titleMap: Record<string, string> = {
  dashboard: 'Dashboard',
  students: 'Students',
  batches: 'Levels Management',
  chapters: 'Chapters',
  questions: 'Question Bank',
  exams: 'Exams',
  results: 'Results',
  certificates: 'Certificates',
  reports: 'Reports',
  'student-reports': 'Student Reports',
  notifications: 'Notifications',
  announcements: 'Announcements',
  activity: 'Activity Logs',
  'email-templates': 'Email Templates',
  'email-log': 'Email Log',
  settings: 'Settings',
  practice: 'Practice',
  notes: 'My Notes',
  messages: 'Messages',
  profile: 'Profile',
}

// Category → icon colour chip used in the bell dropdown. Mirrors the palette
// used on the full Notifications page so the dropdown feels like a preview.
const notifCategoryStyle: Record<string, { bg: string; label: string }> = {
  system:            { bg: 'bg-zinc-500/15 text-zinc-600 dark:text-zinc-300', label: 'System' },
  chapter_assigned:  { bg: 'bg-violet-500/15 text-violet-600 dark:text-violet-400', label: 'Chapter' },
  exam_available:    { bg: 'bg-sky-500/15 text-sky-600 dark:text-sky-400', label: 'Exam' },
  exam_result:       { bg: 'bg-amber-500/15 text-amber-600 dark:text-amber-400', label: 'Result' },
  certificate:       { bg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400', label: 'Certificate' },
  announcement:      { bg: 'bg-teal-500/15 text-teal-600 dark:text-teal-400', label: 'Announcement' },
  reminder:          { bg: 'bg-orange-500/15 text-orange-600 dark:text-orange-400', label: 'Reminder' },
  maintenance:       { bg: 'bg-rose-500/15 text-rose-600 dark:text-rose-400', label: 'Maintenance' },
  message:           { bg: 'bg-fuchsia-500/15 text-fuchsia-600 dark:text-fuchsia-400', label: 'Message' },
  general:           { bg: 'bg-primary/15 text-primary', label: 'General' },
}

// Relative time formatter ("2m", "1h", "3d") for the bell dropdown.
function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60_000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h`
  const d = Math.floor(h / 24)
  return `${d}d`
}

export function Header() {
  const {
    user, adminPage, studentPage, setAdminPage, setStudentPage,
    setMobileSidebarOpen, setCommandOpen,
  } = useAppStore()
  const { resolvedTheme, toggleTheme } = useTheme()
  // Look up the student record so we can show their uploaded photo.
  const studentPhoto = useDataStore((s) =>
    user?.role === 'student' ? s.students.find((st) => st.id === user.id)?.photo : undefined
  )
  // v3.33 — Admin profile photo from settings.
  const adminPhoto = useDataStore((s) =>
    user?.role === 'admin' ? s.settings.adminPhoto : undefined
  )
  const profilePhoto = user?.role === 'admin' ? adminPhoto : studentPhoto

  // ── Notifications (bell) ──
  // Pull the live notification list + actions from the data store. For
  // students we only surface notifications addressed to them (individual,
  // multiple, their batch, or all). Unread = not in the notification's
  // `readBy` ledger for this student. Admins see every sent notification.
  const allNotifications = useDataStore((s) => s.notifications)
  const markNotificationRead = useDataStore((s) => s.markNotificationRead)
  const markAllNotificationsRead = useDataStore((s) => s.markAllNotificationsRead)
  const studentBatch = useDataStore((s) =>
    user?.role === 'student' ? s.students.find((st) => st.id === user.id)?.batch : undefined
  )

  const visibleNotifications = React.useMemo(() => {
    const sent = allNotifications.filter((n) => n.status === 'sent')
    if (user?.role === 'admin') return sent
    if (!user) return []
    return sent.filter((n) => {
      if (n.audience === 'all') return true
      if (n.audience === 'batch') return n.recipientBatch === studentBatch
      return n.recipientIds.includes(user.id)
    })
  }, [allNotifications, user, studentBatch])

  const unreadNotifications = React.useMemo(
    () => visibleNotifications.filter((n) => !n.readBy.some((r) => r.studentId === user?.id)),
    [visibleNotifications, user]
  )
  const recentNotifications = React.useMemo(
    () => [...visibleNotifications].sort((a, b) => new Date(b.sentAt ?? b.createdAt).getTime() - new Date(a.sentAt ?? a.createdAt).getTime()).slice(0, 6),
    [visibleNotifications]
  )
  const unreadCount = unreadNotifications.length

  const goToNotifications = React.useCallback(() => {
    if (user?.role === 'admin') setAdminPage('notifications')
    else setStudentPage('notifications')
  }, [user, setAdminPage, setStudentPage])

  const handleMarkAllRead = React.useCallback(() => {
    if (!user) return
    markAllNotificationsRead(user.id)
  }, [user, markAllNotificationsRead])

  const handleOpenNotif = React.useCallback((id: string) => {
    if (!user) return
    markNotificationRead(id, user.id)
  }, [user, markNotificationRead])

  const currentPage = user?.role === 'admin' ? adminPage : studentPage
  // v3.38.0 — resolve the header title from the nav config so it follows
  // any renames the admin makes in Settings → Navigation. Falls back to the
  // static titleMap (then 'Dashboard') if the nav item is somehow missing.
  const role: 'admin' | 'student' = user?.role === 'admin' ? 'admin' : 'student'
  const pageTitle = useNavLabel(currentPage, titleMap[currentPage] || 'Dashboard', role)

  const initials = user?.name
    ?.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase() || 'U'

  // ── Fullscreen toggle ──
  // Tracks whether the browser is in fullscreen mode and toggles it via the
  // Fullscreen API. Works on all modern browsers (Chrome/Firefox/Safari/Edge).
  const [isFullscreen, setIsFullscreen] = React.useState(false)

  React.useEffect(() => {
    const onChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement))
    }
    document.addEventListener('fullscreenchange', onChange)
    document.addEventListener('webkitfullscreenchange', onChange as EventListener)
    return () => {
      document.removeEventListener('fullscreenchange', onChange)
      document.removeEventListener('webkitfullscreenchange', onChange as EventListener)
    }
  }, [])

  const toggleFullscreen = React.useCallback(() => {
    const doc = document as Document & {
      webkitFullscreenElement?: Element | null
      webkitExitFullscreen?: () => void
    }
    const el = document.documentElement as HTMLElement & {
      webkitRequestFullscreen?: () => Promise<void>
    }
    const inFs = Boolean(doc.fullscreenElement || doc.webkitFullscreenElement)
    if (!inFs) {
      if (el.requestFullscreen) el.requestFullscreen()
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen()
    } else {
      if (doc.exitFullscreen) doc.exitFullscreen()
      else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen()
    }
  }, [])

  const goToSettings = () => {
    if (user?.role === 'admin') setAdminPage('settings')
    else setStudentPage('settings')
  }

  // v3.49.0 — Profile navigation. Students have a dedicated Profile page;
  // admins don't (they manage their info under Settings), so for admins the
  // Profile menu item routes to Settings where the profile/branding fields
  // live. Previously this item had NO handler, so clicking it did nothing.
  const goToProfile = () => {
    if (user?.role === 'admin') setAdminPage('settings')
    else setStudentPage('profile')
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-1.5 border-b border-border bg-background/80 glass-header px-3 sm:gap-2 sm:px-6">
      {/* Mobile menu — 44px tap target */}
      <button
        onClick={() => setMobileSidebarOpen(true)}
        className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted lg:hidden"
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Breadcrumb / title — flex-1 with min-w-0 so it shrinks before buttons */}
      <div className="min-w-0 flex-1">
        <div className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex">
          <span className="capitalize">{user?.role === 'admin' ? 'Admin' : 'Student'}</span>
          <ChevronRight className="h-3 w-3" />
          <span className="font-medium text-foreground">{pageTitle}</span>
        </div>
        {/* v3.53.1 — title uses text-xs on mobile (was text-base) and
            scales up at sm/md so longer titles like "Question Bank" /
            "Levels Management" fit without heavy truncation at 375px. */}
        <h1 className="truncate text-xs font-semibold tracking-tight sm:text-base md:text-lg">{pageTitle}</h1>
      </div>

      {/* Search (desktop) — hidden below md, wider on lg */}
      <button
        onClick={() => setCommandOpen(true)}
        className="hidden md:flex h-10 w-48 items-center gap-2 rounded-lg border border-border bg-muted/40 px-3 text-sm text-muted-foreground transition-colors hover:bg-muted lg:w-72"
      >
        <Search className="h-4 w-4" />
        <span className="flex-1 text-left">Search...</span>
        <kbd className="flex h-5 items-center gap-0.5 rounded border border-border bg-background px-1 text-[10px] font-medium">
          <Command className="h-2.5 w-2.5" />K
        </kbd>
      </button>

      {/* Search (mobile) — v3.53.1 hidden on smallest screens to give the
          page title more room. Search is still reachable via the ⌘K command
          palette (which works on every viewport) and via the sidebar. */}
      <button
        onClick={() => setCommandOpen(true)}
        className="hidden h-11 w-11 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted sm:inline-flex md:hidden"
        aria-label="Search"
      >
        <Search className="h-5 w-5" />
      </button>

      {/* Theme toggle — 44px tap target (was 36px) */}
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleTheme}
        className="h-11 w-11 shrink-0"
        aria-label="Toggle theme"
      >
        {resolvedTheme === 'dark' ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
      </Button>

      {/* Notifications — 44px tap target (was 36px) */}
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="icon" className="relative h-11 w-11 shrink-0" aria-label="Notifications">
            <Bell className="h-[18px] w-[18px]" />
            {unreadCount > 0 && (
              <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground shadow-sm">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="end">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold">Notifications</p>
              {unreadCount > 0 && (
                <Badge variant="destructive" className="text-[10px]">{unreadCount} new</Badge>
              )}
            </div>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-[11px] font-medium text-primary hover:underline"
              >
                Mark all read
              </button>
            )}
          </div>
          <ScrollArea className="h-80">
            {recentNotifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center px-4 py-10 text-center">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Bell className="h-5 w-5" />
                </div>
                <p className="mt-3 text-sm font-medium">All caught up</p>
                <p className="mt-0.5 text-xs text-muted-foreground">No notifications right now.</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {recentNotifications.map((n) => {
                  const isUnread = !n.readBy.some((r) => r.studentId === user?.id)
                  const style = notifCategoryStyle[n.category] ?? notifCategoryStyle.general
                  return (
                    <button
                      key={n.id}
                      onClick={() => handleOpenNotif(n.id)}
                      className={cn(
                        'flex w-full gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/50',
                        isUnread && 'bg-primary/5'
                      )}
                    >
                      <div className={cn('mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full', style.bg)}>
                        <Bell className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-medium leading-tight">{n.title}</p>
                          {isUnread && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />}
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{n.description}</p>
                        <div className="mt-1 flex items-center gap-1.5">
                          <span className="text-[11px] text-muted-foreground/70">{relativeTime(n.sentAt ?? n.createdAt)} ago</span>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-[11px] text-muted-foreground/70">{style.label}</span>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            )}
          </ScrollArea>
          <div className="border-t border-border p-2">
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs"
              onClick={goToNotifications}
            >
              View all notifications
            </Button>
          </div>
        </PopoverContent>
      </Popover>

      {/* v3.53.1 — Fullscreen + Settings moved into a "more" overflow menu
          on mobile/tablet to free up horizontal space for the page title.
          Desktop (lg+) keeps them as direct icon buttons (44px tap targets). */}
      <div className="hidden lg:contents">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleFullscreen}
          className="h-11 w-11 shrink-0 transition-transform hover:scale-105"
          aria-label={isFullscreen ? 'Exit full screen' : 'Enter full screen'}
          title={isFullscreen ? 'Exit full screen' : 'Enter full screen'}
        >
          {isFullscreen ? (
            <Minimize2 className="h-[18px] w-[18px]" />
          ) : (
            <Maximize2 className="h-[18px] w-[18px]" />
          )}
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={goToSettings}
          className="h-11 w-11 shrink-0"
          aria-label="Settings"
          title="System settings"
        >
          <Settings className="h-[18px] w-[18px]" />
        </Button>
      </div>

      {/* Mobile/tablet overflow menu — surfaces Fullscreen + Settings so the
          actions are still reachable without crowding the header. */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="h-11 w-11 shrink-0 lg:hidden"
            aria-label="More actions"
          >
            <MoreHorizontal className="h-5 w-5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-52">
          <DropdownMenuItem onClick={toggleFullscreen}>
            {isFullscreen ? (
              <Minimize2 className="mr-2 h-4 w-4" />
            ) : (
              <Maximize2 className="mr-2 h-4 w-4" />
            )}
            {isFullscreen ? 'Exit full screen' : 'Enter full screen'}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={goToSettings}>
            <Settings className="mr-2 h-4 w-4" /> Settings
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Profile dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 rounded-lg p-1 pr-2 transition-colors hover:bg-muted">
            <Avatar className="h-8 w-8 border border-border">
              {profilePhoto ? <AvatarImage src={profilePhoto} alt={user?.name ?? 'User'} /> : null}
              <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="hidden text-left sm:block">
              <p className="max-w-[140px] truncate text-xs font-semibold leading-tight">{user?.name}</p>
              <p className="text-[11px] text-muted-foreground capitalize">{user?.role}</p>
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuLabel>
            <div className="flex flex-col gap-0.5">
              <p className="text-sm font-semibold">{user?.name}</p>
              <p className="truncate text-xs font-normal text-muted-foreground">{user?.email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={goToProfile}>
            <UserCircle className="mr-2 h-4 w-4" /> Profile
          </DropdownMenuItem>
          <DropdownMenuItem onClick={goToSettings}>
            <CreditCard className="mr-2 h-4 w-4" /> Billing
            <DropdownMenuShortcut>⌘B</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={goToSettings}>
            <Settings className="mr-2 h-4 w-4" /> Settings
            <DropdownMenuShortcut>⌘,</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setCommandOpen(true)}>
            <Keyboard className="mr-2 h-4 w-4" /> Keyboard shortcuts
            <DropdownMenuShortcut>⌘K</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={goToSettings}>
            <HelpCircle className="mr-2 h-4 w-4" /> Help & support
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="text-destructive focus:text-destructive"
            onClick={() => useAppStore.getState().logout()}
          >
            <LogOut className="mr-2 h-4 w-4" /> Sign out
            <DropdownMenuShortcut>⇧⌘Q</DropdownMenuShortcut>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
