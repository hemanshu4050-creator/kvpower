'use client'

/**
 * DrmContent — a lightweight DRM wrapper for non-PDF learning content
 * (Formula cards, Theory textbook).
 *
 * Protections (mirrors SecurePdfViewer where applicable):
 *   • Right-click context menu disabled
 *   • Text selection disabled (user-select: none + onselectstart)
 *   • Copy / Cut disabled
 *   • Drag-start disabled
 *   • PrintScreen keyup → clipboard wiped (best-effort)
 *   • Ctrl+P / Ctrl+S / Ctrl+U blocked
 *   • Optional sticky watermark (student name + ID) at the bottom
 *
 * Unlike SecurePdfViewer this is NOT a modal — it renders inline so it
 * can be embedded inside tab panels.
 */

import * as React from 'react'
import { cn } from '@/lib/utils'

interface DrmContentProps {
  children: React.ReactNode
  className?: string
  /** Optional watermark text shown in a sticky footer banner. */
  watermark?: string
  /** Called when a DRM violation is detected (e.g. PrintScreen). */
  onViolation?: (type: string) => void
}

export function DrmContent({ children, className, watermark, onViolation }: DrmContentProps) {
  const ref = React.useRef<HTMLDivElement>(null)

  // Block keyboard shortcuts that could be used to copy / save / print.
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase()
      const ctrl = e.ctrlKey || e.metaKey
      if (ctrl && ['c', 'x', 'a', 'p', 's', 'u'].includes(k)) {
        e.preventDefault()
        onViolation?.(`ctrl+${k}`)
      }
      if (ctrl && e.shiftKey && ['c', 'i', 'j'].includes(k)) {
        e.preventDefault()
        onViolation?.(`ctrl+shift+${k}`)
      }
      if (k === 'printscreen') {
        // Best-effort: wipe the clipboard.
        try { navigator.clipboard?.writeText('') } catch { /* ignore */ }
        onViolation?.('printscreen')
      }
    }
    window.addEventListener('keydown', handler, { capture: true })
    return () => window.removeEventListener('keydown', handler, { capture: true })
  }, [onViolation])

  // `selectstart` is a native DOM event that React does not surface as a
  // synthetic prop (using `onSelectStart` triggers an "Unknown event handler
  // property" warning). Attach it imperatively on the container element.
  React.useEffect(() => {
    const el = ref.current
    if (!el) return
    const block = (e: Event) => e.preventDefault()
    el.addEventListener('selectstart', block)
    return () => el.removeEventListener('selectstart', block)
  }, [])

  return (
    <div
      ref={ref}
      className={cn('relative select-none', className)}
      style={{
        WebkitUserSelect: 'none',
        WebkitTouchCallout: 'none',
      }}
      onContextMenu={(e) => e.preventDefault()}
      onCopy={(e) => e.preventDefault()}
      onCut={(e) => e.preventDefault()}
      onDragStart={(e) => e.preventDefault()}
    >
      {children}
      {watermark && (
        <div
          className="pointer-events-none sticky bottom-0 z-20 -mx-4 -mb-4 mt-4 flex items-center justify-center gap-2 border-t border-foreground/10 bg-foreground/[0.03] px-4 py-2 sm:-mx-8 sm:px-8"
          aria-hidden
        >
          <span className="select-none text-[11px] font-medium tracking-wider text-foreground/45">
            {watermark}
          </span>
        </div>
      )}
    </div>
  )
}
