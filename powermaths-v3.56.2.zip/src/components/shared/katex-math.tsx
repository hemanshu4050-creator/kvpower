'use client'

/**
 * KaTeX math renderer.
 *
 * Renders a single LaTeX expression (no `$...$` delimiters needed) using
 * KaTeX. Used by both the admin formula editor (live preview) and the
 * student formula cards.
 *
 * Errors are rendered as a small red box showing the LaTeX source so the
 * admin can spot typos immediately — never crashes the page.
 */

import * as React from 'react'
import katex from 'katex'
// KaTeX CSS is loaded globally via the layout (see src/app/layout.tsx) to
// avoid per-component CSS imports that bloat the Turbopack compile graph.

interface KatexMathProps {
  /** LaTeX source (without surrounding $...$). */
  expression: string
  /** Display mode (block) vs inline. Defaults to display. */
  display?: boolean
  className?: string
}

export function KatexMath({ expression, display = true, className }: KatexMathProps) {
  const html = React.useMemo(() => {
    try {
      return katex.renderToString(expression || '', {
        displayMode: display,
        throwOnError: false,
        errorColor: '#dc2626',
        strict: false,
        trust: false,
        output: 'html',
      })
    } catch {
      return `<span style="color:#dc2626">${escapeHtml(expression || '')}</span>`
    }
  }, [expression, display])

  return (
    <span
      className={className}
      // KaTeX output is sanitised by the library itself (no user HTML is
      // interpolated); `output: 'html'` + `trust: false` is the safe mode.
      dangerouslySetInnerHTML={{ __html: html }}
    />
  )
}

/**
 * Render a markdown-ish string that may contain inline math (`$...$`) and
 * display math (`$$...$$`) as React nodes. Plain text segments are
 * returned as-is; math segments are rendered with <KatexMath>.
 *
 * Used by the theory viewer to render paragraphs, list items, etc. that
 * mix prose with formulas.
 */
export function renderInlineMath(text: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = []
  // Split on $$...$$ first (display), then $...$ (inline).
  const displayParts = text.split(/\$\$([^$]+)\$\$/g)
  displayParts.forEach((part, idx) => {
    if (idx % 2 === 1) {
      // Display math segment.
      nodes.push(<KatexMath key={`d${idx}`} expression={part} display />)
      return
    }
    // Within the non-display segment, split on $...$ for inline math.
    const inlineParts = part.split(/\$([^$]+)\$/g)
    inlineParts.forEach((ip, iidx) => {
      if (iidx % 2 === 1) {
        nodes.push(<KatexMath key={`i${idx}-${iidx}`} expression={ip} display={false} />)
      } else if (ip) {
        nodes.push(<React.Fragment key={`t${idx}-${iidx}`}>{ip}</React.Fragment>)
      }
    })
  })
  return nodes
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}
