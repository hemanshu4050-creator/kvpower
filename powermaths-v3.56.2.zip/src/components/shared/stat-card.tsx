'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'
import { ArrowDownRight, ArrowUpRight, type LucideIcon } from 'lucide-react'

interface StatCardProps {
  title: string
  value: React.ReactNode
  icon: LucideIcon
  trend?: { value: string; positive: boolean }
  accent?: 'emerald' | 'blue' | 'amber' | 'rose' | 'violet' | 'teal'
  subtitle?: string
  delay?: number
}

const accentMap = {
  emerald: {
    bg: 'bg-gradient-to-br from-emerald-500/15 to-emerald-500/5',
    text: 'text-emerald-600 dark:text-emerald-400',
    ring: 'ring-emerald-500/20',
    glow: 'oklch(0.62 0.13 160 / 0.14)',
  },
  blue: {
    bg: 'bg-gradient-to-br from-sky-500/15 to-sky-500/5',
    text: 'text-sky-600 dark:text-sky-400',
    ring: 'ring-sky-500/20',
    glow: 'oklch(0.6 0.1 230 / 0.14)',
  },
  amber: {
    bg: 'bg-gradient-to-br from-amber-500/15 to-amber-500/5',
    text: 'text-amber-600 dark:text-amber-400',
    ring: 'ring-amber-500/20',
    glow: 'oklch(0.72 0.16 70 / 0.14)',
  },
  rose: {
    bg: 'bg-gradient-to-br from-rose-500/15 to-rose-500/5',
    text: 'text-rose-600 dark:text-rose-400',
    ring: 'ring-rose-500/20',
    glow: 'oklch(0.62 0.2 20 / 0.14)',
  },
  violet: {
    bg: 'bg-gradient-to-br from-violet-500/15 to-violet-500/5',
    text: 'text-violet-600 dark:text-violet-400',
    ring: 'ring-violet-500/20',
    glow: 'oklch(0.6 0.18 300 / 0.14)',
  },
  teal: {
    bg: 'bg-gradient-to-br from-teal-500/15 to-teal-500/5',
    text: 'text-teal-600 dark:text-teal-400',
    ring: 'ring-teal-500/20',
    glow: 'oklch(0.62 0.14 180 / 0.14)',
  },
}

/**
 * StatCard — compact premium metric card with PERFECT EQUAL HEIGHT + VALUE
 * ALIGNMENT guarantee.
 *
 * v3.24.0 changes (vs v3.23.0):
 *  • SLOT COLLAPSE: subtitle + trend slots no longer reserve min-height when
 *    empty. Cards without subtitle/trend are ~74px (was 160px). Homogeneous
 *    rows stay equal-height; the title min-h still guarantees value-Y align.
 *
 * Design contract (v3.24.0 — slot-collapse + title-wrap alignment):
 *  ┌─────────────────────────────────────────────┐
 *  │  TITLE (1 or 2 lines,        [ICON h-8×8]   │  ← top row (shrink-0)
 *  │   always reserves 2 lines)                  │     min-h-[1.625rem] on title
 *  │  VALUE (20px bold)             ← always at   │     → value Y is identical
 *  │  subtitle (only if provided)                 │     on every card
 *  │       (flex-1 spacer — absorbs height diff)  │
 *  │  ↑ trend · vs last week (only if provided)  │  ← bottom row (mt-auto)
 *  └─────────────────────────────────────────────┘
 *
 * v3.22.0 changes (vs v3.21.0):
 *  • Compact sizing: p-4 (was p-5), value 22px (was 28px), icon container
 *    h-9×9 rounded-lg (was h-10×10 rounded-xl), icon h-4×4 (was 18px).
 *  • TITLE-WRAP ALIGNMENT FIX: the title <p> now has `line-clamp-2` +
 *    `leading-tight` + `min-h-[1.75rem]`. This reserves exactly 2 lines
 *    of vertical space (11px × 1.25 × 2 = 27.5px ≈ 1.75rem) for EVERY
 *    card's title, whether the title is 1 line ("Certificates") or 2 lines
 *    ("Total Exams"). The value below therefore starts at the exact same
 *    Y coordinate on every card in a row — fixing the "big number
 *    misalignment when labels wrap" bug.
 *
 * Hard guarantees:
 *  • Equal width          — grid cell (grid-cols-N)
 *  • Equal height         — h-full + flex flex-col + reserved slots
 *  • Equal padding        — p-3 (fixed)
 *  • Equal border radius  — rounded-xl (fixed)
 *  • Equal icon size      — h-3.5 w-3.5 (fixed)
 *  • Equal icon container — h-8 w-8 rounded-lg ring-1 (fixed)
 *  • Equal typography     — title 11px / value 20px / subtitle 12px / trend 11px
 *  • Equal vertical align — flexbox column with reserved min-heights (title 2 lines + subtitle + trend)
 *  • Equal horizontal align— justify-between (title left, icon right)
 *  • Equal shadow         — stat-card-premium (shared CSS class)
 *  • Equal bottom section — trend pinned with mt-auto + min-h
 *  • Equal spacing        — gap-4 on the grid wrapper (standardised)
 *  • VALUE ALIGNMENT      — title min-h-[1.75rem] guarantees value Y is identical
 */
export function StatCard({ title, value, icon: Icon, trend, accent = 'emerald', subtitle, delay = 0 }: StatCardProps) {
  const a = accentMap[accent]
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: [0.16, 1, 0.3, 1] }}
      style={{ ['--stat-glow' as string]: a.glow }}
      className="h-full"
    >
      <Card className="stat-card-premium relative flex h-full flex-col overflow-hidden rounded-xl p-3">
        {/* ── Top section: title + value (left) · icon (right) ── */}
        <div className="relative flex items-start justify-between gap-2">
          <div className="min-w-0">
            {/* Title: line-clamp-2 + min-h-[1.625rem] guarantees the value
                below starts at the SAME Y on every card, whether the title
                is 1 line ("Certificates") or 2 lines ("Total Exams"). */}
            <p className="line-clamp-2 min-h-[1.625rem] text-[11px] font-semibold uppercase leading-[1.2] tracking-wide text-muted-foreground">
              {title}
            </p>
            <p className="num-premium mt-0.5 text-[20px] font-bold leading-none tracking-tight">
              {value}
            </p>
          </div>
          <div
            className={cn(
              'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ring-1',
              a.bg,
              a.text,
              a.ring
            )}
          >
            <Icon className="h-3.5 w-3.5" />
          </div>
        </div>

        {/* ── Subtitle slot — ONLY rendered when a subtitle is provided.
             No reserved min-height, so cards without subtitles are shorter. ── */}
        {subtitle ? (
          <p className="mt-1 text-xs leading-tight text-muted-foreground">{subtitle}</p>
        ) : null}

        {/* ── Bottom section: trend — ONLY rendered when a trend is provided.
             Pinned to the bottom with mt-auto; no reserved min-height. ── */}
        {trend ? (
          <div className="mt-auto flex items-center gap-1.5 pt-2">
            <span
              className={cn(
                'inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[11px] font-semibold',
                trend.positive
                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                  : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
              )}
            >
              {trend.positive ? (
                <ArrowUpRight className="h-3 w-3" />
              ) : (
                <ArrowDownRight className="h-3 w-3" />
              )}
              {trend.value}
            </span>
            <span className="text-[11px] text-muted-foreground">vs last week</span>
          </div>
        ) : null}
      </Card>
    </motion.div>
  )
}
