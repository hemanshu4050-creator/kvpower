'use client'

/**
 * Friend — the Power Maths chatbot (non-AI, rule-based).
 *
 * Two modes:
 *   • visitor  — shown on the login screen, captures WhatsApp leads.
 *   • student  — shown inside the app shell, helps with navigation, hints,
 *                formula lookup and progress.
 *
 * The widget HIDES itself when `examInProgress` is true in the app store
 * (so it never appears during a proctored exam).
 */

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, X, Send, Sparkles, Lightbulb } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store'
import {
  createSession,
  processInput,
  type ChatSessionState,
  type ChatMessage,
  type ChatAudience,
} from '@/lib/chat-engine'
import { WHATSAPP_DISPLAY } from '@/lib/chat-data'

interface ChatWidgetProps {
  audience: ChatAudience
}

export function ChatWidget({ audience }: ChatWidgetProps) {
  const examInProgress = useAppStore((s) => s.examInProgress)
  const [open, setOpen] = React.useState(false)
  const [session, setSession] = React.useState<ChatSessionState | null>(null)
  const [input, setInput] = React.useState('')
  const [typing, setTyping] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)
  const typingTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  // Keep a ref to the latest session so the timeout closure sees updates.
  const sessionRef = React.useRef(session)
  // Monotonic counter appended to Date.now()-based message ids so two messages
  // created in the same millisecond (e.g. user + bot in a fast typed exchange)
  // never collide and trigger React "duplicate key" warnings.
  const idCounter = React.useRef(0)

  // Lazy-init session on first open (and reset when audience changes).
  React.useEffect(() => {
    if (open && !session) {
      setSession(createSession(audience))
    }
  }, [open, session, audience])

  React.useEffect(() => {
    sessionRef.current = session
  }, [session])

  // Auto-scroll to bottom on new message.
  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [session?.messages, typing])

  // Clean up typing timer on unmount.
  React.useEffect(() => {
    return () => {
      if (typingTimer.current) clearTimeout(typingTimer.current)
    }
  }, [])

  const handleSend = (rawInput?: string, action?: string) => {
    if (!session) return
    const text = (rawInput ?? input).trim()
    if (!text && !action) return

    // Append user message (for free text only — chip clicks don't echo user text).
    // The id is `u${ts}-${counter}` so two user messages sent in the same
    // millisecond never share a React key.
    const userMsg: ChatMessage | null = text
      ? { id: `u${Date.now()}-${++idCounter.current}`, role: 'user', text, at: Date.now() }
      : null
    const baseMessages = userMsg ? [...session.messages, userMsg] : session.messages

    // Capture the user message id we just added so the timeout closure can
    // detect whether it is still present in the latest session (it should be,
    // but if the session was reset mid-typing — e.g. audience changed — we
    // must not re-append a duplicate).
    const userMsgId = userMsg?.id ?? null
    setSession({ ...session, messages: baseMessages })
    if (!action) setInput('')
    setTyping(true)

    // Simulate "Friend is typing…" for a natural feel.
    if (typingTimer.current) clearTimeout(typingTimer.current)
    typingTimer.current = setTimeout(() => {
      const current = sessionRef.current
      if (!current) {
        setTyping(false)
        return
      }
      const response = processInput(current, { userInput: text || undefined, action })
      const botMsg: ChatMessage = {
        id: `b${Date.now()}-${++idCounter.current}`,
        role: 'bot',
        text: response.botText,
        quickReplies: response.quickReplies,
        action: response.actionPayload,
        at: Date.now(),
      }
      // `current.messages` already contains `userMsg` (we appended it
      // synchronously above). Only re-append `userMsg` if it is somehow
      // missing — this guards against a stale closure re-introducing a
      // duplicate React key (the original v3.27 bug).
      const stillMissingUserMsg =
        userMsgId != null && !current.messages.some((m) => m.id === userMsgId)
      setSession({
        ...current,
        ...response.statePatch,
        messages: [
          ...current.messages,
          ...(stillMissingUserMsg && userMsg ? [userMsg] : []),
          botMsg,
        ],
      })
      setTyping(false)

      // Execute side-effects (open WhatsApp, navigate, etc.)
      if (response.actionPayload) {
        executeAction(response.actionPayload)
      }
    }, 450 + Math.random() * 500)
  }

  const executeAction = (payload: NonNullable<ChatMessage['action']>) => {
    if (payload.type === 'handoff' && payload.url) {
      window.open(payload.url, '_blank', 'noopener,noreferrer')
    } else if (payload.type === 'nav') {
      handleNavigation(payload.target)
    }
  }

  const handleNavigation = (target?: string) => {
    if (!target) return
    const map: Record<string, string> = {
      demo: 'demo',
      dashboard: 'dashboard',
      practice: 'practice',
      chapters: 'chapters',
      exams: 'exams',
      results: 'results',
      certificates: 'certificates',
      notes: 'notes',
      messages: 'messages',
      notifications: 'notifications',
      settings: 'settings',
    }
    const page = map[target]
    if (page && audience === 'student') {
      useAppStore.getState().setStudentPage(page as never)
    }
  }

  // Don't render during exams — all hooks above must run unconditionally.
  if (examInProgress) return null

  return (
    <>
      {/* Floating button */}
      <AnimatePresence>
        {!open && (
          <motion.button
            key="fab"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            onClick={() => setOpen(true)}
            className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 transition-transform hover:scale-105 sm:bottom-6 sm:right-6"
            aria-label="Open Friend chat assistant"
          >
            <MessageCircle className="h-6 w-6" />
            <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-3.5 w-3.5 rounded-full bg-emerald-500" />
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            key="panel"
            initial={{ opacity: 0, y: 20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.98 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-0 right-0 z-50 flex h-[100dvh] w-full flex-col bg-card shadow-2xl sm:bottom-5 sm:right-5 sm:h-[560px] sm:w-[380px] sm:rounded-2xl sm:border"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b bg-primary px-4 py-3 text-primary-foreground sm:rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary-foreground/15">
                  <Sparkles className="h-5 w-5" />
                  <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-primary bg-emerald-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold leading-tight">Friend</p>
                  <p className="text-[11px] leading-tight text-primary-foreground/70">
                    {audience === 'visitor' ? 'Power Maths assistant' : 'Your study buddy · online'}
                  </p>
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/15"
                onClick={() => setOpen(false)}
                aria-label="Close chat"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Messages */}
            <div
              ref={scrollRef}
              className="flex-1 space-y-3 overflow-y-auto bg-background px-3 py-4"
            >
              {session?.messages.map((m) => (
                <MessageBubble key={m.id} message={m} onQuickReply={handleSend} />
              ))}
              {typing && <TypingBubble />}
              {!session && (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                  Starting chat…
                </div>
              )}
            </div>

            {/* Input */}
            <div className="border-t bg-background p-3">
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  handleSend()
                }}
                className="flex items-center gap-2"
              >
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type your message…"
                  className="h-10 flex-1"
                  autoComplete="off"
                />
                <Button
                  type="submit"
                  size="icon"
                  className="h-10 w-10 shrink-0"
                  disabled={!input.trim()}
                  aria-label="Send message"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
              <p className="mt-1.5 text-center text-[10px] text-muted-foreground">
                {audience === 'visitor' ? (
                  <>Powered by Power Maths · We may ask for your WhatsApp to help you</>
                ) : (
                  <>Friend is a rule-based assistant · Tap a chip for quick actions</>
                )}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// ─────────────────────────── Sub-components ───────────────────────────

function MessageBubble({
  message,
  onQuickReply,
}: {
  message: ChatMessage
  onQuickReply: (input?: string, action?: string) => void
}) {
  const isBot = message.role === 'bot'
  return (
    <div className={cn('flex', isBot ? 'justify-start' : 'justify-end')}>
      <div
        className={cn(
          'max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed shadow-sm',
          isBot
            ? 'rounded-bl-md bg-muted text-foreground'
            : 'rounded-br-md bg-primary text-primary-foreground'
        )}
      >
        <p className="whitespace-pre-wrap">{message.text}</p>
        {isBot && message.quickReplies && message.quickReplies.length > 0 && (
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {message.quickReplies.map((qr, i) => (
              <button
                key={i}
                onClick={() => onQuickReply(undefined, qr.action)}
                className="rounded-full border border-primary/30 bg-primary/5 px-2.5 py-1 text-xs font-medium text-primary transition-colors hover:bg-primary/10"
              >
                {qr.label}
              </button>
            ))}
          </div>
        )}
        {isBot && message.action?.type === 'handoff' && (
          <Badge variant="outline" className="mt-2 gap-1 border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">
            <Lightbulb className="h-3 w-3" /> WhatsApp: {WHATSAPP_DISPLAY}
          </Badge>
        )}
      </div>
    </div>
  )
}

function TypingBubble() {
  return (
    <div className="flex justify-start">
      <div className="flex items-center gap-1 rounded-2xl rounded-bl-md bg-muted px-4 py-3">
        <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.3s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.15s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60" />
      </div>
    </div>
  )
}
