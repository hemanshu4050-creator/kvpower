'use client'

/**
 * MathInput (v3.34.0)
 *
 * A textarea-based input with a built-in math symbol toolbar and an optional
 * live KaTeX preview. Used by the admin Inbox reply box and the student
 * Messages reply/compose boxes so both sides can write proper maths
 * (e.g. `2(x^2 - 4)`, `\sqrt{x}`, `\frac{a}{b}`) and the other side sees
 * the rendered formula instead of raw LaTeX.
 *
 * Math syntax (KaTeX):
 *   • Inline math   →  $x^2 + 1$            (renders inline)
 *   • Display math  →  $$\frac{a}{b}$$      (renders as a centred block)
 *
 * The toolbar buttons insert ready-made LaTeX snippets at the caret
 * position. A small "Preview" toggle shows the rendered output below the
 * textarea so the writer can verify their formula before sending.
 */

import * as React from 'react'
import { Eye, EyeOff, Sigma, Superscript, Subscript, Radical, Divide, Pi, Infinity, Plus, Minus, Equal, Triangle } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { KatexMath, renderInlineMath } from '@/components/shared/katex-math'
import { cn } from '@/lib/utils'

// Quick-insert math snippets. Each inserts LaTeX at the caret and leaves
// the caret between the braces (for snippets with a placeholder).
const SNIPPETS: { label: string; latex: string; caret: number; icon: React.ReactNode; hint: string }[] = [
  { label: 'x²', latex: 'x^{2}', caret: 2, icon: <Superscript className="h-3.5 w-3.5" />, hint: 'Superscript (x²)' },
  { label: 'xₙ', latex: 'x_{n}', caret: 2, icon: <Subscript className="h-3.5 w-3.5" />, hint: 'Subscript (xₙ)' },
  { label: '√', latex: '\\sqrt{}', caret: 6, icon: <Radical className="h-3.5 w-3.5" />, hint: 'Square root' },
  { label: '½', latex: '\\frac{}{}', caret: 6, icon: <Divide className="h-3.5 w-3.5" />, hint: 'Fraction' },
  { label: 'π', latex: '\\pi', caret: 0, icon: <Pi className="h-3.5 w-3.5" />, hint: 'Pi' },
  { label: '∞', latex: '\\infty', caret: 0, icon: <Infinity className="h-3.5 w-3.5" />, hint: 'Infinity' },
  { label: '±', latex: '\\pm', caret: 0, icon: <Plus className="h-3.5 w-3.5" />, hint: 'Plus-minus' },
  { label: '−', latex: '-', caret: 0, icon: <Minus className="h-3.5 w-3.5" />, hint: 'Minus' },
  { label: '=', latex: '=', caret: 0, icon: <Equal className="h-3.5 w-3.5" />, hint: 'Equals' },
  { label: '≤', latex: '\\leq', caret: 0, icon: <Triangle className="h-3.5 w-3.5" />, hint: 'Less than or equal' },
  { label: '×', latex: '\\times', caret: 0, icon: <Divide className="h-3.5 w-3.5" />, hint: 'Multiply' },
  { label: '∑', latex: '\\sum_{}^{}', caret: 5, icon: <Sigma className="h-3.5 w-3.5" />, hint: 'Summation' },
]

export interface MathInputProps {
  value: string
  onChange: (v: string) => void
  placeholder?: string
  rows?: number
  autoFocus?: boolean
  className?: string
  /** Show the symbol toolbar. Defaults to true. */
  showToolbar?: boolean
  /** Show the live-preview toggle. Defaults to true. */
  showPreviewToggle?: boolean
}

export function MathInput({
  value,
  onChange,
  placeholder,
  rows = 3,
  autoFocus,
  className,
  showToolbar = true,
  showPreviewToggle = true,
}: MathInputProps) {
  const textareaRef = React.useRef<HTMLTextAreaElement | null>(null)
  const [showPreview, setShowPreview] = React.useState(false)

  const insertAtCaret = (latex: string, caretOffset: number) => {
    const el = textareaRef.current
    if (!el) {
      // Fallback: just append.
      onChange(value + latex)
      return
    }
    const start = el.selectionStart ?? value.length
    const end = el.selectionEnd ?? value.length
    const next = value.slice(0, start) + latex + value.slice(end)
    onChange(next)
    // Place the caret inside the inserted snippet.
    requestAnimationFrame(() => {
      const pos = start + (latex.indexOf('{}') >= 0 ? latex.indexOf('{}') + 1 : latex.length - caretOffset)
      el.focus()
      el.setSelectionRange(pos, pos)
    })
  }

  return (
    <div className={cn('space-y-2', className)}>
      {showToolbar && (
        <div className="flex flex-wrap items-center gap-1 rounded-md border bg-muted/40 p-1.5">
          <span className="mr-1 inline-flex items-center gap-1 px-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
            <Sigma className="h-3 w-3" /> Math
          </span>
          {SNIPPETS.map((s) => (
            <Button
              key={s.label}
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-xs"
              onClick={() => insertAtCaret(s.latex, s.caret)}
              title={s.hint}
            >
              {s.icon}
              <span className="font-mono">{s.label}</span>
            </Button>
          ))}
          <span className="ml-auto text-[10px] text-muted-foreground">
            Tip: wrap LaTeX in <code className="rounded bg-background px-1 font-mono">$...$</code>
          </span>
        </div>
      )}

      <Textarea
        ref={textareaRef}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        autoFocus={autoFocus}
        className="resize-none font-mono text-sm"
      />

      {showPreviewToggle && (
        <div className="space-y-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 text-xs text-muted-foreground"
            onClick={() => setShowPreview((v) => !v)}
          >
            {showPreview ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            {showPreview ? 'Hide preview' : 'Show preview'}
          </Button>
          {showPreview && (
            <div className="rounded-md border bg-background p-3">
              {value.trim() ? (
                <div className="space-y-1.5 text-sm leading-relaxed text-foreground">
                  {renderInlineMath(value).map((node, i) => (
                    <React.Fragment key={i}>{node}</React.Fragment>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Nothing to preview yet. Try typing <code className="font-mono">2(x^2 - 4)</code> wrapped in
                  <code className="ml-1 font-mono">$...$</code>.
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

/**
 * Render a message body that may contain inline (`$...$`) and display
 * (`$$...$$`) math. Falls back to plain text (with preserved whitespace)
 * for messages that contain no math. Used by both the admin Inbox and the
 * student Messages detail view so formulas render consistently on both
 * sides of the conversation.
 */
export function MessageBody({ body, className }: { body: string; className?: string }) {
  const hasMath = body.includes('$')
  if (!hasMath) {
    return <p className={cn('whitespace-pre-line text-sm leading-relaxed text-foreground', className)}>{body}</p>
  }
  return (
    <div className={cn('whitespace-pre-line text-sm leading-relaxed text-foreground', className)}>
      {renderInlineMath(body).map((node, i) => (
        <React.Fragment key={i}>{node}</React.Fragment>
      ))}
    </div>
  )
}

// Re-export so callers can render a single LaTeX expression if needed.
export { KatexMath }
