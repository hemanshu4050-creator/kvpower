'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  BookCheck, Clock, Target, FileQuestion, Play,
  ShieldCheck, Info, AlertTriangle, BookOpen, CheckCircle2,
  Trophy, Eye, RotateCcw, Lock,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useDataStore, type Exam } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { useAssignedExams, useHasPassed, useChapterStatuses } from './lib/student-helpers'
import { ExamRunner } from './lib/exam-runner'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export function StudentExams() {
  const pageTitle = useNavLabel('exams', 'Exams', 'student')
  const user = useAppStore((s) => s.user)
  const results = useDataStore((s) => s.results)
  const setStudentPage = useAppStore((s) => s.setStudentPage)
  const assignedExams = useAssignedExams()
  // Chapter statuses drive the lock/unlock UI — an exam for a chapter that
  // hasn't been unlocked yet (i.e. the previous chapter isn't complete) is
  // shown in a locked state, mirroring the My Chapters page.
  const chapterStatuses = useChapterStatuses()
  const lockedChapterIds = React.useMemo(() => {
    const set = new Set<string>()
    for (const cs of chapterStatuses) {
      if (cs.isLocked) set.add(cs.chapter.id)
    }
    return set
  }, [chapterStatuses])

  const [activeExam, setActiveExam] = React.useState<Exam | null>(null)

  const myResults = React.useMemo(() => {
    if (!user) return []
    return results
      .filter((r) => r.studentId === user.id)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  }, [results, user])

  // Available = assigned, published, not yet passed (can still re-attempt failed ones, but hide passed)
  const completedExamIds = React.useMemo(() => {
    const set = new Set<string>()
    for (const r of myResults) {
      if (r.status === 'passed') set.add(r.examId)
    }
    return set
  }, [myResults])

  const availableExams = React.useMemo(() => {
    return assignedExams.filter((e) => !completedExamIds.has(e.id))
  }, [assignedExams, completedExamIds])

  if (activeExam) {
    return (
      <ExamRunner
        exam={activeExam}
        onExit={() => {
          setActiveExam(null)
          setStudentPage('exams')
        }}
      />
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Attempt chapter tests and track your assessments"
        icon={<BookCheck className="h-5 w-5" />}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_320px]">
        <div>
          <Tabs defaultValue="available">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="available">
                Available
                {availableExams.length > 0 && (
                  <Badge className="ml-1.5 h-4 px-1 text-[10px]">{availableExams.length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="completed">
                Completed
                {myResults.length > 0 && (
                  <Badge variant="secondary" className="ml-1.5 h-4 px-1 text-[10px]">{myResults.length}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            {/* Available */}
            <TabsContent value="available" className="mt-4 space-y-3">
              {availableExams.length === 0 ? (
                <EmptyState
                  icon={Trophy}
                  title="No exams available"
                  description="You've passed every available exam. Outstanding work!"
                  action={<Button size="sm" variant="outline" onClick={() => setStudentPage('certificates')}><Trophy className="h-4 w-4" /> View Certificates</Button>}
                />
              ) : (
                availableExams.map((exam, i) => (
                  <AvailableExamCard
                    key={exam.id}
                    exam={exam}
                    attempted={myResults.some((r) => r.examId === exam.id)}
                    isLocked={lockedChapterIds.has(exam.chapterId)}
                    delay={i * 0.05}
                    onStart={() => setActiveExam(exam)}
                  />
                ))
              )}
            </TabsContent>

            {/* Completed */}
            <TabsContent value="completed" className="mt-4">
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle className="text-base">Completed Exams</CardTitle>
                  <CardDescription>{myResults.length} attempts across all exams</CardDescription>
                </CardHeader>
                <CardContent className="px-0 sm:px-6">
                  {myResults.length === 0 ? (
                    <div className="py-10 text-center text-sm text-muted-foreground">
                      You haven&apos;t attempted any exams yet. Switch to the Available tab to start one.
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Exam</TableHead>
                          <TableHead className="hidden sm:table-cell">Attempt</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead className="hidden sm:table-cell">%</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="hidden md:table-cell">Date</TableHead>
                          <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {myResults.map((r) => (
                          <TableRow key={r.id}>
                            <TableCell>
                              <div className="font-medium">{r.examTitle}</div>
                              <div className="text-xs text-muted-foreground">{r.chapterName}</div>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell tabular-nums">#{r.attemptNumber}</TableCell>
                            <TableCell className="font-semibold tabular-nums">{r.marksObtained}/{r.totalMarks}</TableCell>
                            <TableCell className="hidden sm:table-cell">
                              <Badge className={cn(
                                r.percentage >= 80 && 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15',
                                r.percentage >= 60 && r.percentage < 80 && 'bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15',
                                r.percentage < 60 && 'bg-rose-500/15 text-rose-700 dark:text-rose-400 hover:bg-rose-500/15',
                              )}>
                                {r.percentage}%
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {r.status === 'passed' ? (
                                <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
                                  <CheckCircle2 className="h-3 w-3" /> Passed
                                </Badge>
                              ) : (
                                <Badge variant="destructive"><AlertTriangle className="h-3 w-3" /> Failed</Badge>
                              )}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground">{r.createdAt}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" onClick={() => setStudentPage('results')}>
                                <Eye className="h-4 w-4" /> View
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Exam rules sidebar */}
        <div className="lg:sticky lg:top-6 lg:self-start">
          <Card className="card-elevated border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <ShieldCheck className="h-4 w-4 text-primary" /> Exam Rules
              </CardTitle>
              <CardDescription>Read before you start</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5 text-sm">
              {[
                { icon: Clock, text: 'Once started, the timer cannot be paused.', warn: true },
                { icon: ShieldCheck, text: 'Do not switch tabs — it gets logged.' },
                { icon: Info, text: 'Auto-submit when the timer ends.' },
                { icon: CheckCircle2, text: 'You need 50%+ to pass most exams.' },
                { icon: AlertTriangle, text: 'Results are released immediately.', warn: true },
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <rule.icon className={cn(
                    'mt-0.5 h-4 w-4 shrink-0',
                    rule.warn ? 'text-amber-500' : 'text-primary',
                  )} />
                  <span className="text-muted-foreground">{rule.text}</span>
                </div>
              ))}
              <div className="mt-3 rounded-lg bg-primary/5 p-3 text-xs">
                <p className="font-medium text-foreground">Pro tip</p>
                <p className="mt-0.5 text-muted-foreground">
                  Attempt all practice sheets for a chapter before its test for best results.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function AvailableExamCard({
  exam, attempted, isLocked, delay, onStart,
}: {
  exam: Exam
  attempted: boolean
  isLocked: boolean
  delay: number
  onStart: () => void
}) {
  const hasPassed = useHasPassed(exam.id)
  const questionCount = exam.questionIds.length

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
    >
      <Card className={cn(
        'card-elevated transition-all',
        isLocked ? 'opacity-70' : 'hover:shadow-md',
      )}>
        <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3.5">
            <div className={cn(
              'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl',
              isLocked ? 'bg-muted text-muted-foreground' : 'bg-primary/10 text-primary',
            )}>
              {isLocked ? <Lock className="h-6 w-6" /> : <BookCheck className="h-6 w-6" />}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold leading-tight">{exam.title}</h3>
                {exam.proctored && (
                  <Badge variant="outline" className="gap-1 border-rose-500/30 bg-rose-500/10 text-[10px] text-rose-700 dark:text-rose-400">
                    <ShieldCheck className="h-2.5 w-2.5" /> Proctored
                  </Badge>
                )}
                {exam.questionPoolIds && exam.questionPoolIds.length > 0 && (
                  <Badge variant="outline" className="gap-1 border-amber-500/30 bg-amber-500/10 text-[10px] text-amber-700 dark:text-amber-400">
                    Question pool
                  </Badge>
                )}
                {isLocked ? (
                  <Badge variant="secondary" className="gap-1 text-[10px]">
                    <Lock className="h-2.5 w-2.5" /> Locked
                  </Badge>
                ) : attempted && !hasPassed ? (
                  <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15 text-[10px]">
                    Re-attempt
                  </Badge>
                ) : null}
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">{exam.chapterName}</p>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><BookOpen className="h-3.5 w-3.5" /> {exam.attempts} attempts</span>
                <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {exam.duration} min</span>
                <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" /> {exam.marks} marks</span>
                <span className="flex items-center gap-1"><FileQuestion className="h-3.5 w-3.5" /> {questionCount} Qs</span>
                <span className="flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> {exam.passingPercentage}% pass</span>
                {exam.negativeMarking > 0 && (
                  <span className="flex items-center gap-1 text-rose-500"><AlertTriangle className="h-3.5 w-3.5" /> −{exam.negativeMarking}</span>
                )}
              </div>
            </div>
          </div>
          <div className="flex shrink-0 flex-col items-stretch gap-2 sm:items-end">
            {isLocked ? (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" disabled>
                      <Lock className="h-4 w-4" /> Locked
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Complete the previous chapter first to unlock this exam.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ) : (
              <Button onClick={onStart}>
                <Play className="h-4 w-4" /> Start Exam
              </Button>
            )}
            {!isLocked && attempted && !hasPassed && (
              <span className="flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400">
                <RotateCcw className="h-3 w-3" /> Previous attempt failed
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
