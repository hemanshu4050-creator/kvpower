'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  ArrowUpRight,
  ArrowRight,
  Youtube,
  ImageIcon,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useDataStore } from '@/lib/data-store'
import type { MarketingCampaign, Student } from '@/lib/data-store'

// ─────────────────────── YouTube URL helpers ───────────────────────
// Parse any common YouTube URL format into a clean embed URL.
export function youtubeEmbedUrl(raw: string): string | null {
  if (!raw) return null
  const url = raw.trim()
  const embedMatch = url.match(/youtube\.com\/embed\/([\w-]{6,})/)
  if (embedMatch) return `https://www.youtube.com/embed/${embedMatch[1]}`
  const shortMatch = url.match(/youtu\.be\/([\w-]{6,})/)
  if (shortMatch) return `https://www.youtube.com/embed/${shortMatch[1]}`
  const shortsMatch = url.match(/youtube\.com\/shorts\/([\w-]{6,})/)
  if (shortsMatch) return `https://www.youtube.com/embed/${shortsMatch[1]}`
  const watchMatch = url.match(/[?&]v=([\w-]{6,})/)
  if (watchMatch) return `https://www.youtube.com/embed/${watchMatch[1]}`
  return null
}

// ─────────────────────── Personalization (v3.52.0) ───────────────────────
// Resolve dynamic placeholders inside a text-campaign message body for a
// specific student. Supported variables:
//   {{student_name}} — full name (e.g. "Aarav Sharma")
//   {{first_name}}   — first name (e.g. "Aarav")
//   {{last_name}}    — last name (e.g. "Sharma")
//   {{level}}        — current level/grade derived from batch name
//   {{batch}}        — batch name (e.g. "Batch 2026-A")
//   {{today_date}}   — today's date in the portal locale (e.g. "6/8/2026")
//
// Architecture note: to add a new variable in the future, just extend the
// `vars` map below. Unknown placeholders are left untouched so the admin
// sees the literal `{{unknown}}` text during preview (making it obvious a
// typo occurred) rather than silently dropping content.
export function personalizeMessage(
  raw: string,
  student?: Student | null,
): string {
  if (!raw) return ''
  const parts = (student?.name || '').trim().split(/\s+/)
  const firstName = parts[0] || student?.name || 'Student'
  const lastName = parts.length > 1 ? parts.slice(1).join(' ') : ''
  const batch = student?.batch || ''
  // Derive a friendly level label from the batch name when possible
  // (e.g. "Batch 2026-A" → "Level A"). Falls back to the batch itself.
  let level = batch
  const levelMatch = batch.match(/([A-Za-z])\s*$/)
  if (levelMatch) level = `Level ${levelMatch[1].toUpperCase()}`
  const today = new Date().toLocaleDateString()

  const vars: Record<string, string> = {
    student_name: student?.name || 'Student',
    first_name: firstName,
    last_name: lastName,
    level,
    batch,
    today_date: today,
  }

  return raw.replace(/\{\{\s*(\w+)\s*\}\}/g, (full, key: string) => {
    return Object.prototype.hasOwnProperty.call(vars, key)
      ? vars[key]
      : full
  })
}

/**
 * v3.50.0 — Filter marketing campaigns visible to a specific student.
 *
 * A campaign is visible when ALL of the following are true:
 *   1. status === 'published'
 *   2. current date is within [startDate, endDate] (empty = unbounded)
 *   3. audience match:
 *        • 'all'        → always
 *        • 'batch'      → student's batch is in targetBatches
 *        • 'individual' → student's id is in targetStudentIds
 *
 * Results are sorted by ascending `priority` (1 = top).
 */
export function filterVisibleCampaigns(
  campaigns: MarketingCampaign[],
  studentId: string,
  studentBatch?: string,
): MarketingCampaign[] {
  const now = new Date()
  // Use date-only comparison (ignore time) so a campaign with endDate = today
  // is still visible for the whole day.
  const todayStr = now.toISOString().slice(0, 10)
  return campaigns
    .filter((c) => {
      if (c.status !== 'published') return false
      if (c.startDate && todayStr < c.startDate) return false
      if (c.endDate && todayStr > c.endDate) return false
      if (c.audience === 'all') return true
      if (c.audience === 'batch') {
        return !!studentBatch && (c.targetBatches?.includes(studentBatch) ?? false)
      }
      if (c.audience === 'individual') {
        return c.targetStudentIds?.includes(studentId) ?? false
      }
      return false
    })
    .sort((a, b) => a.priority - b.priority)
}

// ─────────────────────── Text Banner content renderer ───────────────────────
// Renders a personalized message body as structured JSX. Supports:
//   • Paragraphs (separated by blank lines)
//   • Line breaks within paragraphs
//   • Bullet lists (lines starting with -, •, * or —)
//   • Inline emoji & plain text (no HTML injection — safe)
function TextMessageBody({ content }: { content: string }) {
  const blocks = React.useMemo(() => {
    // Split into paragraphs on one-or-more blank lines.
    const paragraphs = content
      .replace(/\r\n/g, '\n')
      .split(/\n\s*\n/)
      .map((p) => p.trim())
      .filter(Boolean)

    return paragraphs.map((para) => {
      const lines = para.split('\n')
      // If every non-empty line starts with a bullet marker, render as a list.
      const bulletRe = /^\s*([-•*—])\s+/
      const isList = lines.length > 0 && lines.every((l) => bulletRe.test(l))
      if (isList) {
        const items = lines.map((l) => l.replace(bulletRe, '').trim())
        return { type: 'list' as const, items }
      }
      return { type: 'para' as const, lines }
    })
  }, [content])

  return (
    <div className="space-y-3">
      {blocks.map((block, i) =>
        block.type === 'list' ? (
          <ul key={i} className="space-y-1.5">
            {block.items.map((item, j) => (
              <li
                key={j}
                className="flex items-start gap-2 text-sm text-foreground/90 sm:text-[0.95rem]"
              >
                <span
                  className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary"
                  aria-hidden
                />
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p
            key={i}
            className="text-sm leading-relaxed text-foreground/90 sm:text-[0.95rem]"
          >
            {block.lines.map((line, k) => (
              <React.Fragment key={k}>
                {k > 0 && <br />}
                {line}
              </React.Fragment>
            ))}
          </p>
        ),
      )}
    </div>
  )
}

/**
 * v3.52.0 — Premium personalized Text Banner card.
 *
 * Renders a SaaS-style promotional card with:
 *   • Soft gradient background (emerald→teal, adapts to dark mode)
 *   • "✨ Special Announcement" eyebrow with icon
 *   • Optional campaign title (large, bold)
 *   • Personalized message body (paragraphs + bullet lists)
 *   • Optional CTA button
 *   • Subtle hover lift animation
 *
 * The message body is personalized per-student via personalizeMessage()
 * before rendering — so {{student_name}} becomes the actual student's name.
 */
function TextBannerCard({
  campaign,
  student,
  index,
}: {
  campaign: MarketingCampaign
  student?: Student | null
  index: number
}) {
  // v3.53.0 — Admin profile photo (data URL) from portal settings. Used in
  // the signed-message footer so the announcement feels personal, like a
  // message hand-signed by the institute administrator. Falls back to a
  // coloured-initials avatar when no photo has been uploaded yet.
  const adminPhoto = useDataStore((s) => s.settings.adminPhoto)
  const adminName = campaign.author || 'Prof. Kalpesh Vyas'

  const personalized = React.useMemo(
    () => personalizeMessage(campaign.messageContent || '', student),
    [campaign.messageContent, student],
  )

  // Compute initials for the avatar fallback (e.g. "Prof. Kalpesh Vyas" → "PK").
  const initials = React.useMemo(() => {
    const parts = adminName.replace(/^(Prof\.?|Dr\.?|Mr\.?|Ms\.?|Mrs\.?)\s+/i, '').trim().split(/\s+/)
    return (parts[0]?.[0] || 'A') + (parts[1]?.[0] || '')
  }, [adminName])

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: 0.1 + index * 0.08 }}
      whileHover={{ y: -2 }}
      className="group relative overflow-hidden rounded-2xl border border-emerald-200/60 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 p-5 shadow-sm transition-shadow hover:shadow-md dark:border-emerald-900/40 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-cyan-950/20 sm:p-6"
    >
      {/* Decorative glow blobs */}
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-emerald-400/20 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -bottom-20 -left-10 h-40 w-40 rounded-full bg-teal-400/15 blur-3xl"
        aria-hidden
      />

      <div className="relative space-y-4">
        {/* Eyebrow */}
        <div className="flex items-center gap-2">
          <span className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-300">
            <Sparkles className="h-4 w-4" />
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
            {campaign.title || 'Special Announcement'}
          </span>
        </div>

        {/* Personalized message body */}
        {personalized ? (
          <TextMessageBody content={personalized} />
        ) : (
          campaign.description && (
            <p className="text-sm leading-relaxed text-foreground/90">
              {campaign.description}
            </p>
          )
        )}

        {/* v3.53.0 — Signed-message footer.
            • Left: admin profile photo (from settings.adminPhoto) with a premium
              emerald ring + name/designation stack — looks like a hand-signed
              institute message.
            • Right: optional CTA button. */}
        {(campaign.ctaText || campaign.author) && (
          <div className="flex flex-col gap-3 border-t border-emerald-200/50 pt-4 dark:border-emerald-800/40 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="avatar-premium h-11 w-11 shrink-0 rounded-full border-2 border-emerald-300/70 shadow-sm dark:border-emerald-700/60">
                {adminPhoto ? (
                  <AvatarImage src={adminPhoto} alt={adminName} />
                ) : null}
                <AvatarFallback className="rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-sm font-semibold text-white">
                  {initials.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col leading-tight">
                <span className="text-sm font-semibold text-foreground">
                  {adminName}
                </span>
                <span className="text-[11px] font-medium uppercase tracking-wider text-emerald-700/80 dark:text-emerald-300/80">
                  Administrator
                </span>
              </div>
            </div>
            {campaign.ctaText && campaign.ctaUrl && (
              <Button
                size="sm"
                className="gap-1.5 bg-emerald-600 text-white shadow-sm hover:bg-emerald-700"
                asChild
              >
                <a
                  href={campaign.ctaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {campaign.ctaText}
                  <ArrowRight className="h-3.5 w-3.5" />
                </a>
              </Button>
            )}
          </div>
        )}
      </div>
    </motion.div>
  )
}

/**
 * Render a single marketing campaign card. Used on the student dashboard.
 * Layout:
 *   • Banner → large image (clickable if CTA URL set) + title/desc/CTA
 *   • Video  → responsive YouTube embed + title/desc/CTA
 *   • Text   → premium personalized text card (v3.52.0)
 */
export function MarketingCampaignCard({
  campaign,
  index,
  student,
}: {
  campaign: MarketingCampaign
  index: number
  student?: Student | null
}) {
  // Text Banner — delegated to the premium card renderer.
  if (campaign.type === 'text') {
    return (
      <TextBannerCard campaign={campaign} student={student} index={index} />
    )
  }

  const embed = campaign.type === 'video' ? youtubeEmbedUrl(campaign.videoUrl || '') : null

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 + index * 0.08 }}
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      {/* Banner type */}
      {campaign.type === 'banner' && campaign.image && (
        campaign.ctaUrl ? (
          <a href={campaign.ctaUrl} target="_blank" rel="noopener noreferrer" className="block">
            <img
              src={campaign.image}
              alt={campaign.title}
              className="block h-auto w-full object-cover"
            />
          </a>
        ) : (
          <img
            src={campaign.image}
            alt={campaign.title}
            className="block h-auto w-full object-cover"
          />
        )
      )}

      {/* Video type */}
      {campaign.type === 'video' && embed && (
        <div className="aspect-video w-full bg-black">
          <iframe
            src={embed}
            title={campaign.title}
            className="h-full w-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      )}

      {/* Title + description + CTA (shown when any of them is present) */}
      {(campaign.title || campaign.description || (campaign.ctaText && campaign.ctaUrl)) && (
        <div className="space-y-2 p-4 sm:p-5">
          {campaign.title && (
            <div className="flex items-start gap-2">
              {campaign.type === 'video' ? (
                <Youtube className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
              ) : (
                <ImageIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              )}
              <h3 className="font-semibold leading-tight">{campaign.title}</h3>
            </div>
          )}
          {campaign.description && (
            <p className="text-sm text-muted-foreground">{campaign.description}</p>
          )}
          {campaign.ctaText && campaign.ctaUrl && (
            <Button size="sm" className="mt-1 gap-1.5" asChild>
              <a href={campaign.ctaUrl} target="_blank" rel="noopener noreferrer">
                {campaign.ctaText} <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </Button>
          )}
        </div>
      )}
    </motion.div>
  )
}

/**
 * Render the full marketing-campaigns block (all visible campaigns, in
 * priority order). Returns null when there are no visible campaigns so the
 * dashboard doesn't render an empty wrapper.
 */
export function StudentMarketingBlock({
  campaigns,
  studentId,
  studentBatch,
  student,
}: {
  campaigns: MarketingCampaign[]
  studentId: string
  studentBatch?: string
  student?: Student | null
}) {
  const visible = React.useMemo(
    () => filterVisibleCampaigns(campaigns, studentId, studentBatch),
    [campaigns, studentId, studentBatch],
  )

  if (visible.length === 0) return null

  return (
    <div className="space-y-4">
      {visible.map((c, i) => (
        <MarketingCampaignCard
          key={c.id}
          campaign={c}
          index={i}
          student={student}
        />
      ))}
    </div>
  )
}
