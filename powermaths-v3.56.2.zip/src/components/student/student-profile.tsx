'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  User, Mail, Phone, MapPin, Calendar, Edit3, Save, Award, BookCheck,
  Clock, Flame, Trophy, Star, Target, Lock, Zap, BookOpen, TrendingUp,
  GraduationCap, ShieldCheck, X, Upload,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { StatCard } from '@/components/shared/stat-card'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { useDataStore, getStudentProgress } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { useAssignedChapters, useChapterStatuses } from './lib/student-helpers'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export function StudentProfile() {
  const pageTitle = useNavLabel('profile', 'Profile', 'student')
  const user = useAppStore((s) => s.user)
  const students = useDataStore((s) => s.students)
  const results = useDataStore((s) => s.results)
  const certificates = useDataStore((s) => s.certificates)
  const activityLogs = useDataStore((s) => s.activityLogs)

  const student = React.useMemo(
    () => students.find((s) => s.id === user?.id) ?? null,
    [students, user]
  )

  const myResults = React.useMemo(
    () => (user ? results.filter((r) => r.studentId === user.id) : []),
    [results, user]
  )
  const myCerts = React.useMemo(
    () => (user ? certificates.filter((c) => c.studentId === user.id && c.status === 'issued') : []),
    [certificates, user]
  )
  const myActivity = React.useMemo(
    () => (user ? activityLogs.filter((a) => a.user === user.name) : []).slice(0, 12),
    [activityLogs, user]
  )

  const chaptersCompleted = myResults.length
    ? new Set(myResults.filter((r) => r.status === 'passed').map((r) => r.chapterName)).size
    : 0
  const avgScore = myResults.length
    ? Math.round(myResults.reduce((a, r) => a + r.percentage, 0) / myResults.length)
    : 0

  const [editOpen, setEditOpen] = React.useState(false)

  if (!student) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <p className="text-sm text-muted-foreground">Student record not found. Please log in again.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Your account, achievements and activity"
        icon={<User className="h-5 w-5" />}
      />

      {/* Profile header card */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
      >
        <Card className="card-elevated overflow-hidden">
          <div className="relative h-28 bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700">
            <div className="absolute inset-0 bg-grid-white/10 opacity-30" />
            <div className="absolute -bottom-12 left-6 flex items-end">
              <Avatar className="h-24 w-24 border-4 border-background shadow-md">
                {student.photo ? <AvatarImage src={student.photo} alt={student.name} /> : null}
                <AvatarFallback className="bg-emerald-100 text-2xl font-bold text-emerald-700">
                  {student.name.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
          <CardContent className="pt-16">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl font-bold">{student.name}</h2>
                  <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
                    <ShieldCheck className="h-3 w-3" /> {student.status === 'active' ? 'Active' : student.status}
                  </Badge>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1.5"><User className="h-3.5 w-3.5" /> {student.id}</span>
                  <span className="flex items-center gap-1.5"><GraduationCap className="h-3.5 w-3.5" /> {student.batch}</span>
                  <span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" /> Joined {student.enrolledAt}</span>
                  {student.validityEnd && (
                    <span className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> Valid till {student.validityEnd}</span>
                  )}
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => setEditOpen(true)}>
                <Edit3 className="h-4 w-4" /> Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Exams Completed" value={myResults.length} icon={BookCheck} accent="emerald" delay={0.05} />
        <StatCard title="Average Score" value={`${avgScore}%`} icon={Target} accent="teal" delay={0.1} />
        <StatCard title="Certificates" value={myCerts.length} icon={Award} accent="violet" delay={0.15} />
        <StatCard title="Chapters Done" value={`${chaptersCompleted}`} icon={Flame} accent="amber" delay={0.2} />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="academic">Academic</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="mt-4">
          <OverviewTab student={student} />
        </TabsContent>

        {/* Academic */}
        <TabsContent value="academic" className="mt-4">
          <AcademicTab myResults={myResults} avgScore={avgScore} certsCount={myCerts.length} />
        </TabsContent>

        {/* Achievements */}
        <TabsContent value="achievements" className="mt-4">
          <AchievementsTab myResults={myResults} myCerts={myCerts} chaptersCompleted={chaptersCompleted} />
        </TabsContent>

        {/* Activity */}
        <TabsContent value="activity" className="mt-4">
          <ActivityTab activity={myActivity} />
        </TabsContent>
      </Tabs>

      <EditProfileDialog open={editOpen} onOpenChange={setEditOpen} student={student} />
    </div>
  )
}

function OverviewTab({ student }: { student: ReturnType<typeof useDataStore.getState>['students'][number] }) {
  const updateStudent = useDataStore((s) => s.updateStudent)
  const [email, setEmail] = React.useState(student.email)
  const [phone, setPhone] = React.useState(student.phone)
  const [address, setAddress] = React.useState(student.address ?? '')
  const [bio, setBio] = React.useState(student.notes ?? '')
  const [saving, setSaving] = React.useState(false)

  // Sync when student prop changes (e.g. after edit dialog save).
  // NOTE (v3.37.0): the student's Name is intentionally NOT editable here —
  // only an admin can change a student's name. The field is shown read-only.
  React.useEffect(() => {
    setEmail(student.email)
    setPhone(student.phone)
    setAddress(student.address ?? '')
    setBio(student.notes ?? '')
  }, [student])

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setTimeout(() => {
      // `name` is deliberately omitted — students cannot rename themselves.
      updateStudent(student.id, { email, phone, address, notes: bio })
      setSaving(false)
      toast.success('Profile updated!')
    }, 500)
  }

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="text-base">Contact Information</CardTitle>
        <CardDescription>Keep your details up to date</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="p-name" className="flex items-center gap-1.5"><User className="h-3.5 w-3.5" /> Full name <Lock className="h-3 w-3 text-muted-foreground" /></Label>
              <Input id="p-name" value={student.name} readOnly className="cursor-not-allowed bg-muted/50 text-muted-foreground" />
              <p className="text-[11px] text-muted-foreground">Only an admin can change your name. Please contact your teacher / admin if it needs correction.</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-email" className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> Email</Label>
              <Input id="p-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-phone" className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> Phone</Label>
              <Input id="p-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-location" className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Address</Label>
              <Input id="p-location" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="City, State" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="p-bio">Bio / Notes</Label>
            <Textarea
              id="p-bio"
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us about your goals..."
            />
          </div>
          <div className="flex justify-end">
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : 'Save Changes'} {!saving && <Save className="h-4 w-4" />}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

function AcademicTab({
  myResults, avgScore, certsCount,
}: {
  myResults: ReturnType<typeof useDataStore.getState>['results']
  avgScore: number
  certsCount: number
}) {
  const user = useAppStore((s) => s.user)
  const statuses = useChapterStatuses()

  const passedCount = myResults.filter((r) => r.status === 'passed').length
  const passRate = myResults.length ? Math.round((passedCount / myResults.length) * 100) : 0

  return (
    <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
      {/* Enrolled chapters */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <BookOpen className="h-4 w-4 text-primary" /> Enrolled Chapters
          </CardTitle>
          <CardDescription>Your progress across the curriculum</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {statuses.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No chapters assigned.</p>
          ) : (
            statuses.map((s) => {
              const progress = s.status === 'completed' ? 100 : s.bestScore || 0
              return (
                <div key={s.chapter.id} className="rounded-lg border bg-card p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-primary/10 text-xs font-bold text-primary">
                        {s.chapter.order}
                      </span>
                      <span className="truncate text-sm font-medium">{s.chapter.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {s.bestScore > 0 && <span className="text-xs font-semibold tabular-nums text-muted-foreground">{s.bestScore}%</span>}
                      <Badge className={cn(
                        'text-[10px]',
                        s.status === 'completed' && 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15',
                        s.status === 'in_progress' && 'bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15',
                        s.status === 'locked' && 'bg-muted text-muted-foreground',
                        s.status === 'not_started' && 'bg-muted text-muted-foreground',
                      )}>
                        {s.status === 'completed' ? 'Done' : s.status === 'in_progress' ? 'In progress' : s.status === 'locked' ? 'Locked' : 'Not started'}
                      </Badge>
                    </div>
                  </div>
                  <Progress value={progress} className="mt-2 h-1.5" />
                </div>
              )
            })
          )}
        </CardContent>
      </Card>

      {/* Summary cards */}
      <div className="space-y-4">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-base">Exam History</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Exams taken</span>
              <span className="font-semibold">{myResults.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Passed</span>
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">{passedCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Pass rate</span>
              <span className="font-semibold">{passRate}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Average score</span>
              <span className="font-semibold text-primary">{avgScore}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Certificates</span>
              <span className="font-semibold">{certsCount}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="card-elevated overflow-hidden">
          <div className="bg-gradient-to-br from-amber-500/10 to-transparent p-5">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-amber-500" />
              <p className="text-sm font-semibold">Current Rank</p>
            </div>
            <p className="mt-2 text-4xl font-bold tabular-nums text-amber-600 dark:text-amber-400">#3</p>
            <p className="text-xs text-muted-foreground">in {user?.batch ?? 'your batch'} this week</p>
            <div className="mt-3 rounded-lg bg-background/60 p-2.5 text-xs">
              <p className="text-muted-foreground">
                You&apos;re <span className="font-semibold text-foreground">1 exam away</span> from rank #2.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

function AchievementsTab({
  myResults, myCerts, chaptersCompleted,
}: {
  myResults: ReturnType<typeof useDataStore.getState>['results']
  myCerts: ReturnType<typeof useDataStore.getState>['certificates']
  chaptersCompleted: number
}) {
  const perfectScore = myResults.some((r) => r.percentage === 100)
  const above85 = myResults.filter((r) => r.percentage >= 85).length
  const allSixChapters = chaptersCompleted >= 6

  const achievements = [
    { id: 'a1', name: 'First Certificate', desc: 'Earned your first certificate', icon: Award, earned: myCerts.length >= 1, color: 'text-amber-500' },
    { id: 'a2', name: '7-Day Streak', desc: 'Studied 7 days in a row', icon: Flame, earned: true, color: 'text-rose-500' },
    { id: 'a3', name: 'Top 3 Rank', desc: 'Reached top 3 in your batch', icon: Trophy, earned: true, color: 'text-amber-500' },
    { id: 'a4', name: 'Perfect Score', desc: 'Scored 100% on an exam', icon: Star, earned: perfectScore, color: 'text-amber-500' },
    { id: 'a5', name: 'Sharp Shooter', desc: '5 exams above 85%', icon: Target, earned: above85 >= 5, color: 'text-emerald-500' },
    { id: 'a6', name: 'Bookworm', desc: 'Complete 4 chapters', icon: BookOpen, earned: chaptersCompleted >= 4, color: 'text-teal-500' },
    { id: 'a7', name: 'Night Owl', desc: 'Study after 10 PM 10 times', icon: Zap, earned: false, color: 'text-violet-500' },
    { id: 'a8', name: 'Math Master', desc: 'Complete all 6 chapters', icon: GraduationCap, earned: allSixChapters, color: 'text-primary' },
  ]

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {achievements.map((a, i) => (
        <motion.div
          key={a.id}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: i * 0.04 }}
        >
          <Card className={cn(
            'card-elevated h-full text-center',
            !a.earned && 'opacity-60',
          )}>
            <CardContent className="flex flex-col items-center p-4">
              <div className={cn(
                'flex h-12 w-12 items-center justify-center rounded-xl',
                a.earned ? 'bg-primary/10' : 'bg-muted',
              )}>
                {a.earned ? (
                  <a.icon className={cn('h-6 w-6', a.color)} />
                ) : (
                  <Lock className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
              <p className="mt-2.5 text-sm font-semibold">{a.name}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">{a.desc}</p>
              {a.earned ? (
                <Badge className="mt-2 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">Earned</Badge>
              ) : (
                <Badge variant="secondary" className="mt-2">Locked</Badge>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}

function ActivityTab({
  activity,
}: {
  activity: ReturnType<typeof useDataStore.getState>['activityLogs']
}) {
  const iconForType = (type: string) => {
    switch (type) {
      case 'submit': return { icon: BookCheck, color: 'text-emerald-500' }
      case 'create': return { icon: Award, color: 'text-violet-500' }
      case 'login': return { icon: User, color: 'text-muted-foreground' }
      case 'system': return { icon: Zap, color: 'text-amber-500' }
      default: return { icon: TrendingUp, color: 'text-primary' }
    }
  }

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <TrendingUp className="h-4 w-4 text-primary" /> Recent Activity
        </CardTitle>
        <CardDescription>Your latest actions on the portal</CardDescription>
      </CardHeader>
      <CardContent>
        {activity.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">No recent activity.</p>
        ) : (
          <div className="relative space-y-1">
            <div className="absolute left-[18px] top-2 bottom-2 w-px bg-border" />
            {activity.map((t, i) => {
              const { icon: Icon, color } = iconForType(t.type)
              return (
                <motion.div
                  key={t.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className="relative flex items-start gap-3 rounded-lg p-2 hover:bg-muted/40"
                >
                  <div className={cn(
                    'z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 border-background bg-background shadow-sm',
                    color,
                  )}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 pt-1">
                    <p className="text-sm">
                      <span className="font-medium capitalize">{t.action}</span>
                      {t.target && <span className="text-muted-foreground"> · {t.target}</span>}
                    </p>
                    <p className="text-xs text-muted-foreground">{t.time}</p>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function EditProfileDialog({
  open, onOpenChange, student,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  student: ReturnType<typeof useDataStore.getState>['students'][number]
}) {
  const updateStudent = useDataStore((s) => s.updateStudent)
  const [email, setEmail] = React.useState(student.email)
  const [phone, setPhone] = React.useState(student.phone)
  const [address, setAddress] = React.useState(student.address ?? '')
  const [photo, setPhoto] = React.useState(student.photo ?? '')
  const [saving, setSaving] = React.useState(false)

  React.useEffect(() => {
    setEmail(student.email)
    setPhone(student.phone)
    setAddress(student.address ?? '')
    setPhoto(student.photo ?? '')
  }, [student])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG, or SVG).')
      return
    }
    if (file.size > 800 * 1024) {
      toast.error('Image too large. Maximum 800 KB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = String(reader.result || '')
      setPhoto(dataUrl)
      // Apply immediately so the profile header updates live.
      updateStudent(student.id, { photo: dataUrl })
      toast.success('Photo updated', { description: file.name })
    }
    reader.onerror = () => toast.error('Could not read the image file.')
    reader.readAsDataURL(file)
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) {
      toast.error('Email is required')
      return
    }
    setSaving(true)
    setTimeout(() => {
      // NOTE (v3.37.0): `name` is deliberately NOT passed — students cannot
      // change their own name; only an admin can edit a student's name.
      updateStudent(student.id, { email: email.trim(), phone: phone.trim(), address: address.trim(), photo: photo || undefined })
      setSaving(false)
      onOpenChange(false)
      toast.success('Profile updated!')
    }, 500)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
          <DialogDescription>Update your personal information</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSave} className="space-y-4">
          {/* Photo uploader */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2 border-border">
              {photo ? <AvatarImage src={photo} alt={student.name} /> : null}
              <AvatarFallback className="bg-emerald-100 text-sm font-bold text-emerald-700">
                {student.name ? student.name.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase() : <User className="h-5 w-5" />}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById('student-profile-photo')?.click()}>
                  <Upload className="h-4 w-4" />
                  {photo ? 'Change photo' : 'Upload photo'}
                </Button>
                {photo && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => { setPhoto(''); updateStudent(student.id, { photo: undefined }) }}>
                    <X className="h-4 w-4" /> Remove
                  </Button>
                )}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">JPG, PNG or SVG. Max 800 KB.</p>
              <input
                id="student-profile-photo"
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={handlePhotoUpload}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="e-name" className="flex items-center gap-1.5">Full name <Lock className="h-3 w-3 text-muted-foreground" /></Label>
            <Input id="e-name" value={student.name} readOnly className="cursor-not-allowed bg-muted/50 text-muted-foreground" />
            <p className="text-[11px] text-muted-foreground">Only an admin can change your name. Contact your teacher / admin if it needs correction.</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="e-email">Email</Label>
            <Input id="e-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="e-phone">Phone</Label>
            <Input id="e-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="e-address">Address</Label>
            <Input id="e-address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="City, State" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              <X className="h-4 w-4" /> Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : 'Save Changes'} {!saving && <Save className="h-4 w-4" />}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
