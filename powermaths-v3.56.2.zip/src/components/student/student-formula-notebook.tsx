'use client'

/**
 * StudentFormulaNotebook — the student-facing Formula notebook view.
 *
 * Renders inside the chapter learning page "Formula" tab. Shows every
 * non-hidden formula in the chapter as a beautiful card with:
 *   • KaTeX-rendered expression
 *   • Title + category
 *   • Explanation
 *   • Expandable example + notes
 *   • "Viewed" checkmark + progress tracking
 *
 * DRM: copy/select/print/right-click all disabled via <DrmContent>.
 */

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Sigma, ChevronDown, ChevronRight, CheckCircle2,
  Sparkles, Filter,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { KatexMath } from '@/components/shared/katex-math'
import { DrmContent } from '@/components/shared/drm-content'
import { useAppStore } from '@/lib/store'
import { useLearningProgress } from '@/lib/learning-progress'
import type { Formula } from '@/lib/data-store'
import { cn } from '@/lib/utils'

interface StudentFormulaNotebookProps {
  chapterId: string
  formulas: Formula[]
}

const ACCENTS = ['violet', 'teal', 'amber', 'rose', 'emerald', 'blue']

function accentFor(idx: number) {
  const a = ACCENTS[idx % ACCENTS.length]
  return {
    bg: `bg-${a}-500/10`,
    text: `text-${a}-600 dark:text-${a}-400`,
    ring: `ring-${a}-500/30`,
    border: `border-${a}-500/20`,
  }
}

export function StudentFormulaNotebook({ chapterId, formulas }: StudentFormulaNotebookProps) {
  const user = useAppStore((s) => s.user)
  const markFormulaViewed = useLearningProgress((s) => s.markFormulaViewed)
  const progress = useLearningProgress((s) => s.chapters[`${user?.id}:${chapterId}`])

  const [search, setSearch] = React.useState('')
  const [activeCategory, setActiveCategory] = React.useState<string>('all')
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set())

  // Open the first formula by default so students immediately see the
  // explanation / example / notes structure and understand the affordance.
  // Uses a ref guard so this only fires once — the first time formulas are
  // available — rather than on every prop change.
  const didAutoOpen = React.useRef(false)
  React.useEffect(() => {
    if (didAutoOpen.current) return
    const first = [...formulas]
      .filter((f) => !f.hidden)
      .sort((a, b) => a.order - b.order)[0]
    if (first) {
      setExpanded(new Set([first.id]))
      didAutoOpen.current = true
    }
  }, [formulas])

  const visibleFormulas = React.useMemo(
    () => [...formulas].filter((f) => !f.hidden).sort((a, b) => a.order - b.order),
    [formulas]
  )

  const categories = React.useMemo(() => {
    const set = new Set<string>()
    visibleFormulas.forEach((f) => f.category && set.add(f.category))
    return ['all', ...Array.from(set).sort()]
  }, [visibleFormulas])

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase()
    return visibleFormulas
      .filter((f) => activeCategory === 'all' || f.category === activeCategory)
      .filter((f) => {
        if (!q) return true
        return (
          f.title.toLowerCase().includes(q) ||
          f.category.toLowerCase().includes(q) ||
          f.expression.toLowerCase().includes(q) ||
          f.explanation.toLowerCase().includes(q)
        )
      })
  }, [visibleFormulas, search, activeCategory])

  const viewedCount = React.useMemo(() => {
    if (!progress?.formulas) return 0
    return visibleFormulas.filter((f) => progress.formulas[f.id]?.viewed).length
  }, [visibleFormulas, progress])

  const toggleExpand = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
    // Mark as viewed on first expand.
    if (user && !progress?.formulas?.[id]?.viewed) {
      markFormulaViewed(user.id, chapterId, id)
    }
  }

  const watermark = user ? `${user.name} · ID: ${user.id}` : undefined

  return (
    <Card className="card-elevated">
      <CardContent className="p-5 sm:p-6">
        {/* Header */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 font-semibold">
              <Sigma className="h-5 w-5 text-violet-600 dark:text-violet-400" />
              Formula Notebook
            </h3>
            <p className="text-sm text-muted-foreground">
              Quick revision of every important formula in this chapter. Tap a card to expand.
            </p>
          </div>
          <Badge variant="secondary" className="gap-1">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
            {viewedCount} / {visibleFormulas.length} viewed
          </Badge>
        </div>

        {/* Instructional banner — make it obvious that formulas expand */}
        <div className="mb-4 flex items-center gap-3 rounded-lg border border-violet-500/30 bg-violet-500/5 px-4 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-600 dark:text-violet-400">
            <Sparkles className="h-4 w-4" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-foreground">
              Tap a formula card to reveal its explanation, example &amp; notes
            </p>
            <p className="text-xs text-muted-foreground">
              Each formula expands to show a detailed breakdown. The first one is already open for you below.
            </p>
          </div>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
            className="hidden shrink-0 text-violet-500 sm:block"
            aria-hidden
          >
            <ChevronDown className="h-5 w-5" />
          </motion.div>
        </div>

        {/* Search + categories */}
        <div className="mb-4 space-y-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search formulas by name, category or content..."
              className="pl-9"
            />
          </div>
          {categories.length > 1 && (
            <div className="flex flex-wrap items-center gap-1.5">
              <Filter className="h-3 w-3 text-muted-foreground" />
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveCategory(c)}
                  className={cn(
                    'rounded-full border px-2.5 py-0.5 text-[11px] font-medium transition-colors',
                    activeCategory === c
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background text-muted-foreground hover:bg-muted'
                  )}
                >
                  {c === 'all' ? 'All' : c}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Formula cards (DRM-protected) */}
        {filtered.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 px-4 py-10 text-center">
            <Sigma className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
            <p className="text-sm font-medium">No formulas found</p>
            <p className="text-xs text-muted-foreground mt-1">
              {search ? 'Try a different search term.' : 'Formulas will appear here once your teacher adds them.'}
            </p>
          </div>
        ) : (
          <DrmContent watermark={watermark} className="space-y-3">
            <AnimatePresence initial={false}>
              {filtered.map((f, idx) => {
                const accent = accentFor(idx)
                const isExpanded = expanded.has(f.id)
                const isViewed = progress?.formulas?.[f.id]?.viewed
                return (
                  <motion.div
                    key={f.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.18 }}
                    className={cn(
                      'relative overflow-hidden rounded-xl border bg-card transition-all',
                      accent.border,
                      isExpanded ? 'shadow-md' : 'hover:shadow-sm'
                    )}
                  >
                    {/* Accent strip */}
                    <div className={cn('absolute left-0 top-0 h-full w-1', accent.bg)} />

                    {/* Clickable header */}
                    <button
                      onClick={() => toggleExpand(f.id)}
                      className="flex w-full items-start gap-3 p-4 pl-5 text-left"
                    >
                      {/* Icon tile */}
                      <div className={cn(
                        'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ring-1',
                        accent.bg, accent.text, accent.ring
                      )}>
                        <Sigma className="h-5 w-5" />
                      </div>

                      {/* Title + category */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="truncate text-sm font-semibold">{f.title}</p>
                          {isViewed && (
                            <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                          )}
                        </div>
                        {f.category && (
                          <Badge variant="outline" className="mt-0.5 h-4 px-1.5 text-[9px] uppercase tracking-wide">
                            {f.category}
                          </Badge>
                        )}
                      </div>

                      {/* Expand chevron + hint */}
                      <div className="flex shrink-0 items-center gap-1 pt-1">
                        {!isExpanded && (
                          <span className="hidden text-[10px] font-semibold text-violet-500 sm:inline">
                            Tap to expand
                          </span>
                        )}
                        {isExpanded ? (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-violet-500" />
                        )}
                      </div>
                    </button>

                    {/* Formula expression — always visible */}
                    <div className="px-5 pb-3">
                      <div className={cn(
                        'rounded-lg px-3 py-3 text-center overflow-x-auto',
                        accent.bg, 'border', accent.border
                      )}>
                        <KatexMath expression={f.expression} display />
                      </div>
                    </div>

                    {/* Expandable content */}
                    <AnimatePresence initial={false}>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden border-t border-border/60 px-5 pt-3"
                        >
                          {f.explanation && (
                            <div className="mb-3">
                              <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                                Explanation
                              </p>
                              <p className="text-xs leading-relaxed text-foreground/90">{f.explanation}</p>
                            </div>
                          )}
                          {f.example && (
                            <div className="mb-3 rounded-md border border-border/60 bg-muted/30 px-3 py-2">
                              <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                                Example
                              </p>
                              <div className="overflow-x-auto text-xs">
                                <KatexMath expression={f.example} display={false} />
                              </div>
                            </div>
                          )}
                          {f.notes && (
                            <div className="mb-3 rounded-md border-l-2 border-primary/40 bg-primary/5 px-3 py-2">
                              <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                                Note
                              </p>
                              <p className="text-xs leading-relaxed text-foreground/90">{f.notes}</p>
                            </div>
                          )}
                          <div className="flex items-center justify-end pt-1 pb-3">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-[11px]"
                              onClick={() => setExpanded((p) => { const n = new Set(p); n.delete(f.id); return n })}
                            >
                              Collapse
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )
              })}
            </AnimatePresence>

            {/* Footer summary */}
            <div className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-violet-500" />
              <span>
                {viewedCount} of {visibleFormulas.length} formulas viewed · {visibleFormulas.length - viewedCount} remaining
              </span>
            </div>
          </DrmContent>
        )}
      </CardContent>
    </Card>
  )
}
