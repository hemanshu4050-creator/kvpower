'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  BookOpen, FileText, PenTool, BookCheck, Lock, CheckCircle2, Play,
  Eye, Clock, ArrowRight, Trophy,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { useAppStore } from '@/lib/store'
import { formatDuration } from '@/lib/learning-progress'
import { useNavLabel } from '@/lib/nav-helpers'
import {
  ChapterIcon, useChapterStatuses, type ChapterStatusInfo,
} from './lib/student-helpers'
import { ChapterLearningPage } from './chapter-learning-page'
import { cn } from '@/lib/utils'

export function StudentChapters() {
  const pageTitle = useNavLabel('chapters', 'My Chapters', 'student')
  const statuses = useChapterStatuses()
  const completedCount = statuses.filter((s) => s.status === 'completed').length
  const studentChapterView = useAppStore((s) => s.studentChapterView)
  const openChapterLearning = useAppStore((s) => s.openChapterLearning)
  const closeChapterLearning = useAppStore((s) => s.closeChapterLearning)

  // ── Chapter Learning Page (full-page view, replaces the popup) ──
  if (studentChapterView.mode === 'learning' && studentChapterView.chapterId) {
    const chapter = statuses.find((s) => s.chapter.id === studentChapterView.chapterId)?.chapter
    if (chapter) {
      return (
        <AnimatePresence mode="wait">
          <motion.div
            key={`learning-${chapter.id}`}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            <ChapterLearningPage chapter={chapter} onBack={closeChapterLearning} />
          </motion.div>
        </AnimatePresence>
      )
    }
    // Fallback: invalid chapter id → reset to list view.
    closeChapterLearning()
  }

  // ── Chapters list (default view) ──
  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Your learning path — complete each chapter to unlock the next"
        icon={<BookOpen className="h-5 w-5" />}
        actions={
          <Badge variant="secondary" className="gap-1.5">
            <Trophy className="h-3.5 w-3.5 text-amber-500" />
            {completedCount} of {statuses.length} completed
          </Badge>
        }
      />

      {/* Learning path */}
      <div className="relative">
        {/* Vertical connector line (desktop) */}
        <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-emerald-500/40 via-border to-transparent lg:block" />

        <div className="space-y-4 lg:space-y-2">
          {statuses.map((info, idx) => {
            const isLeft = idx % 2 === 0
            return (
              <motion.div
                key={info.chapter.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: idx * 0.06 }}
                className="relative lg:grid lg:grid-cols-2 lg:gap-8"
              >
                {/* Connector dot (desktop) */}
                <div className="absolute left-1/2 top-8 z-10 hidden -translate-x-1/2 lg:block">
                  <div className={cn(
                    'flex h-7 w-7 items-center justify-center rounded-full border-2 bg-background shadow-sm',
                    info.status === 'completed' && 'border-emerald-500 bg-emerald-500 text-white',
                    info.status === 'in_progress' && 'border-amber-500 bg-amber-500 text-white',
                    info.status === 'not_started' && 'border-primary/40 bg-background text-primary',
                    info.status === 'locked' && 'border-muted-foreground/30 bg-background text-muted-foreground',
                  )}>
                    {info.status === 'completed' ? <CheckCircle2 className="h-4 w-4" />
                      : info.isLocked ? <Lock className="h-3.5 w-3.5" />
                      : <span className="text-xs font-bold">{info.chapter.order}</span>}
                  </div>
                </div>

                {/* Mobile connector line */}
                <div className="absolute left-[27px] top-12 h-[calc(100%-1rem)] w-0.5 bg-border lg:hidden" />

                <div className={cn(
                  'pl-16 lg:pl-0',
                  isLeft ? 'lg:pr-10' : 'lg:col-start-2 lg:pl-10',
                )}>
                  <ChapterCard
                    info={info}
                    onOpen={() => !info.isLocked && openChapterLearning(info.chapter.id)}
                  />
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function ChapterCard({
  info, onOpen,
}: {
  info: ChapterStatusInfo
  onOpen: () => void
}) {
  const { chapter, status, bestScore, isLocked, learningProgress, timeSpentSeconds } = info
  // Use the live learning progress when available; fall back to the legacy
  // bestScore-based estimate so cards always show something sensible.
  const progress = status === 'completed'
    ? 100
    : learningProgress > 0
      ? learningProgress
      : status === 'in_progress'
        ? Math.max(20, bestScore)
        : 0
  const isCompleted = status === 'completed'

  return (
    <Card
      className={cn(
        'card-elevated relative transition-all hover:shadow-md',
        isLocked && 'opacity-70',
        !isLocked && 'cursor-pointer hover:border-primary/40',
      )}
      onClick={() => !isLocked && onOpen()}
    >
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          {/* Status circle (mobile) */}
          <div className={cn(
            'absolute -left-3.5 top-5 z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 bg-background shadow-sm lg:hidden',
            status === 'completed' && 'border-emerald-500 bg-emerald-500 text-white',
            status === 'in_progress' && 'border-amber-500 bg-amber-500 text-white',
            status === 'not_started' && 'border-primary/40 bg-background text-primary',
            status === 'locked' && 'border-muted-foreground/30 bg-background text-muted-foreground',
          )}>
            {isCompleted ? <CheckCircle2 className="h-4 w-4" />
              : isLocked ? <Lock className="h-3.5 w-3.5" />
              : <span className="text-xs font-bold">{chapter.order}</span>}
          </div>

          <div className={cn(
            'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl',
            isLocked ? 'bg-muted text-muted-foreground' : 'bg-primary/10 text-primary',
          )}>
            <ChapterIcon name={chapter.icon} className="h-6 w-6" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-semibold leading-tight">{chapter.name}</h3>
              <StatusBadge status={status} />
            </div>
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{chapter.description}</p>

            <div className="mt-3 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  {isLocked ? 'Locked' : 'Progress'}
                </span>
                <span className="font-semibold tabular-nums">
                  {isLocked ? '—' : `${progress}%`}
                </span>
              </div>
              <Progress value={progress} className="h-1.5" />
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" /> {chapter.studyMaterials.length} materials</span>
              <span className="flex items-center gap-1"><PenTool className="h-3.5 w-3.5" /> {chapter.practiceSheets.length} practice</span>
              <span className="flex items-center gap-1"><BookCheck className="h-3.5 w-3.5" /> {chapter.tests.length} tests</span>
              {timeSpentSeconds > 0 && (
                <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {formatDuration(timeSpentSeconds)}</span>
              )}
            </div>

            <div className="mt-4">
              {isLocked ? (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button size="sm" variant="outline" disabled className="w-full sm:w-auto">
                        <Lock className="h-4 w-4" /> Locked
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Complete the previous chapter first to unlock this one.</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ) : (
                <Button
                  size="sm"
                  variant={isCompleted ? 'outline' : 'default'}
                  onClick={(e) => {
                    e.stopPropagation()
                    onOpen()
                  }}
                  className="w-full gap-1.5 sm:w-auto"
                >
                  {isCompleted ? (<><Eye className="h-4 w-4" /> Review Chapter</>)
                    : progress > 0 ? (<><Play className="h-4 w-4" /> Continue</>)
                    : (<><Play className="h-4 w-4" /> Start Learning</>)}
                  <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status }: { status: ChapterStatusInfo['status'] }) {
  if (status === 'completed')
    return <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15"><CheckCircle2 className="h-3 w-3" /> Completed</Badge>
  if (status === 'in_progress')
    return <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15"><Clock className="h-3 w-3" /> In Progress</Badge>
  if (status === 'locked')
    return <Badge variant="secondary" className="gap-1"><Lock className="h-3 w-3" /> Locked</Badge>
  return <Badge variant="outline" className="gap-1">Not Started</Badge>
}
