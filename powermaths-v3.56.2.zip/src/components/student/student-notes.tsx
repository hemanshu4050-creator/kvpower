'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  StickyNote, Plus, Search, Pin, Trash2, Edit3, BookOpen, Clock,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useDataStore, type Note } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { useAssignedChapters } from './lib/student-helpers'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

const colorOptions = [
  { value: 'emerald', label: 'Emerald', ring: 'ring-emerald-500/40', bar: 'bg-emerald-500', chip: 'bg-emerald-500' },
  { value: 'amber', label: 'Amber', ring: 'ring-amber-500/40', bar: 'bg-amber-500', chip: 'bg-amber-500' },
  { value: 'violet', label: 'Violet', ring: 'ring-violet-500/40', bar: 'bg-violet-500', chip: 'bg-violet-500' },
  { value: 'rose', label: 'Rose', ring: 'ring-rose-500/40', bar: 'bg-rose-500', chip: 'bg-rose-500' },
  { value: 'teal', label: 'Teal', ring: 'ring-teal-500/40', bar: 'bg-teal-500', chip: 'bg-teal-500' },
] as const

type NoteColor = typeof colorOptions[number]['value']

const colorMap = Object.fromEntries(colorOptions.map((c) => [c.value, c])) as Record<NoteColor, typeof colorOptions[number]>

export function StudentNotes() {
  const pageTitle = useNavLabel('notes', 'My Notes', 'student')
  const user = useAppStore((s) => s.user)
  const notes = useDataStore((s) => s.notes)
  const addNote = useDataStore((s) => s.addNote)
  const updateNote = useDataStore((s) => s.updateNote)
  const deleteNote = useDataStore((s) => s.deleteNote)

  const [search, setSearch] = React.useState('')
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [editing, setEditing] = React.useState<Note | null>(null)

  const myNotes = React.useMemo(() => {
    if (!user) return []
    return notes.filter((n) => n.studentId === user.id)
  }, [notes, user])

  const filtered = React.useMemo(() => {
    return myNotes
      .filter((n) =>
        n.title.toLowerCase().includes(search.toLowerCase()) ||
        n.content.toLowerCase().includes(search.toLowerCase()) ||
        n.chapter.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => {
        const ap = a.pinned ? 1 : 0
        const bp = b.pinned ? 1 : 0
        if (bp !== ap) return bp - ap
        return (b.updatedAt || '').localeCompare(a.updatedAt || '')
      })
  }, [myNotes, search])

  const handleTogglePin = (note: Note) => {
    updateNote(note.id, { pinned: !note.pinned })
    toast.success(note.pinned ? 'Note unpinned' : 'Note pinned')
  }

  const handleDelete = (note: Note) => {
    deleteNote(note.id)
    toast.success('Note deleted')
  }

  const handleOpenEdit = (note: Note) => {
    setEditing(note)
    setDialogOpen(true)
  }

  const handleOpenNew = () => {
    setEditing(null)
    setDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Capture formulas, theorems and reminders"
        icon={<StickyNote className="h-5 w-5" />}
        actions={
          <Button size="sm" onClick={handleOpenNew}>
            <Plus className="h-4 w-4" /> New Note
          </Button>
        }
      />

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search notes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-8"
        />
      </div>

      {/* Notes masonry grid */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={StickyNote}
              title={search ? 'No notes match your search' : 'No notes yet'}
              description={search ? 'Try a different keyword.' : 'Create your first note to capture formulas and reminders.'}
              action={!search ? (
                <Button size="sm" onClick={handleOpenNew}>
                  <Plus className="h-4 w-4" /> Create Note
                </Button>
              ) : undefined}
            />
          </CardContent>
        </Card>
      ) : (
        <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4 [&>*]:break-inside-avoid">
          {filtered.map((note, i) => {
            const color = colorMap[note.color as NoteColor] ?? colorMap.emerald
            return (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.04 }}
              >
                <Card className="group relative overflow-hidden p-0 transition-all hover:shadow-md">
                  {/* Color bar */}
                  <div className={cn('h-1.5 w-full', color.bar)} />
                  <CardContent className="space-y-3 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold leading-snug">{note.title}</h3>
                      <button
                        onClick={() => handleTogglePin(note)}
                        className={cn(
                          'shrink-0 rounded-md p-1 transition-colors',
                          note.pinned ? 'text-primary' : 'text-muted-foreground/50 hover:text-foreground',
                        )}
                        aria-label={note.pinned ? 'Unpin note' : 'Pin note'}
                      >
                        <Pin className={cn('h-3.5 w-3.5', note.pinned && 'fill-current')} />
                      </button>
                    </div>

                    <p className="whitespace-pre-line text-sm text-muted-foreground line-clamp-6">
                      {note.content}
                    </p>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <Badge variant="secondary" className="gap-1 text-[10px]">
                        <BookOpen className="h-3 w-3" /> {note.chapter || 'General'}
                      </Badge>
                      <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        <Clock className="h-3 w-3" /> {note.updatedAt}
                      </span>
                    </div>

                    {/* Hover actions */}
                    <div className="flex items-center gap-1 border-t pt-2 opacity-0 transition-opacity group-hover:opacity-100">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => handleOpenEdit(note)}
                      >
                        <Edit3 className="h-3.5 w-3.5" /> Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs text-destructive hover:text-destructive"
                        onClick={() => handleDelete(note)}
                      >
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}

      <NoteDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        onCreate={(payload) => {
          if (!user) return
          addNote({ studentId: user.id, ...payload })
          toast.success('Note created!')
        }}
        onUpdate={(id, patch) => {
          updateNote(id, patch)
          toast.success('Note updated!')
        }}
      />
    </div>
  )
}

function NoteDialog({
  open, onOpenChange, editing, onCreate, onUpdate,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  editing: Note | null
  onCreate: (note: Omit<Note, 'id' | 'studentId' | 'updatedAt' | 'pinned'>) => void
  onUpdate: (id: string, patch: Partial<Note>) => void
}) {
  const chapters = useAssignedChapters()
  const [title, setTitle] = React.useState('')
  const [chapter, setChapter] = React.useState('')
  const [content, setContent] = React.useState('')
  const [color, setColor] = React.useState<NoteColor>('emerald')
  const [saving, setSaving] = React.useState(false)

  // Sync form whenever dialog opens (for new or edit)
  React.useEffect(() => {
    if (!open) return
    if (editing) {
      setTitle(editing.title)
      setChapter(editing.chapter)
      setContent(editing.content)
      setColor((editing.color as NoteColor) || 'emerald')
    } else {
      setTitle('')
      setChapter(chapters[0]?.name ?? 'General')
      setContent('')
      setColor('emerald')
    }
  }, [open, editing, chapters])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !content.trim()) {
      toast.error('Please add a title and content')
      return
    }
    setSaving(true)
    setTimeout(() => {
      if (editing) {
        onUpdate(editing.id, { title: title.trim(), content: content.trim(), chapter, color })
      } else {
        onCreate({ title: title.trim(), content: content.trim(), chapter, color })
      }
      setSaving(false)
      onOpenChange(false)
    }, 400)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{editing ? 'Edit Note' : 'New Note'}</DialogTitle>
          <DialogDescription>Jot down a formula, theorem or reminder.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="note-title">Title</Label>
            <Input
              id="note-title"
              placeholder="e.g. Pythagoras theorem"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="note-chapter">Chapter</Label>
            <Select value={chapter} onValueChange={setChapter}>
              <SelectTrigger id="note-chapter" className="w-full">
                <SelectValue placeholder="Pick a chapter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="General">General</SelectItem>
                {chapters.map((c) => (
                  <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="note-content">Content</Label>
            <Textarea
              id="note-content"
              placeholder="Write your note here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={5}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Color</Label>
            <div className="flex flex-wrap gap-2">
              {colorOptions.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setColor(c.value)}
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-background transition-all',
                    color === c.value ? c.ring : 'ring-transparent',
                  )}
                  aria-label={c.label}
                >
                  <span className={cn('h-5 w-5 rounded-full', c.chip)} />
                </button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : editing ? 'Save Changes' : 'Save Note'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
