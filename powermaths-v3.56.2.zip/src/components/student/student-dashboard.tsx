'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import {
  Flame, BookOpen, BookCheck, Award, TrendingUp, Play, ArrowRight,
  Calendar, Clock, Megaphone, Trophy, Target, Sparkles, ChevronRight,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { useDataStore, getStudentProgress } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { StatCard } from '@/components/shared/stat-card'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useAssignedChapters, ChapterIcon } from './lib/student-helpers'
import { StudentMarketingBlock } from './student-marketing'
import { cn } from '@/lib/utils'

const weeklyActivity = [
  { day: 'Mon', study: 45, exams: 1 },
  { day: 'Tue', study: 60, exams: 0 },
  { day: 'Wed', study: 30, exams: 0 },
  { day: 'Thu', study: 75, exams: 1 },
  { day: 'Fri', study: 40, exams: 0 },
  { day: 'Sat', study: 90, exams: 1 },
  { day: 'Sun', study: 50, exams: 0 },
]

function greeting(): string {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

export function StudentDashboard() {
  const pageTitle = useNavLabel('dashboard', 'Dashboard', 'student')
  const user = useAppStore((s) => s.user)
  const setStudentPage = useAppStore((s) => s.setStudentPage)

  const chapters = useAssignedChapters()
  const results = useDataStore((s) => s.results)
  const certificates = useDataStore((s) => s.certificates)
  const announcements = useDataStore((s) => s.announcements)
  const marketingCampaigns = useDataStore((s) => s.marketingCampaigns)
  const students = useDataStore((s) => s.students)

  const myResults = React.useMemo(() => {
    if (!user) return []
    return results
      .filter((r) => r.studentId === user.id)
      .sort((a, b) => (b.createdAt + b.endTime).localeCompare(a.createdAt + a.endTime))
  }, [results, user])

  const myCerts = React.useMemo(() => {
    if (!user) return []
    return certificates.filter((c) => c.studentId === user.id && c.status === 'issued')
  }, [certificates, user])

  const progress = React.useMemo(() => (user ? getStudentProgress(user.id) : []), [user, results, chapters])

  const chaptersCompleted = progress.filter((p) => p && p.status === 'completed').length
  const examsCompleted = myResults.length
  const avgScore = myResults.length
    ? Math.round(myResults.reduce((a, r) => a + r.percentage, 0) / myResults.length)
    : 0
  const certCount = myCerts.length

  const recentResults = myResults.slice(0, 4)
  const activeAnnouncements = announcements
    .filter((a) => a.status === 'active' && (a.audience === 'all' || a.audience === 'students'))
    .slice(0, 3)

  // Resume learning = first in-progress chapter, else first not_started, else first chapter
  const resumeChapter = React.useMemo(() => {
    const inProgress = progress.find((p) => p && p.status === 'in_progress')
    if (inProgress) return inProgress.chapter
    const notStarted = progress.find((p) => p && p.status === 'not_started')
    if (notStarted) return notStarted.chapter
    return chapters[0] ?? null
  }, [progress, chapters])

  const resumeProgress = resumeChapter
    ? (progress.find((p) => p && p.chapter.id === resumeChapter.id)?.bestScore ?? 0)
    : 0

  const today = new Date()
  const formattedDate = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Your learning command center"
        icon={<Sparkles className="h-5 w-5" />}
        actions={
          <Button variant="outline" size="sm" onClick={() => setStudentPage('practice')}>
            <Play className="h-4 w-4" /> Quick Practice
          </Button>
        }
      />

      {/* Welcome Hero */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700 text-white shadow-lg">
          <div className="absolute inset-0 bg-grid-white/10 opacity-30" />
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-16 right-32 h-40 w-40 rounded-full bg-teal-300/20 blur-2xl" />
          <CardContent className="relative grid gap-6 p-6 sm:p-8 lg:grid-cols-[1.4fr_1fr]">
            <div className="flex flex-col justify-between gap-6">
              <div>
                <p className="text-sm font-medium text-emerald-50/90">{formattedDate}</p>
                <h2 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
                  {greeting()}, {user?.name?.split(' ')[0] ?? 'Student'} 👋
                </h2>
                <p className="mt-1.5 max-w-md text-sm text-emerald-50/85">
                  {chaptersCompleted === chapters.length && chapters.length > 0
                    ? 'Outstanding! You\'ve completed every chapter. Time to revise and aim higher.'
                    : 'Keep the momentum going — pick up where you left off and ace your next test.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 rounded-xl bg-white/15 px-3.5 py-2 backdrop-blur-sm">
                  <Flame className="h-5 w-5 text-amber-300" />
                  <div className="leading-tight">
                    <p className="text-lg font-bold tabular-nums">12 days</p>
                    <p className="text-[11px] text-emerald-50/80">Study streak</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 rounded-xl bg-white/15 px-3.5 py-2 backdrop-blur-sm">
                  <Trophy className="h-5 w-5 text-amber-300" />
                  <div className="leading-tight">
                    <p className="text-lg font-bold tabular-nums">#3</p>
                    <p className="text-[11px] text-emerald-50/80">Weekly rank</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 rounded-xl bg-white/15 px-3.5 py-2 backdrop-blur-sm">
                  <Clock className="h-5 w-5 text-emerald-100" />
                  <div className="leading-tight">
                    <p className="text-lg font-bold tabular-nums">48h</p>
                    <p className="text-[11px] text-emerald-50/80">Studied total</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Continue learning */}
            {resumeChapter ? (
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur-md ring-1 ring-white/20">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold uppercase tracking-wide text-emerald-50/80">
                    Continue learning
                  </p>
                  <Badge className="bg-amber-400/90 text-amber-950 hover:bg-amber-400">
                    {resumeProgress > 0 ? 'In progress' : 'Get started'}
                  </Badge>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/20">
                    <ChapterIcon name={resumeChapter.icon} className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-bold">{resumeChapter.name}</h3>
                </div>
                <p className="mt-1 text-xs text-emerald-50/80">
                  Chapter {resumeChapter.order} · {resumeChapter.description}
                </p>
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-50/80">Best score</span>
                    <span className="font-semibold">{resumeProgress}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-white/25">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${resumeProgress || 8}%` }}
                      transition={{ duration: 0.9, ease: 'easeOut' }}
                      className="h-full rounded-full bg-gradient-to-r from-amber-300 to-amber-400"
                    />
                  </div>
                </div>
                <Button
                  onClick={() => setStudentPage('chapters')}
                  className="mt-4 w-full bg-white text-emerald-700 hover:bg-emerald-50"
                  size="sm"
                >
                  <Play className="h-4 w-4" /> Resume Lesson
                </Button>
              </div>
            ) : (
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur-md ring-1 ring-white/20">
                <p className="text-sm text-emerald-50/90">No chapters assigned yet. Please contact your instructor.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* v3.50.0 — Marketing Campaigns. Admin-authored promotional banners,
          YouTube videos, and personalized text announcements targeted at all
          students, specific batches, or individual students. Rendered right
          after the welcome hero (the old hardcoded /branding/power-maths-banner.jpg
          static banner was removed in v3.53.0 — all dashboard promotions now
          flow through this single centralized Marketing module), in ascending
          priority order. The block is hidden entirely when no campaigns match
          this student.
          v3.52.0 — Text Banner campaigns with per-student personalization
          ({{student_name}}, {{level}}, …). The full Student object is passed
          so the text card can resolve placeholders.
          v3.53.0 — Text Banner footer now shows the administrator's profile
          photo + name/designation as a hand-signed institute message. */}
      <StudentMarketingBlock
        campaigns={marketingCampaigns}
        studentId={user?.id ?? ''}
        studentBatch={students.find((s) => s.id === user?.id)?.batch ?? user?.batch}
        student={students.find((s) => s.id === user?.id) ?? null}
      />

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Chapters Completed"
          value={`${chaptersCompleted}/${chapters.length || 0}`}
          subtitle="Mastery so far"
          icon={BookOpen}
          accent="emerald"
          trend={{ value: `+${Math.max(0, chaptersCompleted - 1)}`, positive: true }}
          delay={0.05}
        />
        <StatCard
          title="Exams Completed"
          value={examsCompleted}
          subtitle="Total attempts"
          icon={BookCheck}
          accent="teal"
          trend={{ value: `+${Math.min(2, examsCompleted)}`, positive: true }}
          delay={0.1}
        />
        <StatCard
          title="Average Score"
          value={`${avgScore}%`}
          subtitle="Across all exams"
          icon={Target}
          accent="amber"
          trend={{ value: `${avgScore >= 75 ? '+3%' : '0%'}`, positive: avgScore >= 75 }}
          delay={0.15}
        />
        <StatCard
          title="Certificates"
          value={certCount}
          subtitle="Earned & verified"
          icon={Award}
          accent="violet"
          trend={{ value: `+${Math.min(1, certCount)}`, positive: true }}
          delay={0.2}
        />
      </div>

      {/* 2-column: progress + activity */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Learning Progress */}
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" /> Learning Progress
            </CardTitle>
            <CardDescription>Per-chapter mastery so far</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3.5">
            {progress.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No chapters assigned yet.</p>
            ) : (
              progress.map((item, i) => {
                if (!item) return null
                const pct = item.status === 'completed' ? 100 : item.bestScore || 0
                return (
                  <motion.div
                    key={item.chapter.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.05 }}
                    className="group"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-xs font-bold text-primary">
                          {item.chapter.order}
                        </span>
                        <span className="truncate text-sm font-medium">{item.chapter.name}</span>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        {item.bestScore > 0 && (
                          <span className="text-xs font-semibold tabular-nums text-muted-foreground">
                            {item.bestScore}%
                          </span>
                        )}
                        <span className={cn(
                          'w-10 text-right text-sm font-bold tabular-nums',
                          pct === 100 && 'text-emerald-600 dark:text-emerald-400',
                          pct >= 50 && pct < 100 && 'text-amber-600 dark:text-amber-400',
                          pct > 0 && pct < 50 && 'text-orange-600 dark:text-orange-400',
                          pct === 0 && 'text-muted-foreground',
                        )}>
                          {pct}%
                        </span>
                      </div>
                    </div>
                    <Progress value={pct} className="mt-2 h-1.5" />
                  </motion.div>
                )
              })
            )}
          </CardContent>
        </Card>

        {/* Weekly Activity */}
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" /> Weekly Activity
            </CardTitle>
            <CardDescription>Study hours & exams per day</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyActivity} margin={{ top: 6, right: 8, left: -16, bottom: 0 }}>
                  <defs>
                    <linearGradient id="studyGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.45} />
                      <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="examGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip
                    contentStyle={{
                      background: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Area type="monotone" dataKey="study" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#studyGrad)" name="Study min" />
                  <Area type="monotone" dataKey="exams" stroke="#f59e0b" strokeWidth={2} fill="url(#examGrad)" name="Exams" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> Study minutes
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-500" /> Exams taken
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming exam + Rank */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[2fr_1fr]">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Calendar className="h-4 w-4 text-primary" /> Next Exam
            </CardTitle>
            <CardDescription>Your next available assessment</CardDescription>
          </CardHeader>
          <CardContent>
            <NextExamCard />
          </CardContent>
        </Card>

        {/* Rank card */}
        <Card className="card-elevated overflow-hidden">
          <div className="relative bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-transparent p-5">
            <div className="absolute right-3 top-3">
              <Trophy className="h-5 w-5 text-amber-500" />
            </div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Your Rank</p>
            <p className="mt-1 text-4xl font-bold tabular-nums text-amber-600 dark:text-amber-400">#3</p>
            <p className="text-xs text-muted-foreground">this week in your batch</p>

            {/* Mini podium */}
            <div className="mt-4 flex items-end justify-center gap-2">
              <div className="flex flex-col items-center">
                <Avatar className="h-7 w-7 border-2 border-zinc-300">
                  <AvatarFallback className="bg-zinc-200 text-[10px] text-zinc-700">DP</AvatarFallback>
                </Avatar>
                <div className="mt-1 h-8 w-9 rounded-t bg-zinc-300/70" />
                <span className="text-[10px] font-semibold text-muted-foreground">2</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="mb-0.5 rounded-full bg-amber-400 p-0.5">
                  <Trophy className="h-3 w-3 text-amber-950" />
                </div>
                <Avatar className="h-8 w-8 border-2 border-amber-400 ring-2 ring-amber-400/30">
                  <AvatarFallback className="bg-amber-100 text-[10px] font-bold text-amber-700">AS</AvatarFallback>
                </Avatar>
                <div className="mt-1 h-12 w-9 rounded-t bg-gradient-to-t from-amber-500 to-amber-400" />
                <span className="text-[10px] font-bold text-amber-600">1</span>
              </div>
              <div className="flex flex-col items-center">
                <Avatar className="h-7 w-7 border-2 border-orange-400/60">
                  <AvatarFallback className="bg-orange-100 text-[10px] text-orange-700">IV</AvatarFallback>
                </Avatar>
                <div className="mt-1 h-6 w-9 rounded-t bg-orange-400/60" />
                <span className="text-[10px] font-semibold text-muted-foreground">3</span>
              </div>
            </div>
            <p className="mt-3 text-center text-[11px] text-muted-foreground">
              1 more exam to reach <span className="font-semibold text-amber-600">#2</span>
            </p>
          </div>
        </Card>
      </div>

      {/* Recent results + Announcements */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card className="card-elevated">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Recent Results</CardTitle>
              <CardDescription>Your latest exam scores</CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setStudentPage('results')}>
              View all <ChevronRight className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentResults.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                No exam attempts yet. Try an available exam to see your scores here.
              </p>
            ) : (
              recentResults.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between gap-3 rounded-lg border bg-card px-3.5 py-2.5 transition-colors hover:bg-muted/40"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{r.examTitle}</p>
                    <p className="text-xs text-muted-foreground">
                      {r.marksObtained}/{r.totalMarks} · {r.createdAt}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-bold tabular-nums">{r.percentage}%</span>
                    <Badge
                      variant={r.status === 'passed' ? 'default' : 'destructive'}
                      className="text-[10px]"
                    >
                      {r.status === 'passed' ? 'Passed' : 'Failed'}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Megaphone className="h-4 w-4 text-primary" /> Announcements
            </CardTitle>
            <CardDescription>Latest from your instructor</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {activeAnnouncements.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No active announcements.</p>
            ) : (
              activeAnnouncements.map((a) => (
                <div
                  key={a.id}
                  className="flex items-start gap-3 rounded-lg border bg-card px-3.5 py-3 transition-colors hover:bg-muted/40"
                >
                  <span className={cn(
                    'mt-1.5 h-2 w-2 shrink-0 rounded-full',
                    a.priority === 'high' && 'bg-rose-500',
                    a.priority === 'normal' && 'bg-amber-500',
                    a.priority === 'low' && 'bg-emerald-500',
                  )} />
                  <div className="min-w-0">
                    <p className="text-sm font-medium leading-snug">{a.title}</p>
                    <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{a.body}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground/80">{a.author} · {a.createdAt}</p>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function NextExamCard() {
  const setStudentPage = useAppStore((s) => s.setStudentPage)
  const user = useAppStore((s) => s.user)
  const results = useDataStore((s) => s.results)
  const exams = useDataStore((s) => s.exams)
  const chapters = useAssignedChapters()

  const nextExam = React.useMemo(() => {
    if (!user) return null
    const assignedIds = new Set(chapters.map((c) => c.id))
    const passedExamIds = new Set(
      results.filter((r) => r.studentId === user.id && r.status === 'passed').map((r) => r.examId)
    )
    const candidate = exams
      .filter((e) => e.status === 'published' && assignedIds.has(e.chapterId) && !passedExamIds.has(e.id))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0]
    return candidate ?? null
  }, [user, results, exams, chapters])

  if (!nextExam) {
    return (
      <EmptyState
        icon={BookCheck}
        title="No exams available"
        description="You've passed every available exam. Browse your certificates."
        action={<Button size="sm" onClick={() => setStudentPage('certificates')}><Award className="h-4 w-4" /> View Certificates</Button>}
      />
    )
  }

  return (
    <div className="flex flex-col gap-4 rounded-xl border bg-muted/30 p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-start gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
          <BookCheck className="h-6 w-6" />
        </div>
        <div>
          <p className="font-semibold">{nextExam.title}</p>
          <p className="text-sm text-muted-foreground">{nextExam.chapterName} chapter</p>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {nextExam.duration} min</span>
            <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" /> {nextExam.marks} marks</span>
            <span className="flex items-center gap-1"><BookOpen className="h-3.5 w-3.5" /> {nextExam.questionIds.length} questions</span>
            <span className="flex items-center gap-1"><BookCheck className="h-3.5 w-3.5" /> {nextExam.passingPercentage}% to pass</span>
          </div>
        </div>
      </div>
      <Button onClick={() => setStudentPage('exams')} className="shrink-0">
        Start Exam <ArrowRight className="h-4 w-4" />
      </Button>
    </div>
  )
}
