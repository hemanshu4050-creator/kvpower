'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  Layers, Lock, CheckCircle2, Play, BookOpen,
  Trophy, ArrowRight, AlertCircle,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { useAppStore } from '@/lib/store'
import {
  useDataStore,
  type Batch,
  type Chapter,
  type Exam,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface LevelProgress {
  levelNumber: number
  batch: Batch
  totalChapters: number
  completedChapters: number
  remainingChapters: number
  examStatus: 'not_attempted' | 'failed' | 'passed'
  isUnlocked: boolean
  isCompleted: boolean
  progressPct: number
}

export function StudentLevels() {
  const pageTitle = useNavLabel('levels', 'Level / Batch', 'student')
  const setStudentPage = useAppStore((s) => s.setStudentPage)
  const user = useAppStore((s) => s.user)
  const students = useDataStore((s) => s.students)
  const batches = useDataStore((s) => s.batches)
  const chapters = useDataStore((s) => s.chapters)
  const exams = useDataStore((s) => s.exams)
  const results = useDataStore((s) => s.results)

  // ── Resolve the ordered learning path + per-level progress ──
  const levels = useMemo<LevelProgress[]>(() => {
    if (!user) return []
    const student = students.find((s) => s.id === user.id)
    if (!student) return []

    // Resolve the ordered learning path. If the student has assignedBatchIds
    // use them; otherwise derive: own batch first, then other active batches
    // sorted by name (matching the seed/migration strategy).
    const activeBatches = batches
      .filter((b) => b.status === 'active')
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
    const pathIds =
      student.assignedBatchIds && student.assignedBatchIds.length > 0
        ? student.assignedBatchIds
        : (() => {
            const own = activeBatches.find((b) => b.name === student.batch)
            const others = activeBatches.filter((b) => b.name !== student.batch)
            return own
              ? [own.id, ...others.map((b) => b.id)]
              : others.map((b) => b.id)
          })()

    const pathBatches = pathIds
      .map((id) => batches.find((b) => b.id === id))
      .filter((b): b is Batch => !!b)

    const studentResults = results.filter((r) => r.studentId === user.id)
    // A chapter is "completed" if the student has at least one passed Result
    // whose `chapterName` matches the chapter's `name` (mirrors
    // useChapterStatuses in src/components/student/lib/student-helpers.tsx).
    const completedChapterNames = new Set(
      studentResults
        .filter((r) => r.status === 'passed')
        .map((r) => r.chapterName)
    )

    const out: LevelProgress[] = pathBatches.map((batch, idx) => {
      const batchChapters = (batch.chapterIds || [])
        .map((cid) => chapters.find((c) => c.id === cid))
        .filter((c): c is Chapter => !!c)
      const totalChapters = batchChapters.length
      const completedChapters = batchChapters.filter((c) =>
        completedChapterNames.has(c.name)
      ).length
      const remainingChapters = Math.max(0, totalChapters - completedChapters)

      // Exam status: derived from results matching any exam in batch.examIds.
      // Passed if ANY passed result; Failed if results exist but none passed;
      // Not Attempted otherwise.
      const batchExamIds = batch.examIds || []
      void exams // exams kept in deps so the memo recomputes when exams change
      const examResults = studentResults.filter((r) =>
        batchExamIds.includes(r.examId)
      )
      let examStatus: 'not_attempted' | 'failed' | 'passed' = 'not_attempted'
      if (examResults.some((r) => r.status === 'passed')) examStatus = 'passed'
      else if (examResults.length > 0) examStatus = 'failed'

      const isThisLevelCompleted =
        totalChapters > 0 &&
        completedChapters === totalChapters &&
        examStatus === 'passed'

      const progressPct =
        totalChapters > 0
          ? Math.round((completedChapters / totalChapters) * 100)
          : 0

      return {
        levelNumber: idx + 1,
        batch,
        totalChapters,
        completedChapters,
        remainingChapters,
        examStatus,
        // placeholder — fixed in the second pass below
        isUnlocked: idx === 0,
        isCompleted: isThisLevelCompleted,
        progressPct,
      }
    })

    // Second pass: sequential unlock — Level N+1 is unlocked only when Level N
    // is fully completed (all chapters done AND exam passed).
    for (let i = 0; i < out.length; i++) {
      if (i === 0) {
        out[i].isUnlocked = true
      } else {
        out[i].isUnlocked = out[i - 1].isCompleted
      }
    }

    return out
  }, [user, students, batches, chapters, exams, results])

  // ── Summary stats ──
  const totalLevels = levels.length
  const completedLevels = levels.filter((l) => l.isCompleted).length
  const currentLevel =
    levels.find((l) => l.isUnlocked && !l.isCompleted)?.levelNumber ??
    (totalLevels > 0 ? totalLevels : 0)

  // ── Empty state ──
  if (totalLevels === 0) {
    return (
      <div className="space-y-6">
        <PageHeader
          title={pageTitle}
          description="Your sequential learning path — complete each level to unlock the next"
          icon={<Layers className="h-5 w-5" />}
        />
        <Card className="card-elevated">
          <CardContent className="p-0">
            <EmptyState
              icon={Layers}
              title="No levels assigned yet"
              description="Your learning path hasn't been configured. Please contact your administrator to get your levels assigned."
            />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Your sequential learning path — complete each level to unlock the next"
        icon={<Layers className="h-5 w-5" />}
        actions={
          <Badge variant="secondary" className="gap-1.5">
            <Trophy className="h-3.5 w-3.5 text-amber-500" />
            {completedLevels} of {totalLevels} completed
          </Badge>
        }
      />

      {/* Summary stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <SummaryStat
          icon={<Layers className="h-4 w-4" />}
          label="Total Levels"
          value={totalLevels}
          accent="emerald"
          delay={0.05}
        />
        <SummaryStat
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Completed Levels"
          value={completedLevels}
          accent="emerald"
          delay={0.1}
        />
        <SummaryStat
          icon={<Play className="h-4 w-4" />}
          label="Current Level"
          value={currentLevel > 0 ? `Level ${currentLevel}` : '—'}
          accent="amber"
          delay={0.15}
        />
      </div>

      {/* Level cards */}
      <div className="space-y-4">
        {levels.map((level, idx) => (
          <motion.div
            key={level.batch.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: idx * 0.05 }}
          >
            <LevelCard
              level={level}
              previousLevelNumber={idx > 0 ? levels[idx - 1].levelNumber : null}
              previousLevelChapters={idx > 0 ? levels[idx - 1].totalChapters : 0}
              onOpen={() => {
                toast.info(`Opening Level ${level.levelNumber} chapters…`)
                setStudentPage('chapters')
              }}
              onLockedClick={() =>
                toast.error(
                  `Level ${level.levelNumber} is locked. Complete Level ${level.levelNumber - 1} first.`
                )
              }
            />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

// ───────────────────────────────────────────────────────────────────
// Sub-components
// ───────────────────────────────────────────────────────────────────

function SummaryStat({
  icon,
  label,
  value,
  accent,
  delay,
}: {
  icon: React.ReactNode
  label: string
  value: number | string
  accent: 'emerald' | 'amber'
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
    >
      <Card className="card-elevated">
        <CardContent className="flex items-center gap-3 p-4">
          <div
            className={cn(
              'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
              accent === 'emerald'
                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
            )}
          >
            {icon}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {label}
            </p>
            <p className="text-lg font-bold tabular-nums leading-tight">{value}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

function LevelCard({
  level,
  previousLevelNumber,
  previousLevelChapters,
  onOpen,
  onLockedClick,
}: {
  level: LevelProgress
  previousLevelNumber: number | null
  previousLevelChapters: number
  onOpen: () => void
  onLockedClick: () => void
}) {
  const { batch, isUnlocked, isCompleted, progressPct } = level

  // Status badge + action button logic
  let statusBadge: React.ReactNode
  let actionButton: React.ReactNode

  if (!isUnlocked) {
    const tooltipText =
      previousLevelNumber !== null
        ? `Complete all ${previousLevelChapters} chapter${previousLevelChapters === 1 ? '' : 's'} and pass the exam in Level ${previousLevelNumber} to unlock Level ${level.levelNumber}`
        : 'Complete the previous level to unlock this one.'
    statusBadge = (
      <Badge variant="secondary" className="gap-1">
        <Lock className="h-3 w-3" /> Locked
      </Badge>
    )
    actionButton = (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button size="sm" variant="outline" onClick={onLockedClick}>
              <Lock className="h-4 w-4" /> Locked
            </Button>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs">
            <p>{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  } else if (isCompleted) {
    statusBadge = (
      <Badge className="gap-1 bg-emerald-500/15 text-emerald-700 hover:bg-emerald-500/15 dark:text-emerald-400">
        <CheckCircle2 className="h-3 w-3" /> Completed
      </Badge>
    )
    actionButton = (
      <Button size="sm" variant="outline" onClick={onOpen}>
        Review <ArrowRight className="h-3.5 w-3.5" />
      </Button>
    )
  } else {
    statusBadge = (
      <Badge className="gap-1 bg-amber-500/15 text-amber-700 hover:bg-amber-500/15 dark:text-amber-400">
        <AlertCircle className="h-3 w-3" /> In Progress
      </Badge>
    )
    actionButton = (
      <Button size="sm" onClick={onOpen}>
        <Play className="h-4 w-4" /> Continue Learning
        <ArrowRight className="h-3.5 w-3.5" />
      </Button>
    )
  }

  return (
    <Card
      className={cn(
        'card-elevated transition-all',
        !isUnlocked && 'opacity-60',
        isUnlocked && !isCompleted && 'hover:border-primary/40 hover:shadow-md',
      )}
    >
      <CardContent className="p-5 sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          {/* Left: level number + batch info */}
          <div className="flex items-start gap-4">
            <div
              className={cn(
                'flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-2xl text-center shadow-sm',
                isCompleted
                  ? 'bg-emerald-500 text-white'
                  : isUnlocked
                    ? 'bg-primary/10 text-primary'
                    : 'bg-muted text-muted-foreground'
              )}
            >
              <Layers className="h-4 w-4" />
              <span className="mt-0.5 text-xs font-bold tabular-nums leading-none">
                L{level.levelNumber}
              </span>
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base font-semibold leading-tight">
                  Level {level.levelNumber} — {batch.name}
                </h3>
                {batch.code && (
                  <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wide">
                    {batch.code}
                  </Badge>
                )}
              </div>
              <p className="mt-0.5 line-clamp-1 text-sm text-muted-foreground">
                {batch.description || `${batch.academicYear} cohort`}
              </p>

              {/* Stat row — locked levels show only Total Chapters + a Locked
                  hint instead of computed stats (which would be misleading
                  because exams/chapters are shared across batches). */}
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <BookOpen className="h-3.5 w-3.5" />
                  Total Chapters:{' '}
                  <span className="font-semibold tabular-nums text-foreground">
                    {level.totalChapters}
                  </span>
                </span>
                {isUnlocked ? (
                  <>
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Completed:{' '}
                      <span className="font-semibold tabular-nums text-foreground">
                        {level.completedChapters}/{level.totalChapters}
                      </span>
                    </span>
                    <span className="flex items-center gap-1">
                      Remaining:{' '}
                      <span className="font-semibold tabular-nums text-foreground">
                        {level.remainingChapters}
                      </span>
                    </span>
                    <span className="flex items-center gap-1">
                      Exam:{' '}
                      <ExamStatusBadge status={level.examStatus} />
                    </span>
                  </>
                ) : (
                  <span className="flex items-center gap-1 font-medium text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Locked — complete Level {level.levelNumber - 1} to unlock
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Right: status badge + action */}
          <div className="flex shrink-0 items-center gap-2 lg:flex-col lg:items-end lg:gap-2">
            {statusBadge}
            {actionButton}
          </div>
        </div>

        {/* Progress bar — locked levels show 0% / "Locked" */}
        <div className="mt-4 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              {!isUnlocked ? 'Locked' : isCompleted ? 'Completed' : 'Progress'}
            </span>
            <span className="font-semibold tabular-nums">
              {!isUnlocked ? '—' : `${progressPct}%`}
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: !isUnlocked ? '0%' : `${progressPct}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className={cn(
                'h-full rounded-full',
                isCompleted
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                  : isUnlocked
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                    : 'bg-muted-foreground/40'
              )}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ExamStatusBadge({ status }: { status: 'not_attempted' | 'failed' | 'passed' }) {
  if (status === 'passed')
    return (
      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
        Passed
      </span>
    )
  if (status === 'failed')
    return (
      <span className="font-semibold text-amber-600 dark:text-amber-400">
        Failed
      </span>
    )
  return <span className="font-medium text-muted-foreground">Not Attempted</span>
}
