'use client'

/**
 * StudentTheoryTextbook — the student-facing Theory textbook view.
 *
 * Renders inside the chapter learning page "Theory" tab. Shows every
 * non-hidden theory section in order as a premium digital textbook:
 *   • Chapter banner + reading progress indicator
 *   • Section navigation (sticky)
 *   • Beautiful content rendering (headings, bullets, callouts, math)
 *   • Reading-time tracker
 *   • Per-section read %
 *
 * DRM: copy/select/print/right-click all disabled via <DrmContent>.
 */

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  BookOpen, Clock, CheckCircle2, ChevronRight, ListTree,
  Sparkles, Lightbulb, AlertTriangle, Info,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { DrmContent } from '@/components/shared/drm-content'
import { KatexMath, renderInlineMath } from '@/components/shared/katex-math'
import { useAppStore } from '@/lib/store'
import { useLearningProgress } from '@/lib/learning-progress'
import type { TheorySection } from '@/lib/data-store'
import { cn } from '@/lib/utils'

interface StudentTheoryTextbookProps {
  chapterId: string
  chapterName: string
  theories: TheorySection[]
}

export function StudentTheoryTextbook({ chapterId, chapterName, theories }: StudentTheoryTextbookProps) {
  const user = useAppStore((s) => s.user)
  const updateTheoryReadProgress = useLearningProgress((s) => s.updateTheoryReadProgress)
  const progress = useLearningProgress((s) => s.chapters[`${user?.id}:${chapterId}`])

  const scrollRef = React.useRef<HTMLDivElement>(null)
  const [activeSectionId, setActiveSectionId] = React.useState<string | null>(null)

  const visibleSections = React.useMemo(
    () => [...theories].filter((t) => !t.hidden).sort((a, b) => a.order - b.order),
    [theories]
  )

  // Track reading progress as the student scrolls.
  React.useEffect(() => {
    const el = scrollRef.current
    if (!el || visibleSections.length === 0) return

    let lastUpdate = 0
    const onScroll = () => {
      const now = Date.now()
      // Throttle to once per 1s.
      if (now - lastUpdate < 1000) return
      lastUpdate = now

      const scrollTop = el.scrollTop
      const scrollHeight = el.scrollHeight - el.clientHeight
      const overallPercent = scrollHeight > 0 ? Math.min(100, Math.round((scrollTop / scrollHeight) * 100)) : 0

      // Find the currently-active section.
      let active: string | null = null
      for (const section of visibleSections) {
        const el2 = document.getElementById(`theory-${section.id}`)
        if (!el2) continue
        const rect = el2.getBoundingClientRect()
        if (rect.top < 200 && rect.bottom > 200) {
          active = section.id
          break
        }
      }
      if (active) setActiveSectionId(active)

      // Update progress for all sections up to and including the active one.
      if (user && active) {
        const activeIdx = visibleSections.findIndex((s) => s.id === active)
        visibleSections.forEach((section, idx) => {
          const sectionEl = document.getElementById(`theory-${section.id}`)
          if (!sectionEl) return
          const rect = sectionEl.getBoundingClientRect()
          // A section is "fully read" when its bottom has scrolled above 80% of viewport.
          const sectionPercent = Math.max(0, Math.min(100, Math.round(((window.innerHeight - rect.top) / rect.height) * 100)))
          const prevPct = progress?.theories?.[section.id]?.readPercent ?? 0
          const newPct = Math.max(prevPct, sectionPercent)
          if (newPct > prevPct) {
            updateTheoryReadProgress(user.id, chapterId, section.id, {
              readPercent: newPct,
              timeSpentDeltaSeconds: 1,
            })
          }
        })
        void activeIdx
        void overallPercent
      }
    }

    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [user, chapterId, visibleSections, progress, updateTheoryReadProgress])

  const totalRead = React.useMemo(() => {
    if (!progress?.theories || visibleSections.length === 0) return 0
    const sum = visibleSections.reduce((a, s) => a + (progress.theories[s.id]?.readPercent ?? 0), 0)
    return Math.round(sum / visibleSections.length)
  }, [visibleSections, progress])

  const sectionsRead = React.useMemo(() => {
    if (!progress?.theories) return 0
    return visibleSections.filter((s) => (progress.theories[s.id]?.readPercent ?? 0) >= 80).length
  }, [visibleSections, progress])

  // Estimate reading time: ~250 wpm, plus 30s per section.
  const estimatedMinutes = React.useMemo(() => {
    const words = visibleSections.reduce((a, s) => a + s.body.split(/\s+/).filter(Boolean).length, 0)
    return Math.max(1, Math.round(words / 250) + visibleSections.length * 0.5)
  }, [visibleSections])

  const watermark = user ? `${user.name} · ID: ${user.id}` : undefined

  if (visibleSections.length === 0) {
    return (
      <Card className="card-elevated">
        <CardContent className="p-5 sm:p-6">
          <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 px-4 py-10 text-center">
            <BookOpen className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
            <p className="text-sm font-medium">No theory sections yet</p>
            <p className="text-xs text-muted-foreground mt-1">
              Your teacher hasn't published any theory for this chapter yet. Check back soon!
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {/* Chapter banner */}
      <Card className="card-elevated overflow-hidden border-primary/20">
        <div className="relative bg-gradient-to-br from-emerald-500/10 via-primary/5 to-transparent">
          <CardContent className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary ring-1 ring-primary/20">
                  <BookOpen className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{chapterName} — Theory</h3>
                  <p className="mt-0.5 text-sm text-muted-foreground">
                    A structured digital textbook for this chapter. Read top to bottom for best results.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge variant="secondary" className="gap-1">
                      <BookOpen className="h-3 w-3" /> {visibleSections.length} sections
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <Clock className="h-3 w-3" /> ~{Math.round(estimatedMinutes)} min read
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <CheckCircle2 className="h-3 w-3 text-emerald-500" /> {sectionsRead}/{visibleSections.length} read
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Reading progress ring */}
              <div className="flex flex-col items-center">
                <div className="relative h-16 w-16">
                  <svg className="h-16 w-16 -rotate-90" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeWidth="4" className="text-muted/30" />
                    <circle
                      cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeWidth="4"
                      className="text-primary transition-all"
                      strokeDasharray={`${(totalRead / 100) * 176} 176`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-sm font-bold">{totalRead}%</span>
                  </div>
                </div>
                <p className="mt-1 text-[10px] uppercase tracking-wide text-muted-foreground">read</p>
              </div>
            </div>
          </CardContent>
        </div>
      </Card>

      {/* Two-column: sticky nav + content */}
      <div className="grid gap-3 lg:grid-cols-[200px_1fr]">
        {/* Section nav (sticky on lg+) */}
        <Card className="hidden lg:block lg:sticky lg:top-4 lg:self-start">
          <CardContent className="p-3">
            <p className="mb-2 flex items-center gap-1.5 px-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              <ListTree className="h-3 w-3" /> Sections
            </p>
            <nav className="space-y-0.5">
              {visibleSections.map((s, idx) => {
                const isActive = activeSectionId === s.id
                const sectionPct = progress?.theories?.[s.id]?.readPercent ?? 0
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      const el = document.getElementById(`theory-${s.id}`)
                      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
                    }}
                    className={cn(
                      'flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs transition-colors',
                      isActive ? 'bg-primary/10 font-medium text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                    )}
                  >
                    <span className={cn(
                      'flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[9px]',
                      sectionPct >= 80 ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' : 'bg-muted text-muted-foreground'
                    )}>
                      {sectionPct >= 80 ? '✓' : idx + 1}
                    </span>
                    <span className="flex-1 truncate">{s.title}</span>
                  </button>
                )
              })}
            </nav>
          </CardContent>
        </Card>

        {/* Theory content (DRM-protected, scrollable) */}
        <Card className="card-elevated">
          <div
            ref={scrollRef}
            className="max-h-[70vh] overflow-y-auto"
          >
            <DrmContent watermark={watermark} className="p-5 sm:p-6">
              {visibleSections.map((section, idx) => {
                const sectionPct = progress?.theories?.[section.id]?.readPercent ?? 0
                return (
                  <motion.section
                    key={section.id}
                    id={`theory-${section.id}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25, delay: idx * 0.05 }}
                    className={cn(
                      'mb-8 scroll-mt-4 rounded-xl border bg-card p-5',
                      sectionPct >= 80 ? 'border-emerald-500/30' : 'border-border/60'
                    )}
                  >
                    {/* Section header */}
                    <div className="mb-4 flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-sm font-bold text-primary">
                          {idx + 1}
                        </div>
                        <div>
                          <h4 className="text-base font-bold leading-tight">{section.title}</h4>
                          {sectionPct >= 80 && (
                            <Badge variant="outline" className="mt-1 h-4 gap-0.5 border-emerald-500/30 bg-emerald-500/10 px-1 text-[9px] text-emerald-600 dark:text-emerald-400">
                              <CheckCircle2 className="h-2.5 w-2.5" /> read
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Section banner image */}
                    {section.image && (
                      <div className="mb-4 overflow-hidden rounded-lg border">
                        <img src={section.image} alt={section.title} className="max-h-64 w-full object-cover" />
                      </div>
                    )}

                    {/* Section progress bar */}
                    {sectionPct > 0 && sectionPct < 100 && (
                      <div className="mb-3">
                        <Progress value={sectionPct} className="h-1" />
                      </div>
                    )}

                    {/* Body content */}
                    <TheoryBody body={section.body} />
                  </motion.section>
                )
              })}

              {/* Completion celebration */}
              {totalRead >= 100 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-5 text-center"
                >
                  <Sparkles className="mx-auto mb-2 h-8 w-8 text-emerald-500" />
                  <p className="text-sm font-semibold">Theory complete! 🎉</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    You've read all {visibleSections.length} sections. Move on to Materials and Practice to keep going.
                  </p>
                </motion.div>
              )}
            </DrmContent>
          </div>
        </Card>
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────────────────────
// TheoryBody — renders the markdown-ish body string
// ──────────────────────────────────────────────────────────────────────

function TheoryBody({ body }: { body: string }) {
  const lines = body.split('\n')
  const elements: React.ReactNode[] = []
  let i = 0
  let listBuffer: React.ReactNode[] = []
  let listType: 'ul' | 'ol' | null = null

  const flushList = (key: string) => {
    if (listBuffer.length === 0) return
    if (listType === 'ol') {
      elements.push(
        <ol key={key} className="my-2 space-y-1 pl-5">
          {listBuffer}
        </ol>
      )
    } else {
      elements.push(
        <ul key={key} className="my-2 space-y-1 pl-5">
          {listBuffer}
        </ul>
      )
    }
    listBuffer = []
    listType = null
  }

  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx]
    const trimmed = line.trim()

    if (!trimmed) {
      flushList(`fl${idx}`)
      continue
    }

    // Headings
    if (trimmed.startsWith('### ')) {
      flushList(`fl${idx}`)
      elements.push(<h5 key={`h${idx}`} className="mt-4 text-sm font-semibold text-foreground">{renderInlineMath(trimmed.slice(4))}</h5>)
      continue
    }
    if (trimmed.startsWith('## ')) {
      flushList(`fl${idx}`)
      elements.push(<h4 key={`h${idx}`} className="mt-5 text-base font-bold text-foreground">{renderInlineMath(trimmed.slice(3))}</h4>)
      continue
    }

    // Callout boxes
    if (trimmed.startsWith('> ')) {
      flushList(`fl${idx}`)
      const content = trimmed.slice(2).trim()
      const lower = content.toLowerCase()
      let cls = 'border-l-4 border-primary/50 bg-primary/5'
      let Icon = Info
      let label = 'Note'
      if (lower.startsWith('tip')) {
        cls = 'border-l-4 border-emerald-500/50 bg-emerald-500/5'
        Icon = Lightbulb; label = 'Tip'
      } else if (lower.startsWith('important')) {
        cls = 'border-l-4 border-amber-500/50 bg-amber-500/5'
        Icon = Info; label = 'Important'
      } else if (lower.startsWith('warning')) {
        cls = 'border-l-4 border-rose-500/50 bg-rose-500/5'
        Icon = AlertTriangle; label = 'Warning'
      }
      elements.push(
        <div key={`c${idx}`} className={cn('my-3 flex gap-3 rounded-md px-3 py-2.5', cls)}>
          <Icon className="mt-0.5 h-4 w-4 shrink-0 opacity-70" />
          <div className="flex-1">
            <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide opacity-70">{label}</p>
            <p className="text-xs leading-relaxed">{renderInlineMath(content)}</p>
          </div>
        </div>
      )
      continue
    }

    // Bullets
    if (trimmed.startsWith('- ')) {
      if (listType && listType !== 'ul') flushList(`fl${idx}`)
      listType = 'ul'
      listBuffer.push(
        <li key={`li${idx}`} className="flex gap-2 text-sm leading-relaxed">
          <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" />
          <span className="flex-1">{renderInlineMath(trimmed.slice(2))}</span>
        </li>
      )
      continue
    }

    // Numbered list
    const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/)
    if (numMatch) {
      if (listType && listType !== 'ol') flushList(`fl${idx}`)
      listType = 'ol'
      listBuffer.push(
        <li key={`li${idx}`} className="flex gap-2 text-sm leading-relaxed">
          <span className="font-semibold text-primary">{numMatch[1]}.</span>
          <span className="flex-1">{renderInlineMath(numMatch[2])}</span>
        </li>
      )
      continue
    }

    // Image
    const imgMatch = trimmed.match(/^!\[([^\]]*)\]\(([^)]+)\)$/)
    if (imgMatch) {
      flushList(`fl${idx}`)
      elements.push(
        <figure key={`img${idx}`} className="my-3">
          <img src={imgMatch[2]} alt={imgMatch[1]} className="max-h-72 w-full rounded-lg border object-cover" />
          {imgMatch[1] && <figcaption className="mt-1 text-center text-[11px] text-muted-foreground">{imgMatch[1]}</figcaption>}
        </figure>
      )
      continue
    }

    // Display math $$...$$
    if (trimmed.startsWith('$$') && trimmed.endsWith('$$')) {
      flushList(`fl${idx}`)
      elements.push(
        <div key={`dm${idx}`} className="my-3 overflow-x-auto rounded-md bg-muted/30 px-4 py-3 text-center">
          <KatexMath expression={trimmed.slice(2, -2)} display />
        </div>
      )
      continue
    }

    // Default paragraph
    flushList(`fl${idx}`)
    elements.push(
      <p key={`p${idx}`} className="my-2 text-sm leading-relaxed text-foreground/90">
        {renderInlineMath(trimmed)}
      </p>
    )
  }
  flushList('fl-end')

  return <div className="theory-body">{elements}</div>
}
