'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  PenTool, FileQuestion, Eye, Play, Sparkles, Clock, CheckCircle2,
  TrendingUp, Target, CheckCircle, CircleDot, Lock,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAssignedChapters, useChapterStatuses } from './lib/student-helpers'
import { SecurePdfViewer } from './lib/secure-pdf-viewer'
import { useAppStore } from '@/lib/store'
import { useLearningProgress } from '@/lib/learning-progress'
import { usePdfPages, PdfLoadingPlaceholder } from '@/hooks/use-pdf-pages'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import type { Chapter } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'

type Difficulty = 'Easy' | 'Medium' | 'Hard'

interface PracticeSheetItem {
  id: string
  title: string
  chapterId: string
  chapterName: string
  chapter: Chapter
  difficulty: Difficulty
  questions: number
  estimated: number
  hasSolution: boolean
  fileData?: string
  solutionFileData?: string
  order: number
}

const diffColor: Record<Difficulty, string> = {
  Easy: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400',
  Medium: 'bg-amber-500/15 text-amber-700 dark:text-amber-400',
  Hard: 'bg-rose-500/15 text-rose-700 dark:text-rose-400',
}

function difficultyFor(idx: number): Difficulty {
  return (['Easy', 'Medium', 'Hard'] as Difficulty[])[idx % 3]
}

export function StudentPractice() {
  const pageTitle = useNavLabel('practice', 'Practice', 'student')
  const chapters = useAssignedChapters()
  // Chapter statuses drive the lock/unlock UI — a practice sheet for a
  // chapter that hasn't been unlocked yet (i.e. the previous chapter isn't
  // complete) is shown in a locked state, mirroring the My Chapters page.
  const chapterStatuses = useChapterStatuses()
  const lockedChapterIds = React.useMemo(() => {
    const set = new Set<string>()
    for (const cs of chapterStatuses) {
      if (cs.isLocked) set.add(cs.chapter.id)
    }
    return set
  }, [chapterStatuses])
  const user = useAppStore((s) => s.user)
  const [chapterFilter, setChapterFilter] = React.useState<string>('all')
  const [tab, setTab] = React.useState('all')

  // Subscribe to learning-progress changes so the cards re-render when a
  // student starts / completes a practice sheet.
  const progressChapters = useLearningProgress((s) => s.chapters)

  // ── PDF viewer state (FIX: Start Practice now actually opens the sheet) ──
  const [viewerState, setViewerState] = React.useState<{
    title: string
    fileData?: string
    fallbackPages: { content: React.ReactNode }[]
    documentId: string
    chapterId: string
    practiceId: string
    totalQuestions: number
  } | null>(null)

  const { pages: pdfPages, loading: pdfLoading, error: pdfError } =
    usePdfPages(viewerState?.fileData)

  React.useEffect(() => {
    if (pdfError && viewerState) {
      toast.error('Could not render this practice sheet', {
        description: 'Showing a preview instead.',
      })
    }
  }, [pdfError, viewerState])

  const viewerPages = React.useMemo<{ content: React.ReactNode }[]>(() => {
    if (!viewerState) return []
    if (!viewerState.fileData) return viewerState.fallbackPages
    if (pdfError) return viewerState.fallbackPages
    if (pdfLoading || pdfPages.length === 0) {
      return [{ content: <PdfLoadingPlaceholder label="Loading practice sheet…" /> }]
    }
    return pdfPages
  }, [viewerState, pdfPages, pdfLoading, pdfError])

  const practiceSheets: PracticeSheetItem[] = React.useMemo(() => {
    return chapters.flatMap((c) => {
      return c.practiceSheets.map((p, i) => ({
        id: p.id,
        title: p.title || `${c.name} — Sheet ${i + 1}`,
        chapterId: c.id,
        chapterName: c.name,
        chapter: c,
        difficulty: difficultyFor(i),
        questions: 8 + i * 3,
        estimated: 15 + i * 5,
        hasSolution: p.hasSolution,
        fileData: p.fileData,
        solutionFileData: p.solutionFileData,
        order: p.order,
      }))
    })
  }, [chapters])

  const filtered = React.useMemo(() => {
    let list = practiceSheets
    if (chapterFilter !== 'all') list = list.filter((p) => p.chapterId === chapterFilter)
    if (tab === 'easy') list = list.filter((p) => p.difficulty === 'Easy')
    if (tab === 'medium') list = list.filter((p) => p.difficulty === 'Medium')
    if (tab === 'hard') list = list.filter((p) => p.difficulty === 'Hard')
    return list
  }, [practiceSheets, chapterFilter, tab])

  // Recommended = Trigonometry (or the lowest-order in-progress chapter) sheets
  const recommended = React.useMemo(() => {
    if (chapters.length === 0) return []
    const target = chapters.find((c) => c.id === 'CH004') ?? chapters[Math.min(3, chapters.length - 1)]
    return practiceSheets.filter((p) => p.chapterId === target.id).slice(0, 2)
  }, [practiceSheets, chapters])

  // ── FIX: Start Practice actually opens the practice sheet in the viewer ──
  const startPractice = (sheet: PracticeSheetItem) => {
    if (!user) return
    // Build fallback pages for the practice sheet (used when no PDF is uploaded).
    const fallbackPages = Array.from({ length: 4 }).map((_, i) => ({
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h2 className="font-serif text-xl font-bold">{sheet.title}</h2>
              <p className="text-xs text-muted-foreground">
                {sheet.chapterName} · Practice Sheet · Page {i + 1} of 4
              </p>
            </div>
            <div className="text-right text-[10px] uppercase tracking-wider text-muted-foreground">
              Power Maths<br />by Prof. Kalpesh Vyas
            </div>
          </div>
          {Array.from({ length: 4 }).map((_, q) => {
            const qNum = i * 4 + q + 1
            return (
              <div key={q} className="space-y-2">
                <p className="text-sm font-medium">
                  Q{qNum}. Solve the following:
                </p>
                <div className="h-3 w-full rounded bg-muted/70" />
                <div className="h-3 w-4/5 rounded bg-muted/70" />
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {['(a)', '(b)', '(c)', '(d)'].map((opt) => (
                    <div key={opt} className="rounded border bg-muted/30 px-2 py-1 text-xs">
                      <span className="font-medium">{opt}</span> <span className="text-muted-foreground">option</span>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
          <p className="border-t pt-2 text-center text-[10px] text-muted-foreground">
            © Power Maths · Confidential · for the personal use of {user.name} only
          </p>
        </div>
      ),
    }))

    // Mark the practice as started in the learning-progress store.
    useLearningProgress.getState().startPractice(
      user.id, sheet.chapterId, sheet.id, sheet.questions
    )

    setViewerState({
      title: sheet.title,
      fileData: sheet.fileData,
      fallbackPages,
      documentId: sheet.id,
      chapterId: sheet.chapterId,
      practiceId: sheet.id,
      totalQuestions: sheet.questions,
    })

    toast.success(`Practice started: ${sheet.title}`, {
      description: `${sheet.questions} questions · progress is being tracked.`,
    })
  }

  const openSolutions = (sheet: PracticeSheetItem) => {
    if (!user) return
    const fallbackPages = Array.from({ length: 3 }).map((_, i) => ({
      content: (
        <div className="space-y-4">
          <div className="border-b pb-3">
            <h2 className="font-serif text-xl font-bold">{sheet.title} — Solutions</h2>
            <p className="text-xs text-muted-foreground">{sheet.chapterName} · Page {i + 1} of 3</p>
          </div>
          {Array.from({ length: 4 }).map((_, q) => (
            <div key={q} className="space-y-1.5">
              <p className="text-sm font-medium">Solution {i * 4 + q + 1}</p>
              <div className="h-3 w-full rounded bg-muted/70" />
              <div className="h-3 w-4/5 rounded bg-muted/70" />
              <div className="rounded bg-emerald-500/5 px-2 py-1 text-xs text-emerald-700 dark:text-emerald-400">
                Answer: <span className="font-mono">42</span>
              </div>
            </div>
          ))}
        </div>
      ),
    }))
    setViewerState({
      title: `${sheet.title} — Solutions`,
      fileData: sheet.solutionFileData,
      fallbackPages,
      documentId: `${sheet.id}-sol`,
      chapterId: sheet.chapterId,
      practiceId: `${sheet.id}-sol`,
      totalQuestions: sheet.questions,
    })
  }

  if (chapters.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeader title={pageTitle} description="Sharpen your skills with chapter-wise practice sheets" icon={<PenTool className="h-5 w-5" />} />
        <Card><CardContent><EmptyState icon={PenTool} title="No chapters assigned" description="Practice sheets become available once a chapter is assigned to you." /></CardContent></Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Sharpen your skills with chapter-wise practice sheets"
        icon={<PenTool className="h-5 w-5" />}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success('Generating a smart practice set...', { description: 'Pick any sheet below to start now.' })}>
            <Sparkles className="h-4 w-4" /> Smart Practice
          </Button>
        }
      />

      {/* Recommended for you */}
      {recommended.length > 0 && (
        <Card className="card-elevated overflow-hidden border-primary/30">
          <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
            <div className="absolute right-4 top-4 hidden sm:block">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Target className="h-4 w-4 text-primary" /> Recommended for you
              </CardTitle>
              <CardDescription>Hand-picked sheets for your focus areas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2">
                {recommended.map((sheet) => {
                  const isChapterLocked = lockedChapterIds.has(sheet.chapterId)
                  return (
                    <div
                      key={sheet.id}
                      className={cn(
                        'flex items-center justify-between gap-3 rounded-xl border bg-background/70 p-3.5 backdrop-blur-sm',
                        isChapterLocked && 'opacity-70',
                      )}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={cn(
                          'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
                          isChapterLocked
                            ? 'bg-muted text-muted-foreground'
                            : 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
                        )}>
                          {isChapterLocked ? <Lock className="h-5 w-5" /> : <FileQuestion className="h-5 w-5" />}
                        </div>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold">{sheet.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {sheet.questions} questions · {sheet.estimated} min
                          </p>
                        </div>
                      </div>
                      {isChapterLocked ? (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button size="sm" variant="outline" disabled className="shrink-0 gap-1.5">
                                <Lock className="h-4 w-4" /> Locked
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Complete the previous chapter first to unlock this sheet.</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => startPractice(sheet)}
                          className="shrink-0"
                        >
                          <Play className="h-4 w-4" /> Start
                        </Button>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </div>
        </Card>
      )}

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="easy">Easy</TabsTrigger>
            <TabsTrigger value="medium">Medium</TabsTrigger>
            <TabsTrigger value="hard">Hard</TabsTrigger>
          </TabsList>
        </Tabs>
        <Select value={chapterFilter} onValueChange={setChapterFilter}>
          <SelectTrigger className="w-full sm:w-[220px]">
            <SelectValue placeholder="Filter by chapter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All chapters</SelectItem>
            {chapters.map((c) => (
              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Practice grid */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState icon={PenTool} title="No practice sheets match your filters" description="Try adjusting chapter or difficulty." />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((sheet, i) => {
            // Read live progress for this practice sheet (subscribed via
            // `progressChapters` above so the UI re-renders on change).
            const progressKey = `${user?.id}:${sheet.chapterId}`
            const progress = progressChapters[progressKey]
            const pp = progress?.practice[sheet.id]
            const status = pp?.status ?? 'not_started'
            const attempted = pp?.attempted ?? 0
            const isCompleted = status === 'completed'
            const isInProgress = status === 'in_progress'
            // A sheet is locked when its parent chapter hasn't been unlocked
            // yet (previous chapter not completed). The student can still
            // SEE the sheet (so they know what's coming) but can't open it.
            const isChapterLocked = lockedChapterIds.has(sheet.chapterId)

            return (
              <motion.div
                key={sheet.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.04 }}
              >
                <Card className={cn(
                  'card-elevated h-full transition-all',
                  isChapterLocked
                    ? 'opacity-70'
                    : 'hover:-translate-y-0.5 hover:shadow-md',
                )}>
                  <CardContent className="flex h-full flex-col p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div className={cn(
                        'flex h-11 w-11 items-center justify-center rounded-xl',
                        isChapterLocked ? 'bg-muted text-muted-foreground'
                          : isCompleted ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                          : isInProgress ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          : 'bg-primary/10 text-primary'
                      )}>
                        {isChapterLocked ? <Lock className="h-5 w-5" />
                          : isCompleted ? <CheckCircle className="h-5 w-5" />
                          : isInProgress ? <CircleDot className="h-5 w-5" />
                          : <FileQuestion className="h-5 w-5" />}
                      </div>
                      <div className="flex items-center gap-1.5">
                        {isChapterLocked && (
                          <Badge variant="secondary" className="gap-1 text-[10px]">
                            <Lock className="h-2.5 w-2.5" /> Locked
                          </Badge>
                        )}
                        <Badge className={cn('text-[10px]', diffColor[sheet.difficulty])}>
                          {sheet.difficulty}
                        </Badge>
                      </div>
                    </div>
                    <h3 className="mt-3 font-semibold leading-snug">{sheet.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{sheet.chapterName}</p>

                    <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><FileQuestion className="h-3.5 w-3.5" /> {sheet.questions} Qs</span>
                      <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {sheet.estimated} min</span>
                    </div>

                    {!isChapterLocked && (isInProgress || isCompleted) && (
                      <div className="mt-3 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                          <span>{isCompleted ? 'Completed' : 'Progress'}</span>
                          <span className="tabular-nums">{attempted}/{sheet.questions}</span>
                        </div>
                        <Progress
                          value={Math.min(100, Math.round((attempted / sheet.questions) * 100))}
                          className="h-1"
                        />
                      </div>
                    )}

                    <div className="mt-auto flex items-center gap-2 pt-4">
                      {isChapterLocked ? (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button size="sm" variant="outline" disabled className="flex-1 gap-1.5">
                                <Lock className="h-4 w-4" /> Locked
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Complete the previous chapter first to unlock this practice sheet.</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ) : (
                        <Button
                          size="sm"
                          className="flex-1 gap-1.5"
                          onClick={() => startPractice(sheet)}
                        >
                          <Play className="h-4 w-4" />
                          {isCompleted ? 'Review' : isInProgress ? 'Continue' : 'Start Practice'}
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={!sheet.hasSolution || isChapterLocked}
                        onClick={() => openSolutions(sheet)}
                        className="gap-1.5"
                      >
                        <Eye className="h-4 w-4" /> Solutions
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Recent attempts (computed from practiceSheets mock) */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="h-4 w-4 text-primary" /> Practice Tips
          </CardTitle>
          <CardDescription>Make the most of every session</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
            <p>Attempt the practice sheet first, then check the solution only after submitting.</p>
          </div>
          <div className="flex items-start gap-2">
            <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
            <p>Time yourself — most sheets are designed for the estimated time shown.</p>
          </div>
          <div className="flex items-start gap-2">
            <Target className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <p>Focus on weaker chapters first; your dashboard highlights in-progress chapters.</p>
          </div>
        </CardContent>
      </Card>

      {/* Secure PDF viewer — the only popup in this flow */}
      <SecurePdfViewer
        open={!!viewerState}
        onOpenChange={(o) => !o && setViewerState(null)}
        title={viewerState?.title ?? ''}
        pages={viewerPages}
        studentName={user?.name}
        studentEmail={user?.email}
        studentId={user?.id}
        chapterId={viewerState?.chapterId}
        materialId={viewerState?.practiceId}
        documentId={viewerState?.documentId}
        trackAsPractice
        totalPracticeQuestions={viewerState?.totalQuestions}
        onProgress={(info) => {
          if (!user || !viewerState) return
          // Compute the time delta from the previously-stored value so we
          // don't double-count time on each throttled flush.
          const k = `${user.id}:${viewerState.chapterId}`
          const prev = useLearningProgress.getState().chapters[k]
          const prevTime = prev?.practice[viewerState.practiceId]?.timeSpentSeconds ?? 0
          const delta = Math.max(0, info.timeSpentSeconds - prevTime)
          if (delta > 0) {
            useLearningProgress.getState().updatePracticeProgress(
              user.id, viewerState.chapterId, viewerState.practiceId,
              { timeSpentDeltaSeconds: delta }
            )
          }
        }}
      />
    </div>
  )
}
