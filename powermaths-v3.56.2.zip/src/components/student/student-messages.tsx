'use client'

import * as React from 'react'
import {
  MessageSquare, Plus, Send, Inbox, ArrowLeft, Mail, Search, Loader2,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { useDataStore, type Message } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { initialsOf } from './lib/student-helpers'
import { MathInput, MessageBody } from '@/components/shared/math-input'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

const TEACHER = 'Prof. Kalpesh Vyas'

export function StudentMessages() {
  const pageTitle = useNavLabel('messages', 'Messages', 'student')
  const user = useAppStore((s) => s.user)
  const messages = useDataStore((s) => s.messages)
  const sendMessage = useDataStore((s) => s.sendMessage)
  const markMessageRead = useDataStore((s) => s.markMessageRead)
  // v3.34 — admin's uploaded profile photo (settings.adminPhoto) so the
  // student sees Prof. Kalpesh's real photo instead of "PK" initials on
  // messages the teacher sent (direction='in').
  const adminPhoto = useDataStore((s) => s.settings.adminPhoto)

  const [selectedId, setSelectedId] = React.useState<string | null>(null)
  const [mobileDetail, setMobileDetail] = React.useState(false)
  const [composeOpen, setComposeOpen] = React.useState(false)
  const [search, setSearch] = React.useState('')

  const myMessages = React.useMemo(() => {
    if (!user) return []
    return messages
      .filter((m) => m.studentId === user.id)
      .slice()
      .reverse() // newest first assuming store appends
  }, [messages, user])

  const unreadCount = myMessages.filter((m) => !m.read && m.direction === 'in').length

  const filtered = React.useMemo(() => {
    return myMessages.filter((m) =>
      m.subject.toLowerCase().includes(search.toLowerCase()) ||
      m.from.toLowerCase().includes(search.toLowerCase()) ||
      m.preview.toLowerCase().includes(search.toLowerCase())
    )
  }, [myMessages, search])

  const selected = myMessages.find((m) => m.id === selectedId) ?? filtered[0] ?? null

  const handleSelect = (id: string) => {
    setSelectedId(id)
    setMobileDetail(true)
    const m = myMessages.find((mm) => mm.id === id)
    if (m && !m.read) markMessageRead(id)
  }

  const handleReply = (body: string) => {
    if (!user || !selected) return
    const to = selected.direction === 'in' ? selected.from : selected.to
    sendMessage({
      studentId: user.id,
      from: user.name,
      to,
      subject: selected.subject.startsWith('Re:') ? selected.subject : `Re: ${selected.subject}`,
      body,
      preview: body.slice(0, 80),
    })
    toast.success('Reply sent!')
  }

  const handleCompose = (subject: string, body: string) => {
    if (!user) return
    sendMessage({
      studentId: user.id,
      from: user.name,
      to: TEACHER,
      subject,
      body,
      preview: body.slice(0, 80),
    })
    setComposeOpen(false)
    toast.success('Message sent!')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Chat with your instructor"
        icon={<MessageSquare className="h-5 w-5" />}
        actions={
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Badge variant="destructive" className="gap-1">
                <Inbox className="h-3 w-3" /> {unreadCount} unread
              </Badge>
            )}
            <Button size="sm" onClick={() => setComposeOpen(true)}>
              <Plus className="h-4 w-4" /> New Message
            </Button>
          </div>
        }
      />

      <Card className="card-elevated overflow-hidden p-0">
        <CardContent className="grid h-[calc(100vh-220px)] min-h-[500px] grid-cols-1 p-0 md:grid-cols-[320px_1fr]">
          {/* Message list */}
          <div className={cn(
            'flex flex-col border-r',
            mobileDetail && 'hidden md:flex',
          )}>
            <div className="border-b p-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search messages..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="h-9 pl-8"
                />
              </div>
            </div>
            {/* v3.35 — Use a native scrollable div instead of ScrollArea so
                the full message history is reachable. ScrollArea's fixed
                viewport was clipping older messages on short screens. */}
            <div className="flex-1 overflow-y-auto">
              <div className="space-y-0.5 p-2">
                {filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Mail className="h-8 w-8 text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">No messages found</p>
                  </div>
                ) : (
                  filtered.map((m) => {
                    const isSel = selected?.id === m.id
                    const isUnread = !m.read && m.direction === 'in'
                    return (
                      <button
                        key={m.id}
                        onClick={() => handleSelect(m.id)}
                        className={cn(
                          'flex w-full items-start gap-3 rounded-lg p-3 text-left transition-colors',
                          isSel ? 'bg-primary/10' : 'hover:bg-muted/60',
                        )}
                      >
                        <div className="relative">
                          <Avatar className="h-9 w-9">
                            {m.direction === 'in' && adminPhoto ? (
                              <AvatarImage src={adminPhoto} alt={m.from} />
                            ) : null}
                            <AvatarFallback className={cn(
                              'text-xs font-semibold',
                              m.direction === 'in'
                                ? 'bg-primary/15 text-primary'
                                : 'bg-muted text-muted-foreground',
                            )}>
                              {initialsOf(m.direction === 'in' ? m.from : m.to)}
                            </AvatarFallback>
                          </Avatar>
                          {isUnread && (
                            <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-background" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <p className={cn(
                              'truncate text-sm',
                              isUnread ? 'font-semibold' : 'font-medium',
                            )}>
                              {m.direction === 'in' ? m.from : `To: ${m.to}`}
                            </p>
                            <span className="shrink-0 text-[11px] text-muted-foreground">{m.time}</span>
                          </div>
                          <p className={cn(
                            'truncate text-xs',
                            isUnread ? 'font-medium text-foreground' : 'text-muted-foreground',
                          )}>
                            {m.subject}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">{m.preview}</p>
                        </div>
                      </button>
                    )
                  })
                )}
              </div>
            </div>
          </div>

          {/* Detail pane (desktop) */}
          <div className="hidden flex-col md:flex">
            {selected ? (
              <MessageDetail message={selected} adminPhoto={adminPhoto} onReply={handleReply} onBack={() => setMobileDetail(false)} showBack={false} />
            ) : (
              <div className="flex flex-1 flex-col items-center justify-center text-center">
                <MessageSquare className="h-12 w-12 text-muted-foreground/50" />
                <p className="mt-3 text-sm font-medium">Select a message to read</p>
                <p className="text-xs text-muted-foreground">Your conversation appears here</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Mobile detail sheet */}
      <Sheet open={mobileDetail && !!selected} onOpenChange={(o) => !o && setMobileDetail(false)}>
        <SheetContent side="bottom" className="h-[90vh] p-0">
          <SheetHeader className="sr-only">
            <SheetTitle>Message</SheetTitle>
          </SheetHeader>
          {selected && (
            <MessageDetail message={selected} adminPhoto={adminPhoto} onReply={handleReply} onBack={() => setMobileDetail(false)} showBack />
          )}
        </SheetContent>
      </Sheet>

      <ComposeDialog open={composeOpen} onOpenChange={setComposeOpen} onSend={handleCompose} />
    </div>
  )
}

function MessageDetail({
  message, adminPhoto, onReply, onBack, showBack,
}: {
  message: Message
  adminPhoto?: string
  onReply: (body: string) => void
  onBack: () => void
  showBack: boolean
}) {
  const [reply, setReply] = React.useState('')
  const [sending, setSending] = React.useState(false)

  const handleSend = () => {
    if (!reply.trim()) {
      toast.error('Reply cannot be empty')
      return
    }
    setSending(true)
    setTimeout(() => {
      onReply(reply.trim())
      setReply('')
      setSending(false)
    }, 400)
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex items-start gap-3 border-b p-4">
        {showBack && (
          <Button variant="ghost" size="icon" className="md:hidden" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}
        <Avatar className="h-10 w-10">
          {message.direction === 'in' && adminPhoto ? (
            <AvatarImage src={adminPhoto} alt={message.from} />
          ) : null}
          <AvatarFallback className={cn(
            'text-xs font-semibold',
            message.direction === 'in'
              ? 'bg-primary/15 text-primary'
              : 'bg-muted text-muted-foreground',
          )}>
            {initialsOf(message.direction === 'in' ? message.from : message.to)}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="font-semibold">{message.direction === 'in' ? message.from : `To: ${message.to}`}</p>
          <p className="text-xs text-muted-foreground">{message.time}</p>
        </div>
      </div>

      {/* Body — native scroll so long messages never get clipped */}
      <div className="flex-1 overflow-y-auto">
        <div className="space-y-4 p-4">
          <div>
            <h3 className="text-lg font-semibold">{message.subject}</h3>
          </div>
          <div className="rounded-xl border bg-muted/30 p-4">
            <MessageBody body={message.body} />
          </div>
        </div>
      </div>

      {/* Reply box (math-aware) */}
      <div className="border-t p-3">
        <MathInput
          placeholder="Write a reply... (use $...$ for math, e.g. $\sqrt{x+1}$)"
          value={reply}
          onChange={setReply}
          rows={2}
          showPreviewToggle={false}
        />
        <div className="mt-2 flex justify-end">
          <Button size="sm" onClick={handleSend} disabled={sending} className="gap-1.5">
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            {sending ? 'Sending…' : 'Send Reply'}
          </Button>
        </div>
      </div>
    </div>
  )
}

function ComposeDialog({
  open, onOpenChange, onSend,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  onSend: (subject: string, body: string) => void
}) {
  const [subject, setSubject] = React.useState('')
  const [body, setBody] = React.useState('')
  const [sending, setSending] = React.useState(false)

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()
    if (!subject.trim() || !body.trim()) {
      toast.error('Subject and body are required')
      return
    }
    setSending(true)
    setTimeout(() => {
      onSend(subject.trim(), body.trim())
      setSubject('')
      setBody('')
      setSending(false)
    }, 400)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Message</DialogTitle>
          <DialogDescription>Send a message to {TEACHER}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSend} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="msg-to">To</Label>
            <Input id="msg-to" value={TEACHER} readOnly className="bg-muted/40" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="msg-subject">Subject</Label>
            <Input
              id="msg-subject"
              placeholder="What's this about?"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="msg-body">Message</Label>
            <MathInput
              placeholder="Type your message... (use $...$ for math, e.g. $x^2 + 2x + 1$)"
              value={body}
              onChange={setBody}
              rows={5}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={sending}>
              {sending ? 'Sending...' : 'Send Message'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
