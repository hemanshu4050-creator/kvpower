'use client'

/**
 * Exam Proctoring — lockdown mode, violation tracking, browser fingerprinting
 * and question-pool selection for Power Maths "Pro" exams.
 *
 * Features:
 *   • Lockdown browser mode (fullscreen request, copy/cut/right-click/drag blocked)
 *   • Tab-switch / window-blur detection with a 3-strike auto-submit
 *   • Fullscreen-exit detection (counts as a violation)
 *   • Browser fingerprint generation (canvas + navigator + screen + timezone)
 *   • Per-student fingerprint persistence — flags if a different device is used
 *   • Question-pool selection — pick N random questions from a pool of M
 *
 * No data leaves the browser. All fingerprint comparison is local.
 */

import * as React from 'react'

// ─────────────────────────── Fingerprinting ───────────────────────────

/**
 * Generate a stable browser fingerprint. Combines:
 *   • Canvas rendering hash (catches different GPUs / rendering engines)
 *   • Navigator info (UA, platform, language, cores, memory)
 *   • Screen info (resolution, colour depth, pixel ratio)
 *   • Timezone
 *
 * Returns a short hex string. NOT cryptographically unique — it is meant to
 * detect "is this the same device as last time", not to identify a person.
 */
export function generateFingerprint(): string {
  if (typeof window === 'undefined') return 'server'

  const parts: string[] = []

  // Navigator
  const n = navigator
  parts.push(n.userAgent || '')
  parts.push(n.platform || '')
  parts.push(n.language || '')
  parts.push(String((n as Navigator & { hardwareConcurrency?: number }).hardwareConcurrency || ''))
  parts.push(String((n as Navigator & { deviceMemory?: number }).deviceMemory || ''))
  parts.push(String(n.maxTouchPoints || 0))

  // Screen
  const s = screen
  parts.push(`${s.width}x${s.height}x${s.colorDepth}`)
  parts.push(String(window.devicePixelRatio || 1))

  // Timezone
  parts.push(Intl.DateTimeFormat().resolvedOptions().timeZone || '')

  // Canvas fingerprint
  try {
    const canvas = document.createElement('canvas')
    canvas.width = 240
    canvas.height = 60
    const ctx = canvas.getContext('2d')
    if (ctx) {
      ctx.textBaseline = 'top'
      ctx.font = "14px 'Arial'"
      ctx.fillStyle = '#f60'
      ctx.fillRect(125, 1, 62, 20)
      ctx.fillStyle = '#069'
      ctx.fillText('Power Maths Proctor 🖥️', 2, 15)
      ctx.fillStyle = 'rgba(102, 204, 0, 0.7)'
      ctx.fillText('Power Maths Proctor 🖥️', 4, 17)
      parts.push(canvas.toDataURL())
    }
  } catch {
    parts.push('canvas-blocked')
  }

  // Simple hash (djb2) → hex
  const str = parts.join('|')
  let hash = 5381
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 33) ^ str.charCodeAt(i)
  }
  return (hash >>> 0).toString(16).padStart(8, '0')
}

export interface FingerprintCheck {
  fingerprint: string
  /** 'first' if no prior fingerprint, 'match' if same, 'mismatch' if different device. */
  status: 'first' | 'match' | 'mismatch'
  previousFingerprint?: string
}

const FP_KEY = 'pm-device-fingerprints'

interface StoredFp {
  [studentId: string]: string
}

function readStoredFingerprints(): StoredFp {
  try {
    const raw = localStorage.getItem(FP_KEY)
    return raw ? (JSON.parse(raw) as StoredFp) : {}
  } catch {
    return {}
  }
}

function writeStoredFingerprints(data: StoredFp): void {
  try {
    localStorage.setItem(FP_KEY, JSON.stringify(data))
  } catch {
    /* ignore quota errors */
  }
}

/** Check the current device fingerprint against the stored one for a student. */
export function checkFingerprint(studentId: string): FingerprintCheck {
  const fp = generateFingerprint()
  const stored = readStoredFingerprints()
  const previous = stored[studentId]
  if (!previous) {
    stored[studentId] = fp
    writeStoredFingerprints(stored)
    return { fingerprint: fp, status: 'first' }
  }
  if (previous === fp) {
    return { fingerprint: fp, status: 'match' }
  }
  // Mismatch — update stored to the new one so we don't keep alerting.
  stored[studentId] = fp
  writeStoredFingerprints(stored)
  return { fingerprint: fp, status: 'mismatch', previousFingerprint: previous }
}

// ─────────────────────────── Question pool ───────────────────────────

/**
 * Pick `n` random items from `pool` using a seeded shuffle so the same
 * student gets the same subset on a retake (deterministic per student+exam).
 * Falls back to `pool` itself if n >= pool.length.
 */
export function pickFromPool<T>(pool: T[], n: number, seedStr: string): T[] {
  if (n >= pool.length) return [...pool]
  // Seeded PRNG (mulberry32) from the seed string.
  let seed = 0
  for (let i = 0; i < seedStr.length; i++) {
    seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0
  }
  const rng = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0
    return seed / 4294967296
  }
  const arr = [...pool]
  // Fisher-Yates with seeded rng
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr.slice(0, n)
}

// ─────────────────────────── Proctor hook ───────────────────────────

export type ViolationType =
  | 'tab-switch'
  | 'window-blur'
  | 'fullscreen-exit'
  | 'copy-attempt'
  | 'right-click'
  | 'drag-attempt'
  | 'devtools'
  | 'print'

export interface ProctorState {
  violations: ViolationType[]
  violationCount: number
  /** True once the threshold (default 3) is reached — caller should auto-submit. */
  shouldAutoSubmit: boolean
  lastViolation: ViolationType | null
}

export interface UseExamProctorOptions {
  enabled: boolean
  /** Number of violations before auto-submit. Default 3. */
  maxViolations?: number
  /** Called on every violation with the updated state. */
  onViolation?: (state: ProctorState) => void
  /** Called once when the threshold is reached. */
  onAutoSubmit?: () => void
  /** Called when fullscreen is requested/exited. */
  onFullscreenChange?: (isFullscreen: boolean) => void
}

/**
 * Activates lockdown proctoring for an exam. Returns the current proctor state
 * and a `requestFullscreen` function to call when the exam starts.
 */
export function useExamProctor(opts: UseExamProctorOptions) {
  const { enabled, maxViolations = 3, onViolation, onAutoSubmit, onFullscreenChange } = opts
  const [state, setState] = React.useState<ProctorState>({
    violations: [],
    violationCount: 0,
    shouldAutoSubmit: false,
    lastViolation: null,
  })

  // Keep latest callbacks in refs so the event listeners don't go stale.
  const onViolationRef = React.useRef(onViolation)
  const onAutoSubmitRef = React.useRef(onAutoSubmit)
  const onFullscreenRef = React.useRef(onFullscreenChange)
  React.useEffect(() => {
    onViolationRef.current = onViolation
    onAutoSubmitRef.current = onAutoSubmit
    onFullscreenRef.current = onFullscreenChange
  })

  const alreadyAutoSubmitted = React.useRef(false)

  const recordViolation = React.useCallback(
    (type: ViolationType) => {
      setState((prev) => {
        const violations = [...prev.violations, type]
        const violationCount = violations.length
        const shouldAutoSubmit = violationCount >= maxViolations
        const next: ProctorState = {
          violations,
          violationCount,
          shouldAutoSubmit,
          lastViolation: type,
        }
        onViolationRef.current?.(next)
        if (shouldAutoSubmit && !alreadyAutoSubmitted.current) {
          alreadyAutoSubmitted.current = true
          // Defer to avoid setState-in-render warnings.
          setTimeout(() => onAutoSubmitRef.current?.(), 0)
        }
        return next
      })
    },
    [maxViolations]
  )

  // Main lockdown effect.
  React.useEffect(() => {
    if (!enabled) return

    // ── Block copy / cut / right-click / drag ──
    const blockEvent = (e: Event) => {
      e.preventDefault()
      if (e.type === 'copy' || e.type === 'cut') recordViolation('copy-attempt')
      else if (e.type === 'contextmenu') recordViolation('right-click')
      else if (e.type === 'dragstart') recordViolation('drag-attempt')
    }
    document.addEventListener('copy', blockEvent)
    document.addEventListener('cut', blockEvent)
    document.addEventListener('contextmenu', blockEvent)
    document.addEventListener('dragstart', blockEvent)

    // ── Block print ──
    const blockPrint = (e: Event) => {
      e.preventDefault()
      recordViolation('print')
    }
    window.addEventListener('beforeprint', blockPrint)

    // ── Detect tab-switch (visibilitychange) ──
    const onVisibility = () => {
      if (document.hidden) recordViolation('tab-switch')
    }
    document.addEventListener('visibilitychange', onVisibility)

    // ── Detect window blur (alt-tab to another app) ──
    const onBlur = () => recordViolation('window-blur')
    window.addEventListener('blur', onBlur)

    // ── Detect fullscreen exit ──
    const onFsChange = () => {
      const isFs = Boolean(document.fullscreenElement)
      onFullscreenRef.current?.(isFs)
      if (!isFs) recordViolation('fullscreen-exit')
    }
    document.addEventListener('fullscreenchange', onFsChange)

    // ── Best-effort devtools detection (keydown traps) ──
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase()
      const ctrl = e.ctrlKey || e.metaKey
      if (ctrl && ['c', 'x', 'p', 's', 'u'].includes(k)) {
        e.preventDefault()
        if (k === 'c' || k === 'x') recordViolation('copy-attempt')
      }
      if (ctrl && e.shiftKey && ['i', 'j', 'c'].includes(k)) {
        e.preventDefault()
        recordViolation('devtools')
      }
      if (e.key === 'F12') {
        e.preventDefault()
        recordViolation('devtools')
      }
    }
    window.addEventListener('keydown', onKey, { capture: true })

    return () => {
      document.removeEventListener('copy', blockEvent)
      document.removeEventListener('cut', blockEvent)
      document.removeEventListener('contextmenu', blockEvent)
      document.removeEventListener('dragstart', blockEvent)
      window.removeEventListener('beforeprint', blockPrint)
      document.removeEventListener('visibilitychange', onVisibility)
      window.removeEventListener('blur', onBlur)
      document.removeEventListener('fullscreenchange', onFsChange)
      window.removeEventListener('keydown', onKey, { capture: true } as EventListenerOptions)
    }
  }, [enabled, recordViolation])

  const requestFullscreen = React.useCallback(async () => {
    try {
      await document.documentElement.requestFullscreen?.()
    } catch {
      /* user may deny — that's fine, proctor still tracks via visibilitychange */
    }
  }, [])

  const exitFullscreen = React.useCallback(async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen?.()
    } catch {
      /* ignore */
    }
  }, [])

  return { state, requestFullscreen, exitFullscreen, recordViolation }
}
