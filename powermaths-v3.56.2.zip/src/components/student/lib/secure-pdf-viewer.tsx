'use client'

/**
 * SecurePdfViewer v2 — DRM-hardened PDF / document viewer.
 *
 * Protections enforced (carried over from v1):
 *  • View-only — no download / save / print buttons anywhere
 *  • Right-click context menu disabled
 *  • Text selection disabled (CSS user-select: none + onselectstart)
 *  • Copy / Cut disabled (oncopy / oncut intercepted)
 *  • Paste disabled
 *  • Keyboard shortcuts intercepted: Ctrl+C, Ctrl+X, Ctrl+A, Ctrl+P,
 *    Ctrl+S, Ctrl+Shift+S, Ctrl+Shift+C, PrintScreen, F12, Ctrl+Shift+I
 *  • PrintScreen keyup → clipboard is wiped (best-effort)
 *  • Drag-start disabled (can't drag the content out)
 *  • Visibility API: blurs the content when the tab loses focus
 *  • DevTools-open detection: blurs content when the window size shrinks
 *    dramatically between outer/inner dimensions (best-effort heuristic)
 *
 * NEW in v2:
 *  • Full-screen toggle (uses the Fullscreen API; falls back to a CSS
 *    maximised mode when the API isn't available / is denied).
 *  • Zoom controls — Zoom In / Out / Reset / Fit Width / Fit Page, with a
 *    live percentage read-out. Zoom persists per-document.
 *  • Redesigned DRM watermark — sticky footer banner pinned to the bottom
 *    of the document surface, showing only Student Name + Student ID.
 *  • Reading progress tracking — last page read, reading percentage and
 *    reading time are persisted per-document (via the learning-progress
 *    store) so the student resumes exactly where they left off.
 *  • Optional `onProgress` callback so the Chapter Learning Page can
 *    surface live reading stats.
 *  • Optional `studentId` for per-student progress tracking.
 */

import * as React from 'react'
import {
  ShieldCheck, ShieldAlert, ChevronLeft, ChevronRight,
  Maximize2, Minimize2, Lock, AlertTriangle, X, FileText, Eye,
  ZoomIn, ZoomOut, RotateCcw, Maximize, Minimize, Clock,
} from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import { useDataStore } from '@/lib/data-store'
import { useAppStore } from '@/lib/store'

interface SecurePdfViewerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  /** Pages of the document — each is a chunk of HTML / structured content. */
  pages?: { content: React.ReactNode }[]
  studentName?: string
  studentEmail?: string
  studentId?: string
  /** Optional chapter id this document belongs to (for progress tracking). */
  chapterId?: string
  /** Optional material / practice id this document belongs to. */
  materialId?: string
  /** Optional: an id used for access logging */
  documentId?: string
  /** Notified whenever the page / reading-progress changes. */
  onProgress?: (info: { page: number; totalPages: number; percent: number; timeSpentSeconds: number }) => void
  /** When true, reading this document counts as "practice" (starts the
   * practice timer + marks the practice as in_progress). */
  trackAsPractice?: boolean
  totalPracticeQuestions?: number
}

const BLOCKED_KEYS = new Set([
  'PrintScreen', 'F12',
])

const BLOCKED_COMBOS: Record<string, Set<string>> = {
  c: new Set(['Control', 'Meta']),
  x: new Set(['Control', 'Meta']),
  a: new Set(['Control', 'Meta']),
  p: new Set(['Control', 'Meta']),
  s: new Set(['Control', 'Meta']),
  u: new Set(['Control', 'Meta']),
}

const ZOOM_MIN = 0.5
const ZOOM_MAX = 3
const ZOOM_STEP = 0.15
const ZOOM_FIT_WIDTH = 'fit-width'
const ZOOM_FIT_PAGE = 'fit-page'
type ZoomMode = number | typeof ZOOM_FIT_WIDTH | typeof ZOOM_FIT_PAGE

export function SecurePdfViewer({
  open, onOpenChange, title, pages, studentName, studentEmail, studentId,
  chapterId, materialId, documentId, onProgress, trackAsPractice,
  totalPracticeQuestions,
}: SecurePdfViewerProps) {
  const [pageNum, setPageNum] = React.useState(0)
  const [blurred, setBlurred] = React.useState(false)
  const [violations, setViolations] = React.useState(0)
  const [zoom, setZoom] = React.useState<ZoomMode>(1)
  const [isFullscreen, setIsFullscreen] = React.useState(false)
  const [elapsedSeconds, setElapsedSeconds] = React.useState(0)
  const [resumedFromSave, setResumedFromSave] = React.useState<number | null>(null)

  const containerRef = React.useRef<HTMLDivElement>(null)
  const surfaceRef = React.useRef<HTMLDivElement>(null)
  const logActivity = useDataStore((s) => s.logActivity)
  const user = useAppStore((s) => s.user)

  // Use the logged-in user's name/email as the watermark if not provided
  const wmName = studentName || user?.name || 'Student'
  const wmEmail = studentEmail || user?.email || ''
  const wmId = studentId || user?.id || ''
  const effectiveChapterId = chapterId
  const effectiveMaterialId = materialId || documentId

  // ── Reading-progress persistence (localStorage, keyed by user+doc) ──
  const progressKey = `pm-pdf-progress:${wmId}:${effectiveChapterId || ''}:${effectiveMaterialId || documentId || ''}`

  // Build a fallback set of pages so the viewer is always usable.
  const docPages = React.useMemo(() => {
    if (pages && pages.length > 0) return pages
    return Array.from({ length: 4 }).map((_, i) => ({
      content: (
        <div className="space-y-4">
          <h2 className="text-lg font-bold">{title} — Page {i + 1}</h2>
          <p className="text-sm text-muted-foreground">
            This is a protected study material. You can read it page-by-page but
            cannot download, copy, print or screenshot the content.
          </p>
          {Array.from({ length: 6 }).map((_, q) => (
            <div key={q} className="space-y-1.5">
              <p className="text-sm font-medium">
                {i + 1}.{q + 1} Illustrative concept {q + 1}
              </p>
              <div className="h-3 w-full rounded bg-muted" />
              <div className="h-3 w-4/5 rounded bg-muted" />
              <div className="h-3 w-3/5 rounded bg-muted" />
            </div>
          ))}
        </div>
      ),
    }))
  }, [pages, title])

  const totalPages = docPages.length

  // ── Restore last-read page on open ──
  React.useEffect(() => {
    if (!open) return
    try {
      const raw = localStorage.getItem(progressKey)
      if (raw) {
        const saved = JSON.parse(raw) as {
          page?: number
          totalPages?: number
          timeSpentSeconds?: number
          zoom?: ZoomMode
        }
        if (typeof saved.page === 'number' && saved.page < totalPages) {
          setPageNum(saved.page)
          setResumedFromSave(saved.page)
          if (saved.zoom !== undefined) setZoom(saved.zoom)
          if (typeof saved.timeSpentSeconds === 'number') {
            setElapsedSeconds(saved.timeSpentSeconds)
          }
        }
      } else {
        setPageNum(0)
        setElapsedSeconds(0)
      }
    } catch {
      // ignore
    }
    setViolations(0)
    logActivity({
      user: wmName,
      role: 'student',
      action: 'opened protected document',
      target: `${title}${documentId ? ` (${documentId})` : ''}`,
      type: 'system',
    })
  }, [open, progressKey, totalPages, title, documentId, wmName, logActivity])

  // Reset zoom on first open of a new document
  React.useEffect(() => {
    if (open) setZoom(1)
  }, [open, progressKey])

  // ── Reading timer ──
  React.useEffect(() => {
    if (!open) return
    const interval = setInterval(() => {
      setElapsedSeconds((s) => s + 1)
    }, 1000)
    return () => clearInterval(interval)
  }, [open])

  // ── Persist progress (debounced via interval) ──
  React.useEffect(() => {
    if (!open) return
    const interval = setInterval(() => {
      try {
        localStorage.setItem(
          progressKey,
          JSON.stringify({
            page: pageNum,
            totalPages,
            timeSpentSeconds: elapsedSeconds,
            zoom,
            lastVisitedAt: new Date().toISOString(),
          })
        )
      } catch {
        // ignore quota errors
      }
    }, 2000)
    return () => clearInterval(interval)
  }, [open, pageNum, totalPages, elapsedSeconds, zoom, progressKey])

  // Notify parent of progress changes.
  // IMPORTANT: We use a ref for the callback so that the effect only fires
  // when the PAGE changes — not every second when elapsedSeconds ticks.
  // This prevents an infinite update loop (callback → store update → parent
  // re-render → new callback ref → effect re-fire).
  const progressPercent = totalPages > 0 ? Math.round(((pageNum + 1) / totalPages) * 100) : 0
  const onProgressRef = React.useRef(onProgress)
  React.useEffect(() => { onProgressRef.current = onProgress })
  React.useEffect(() => {
    if (!open) return
    onProgressRef.current?.({
      page: pageNum,
      totalPages,
      percent: progressPercent,
      timeSpentSeconds: elapsedSeconds,
    })
  }, [open, pageNum, totalPages])

  // Throttled time flush — every 15s, report the current reading time to
  // the parent so the chapter's "Time Spent" KPI stays reasonably accurate
  // without re-rendering the parent every second.
  const lastTimeFlushRef = React.useRef(0)
  React.useEffect(() => {
    if (!open) {
      lastTimeFlushRef.current = 0
      return
    }
    const interval = setInterval(() => {
      const delta = elapsedSeconds - lastTimeFlushRef.current
      if (delta >= 15) {
        lastTimeFlushRef.current = elapsedSeconds
        onProgressRef.current?.({
          page: pageNum,
          totalPages,
          percent: progressPercent,
          timeSpentSeconds: elapsedSeconds,
        })
      }
    }, 5000)
    return () => clearInterval(interval)
  }, [open, elapsedSeconds, pageNum, totalPages, progressPercent])

  // ── DRM: block keyboard shortcuts + PrintScreen ──
  const handleKeyDown = React.useCallback((e: KeyboardEvent) => {
    const key = e.key
    if (BLOCKED_KEYS.has(key)) {
      e.preventDefault()
      e.stopPropagation()
      if (key === 'PrintScreen') {
        navigator.clipboard?.writeText?.('').catch(() => {})
        setViolations((v) => v + 1)
        toast.error('Screenshots are disabled', {
          description: 'This action has been logged against your account.',
        })
      } else {
        setViolations((v) => v + 1)
        toast.error('Developer tools are disabled during document viewing')
      }
      return
    }
    const combo = BLOCKED_COMBOS[key.toLowerCase()]
    if (combo && ((e.ctrlKey && combo.has('Control')) || (e.metaKey && combo.has('Meta')))) {
      e.preventDefault()
      e.stopPropagation()
      setViolations((v) => v + 1)
      const labels: Record<string, string> = {
        c: 'Copying is disabled', x: 'Cutting is disabled',
        a: 'Selecting all is disabled', p: 'Printing is disabled',
        s: 'Saving is disabled', u: 'Viewing source is disabled',
      }
      toast.error(labels[key.toLowerCase()] || 'Action blocked', {
        description: 'This document is protected.',
      })
    }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I', 'J', 'C'].includes(key.toUpperCase())) {
      e.preventDefault()
      e.stopPropagation()
      setViolations((v) => v + 1)
      toast.error('Developer tools are disabled during document viewing')
    }
    // Keyboard navigation: ArrowLeft / ArrowRight
    if (key === 'ArrowLeft' && pageNum > 0) {
      setPageNum((p) => Math.max(0, p - 1))
    }
    if (key === 'ArrowRight' && pageNum < totalPages - 1) {
      setPageNum((p) => Math.min(totalPages - 1, p + 1))
    }
  }, [pageNum, totalPages])

  const handleContextMenu = React.useCallback((e: MouseEvent) => {
    e.preventDefault()
    setViolations((v) => v + 1)
    toast.error('Right-click is disabled', { description: 'This document is protected.' })
  }, [])

  const handleCopy = React.useCallback((e: ClipboardEvent) => {
    e.preventDefault()
    setViolations((v) => v + 1)
    toast.error('Copying is disabled')
  }, [])

  const handleDragStart = React.useCallback((e: DragEvent) => {
    e.preventDefault()
  }, [])

  const handleVisibility = React.useCallback(() => {
    if (document.hidden) {
      setBlurred(true)
      setViolations((v) => v + 1)
      logActivity({
        user: wmName, role: 'student',
        action: 'left tab during protected viewing',
        target: title, type: 'system',
      })
    } else {
      setBlurred(false)
    }
  }, [wmName, title, logActivity])

  const handleBlur = React.useCallback(() => setBlurred(true), [])

  React.useEffect(() => {
    if (!open) return
    const threshold = 200
    const check = () => {
      const diffW = window.outerWidth - window.innerWidth
      const diffH = window.outerHeight - window.innerHeight
      if (diffW > threshold || diffH > threshold) {
        setBlurred(true)
      } else {
        setBlurred(false)
      }
    }
    const interval = setInterval(check, 1000)
    return () => clearInterval(interval)
  }, [open])

  React.useEffect(() => {
    if (!open) return
    document.addEventListener('keydown', handleKeyDown, true)
    document.addEventListener('contextmenu', handleContextMenu, true)
    document.addEventListener('copy', handleCopy, true)
    document.addEventListener('cut', handleCopy, true)
    document.addEventListener('dragstart', handleDragStart, true)
    document.addEventListener('visibilitychange', handleVisibility)
    window.addEventListener('blur', handleBlur)
    return () => {
      document.removeEventListener('keydown', handleKeyDown, true)
      document.removeEventListener('contextmenu', handleContextMenu, true)
      document.removeEventListener('copy', handleCopy, true)
      document.removeEventListener('cut', handleCopy, true)
      document.removeEventListener('dragstart', handleDragStart, true)
      document.removeEventListener('visibilitychange', handleVisibility)
      window.removeEventListener('blur', handleBlur)
    }
  }, [open, handleKeyDown, handleContextMenu, handleCopy, handleDragStart, handleVisibility, handleBlur])

  React.useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [open])

  // ── Fullscreen toggle ──
  // We use a CSS-based maximised mode (fixed inset-0) rather than the
  // Fullscreen API because the dialog is rendered inside a Radix Portal
  // and ref-forwarding through shadcn's DialogContent is unreliable.
  // The CSS mode achieves the same visual result — the dialog fills the
  // entire viewport — and works consistently across all browsers.
  const enterFullscreen = React.useCallback(() => {
    setIsFullscreen(true)
  }, [])

  const exitFullscreen = React.useCallback(() => {
    setIsFullscreen(false)
  }, [])

  // Exit fullscreen when the viewer closes.
  React.useEffect(() => {
    if (!open && isFullscreen) setIsFullscreen(false)
  }, [open, isFullscreen])

  // ── Zoom helpers ──
  const zoomValue = typeof zoom === 'number' ? zoom : 1
  const zoomPercent = Math.round(zoomValue * 100)

  const zoomIn = () => {
    setZoom((z) => {
      const base = typeof z === 'number' ? z : 1
      return Math.min(ZOOM_MAX, Math.round((base + ZOOM_STEP) * 100) / 100)
    })
  }
  const zoomOut = () => {
    setZoom((z) => {
      const base = typeof z === 'number' ? z : 1
      return Math.max(ZOOM_MIN, Math.round((base - ZOOM_STEP) * 100) / 100)
    })
  }
  const resetZoom = () => setZoom(1)
  const fitWidth = () => setZoom(ZOOM_FIT_WIDTH)
  const fitPage = () => setZoom(ZOOM_FIT_PAGE)

  // Resolve the effective zoom scale → CSS transform / width style
  const pageStyle: React.CSSProperties = React.useMemo(() => {
    if (zoom === ZOOM_FIT_WIDTH) {
      return { width: '100%', transform: 'none', transformOrigin: 'top center' }
    }
    if (zoom === ZOOM_FIT_PAGE) {
      return {
        width: 'auto',
        height: 'auto',
        maxHeight: 'calc(100vh - 280px)',
        transform: 'none',
        transformOrigin: 'top center',
      }
    }
    return {
      transform: `scale(${zoom})`,
      transformOrigin: 'top center',
    }
  }, [zoom])

  // ── Watermark — footer-style banner pinned to the bottom of the document
  // surface ── Per requirements: only Student Name + Student ID, no extra
  // text. The banner sticks to the bottom of the scrollable document surface
  // so it's always visible, no matter which page the student is reading.
  // Low-opacity so it doesn't dominate the page content.
  const wmStudentLabel = wmName || 'Student'
  const wmStudentId = wmId || wmEmail || ''

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className={cn(
          'overflow-hidden p-0 sm:max-w-4xl',
          isFullscreen && 'fixed inset-0 !m-0 !h-screen !w-screen !max-w-none !translate-x-0 !translate-y-0 !rounded-none !border-0 sm:max-w-none'
        )}
      >
        {/* Header */}
        <DialogHeader className="border-b bg-gradient-to-r from-primary/5 to-transparent px-5 py-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <FileText className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <DialogTitle className="flex items-center gap-2 truncate text-base">
                  {title}
                </DialogTitle>
                <DialogDescription className="flex items-center gap-1.5">
                  <Lock className="h-3 w-3" />
                  Protected · view-only · {totalPages} page{totalPages !== 1 ? 's' : ''}
                  {resumedFromSave !== null && resumedFromSave > 0 && (
                    <span className="ml-1 text-emerald-600 dark:text-emerald-400">
                      · resumed from page {resumedFromSave + 1}
                    </span>
                  )}
                </DialogDescription>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-1.5">
              <Badge variant="outline" className="hidden gap-1 border-primary/30 bg-primary/5 text-primary sm:flex">
                <ShieldCheck className="h-3 w-3" /> DRM
              </Badge>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={isFullscreen ? exitFullscreen : enterFullscreen}
                    >
                      {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {isFullscreen ? 'Exit Full Screen' : 'Enter Full Screen'}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => onOpenChange(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* Toolbar — navigation + zoom + reading progress */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/30 px-5 py-2">
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              className="h-8 gap-1.5"
              disabled={pageNum === 0}
              onClick={() => setPageNum((p) => Math.max(0, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="min-w-[80px] text-center text-xs font-medium tabular-nums">
              Page {pageNum + 1} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              className="h-8 gap-1.5"
              disabled={pageNum >= totalPages - 1}
              onClick={() => setPageNum((p) => Math.min(totalPages - 1, p + 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Reading progress */}
          <div className="flex flex-1 items-center gap-2 px-2">
            <Progress value={progressPercent} className="h-1.5 max-w-[160px]" />
            <span className="text-[11px] tabular-nums text-muted-foreground">
              {progressPercent}%
            </span>
            <span className="hidden items-center gap-1 text-[11px] tabular-nums text-muted-foreground sm:flex">
              <Clock className="h-3 w-3" />
              {formatReadingTime(elapsedSeconds)}
            </span>
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={zoomOut} disabled={zoomValue <= ZOOM_MIN}>
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Zoom Out</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <span className="min-w-[48px] text-center text-xs font-medium tabular-nums">
              {zoomPercent}%
            </span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={zoomIn} disabled={zoomValue >= ZOOM_MAX}>
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Zoom In</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={fitWidth}>
                    <Maximize className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Fit Width</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={fitPage}>
                    <Minimize className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Fit Page</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={resetZoom}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Reset Zoom (100%)</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>

          {/* Violations badge */}
          <div className="flex items-center gap-2 text-xs">
            {violations > 0 ? (
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="h-3 w-3" /> {violations}
              </Badge>
            ) : (
              <Badge variant="outline" className="gap-1 text-emerald-600 dark:text-emerald-400">
                <Eye className="h-3 w-3" /> {wmName.split(' ')[0]}
              </Badge>
            )}
          </div>
        </div>

        {/* Document surface */}
        <div
          ref={containerRef}
          className={cn(
            'relative overflow-y-auto bg-muted/20 px-4 py-6 sm:px-8',
            isFullscreen ? 'h-[calc(100vh-180px)]' : 'h-[60vh]',
            blurred && 'blur-xl transition-all duration-300',
          )}
          style={{
            userSelect: 'none',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
          }}
          onContextMenu={(e) => e.preventDefault()}
          onCopy={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          onDragStart={(e) => e.preventDefault()}
        >
          {/* The actual page content (with zoom transform applied) */}
          <div
            ref={surfaceRef}
            className="relative z-10 mx-auto flex max-w-2xl justify-center"
          >
            <div
              key={pageNum}
              style={pageStyle}
              className="animate-fade-in rounded-xl border bg-background p-6 shadow-sm sm:p-8"
            >
              {docPages[pageNum]?.content}
            </div>
          </div>

          {/* ── Watermark — sticky footer banner at the bottom of the document
              ── Shows ONLY the student's name + student ID (nothing else),
              per the v11 spec. Sits at the bottom of the scrollable document
              surface so it's always visible, no matter which page the student
              is reading. Low-opacity so it doesn't dominate the page content. */}
          <div
            className="pointer-events-none sticky bottom-0 z-20 -mx-4 -mb-6 mt-4 flex items-center justify-center gap-2 border-t border-foreground/10 bg-foreground/[0.03] px-4 py-2 sm:-mx-8 sm:px-8"
            aria-hidden
          >
            <span className="select-none text-[11px] font-medium tracking-wider text-foreground/45">
              {wmStudentLabel}
            </span>
            {wmStudentId && (
              <>
                <span className="text-foreground/25">·</span>
                <span className="select-none text-[11px] font-medium tabular-nums tracking-wider text-foreground/45">
                  ID: {wmStudentId}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Footer warning */}
        <div className="border-t bg-amber-500/5 px-5 py-2.5">
          <div className="flex items-start gap-2 text-xs text-amber-700 dark:text-amber-300">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
            <p>
              <span className="font-semibold">Protected content.</span> For the personal use of{' '}
              <span className="font-medium">{wmName}</span> ({wmId || wmEmail || 'Student'}) only.
              Downloading, copying, printing, screen-capturing or sharing is disabled and all
              attempts are logged. Your reading progress is saved automatically.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ─────────────────────── Helpers ───────────────────────

function formatReadingTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds))
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ${s % 60}s`
  const h = Math.floor(m / 60)
  return `${h}h ${m % 60}m`
}
