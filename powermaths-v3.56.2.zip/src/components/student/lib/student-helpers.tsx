'use client'

import * as React from 'react'
import {
  Hash, Sigma, Triangle, Compass, Box, BarChart3, BookOpen,
  type LucideIcon,
} from 'lucide-react'
import { useDataStore, type Chapter, type Exam, type Result, visibleContentTabIds } from '@/lib/data-store'
import { useAppStore } from '@/lib/store'
import {
  useLearningProgress,
  computeChapterCompletion,
  getChapterProgress,
} from '@/lib/learning-progress'

const chapterIconMap: Record<string, LucideIcon> = {
  Hash,
  Sigma,
  Triangle,
  Compass,
  Box,
  BarChart3,
  BookOpen,
}

export function getChapterIcon(name: string): LucideIcon {
  return chapterIconMap[name] ?? BookOpen
}

export function ChapterIcon({ name, className }: { name: string; className?: string }) {
  return React.createElement(getChapterIcon(name), { className })
}

/** Returns the logged-in student's assigned chapters, ordered by chapter.order. */
export function useAssignedChapters(): Chapter[] {
  const user = useAppStore((s) => s.user)
  const chapters = useDataStore((s) => s.chapters)
  const students = useDataStore((s) => s.students)
  return React.useMemo(() => {
    if (!user) return []
    const student = students.find((s) => s.id === user.id)
    if (!student) return []
    return chapters
      .filter((c) => student.assignedChapters.includes(c.id))
      .sort((a, b) => a.order - b.order)
  }, [user, chapters, students])
}

/**
 * For each assigned chapter, determine status using BOTH:
 *   1. The LIVE results store (legacy: a chapter is "completed" if the
 *      student has passed any exam in that chapter).
 *   2. The learning-progress store (materials viewed + practice completed
 *      + test passed). A chapter is "completed" when its computed
 *      completion percentage reaches 100%.
 *
 * The chapter is "locked" only if the previous assigned chapter isn't
 * completed AND this chapter itself isn't already completed. (Once a
 * student has passed any exam in a chapter, they can always review it.)
 */
export interface ChapterStatusInfo {
  chapter: Chapter
  status: 'completed' | 'in_progress' | 'not_started' | 'locked'
  bestScore: number
  attempts: number
  isLocked: boolean
  /** Computed learning progress 0–100 across materials + practice + test. */
  learningProgress: number
  /** Total seconds spent on this chapter (materials + practice). */
  timeSpentSeconds: number
}

export function useChapterStatuses(): ChapterStatusInfo[] {
  const user = useAppStore((s) => s.user)
  const chapters = useAssignedChapters()
  const results = useDataStore((s) => s.results)
  // Subscribe to learning-progress changes so the UI re-renders when a
  // student completes a material / practice.
  const progressChapters = useLearningProgress((s) => s.chapters)

  return React.useMemo(() => {
    if (!user) return []
    const studentResults = results.filter((r) => r.studentId === user.id)
    const completedChapters = new Set<string>()
    const inProgressChapters = new Set<string>()
    const bestByChapter = new Map<string, number>()
    const attemptsByChapter = new Map<string, number>()

    for (const r of studentResults) {
      const ch = chapters.find((c) => c.name === r.chapterName)
      if (!ch) continue
      const prevBest = bestByChapter.get(ch.id) ?? 0
      bestByChapter.set(ch.id, Math.max(prevBest, r.percentage))
      attemptsByChapter.set(ch.id, (attemptsByChapter.get(ch.id) ?? 0) + 1)
      if (r.status === 'passed') completedChapters.add(ch.id)
      else inProgressChapters.add(ch.id)
    }

    const out: ChapterStatusInfo[] = []
    for (let i = 0; i < chapters.length; i++) {
      const chapter = chapters[i]
      const previousCompleted = i === 0 || completedChapters.has(chapters[i - 1].id)
      const completed = completedChapters.has(chapter.id)

      // Compute learning progress from the progress store.
      const progressKey = `${user.id}:${chapter.id}`
      const progress =
        progressChapters[progressKey] ?? getChapterProgress(user.id, chapter.id)
      const hasPassedTest = completed // legacy: passed any exam in chapter
      const learningProgress = computeChapterCompletion(progress, {
        materialIds: chapter.studyMaterials.map((m) => m.id),
        practiceIds: chapter.practiceSheets.map((p) => p.id),
        formulaIds: (chapter.formulas ?? []).map((f) => f.id),
        theoryIds: (chapter.theories ?? []).map((t) => t.id),
        testPassed: hasPassedTest,
        activeTabs: new Set(visibleContentTabIds(chapter)),
      })

      // A chapter is "completed" if either the legacy test-passed rule
      // fires OR the new learning-progress hits 100%.
      const isCompleted = completed || learningProgress >= 100
      const isLocked = !previousCompleted && !isCompleted
      const inProgress = inProgressChapters.has(chapter.id) || learningProgress > 0
      const status: ChapterStatusInfo['status'] = isCompleted
        ? 'completed'
        : isLocked
          ? 'locked'
          : inProgress
            ? 'in_progress'
            : 'not_started'
      out.push({
        chapter,
        status,
        bestScore: bestByChapter.get(chapter.id) ?? 0,
        attempts: attemptsByChapter.get(chapter.id) ?? 0,
        isLocked,
        learningProgress,
        timeSpentSeconds: progress.totalTimeSpentSeconds,
      })
    }
    return out
  }, [user, chapters, results, progressChapters])
}

/** Returns the published exams for the student's assigned chapters. */
export function useAssignedExams(): Exam[] {
  const user = useAppStore((s) => s.user)
  const exams = useDataStore((s) => s.exams)
  const chapters = useAssignedChapters()
  return React.useMemo(() => {
    if (!user) return []
    const ids = new Set(chapters.map((c) => c.id))
    return exams.filter((e) => ids.has(e.chapterId) && e.status === 'published')
  }, [user, exams, chapters])
}

/** Has the student passed this exam already? */
export function useHasPassed(examId: string): boolean {
  const user = useAppStore((s) => s.user)
  const results = useDataStore((s) => s.results)
  return React.useMemo(() => {
    if (!user) return false
    return results.some((r) => r.examId === examId && r.studentId === user.id && r.status === 'passed')
  }, [results, user, examId])
}

/** Fisher–Yates shuffle (returns a new array). */
export function shuffle<T>(arr: readonly T[]): T[] {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** Returns true if the student has a passed result for any exam in this chapter. */
export function chapterCompleted(chapterName: string, results: Result[], studentId: string): boolean {
  return results.some(
    (r) => r.studentId === studentId && r.chapterName === chapterName && r.status === 'passed'
  )
}

export function formatTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds))
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
}

export function initialsOf(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('')
}
