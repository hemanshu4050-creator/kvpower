'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Clock, Target, FileQuestion, CheckCircle2, XCircle, AlertTriangle,
  ChevronLeft, ChevronRight, Flag, Send, Trophy, RotateCcw, ArrowLeft,
  Award, Timer, Lightbulb, ShieldAlert, Fingerprint, Lock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  useDataStore, getExamQuestions, getExamQuestionsForStudent,
  type Exam, type Question, type AnswerRecord, type Result,
} from '@/lib/data-store'
import { useAppStore } from '@/lib/store'
import { shuffle, formatTime } from './student-helpers'
import { useExamProctor, checkFingerprint, type ViolationType } from './exam-proctor'
import { getHintLadder } from '@/lib/chat-engine'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface PreparedQuestion {
  question: Question
  options: string[]
  correctOption: number
}

function prepareExam(exam: Exam, studentId: string): PreparedQuestion[] {
  // v3.27.0 — use the per-student question selector so question pools work.
  const qs = getExamQuestionsForStudent(exam, studentId)
  const ordered = exam.shuffleQuestions ? shuffle(qs) : qs
  return ordered.map((q) => {
    if (!exam.shuffleOptions || q.options.length < 2) {
      return { question: q, options: q.options, correctOption: q.correctAnswer }
    }
    const indices = shuffle(q.options.map((_, i) => i))
    const options = indices.map((i) => q.options[i])
    const correctOption = indices.indexOf(q.correctAnswer)
    return { question: q, options, correctOption }
  })
}

function gradeExam(
  exam: Exam,
  prepared: PreparedQuestion[],
  answers: Record<string, number | null>,
  perQuestionSeconds: Record<string, number>,
  startTimeISO: string,
  endTimeISO: string
): {
  result: Omit<Result, 'id' | 'createdAt'>
  answerRecords: AnswerRecord[]
} {
  let attempted = 0
  let correct = 0
  let wrong = 0
  let marksObtained = 0
  let totalMarks = 0
  const answerRecords: AnswerRecord[] = []

  for (const pq of prepared) {
    const q = pq.question
    const selected = answers[q.id] ?? null
    const maxMarks = q.marks
    totalMarks += maxMarks
    const timeTakenSeconds = perQuestionSeconds[q.id] ?? 0
    const isCorrect = selected !== null && selected === pq.correctOption
    if (selected !== null) {
      attempted += 1
      if (isCorrect) {
        correct += 1
        marksObtained += maxMarks
      } else {
        wrong += 1
        marksObtained -= exam.negativeMarking
      }
    }
    answerRecords.push({
      questionId: q.id,
      questionText: q.text,
      options: pq.options,
      selectedOption: selected,
      correctOption: pq.correctOption,
      isCorrect,
      marksAwarded: isCorrect ? maxMarks : selected === null ? 0 : -exam.negativeMarking,
      maxMarks,
      timeTakenSeconds,
      explanation: q.explanation,
    })
  }

  // round to 2 decimals
  marksObtained = Math.round(marksObtained * 100) / 100
  const percentage = totalMarks > 0 ? Math.round((marksObtained / totalMarks) * 1000) / 10 : 0
  const status: 'passed' | 'failed' = percentage >= exam.passingPercentage ? 'passed' : 'failed'
  const startMs = new Date(startTimeISO).getTime()
  const endMs = new Date(endTimeISO).getTime()
  const timeTakenMinutes = Math.max(1, Math.round((endMs - startMs) / 60000))

  return {
    result: {
      studentId: '',
      studentName: '',
      examId: exam.id,
      examTitle: exam.title,
      chapterName: exam.chapterName,
      attemptNumber: 1,
      startTime: startTimeISO.replace('T', ' ').slice(0, 16),
      endTime: endTimeISO.replace('T', ' ').slice(0, 16),
      timeTakenMinutes,
      totalQuestions: prepared.length,
      attempted,
      correct,
      wrong,
      marksObtained,
      totalMarks,
      percentage,
      status,
      answers: answerRecords,
    },
    answerRecords,
  }
}

type Phase = 'intro' | 'live' | 'submitting' | 'review'

export interface ExamRunnerProps {
  exam: Exam
  /** Called when the user exits (after review or by pressing Back). */
  onExit: () => void
  /** Auto-start (skip intro confirmation)? Defaults to false. */
  autoStart?: boolean
}

export function ExamRunner({ exam, onExit, autoStart = false }: ExamRunnerProps) {
  const user = useAppStore((s) => s.user)
  const setExamInProgress = useAppStore((s) => s.setExamInProgress)
  const addResult = useDataStore((s) => s.addResult)
  const results = useDataStore((s) => s.results)
  const logActivity = useDataStore((s) => s.logActivity)

  const [phase, setPhase] = React.useState<Phase>(autoStart ? 'live' : 'intro')
  const [prepared] = React.useState<PreparedQuestion[]>(() => prepareExam(exam, user?.id ?? 'anon'))
  const [currentIdx, setCurrentIdx] = React.useState(0)
  const [answers, setAnswers] = React.useState<Record<string, number | null>>({})
  const [secondsLeft, setSecondsLeft] = React.useState(exam.duration * 60)
  const [perQuestionSeconds, setPerQuestionSeconds] = React.useState<Record<string, number>>({})
  const [startTime] = React.useState(() => new Date().toISOString())
  const [submitOpen, setSubmitOpen] = React.useState(false)
  const [savedResult, setSavedResult] = React.useState<Result | null>(null)
  const [hintLevel, setHintLevel] = React.useState<Record<string, number>>({})
  const [fingerprintCheck, setFingerprintCheck] = React.useState<{ status: string; previous?: string } | null>(null)

  // Question enter time tracking (for per-question time)
  const questionEnterRef = React.useRef<number>(Date.now())

  // ── Mark exam in-progress so the Friend chatbot hides itself. ──
  React.useEffect(() => {
    setExamInProgress(true)
    return () => setExamInProgress(false)
  }, [setExamInProgress])

  // ── Fingerprint check for proctored exams (run once on mount). ──
  React.useEffect(() => {
    if (exam.proctored && user?.id) {
      const check = checkFingerprint(user.id)
      setFingerprintCheck({ status: check.status, previous: check.previousFingerprint })
      if (check.status === 'mismatch') {
        toast.warning('Device changed', {
          description: 'This exam was last attempted from a different device. This has been logged.',
        })
      }
    }
  }, [exam.proctored, user?.id])

  // ── Proctoring hook (only active when exam.proctored is true). ──
  const proctor = useExamProctor({
    enabled: Boolean(exam.proctored),
    maxViolations: 3,
    onViolation: (s) => {
      const remaining = 3 - s.violationCount
      const labels: Record<ViolationType, string> = {
        'tab-switch': 'Switched tabs',
        'window-blur': 'Left the exam window',
        'fullscreen-exit': 'Exited full-screen',
        'copy-attempt': 'Tried to copy',
        'right-click': 'Right-click blocked',
        'drag-attempt': 'Drag blocked',
        'devtools': 'Developer tools blocked',
        'print': 'Print blocked',
      }
      toast.error(`${labels[s.lastViolation!] || 'Violation'} — warning ${s.violationCount} of 3`, {
        description: remaining > 0
          ? `${remaining} ${remaining === 1 ? 'warning' : 'warnings'} left before auto-submit.`
          : 'Auto-submitting your exam now.',
      })
    },
    onAutoSubmit: () => {
      toast.error('Exam auto-submitted', {
        description: 'You exceeded the maximum number of proctoring violations.',
      })
      handleSubmit(true, true)
    },
  })

  // Track per-question time when navigating
  const recordQuestionTime = React.useCallback(() => {
    const now = Date.now()
    const elapsed = Math.round((now - questionEnterRef.current) / 1000)
    const qid = prepared[currentIdx]?.question.id
    if (qid) {
      setPerQuestionSeconds((prev) => ({ ...prev, [qid]: (prev[qid] ?? 0) + elapsed }))
    }
    questionEnterRef.current = now
  }, [currentIdx, prepared])

  const goTo = React.useCallback((idx: number) => {
    recordQuestionTime()
    setCurrentIdx(Math.max(0, Math.min(prepared.length - 1, idx)))
  }, [prepared.length, recordQuestionTime])

  const selectAnswer = (qid: string, optionIdx: number) => {
    setAnswers((prev) => ({ ...prev, [qid]: optionIdx }))
  }

  const handleSubmit = React.useCallback((auto = false, proctorAutoSubmit = false) => {
    setPhase('submitting')
    setSubmitOpen(false)
    // record time for the current question
    const now = Date.now()
    const elapsed = Math.round((now - questionEnterRef.current) / 1000)
    const qid = prepared[currentIdx]?.question.id
    const finalPerQuestion = { ...perQuestionSeconds }
    if (qid) finalPerQuestion[qid] = (finalPerQuestion[qid] ?? 0) + elapsed

    const endTimeISO = new Date().toISOString()
    const { result } = gradeExam(exam, prepared, answers, finalPerQuestion, startTime, endTimeISO)

    if (!user) {
      toast.error('Session expired. Please log in again.')
      onExit()
      return
    }

    const attemptNumber =
      results.filter((r) => r.studentId === user.id && r.examId === exam.id).length + 1

    const created = addResult({
      ...result,
      studentId: user.id,
      studentName: user.name,
      attemptNumber,
    })
    setSavedResult(created)
    if (proctorAutoSubmit) {
      toast.error('Exam auto-submitted due to proctoring violations.')
    } else if (auto) {
      toast.info('Time up! Exam auto-submitted.')
    } else {
      toast.success(created.status === 'passed' ? 'Exam submitted — you passed! 🎉' : 'Exam submitted.')
    }
    if (created.status === 'passed') {
      logActivity({
        user: user.name,
        role: 'student',
        action: 'passed exam',
        target: exam.title,
        type: 'submit',
      })
    } else {
      logActivity({
        user: user.name,
        role: 'student',
        action: 'submitted exam',
        target: exam.title,
        type: 'submit',
      })
    }
    setPhase('review')
  }, [addResult, answers, currentIdx, exam, logActivity, onExit, perQuestionSeconds, prepared, results, startTime, user])

  // Countdown timer
  React.useEffect(() => {
    if (phase !== 'live') return
    const t = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(t)
          handleSubmit(true)
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(t)
  }, [phase, handleSubmit])

  // ─── Intro phase ───
  if (phase === 'intro') {
    return (
      <ExamIntroDialog
        exam={exam}
        questionCount={prepared.length}
        fingerprintStatus={fingerprintCheck?.status}
        onConfirm={() => {
          setPhase('live')
          questionEnterRef.current = Date.now()
          // Request fullscreen for proctored exams.
          if (exam.proctored) {
            proctor.requestFullscreen()
          }
          toast.success(`${exam.title} started. Good luck, ${user?.name?.split(' ')[0] ?? 'student'}!`)
        }}
        onCancel={onExit}
      />
    )
  }

  // ─── Review phase ───
  if (phase === 'review' && savedResult) {
    return <ExamReviewScreen exam={exam} result={savedResult} onExit={onExit} />
  }

  // ─── Live phase ───
  const current = prepared[currentIdx]
  const answeredCount = Object.values(answers).filter((v) => v !== null && v !== undefined).length
  const isLast = currentIdx === prepared.length - 1
  const lowTime = secondsLeft <= 60

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Top bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-card/80 px-4 py-3 backdrop-blur sm:px-6">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold sm:text-base">{exam.title}</p>
          <p className="text-xs text-muted-foreground">{exam.chapterName}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className={cn(
            'flex items-center gap-2 rounded-lg px-3 py-1.5 font-mono text-base font-bold tabular-nums sm:text-lg',
            lowTime ? 'animate-pulse bg-rose-500/10 text-rose-600 dark:text-rose-400' : 'bg-primary/10 text-primary',
          )}>
            <Timer className="h-4 w-4" />
            {formatTime(secondsLeft)}
          </div>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setSubmitOpen(true)}
          >
            <Send className="h-4 w-4" /> <span className="hidden sm:inline">Submit</span>
          </Button>
        </div>
      </header>

      {/* Progress */}
      <div className="border-b bg-card/40 px-4 py-2 sm:px-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Question {currentIdx + 1} of {prepared.length}</span>
          <span>{answeredCount} answered · {prepared.length - answeredCount} left</span>
        </div>
        <Progress value={(answeredCount / prepared.length) * 100} className="mt-1.5 h-1.5" />
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col overflow-hidden lg:flex-row">
        {/* Question area */}
        <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
          <div className="mx-auto max-w-3xl">
            <div className="flex items-center justify-between gap-3">
              <Badge variant="outline" className="gap-1">
                <FileQuestion className="h-3 w-3" /> Q{currentIdx + 1}
              </Badge>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" /> {current.question.marks} marks</span>
                <span>·</span>
                <span className="capitalize">{current.question.difficulty}</span>
                {exam.negativeMarking > 0 && (
                  <>
                    <span>·</span>
                    <span className="text-rose-500">−{exam.negativeMarking} wrong</span>
                  </>
                )}
                {/* Hint button — disabled in proctored exams (integrity). */}
                {!exam.proctored && getHintLadder(current.question.id) && (
                  <>
                    <span>·</span>
                    <HintButton
                      questionId={current.question.id}
                      level={hintLevel[current.question.id] ?? 0}
                      onReveal={(lvl) => setHintLevel((p) => ({ ...p, [current.question.id]: lvl }))}
                    />
                  </>
                )}
              </div>
            </div>

            {/* Proctor violation banner (live) */}
            {exam.proctored && proctor.state.violationCount > 0 && !proctor.state.shouldAutoSubmit && (
              <div className="mt-3 flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-300">
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>
                  Proctor warning {proctor.state.violationCount} of 3 — {3 - proctor.state.violationCount} {3 - proctor.state.violationCount === 1 ? 'warning' : 'warnings'} left before auto-submit.
                </span>
              </div>
            )}

            <h2 className="mt-4 text-lg font-semibold leading-snug sm:text-xl">
              {current.question.text}
            </h2>

            {current.question.imageData && (
              <img
                src={current.question.imageData}
                alt="Question illustration"
                className="mt-3 max-w-full rounded-lg border"
              />
            )}

            <div className="mt-6 space-y-3">
              {current.options.map((opt, i) => {
                const selected = answers[current.question.id] === i
                // For true/false questions, empty options may exist — hide them
                if (!opt && current.options.length > 2) return null
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => selectAnswer(current.question.id, i)}
                    className={cn(
                      'flex w-full items-center gap-3 rounded-xl border-2 p-4 text-left transition-all hover:bg-muted/40',
                      selected
                        ? 'border-primary bg-primary/5 ring-1 ring-primary/30'
                        : 'border-border bg-card',
                    )}
                  >
                    <span className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-sm font-bold',
                      selected
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-border text-muted-foreground',
                    )}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className={cn('text-sm sm:text-base', selected && 'font-medium')}>{opt}</span>
                  </button>
                )
              })}
            </div>

            {/* Hint display panel (non-proctored exams only) */}
            {!exam.proctored && (hintLevel[current.question.id] ?? 0) > 0 && (
              <HintPanel
                questionId={current.question.id}
                level={hintLevel[current.question.id]}
              />
            )}

            {/* Footer nav */}
            <div className="mt-8 flex items-center justify-between gap-3">
              <Button
                variant="outline"
                onClick={() => goTo(currentIdx - 1)}
                disabled={currentIdx === 0}
              >
                <ChevronLeft className="h-4 w-4" /> Previous
              </Button>
              <div className="hidden items-center gap-1 text-xs text-muted-foreground sm:flex">
                <Flag className="h-3.5 w-3.5" /> You can change answers before submitting
              </div>
              {isLast ? (
                <Button variant="default" onClick={() => setSubmitOpen(true)}>
                  <Send className="h-4 w-4" /> Submit Exam
                </Button>
              ) : (
                <Button onClick={() => goTo(currentIdx + 1)}>
                  Next <ChevronRight className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Question palette (desktop sidebar) */}
        <aside className="hidden w-72 shrink-0 border-l bg-card/40 lg:block">
          <div className="sticky top-0 p-5">
            <p className="text-sm font-semibold">Question Palette</p>
            <p className="text-xs text-muted-foreground">Click any number to jump</p>
            <div className="mt-4 grid grid-cols-5 gap-2">
              {prepared.map((pq, i) => {
                const ans = answers[pq.question.id]
                const isAnswered = ans !== undefined && ans !== null
                const isCurrent = i === currentIdx
                return (
                  <button
                    key={pq.question.id}
                    onClick={() => goTo(i)}
                    className={cn(
                      'flex h-10 w-10 items-center justify-center rounded-lg border-2 text-sm font-semibold transition-all',
                      isCurrent
                        ? 'border-primary bg-primary text-primary-foreground'
                        : isAnswered
                          ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                          : 'border-border bg-card text-muted-foreground hover:border-primary/40',
                    )}
                  >
                    {i + 1}
                  </button>
                )
              })}
            </div>
            <div className="mt-5 space-y-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded border-2 border-emerald-500/40 bg-emerald-500/10" /> Answered
              </div>
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded border-2 border-primary bg-primary" /> Current
              </div>
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded border-2 border-border bg-card" /> Not answered
              </div>
            </div>
            <Button
              className="mt-5 w-full"
              variant="destructive"
              onClick={() => setSubmitOpen(true)}
            >
              <Send className="h-4 w-4" /> Submit Exam
            </Button>
          </div>
        </aside>
      </div>

      {/* Submit confirmation */}
      <Dialog open={submitOpen} onOpenChange={setSubmitOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" /> Submit exam?
            </DialogTitle>
            <DialogDescription>
              You answered <strong>{answeredCount}</strong> of <strong>{prepared.length}</strong> questions.
              {prepared.length - answeredCount > 0 && (
                <> {prepared.length - answeredCount} unanswered will be marked as not attempted.</>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-lg bg-amber-500/10 p-3 text-sm text-amber-800 dark:text-amber-300">
            Once submitted, you cannot change your answers. Results will be calculated instantly.
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSubmitOpen(false)}>Keep Working</Button>
            <Button variant="destructive" onClick={() => handleSubmit(false)}>
              <Send className="h-4 w-4" /> Submit Now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Submitting overlay */}
      <AnimatePresence>
        {phase === 'submitting' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm"
          >
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            <p className="mt-4 text-sm font-medium">Grading your exam…</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─────────────────────── Intro Dialog ───────────────────────

function ExamIntroDialog({
  exam, questionCount, fingerprintStatus, onConfirm, onCancel,
}: {
  exam: Exam
  questionCount: number
  fingerprintStatus?: string
  onConfirm: () => void
  onCancel: () => void
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-xl border bg-background p-6 shadow-2xl"
      >
        <div className="flex items-start gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <FileQuestion className="h-6 w-6" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-lg font-bold">{exam.title}</h3>
            <p className="text-sm text-muted-foreground">{exam.chapterName} · {exam.type.replace(/_/g, ' ')}</p>
          </div>
          {exam.proctored && (
            <Badge className="gap-1 border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-400" variant="outline">
              <Lock className="h-3 w-3" /> PROCTORED
            </Badge>
          )}
        </div>

        <p className="mt-4 text-sm text-muted-foreground">{exam.instructions}</p>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Duration" value={`${exam.duration} min`} icon={Clock} />
          <Stat label="Total Marks" value={`${exam.marks}`} icon={Target} />
          <Stat label="Questions" value={`${questionCount}`} icon={FileQuestion} />
          <Stat label="Pass %" value={`${exam.passingPercentage}%`} icon={CheckCircle2} />
        </div>

        {exam.negativeMarking > 0 && (
          <div className="mt-4 flex items-start gap-2 rounded-lg bg-rose-500/10 p-3 text-sm text-rose-700 dark:text-rose-300">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <p>Negative marking of <strong>−{exam.negativeMarking}</strong> per wrong answer. Unanswered questions are not penalized.</p>
          </div>
        )}
        {exam.shuffleQuestions && (
          <p className="mt-3 text-xs text-muted-foreground">
            <Flag className="mr-1 inline h-3 w-3" />
            Questions and options will be shuffled for this attempt.
          </p>
        )}
        {exam.questionPoolIds && exam.questionPoolIds.length > 0 && (
          <p className="mt-3 text-xs text-muted-foreground">
            <Flag className="mr-1 inline h-3 w-3" />
            Question pool: {exam.questionsToPick} questions picked from a pool of {exam.questionPoolIds.length} — each student sees a different set.
          </p>
        )}

        {exam.proctored && (
          <div className="mt-4 rounded-lg border border-rose-500/30 bg-rose-500/5 p-3">
            <p className="flex items-center gap-1.5 text-sm font-semibold text-rose-700 dark:text-rose-400">
              <ShieldAlert className="h-4 w-4" /> Lockdown rules — read carefully
            </p>
            <ul className="mt-2 space-y-1 text-xs text-rose-700/90 dark:text-rose-300/90">
              <li>• The exam runs in full-screen mode. Exiting full-screen counts as a violation.</li>
              <li>• Switching tabs or windows = 1 warning. <strong>3 warnings and your exam auto-submits.</strong></li>
              <li>• Right-click, copy, cut, drag and print are blocked.</li>
              <li>• Keyboard shortcuts like Ctrl+C, Ctrl+P, F12 and Ctrl+Shift+I are disabled.</li>
              <li>• Your device is verified to detect if the exam is taken from a different device.</li>
            </ul>
          </div>
        )}

        {exam.proctored && fingerprintStatus && (
          <div className="mt-3 flex items-start gap-2 rounded-lg bg-muted/60 p-2.5 text-xs text-muted-foreground">
            <Fingerprint className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>
              {fingerprintStatus === 'first' && 'Device verified — this is your first proctored exam on this device.'}
              {fingerprintStatus === 'match' && 'Device verified — matches your previous proctored exam.'}
              {fingerprintStatus === 'mismatch' && '⚠ This exam was last attempted from a different device. This has been logged for your teacher.'}
            </span>
          </div>
        )}

        <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={onConfirm}>
            <Timer className="h-4 w-4" /> {exam.proctored ? 'Start Proctored Exam' : 'Start Exam Now'}
          </Button>
        </div>
      </motion.div>
    </div>
  )
}

function Stat({ label, value, icon: Icon }: { label: string; value: string; icon: React.ComponentType<{ className?: string }> }) {
  return (
    <div className="rounded-xl border bg-card p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <p className="mt-1 text-base font-bold tabular-nums">{value}</p>
    </div>
  )
}

// ─────────────────────── Review Screen ───────────────────────

function ExamReviewScreen({ exam, result, onExit }: { exam: Exam; result: Result; onExit: () => void }) {
  const passed = result.status === 'passed'
  const unattempted = result.totalQuestions - result.attempted

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6 sm:py-8">
        {/* Banner */}
        <motion.div
          initial={{ opacity: 0, y: 14, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.4 }}
          className={cn(
            'relative overflow-hidden rounded-2xl border p-6 text-white shadow-lg sm:p-8',
            passed
              ? 'border-emerald-600/30 bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700'
              : 'border-rose-600/30 bg-gradient-to-br from-rose-500 via-rose-600 to-rose-800',
          )}
        >
          <div className="absolute inset-0 bg-grid-white/10 opacity-30" />
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div className="relative flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                {passed ? <Trophy className="h-6 w-6 text-amber-300" /> : <AlertTriangle className="h-6 w-6 text-rose-100" />}
                <span className="text-lg font-bold tracking-tight sm:text-2xl">
                  {passed ? 'Congratulations! You passed 🎉' : 'Not quite — keep practicing'}
                </span>
              </div>
              <p className="mt-1 text-sm text-white/85">{exam.title}</p>
              <p className="text-xs text-white/70">{exam.chapterName} · Attempt #{result.attemptNumber}</p>
            </div>
            {/* Score circle */}
            <div className="flex items-center gap-3 rounded-2xl bg-white/15 p-4 backdrop-blur-sm">
              <div className="text-center">
                <p className="text-3xl font-bold tabular-nums sm:text-4xl">{result.percentage}%</p>
                <p className="text-[11px] uppercase tracking-wide text-white/80">Score</p>
              </div>
              <div className="h-12 w-px bg-white/30" />
              <div className="text-center">
                <p className="text-3xl font-bold tabular-nums sm:text-4xl">{result.marksObtained}<span className="text-base">/{result.totalMarks}</span></p>
                <p className="text-[11px] uppercase tracking-wide text-white/80">Marks</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats grid */}
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <ReviewStat label="Correct" value={result.correct} icon={CheckCircle2} className="text-emerald-600 dark:text-emerald-400" />
          <ReviewStat label="Wrong" value={result.wrong} icon={XCircle} className="text-rose-600 dark:text-rose-400" />
          <ReviewStat label="Unattempted" value={unattempted} icon={FileQuestion} className="text-amber-600 dark:text-amber-400" />
          <ReviewStat label="Time Taken" value={`${result.timeTakenMinutes} min`} icon={Clock} className="text-primary" />
        </div>

        {/* Pass/fail threshold */}
        <div className="mt-4 rounded-xl border bg-card p-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Passing threshold</span>
            <span className="font-semibold">{exam.passingPercentage}%</span>
          </div>
          <Progress value={result.percentage} className="mt-2 h-2" />
          <p className="mt-2 text-xs text-muted-foreground">
            You scored {result.percentage}% — {passed ? 'above' : 'below'} the passing threshold.
            {exam.negativeMarking > 0 && ` Negative marking: −${exam.negativeMarking} per wrong answer applied.`}
          </p>
        </div>

        {/* Question-by-question review */}
        <div className="mt-6">
          <h3 className="flex items-center gap-2 text-lg font-bold">
            <FileQuestion className="h-5 w-5 text-primary" /> Question Review
          </h3>
          <p className="text-sm text-muted-foreground">Each question with your answer and the correct solution.</p>

          <div className="mt-4 space-y-4">
            {result.answers.map((a, i) => (
              <AnswerReviewCard key={a.questionId} answer={a} index={i} />
            ))}
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-8 flex flex-col gap-2 sm:flex-row sm:justify-between">
          <Button variant="outline" onClick={onExit}>
            <ArrowLeft className="h-4 w-4" /> Back to Exams
          </Button>
          {passed && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-700 dark:text-emerald-300">
              <Award className="h-4 w-4" />
              A certificate has been generated for this achievement.
            </div>
          )}
          <Button onClick={onExit}>
            <RotateCcw className="h-4 w-4" /> Done
          </Button>
        </div>
      </div>
    </div>
  )
}

function ReviewStat({
  label, value, icon: Icon, className,
}: {
  label: string
  value: string | number
  icon: React.ComponentType<{ className?: string }>
  className?: string
}) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className={cn('flex items-center gap-1.5 text-xs', className)}>
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <p className="mt-1 text-2xl font-bold tabular-nums">{value}</p>
    </div>
  )
}

function AnswerReviewCard({ answer, index }: { answer: AnswerRecord; index: number }) {
  const { questionText, options, selectedOption, correctOption, isCorrect, marksAwarded, maxMarks, explanation } = answer
  const unattempted = selectedOption === null
  // Look up the live Question to access the optional explanation image
  // (AnswerRecord itself doesn't carry it).
  const questions = useDataStore((s) => s.questions)
  const liveQuestion = questions.find((q) => q.id === answer.questionId)
  const explanationImage = liveQuestion?.explanationImage
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.04, 0.5) }}
      className={cn(
        'overflow-hidden rounded-xl border bg-card',
        isCorrect ? 'border-emerald-500/30' : unattempted ? 'border-amber-500/30' : 'border-rose-500/30',
      )}
    >
      <div className="flex items-start justify-between gap-3 border-b bg-muted/30 px-4 py-3">
        <div className="flex items-start gap-3">
          <span className={cn(
            'flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-xs font-bold',
            isCorrect ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400'
              : unattempted ? 'bg-amber-500/15 text-amber-700 dark:text-amber-400'
              : 'bg-rose-500/15 text-rose-700 dark:text-rose-400',
          )}>
            Q{index + 1}
          </span>
          <p className="text-sm font-medium leading-snug sm:text-base">{questionText}</p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {isCorrect ? (
            <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
              <CheckCircle2 className="h-3 w-3" /> Correct
            </Badge>
          ) : unattempted ? (
            <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15">
              <FileQuestion className="h-3 w-3" /> Skipped
            </Badge>
          ) : (
            <Badge className="bg-rose-500/15 text-rose-700 dark:text-rose-400 hover:bg-rose-500/15">
              <XCircle className="h-3 w-3" /> Wrong
            </Badge>
          )}
          <span className={cn(
            'text-xs font-semibold tabular-nums',
            marksAwarded > 0 ? 'text-emerald-600 dark:text-emerald-400'
              : marksAwarded < 0 ? 'text-rose-600 dark:text-rose-400'
              : 'text-muted-foreground',
          )}>
            {marksAwarded > 0 ? '+' : ''}{marksAwarded}/{maxMarks}
          </span>
        </div>
      </div>

      <div className="space-y-2 p-4">
        {options.map((opt, i) => {
          if (!opt && options.length > 2) return null
          const isCorrectOpt = i === correctOption
          const isSel = i === selectedOption
          return (
            <div
              key={i}
              className={cn(
                'flex items-center gap-3 rounded-lg border-2 px-3 py-2 text-sm',
                isCorrectOpt
                  ? 'border-emerald-500/50 bg-emerald-500/10 text-foreground'
                  : isSel
                    ? 'border-rose-500/50 bg-rose-500/10 text-foreground'
                    : 'border-border bg-card text-muted-foreground',
              )}
            >
              <span className={cn(
                'flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs font-bold',
                isCorrectOpt
                  ? 'border-emerald-500 bg-emerald-500 text-white'
                  : isSel
                    ? 'border-rose-500 bg-rose-500 text-white'
                    : 'border-border text-muted-foreground',
              )}>
                {String.fromCharCode(65 + i)}
              </span>
              <span className="flex-1">{opt}</span>
              {isCorrectOpt && <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />}
              {isSel && !isCorrectOpt && <XCircle className="h-4 w-4 text-rose-600 dark:text-rose-400" />}
            </div>
          )
        })}

        {unattempted && (
          <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-300">
            You didn't attempt this question. The correct answer is option <strong>{String.fromCharCode(65 + correctOption)}</strong>.
          </p>
        )}

        <div className="mt-2 rounded-lg bg-primary/5 px-3 py-2.5 text-xs">
          <p className="font-semibold text-primary">Explanation</p>
          {/* v3.53.6 — whitespace-pre-wrap preserves newlines in multi-line
              explanations (e.g. step-by-step working imported from Word/PDF). */}
          <p className="mt-0.5 whitespace-pre-wrap text-muted-foreground">{explanation}</p>
          {explanationImage && (
            <img
              src={explanationImage}
              alt="Explanation illustration"
              className="mt-2 max-w-full rounded-lg border"
            />
          )}
        </div>
      </div>
    </motion.div>
  )
}

// ─────────────────────── Hint Button + Panel (v3.27.0) ───────────────────────

function HintButton({
  questionId, level, onReveal,
}: {
  questionId: string
  level: number
  onReveal: (level: number) => void
}) {
  const ladder = getHintLadder(questionId)
  if (!ladder) return null
  const maxLevel = ladder.length
  const nextLevel = level + 1
  const exhausted = level >= maxLevel

  return (
    <button
      type="button"
      onClick={() => !exhausted && onReveal(nextLevel)}
      disabled={exhausted}
      className={cn(
        'flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium transition-colors',
        exhausted
          ? 'cursor-not-allowed bg-muted text-muted-foreground/60'
          : 'bg-amber-500/15 text-amber-700 hover:bg-amber-500/25 dark:text-amber-400',
      )}
      title={exhausted ? 'All hints revealed' : `Show hint ${nextLevel} of ${maxLevel}`}
    >
      <Lightbulb className="h-3 w-3" />
      {exhausted ? 'No more hints' : `Hint ${nextLevel}/${maxLevel}`}
    </button>
  )
}

function HintPanel({ questionId, level }: { questionId: string; level: number }) {
  const ladder = getHintLadder(questionId)
  if (!ladder) return null
  const labels = ['Concept nudge', 'Formula / method', 'Half-worked set-up']
  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      className="mt-4 space-y-2"
    >
      {ladder.slice(0, level).map((hint, i) => (
        <div
          key={i}
          className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs"
        >
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-[10px] font-bold text-amber-700 dark:text-amber-400">
            {i + 1}
          </span>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-amber-700/70 dark:text-amber-400/70">
              {labels[i] ?? `Hint ${i + 1}`}
            </p>
            <p className="mt-0.5 text-foreground">{hint}</p>
          </div>
        </div>
      ))}
    </motion.div>
  )
}
