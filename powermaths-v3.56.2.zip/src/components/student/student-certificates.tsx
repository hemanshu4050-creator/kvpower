'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  Award, Download, Share2, GraduationCap, Sparkles, ShieldCheck, Calendar,
  Printer, Eye, QrCode, BadgeCheck, Star, Crown, BookOpen, Layers, Loader2,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { StatCard } from '@/components/shared/stat-card'
import { EmptyState } from '@/components/shared/empty-state'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { useDataStore, type Certificate } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import {
  resolveTemplate, scoreTier, bgGradient, brandGradient,
  sealGradient, withAlpha, toHex, buildCertificateHtml,
} from '@/lib/certificate-template'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

export function StudentCertificates() {
  const pageTitle = useNavLabel('certificates', 'My Certificates', 'student')
  const user = useAppStore((s) => s.user)
  const certificates = useDataStore((s) => s.certificates)

  const myCerts = React.useMemo(() => {
    if (!user) return []
    return certificates
      .filter((c) => c.studentId === user.id && c.status === 'issued')
      .sort((a, b) => b.issuedAt.localeCompare(a.issuedAt))
  }, [certificates, user])

  const thisYear = myCerts.filter((c) => c.issuedAt.startsWith(String(new Date().getFullYear()))).length
  const highestScore = myCerts.length ? Math.max(...myCerts.map((c) => c.score)) : 0
  const chaptersMastered = new Set(myCerts.map((c) => c.chapterName)).size

  const [previewCert, setPreviewCert] = React.useState<Certificate | null>(null)

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Your earned achievements — printable and shareable"
        icon={<Award className="h-5 w-5" />}
        actions={
          myCerts.length > 0 ? (
            <Button variant="outline" size="sm" onClick={() => toast.success('Preparing all certificates for printing…')}>
              <Printer className="h-4 w-4" /> Print All
            </Button>
          ) : undefined
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Certificates" value={myCerts.length} icon={Award} accent="emerald" delay={0.05} />
        <StatCard title="This Year" value={thisYear} icon={Calendar} accent="teal" delay={0.1} />
        <StatCard title="Highest Score" value={`${highestScore}%`} icon={Sparkles} accent="amber" delay={0.15} />
        <StatCard title="Chapters Mastered" value={chaptersMastered} icon={GraduationCap} accent="violet" delay={0.2} />
      </div>

      {myCerts.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={Award}
              title="No certificates yet"
              description="Pass a chapter exam to earn your first certificate. Keep practicing!"
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {myCerts.map((cert, i) => (
            <motion.div
              key={cert.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <CertificateCard
                cert={cert}
                onView={() => setPreviewCert(cert)}
                onPrint={() => printCertificate(cert)}
                onDownload={() => downloadCertificatePdf(cert)}
                onShare={() => {
                  const url = `${window.location.origin}/?verify=${cert.certificateNumber}`
                  navigator.clipboard?.writeText(url).catch(() => {})
                  toast.success('Verification link copied!', { description: cert.certificateNumber })
                }}
              />
            </motion.div>
          ))}
        </div>
      )}

      {/* Full-screen certificate preview / print dialog */}
      <CertificatePreviewDialog
        cert={previewCert}
        onClose={() => setPreviewCert(null)}
      />
    </div>
  )
}

// ─────────────────────── Certificate Card (grid view) ───────────────────────

function CertificateCard({
  cert, onView, onPrint, onDownload, onShare,
}: {
  cert: Certificate
  onView: () => void
  onPrint: () => void
  onDownload: () => void
  onShare: () => void
}) {
  const template = resolveTemplate(useDataStore((s) => s.settings.certificateTemplate))
  const [downloading, setDownloading] = React.useState(false)

  const handleDownload = async () => {
    if (downloading) return
    setDownloading(true)
    try {
      await onDownload()
    } finally {
      setDownloading(false)
    }
  }

  return (
    <Card className="card-elevated group overflow-hidden p-0">
      {/* Mini certificate preview */}
      <button
        onClick={onView}
        className="relative block aspect-[1.5/1] w-full overflow-hidden text-left transition-transform duration-300 group-hover:scale-[1.02]"
        style={{ background: bgGradient(template) }}
      >
        <CertificateArtwork cert={cert} compact />
        {/* Hover overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition-all duration-300 group-hover:bg-black/30 group-hover:opacity-100">
          <span className="flex items-center gap-2 rounded-full bg-white/95 px-4 py-2 text-sm font-medium text-foreground shadow-lg">
            <Eye className="h-4 w-4" /> View certificate
          </span>
        </div>
      </button>

      {/* Actions */}
      <div className="flex items-center justify-between gap-2 border-t bg-muted/30 px-3 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          {cert.certificateType === 'level' ? (
            <Badge variant="outline" className="gap-1 border-violet-500/30 bg-violet-500/5 text-violet-700 dark:text-violet-300">
              <Layers className="h-3 w-3" /> Level
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1 border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400">
              <ShieldCheck className="h-3 w-3" /> Verified
            </Badge>
          )}
          <span className="truncate text-xs text-muted-foreground">
            {cert.certificateType === 'level'
              ? `${cert.levelName ?? cert.chapterName} · ${cert.certificateNumber}`
              : `${cert.chapterName} · ${cert.certificateNumber}`}
          </span>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <Button variant="outline" size="sm" onClick={onPrint}>
            <Printer className="h-4 w-4" /> <span className="hidden sm:inline">Print</span>
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload} disabled={downloading}>
            {downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            <span className="hidden sm:inline">{downloading ? '…' : 'Download'}</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={onShare}>
            <Share2 className="h-4 w-4" /> <span className="hidden sm:inline">Share</span>
          </Button>
        </div>
      </div>
    </Card>
  )
}

// ─────────────────────── Certificate Artwork ───────────────────────
// The actual visual certificate — used both in the grid card (compact),
// in the full preview / print view (full), AND in the Settings → Certificates
// live preview (where the template prop is passed in directly).
//
// v3.29.0 — every visual aspect is now driven by the editable
// CertificateTemplate (read from the store, or passed in for the admin
// Settings preview).

export function CertificateArtwork({
  cert, compact = false, template: templateProp,
}: {
  cert: Certificate
  compact?: boolean
  /** Optional override (used by the Settings live preview so the admin sees
   *  their unsaved edits instantly without going through the store). */
  template?: Certificate['studentId'] extends never ? never : import('@/lib/data-store').CertificateTemplate
}) {
  const storeTemplate = useDataStore((s) => s.settings.certificateTemplate)
  const template = resolveTemplate(templateProp ?? storeTemplate)
  const tier = scoreTier(cert.score, template)
  const isLevelCert = cert.certificateType === 'level'
  // Level certs list up to 6 chapters in-card; the rest get a "+N more" hint.
  const levelChapters = isLevelCert ? (cert.chapterNames ?? []) : []

  const showOuter = template.layout !== 'minimal'
  const showInner = template.layout === 'classic'
  const showCorners = template.layout === 'classic' && template.showCornerFlourishes

  return (
    <div className={cn('relative h-full w-full', compact && 'scale-[0.62] sm:scale-[0.72]')}>
      {/* Ornate double border (template-driven) */}
      {showOuter && (
        <div
          className="absolute inset-2.5 rounded-lg border-[2.5px]"
          style={{ borderColor: withAlpha(template.borderOuterColor, 0.4) }}
        />
      )}
      {showInner && (
        <div
          className="absolute inset-4 rounded-md border"
          style={{ borderColor: withAlpha(template.borderInnerColor, 0.5) }}
        />
      )}

      {/* Corner flourishes (template-driven) */}
      {showCorners && (
        <>
          {[
            'left-3 top-3 rounded-tl-lg border-l-[2.5px] border-t-[2.5px]',
            'right-3 top-3 rounded-tr-lg border-r-[2.5px] border-t-[2.5px]',
            'bottom-3 left-3 rounded-bl-lg border-b-[2.5px] border-l-[2.5px]',
            'bottom-3 right-3 rounded-br-lg border-b-[2.5px] border-r-[2.5px]',
          ].map((cls, i) => (
            <div
              key={i}
              className={cn('absolute h-7 w-7', cls)}
              style={{ borderColor: withAlpha(template.borderOuterColor, 0.7) }}
            />
          ))}
        </>
      )}

      {/* Decorative watermark pattern */}
      <div
        className="pointer-events-none absolute inset-6 opacity-[0.04]"
        aria-hidden
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
          backgroundSize: '24px 24px',
        }}
      />

      {/* Central graduation cap watermark (template-driven) */}
      {template.showWatermark && (
        <GraduationCap
          className="pointer-events-none absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2"
          style={{ color: withAlpha(template.primaryColor, 0.05) }}
        />
      )}

      {/* Content */}
      <div
        className="relative flex h-full flex-col items-center justify-center px-10 py-6 text-center"
        style={{ color: toHex(template.textColor) }}
      >
        {/* Header — brand + medal */}
        <div className="flex items-center gap-3">
          {/* v3.31 — Official Power Maths logo (circular badge). Replaces the
              old GraduationCap-in-gradient placeholder so every printed /
              on-screen certificate carries the real brand mark.
              v3.34 — enlarged from h-9 w-9 to h-14 w-14.
              v3.35 — uses the transparent-background PNG (no white "patch"
              around the logo) and enlarged to h-20 w-20. Removed the white
              bg/shadow/ring so the logo blends into the certificate gradient. */}
          <div className="flex h-20 w-20 shrink-0 items-center justify-center">
            <img
              src="/branding/power-maths-logo-transparent.png"
              alt="Power Maths"
              className="h-full w-full object-contain"
            />
          </div>
          <div className="text-left">
            <p
              className="text-base font-bold leading-none tracking-wide"
              style={{ color: toHex(template.primaryColor) }}
            >
              {template.brandName}
            </p>
            <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              {template.brandSub}
            </p>
          </div>
        </div>

        {/* Divider with star */}
        <div className="my-2 flex items-center gap-2">
          <div
            className="h-px w-12"
            style={{ background: `linear-gradient(to right, transparent, ${withAlpha(template.accentColor, 0.5)})` }}
          />
          <Star
            className="h-3 w-3"
            style={{ color: toHex(template.accentColor), fill: toHex(template.accentColor) }}
          />
          <div
            className="h-px w-12"
            style={{ background: `linear-gradient(to left, transparent, ${withAlpha(template.accentColor, 0.5)})` }}
          />
        </div>

        {/* Title — for level certs override the template title to make the
            scope explicit. */}
        <h3
          className="text-xl font-bold tracking-tight sm:text-2xl"
          style={{ fontFamily: `'${template.titleFont}', serif`, color: toHex(template.textColor) }}
        >
          {isLevelCert ? 'Level Completion Certificate' : template.title}
        </h3>
        <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          {isLevelCert ? 'Successful completion of an entire learning level' : template.subtitle}
        </p>

        {/* Student name */}
        <p
          className="mt-2 text-2xl font-semibold italic sm:text-3xl"
          style={{ fontFamily: `'${template.titleFont}', serif`, color: toHex(template.nameColor) }}
        >
          {cert.studentName}
        </p>

        {/* Underline flourish */}
        <div className="mt-1 flex items-center gap-1.5">
          <div
            className="h-px w-32"
            style={{ background: `linear-gradient(to right, transparent, ${withAlpha(template.primaryColor, 0.6)}, transparent)` }}
          />
        </div>

        {isLevelCert ? (
          <>
            {/* Level completion line + level name */}
            <p className="mt-3 text-xs text-muted-foreground sm:text-sm">
              has successfully completed
            </p>
            <p className="text-base font-bold sm:text-lg" style={{ color: toHex(template.primaryColor) }}>
              {cert.levelName ?? cert.chapterName}
            </p>

            {/* Chapter list — 2-column grid, max 6 visible + "+N more" */}
            {levelChapters.length > 0 && (
              <div className="mt-3 grid w-full max-w-md grid-cols-2 gap-x-4 gap-y-1 px-2 text-left">
                {levelChapters.slice(0, 6).map((name, i) => (
                  <div key={`${name}-${i}`} className="flex items-center gap-1.5 text-[11px]">
                    <span
                      className="font-mono text-[9px] tabular-nums"
                      style={{ color: toHex(template.accentColor) }}
                    >
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="truncate" style={{ color: toHex(template.textColor) }}>
                      {name}
                    </span>
                  </div>
                ))}
                {levelChapters.length > 6 && (
                  <div className="col-span-2 text-center text-[10px] italic text-muted-foreground">
                    + {levelChapters.length - 6} more chapters
                  </div>
                )}
              </div>
            )}
          </>
        ) : (
          <>
            {/* Details */}
            <p className="mt-3 text-xs text-muted-foreground sm:text-sm">
              {template.completionLine} the
            </p>
            <p className="text-sm font-semibold sm:text-base" style={{ color: toHex(template.textColor) }}>
              {cert.chapterName}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              chapter examination · <span className="font-medium">{cert.examTitle}</span>
            </p>

            {/* Score badge (template-driven) */}
            {template.showScoreBadge && (
              <div className="mt-3">
                <span
                  className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold"
                  style={{
                    background: withAlpha(
                      tier.kind === 'distinction' ? template.accentColor : tier.kind === 'merit' ? template.primaryColor : '#0d9488',
                      0.15,
                    ),
                    color: tier.kind === 'distinction'
                      ? toHex(template.accentColor)
                      : tier.kind === 'merit'
                      ? toHex(template.primaryColor)
                      : '#0f766e',
                  }}
                >
                  {tier.kind === 'distinction' ? <><Crown className="h-3.5 w-3.5" /> {tier.label}</>
                    : tier.kind === 'merit' ? <><Sparkles className="h-3.5 w-3.5" /> {tier.label}</>
                    : <><BadgeCheck className="h-3.5 w-3.5" /> {tier.label}</>}
                  with {cert.score}%
                </span>
              </div>
            )}
          </>
        )}

        {/* Footer — date / seal / signature (template-driven) */}
        <div className="mt-auto flex w-full items-end justify-between pt-4">
          {/* Date */}
          {template.showDate ? (
            <div className="text-left">
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground">Date issued</p>
              <p className="text-xs font-medium" style={{ color: toHex(template.textColor) }}>{cert.issuedAt}</p>
              <div className="mt-0.5 h-px w-20 bg-foreground/30" />
            </div>
          ) : <div />}

          {/* Center seal (template-driven emoji + text) */}
          <div className="relative flex h-16 w-16 items-center justify-center">
            <div
              className="absolute inset-0 rotate-12 rounded-full border-2 border-dashed"
              style={{ borderColor: withAlpha(template.accentColor, 0.5) }}
            />
            <div
              className="absolute inset-1.5 rounded-full border"
              style={{ borderColor: withAlpha(template.accentColor, 0.3) }}
            />
            <div
              className="flex h-12 w-12 flex-col items-center justify-center rounded-full text-white shadow-lg"
              style={{ background: sealGradient(template) }}
            >
              <span className="text-[10px] leading-none">{template.sealEmoji}</span>
              <span className="text-[6px] font-bold uppercase tracking-wider">{template.sealText}</span>
            </div>
          </div>

          {/* Signature (template-driven) */}
          <div className="text-right">
            <p className="text-[9px] uppercase tracking-wider text-muted-foreground">{template.instructorTitle}</p>
            <p
              className="text-sm italic"
              style={{ fontFamily: `'${template.titleFont}', serif`, color: toHex(template.textColor) }}
            >
              {template.instructorName}
            </p>
            <div className="mt-0.5 h-px w-24 bg-foreground/30" />
          </div>
        </div>

        {/* Serial number (template-driven) */}
        {template.showSerial && (
          <p className="mt-2 text-[8px] uppercase tracking-[0.15em] text-muted-foreground/70">
            Serial · {cert.certificateNumber}
          </p>
        )}
      </div>
    </div>
  )
}

// ─────────────────────── Full Preview / Print Dialog ───────────────────────

function CertificatePreviewDialog({
  cert, onClose,
}: {
  cert: Certificate | null
  onClose: () => void
}) {
  const template = resolveTemplate(useDataStore((s) => s.settings.certificateTemplate))
  const [downloading, setDownloading] = React.useState(false)
  if (!cert) return null

  const handleDownload = async () => {
    if (downloading || !cert) return
    setDownloading(true)
    try {
      await downloadCertificatePdf(cert)
    } finally {
      setDownloading(false)
    }
  }

  return (
    <Dialog open={!!cert} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[94vh] overflow-y-auto p-0 sm:max-w-3xl">
        <DialogHeader className="border-b bg-gradient-to-r from-emerald-500/5 to-amber-500/5 px-5 py-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <DialogTitle className="text-base">Certificate preview</DialogTitle>
                <DialogDescription>
                  {cert.studentName} ·{' '}
                  {cert.certificateType === 'level'
                    ? `${cert.levelName ?? cert.chapterName} (Level Completion)`
                    : cert.chapterName}
                </DialogDescription>
              </div>
            </div>
            {cert.certificateType === 'level' ? (
              <Badge variant="outline" className="gap-1 border-violet-500/30 bg-violet-500/5 text-violet-700 dark:text-violet-300">
                <Layers className="h-3 w-3" /> Level
              </Badge>
            ) : (
              <Badge variant="outline" className="gap-1 border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400">
                <ShieldCheck className="h-3 w-3" /> Verified
              </Badge>
            )}
          </div>
        </DialogHeader>

        {/* Full-size certificate */}
        <div className="bg-muted/30 p-4 sm:p-6">
          <div
            id="certificate-print-root"
            className="mx-auto aspect-[1.414/1] w-full max-w-2xl overflow-hidden rounded-lg shadow-xl"
            style={{ background: bgGradient(template) }}
          >
            <CertificateArtwork cert={cert} />
          </div>
        </div>

        {/* Verification details */}
        <div className="grid grid-cols-1 gap-4 border-t px-5 py-4 sm:grid-cols-2">
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Certificate number</p>
            <p className="font-mono text-sm font-medium">{cert.certificateNumber}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Issued on</p>
            <p className="text-sm font-medium">{cert.issuedAt}</p>
          </div>
          {cert.certificateType === 'level' ? (
            <>
              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Level</p>
                <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">
                  {cert.levelName ?? cert.chapterName}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Chapters included</p>
                <p className="text-sm font-medium tabular-nums">
                  {cert.chapterNames?.length ?? 0} chapters
                </p>
              </div>
              {cert.chapterNames && cert.chapterNames.length > 0 && (
                <div className="space-y-1 sm:col-span-2">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Chapter list</p>
                  <div className="flex flex-wrap gap-1.5">
                    {cert.chapterNames.map((name, i) => (
                      <span
                        key={`${name}-${i}`}
                        className="inline-flex items-center gap-1 rounded-md border border-emerald-500/20 bg-emerald-500/5 px-2 py-0.5 text-xs text-emerald-700 dark:text-emerald-300"
                      >
                        <span className="font-mono text-[10px] text-emerald-500">{String(i + 1).padStart(2, '0')}</span>
                        {name}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Chapter</p>
                <p className="text-sm font-medium">{cert.chapterName}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Examination</p>
                <p className="text-sm font-medium">{cert.examTitle}</p>
              </div>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t bg-muted/30 px-5 py-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <QrCode className="h-4 w-4" />
            <span>Scan to verify at powermaths.com/verify</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => {
              const url = `${window.location.origin}/?verify=${cert.certificateNumber}`
              navigator.clipboard?.writeText(url).catch(() => {})
              toast.success('Verification link copied!')
            }}>
              <Share2 className="h-4 w-4" /> Copy link
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownload} disabled={downloading}>
              {downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              {downloading ? 'Preparing…' : 'Download'}
            </Button>
            <Button size="sm" onClick={() => printCertificate(cert)}>
              <Printer className="h-4 w-4" /> Print
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ─────────────────────── Print helper ───────────────────────
// Opens a new window with just the certificate artwork + print-optimised
// styles, then triggers the browser print dialog. This avoids printing
// the whole portal UI.
//
// v3.29.0 — the HTML is now generated from the editable certificate
// template via buildCertificateHtml() in src/lib/certificate-template.ts.

export function printCertificate(cert: Certificate) {
  if (typeof window === 'undefined') return
  const printWin = window.open('', '_blank', 'width=900,height=650')
  if (!printWin) {
    toast.error('Pop-up blocked', { description: 'Allow pop-ups to print the certificate.' })
    return
  }
  const template = resolveTemplate(useDataStore.getState().settings.certificateTemplate)
  printWin.document.write(buildCertificateHtml({ cert, template }))
  printWin.document.close()
  toast.success('Opening print dialog…', { description: cert.certificateNumber })
}

// ─────────────────────── Download-as-PDF helper (v3.34.0) ───────────────────────
// Generates a proper VECTOR PDF of the certificate using jsPDF's native
// drawing APIs (text, rectangles, circles, embedded logo image). The
// result is a genuine .pdf with selectable text and crisp graphics — NOT
// a rasterized JPEG wrapped in a PDF. The logo is embedded at high
// resolution and enlarged so the Power Maths brand mark is prominent.
//
// The actual drawing logic lives in `src/lib/certificate-pdf.ts` so it
// can be unit-tested and reused (e.g. by a future admin "batch download"
// feature). This thin wrapper adds the toast notifications.

import { downloadCertificatePdf as generateCertPdf } from '@/lib/certificate-pdf'

export async function downloadCertificatePdf(cert: Certificate): Promise<void> {
  if (typeof window === 'undefined') return
  try {
    await generateCertPdf(cert)
    toast.success('Certificate downloaded', {
      description: `${cert.certificateNumber} · PDF saved to your downloads`,
    })
  } catch (err) {
    console.error('[downloadCertificatePdf]', err)
    toast.error('Could not download certificate', {
      description: err instanceof Error ? err.message : 'Unexpected error.',
    })
  }
}
