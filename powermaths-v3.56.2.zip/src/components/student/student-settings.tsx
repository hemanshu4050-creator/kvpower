'use client'

import * as React from 'react'
import {
  Settings, User, Bell, Palette, Lock, Shield, Sun, Moon, Monitor,
  Save, Trash2, Smartphone, LogOut, AlertTriangle, Check, Eye, EyeOff,
} from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { useDataStore } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { useTheme } from '@/components/portal/theme-provider'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export function StudentSettings() {
  const pageTitle = useNavLabel('settings', 'Settings', 'student')
  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Manage your account, preferences and security"
        icon={<Settings className="h-5 w-5" />}
      />

      <Tabs defaultValue="account">
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-5">
          <TabsTrigger value="account"><User className="h-4 w-4" /> <span className="hidden sm:inline">Account</span></TabsTrigger>
          <TabsTrigger value="notifications"><Bell className="h-4 w-4" /> <span className="hidden sm:inline">Notifications</span></TabsTrigger>
          <TabsTrigger value="appearance"><Palette className="h-4 w-4" /> <span className="hidden sm:inline">Appearance</span></TabsTrigger>
          <TabsTrigger value="privacy"><Eye className="h-4 w-4" /> <span className="hidden sm:inline">Privacy</span></TabsTrigger>
          <TabsTrigger value="security"><Shield className="h-4 w-4" /> <span className="hidden sm:inline">Security</span></TabsTrigger>
        </TabsList>

        <TabsContent value="account" className="mt-4"><AccountSection /></TabsContent>
        <TabsContent value="notifications" className="mt-4"><NotificationsSection /></TabsContent>
        <TabsContent value="appearance" className="mt-4"><AppearanceSection /></TabsContent>
        <TabsContent value="privacy" className="mt-4"><PrivacySection /></TabsContent>
        <TabsContent value="security" className="mt-4"><SecuritySection /></TabsContent>
      </Tabs>
    </div>
  )
}

function AccountSection() {
  const user = useAppStore((s) => s.user)
  const students = useDataStore((s) => s.students)
  const updateStudent = useDataStore((s) => s.updateStudent)

  const student = React.useMemo(
    () => students.find((s) => s.id === user?.id) ?? null,
    [students, user]
  )

  const [name, setName] = React.useState(student?.name ?? '')
  const [email, setEmail] = React.useState(student?.email ?? '')
  const [phone, setPhone] = React.useState(student?.phone ?? '')
  const [saving, setSaving] = React.useState(false)
  const [showPwd, setShowPwd] = React.useState(false)

  React.useEffect(() => {
    if (student) {
      setName(student.name)
      setEmail(student.email)
      setPhone(student.phone)
    }
  }, [student])

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !student) return
    if (!name.trim() || !email.trim()) {
      toast.error('Name and email are required')
      return
    }
    setSaving(true)
    setTimeout(() => {
      updateStudent(user.id, { name: name.trim(), email: email.trim(), phone: phone.trim() })
      setSaving(false)
      toast.success('Account settings saved!')
    }, 500)
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><User className="h-4 w-4 text-primary" /> Personal Info</CardTitle>
          <CardDescription>Update your basic account details</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="s-name">Full name</Label>
              <Input id="s-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-email">Email address</Label>
              <Input id="s-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-phone">Phone number</Label>
              <Input id="s-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? 'Saving...' : 'Save Changes'} {!saving && <Save className="h-4 w-4" />}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Lock className="h-4 w-4 text-primary" /> Change Password</CardTitle>
          <CardDescription>Choose a strong, unique password</CardDescription>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              toast.success('Password updated!')
              ;(e.target as HTMLFormElement).reset()
            }}
            className="space-y-4"
          >
            <div className="space-y-1.5">
              <Label htmlFor="s-cpwd">Current password</Label>
              <div className="relative">
                <Input id="s-cpwd" type={showPwd ? 'text' : 'password'} placeholder="••••••••" required />
                <button
                  type="button"
                  onClick={() => setShowPwd((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-npwd">New password</Label>
              <Input id="s-npwd" type="password" placeholder="••••••••" required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-cpwd2">Confirm new password</Label>
              <Input id="s-cpwd2" type="password" placeholder="••••••••" required />
            </div>
            <p className="text-xs text-muted-foreground">Use at least 8 characters with a mix of letters, numbers and symbols.</p>
            <Button type="submit" variant="outline" className="w-full sm:w-auto">
              Update Password
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

function NotificationsSection() {
  const [settings, setSettings] = React.useState({
    examReminders: true,
    announcements: true,
    results: true,
    messages: true,
    weeklyDigest: false,
    streakAlerts: true,
  })

  const toggle = (key: keyof typeof settings) => {
    setSettings((p) => ({ ...p, [key]: !p[key] }))
    toast.success('Notification preference updated')
  }

  const items: { key: keyof typeof settings; title: string; desc: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: 'examReminders', title: 'Exam reminders', desc: 'Get notified before scheduled exams', icon: Bell },
    { key: 'announcements', title: 'Announcements', desc: 'News and updates from your instructor', icon: AlertTriangle },
    { key: 'results', title: 'Result alerts', desc: 'When your exam results are published', icon: Check },
    { key: 'messages', title: 'Messages', desc: 'New messages from Prof. Vyas', icon: Bell },
    { key: 'weeklyDigest', title: 'Weekly digest', desc: 'A summary of your week, every Sunday', icon: Check },
    { key: 'streakAlerts', title: 'Streak alerts', desc: 'Reminder to keep your streak alive', icon: AlertTriangle },
  ]

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base"><Bell className="h-4 w-4 text-primary" /> Notification Preferences</CardTitle>
        <CardDescription>Choose what you want to hear about</CardDescription>
      </CardHeader>
      <CardContent className="divide-y">
        {items.map((item) => (
          <div key={item.key} className="flex items-center justify-between gap-4 py-3.5 first:pt-0 last:pb-0">
            <div className="flex items-start gap-3 min-w-0">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <item.icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium">{item.title}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            </div>
            <Switch checked={settings[item.key]} onCheckedChange={() => toggle(item.key)} />
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function AppearanceSection() {
  const { theme, setTheme } = useTheme()
  const [fontSize, setFontSize] = React.useState('medium')
  const [reducedMotion, setReducedMotion] = React.useState(false)

  const themes: { value: 'light' | 'dark' | 'system'; label: string; icon: React.ComponentType<{ className?: string }>; desc: string }[] = [
    { value: 'light', label: 'Light', icon: Sun, desc: 'Bright and clean' },
    { value: 'dark', label: 'Dark', icon: Moon, desc: 'Easy on the eyes' },
    { value: 'system', label: 'System', icon: Monitor, desc: 'Match your OS' },
  ]

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Palette className="h-4 w-4 text-primary" /> Theme</CardTitle>
          <CardDescription>Pick your preferred appearance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {themes.map((t) => (
              <button
                key={t.value}
                onClick={() => {
                  setTheme(t.value)
                  toast.success(`Theme set to ${t.label}`)
                }}
                className={cn(
                  'flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-all',
                  theme === t.value
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/40',
                )}
              >
                <div className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-lg',
                  theme === t.value ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground',
                )}>
                  <t.icon className="h-5 w-5" />
                </div>
                <span className="text-sm font-medium">{t.label}</span>
                <span className="text-[10px] text-muted-foreground text-center">{t.desc}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="text-base">Display Preferences</CardTitle>
          <CardDescription>Adjust readability and motion</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-1.5">
            <Label>Font size</Label>
            <Select value={fontSize} onValueChange={(v) => { setFontSize(v); toast.success('Font size updated') }}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="medium">Medium (default)</SelectItem>
                <SelectItem value="large">Large</SelectItem>
                <SelectItem value="xl">Extra large</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">Reduce motion</p>
              <p className="text-xs text-muted-foreground">Minimize animations across the portal</p>
            </div>
            <Switch checked={reducedMotion} onCheckedChange={(v) => { setReducedMotion(v); toast.success('Motion preference saved') }} />
          </div>

          <div className="rounded-lg bg-primary/5 p-3 text-xs text-muted-foreground">
            <p className="font-medium text-foreground">Preview</p>
            <p className="mt-1">The quick brown fox jumps over the lazy dog. 1234567890</p>
          </div>

          <Button className="w-full" onClick={() => toast.success('Appearance saved!')}>
            <Save className="h-4 w-4" /> Save Preferences
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function PrivacySection() {
  const [settings, setSettings] = React.useState({
    profileVisible: true,
    showLeaderboard: true,
    showProgress: false,
    allowMessages: true,
  })

  const toggle = (key: keyof typeof settings) => {
    setSettings((p) => ({ ...p, [key]: !p[key] }))
    toast.success('Privacy preference updated')
  }

  const items: { key: keyof typeof settings; title: string; desc: string }[] = [
    { key: 'profileVisible', title: 'Public profile', desc: 'Let other students view your profile' },
    { key: 'showLeaderboard', title: 'Show in leaderboard', desc: 'Appear in batch rankings' },
    { key: 'showProgress', title: 'Share progress', desc: 'Let classmates see your chapter progress' },
    { key: 'allowMessages', title: 'Allow messages', desc: 'Receive messages from peers' },
  ]

  return (
    <Card className="card-elevated">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base"><Eye className="h-4 w-4 text-primary" /> Privacy Controls</CardTitle>
        <CardDescription>Control your visibility to others</CardDescription>
      </CardHeader>
      <CardContent className="divide-y">
        {items.map((item) => (
          <div key={item.key} className="flex items-center justify-between gap-4 py-3.5 first:pt-0 last:pb-0">
            <div className="min-w-0">
              <p className="text-sm font-medium">{item.title}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            <Switch checked={settings[item.key]} onCheckedChange={() => toggle(item.key)} />
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function SecuritySection() {
  const [twoFA, setTwoFA] = React.useState(false)
  const [deleteOpen, setDeleteOpen] = React.useState(false)
  const [confirmText, setConfirmText] = React.useState('')
  const [deleting, setDeleting] = React.useState(false)

  const sessions = [
    { id: 's1', device: 'Chrome on Windows', location: 'Mumbai, IN', current: true, last: 'Active now' },
    { id: 's2', device: 'Safari on iPhone', location: 'Mumbai, IN', current: false, last: '2 hours ago' },
    { id: 's3', device: 'Chrome on Android', location: 'Pune, IN', current: false, last: 'Yesterday' },
  ]

  const handleDelete = () => {
    if (confirmText !== 'DELETE') {
      toast.error('Please type DELETE to confirm')
      return
    }
    setDeleting(true)
    setTimeout(() => {
      setDeleting(false)
      setDeleteOpen(false)
      setConfirmText('')
      toast.error('Account deletion scheduled (demo only)')
    }, 1000)
  }

  return (
    <div className="space-y-4">
      {/* 2FA */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Shield className="h-4 w-4 text-primary" /> Two-Factor Authentication</CardTitle>
          <CardDescription>Add an extra layer of security</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
            <div className="flex items-start gap-3">
              <div className={cn(
                'flex h-9 w-9 items-center justify-center rounded-lg',
                twoFA ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted text-muted-foreground',
              )}>
                {twoFA ? <Check className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
              </div>
              <div>
                <p className="text-sm font-medium">
                  2FA is {twoFA ? 'enabled' : 'disabled'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {twoFA ? 'Your account is protected with an authenticator app.' : 'Protect your account with a second verification step.'}
                </p>
              </div>
            </div>
            <Switch
              checked={twoFA}
              onCheckedChange={(v) => {
                setTwoFA(v)
                toast.success(v ? '2FA enabled!' : '2FA disabled')
              }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Active sessions */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Smartphone className="h-4 w-4 text-primary" /> Active Sessions</CardTitle>
          <CardDescription>Devices currently signed in</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {sessions.map((s) => (
            <div key={s.id} className="flex items-center justify-between gap-3 rounded-lg border bg-card p-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                  <Smartphone className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm font-medium">
                    {s.device}
                    {s.current && <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">Current</Badge>}
                  </p>
                  <p className="text-xs text-muted-foreground">{s.location} · {s.last}</p>
                </div>
              </div>
              {!s.current && (
                <Button variant="ghost" size="sm" onClick={() => toast.success('Session revoked')}>
                  <LogOut className="h-4 w-4" /> Revoke
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Danger zone */}
      <Card className="border-rose-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base text-rose-600 dark:text-rose-400">
            <AlertTriangle className="h-4 w-4" /> Danger Zone
          </CardTitle>
          <CardDescription>Irreversible and destructive actions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3 rounded-lg border border-rose-500/30 bg-rose-500/5 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-medium text-rose-700 dark:text-rose-400">Delete account</p>
              <p className="text-xs text-muted-foreground">Permanently remove your account and all data. This cannot be undone.</p>
            </div>
            <Button variant="destructive" onClick={() => setDeleteOpen(true)} className="shrink-0">
              <Trash2 className="h-4 w-4" /> Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Delete confirmation */}
      <Dialog open={deleteOpen} onOpenChange={(o) => !o && setDeleteOpen(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-rose-600 dark:text-rose-400">
              <AlertTriangle className="h-5 w-5" /> Delete Account?
            </DialogTitle>
            <DialogDescription>
              This will permanently delete your account, all your results, certificates and notes. <strong>This action cannot be undone.</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm">Type <span className="font-mono font-bold text-rose-600">DELETE</span> to confirm:</p>
            <Input
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder="DELETE"
              className="font-mono"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? 'Deleting...' : 'Permanently Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
