'use client'

import * as React from 'react'
import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Bell, BellRing, Search, Eye, Clock, CheckCheck, CheckCircle2,
  BookOpen, BookCheck, Award, Megaphone, Wrench, MessageSquare,
  Info, FileText, CalendarClock, Filter, ChevronDown, ChevronLeft,
  ChevronRight, X, Inbox, type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader } from '@/components/shared/page-header'
import { EmptyState } from '@/components/shared/empty-state'
import { StatCard } from '@/components/shared/stat-card'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '@/components/ui/sheet'
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  useDataStore,
  type AppNotification,
  type NotificationCategory,
  type NotificationPriority,
  type Student,
} from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { avatarColorClasses, initials } from '../admin/lib/helpers'
import { useAppStore } from '@/lib/store'
import { cn } from '@/lib/utils'

// ────────────────────────────────────────────────────────────────────────────
//  Category metadata (mirrors the admin page palette)
// ────────────────────────────────────────────────────────────────────────────

interface CatMeta { icon: LucideIcon; label: string; bg: string; dot: string }

const CATEGORY_META: Record<NotificationCategory, CatMeta> = {
  system:           { icon: Info, label: 'System', bg: 'bg-zinc-500/15 text-zinc-600 dark:text-zinc-300', dot: 'bg-zinc-500' },
  chapter_assigned: { icon: BookOpen, label: 'Chapter Assigned', bg: 'bg-violet-500/15 text-violet-600 dark:text-violet-400', dot: 'bg-violet-500' },
  exam_available:   { icon: BookCheck, label: 'Exam Available', bg: 'bg-sky-500/15 text-sky-600 dark:text-sky-400', dot: 'bg-sky-500' },
  exam_result:      { icon: FileText, label: 'Exam Result', bg: 'bg-amber-500/15 text-amber-600 dark:text-amber-400', dot: 'bg-amber-500' },
  certificate:      { icon: Award, label: 'Certificate', bg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400', dot: 'bg-emerald-500' },
  announcement:     { icon: Megaphone, label: 'Announcement', bg: 'bg-teal-500/15 text-teal-600 dark:text-teal-400', dot: 'bg-teal-500' },
  reminder:         { icon: Clock, label: 'Reminder', bg: 'bg-orange-500/15 text-orange-600 dark:text-orange-400', dot: 'bg-orange-500' },
  maintenance:      { icon: Wrench, label: 'Maintenance', bg: 'bg-rose-500/15 text-rose-600 dark:text-rose-400', dot: 'bg-rose-500' },
  message:          { icon: MessageSquare, label: 'Personal Message', bg: 'bg-fuchsia-500/15 text-fuchsia-600 dark:text-fuchsia-400', dot: 'bg-fuchsia-500' },
  general:          { icon: Bell, label: 'General Notice', bg: 'bg-primary/15 text-primary', dot: 'bg-primary' },
}

const PRIORITY_META: Record<NotificationPriority, { label: string; badge: string }> = {
  low:    { label: 'Low', badge: 'border-zinc-500/30 bg-zinc-500/10 text-zinc-600 dark:text-zinc-300' },
  normal: { label: 'Normal', badge: 'border-sky-500/30 bg-sky-500/10 text-sky-600 dark:text-sky-400' },
  high:   { label: 'High', badge: 'border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400' },
  urgent: { label: 'Urgent', badge: 'border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400' },
}

// ────────────────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────────────────

function AnimatedNumber({ value, duration = 600 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(value * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, duration])
  return <span className="tabular-nums">{display}</span>
}

function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const m = Math.floor(diff / 60_000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  if (d < 30) return `${d}d ago`
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

function formatDateTime(iso?: string): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true,
  })
}

function renderBody(body: string): React.ReactNode {
  const lines = body.split('\n')
  return lines.map((line, i) => {
    const parts: React.ReactNode[] = []
    let remaining = line
    let key = 0
    while (remaining.length) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/)
      const italicMatch = remaining.match(/\*(.+?)\*/)
      if (boldMatch && boldMatch.index !== undefined && (italicMatch?.index === undefined || boldMatch.index <= italicMatch.index)) {
        if (boldMatch.index > 0) parts.push(<span key={key++}>{remaining.slice(0, boldMatch.index)}</span>)
        parts.push(<strong key={key++} className="font-semibold text-foreground">{boldMatch[1]}</strong>)
        remaining = remaining.slice(boldMatch.index + boldMatch[0].length)
      } else if (italicMatch && italicMatch.index !== undefined) {
        if (italicMatch.index > 0) parts.push(<span key={key++}>{remaining.slice(0, italicMatch.index)}</span>)
        parts.push(<em key={key++} className="italic">{italicMatch[1]}</em>)
        remaining = remaining.slice(italicMatch.index + italicMatch[0].length)
      } else {
        parts.push(<span key={key++}>{remaining}</span>)
        remaining = ''
      }
    }
    return <p key={i} className={i > 0 ? 'mt-2' : ''}>{parts.length ? parts : '\u00A0'}</p>
  })
}

// ────────────────────────────────────────────────────────────────────────────
//  Main component
// ────────────────────────────────────────────────────────────────────────────

export function StudentNotifications() {
  const pageTitle = useNavLabel('notifications', 'My Notifications', 'student')
  const { user } = useAppStore()
  const { notifications, students, markNotificationRead, markAllNotificationsRead } = useDataStore()

  const studentBatch = students.find((s) => s.id === user?.id)?.batch

  // Filter to only notifications addressed to this student
  const myNotifications = useMemo(() => {
    if (!user) return []
    return notifications
      .filter((n) => n.status === 'sent')
      .filter((n) => {
        if (n.audience === 'all') return true
        if (n.audience === 'batch') return n.recipientBatch === studentBatch
        return n.recipientIds.includes(user.id)
      })
      .sort((a, b) => new Date(b.sentAt ?? b.createdAt).getTime() - new Date(a.sentAt ?? a.createdAt).getTime())
  }, [notifications, user, studentBatch])

  const readSet = useMemo(
    () => new Set(myNotifications.filter((n) => n.readBy.some((r) => r.studentId === user?.id)).map((n) => n.id)),
    [myNotifications, user]
  )

  const stats = useMemo(() => {
    const total = myNotifications.length
    const unread = myNotifications.filter((n) => !readSet.has(n.id)).length
    const read = total - unread
    // "Important" = high or urgent priority
    const important = myNotifications.filter((n) => n.priority === 'high' || n.priority === 'urgent').length
    // "Personal" = addressed to this student individually (not all/batch)
    const personal = myNotifications.filter((n) => n.audience === 'individual' || n.audience === 'multiple').length
    return { total, unread, read, important, personal }
  }, [myNotifications, readSet])

  const [tab, setTab] = useState<'all' | 'unread' | 'read' | 'important' | 'personal'>('all')
  const [search, setSearch] = useState('')
  const [filterCategory, setFilterCategory] = useState<NotificationCategory | 'all'>('all')
  const [showFilters, setShowFilters] = useState(false)
  const [page, setPage] = useState(0)
  const [detailTarget, setDetailTarget] = useState<AppNotification | null>(null)
  const PAGE_SIZE = 8

  const filtered = useMemo(() => {
    let list = myNotifications
    if (tab === 'unread') list = list.filter((n) => !readSet.has(n.id))
    else if (tab === 'read') list = list.filter((n) => readSet.has(n.id))
    else if (tab === 'important') list = list.filter((n) => n.priority === 'high' || n.priority === 'urgent')
    else if (tab === 'personal') list = list.filter((n) => n.audience === 'individual' || n.audience === 'multiple')

    if (filterCategory !== 'all') list = list.filter((n) => n.category === filterCategory)

    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter((n) => n.title.toLowerCase().includes(q) || n.description.toLowerCase().includes(q) || n.body.toLowerCase().includes(q))
    }
    return list
  }, [myNotifications, tab, readSet, filterCategory, search])

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)

  // Reset to page 0 when filters change — render-time pattern (no effect).
  const filterKey = `${tab}·${search}·${filterCategory}`
  const [prevFilterKey, setPrevFilterKey] = useState(filterKey)
  if (prevFilterKey !== filterKey) {
    setPrevFilterKey(filterKey)
    setPage(0)
  }

  const handleOpen = (n: AppNotification) => {
    if (user && !readSet.has(n.id)) {
      markNotificationRead(n.id, user.id)
    }
    setDetailTarget(n)
  }

  const handleMarkAllRead = () => {
    if (!user) return
    markAllNotificationsRead(user.id)
    toast.success('All notifications marked as read')
  }

  const activeFilters = filterCategory !== 'all'

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Announcements, exam alerts, reminders and personal messages from your teacher."
        icon={<BellRing className="h-5 w-5" />}
        actions={
          stats.unread > 0 ? (
            <Button variant="outline" size="sm" onClick={handleMarkAllRead} className="gap-2">
              <CheckCheck className="h-4 w-4" /> Mark all as read
            </Button>
          ) : undefined
        }
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard title="All" value={<AnimatedNumber value={stats.total} />} icon={Inbox} accent="emerald" subtitle="notifications" delay={0} />
        <StatCard title="Unread" value={<AnimatedNumber value={stats.unread} />} icon={Bell} accent="rose" subtitle="needs attention" delay={0.05} />
        <StatCard title="Read" value={<AnimatedNumber value={stats.read} />} icon={CheckCircle2} accent="teal" subtitle="viewed" delay={0.1} />
        <StatCard title="Important" value={<AnimatedNumber value={stats.important} />} icon={Megaphone} accent="amber" subtitle="high priority" delay={0.15} />
        <StatCard title="Personal" value={<AnimatedNumber value={stats.personal} />} icon={MessageSquare} accent="violet" subtitle="directed to you" delay={0.2} />
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="flex w-full flex-wrap sm:w-auto">
          <TabsTrigger value="all" className="gap-1.5">All <Badge variant="secondary" className="text-[10px]">{stats.total}</Badge></TabsTrigger>
          <TabsTrigger value="unread" className="gap-1.5">Unread <Badge variant="destructive" className="text-[10px]">{stats.unread}</Badge></TabsTrigger>
          <TabsTrigger value="read" className="gap-1.5">Read <Badge variant="secondary" className="text-[10px]">{stats.read}</Badge></TabsTrigger>
          <TabsTrigger value="important" className="gap-1.5">Important <Badge variant="secondary" className="text-[10px]">{stats.important}</Badge></TabsTrigger>
          <TabsTrigger value="personal" className="gap-1.5">Personal <Badge variant="secondary" className="text-[10px]">{stats.personal}</Badge></TabsTrigger>
        </TabsList>

        {/* Search + filters */}
        <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search your notifications..."
              className="pl-9"
            />
          </div>
          <Button
            variant={showFilters || activeFilters ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setShowFilters((v) => !v)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" /> Filters
            {activeFilters && <span className="flex h-2 w-2 rounded-full bg-primary" />}
          </Button>
          {activeFilters && (
            <Button variant="ghost" size="sm" onClick={() => setFilterCategory('all')} className="gap-1.5 text-muted-foreground">
              <X className="h-3.5 w-3.5" /> Clear
            </Button>
          )}
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <Card className="mt-2 grid grid-cols-1 gap-3 p-4 sm:grid-cols-2">
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Category</Label>
                  <Select value={filterCategory} onValueChange={(v) => setFilterCategory(v as NotificationCategory | 'all')}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {Object.entries(CATEGORY_META).map(([k, m]) => (
                        <SelectItem key={k} value={k}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <TabsContent value={tab} className="mt-4">
          {paged.length === 0 ? (
            <EmptyState
              icon={Bell}
              title={tab === 'unread' ? 'No unread notifications' : 'No notifications found'}
              description={search || activeFilters ? 'Try adjusting your search or filters.' : tab === 'unread' ? 'You are all caught up!' : 'New notifications will appear here.'}
            />
          ) : (
            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {paged.map((n, idx) => {
                  const isUnread = !readSet.has(n.id)
                  return (
                    <motion.div
                      key={n.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.25, delay: idx * 0.03 }}
                    >
                      <StudentNotificationCard
                        notification={n}
                        isUnread={isUnread}
                        onOpen={() => handleOpen(n)}
                      />
                    </motion.div>
                  )
                })}
              </AnimatePresence>

              {pageCount > 1 && (
                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-muted-foreground">
                    Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
                  </p>
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" className="h-8 w-8" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="px-2 text-xs font-medium">{page + 1} / {pageCount}</span>
                    <Button variant="outline" size="icon" className="h-8 w-8" disabled={page >= pageCount - 1} onClick={() => setPage((p) => p + 1)}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Detail sheet */}
      <StudentNotificationDetail
        notification={detailTarget}
        onOpenChange={(open) => !open && setDetailTarget(null)}
        studentName={user?.name}
      />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Notification Card (student view)
// ────────────────────────────────────────────────────────────────────────────

function StudentNotificationCard({
  notification: n, isUnread, onOpen,
}: {
  notification: AppNotification
  isUnread: boolean
  onOpen: () => void
}) {
  const catMeta = CATEGORY_META[n.category]
  const prioMeta = PRIORITY_META[n.priority]
  const CatIcon = catMeta.icon

  return (
    <Card
      className={cn(
        'group relative cursor-pointer overflow-hidden rounded-xl p-0 transition-all hover:shadow-md',
        isUnread && 'ring-1 ring-primary/30'
      )}
      onClick={onOpen}
    >
      {/* Left accent stripe */}
      <div className={cn('absolute left-0 top-0 h-full w-1', catMeta.dot)} />
      {isUnread && (
        <div className="absolute right-3 top-3 flex h-2 w-2 rounded-full bg-primary">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
        </div>
      )}
      <div className="flex gap-4 p-4 pl-5">
        {/* Icon */}
        <div className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl', catMeta.bg)}>
          <CatIcon className="h-5 w-5" />
        </div>

        {/* Body */}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className={cn('text-sm leading-tight', isUnread ? 'font-semibold' : 'font-medium text-muted-foreground')}>{n.title}</h3>
            <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', prioMeta.badge)}>
              {prioMeta.label}
            </span>
          </div>
          <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{n.description}</p>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <span className={cn('h-2 w-2 rounded-full', catMeta.dot)} />
              {catMeta.label}
            </span>
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {relativeTime(n.sentAt ?? n.createdAt)}
            </span>
            <span className="inline-flex items-center gap-1">
              from {n.sender}
            </span>
          </div>
        </div>
      </div>
    </Card>
  )
}

// ────────────────────────────────────────────────────────────────────────────
//  Detail Sheet (student view — read-only)
// ────────────────────────────────────────────────────────────────────────────

function StudentNotificationDetail({
  notification: n, onOpenChange, studentName,
}: {
  notification: AppNotification | null
  onOpenChange: (open: boolean) => void
  studentName?: string
}) {
  if (!n) return null
  const catMeta = CATEGORY_META[n.category]
  const prioMeta = PRIORITY_META[n.priority]
  const CatIcon = catMeta.icon

  return (
    <Sheet open={!!n} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col overflow-hidden sm:max-w-lg">
        <SheetHeader className="border-b border-border pb-4">
          <div className="flex items-start gap-3">
            <div className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl', catMeta.bg)}>
              <CatIcon className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <SheetTitle className="text-base leading-tight">{n.title}</SheetTitle>
              <SheetDescription className="mt-1 line-clamp-1">{n.description}</SheetDescription>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', prioMeta.badge)}>{prioMeta.label}</span>
                <span className={cn('inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium', catMeta.bg)}>{catMeta.label}</span>
              </div>
            </div>
          </div>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-4 p-4">
            {/* Meta */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">From</p>
                <p className="mt-0.5 font-medium">{n.sender}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Received</p>
                <p className="mt-0.5 font-medium">{formatDateTime(n.sentAt)}</p>
              </div>
              {n.expiresAt && (
                <div className="rounded-lg border border-border p-3">
                  <p className="text-muted-foreground">Expires</p>
                  <p className="mt-0.5 font-medium">{formatDateTime(n.expiresAt)}</p>
                </div>
              )}
              <div className="rounded-lg border border-border p-3">
                <p className="text-muted-foreground">Category</p>
                <p className="mt-0.5 font-medium">{catMeta.label}</p>
              </div>
            </div>

            {/* Body */}
            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Message</h4>
              <Card className="bg-muted/30 p-4">
                <div className="text-sm leading-relaxed text-foreground">
                  {renderBody(n.body)}
                </div>
              </Card>
            </div>

            {studentName && (
              <p className="text-center text-[11px] text-muted-foreground">
                This notification was sent to <strong>{studentName}</strong>.
              </p>
            )}
          </div>
        </ScrollArea>

        <div className="flex items-center justify-end gap-2 border-t border-border p-3">
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>Close</Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
