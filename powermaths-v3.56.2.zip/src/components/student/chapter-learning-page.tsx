'use client'

/**
 * ChapterLearningPage — the full-page chapter learning experience.
 *
 * Replaces the old ChapterDetailDialog popup. Renders inside the student
 * portal content area (sidebar + header stay visible). The only popup is
 * the SecurePdfViewer (enhanced with fullscreen + zoom + reading progress).
 *
 * Layout:
 *  • Back button + breadcrumb
 *  • Premium page header (chapter name, number, description, progress,
 *    status, assigned date, estimated study time)
 *  • KPI stat cards (materials, practice, tests, progress, time, completion)
 *  • Tabs: Materials / Practice / Tests
 *
 * The Materials + Practice tabs open the SecurePdfViewer with full reading
 * progress + watermark + zoom + fullscreen support. The Test tab launches
 * the ExamRunner (unchanged).
 */

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft, BookOpen, FileText, PenTool, BookCheck, Lock, CheckCircle2,
  Play, Eye, Clock, GraduationCap, ArrowRight, Sparkles, Timer,
  TrendingUp, Target, Layers, Award, ChevronRight, FileQuestion,
  CheckCircle, Circle, CircleDot, Sigma,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { StatCard } from '@/components/shared/stat-card'
import { useDataStore, type Chapter, type Exam, visibleContentTabIds, resolveContentTabs, resolveTabLabel } from '@/lib/data-store'
import { useAppStore } from '@/lib/store'
import {
  useLearningProgress,
  computeChapterCompletion,
  formatDuration,
  type MaterialProgress,
  type PracticeProgress,
} from '@/lib/learning-progress'
import {
  ChapterIcon, useAssignedExams, useChapterStatuses,
} from './lib/student-helpers'
import { ExamRunner } from './lib/exam-runner'
import { SecurePdfViewer } from './lib/secure-pdf-viewer'
import { StudentFormulaNotebook } from './student-formula-notebook'
import { StudentTheoryTextbook } from './student-theory-textbook'
import { usePdfPages, PdfLoadingPlaceholder } from '@/hooks/use-pdf-pages'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface ChapterLearningPageProps {
  chapter: Chapter
  onBack: () => void
}

/** Display metadata for each content tab (icon + label). The order of the
 *  rendered tab strip is driven by `chapter.contentTabs`, NOT by this map. */
const TAB_META: Record<string, { label: string; icon: typeof BookOpen }> = {
  theory: { label: 'Theory', icon: BookOpen },
  materials: { label: 'Materials', icon: FileText },
  formula: { label: 'Formula', icon: Sigma },
  practice: { label: 'Practice', icon: PenTool },
  test: { label: 'Test', icon: BookCheck },
}

export function ChapterLearningPage({ chapter, onBack }: ChapterLearningPageProps) {
  const user = useAppStore((s) => s.user)
  const exams = useAssignedExams()
  const statuses = useChapterStatuses()
  const info = statuses.find((s) => s.chapter.id === chapter.id)
  const [activeExam, setActiveExam] = React.useState<Exam | null>(null)
  const [tab, setTab] = React.useState('materials')

  // v3.13.0 — Respect the admin's per-chapter tab visibility + order. A
  // hidden tab is never rendered to the student and is excluded from the
  // completion calculation. If the student's last-visited tab is now
  // hidden (admin toggled it off since their last visit), snap to the
  // first visible tab so the page never shows an empty pane.
  const orderedTabs = React.useMemo(() => resolveContentTabs(chapter), [chapter])
  const visibleTabIds = React.useMemo(() => orderedTabs.filter((t) => t.visible).map((t) => t.id), [orderedTabs])
  React.useEffect(() => {
    if (visibleTabIds.length === 0) return
    if (!visibleTabIds.includes(tab as typeof visibleTabIds[number])) {
      setTab(visibleTabIds[0])
    }
  }, [visibleTabIds, tab])

  // Subscribe to learning progress so the page re-renders live as the
  // student reads / practices.
  const progressChapters = useLearningProgress((s) => s.chapters)
  const progressKey = `${user?.id}:${chapter.id}`
  const progress = progressChapters[progressKey] ?? {
    chapterId: chapter.id,
    materials: {},
    practice: {},
    totalTimeSpentSeconds: 0,
  }

  // Mark chapter as touched on first mount.
  const touchChapter = useLearningProgress((s) => s.touchChapter)
  React.useEffect(() => {
    if (user) touchChapter(user.id, chapter.id)
  }, [user, chapter.id, touchChapter])

  const chapterExams = exams.filter((e) => e.chapterId === chapter.id && e.status === 'published')
  const hasPassedTest = info?.status === 'completed'

  const completionPercent = computeChapterCompletion(progress, {
    materialIds: chapter.studyMaterials.map((m) => m.id),
    practiceIds: chapter.practiceSheets.map((p) => p.id),
    formulaIds: (chapter.formulas ?? []).map((f) => f.id),
    theoryIds: (chapter.theories ?? []).map((t) => t.id),
    testPassed: hasPassedTest,
    activeTabs: new Set(visibleContentTabIds(chapter)),
  })

  // ── PDF viewer state ──
  const [viewerMaterial, setViewerMaterial] = React.useState<{
    title: string
    documentId?: string
    // v3.20.0: `fileSource` is EITHER a base64 data URL OR a /public file
    // path (e.g. '/practice/Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf').
    // The usePdfPages hook resolves both.
    fileData?: string
    fallbackPages: { content: React.ReactNode }[]
    materialId?: string
    isPractice?: boolean
    practiceId?: string
    totalQuestions?: number
  } | null>(null)

  const { pages: pdfPages, loading: pdfLoading, error: pdfError } =
    usePdfPages(viewerMaterial?.fileData)

  React.useEffect(() => {
    if (pdfError && viewerMaterial) {
      toast.error('Could not render this PDF', { description: 'Showing a preview instead.' })
    }
  }, [pdfError, viewerMaterial])

  const viewerPages = React.useMemo<{ content: React.ReactNode }[]>(() => {
    if (!viewerMaterial) return []
    if (!viewerMaterial.fileData) return viewerMaterial.fallbackPages
    if (pdfError) return viewerMaterial.fallbackPages
    if (pdfLoading || pdfPages.length === 0) {
      return [{ content: <PdfLoadingPlaceholder /> }]
    }
    return pdfPages
  }, [viewerMaterial, pdfPages, pdfLoading, pdfError])

  if (activeExam) {
    return <ExamRunner exam={activeExam} onExit={() => setActiveExam(null)} />
  }

  // Build the structured fallback pages (always available).
  const buildFallbackPages = (title: string, baseChapter: Chapter) =>
    Array.from({ length: 4 }).map((_, i) => ({
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h2 className="font-serif text-xl font-bold">{baseChapter.name}</h2>
              <p className="text-xs text-muted-foreground">{title} · Page {i + 1} of 4</p>
            </div>
            <div className="text-right text-[10px] uppercase tracking-wider text-muted-foreground">
              Power Maths<br />by Prof. Kalpesh Vyas
            </div>
          </div>
          {Array.from({ length: 5 }).map((_, q) => (
            <div key={q} className="space-y-1.5">
              <p className="text-sm font-medium">
                {i + 1}.{q + 1} Illustrative problem {q + 1}
              </p>
              <p className="text-xs text-muted-foreground">
                Solve the following and verify your answer with the worked solution.
              </p>
              <div className="h-3 w-full rounded bg-muted/70" />
              <div className="h-3 w-4/5 rounded bg-muted/70" />
              <div className="h-3 w-3/5 rounded bg-muted/70" />
            </div>
          ))}
          <p className="border-t pt-2 text-center text-[10px] text-muted-foreground">
            © Power Maths · Confidential · for the personal use of {user?.name} only
          </p>
        </div>
      ),
    }))

  const openViewer = (
    title: string,
    baseChapter: Chapter,
    opts: {
      fileData?: string
      filePath?: string
      documentId?: string
      materialId?: string
      isPractice?: boolean
      practiceId?: string
      totalQuestions?: number
    } = {}
  ) => {
    // v3.20.0: prefer an explicit /public filePath, fall back to base64 fileData.
    const fileSource = opts.filePath ?? opts.fileData
    setViewerMaterial({
      title,
      documentId: opts.documentId,
      fileData: fileSource,
      materialId: opts.materialId ?? opts.documentId,
      isPractice: opts.isPractice,
      practiceId: opts.practiceId,
      totalQuestions: opts.totalQuestions,
      fallbackPages: buildFallbackPages(title, baseChapter),
    })
  }

  // ── Derived stats for KPI cards ──
  const totalMaterials = chapter.studyMaterials.length
  const totalPractice = chapter.practiceSheets.length
  const totalTests = chapterExams.length
  const materialsViewed = chapter.studyMaterials.filter((m) => progress.materials[m.id]?.viewed).length
  const practiceCompleted = chapter.practiceSheets.filter((p) => progress.practice[p.id]?.status === 'completed').length
  const timeSpent = progress.totalTimeSpentSeconds

  // Estimated study time: materials (5 min each) + practice (15 min each) + tests (30 min each)
  const estimatedMinutes = totalMaterials * 5 + totalPractice * 15 + totalTests * 30

  return (
    <div className="space-y-6">
      {/* Breadcrumb + Back */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Button
          variant="ghost"
          size="sm"
          className="gap-1.5 px-2 text-muted-foreground hover:text-foreground"
          onClick={onBack}
        >
          <ArrowLeft className="h-4 w-4" /> Back to Chapters
        </Button>
        <ChevronRight className="h-3.5 w-3.5" />
        <span>My Chapters</span>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="font-medium text-foreground">{chapter.name}</span>
      </div>

      {/* Premium page header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="card-elevated relative overflow-hidden">
          {/* Decorative gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent" />
          <div className="absolute right-0 top-0 h-32 w-32 rounded-full bg-primary/10 blur-3xl" />

          <CardContent className="relative p-6 sm:p-8">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
              {/* Left: title block */}
              <div className="flex items-start gap-4 min-w-0">
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary ring-1 ring-primary/20">
                  <ChapterIcon name={chapter.icon} className="h-8 w-8" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="gap-1 border-primary/30 bg-primary/5 text-primary">
                      <BookOpen className="h-3 w-3" /> Chapter {chapter.order}
                    </Badge>
                    <ChapterStatusBadge status={info?.status ?? 'not_started'} />
                    {hasPassedTest && (
                      <Badge className="gap-1 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
                        <Award className="h-3 w-3" /> Passed
                      </Badge>
                    )}
                  </div>
                  <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
                    {chapter.name}
                  </h1>
                  <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">
                    {chapter.description}
                  </p>
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <CalendarIcon /> Assigned {chapter.createdAt}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Timer className="h-3.5 w-3.5" /> Est. {estimatedMinutes} min study
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5" /> {formatDuration(timeSpent)} spent
                    </span>
                  </div>
                </div>
              </div>

              {/* Right: progress ring */}
              <div className="flex shrink-0 items-center gap-4">
                <ProgressRing percent={completionPercent} />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* KPI stat cards — v3.36.0: titles respect the admin's tab renames. */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <StatCard
          title={resolveTabLabel(orderedTabs.find((t) => t.id === 'theory') ?? { id: 'theory', visible: true })}
          value={`${(chapter.theories ?? []).length}`}
          icon={BookOpen}
          accent="emerald"
          subtitle="sections"
          delay={0}
        />
        <StatCard
          title={resolveTabLabel(orderedTabs.find((t) => t.id === 'materials') ?? { id: 'materials', visible: true })}
          value={`${materialsViewed}/${totalMaterials}`}
          icon={FileText}
          accent="rose"
          subtitle={`${Math.round((materialsViewed / Math.max(1, totalMaterials)) * 100)}% viewed`}
          delay={0.05}
        />
        <StatCard
          title={resolveTabLabel(orderedTabs.find((t) => t.id === 'formula') ?? { id: 'formula', visible: true })}
          value={`${(chapter.formulas ?? []).length}`}
          icon={Sigma}
          accent="violet"
          subtitle="to revise"
          delay={0.1}
        />
        <StatCard
          title={resolveTabLabel(orderedTabs.find((t) => t.id === 'practice') ?? { id: 'practice', visible: true })}
          value={`${practiceCompleted}/${totalPractice}`}
          icon={PenTool}
          accent="amber"
          subtitle={`${Math.round((practiceCompleted / Math.max(1, totalPractice)) * 100)}% done`}
          delay={0.15}
        />
        <StatCard
          title="Study Progress"
          value={`${completionPercent}%`}
          icon={TrendingUp}
          accent="teal"
          subtitle="overall"
          delay={0.2}
        />
        <StatCard
          title="Completion"
          value={completionPercent >= 100 ? 'Done' : `${completionPercent}%`}
          icon={Award}
          accent={completionPercent >= 100 ? 'emerald' : 'amber'}
          subtitle={completionPercent >= 100 ? 'chapter complete' : 'in progress'}
          delay={0.25}
        />
      </div>

      {/* Tabs — v3.13.0: only admin-visible tabs are rendered, in the admin's
          chosen order. The grid column count adapts to the visible count so
          the tab strip always spans full width cleanly. */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList
          className="grid w-full sm:max-w-2xl"
          style={{ gridTemplateColumns: `repeat(${visibleTabIds.length || 1}, minmax(0, 1fr))` }}
        >
          {visibleTabIds.map((tabId) => {
            const cfg = TAB_META[tabId]
            if (!cfg) return null
            // v3.36.0 — resolve the tab's display label (custom rename or
            // canonical default) so students see the admin's chosen name.
            const tabObj = orderedTabs.find((t) => t.id === tabId)
            const label = tabObj ? resolveTabLabel(tabObj) : cfg.label
            const count =
              tabId === 'materials' ? totalMaterials
              : tabId === 'formula' ? (chapter.formulas ?? []).length
              : tabId === 'theory' ? (chapter.theories ?? []).length
              : tabId === 'practice' ? totalPractice
              : tabId === 'test' ? totalTests
              : 0
            return (
              <TabsTrigger key={tabId} value={tabId}>
                <cfg.icon className="h-4 w-4" /> {label}
                <span className="ml-1.5 text-xs text-muted-foreground">({count})</span>
              </TabsTrigger>
            )
          })}
        </TabsList>

        {/* ── Theory ── */}
        <TabsContent value="theory" className="mt-4">
          <StudentTheoryTextbook
            chapterId={chapter.id}
            chapterName={chapter.name}
            theories={chapter.theories ?? []}
          />
        </TabsContent>

        {/* ── Materials ── */}
        <TabsContent value="materials" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <h3 className="font-semibold">Study Materials</h3>
                  <p className="text-sm text-muted-foreground">
                    Read each worksheet to build your foundation. Progress is saved automatically.
                  </p>
                </div>
                <Badge variant="secondary" className="gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                  {materialsViewed} viewed
                </Badge>
              </div>

              {chapter.studyMaterials.length === 0 ? (
                <EmptyRow icon={FileText} text="No study materials uploaded yet." />
              ) : (
                <div className="space-y-2.5">
                  {chapter.studyMaterials.map((m) => (
                    <MaterialRow
                      key={m.id}
                      title={m.title}
                      meta={
                        m.fileData || m.filePath
                          ? `PDF · uploaded ${m.uploadedAt}`
                          : `Preview · uploaded ${m.uploadedAt}`
                      }
                      progress={progress.materials[m.id]}
                      onView={() => openViewer(m.title, chapter, {
                        fileData: m.fileData,
                        filePath: m.filePath,
                        documentId: m.id,
                        materialId: m.id,
                      })}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Formula ── */}
        <TabsContent value="formula" className="mt-4">
          <StudentFormulaNotebook
            chapterId={chapter.id}
            formulas={chapter.formulas ?? []}
          />
        </TabsContent>

        {/* ── Practice ── */}
        <TabsContent value="practice" className="mt-4">
          <Card className="card-elevated">
            <CardContent className="p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <h3 className="font-semibold">Practice Worksheets</h3>
                  <p className="text-sm text-muted-foreground">
                    Solve practice questions to master this chapter. Your progress is tracked automatically.
                  </p>
                </div>
                <Badge variant="secondary" className="gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                  {practiceCompleted} completed
                </Badge>
              </div>

              {chapter.practiceSheets.length === 0 ? (
                <EmptyRow icon={PenTool} text="No practice sheets available for this chapter yet." />
              ) : (
                <div className="space-y-2.5">
                  {chapter.practiceSheets.map((p) => (
                    <PracticeRow
                      key={p.id}
                      sheet={p}
                      chapterName={chapter.name}
                      progress={progress.practice[p.id]}
                      onStart={() => {
                        // Start the practice — opens the PDF viewer with
                        // practice tracking enabled. This is the bug fix:
                        // previously the button just showed a toast.
                        const totalQuestions = 8 + (p.order - 1) * 3
                        if (user) {
                          useLearningProgress.getState().startPractice(
                            user.id, chapter.id, p.id, totalQuestions
                          )
                        }
                        openViewer(p.title, chapter, {
                          fileData: p.fileData,
                          filePath: p.filePath,
                          documentId: p.id,
                          materialId: p.id,
                          isPractice: true,
                          practiceId: p.id,
                          totalQuestions,
                        })
                        toast.success(`Practice started: ${p.title}`, {
                          description: `${totalQuestions} questions · progress is being tracked.`,
                        })
                      }}
                      onSolution={() =>
                        openViewer(`${p.title} — Solutions`, chapter, {
                          fileData: p.solutionFileData,
                          filePath: p.solutionFilePath,
                          documentId: `${p.id}-sol`,
                          materialId: `${p.id}-sol`,
                        })
                      }
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Test ── */}
        <TabsContent value="test" className="mt-4">
          <div className="space-y-3">
            <Card className="card-elevated overflow-hidden border-primary/20">
              <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
                <CardContent className="p-5 sm:p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary ring-1 ring-primary/20">
                      <BookCheck className="h-7 w-7" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{chapter.name} — Chapter Test</h3>
                      <p className="mt-0.5 text-sm text-muted-foreground">
                        Test your mastery of this chapter. {chapterExams.length} published test{chapterExams.length !== 1 ? 's' : ''} available.
                      </p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Badge variant="secondary" className="gap-1">
                          <Clock className="h-3 w-3" /> {chapterExams.reduce((a, e) => a + e.duration, 0)} min total
                        </Badge>
                        <Badge variant="secondary" className="gap-1">
                          <GraduationCap className="h-3 w-3" /> {chapterExams.reduce((a, e) => a + e.marks, 0)} marks
                        </Badge>
                        <Badge variant="secondary" className="gap-1">
                          <CheckCircle2 className="h-3 w-3" /> pass {chapterExams[0]?.passingPercentage ?? 50}%
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </div>
            </Card>

            {chapterExams.length === 0 ? (
              <Card>
                <CardContent>
                  <EmptyRow icon={BookCheck} text="No published tests for this chapter yet. Check back soon." />
                </CardContent>
              </Card>
            ) : (
              chapterExams.map((exam) => (
                <Card key={exam.id} className="card-elevated">
                  <CardContent className="p-4 sm:p-5">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="min-w-0">
                        <p className="font-semibold leading-snug">{exam.title}</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" /> {exam.duration} min</Badge>
                          <Badge variant="secondary" className="gap-1"><GraduationCap className="h-3 w-3" /> {exam.marks} marks</Badge>
                          <Badge variant="secondary" className="gap-1"><CheckCircle2 className="h-3 w-3" /> {exam.passingPercentage}% pass</Badge>
                          <Badge variant="secondary" className="gap-1"><FileText className="h-3 w-3" /> {exam.questionIds.length} Qs</Badge>
                          {exam.negativeMarking > 0 && (
                            <Badge variant="secondary" className="gap-1 text-rose-600 dark:text-rose-400">−{exam.negativeMarking} wrong</Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        className="shrink-0"
                        onClick={() => setActiveExam(exam)}
                      >
                        Start Exam <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* PDF Viewer (the only popup) */}
      <SecurePdfViewer
        open={!!viewerMaterial}
        onOpenChange={(o) => !o && setViewerMaterial(null)}
        title={viewerMaterial?.title ?? ''}
        pages={viewerPages}
        studentName={user?.name}
        studentEmail={user?.email}
        studentId={user?.id}
        chapterId={chapter.id}
        materialId={viewerMaterial?.materialId}
        documentId={viewerMaterial?.documentId ?? chapter.id}
        trackAsPractice={viewerMaterial?.isPractice}
        totalPracticeQuestions={viewerMaterial?.totalQuestions}
        onProgress={(info) => {
          // Mirror the reading progress into the learning-progress store
          // so the chapter list + KPI cards update. The viewer calls this
          // on page change + every 15s (throttled), so we pass the total
          // reading time as the absolute value. The store helper accepts a
          // delta, so we compute it from the previous value.
          if (!user || !viewerMaterial) return
          if (viewerMaterial.isPractice && viewerMaterial.practiceId) {
            const k = `${user.id}:${chapter.id}`
            const prev = useLearningProgress.getState().chapters[k]
            const prevTime = prev?.practice[viewerMaterial.practiceId]?.timeSpentSeconds ?? 0
            const delta = Math.max(0, info.timeSpentSeconds - prevTime)
            if (delta > 0) {
              useLearningProgress.getState().updatePracticeProgress(
                user.id, chapter.id, viewerMaterial.practiceId,
                { timeSpentDeltaSeconds: delta }
              )
            }
          } else if (viewerMaterial.materialId) {
            const k = `${user.id}:${chapter.id}`
            const prev = useLearningProgress.getState().chapters[k]
            const prevTime = prev?.materials[viewerMaterial.materialId]?.timeSpentSeconds ?? 0
            const delta = Math.max(0, info.timeSpentSeconds - prevTime)
            useLearningProgress.getState().updateMaterialReadProgress(
              user.id, chapter.id, viewerMaterial.materialId,
              { page: info.page, totalPages: info.totalPages, timeSpentDeltaSeconds: delta }
            )
          }
        }}
      />
    </div>
  )
}

// ─────────────────────── Sub-components ───────────────────────

function ChapterStatusBadge({ status }: { status: 'completed' | 'in_progress' | 'not_started' | 'locked' }) {
  if (status === 'completed')
    return <Badge className="gap-1 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15"><CheckCircle2 className="h-3 w-3" /> Completed</Badge>
  if (status === 'in_progress')
    return <Badge className="gap-1 bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15"><Clock className="h-3 w-3" /> In Progress</Badge>
  if (status === 'locked')
    return <Badge variant="secondary" className="gap-1"><Lock className="h-3 w-3" /> Locked</Badge>
  return <Badge variant="outline" className="gap-1">Not Started</Badge>
}

function ProgressRing({ percent }: { percent: number }) {
  const radius = 36
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percent / 100) * circumference
  return (
    <div className="relative flex h-24 w-24 items-center justify-center">
      <svg className="h-24 w-24 -rotate-90" viewBox="0 0 96 96">
        <circle cx="48" cy="48" r={radius} className="fill-none stroke-muted" strokeWidth="6" />
        <circle
          cx="48" cy="48" r={radius}
          className="fill-none stroke-primary transition-all duration-500"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-xl font-bold tabular-nums">{percent}%</span>
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">complete</span>
      </div>
    </div>
  )
}

function MaterialRow({
  title, meta, progress, onView,
}: {
  title: string
  meta: string
  progress?: MaterialProgress
  onView: () => void
}) {
  const isViewed = !!progress?.viewed
  const readPercent = progress?.readPercent ?? 0

  return (
    <div className="group flex items-center justify-between gap-3 rounded-xl border bg-card px-4 py-3 transition-all hover:border-primary/30 hover:shadow-sm">
      <div className="flex min-w-0 items-center gap-3">
        <div className={cn(
          'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
          isViewed ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
        )}>
          {isViewed ? <CheckCircle2 className="h-5 w-5" /> : <FileText className="h-5 w-5" />}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{title}</p>
          <p className="text-xs text-muted-foreground">{meta}</p>
          {isViewed && (
            <div className="mt-1.5 flex items-center gap-2">
              <Progress value={readPercent} className="h-1 max-w-[120px]" />
              <span className="text-[10px] tabular-nums text-muted-foreground">{readPercent}%</span>
            </div>
          )}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        <Button variant="default" size="sm" onClick={onView} className="gap-1.5">
          <Eye className="h-4 w-4" />
          {isViewed ? 'Continue' : 'View'}
        </Button>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" disabled className="gap-1.5 opacity-60" aria-label="Download disabled">
                <Lock className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Locked</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Downloading is disabled — this document is view-only.</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  )
}

function PracticeRow({
  sheet, chapterName, progress, onStart, onSolution,
}: {
  sheet: { id: string; title: string; uploadedAt: string; hasSolution: boolean; fileData?: string; filePath?: string; solutionFileData?: string; solutionFilePath?: string; order: number }
  chapterName: string
  progress?: PracticeProgress
  onStart: () => void
  onSolution: () => void
}) {
  const status = progress?.status ?? 'not_started'
  const attempted = progress?.attempted ?? 0
  const total = progress?.totalQuestions ?? 0
  const isCompleted = status === 'completed'
  const isInProgress = status === 'in_progress'
  const totalQuestions = 8 + (sheet.order - 1) * 3
  const hasFile = Boolean(sheet.fileData || sheet.filePath)
  const hasSolutionFile = Boolean(sheet.solutionFileData || sheet.solutionFilePath)

  return (
    <div className="group flex items-center justify-between gap-3 rounded-xl border bg-card px-4 py-3 transition-all hover:border-primary/30 hover:shadow-sm">
      <div className="flex min-w-0 items-center gap-3">
        <div className={cn(
          'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
          isCompleted ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
            : isInProgress ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
            : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
        )}>
          {isCompleted ? <CheckCircle2 className="h-5 w-5" />
            : isInProgress ? <CircleDot className="h-5 w-5" />
            : <PenTool className="h-5 w-5" />}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{sheet.title}</p>
          <p className="text-xs text-muted-foreground">
            {chapterName} · {totalQuestions} questions
            {sheet.hasSolution ? ' · solutions available' : ''}
            {!hasFile ? ' · preview only' : ''}
          </p>
          {(isInProgress || isCompleted) && total > 0 && (
            <div className="mt-1.5 flex items-center gap-2">
              <Progress
                value={Math.min(100, Math.round((attempted / total) * 100))}
                className="h-1 max-w-[120px]"
              />
              <span className="text-[10px] tabular-nums text-muted-foreground">
                {attempted}/{total} {isCompleted ? '· done' : ''}
              </span>
            </div>
          )}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        <Button
          variant={isCompleted ? 'outline' : 'default'}
          size="sm"
          onClick={onStart}
          className="gap-1.5"
        >
          {isCompleted ? (<><Eye className="h-4 w-4" /> Review</>)
            : isInProgress ? (<><Play className="h-4 w-4" /> Continue</>)
            : (<><Play className="h-4 w-4" /> Start Practice</>)}
        </Button>
        {sheet.hasSolution && hasSolutionFile && (
          <Button variant="outline" size="sm" onClick={onSolution} className="gap-1.5">
            <Eye className="h-4 w-4" /> Solutions
          </Button>
        )}
      </div>
    </div>
  )
}

function EmptyRow({ icon: Icon, text }: { icon: React.ElementType, text: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
        <Icon className="h-6 w-6 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  )
}

function CalendarIcon() {
  return (
    <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="18" height="18" x="3" y="4" rx="2" />
      <path d="M3 10h18M8 2v4M16 2v4" />
    </svg>
  )
}
