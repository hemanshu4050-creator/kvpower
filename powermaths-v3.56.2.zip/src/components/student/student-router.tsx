'use client'

import { useAppStore } from '@/lib/store'
import { StudentDashboard } from './student-dashboard'
import { StudentLevels } from './student-levels'
import { StudentChapters } from './student-chapters'
import { StudentPractice } from './student-practice'
import { StudentExams } from './student-exams'
import { StudentResults } from './student-results'
import { StudentCertificates } from './student-certificates'
import { StudentNotifications } from './student-notifications'
import { StudentNotes } from './student-notes'
import { StudentMessages } from './student-messages'
import { StudentProfile } from './student-profile'
import { StudentSettings } from './student-settings'

const pageMap = {
  dashboard: StudentDashboard,
  levels: StudentLevels,
  chapters: StudentChapters,
  practice: StudentPractice,
  exams: StudentExams,
  results: StudentResults,
  certificates: StudentCertificates,
  notifications: StudentNotifications,
  notes: StudentNotes,
  messages: StudentMessages,
  profile: StudentProfile,
  settings: StudentSettings,
} as const

export function StudentRouter() {
  const page = useAppStore((s) => s.studentPage)
  const Component = pageMap[page] ?? StudentDashboard
  return (
    <div key={page} className="animate-fade-in">
      <Component />
    </div>
  )
}
