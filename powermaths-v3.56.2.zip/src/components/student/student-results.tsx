'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  BarChart3, Download, Search, Filter, Eye, Target,
  Award, BookCheck, CheckCircle2, XCircle, Clock,
} from 'lucide-react'
import { StatCard } from '@/components/shared/stat-card'
import { PageHeader } from '@/components/shared/page-header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useDataStore, type Result, type AnswerRecord } from '@/lib/data-store'
import { useNavLabel } from '@/lib/nav-helpers'
import { useAppStore } from '@/lib/store'
import { downloadResultScorecardPdf } from '@/lib/student-pdf'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export function StudentResults() {
  const pageTitle = useNavLabel('results', 'My Results', 'student')
  const user = useAppStore((s) => s.user)
  const results = useDataStore((s) => s.results)

  const myResults = React.useMemo(() => {
    if (!user) return []
    return results
      .filter((r) => r.studentId === user.id)
      .sort((a, b) => (b.createdAt + b.endTime).localeCompare(a.createdAt + a.endTime))
  }, [results, user])

  const [search, setSearch] = React.useState('')
  const [statusFilter, setStatusFilter] = React.useState<string>('all')
  const [detail, setDetail] = React.useState<Result | null>(null)

  const filtered = React.useMemo(() => {
    return myResults
      .filter((r) => statusFilter === 'all' || r.status === statusFilter)
      .filter((r) =>
        r.examTitle.toLowerCase().includes(search.toLowerCase()) ||
        r.chapterName.toLowerCase().includes(search.toLowerCase())
      )
  }, [myResults, search, statusFilter])

  const examsTaken = myResults.length
  const passedCount = myResults.filter((r) => r.status === 'passed').length
  const passRate = examsTaken ? Math.round((passedCount / examsTaken) * 100) : 0
  const avgScore = examsTaken ? Math.round(myResults.reduce((a, r) => a + r.percentage, 0) / examsTaken) : 0
  const bestScore = examsTaken ? Math.max(...myResults.map((r) => r.percentage)) : 0

  // ── Download a single result as a PDF scorecard (works for both pass
  // and fail attempts). The student view shows the question + correctness
  // but NOT the correct answer for questions they got wrong (so they can
  // re-attempt without spoilers). They can see the full breakdown in the
  // View dialog above.
  const handleDownload = (r: Result) => {
    try {
      downloadResultScorecardPdf({
        id: r.id,
        studentName: user?.name ?? 'Student',
        studentId: user?.id,
        examTitle: r.examTitle,
        chapterName: r.chapterName,
        attemptNumber: r.attemptNumber,
        createdAt: r.createdAt,
        timeTakenMinutes: r.timeTakenMinutes,
        totalQuestions: r.totalQuestions,
        attempted: r.attempted,
        correct: r.correct,
        wrong: r.wrong,
        marksObtained: r.marksObtained,
        totalMarks: r.totalMarks,
        percentage: r.percentage,
        status: r.status,
        answers: r.answers.map((a) => ({
          questionText: a.questionText,
          options: a.options,
          selectedOption: a.selectedOption,
          correctOption: a.correctOption,
          isCorrect: a.isCorrect,
          marksAwarded: a.marksAwarded,
          maxMarks: a.maxMarks,
          timeTakenSeconds: a.timeTakenSeconds,
        })),
        // Students get the full breakdown too — they can already see it in
        // the View dialog, and the PDF is their personal record.
        showAnswers: true,
      })
      toast.success('Scorecard downloaded', {
        description: `${r.examTitle} — ${r.percentage}%`,
      })
    } catch {
      toast.error('Could not generate PDF', { description: r.examTitle })
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={pageTitle}
        description="Track your performance across all exams"
        icon={<BarChart3 className="h-5 w-5" />}
      />

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Exams Taken" value={examsTaken} icon={BookCheck} accent="emerald" delay={0.05} />
        <StatCard title="Pass Rate" value={`${passRate}%`} icon={CheckCircle2} accent="teal" delay={0.1} />
        <StatCard title="Average Score" value={`${avgScore}%`} icon={Target} accent="amber" delay={0.15} />
        <StatCard title="Best Score" value={`${bestScore}%`} icon={Award} accent="violet" delay={0.2} />
      </div>

      {/* Results table */}
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle className="text-base">All Results</CardTitle>
              <CardDescription>{filtered.length} of {myResults.length} shown · Download any scorecard as PDF</CardDescription>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search exams..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8 sm:w-[220px]"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="sm:w-[140px]">
                  <Filter className="h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All status</SelectItem>
                  <SelectItem value="passed">Passed</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Exam</TableHead>
                <TableHead className="hidden md:table-cell">Chapter</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>%</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden lg:table-cell">Date</TableHead>
                <TableHead className="hidden lg:table-cell">Duration</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                    No results match your filters.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.examTitle}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{r.chapterName}</TableCell>
                    <TableCell className="font-semibold tabular-nums">{r.marksObtained}/{r.totalMarks}</TableCell>
                    <TableCell>
                      <Badge className={cn(
                        r.percentage >= 80 && 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15',
                        r.percentage >= 60 && r.percentage < 80 && 'bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15',
                        r.percentage < 60 && 'bg-rose-500/15 text-rose-700 dark:text-rose-400 hover:bg-rose-500/15',
                      )}>
                        {r.percentage}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {r.status === 'passed' ? (
                        <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
                          <CheckCircle2 className="h-3 w-3" /> Passed
                        </Badge>
                      ) : (
                        <Badge variant="destructive"><XCircle className="h-3 w-3" /> Failed</Badge>
                      )}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{r.createdAt}</TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{r.timeTakenMinutes} min</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setDetail(r)} disabled={r.answers.length === 0}>
                          <Eye className="h-4 w-4" /> View
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDownload(r)}>
                          <Download className="h-4 w-4" /> PDF
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail dialog */}
      <ResultDetailDialog result={detail} onClose={() => setDetail(null)} onDownload={handleDownload} />
    </div>
  )
}

function ResultDetailDialog({
  result, onClose, onDownload,
}: {
  result: Result | null
  onClose: () => void
  onDownload: (r: Result) => void
}) {
  // Look up the live Question(s) so we can render the optional explanation
  // image (AnswerRecord itself does not carry explanationImage).
  const questions = useDataStore((s) => s.questions)
  return (
    <Dialog open={!!result} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-2xl">
        {result && (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between gap-2 pr-8">
                <span>Scorecard — {result.examTitle}</span>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0"
                  onClick={() => onDownload(result)}
                >
                  <Download className="h-4 w-4" /> PDF
                </Button>
              </DialogTitle>
              <DialogDescription>
                {result.chapterName} · Attempt #{result.attemptNumber} · {result.createdAt}
              </DialogDescription>
            </DialogHeader>

            {/* Summary */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border bg-card p-3.5">
                <p className="text-xs text-muted-foreground">Score</p>
                <p className="mt-0.5 text-xl font-bold tabular-nums">{result.marksObtained}/{result.totalMarks}</p>
              </div>
              <div className="rounded-xl border bg-card p-3.5">
                <p className="text-xs text-muted-foreground">Percentage</p>
                <p className="mt-0.5 text-xl font-bold tabular-nums text-primary">{result.percentage}%</p>
              </div>
              <div className="rounded-xl border bg-card p-3.5">
                <p className="text-xs text-muted-foreground">Status</p>
                <p className={cn(
                  'mt-0.5 text-sm font-bold',
                  result.status === 'passed' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400',
                )}>
                  {result.status === 'passed' ? 'Passed ✓' : 'Failed ✗'}
                </p>
              </div>
              <div className="rounded-xl border bg-card p-3.5">
                <p className="text-xs text-muted-foreground">Time</p>
                <p className="mt-0.5 text-sm font-bold flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" /> {result.timeTakenMinutes} min
                </p>
              </div>
            </div>

            {/* Breakdown counts */}
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl border bg-emerald-500/5 p-3 text-center">
                <p className="text-xs text-muted-foreground">Correct</p>
                <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{result.correct}</p>
              </div>
              <div className="rounded-xl border bg-rose-500/5 p-3 text-center">
                <p className="text-xs text-muted-foreground">Wrong</p>
                <p className="text-lg font-bold text-rose-600 dark:text-rose-400">{result.wrong}</p>
              </div>
              <div className="rounded-xl border bg-amber-500/5 p-3 text-center">
                <p className="text-xs text-muted-foreground">Unattempted</p>
                <p className="text-lg font-bold text-amber-600 dark:text-amber-400">{result.totalQuestions - result.attempted}</p>
              </div>
            </div>

            {/* Progress bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Overall performance</span>
                <span className="font-semibold">{result.percentage}%</span>
              </div>
              <Progress value={result.percentage} className="h-2" />
            </div>

            {/* Question breakdown */}
            <div>
              <p className="mb-2 text-sm font-semibold">Question-by-question review</p>
              {result.answers.length === 0 ? (
                <p className="rounded-lg border bg-muted/30 px-4 py-6 text-center text-xs text-muted-foreground">
                  This result was seeded before detailed answer recording. Take a new exam to see full per-question breakdown.
                </p>
              ) : (
                <ScrollArea className="h-[360px] pr-3">
                  <div className="space-y-3">
                    {result.answers.map((a, i) => (
                      <AnswerCard
                        key={a.questionId}
                        answer={a}
                        index={i}
                        explanationImage={questions.find((q) => q.id === a.questionId)?.explanationImage}
                      />
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

function AnswerCard({
  answer, index, explanationImage,
}: {
  answer: AnswerRecord
  index: number
  explanationImage?: string
}) {
  const { questionText, options, selectedOption, correctOption, isCorrect, marksAwarded, maxMarks, explanation } = answer
  const unattempted = selectedOption === null
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.03, 0.4) }}
      className={cn(
        'rounded-xl border bg-card',
        isCorrect ? 'border-emerald-500/30' : unattempted ? 'border-amber-500/30' : 'border-rose-500/30',
      )}
    >
      <div className="flex items-start justify-between gap-3 border-b bg-muted/30 px-4 py-2.5">
        <div className="flex items-start gap-2.5">
          <span className={cn(
            'flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-xs font-bold',
            isCorrect ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400'
              : unattempted ? 'bg-amber-500/15 text-amber-700 dark:text-amber-400'
              : 'bg-rose-500/15 text-rose-700 dark:text-rose-400',
          )}>
            Q{index + 1}
          </span>
          <p className="text-sm font-medium leading-snug">{questionText}</p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {isCorrect ? (
            <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/15">
              <CheckCircle2 className="h-3 w-3" /> Correct
            </Badge>
          ) : unattempted ? (
            <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15">Skipped</Badge>
          ) : (
            <Badge className="bg-rose-500/15 text-rose-700 dark:text-rose-400 hover:bg-rose-500/15">
              <XCircle className="h-3 w-3" /> Wrong
            </Badge>
          )}
          <span className={cn(
            'text-xs font-semibold tabular-nums',
            marksAwarded > 0 ? 'text-emerald-600 dark:text-emerald-400'
              : marksAwarded < 0 ? 'text-rose-600 dark:text-rose-400'
              : 'text-muted-foreground',
          )}>
            {marksAwarded > 0 ? '+' : ''}{marksAwarded}/{maxMarks}
          </span>
        </div>
      </div>
      <div className="space-y-1.5 p-3">
        {options.map((opt, i) => {
          if (!opt && options.length > 2) return null
          const isCorrectOpt = i === correctOption
          const isSel = i === selectedOption
          return (
            <div
              key={i}
              className={cn(
                'flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-xs',
                isCorrectOpt
                  ? 'border-emerald-500/50 bg-emerald-500/10'
                  : isSel
                    ? 'border-rose-500/50 bg-rose-500/10'
                    : 'border-border bg-card text-muted-foreground',
              )}
            >
              <span className={cn(
                'flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-[10px] font-bold',
                isCorrectOpt
                  ? 'border-emerald-500 bg-emerald-500 text-white'
                  : isSel
                    ? 'border-rose-500 bg-rose-500 text-white'
                    : 'border-border text-muted-foreground',
              )}>
                {String.fromCharCode(65 + i)}
              </span>
              <span className="flex-1">{opt}</span>
              {isCorrectOpt && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />}
              {isSel && !isCorrectOpt && <XCircle className="h-3.5 w-3.5 text-rose-600 dark:text-rose-400" />}
            </div>
          )
        })}
        <div className="mt-1.5 rounded-md bg-primary/5 px-2.5 py-1.5 text-[11px]">
          <p className="font-semibold text-primary">Explanation</p>
          {/* v3.53.6 — whitespace-pre-wrap preserves newlines in multi-line
              explanations (e.g. step-by-step working imported from Word/PDF). */}
          <p className="mt-0.5 whitespace-pre-wrap text-muted-foreground">{explanation}</p>
          {explanationImage && (
            <img
              src={explanationImage}
              alt="Explanation illustration"
              className="mt-2 max-w-full rounded-lg border"
            />
          )}
        </div>
      </div>
    </motion.div>
  )
}
