// ============================================================
// Power Maths — "Friend" Chatbot Engine (non-AI, rule-based)
//
// Matching strategy (in priority order):
//   1. If user clicked a quick-reply chip → resolve that action directly.
//   2. If a scripted flow is waiting for input (e.g. WhatsApp number) →
//      consume the input and advance the flow.
//   3. Keyword match against scripted flow triggers → start that flow.
//   4. Keyword match against FAQ entries → return that FAQ answer.
//   5. Fuzzy keyword overlap with FAQ entries → return best match.
//   6. Graceful fallback → offer to escalate to a human on WhatsApp.
//
// Everything is deterministic. No AI. No external API calls.
// ============================================================

import {
  ALL_FAQS,
  VISITOR_FAQS,
  STUDENT_FAQS,
  VISITOR_FLOWS,
  STUDENT_FLOWS,
  VISITOR_WELCOME,
  STUDENT_WELCOME,
  VISITOR_DEFAULT_REPLIES,
  STUDENT_DEFAULT_REPLIES,
  buildWhatsappLink,
  type ChatAudience,
  type FaqEntry,
  type QuickReply,
  type ScriptedFlow,
} from './chat-data'

// ─────────────────────────── Types ───────────────────────────

export type ChatRole = 'bot' | 'user'

export interface ChatMessage {
  id: string
  role: ChatRole
  text: string
  quickReplies?: QuickReply[]
  /** Optional action payload attached to a bot message (e.g. open WhatsApp). */
  action?: ChatActionPayload
  at: number
}

export interface ChatActionPayload {
  type: 'nav' | 'handoff' | 'hint' | 'link'
  target?: string
  url?: string
}

export interface ChatLead {
  name?: string
  whatsapp?: string
  class?: string
  message?: string
  page?: string
  at: number
}

export interface ChatSessionState {
  audience: ChatAudience
  messages: ChatMessage[]
  /** Active flow id, or null if no flow is running. */
  activeFlowId: string | null
  /** Index of the next step to show in the active flow. */
  flowStepIndex: number
  /** Captured lead data (for visitor mode). */
  lead: ChatLead
  /** Whether a flow is waiting for collected input. */
  awaitingCollect: 'whatsapp' | 'name' | 'class' | 'free' | null
}

// ─────────────────────────── Helpers ───────────────────────────

let _idCounter = 0
function newId(): string {
  _idCounter += 1
  return `m${Date.now().toString(36)}${_idCounter}`
}

function normalise(s: string): string {
  return s.toLowerCase().trim().replace(/\s+/g, ' ')
}

function tokenise(s: string): string[] {
  return normalise(s)
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(' ')
    .filter((t) => t.length > 1)
}

/** Count how many of the entry's keywords appear in the message. */
function keywordScore(entry: { keywords: string[] }, message: string): number {
  const msg = normalise(message)
  let score = 0
  for (const kw of entry.keywords) {
    if (msg.includes(normalise(kw))) {
      // Longer keyword matches are weighted higher (more specific).
      score += kw.split(' ').length + 1
    }
  }
  return score
}

/** Token-overlap score (fuzzy fallback). */
function tokenOverlap(entry: { keywords: string[]; question: string }, message: string): number {
  const msgTokens = new Set(tokenise(message))
  if (msgTokens.size === 0) return 0
  const entryTokens = new Set([
    ...tokenise(entry.keywords.join(' ')),
    ...tokenise(entry.question),
  ])
  let overlap = 0
  for (const t of msgTokens) {
    if (entryTokens.has(t)) overlap += 1
  }
  return overlap / Math.sqrt(msgTokens.size)
}

function validateWhatsapp(input: string): { ok: boolean; digits: string } {
  const digits = input.replace(/\D/g, '')
  // Accept 10-digit Indian numbers or 12-digit with country code.
  if (digits.length === 10) return { ok: true, digits: `91${digits}` }
  if (digits.length === 11 && digits.startsWith('0')) return { ok: true, digits: `91${digits.slice(1)}` }
  if (digits.length === 12 && digits.startsWith('91')) return { ok: true, digits }
  if (digits.length >= 10 && digits.length <= 15) return { ok: true, digits }
  return { ok: false, digits }
}

// ─────────────────────────── Engine ───────────────────────────

export function createSession(audience: ChatAudience): ChatSessionState {
  const welcome = audience === 'visitor' ? VISITOR_WELCOME : STUDENT_WELCOME
  return {
    audience,
    messages: [
      {
        id: newId(),
        role: 'bot',
        text: welcome.message,
        quickReplies: welcome.quickReplies,
        at: Date.now(),
      },
    ],
    activeFlowId: null,
    flowStepIndex: 0,
    lead: { at: Date.now() },
    awaitingCollect: null,
  }
}

function getFaqs(audience: ChatAudience): FaqEntry[] {
  return audience === 'visitor' ? VISITOR_FAQS : STUDENT_FAQS
}

function getFlows(audience: ChatAudience): ScriptedFlow[] {
  return audience === 'visitor' ? VISITOR_FLOWS : STUDENT_FLOWS
}

function getDefaultReplies(audience: ChatAudience): QuickReply[] {
  return audience === 'visitor' ? VISITOR_DEFAULT_REPLIES : STUDENT_DEFAULT_REPLIES
}

function findFlow(audience: ChatAudience, flowId: string): ScriptedFlow | undefined {
  return getFlows(audience).find((f) => f.id === flowId)
}

/** Resolve a quick-reply action into a bot response. */
function resolveAction(action: string, state: ChatSessionState): {
  botText: string
  quickReplies?: QuickReply[]
  actionPayload?: ChatActionPayload
  newLead?: Partial<ChatLead>
  newFlowId?: string | null
  newFlowStep?: number
  newAwaiting?: 'whatsapp' | 'name' | 'class' | 'free' | null
} {
  // ── Navigation actions ──
  if (action.startsWith('nav:')) {
    const target = action.slice(4)
    const navLabels: Record<string, string> = {
      demo: 'Opening the free demo chapter for you…',
      dashboard: 'Opening your Dashboard…',
      practice: 'Opening Practice…',
      chapters: 'Opening My Chapters…',
      exams: 'Opening Exams…',
      results: 'Opening Results…',
      certificates: 'Opening Certificates…',
      notes: 'Opening My Notes…',
      messages: 'Opening Messages…',
      notifications: 'Opening Notifications…',
      settings: 'Opening Settings…',
    }
    return {
      botText: navLabels[target] ?? 'Opening…',
      quickReplies: getDefaultReplies(state.audience),
      actionPayload: { type: 'nav', target },
    }
  }

  // ── WhatsApp handoff ──
  if (action.startsWith('handoff:')) {
    const prefilled =
      state.audience === 'visitor'
        ? `Hi Prof. Vyas, I have a question about Power Maths. ${state.lead.name ? `My name is ${state.lead.name}.` : ''}`
        : `Hi Prof. Vyas, I'm ${state.lead.name || 'a student'} and I have a doubt.`
    return {
      botText: `Opening WhatsApp… You can message Prof. Vyas's team at any time. If WhatsApp doesn't open, save this number: and message manually.`,
      actionPayload: { type: 'handoff', url: buildWhatsappLink(prefilled) },
      quickReplies: getDefaultReplies(state.audience),
    }
  }

  // ── Hint how-to ──
  if (action === 'hint:howto') {
    return {
      botText:
        'To get a hint on any question: open Practice or a chapter test, tap the question, then tap the 💡 Hint button. I\'ll give you 3 hints — one at a time — that nudge you toward the answer without spoiling it.',
      quickReplies: [
        { label: 'Open Practice', action: 'nav:practice' },
        { label: 'Open My Chapters', action: 'nav:chapters' },
      ],
    }
  }

  // ── Flow start ──
  if (action.startsWith('flow:')) {
    const flowId = action.slice(5)
    // Some flows are inline sub-flows (e.g. VF_CLASS_8) — handle them.
    if (flowId === 'VF_CLASS_8' || flowId === 'VF_CLASS_9' || flowId === 'VF_CLASS_10') {
      const cls = flowId.split('_')[2]
      return {
        botText: `Great! For Class ${cls} we have 6 chapters, 315+ practice questions, mock exams and a formula notebook. Would you like to see pricing or start a free demo?`,
        quickReplies: [
          { label: 'See pricing', action: 'flow:VF_PRICING' },
          { label: 'Start a free demo', action: 'nav:demo' },
          { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
        ],
        newLead: { class: cls },
      }
    }
    if (flowId === 'VF_CLASS_ALL') {
      return {
        botText:
          'Perfect — Power Maths covers all three classes (8, 9, 10) with one subscription. Would you like to see pricing or start a free demo?',
        quickReplies: [
          { label: 'See pricing', action: 'flow:VF_PRICING' },
          { label: 'Start a free demo', action: 'nav:demo' },
          { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
        ],
      }
    }
    if (flowId === 'VF_END' || flowId === 'SF_END') {
      return {
        botText: 'No problem! I\'m here if you need me. Tap any quick reply below to continue.',
        quickReplies: getDefaultReplies(state.audience),
        newFlowId: null,
        newFlowStep: 0,
        newAwaiting: null,
      }
    }
    const flow = findFlow(state.audience, flowId)
    if (flow && flow.steps.length > 0) {
      const step = flow.steps[0]
      return {
        botText: step.message,
        quickReplies: step.quickReplies,
        newFlowId: flow.id,
        newFlowStep: step.collect ? 0 : 1,
        newAwaiting: step.collect ?? null,
      }
    }
  }

  // ── Fallback ──
  return {
    botText: 'How can I help you next?',
    quickReplies: getDefaultReplies(state.audience),
  }
}

/** Advance a flow that is waiting for collected input. */
function advanceFlow(state: ChatSessionState, userInput: string): {
  botText: string
  quickReplies?: QuickReply[]
  actionPayload?: ChatActionPayload
  newLead?: Partial<ChatLead>
  newFlowId?: string | null
  newFlowStep?: number
  newAwaiting?: 'whatsapp' | 'name' | 'class' | 'free' | null
} {
  const flow = state.activeFlowId ? findFlow(state.audience, state.activeFlowId) : null
  if (!flow) {
    return resolveAction('', state)
  }

  const currentStep = flow.steps[state.flowStepIndex]
  const collect = state.awaitingCollect

  // ── Validate / store the collected input ──
  const newLead: Partial<ChatLead> = {}
  if (collect === 'whatsapp') {
    const { ok, digits } = validateWhatsapp(userInput)
    if (!ok) {
      return {
        botText: 'Hmm, that doesn\'t look like a valid WhatsApp number. Please enter your 10-digit mobile number (e.g. 9876543210).',
        newAwaiting: 'whatsapp',
      }
    }
    newLead.whatsapp = digits
  } else if (collect === 'name') {
    if (userInput.trim().length < 2) {
      return {
        botText: 'Could you share your name please? Even just your first name is fine.',
        newAwaiting: 'name',
      }
    }
    newLead.name = userInput.trim()
  } else if (collect === 'class') {
    newLead.class = userInput.trim()
  } else if (collect === 'free') {
    newLead.message = userInput.trim()
  }

  // ── Advance to the next step ──
  const nextIndex = state.flowStepIndex + 1
  if (nextIndex < flow.steps.length) {
    const nextStep = flow.steps[nextIndex]
    return {
      botText: nextStep.message,
      quickReplies: nextStep.quickReplies,
      newLead,
      newFlowStep: nextStep.collect ? nextIndex : nextIndex + 1,
      newAwaiting: nextStep.collect ?? null,
    }
  }

  // ── Flow complete ──
  return {
    botText: 'Thank you! Prof. Vyas\'s team will be in touch shortly. Is there anything else I can help with?',
    quickReplies: getDefaultReplies(state.audience),
    newLead,
    newFlowId: null,
    newFlowStep: 0,
    newAwaiting: null,
  }
}

// ─────────────────────────── Main entry ───────────────────────────

export interface BotResponse {
  botText: string
  quickReplies?: QuickReply[]
  actionPayload?: ChatActionPayload
  /** Patch to apply to session state. */
  statePatch: Partial<ChatSessionState>
  /** Whether a lead was just completed (so caller can fire a webhook/log). */
  leadCompleted: boolean
}

/**
 * Process an incoming user message OR a quick-reply action.
 * Pass `userInput` for free text, or `action` for a chip click.
 */
export function processInput(
  state: ChatSessionState,
  opts: { userInput?: string; action?: string }
): BotResponse {
  const { userInput, action } = opts

  // ── 1. Quick-reply action ──
  if (action) {
    const r = resolveAction(action, state)
    const patch: Partial<ChatSessionState> = {}
    if (r.newLead) patch.lead = { ...state.lead, ...r.newLead, at: Date.now() }
    if (r.newFlowId !== undefined) patch.activeFlowId = r.newFlowId
    if (r.newFlowStep !== undefined) patch.flowStepIndex = r.newFlowStep
    if (r.newAwaiting !== undefined) patch.awaitingCollect = r.newAwaiting
    return {
      botText: r.botText,
      quickReplies: r.quickReplies,
      actionPayload: r.actionPayload,
      statePatch: patch,
      leadCompleted: Boolean(r.newLead && patch.lead && (patch.lead.whatsapp || patch.lead.name)),
    }
  }

  // ── 2. Flow awaiting input ──
  if (state.awaitingCollect && userInput) {
    const r = advanceFlow(state, userInput)
    const patch: Partial<ChatSessionState> = {}
    if (r.newLead) patch.lead = { ...state.lead, ...r.newLead, at: Date.now() }
    if (r.newFlowId !== undefined) patch.activeFlowId = r.newFlowId
    if (r.newFlowStep !== undefined) patch.flowStepIndex = r.newFlowStep
    if (r.newAwaiting !== undefined) patch.awaitingCollect = r.newAwaiting
    return {
      botText: r.botText,
      quickReplies: r.quickReplies,
      actionPayload: r.actionPayload,
      statePatch: patch,
      leadCompleted: Boolean(r.newLead && (r.newLead.whatsapp || r.newLead.name)),
    }
  }

  // ── 3. Keyword match against flow triggers ──
  if (userInput) {
    const flows = getFlows(state.audience)
    for (const flow of flows) {
      for (const trigger of flow.triggers) {
        if (normalise(userInput).includes(normalise(trigger))) {
          const step = flow.steps[0]
          return {
            botText: step.message,
            quickReplies: step.quickReplies,
            statePatch: {
              activeFlowId: flow.id,
              flowStepIndex: step.collect ? 0 : 1,
              awaitingCollect: step.collect ?? null,
            },
            leadCompleted: false,
          }
        }
      }
    }

    // ── 4 + 5. FAQ keyword / fuzzy match ──
    const faqs = getFaqs(state.audience)
    let best: FaqEntry | null = null
    let bestScore = 0
    for (const f of faqs) {
      const s = keywordScore(f, userInput)
      if (s > bestScore) {
        bestScore = s
        best = f
      }
    }
    if (!best || bestScore === 0) {
      // Fuzzy fallback on token overlap
      for (const f of faqs) {
        const s = tokenOverlap(f, userInput)
        if (s > bestScore) {
          bestScore = s
          best = f
        }
      }
    }
    if (best && bestScore > 0.15) {
      const followUps: QuickReply[] | undefined = best.followUps?.map((label) => ({
        label,
        action: inferActionFromLabel(label, state.audience),
      }))
      return {
        botText: best.answer,
        quickReplies: followUps ?? getDefaultReplies(state.audience),
        statePatch: {},
        leadCompleted: false,
      }
    }

    // ── 6. Graceful human-handoff fallback ──
    return {
      botText:
        'I\'m not 100% sure I understood that. It might be one of these — or I can connect you with Prof. Vyas on WhatsApp for a definite answer.',
      quickReplies: [
        { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
        { label: 'See pricing', action: 'flow:VF_PRICING' },
        { label: 'Start a free demo', action: 'nav:demo' },
        ...(state.audience === 'student'
          ? [{ label: 'Show my progress', action: 'flow:SF_PROGRESS' }]
          : []),
      ],
      statePatch: {},
      leadCompleted: false,
    }
  }

  return {
    botText: 'How can I help?',
    quickReplies: getDefaultReplies(state.audience),
    statePatch: {},
    leadCompleted: false,
  }
}

/** Infer a quick-reply action from a natural-language follow-up label. */
function inferActionFromLabel(label: string, audience: ChatAudience): string {
  const l = label.toLowerCase()
  if (l.includes('pricing') || l.includes('see pricing')) return 'flow:VF_PRICING'
  if (l.includes('demo')) return 'nav:demo'
  if (l.includes('prof') || l.includes('whatsapp') || l.includes('human')) return 'flow:VF_LEAD'
  if (l.includes('dashboard')) return 'nav:dashboard'
  if (l.includes('practice')) return 'nav:practice'
  if (l.includes('chapter')) return 'nav:chapters'
  if (l.includes('exam')) return 'nav:exams'
  if (l.includes('result')) return 'nav:results'
  if (l.includes('certificate')) return 'nav:certificates'
  if (l.includes('note')) return 'nav:notes'
  if (l.includes('message')) return 'nav:messages'
  if (l.includes('setting')) return 'nav:settings'
  if (l.includes('hint')) return 'hint:howto'
  if (l.includes('progress')) return 'flow:SF_PROGRESS'
  if (l.includes('included')) return 'flow:VF_PRICING'
  return audience === 'visitor' ? 'flow:VF_LEAD' : 'flow:SF_HANDOFF'
}

// ─────────────────────────── Hint retrieval ───────────────────────────

import { QUESTION_HINTS, type HintLadder } from './question-hints'

export function getHintLadder(questionId: string): HintLadder | null {
  return QUESTION_HINTS[questionId] ?? null
}
