/**
 * Seed Formula + Theory content for every chapter.
 *
 * Curriculum coverage: Class 8–10 (primary) with selected Class 11–12
 * concepts where appropriate. Each chapter has a rich formula notebook
 * and a structured theory textbook.
 *
 * LaTeX is KaTeX-compatible. Inline math uses `$...$` in theory bodies;
 * formula `expression` fields are pure LaTeX (no delimiters).
 */

import type { Formula, TheorySection } from '@/lib/data-store'

// ───────────────────────────── CH001 — Number System ─────────────────────────────

const formulasNumberSystem: Formula[] = [
  {
    id: 'F-NS-01', title: 'Prime Factorisation', category: 'Primes',
    expression: 'n = p_1^{a_1} \\times p_2^{a_2} \\times \\cdots \\times p_k^{a_k}',
    explanation: 'Every composite number can be expressed uniquely as a product of powers of primes (Fundamental Theorem of Arithmetic).',
    example: '24 = 2^3 \\times 3', order: 1, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-02', title: 'LCM via Prime Factors', category: 'LCM & HCF',
    expression: '\\text{LCM}(a,b) = p_1^{\\max(\\alpha_1,\\beta_1)} \\times p_2^{\\max(\\alpha_2,\\beta_2)} \\times \\cdots',
    explanation: 'Take the highest power of each prime that appears in either number.',
    example: 'LCM(12, 18) = 2^2 \\times 3^2 = 36', order: 2, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-03', title: 'HCF via Prime Factors', category: 'LCM & HCF',
    expression: '\\text{HCF}(a,b) = p_1^{\\min(\\alpha_1,\\beta_1)} \\times p_2^{\\min(\\alpha_2,\\beta_2)} \\times \\cdots',
    explanation: 'Take the lowest power of each prime common to both numbers.',
    example: 'HCF(12, 18) = 2^1 \\times 3^1 = 6', order: 3, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-04', title: 'LCM × HCF = Product', category: 'LCM & HCF',
    expression: '\\text{LCM}(a,b) \\times \\text{HCF}(a,b) = a \\times b',
    explanation: 'Useful when one of LCM or HCF is known.',
    example: 'For 12 and 18: 36 × 6 = 216 = 12 × 18 ✓', order: 4, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-05', title: 'Laws of Exponents', category: 'Exponents',
    expression: 'a^m \\times a^n = a^{m+n}, \\quad \\frac{a^m}{a^n} = a^{m-n}, \\quad (a^m)^n = a^{mn}',
    explanation: 'The three core laws for manipulating powers with the same base.',
    example: '2^3 \\times 2^4 = 2^7 = 128', order: 5, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-06', title: 'Zero & Negative Exponents', category: 'Exponents',
    expression: 'a^0 = 1, \\quad a^{-n} = \\frac{1}{a^n}',
    explanation: 'Any non-zero number raised to 0 equals 1; negative exponents give reciprocals.',
    example: '5^0 = 1, \\quad 2^{-3} = \\frac{1}{8}', order: 6, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-07', title: 'Scientific Notation', category: 'Exponents',
    expression: 'N = a \\times 10^{k}, \\quad 1 \\le |a| < 10',
    explanation: 'Compact way to write very large or very small numbers.',
    example: '3{,}45{,}00{,}000 = 3.45 \\times 10^{7}', order: 7, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-08', title: 'Divisibility by 3 (and 9)', category: 'Divisibility',
    expression: '\\text{A number is divisible by 3} \\iff \\sum \\text{digits} \\equiv 0 \\pmod 3',
    explanation: 'Sum the digits; if the sum is divisible by 3 (or 9), so is the number.',
    example: '471 → 4+7+1 = 12 → divisible by 3 ✓', order: 8, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-09', title: 'Rational Number', category: 'Rational & Irrational',
    expression: '\\mathbb{Q} = \\left\\{ \\frac{p}{q} : p,q \\in \\mathbb{Z},\\ q \\neq 0 \\right\\}',
    explanation: 'A rational number is any number that can be written as a ratio of two integers.',
    example: '\\frac{3}{4},\\ -7,\\ 0.\\overline{6}\\ \\text{are rational}', order: 9, createdAt: '2026-06-02',
  },
  {
    id: 'F-NS-10', title: 'Irrational Number', category: 'Rational & Irrational',
    expression: '\\sqrt{2} \\notin \\mathbb{Q}, \\quad \\pi \\notin \\mathbb{Q}, \\quad e \\notin \\mathbb{Q}',
    explanation: 'Numbers that cannot be expressed as p/q are irrational. Their decimals never terminate or repeat.',
    example: '\\sqrt{2} \\approx 1.41421356...', order: 10, createdAt: '2026-06-02',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-NS-11 … F-NS-20).
  {
    id: 'F-NS-11', title: 'Even and Odd Numbers', category: 'Number Types',
    expression: '\\text{Even} = 2k, \\quad \\text{Odd} = 2k+1 \\quad (k \\in \\mathbb{Z})',
    explanation: 'Even numbers are divisible by 2; odd numbers leave a remainder of 1 when divided by 2.',
    example: '14 = 2×7 (even), 17 = 2×8+1 (odd)', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-12', title: 'Divisibility by 2, 5 and 10', category: 'Divisibility',
    expression: '\\text{Div by 2} \\iff \\text{units digit even}; \\quad \\text{Div by 5} \\iff \\text{units digit 0 or 5}; \\quad \\text{Div by 10} \\iff \\text{units digit 0}',
    explanation: 'Quick divisibility checks using only the last digit.',
    example: '36 div by 2 ✓; 45 div by 5 ✓; 200 div by 10 ✓', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-13', title: 'Divisibility by 4', category: 'Divisibility',
    expression: '\\text{Div by 4} \\iff \\text{last 2 digits form a multiple of 4}',
    explanation: 'A number is divisible by 4 if its last two digits form a number divisible by 4.',
    example: '236 → 36 ÷ 4 = 9, so 236 is divisible by 4', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-14', title: 'Divisibility by 6', category: 'Divisibility',
    expression: '\\text{Div by 6} \\iff \\text{Div by 2 AND Div by 3}',
    explanation: 'A number is divisible by 6 if it is divisible by both 2 and 3.',
    example: '54: even ✓ and 5+4=9 div by 3 ✓, so 54 div by 6', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-15', title: 'Divisibility by 11', category: 'Divisibility',
    expression: '\\text{Div by 11} \\iff (\\text{sum of odd-place digits}) - (\\text{sum of even-place digits}) \\equiv 0 \\pmod{11}',
    explanation: 'The alternating sum of digits must be a multiple of 11 (including 0).',
    example: '121 → (1+1) − 2 = 0, so 121 is divisible by 11', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-16', title: 'Perfect Square', category: 'Squares & Cubes',
    expression: 'n = k^2 \\quad (k \\in \\mathbb{N})',
    explanation: 'A perfect square is the product of an integer with itself.',
    example: '49 = 7^2 is a perfect square', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-17', title: 'Perfect Cube', category: 'Squares & Cubes',
    expression: 'n = k^3 \\quad (k \\in \\mathbb{N})',
    explanation: 'A perfect cube is the product of an integer with itself, twice.',
    example: '27 = 3^3 is a perfect cube', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-18', title: 'Square Root of a Perfect Square', category: 'Squares & Cubes',
    expression: '\\sqrt{k^2} = |k|',
    explanation: 'The square root of a perfect square gives back the original integer (its absolute value).',
    example: '\\sqrt{81} = 9', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-19', title: 'Cube Root of a Perfect Cube', category: 'Squares & Cubes',
    expression: '\\sqrt[3]{k^3} = k',
    explanation: 'The cube root of a perfect cube gives back the original integer.',
    example: '\\sqrt[3]{125} = 5', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-NS-20', title: 'Percentage to Fraction', category: 'Fractions & Decimals',
    expression: 'x\\% = \\frac{x}{100}',
    explanation: 'A percentage is a fraction with denominator 100.',
    example: '25\\% = \\frac{25}{100} = 0.25', order: 20, createdAt: '2026-11-02',
  },
]

const theoryNumberSystem: TheorySection[] = [
  {
    id: 'T-NS-01', title: 'Introduction to the Number System', order: 1, createdAt: '2026-06-02',
    body: `## What is a Number System?

A **number system** is a organised way to represent and work with numbers. In mathematics, every number you encounter — whether a counting number, a fraction, a decimal, or a root — belongs to a specific family.

> tip
> Understanding the family a number belongs to is the first step to mastering arithmetic, algebra and beyond.

### The Big Families
- **Natural Numbers** ($\\mathbb{N}$): 1, 2, 3, …
- **Whole Numbers** ($\\mathbb{W}$): 0, 1, 2, 3, …
- **Integers** ($\\mathbb{Z}$): …, -3, -2, -1, 0, 1, 2, 3, …
- **Rational Numbers** ($\\mathbb{Q}$): any number of the form $\\frac{p}{q}$, $q \\neq 0$
- **Irrational Numbers**: cannot be written as $\\frac{p}{q}$ (e.g. $\\sqrt{2}$, $\\pi$)
- **Real Numbers** ($\\mathbb{R}$): the union of rational and irrational numbers

Each family is a *superset* of the previous one — every natural number is whole, every whole is an integer, every integer is rational, and every rational is real.`,
  },
  {
    id: 'T-NS-02', title: 'Natural, Whole & Integers', order: 2, createdAt: '2026-06-02',
    body: `## Natural Numbers ($\\mathbb{N}$)
Used for counting: **1, 2, 3, …** They have a smallest element (1) but no largest.

## Whole Numbers ($\\mathbb{W}$)
Natural numbers together with **0**: **0, 1, 2, 3, …**

## Integers ($\\mathbb{Z}$)
Whole numbers and their negatives: **…, -3, -2, -1, 0, 1, 2, 3, …**

> important
> Integers are closed under addition, subtraction and multiplication — but **not** under division. For example $7 \\div 2 = 3.5$ which is not an integer.

### Properties of Integer Operations
- **Commutative**: $a+b = b+a$ and $a \\times b = b \\times a$
- **Associative**: $(a+b)+c = a+(b+c)$ and $(a\\times b)\\times c = a\\times(b\\times c)$
- **Distributive**: $a \\times (b+c) = a\\times b + a\\times c$`,
  },
  {
    id: 'T-NS-03', title: 'Rational Numbers', order: 3, createdAt: '2026-06-02',
    body: `## Rational Numbers ($\\mathbb{Q}$)

A **rational number** is any number that can be written as a fraction $\\frac{p}{q}$ where $p$ and $q$ are integers and $q \\neq 0$.

### Examples
- $\\frac{3}{4}$ — proper fraction
- $\\frac{-7}{1} = -7$ — every integer is rational
- $0.\\overline{6} = \\frac{2}{3}$ — repeating decimals are rational
- $0.25 = \\frac{1}{4}$ — terminating decimals are rational

### Equivalent Fractions
Two fractions $\\frac{a}{b}$ and $\\frac{c}{d}$ are equivalent if $a \\times d = b \\times c$.

### Standard Form
A fraction $\\frac{p}{q}$ is in **standard form** when $q > 0$ and $\\gcd(|p|, q) = 1$.

> tip
> To convert $\\frac{-12}{18}$ to standard form: divide both by $\\gcd(12, 18) = 6$ and move the sign to the top → $\\frac{-2}{3}$.`,
  },
  {
    id: 'T-NS-04', title: 'Irrational Numbers & Real Numbers', order: 4, createdAt: '2026-06-02',
    body: `## Irrational Numbers

A number that **cannot** be written as $\\frac{p}{q}$ is called **irrational**. Their decimal expansions are *non-terminating* and *non-recurring*.

### Famous Irrationals
- $\\sqrt{2} \\approx 1.4142135...$
- $\\sqrt{3} \\approx 1.7320508...$
- $\\pi \\approx 3.1415926...$
- $e \\approx 2.7182818...$

> warning
> $\\sqrt{a}$ is irrational whenever $a$ is a positive integer that is **not** a perfect square. So $\\sqrt{4} = 2$ (rational) but $\\sqrt{5}$ is irrational.

## Real Numbers ($\\mathbb{R}$)
The set of all rational and irrational numbers together forms the **real numbers**. Every real number corresponds to exactly one point on the number line, and vice versa.

### Pythagoras' Proof that $\\sqrt{2}$ is Irrational
Assume $\\sqrt{2} = \\frac{p}{q}$ in lowest terms. Then $2q^2 = p^2$, so $p^2$ is even, so $p$ is even. Write $p = 2k$. Then $2q^2 = 4k^2 \\Rightarrow q^2 = 2k^2$, so $q$ is also even — contradicting that $\\frac{p}{q}$ was in lowest terms. ∎`,
  },
  {
    id: 'T-NS-05', title: 'Prime Numbers & Composite Numbers', order: 5, createdAt: '2026-06-02',
    body: `## Prime Numbers
A **prime number** is a natural number greater than 1 that has exactly two positive divisors: 1 and itself.

### First few primes
**2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, ...**

> important
> 2 is the **only even prime**. Every other even number is divisible by 2 and hence composite.

## Composite Numbers
A **composite number** has more than two divisors. The first few are **4, 6, 8, 9, 10, 12, ...**

### Sieve of Eratosthenes
To list all primes up to $n$:
1. Write numbers 2 to $n$.
2. Circle 2, then cross out every 2nd number.
3. Move to the next uncrossed number (3), circle it, cross out every 3rd number.
4. Repeat until $\\sqrt{n}$. The circled numbers are prime.

### Fundamental Theorem of Arithmetic
Every composite number can be expressed **uniquely** as a product of powers of primes (up to order).
$$24 = 2^3 \\times 3, \\quad 360 = 2^3 \\times 3^2 \\times 5$$`,
  },
  {
    id: 'T-NS-06', title: 'Even, Odd & Number Line', order: 6, createdAt: '2026-06-02',
    body: `## Even and Odd Numbers
- **Even**: divisible by 2 → $2k$ for some integer $k$
- **Odd**: not divisible by 2 → $2k + 1$

### Parity Rules
| Operation | Result |
|-----------|--------|
| Even + Even | Even |
| Odd + Odd | Even |
| Even + Odd | Odd |
| Even × Any | Even |
| Odd × Odd | Odd |

## The Number Line
A **number line** is a straight line on which every real number is represented by a point.

> tip
> Numbers to the **right** are greater; numbers to the **left** are smaller. The distance between two numbers $a$ and $b$ on the line is $|a - b|$.

### Key Properties
- $0$ is the **origin**
- Positive numbers lie to the right of 0
- Negative numbers lie to the left of 0
- Every integer, rational and irrational has a unique position`,
  },
  {
    id: 'T-NS-07', title: 'Divisibility Rules', order: 7, createdAt: '2026-06-02',
    body: `## Quick Divisibility Tests

| Rule | Test |
|------|------|
| **By 2** | Last digit is even (0, 2, 4, 6, 8) |
| **By 3** | Sum of digits is divisible by 3 |
| **By 4** | Last two digits form a number divisible by 4 |
| **By 5** | Last digit is 0 or 5 |
| **By 6** | Divisible by both 2 and 3 |
| **By 8** | Last three digits form a number divisible by 8 |
| **By 9** | Sum of digits is divisible by 9 |
| **By 10** | Last digit is 0 |
| **By 11** | Alternating sum of digits is divisible by 11 |

### Worked Example
Check 1,078,932 for divisibility by 11:
$$1 - 0 + 7 - 8 + 9 - 3 + 2 = 8$$
8 is not divisible by 11, so neither is 1,078,932.

> warning
> The rule for 7 is more involved and usually not worth memorising — just perform the long division.`,
  },
  {
    id: 'T-NS-08', title: 'Summary & Quick Revision', order: 8, createdAt: '2026-06-02',
    body: `## Quick Revision

> important
> **Number family tree**: $\\mathbb{N} \\subset \\mathbb{W} \\subset \\mathbb{Z} \\subset \\mathbb{Q} \\subset \\mathbb{R}$. Irrationals ($\\overline{\\mathbb{Q}}$) fill the gaps in $\\mathbb{Q}$ to make $\\mathbb{R}$.

### Key Formulae Recap
- LCM × HCF = product of the two numbers
- $a^m \\times a^n = a^{m+n}$, $\\frac{a^m}{a^n} = a^{m-n}$, $(a^m)^n = a^{mn}$
- $a^0 = 1$, $a^{-n} = \\frac{1}{a^n}$
- Scientific notation: $N = a \\times 10^k$, $1 \\le |a| < 10$

### Common Mistakes to Avoid
1. **0 is a whole number but NOT a natural number.**
2. $\\sqrt{a}$ is irrational only when $a$ is not a perfect square.
3. $\\frac{p}{q}$ is undefined when $q = 0$ — never divide by zero.
4. Repeating decimals like $0.\\overline{3}$ ARE rational ($= \\frac{1}{3}$).

### Practice Notes
- Find HCF and LCM of 84 and 120 using prime factorisation.
- Express $0.\\overline{45}$ as a fraction in lowest terms.
- Without dividing, check if 1,296 is divisible by 6, 9 and 11.`,
  },
]

// ───────────────────────────── CH002 — Algebra Basics ─────────────────────────────

const formulasAlgebra: Formula[] = [
  {
    id: 'F-AL-01', title: 'Square of a Sum', category: 'Identities',
    expression: '(a+b)^2 = a^2 + 2ab + b^2',
    explanation: 'Expand the square of a binomial sum.',
    example: '(x+3)^2 = x^2 + 6x + 9', order: 1, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-02', title: 'Square of a Difference', category: 'Identities',
    expression: '(a-b)^2 = a^2 - 2ab + b^2',
    explanation: 'Expand the square of a binomial difference.',
    example: '(x-5)^2 = x^2 - 10x + 25', order: 2, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-03', title: 'Difference of Squares', category: 'Identities',
    expression: 'a^2 - b^2 = (a+b)(a-b)',
    explanation: 'A difference of two squares factors into a sum times a difference.',
    example: 'x^2 - 16 = (x+4)(x-4)', order: 3, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-04', title: 'Cube of a Sum', category: 'Identities',
    expression: '(a+b)^3 = a^3 + 3a^2 b + 3ab^2 + b^3',
    explanation: 'Expand the cube of a binomial sum.',
    example: '(x+2)^3 = x^3 + 6x^2 + 12x + 8', order: 4, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-05', title: 'Cube of a Difference', category: 'Identities',
    expression: '(a-b)^3 = a^3 - 3a^2 b + 3ab^2 - b^3',
    explanation: 'Expand the cube of a binomial difference.',
    example: '(x-1)^3 = x^3 - 3x^2 + 3x - 1', order: 5, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-06', title: 'Sum of Cubes', category: 'Identities',
    expression: 'a^3 + b^3 = (a+b)(a^2 - ab + b^2)',
    explanation: 'Factorisation of the sum of two cubes.',
    example: 'x^3 + 8 = (x+2)(x^2 - 2x + 4)', order: 6, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-07', title: 'Difference of Cubes', category: 'Identities',
    expression: 'a^3 - b^3 = (a-b)(a^2 + ab + b^2)',
    explanation: 'Factorisation of the difference of two cubes.',
    example: 'x^3 - 27 = (x-3)(x^2 + 3x + 9)', order: 7, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-08', title: 'Linear Equation (One Variable)', category: 'Linear Equations',
    expression: 'ax + b = 0 \\implies x = -\\frac{b}{a}',
    explanation: 'Solution of a linear equation in one variable.',
    example: '3x + 6 = 0 \\implies x = -2', order: 8, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-09', title: 'Quadratic Formula', category: 'Quadratic',
    expression: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
    explanation: 'The two roots of $ax^2 + bx + c = 0$ (with $a \\neq 0$).',
    example: 'x^2 - 5x + 6 = 0 \\implies x = \\frac{5 \\pm 1}{2} = 3 \\text{ or } 2', order: 9, createdAt: '2026-06-11',
  },
  {
    id: 'F-AL-10', title: 'Discriminant', category: 'Quadratic',
    expression: '\\Delta = b^2 - 4ac',
    explanation: '$\\Delta > 0$: two distinct real roots; $\\Delta = 0$: one repeated root; $\\Delta < 0$: no real roots.',
    example: 'For x^2 - 4x + 5: \\Delta = 16 - 20 = -4 (no real roots)', order: 10, createdAt: '2026-06-11',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-AL-11 … F-AL-20).
  {
    id: 'F-AL-11', title: 'Monomial × Binomial', category: 'Multiplication',
    expression: 'a(b+c) = ab + ac',
    explanation: 'Distributive law — multiply the monomial by each term of the binomial.',
    example: '3x(2x+5) = 6x^2 + 15x', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-12', title: 'Product of Two Binomials (FOIL)', category: 'Multiplication',
    expression: '(a+b)(c+d) = ac + ad + bc + bd',
    explanation: 'Multiply each term of the first binomial by each term of the second (FOIL).',
    example: '(x+2)(x+3) = x^2 + 5x + 6', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-13', title: 'Factorisation — Common Factor', category: 'Factorisation',
    expression: 'ab + ac = a(b+c)',
    explanation: 'Factor out the greatest common factor (GCF) from each term.',
    example: '6x^2 + 9x = 3x(2x+3)', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-14', title: 'Factorisation by Grouping', category: 'Factorisation',
    expression: 'ab + ac + pb + pc = a(b+c) + p(b+c) = (a+p)(b+c)',
    explanation: 'Group terms with a common factor, then factor the resulting common binomial.',
    example: 'x^2 + xy + 2x + 2y = (x+2)(x+y)', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-15', title: 'Linear Equation in Two Variables', category: 'Linear Equations',
    expression: 'ax + by + c = 0 \\quad (a, b \\neq 0)',
    explanation: 'A linear equation in two variables has infinitely many solutions (x, y).',
    example: '2x + 3y = 12 → (3,2), (6,0), (0,4) all work', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-16', title: 'Slope of a Line', category: 'Coordinate Geometry',
    expression: 'm = \\frac{y_2 - y_1}{x_2 - x_1}',
    explanation: 'The slope is the change in y divided by the change in x between two points.',
    example: '(1,2) and (4,8): m = \\frac{8-2}{4-1} = 2', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-17', title: 'Distance Between Two Points', category: 'Coordinate Geometry',
    expression: 'd = \\sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}',
    explanation: 'Straight-line distance between two points on the coordinate plane.',
    example: '(0,0) and (3,4): d = \\sqrt{9+16} = 5', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-18', title: 'Midpoint of a Segment', category: 'Coordinate Geometry',
    expression: 'M = \\left( \\frac{x_1+x_2}{2}, \\frac{y_1+y_2}{2} \\right)',
    explanation: 'The midpoint is the average of the x-coordinates and the average of the y-coordinates.',
    example: 'Midpoint of (2,4) and (6,10) = (4,7)', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-19', title: 'Sum of First n Natural Numbers', category: 'Sequences',
    expression: '1 + 2 + 3 + \\cdots + n = \\frac{n(n+1)}{2}',
    explanation: 'Triangular-number formula — a quick way to add the first n counting numbers.',
    example: '1+2+...+10 = \\frac{10×11}{2} = 55', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-AL-20', title: 'Sum of First n Squares', category: 'Sequences',
    expression: '1^2 + 2^2 + 3^2 + \\cdots + n^2 = \\frac{n(n+1)(2n+1)}{6}',
    explanation: 'Standard formula for the sum of the first n perfect squares.',
    example: '1^2+2^2+3^2+4^2 = \\frac{4×5×9}{6} = 30', order: 20, createdAt: '2026-11-02',
  },
]

const theoryAlgebra: TheorySection[] = [
  {
    id: 'T-AL-01', title: 'Introduction to Algebra', order: 1, createdAt: '2026-06-11',
    body: `## What is Algebra?

**Algebra** is the branch of mathematics where letters (called *variables*) stand for unknown numbers, allowing us to state relationships and solve problems in a general way.

> tip
> Think of a variable as a box — it can hold any number. Algebra gives us rules for working with these boxes without knowing what is inside.

### Algebraic Expressions
An **algebraic expression** combines constants, variables and the operations $+$, $-$, $\\times$, $\\div$.

- $3x + 5$ — a binomial (two terms)
- $2x^2 - 7x + 1$ — a trinomial
- $5y$ — a monomial

### Terms, Coefficients and Degrees
- A **term** is a single number, variable or product (e.g. $7x^2$)
- The **coefficient** is the numerical part of a term (7 in $7x^2$)
- The **degree** of a term in one variable is the exponent (2 in $7x^2$)
- The degree of an expression is the highest degree among its terms`,
  },
  {
    id: 'T-AL-02', title: 'Algebraic Identities', order: 2, createdAt: '2026-06-11',
    body: `## What is an Identity?

An **algebraic identity** is an equation that is true for *every* value of the variable(s). Identities are powerful tools for simplifying expressions and factorising polynomials.

### The Eight Standard Identities
1. $(a+b)^2 = a^2 + 2ab + b^2$
2. $(a-b)^2 = a^2 - 2ab + b^2$
3. $a^2 - b^2 = (a+b)(a-b)$
4. $(a+b)^3 = a^3 + 3a^2 b + 3ab^2 + b^3$
5. $(a-b)^3 = a^3 - 3a^2 b + 3ab^2 - b^3$
6. $a^3 + b^3 = (a+b)(a^2 - ab + b^2)$
7. $a^3 - b^3 = (a-b)(a^2 + ab + b^2)$
8. $(x+a)(x+b) = x^2 + (a+b)x + ab$

> important
> Identities 1–3 are used constantly — memorise them. Identities 4–7 are useful for factorising cubic expressions.

### Worked Example — Without Expanding Fully
Compute $103^2$ using an identity:
$$103^2 = (100 + 3)^2 = 100^2 + 2(100)(3) + 3^2 = 10000 + 600 + 9 = 10609$$`,
  },
  {
    id: 'T-AL-03', title: 'Linear Equations in One Variable', order: 3, createdAt: '2026-06-11',
    body: `## What is a Linear Equation?

A **linear equation in one variable** has the form
$$ax + b = 0, \\quad a \\neq 0$$
Its graph (when solved for $y$) is a straight line — hence "linear".

### Solving Strategy
1. Move all variable terms to one side, constants to the other.
2. Combine like terms.
3. Divide by the coefficient of the variable.

### Example
Solve $5x - 3 = 2x + 9$:
$$5x - 2x = 9 + 3 \\implies 3x = 12 \\implies x = 4$$

> tip
> Always check by substituting back: $5(4) - 3 = 17$ and $2(4) + 9 = 17$ ✓

### Word Problem
"The sum of two consecutive odd integers is 56. Find them."
Let the smaller be $x$. The next odd is $x + 2$.
$$x + (x+2) = 56 \\implies 2x = 54 \\implies x = 27$$
So the integers are **27 and 29**.`,
  },
  {
    id: 'T-AL-04', title: 'Factorisation', order: 4, createdAt: '2026-06-11',
    body: `## What is Factorisation?

**Factorisation** is the reverse of expansion — writing an expression as a product of simpler expressions (its *factors*).

### Common Methods
1. **Common factor**: $6x + 9 = 3(2x + 3)$
2. **Grouping**: $ax + ay + bx + by = a(x+y) + b(x+y) = (a+b)(x+y)$
3. **Difference of squares**: $x^2 - 25 = (x+5)(x-5)$
4. **Trinomial splitting**: $x^2 + 5x + 6 = (x+2)(x+3)$ — find two numbers that multiply to 6 and add to 5
5. **Sum/Difference of cubes**: $x^3 \\pm y^3$ identities

### Worked Example
Factorise $x^2 + 7x + 12$:
- Find two numbers whose product is 12 and sum is 7 → **3 and 4**
- $x^2 + 7x + 12 = (x+3)(x+4)$

> warning
> Always multiply your factors back out to check the result. A common mistake is to pick numbers with the right product but wrong sum.`,
  },
  {
    id: 'T-AL-05', title: 'Quadratic Equations', order: 5, createdAt: '2026-06-11',
    body: `## Quadratic Equation

A **quadratic equation** in standard form is:
$$ax^2 + bx + c = 0, \\quad a \\neq 0$$

### Methods of Solution
1. **Factorisation** — split into two linear factors and use the zero-product rule
2. **Completing the square** — rewrite as $(x+p)^2 = q$
3. **Quadratic formula** — $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$ (always works)

### The Discriminant
$$\\Delta = b^2 - 4ac$$
| $\\Delta$ | Roots |
|----------|-------|
| $> 0$ | Two distinct real roots |
| $= 0$ | One repeated real root |
| $< 0$ | No real roots (complex) |

### Worked Example
Solve $x^2 - 5x + 6 = 0$:
- $a = 1, b = -5, c = 6$
- $\\Delta = 25 - 24 = 1$
- $x = \\frac{5 \\pm 1}{2} = 3$ or $2$

> important
> Always simplify first. $2x^2 - 8x + 6 = 0$ becomes $x^2 - 4x + 3 = 0$ after dividing by 2 — easier to solve and the roots are unchanged.`,
  },
  {
    id: 'T-AL-06', title: 'Summary & Quick Revision', order: 6, createdAt: '2026-06-11',
    body: `## Quick Revision

> important
> Master the three identities $(a+b)^2$, $(a-b)^2$ and $a^2 - b^2$ — they unlock most of school algebra.

### Key Formulae Recap
- $(a \\pm b)^2 = a^2 \\pm 2ab + b^2$
- $a^2 - b^2 = (a+b)(a-b)$
- $a^3 \\pm b^3 = (a \\pm b)(a^2 \\mp ab + b^2)$
- Quadratic: $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$
- Discriminant: $\\Delta = b^2 - 4ac$

### Common Mistakes
1. $(a+b)^2 \\neq a^2 + b^2$ — always include the middle $2ab$ term.
2. $\\sqrt{a^2 + b^2} \\neq a + b$.
3. Don't forget to flip the inequality sign when multiplying/dividing by a negative.

### Practice Notes
- Expand $(2x+3)^2$ using an identity.
- Factorise $x^2 - 9x + 20$.
- Solve $2x^2 - 7x + 3 = 0$ using the quadratic formula.`,
  },
]

// ───────────────────────────── CH003 — Geometry ─────────────────────────────

const formulasGeometry: Formula[] = [
  {
    id: 'F-GM-01', title: 'Angle Sum of a Triangle', category: 'Triangles',
    expression: '\\angle A + \\angle B + \\angle C = 180^{\\circ}',
    explanation: 'The interior angles of any triangle add up to 180°.',
    example: 'If two angles are 50° and 60°, the third is 70°.', order: 1, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-02', title: 'Exterior Angle Theorem', category: 'Triangles',
    expression: '\\angle_{\\text{ext}} = \\angle_{\\text{opp int 1}} + \\angle_{\\text{opp int 2}}',
    explanation: 'An exterior angle of a triangle equals the sum of the two opposite interior angles.',
    example: 'If opposite interior angles are 40° and 70°, the exterior angle is 110°.', order: 2, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-03', title: 'Pythagoras Theorem', category: 'Triangles',
    expression: 'a^2 + b^2 = c^2',
    explanation: 'In a right-angled triangle, the square of the hypotenuse equals the sum of the squares of the other two sides.',
    example: '3^2 + 4^2 = 9 + 16 = 25 = 5^2', order: 3, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-04', title: 'Area of Triangle', category: 'Areas',
    expression: 'A = \\frac{1}{2} \\times \\text{base} \\times \\text{height}',
    explanation: 'Area of any triangle is half the product of base and perpendicular height.',
    example: 'base = 10, height = 6 → A = 30', order: 4, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-05', title: 'Heron\'s Formula', category: 'Areas',
    expression: 'A = \\sqrt{s(s-a)(s-b)(s-c)}, \\quad s = \\frac{a+b+c}{2}',
    explanation: 'Area of a triangle from its three sides; $s$ is the semi-perimeter.',
    example: 'For sides 13, 14, 15: s = 21, A = \\sqrt{21 \\cdot 8 \\cdot 7 \\cdot 6} = 84', order: 5, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-06', title: 'Circle: Circumference', category: 'Circles',
    expression: 'C = 2\\pi r = \\pi d',
    explanation: 'Circumference of a circle of radius $r$ (or diameter $d$).',
    example: 'r = 7 → C = 14\\pi \\approx 44', order: 6, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-07', title: 'Circle: Area', category: 'Circles',
    expression: 'A = \\pi r^2',
    explanation: 'Area of a circle of radius $r$.',
    example: 'r = 7 → A = 49\\pi \\approx 154', order: 7, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-08', title: 'Length of an Arc', category: 'Circles',
    expression: '\\ell = \\frac{\\theta}{360^{\\circ}} \\times 2\\pi r',
    explanation: 'Arc length when $\\theta$ is the central angle in degrees.',
    example: 'r = 14, \\theta = 90° → \\ell = \\frac{1}{4}(28\\pi) = 7\\pi', order: 8, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-09', title: 'Sum of Polygon Angles', category: 'Polygons',
    expression: '\\text{Sum} = (n-2) \\times 180^{\\circ}',
    explanation: 'Sum of interior angles of an $n$-sided polygon.',
    example: 'Hexagon (n=6): (6-2) × 180° = 720°', order: 9, createdAt: '2026-07-02',
  },
  {
    id: 'F-GM-10', title: 'Each Interior Angle (Regular)', category: 'Polygons',
    expression: '\\theta = \\frac{(n-2) \\times 180^{\\circ}}{n}',
    explanation: 'Each interior angle of a regular $n$-gon.',
    example: 'Regular pentagon: \\frac{540°}{5} = 108°', order: 10, createdAt: '2026-07-02',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-GM-11 … F-GM-20).
  {
    id: 'F-GM-11', title: 'Complementary Angles', category: 'Angles',
    expression: '\\alpha + \\beta = 90^{\\circ}',
    explanation: 'Two angles are complementary if their sum is 90°.',
    example: '30° and 60° are complementary', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-12', title: 'Supplementary Angles', category: 'Angles',
    expression: '\\alpha + \\beta = 180^{\\circ}',
    explanation: 'Two angles are supplementary if their sum is 180°.',
    example: '70° and 110° are supplementary', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-13', title: 'Angles on a Straight Line', category: 'Angles',
    expression: '\\alpha + \\beta + \\gamma = 180^{\\circ}',
    explanation: 'Angles meeting at a point on a straight line add up to 180°.',
    example: '60° + 70° + 50° = 180°', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-14', title: 'Vertically Opposite Angles', category: 'Angles',
    expression: '\\alpha = \\gamma, \\quad \\beta = \\delta',
    explanation: 'When two lines cross, the opposite (vertical) angles are equal.',
    example: 'If one angle is 50°, the opposite angle is also 50°', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-15', title: 'Corresponding Angles (Parallel Lines)', category: 'Lines',
    expression: '\\angle 1 = \\angle 5, \\quad \\angle 2 = \\angle 6, \\quad \\angle 3 = \\angle 7, \\quad \\angle 4 = \\angle 8',
    explanation: 'When a transversal cuts parallel lines, corresponding (F-shape) angles are equal.',
    example: 'If one corresponding angle is 65°, the other is 65°', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-16', title: 'Alternate Interior Angles (Parallel Lines)', category: 'Lines',
    expression: '\\angle 3 = \\angle 6, \\quad \\angle 4 = \\angle 5',
    explanation: 'Alternate (Z-shape) angles between parallel lines are equal.',
    example: 'If one alternate angle is 40°, the other is 40°', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-17', title: 'Isosceles Triangle — Equal Angles', category: 'Triangles',
    expression: '\\text{Equal sides} \\iff \\text{Equal opposite angles}',
    explanation: 'In an isosceles triangle, the angles opposite the equal sides are equal.',
    example: 'Sides 5, 5, 7 → the two angles opposite the 5 cm sides are equal', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-18', title: 'Equilateral Triangle — All 60°', category: 'Triangles',
    expression: '\\text{All sides equal} \\implies \\text{All angles} = 60^{\\circ}',
    explanation: 'Every equilateral triangle has three 60° angles.',
    example: 'A triangle with sides 6, 6, 6 has angles 60°, 60°, 60°', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-19', title: 'Rectangle — Area & Perimeter', category: 'Quadrilaterals',
    expression: 'A = l \\times w, \\quad P = 2(l+w)',
    explanation: 'Area is length × width; perimeter is twice the sum of length and width.',
    example: 'l=8, w=3: A=24, P=22', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-GM-20', title: 'Sum of Exterior Angles of a Polygon', category: 'Polygons',
    expression: '\\sum \\text{exterior angles} = 360^{\\circ}',
    explanation: 'The exterior angles of any convex polygon (one at each vertex) always add up to 360°.',
    example: 'Square: 4 × 90° = 360°; Pentagon: 5 × 72° = 360°', order: 20, createdAt: '2026-11-02',
  },
]

const theoryGeometry: TheorySection[] = [
  {
    id: 'T-GM-01', title: 'Introduction to Geometry', order: 1, createdAt: '2026-07-02',
    body: `## What is Geometry?

**Geometry** studies the properties of points, lines, angles, surfaces and solids. The word comes from Greek: *geo* (earth) + *metron* (measure).

### Basic Building Blocks
- **Point**: a location, no size. Denoted by a capital letter.
- **Line**: extends forever in two directions; has length but no thickness.
- **Ray**: starts at a point and extends forever in one direction.
- **Line segment**: part of a line with two endpoints.
- **Plane**: a flat surface that extends forever.

> tip
> A point has **0 dimensions**, a line **1 dimension**, a plane **2 dimensions**, and a solid **3 dimensions**.`,
  },
  {
    id: 'T-GM-02', title: 'Angles', order: 2, createdAt: '2026-07-02',
    body: `## What is an Angle?

An **angle** is formed when two rays share a common endpoint (the *vertex*). It is measured in **degrees** (°) or **radians**.

### Types of Angles
| Type | Measure |
|------|---------|
| Acute | $< 90°$ |
| Right | $= 90°$ |
| Obtuse | Between $90°$ and $180°$ |
| Straight | $= 180°$ |
| Reflex | Between $180°$ and $360°$ |
| Full turn | $= 360°$ |

### Angle Pairs
- **Complementary**: two angles summing to $90°$
- **Supplementary**: two angles summing to $180°$
- **Adjacent**: share a common vertex and side, no overlap
- **Vertically opposite**: formed by two intersecting lines — always **equal**

> important
> When two lines intersect, the vertically opposite angles are always equal. This is one of the most-used facts in geometry.`,
  },
  {
    id: 'T-GM-03', title: 'Triangles', order: 3, createdAt: '2026-07-02',
    body: `## What is a Triangle?

A **triangle** is a closed figure with three sides and three angles. It is the simplest polygon.

### Classification by Sides
- **Equilateral**: all three sides equal (and all angles $= 60°$)
- **Isosceles**: two sides equal (and the two opposite angles equal)
- **Scalene**: all three sides different

### Classification by Angles
- **Acute-angled**: all three angles $< 90°$
- **Right-angled**: one angle $= 90°$
- **Obtuse-angled**: one angle $> 90°$

### Fundamental Properties
1. **Angle Sum**: $\\angle A + \\angle B + \\angle C = 180°$
2. **Exterior Angle**: equals sum of two opposite interior angles
3. **Triangle Inequality**: sum of any two sides > third side
4. **Pythagoras** (right triangles only): $a^2 + b^2 = c^2$

> warning
> The Pythagoras theorem applies **only** to right-angled triangles. The hypotenuse $c$ is always the side opposite the right angle and is the longest side.

### Congruence Rules
- **SSS**: three sides equal
- **SAS**: two sides and the included angle equal
- **ASA**: two angles and the included side equal
- **RHS**: right angle + hypotenuse + one side equal`,
  },
  {
    id: 'T-GM-04', title: 'Pythagoras Theorem (Deep Dive)', order: 4, createdAt: '2026-07-02',
    body: `## The Theorem
In a right-angled triangle, the square of the hypotenuse equals the sum of the squares of the other two sides:
$$a^2 + b^2 = c^2$$

### Pythagorean Triples
Integer solutions to $a^2 + b^2 = c^2$:
- $(3, 4, 5)$ and multiples $(6, 8, 10)$, $(9, 12, 15)$
- $(5, 12, 13)$
- $(8, 15, 17)$
- $(7, 24, 25)$

### Converse
If $a^2 + b^2 = c^2$ holds for a triangle, then the triangle is right-angled (with $c$ as the hypotenuse).

### Worked Example
A ladder leans against a wall. The foot is 6 m from the wall and the ladder reaches 8 m up. How long is the ladder?
$$c = \\sqrt{6^2 + 8^2} = \\sqrt{36 + 64} = \\sqrt{100} = 10 \\text{ m}$$

> tip
> Pythagorean triples save time — recognise $(6, 8, 10)$ as a multiple of $(3, 4, 5)$ without computing.`,
  },
  {
    id: 'T-GM-05', title: 'Circles', order: 5, createdAt: '2026-07-02',
    body: `## What is a Circle?

A **circle** is the set of all points in a plane at a fixed distance (the *radius* $r$) from a fixed point (the *centre*).

### Key Terms
- **Radius** ($r$): distance from centre to any point on the circle
- **Diameter** ($d = 2r$): longest chord, passes through the centre
- **Chord**: any segment joining two points on the circle
- **Arc**: a part of the circumference
- **Sector**: region between two radii and an arc
- **Segment**: region between a chord and an arc
- **Tangent**: a line that touches the circle at exactly one point
- **Secant**: a line that intersects the circle at two points

### Key Formulae
- Circumference: $C = 2\\pi r$
- Area: $A = \\pi r^2$
- Arc length: $\\ell = \\frac{\\theta}{360°} \\times 2\\pi r$
- Sector area: $A_{\\text{sector}} = \\frac{\\theta}{360°} \\times \\pi r^2$

> important
> A tangent is always **perpendicular** to the radius at the point of contact. This fact is the key to most circle geometry problems.`,
  },
  {
    id: 'T-GM-06', title: 'Polygons', order: 6, createdAt: '2026-07-02',
    body: `## What is a Polygon?

A **polygon** is a closed plane figure formed by three or more straight line segments.

### Classification
| Sides | Name |
|-------|------|
| 3 | Triangle |
| 4 | Quadrilateral |
| 5 | Pentagon |
| 6 | Hexagon |
| 7 | Heptagon |
| 8 | Octagon |
| 9 | Nonagon |
| 10 | Decagon |

### Angle Sums
- **Sum of interior angles**: $(n-2) \\times 180°$
- **Each interior angle (regular)**: $\\frac{(n-2) \\times 180°}{n}$
- **Sum of exterior angles**: always $360°$ (for any convex polygon)
- **Each exterior angle (regular)**: $\\frac{360°}{n}$

### Types of Quadrilaterals
- **Parallelogram**: opposite sides parallel and equal
- **Rectangle**: parallelogram with right angles
- **Rhombus**: parallelogram with all sides equal
- **Square**: rectangle + rhombus (all sides equal, all angles 90°)
- **Trapezium**: one pair of parallel sides

> tip
> A square is a rectangle, a rhombus, a parallelogram and a quadrilateral — all at once! Each shape is a special case of the next.`,
  },
  {
    id: 'T-GM-07', title: 'Summary & Quick Revision', order: 7, createdAt: '2026-07-02',
    body: `## Quick Revision

> important
> **Triangle angle sum = 180°**, **Pythagoras $a^2+b^2=c^2$** and **circle area $\\pi r^2$** are the three most-tested facts in school geometry.

### Key Formulae Recap
- Triangle angle sum: $180°$
- Pythagoras: $a^2 + b^2 = c^2$ (right triangles only)
- Heron's formula: $A = \\sqrt{s(s-a)(s-b)(s-c)}$
- Circle circumference: $2\\pi r$ ; area: $\\pi r^2$
- Polygon interior sum: $(n-2) \\times 180°$

### Common Mistakes
1. Forgetting that Pythagoras needs a **right angle**.
2. Confusing the *semi-perimeter* $s$ with the *perimeter* in Heron's formula.
3. Using the diameter instead of the radius in $A = \\pi r^2$.

### Practice Notes
- A triangle has sides 7, 24, 25. Is it right-angled?
- Find the area of a triangle with sides 5, 12 and included angle 90°.
- A regular hexagon has side 10. Find the sum of its interior angles and each interior angle.`,
  },
]

// ───────────────────────────── CH004 — Trigonometry ─────────────────────────────

const formulasTrigonometry: Formula[] = [
  {
    id: 'F-TR-01', title: 'Basic Ratios', category: 'Ratios',
    expression: '\\sin\\theta = \\frac{\\text{opp}}{\\text{hyp}},\\ \\cos\\theta = \\frac{\\text{adj}}{\\text{hyp}},\\ \\tan\\theta = \\frac{\\text{opp}}{\\text{adj}}',
    explanation: 'The three basic trigonometric ratios in a right-angled triangle.',
    example: 'For a 3-4-5 triangle: \\sin = 3/5, \\cos = 4/5, \\tan = 3/4', order: 1, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-02', title: 'Reciprocal Ratios', category: 'Ratios',
    expression: '\\csc\\theta = \\frac{1}{\\sin\\theta},\\ \\sec\\theta = \\frac{1}{\\cos\\theta},\\ \\cot\\theta = \\frac{1}{\\tan\\theta}',
    explanation: 'The reciprocal identities.',
    example: '\\sin 30° = 1/2 \\Rightarrow \\csc 30° = 2', order: 2, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-03', title: 'Pythagorean Identity', category: 'Identities',
    expression: '\\sin^2\\theta + \\cos^2\\theta = 1',
    explanation: 'The most fundamental trigonometric identity.',
    example: 'If \\sin\\theta = 3/5 then \\cos\\theta = 4/5 (since 9/25 + 16/25 = 1).', order: 3, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-04', title: 'Other Pythagorean Identities', category: 'Identities',
    expression: '1 + \\tan^2\\theta = \\sec^2\\theta, \\quad 1 + \\cot^2\\theta = \\csc^2\\theta',
    explanation: 'Derived by dividing the main identity by $\\cos^2\\theta$ or $\\sin^2\\theta$.',
    example: 'If \\tan\\theta = 3/4 then \\sec\\theta = 5/4.', order: 4, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-05', title: 'Complementary Angles', category: 'Identities',
    expression: '\\sin(90°-\\theta) = \\cos\\theta,\\ \\cos(90°-\\theta) = \\sin\\theta,\\ \\tan(90°-\\theta) = \\cot\\theta',
    explanation: 'Co-ratio identities for complementary angles.',
    example: '\\sin 30° = \\cos 60° = 1/2', order: 5, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-06', title: 'Standard Angle Values', category: 'Standard Values',
    expression: '\\begin{array}{c|ccccc} \\theta & 0° & 30° & 45° & 60° & 90° \\\\ \\sin & 0 & 1/2 & 1/\\sqrt{2} & \\sqrt{3}/2 & 1 \\\\ \\cos & 1 & \\sqrt{3}/2 & 1/\\sqrt{2} & 1/2 & 0 \\\\ \\tan & 0 & 1/\\sqrt{3} & 1 & \\sqrt{3} & \\text{undef.} \\end{array}',
    explanation: 'The must-memorise standard angle table.',
    example: '\\tan 45° = 1, \\sin 60° = \\sqrt{3}/2', order: 6, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-07', title: 'Sum of Sines', category: 'Compound Angles',
    expression: '\\sin(A+B) = \\sin A \\cos B + \\cos A \\sin B',
    explanation: 'Sine of a sum of two angles.',
    example: '\\sin 75° = \\sin 45° \\cos 30° + \\cos 45° \\sin 30°', order: 7, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-08', title: 'Sum of Cosines', category: 'Compound Angles',
    expression: '\\cos(A+B) = \\cos A \\cos B - \\sin A \\sin B',
    explanation: 'Cosine of a sum of two angles.',
    example: '\\cos(2A) = \\cos^2 A - \\sin^2 A', order: 8, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-09', title: 'Double Angle (Sine)', category: 'Double Angles',
    expression: '\\sin 2\\theta = 2\\sin\\theta \\cos\\theta',
    explanation: 'Sine of twice an angle.',
    example: '\\sin 60° = 2 \\sin 30° \\cos 30° = 2(1/2)(\\sqrt{3}/2) = \\sqrt{3}/2 ✓', order: 9, createdAt: '2026-08-02',
  },
  {
    id: 'F-TR-10', title: 'Double Angle (Cosine)', category: 'Double Angles',
    expression: '\\cos 2\\theta = \\cos^2\\theta - \\sin^2\\theta = 2\\cos^2\\theta - 1 = 1 - 2\\sin^2\\theta',
    explanation: 'Three equivalent forms of the cosine double-angle identity.',
    example: '\\cos 60° = 2(1/2)^2 - 1 = -1/2 ✗ → use 1 - 2(1/2)^2 = 1/2 ✓', order: 10, createdAt: '2026-08-02',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-TR-11 … F-TR-20).
  {
    id: 'F-TR-11', title: 'Tangent in Terms of Sine and Cosine', category: 'Ratios',
    expression: '\\tan\\theta = \\frac{\\sin\\theta}{\\cos\\theta}',
    explanation: 'Tangent is sine divided by cosine (when cosine is not zero).',
    example: 'If sin = 3/5 and cos = 4/5, then tan = 3/4', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-12', title: 'Value of sin 0°', category: 'Standard Values',
    expression: '\\sin 0^{\\circ} = 0',
    explanation: 'The sine of 0 degrees is zero.',
    example: 'sin 0° = 0', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-13', title: 'Value of cos 0°', category: 'Standard Values',
    expression: '\\cos 0^{\\circ} = 1',
    explanation: 'The cosine of 0 degrees is one.',
    example: 'cos 0° = 1', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-14', title: 'Value of sin 90°', category: 'Standard Values',
    expression: '\\sin 90^{\\circ} = 1',
    explanation: 'The sine of 90 degrees (a right angle) is one.',
    example: 'sin 90° = 1', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-15', title: 'Value of cos 90°', category: 'Standard Values',
    expression: '\\cos 90^{\\circ} = 0',
    explanation: 'The cosine of 90 degrees is zero.',
    example: 'cos 90° = 0', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-16', title: 'Value of tan 0°', category: 'Standard Values',
    expression: '\\tan 0^{\\circ} = 0',
    explanation: 'The tangent of 0 degrees is zero.',
    example: 'tan 0° = 0', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-17', title: 'Value of tan 45°', category: 'Standard Values',
    expression: '\\tan 45^{\\circ} = 1',
    explanation: 'The tangent of 45 degrees is one.',
    example: 'tan 45° = 1', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-18', title: 'Value of tan 90° (Undefined)', category: 'Standard Values',
    expression: '\\tan 90^{\\circ} = \\text{undefined}',
    explanation: 'Tangent of 90° is undefined because cos 90° = 0 (division by zero).',
    example: 'tan 90° → undefined', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-19', title: 'Range of Sine', category: 'Properties',
    expression: '-1 \\leq \\sin\\theta \\leq 1',
    explanation: 'The sine of any angle always lies between −1 and 1 (inclusive).',
    example: 'sin 30° = 0.5, sin 270° = −1 — both inside [−1, 1]', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-TR-20', title: 'Range of Cosine', category: 'Properties',
    expression: '-1 \\leq \\cos\\theta \\leq 1',
    explanation: 'The cosine of any angle always lies between −1 and 1 (inclusive).',
    example: 'cos 0° = 1, cos 180° = −1 — both inside [−1, 1]', order: 20, createdAt: '2026-11-02',
  },
]

const theoryTrigonometry: TheorySection[] = [
  {
    id: 'T-TR-01', title: 'Introduction to Trigonometry', order: 1, createdAt: '2026-08-02',
    body: `## What is Trigonometry?

**Trigonometry** (Greek: *trigonon* = triangle + *metron* = measure) studies relationships between the **side lengths** and **angles** of triangles, especially right-angled triangles.

### Where It's Used
- Architecture and engineering
- Navigation and surveying
- Physics (waves, oscillations, optics)
- Computer graphics and game development
- Astronomy

> tip
> Trigonometry turns **geometry into algebra** — angles become numbers (ratios), so we can compute rather than just measure.`,
  },
  {
    id: 'T-TR-02', title: 'The Six Trigonometric Ratios', order: 2, createdAt: '2026-08-02',
    body: `## Right-Angled Triangle Conventions
For an angle $\\theta$ in a right triangle:
- **Hypotenuse** (hyp): the side opposite the right angle (longest)
- **Opposite** (opp): the side opposite to $\\theta$
- **Adjacent** (adj): the side next to $\\theta$ (not the hypotenuse)

## The Six Ratios
| Ratio | Definition | Reciprocal |
|-------|-----------|------------|
| $\\sin\\theta$ | $\\frac{\\text{opp}}{\\text{hyp}}$ | $\\csc\\theta$ |
| $\\cos\\theta$ | $\\frac{\\text{adj}}{\\text{hyp}}$ | $\\sec\\theta$ |
| $\\tan\\theta$ | $\\frac{\\text{opp}}{\\text{adj}}$ | $\\cot\\theta$ |

### Memory Aid — SOH-CAH-TOA
- **S**in = **O**pp / **H**yp
- **C**os = **A**dj / **H**yp
- **T**an = **O**pp / **A**dj

> important
> The ratios depend **only on the angle**, not on the size of the triangle. Two right triangles with the same angles have proportional sides, so their trig ratios are identical.`,
  },
  {
    id: 'T-TR-03', title: 'Standard Angle Values', order: 3, createdAt: '2026-08-02',
    body: `## The Must-Memorise Table

| $\\theta$ | $0°$ | $30°$ | $45°$ | $60°$ | $90°$ |
|----------|------|-------|-------|-------|-------|
| $\\sin$ | $0$ | $\\frac{1}{2}$ | $\\frac{1}{\\sqrt{2}}$ | $\\frac{\\sqrt{3}}{2}$ | $1$ |
| $\\cos$ | $1$ | $\\frac{\\sqrt{3}}{2}$ | $\\frac{1}{\\sqrt{2}}$ | $\\frac{1}{2}$ | $0$ |
| $\\tan$ | $0$ | $\\frac{1}{\\sqrt{3}}$ | $1$ | $\\sqrt{3}$ | undef. |

### How to Remember
- **sin row**: $\\frac{\\sqrt{0}}{2}, \\frac{\\sqrt{1}}{2}, \\frac{\\sqrt{2}}{2}, \\frac{\\sqrt{3}}{2}, \\frac{\\sqrt{4}}{2}$
- **cos row**: reverse of sin
- **tan row**: $\\frac{\\sin}{\\cos}$

> tip
> Write this table from memory **five times** — it appears in nearly every trigonometry question.`,
  },
  {
    id: 'T-TR-04', title: 'Trigonometric Identities', order: 4, createdAt: '2026-08-02',
    body: `## The Pythagorean Identities
$$\\sin^2\\theta + \\cos^2\\theta = 1$$
$$1 + \\tan^2\\theta = \\sec^2\\theta$$
$$1 + \\cot^2\\theta = \\csc^2\\theta$$

### Complementary Angle Identities
$$\\sin(90°-\\theta) = \\cos\\theta, \\quad \\cos(90°-\\theta) = \\sin\\theta$$
$$\\tan(90°-\\theta) = \\cot\\theta, \\quad \\cot(90°-\\theta) = \\tan\\theta$$

### Compound Angle Identities (Class 11)
$$\\sin(A \\pm B) = \\sin A \\cos B \\pm \\cos A \\sin B$$
$$\\cos(A \\pm B) = \\cos A \\cos B \\mp \\sin A \\sin B$$
$$\\tan(A \\pm B) = \\frac{\\tan A \\pm \\tan B}{1 \\mp \\tan A \\tan B}$$

### Double Angle Identities
$$\\sin 2\\theta = 2\\sin\\theta \\cos\\theta$$
$$\\cos 2\\theta = \\cos^2\\theta - \\sin^2\\theta = 2\\cos^2\\theta - 1 = 1 - 2\\sin^2\\theta$$

> important
> $\\sin^2\\theta$ means $(\\sin\\theta)^2$, **not** $\\sin(\\theta^2)$. This is the most common notation error in trigonometry.`,
  },
  {
    id: 'T-TR-05', title: 'Applications of Trigonometry', order: 5, createdAt: '2026-08-02',
    body: `## Heights and Distances

The two classic applications are:
1. **Angle of elevation**: angle above the horizontal when looking up at an object
2. **Angle of depression**: angle below the horizontal when looking down at an object

### Worked Example
A tower stands vertically on the ground. From a point 15 m away, the angle of elevation of the top is $60°$. Find the tower's height.
$$h = 15 \\times \\tan 60° = 15\\sqrt{3} \\approx 25.98 \\text{ m}$$

### General Strategy
1. Draw a clear diagram with the right angle marked.
2. Identify the known side and the known angle.
3. Pick the ratio that uses those two — sin/cos/tan.
4. Solve for the unknown.

> warning
> Make sure your calculator is in **degree mode** (not radians) for school problems. A wrong mode gives completely wrong answers.`,
  },
  {
    id: 'T-TR-06', title: 'Summary & Quick Revision', order: 6, createdAt: '2026-08-02',
    body: `## Quick Revision

> important
> Memorise **SOH-CAH-TOA**, the **standard angle table** and **$\\sin^2\\theta + \\cos^2\\theta = 1$** — these three things cover 80% of school trigonometry.

### Key Formulae Recap
- $\\sin\\theta = \\text{opp}/\\text{hyp}$, $\\cos\\theta = \\text{adj}/\\text{hyp}$, $\\tan\\theta = \\text{opp}/\\text{adj}$
- $\\sin^2\\theta + \\cos^2\\theta = 1$ (and the tan/sec, cot/csc versions)
- Standard angles: $0°, 30°, 45°, 60°, 90°$
- $\\sin 2\\theta = 2\\sin\\theta\\cos\\theta$

### Common Mistakes
1. Mixing up **opposite** and **adjacent** — always mark the right angle first.
2. Forgetting that $\\tan 90°$ is **undefined**.
3. Writing $\\sin^2\\theta$ when you mean $\\sin(\\theta^2)$ or vice versa.

### Practice Notes
- If $\\sin\\theta = 5/13$, find $\\cos\\theta$ and $\\tan\\theta$.
- Show that $\\tan 22° \\tan 68° = 1$ (use complementary angles).
- A kite is flying at 60 m height, string taut, angle of elevation 60°. Find the string length.`,
  },
]

// ───────────────────────────── CH005 — Mensuration ─────────────────────────────

const formulasMensuration: Formula[] = [
  {
    id: 'F-MN-01', title: 'Rectangle — Area', category: 'Areas',
    expression: 'A = l \\times w',
    explanation: 'Area of a rectangle of length $l$ and width $w$.',
    example: 'l = 8, w = 5 → A = 40', order: 1, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-02', title: 'Rectangle — Perimeter', category: 'Perimeters',
    expression: 'P = 2(l + w)',
    explanation: 'Perimeter of a rectangle.',
    example: 'l = 8, w = 5 → P = 26', order: 2, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-03', title: 'Square — Area & Perimeter', category: 'Areas',
    expression: 'A = s^2, \\quad P = 4s',
    explanation: 'Area and perimeter of a square of side $s$.',
    example: 's = 7 → A = 49, P = 28', order: 3, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-04', title: 'Triangle — Area', category: 'Areas',
    expression: 'A = \\frac{1}{2} b h',
    explanation: 'Area of a triangle, base $b$ and perpendicular height $h$.',
    example: 'b = 12, h = 5 → A = 30', order: 4, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-05', title: 'Trapezium — Area', category: 'Areas',
    expression: 'A = \\frac{1}{2}(a + b) h',
    explanation: 'Area of a trapezium with parallel sides $a$ and $b$, height $h$.',
    example: 'a = 6, b = 10, h = 4 → A = 32', order: 5, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-06', title: 'Circle — Area & Circumference', category: 'Areas',
    expression: 'A = \\pi r^2, \\quad C = 2\\pi r',
    explanation: 'Area and circumference of a circle of radius $r$.',
    example: 'r = 14 → A = 196\\pi, C = 28\\pi', order: 6, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-07', title: 'Cube — Volume & Surface Area', category: 'Solids',
    expression: 'V = s^3, \\quad \\text{SA} = 6s^2',
    explanation: 'Volume and total surface area of a cube of side $s$.',
    example: 's = 4 → V = 64, SA = 96', order: 7, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-08', title: 'Cuboid — Volume & Surface Area', category: 'Solids',
    expression: 'V = lwh, \\quad \\text{SA} = 2(lw + lh + wh)',
    explanation: 'Volume and total surface area of a cuboid.',
    example: 'l=4, w=3, h=2 → V = 24, SA = 52', order: 8, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-09', title: 'Cylinder — Volume & Surface Area', category: 'Solids',
    expression: 'V = \\pi r^2 h, \\quad \\text{CSA} = 2\\pi r h, \\quad \\text{TSA} = 2\\pi r(h + r)',
    explanation: 'Volume, curved surface area (CSA) and total surface area (TSA) of a cylinder.',
    example: 'r=7, h=10 → V = 490\\pi, CSA = 140\\pi', order: 9, createdAt: '2026-09-02',
  },
  {
    id: 'F-MN-10', title: 'Cone & Sphere', category: 'Solids',
    expression: 'V_{\\text{cone}} = \\frac{1}{3}\\pi r^2 h, \\quad V_{\\text{sphere}} = \\frac{4}{3}\\pi r^3, \\quad \\text{SA}_{\\text{sphere}} = 4\\pi r^2',
    explanation: 'Volume of a cone and a sphere; surface area of a sphere.',
    example: 'r=3 sphere: V = 36\\pi, SA = 36\\pi', order: 10, createdAt: '2026-09-02',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-MN-11 … F-MN-20).
  {
    id: 'F-MN-11', title: 'Parallelogram — Area', category: 'Areas',
    expression: 'A = b \\times h',
    explanation: 'Area of a parallelogram is base times the perpendicular height.',
    example: 'b=12, h=5: A=60', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-12', title: 'Rhombus — Area (via Diagonals)', category: 'Areas',
    expression: 'A = \\frac{d_1 \\times d_2}{2}',
    explanation: 'Area of a rhombus is half the product of its two diagonals.',
    example: 'd1=6, d2=8: A=24', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-13', title: 'Semi-circle — Area', category: 'Areas',
    expression: 'A = \\frac{1}{2}\\pi r^2',
    explanation: 'The area of a semi-circle is half the area of the full circle.',
    example: 'r=7: A = \\frac{1}{2}×\\frac{22}{7}×49 = 77', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-14', title: 'Equilateral Triangle — Area', category: 'Areas',
    expression: 'A = \\frac{\\sqrt{3}}{4} a^2',
    explanation: 'Area of an equilateral triangle with side a.',
    example: 'a=4: A = \\frac{\\sqrt{3}}{4}×16 = 4\\sqrt{3}', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-15', title: 'Annulus — Area', category: 'Areas',
    expression: 'A = \\pi (R^2 - r^2)',
    explanation: 'The ring-shaped area between two concentric circles of radii R (outer) and r (inner).',
    example: 'R=5, r=3: A = \\pi(25-9) = 16\\pi', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-16', title: 'Cone — Slant Height', category: 'Solids',
    expression: 'l = \\sqrt{r^2 + h^2}',
    explanation: 'The slant height of a right circular cone from its base radius and perpendicular height.',
    example: 'r=3, h=4: l = 5', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-17', title: 'Hemisphere — Volume & Surface Area', category: 'Solids',
    expression: 'V = \\frac{2}{3}\\pi r^3, \\quad SA = 3\\pi r^2',
    explanation: 'Volume is half a sphere; total surface area includes the curved part plus the flat circular face.',
    example: 'r=2: V = \\frac{16}{3}\\pi, SA = 12\\pi', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-18', title: 'Triangle — Perimeter', category: 'Perimeters',
    expression: 'P = a + b + c',
    explanation: 'Perimeter of a triangle is the sum of its three sides.',
    example: 'Sides 3, 4, 5: P = 12', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-19', title: 'Trapezium — Perimeter', category: 'Perimeters',
    expression: 'P = a + b + c + d',
    explanation: 'Perimeter of a trapezium is the sum of its four sides.',
    example: 'Sides 5, 7, 4, 6: P = 22', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-MN-20', title: 'Cuboid — Space Diagonal', category: 'Solids',
    expression: 'd = \\sqrt{l^2 + w^2 + h^2}',
    explanation: 'The diagonal through the inside of a cuboid from its length, width and height.',
    example: 'l=3, w=4, h=12: d = \\sqrt{9+16+144} = 13', order: 20, createdAt: '2026-11-02',
  },
]

const theoryMensuration: TheorySection[] = [
  {
    id: 'T-MN-01', title: 'Introduction to Mensuration', order: 1, createdAt: '2026-09-02',
    body: `## What is Mensuration?

**Mensuration** is the branch of mathematics that deals with the measurement of lengths, areas and volumes of geometrical figures.

### Two Main Categories
- **2D (Plane) figures**: square, rectangle, triangle, circle, trapezium — measured in **length** and **area**
- **3D (Solid) figures**: cube, cuboid, cylinder, cone, sphere — measured in **surface area** and **volume**

> tip
> Always check the **units** before computing. Length is in m/cm, area in m²/cm², volume in m³/cm³. Mixing units is the #1 source of mistakes.

### Units Conversion
| From | To | Multiply by |
|------|----|-------------|
| 1 m² | cm² | 10,000 |
| 1 m³ | cm³ | 1,000,000 |
| 1 litre | cm³ | 1,000 |
| 1 hectare | m² | 10,000 |`,
  },
  {
    id: 'T-MN-02', title: 'Perimeter and Area (2D)', order: 2, createdAt: '2026-09-02',
    body: `## Plane Figures — Quick Reference

### Rectangle
- Perimeter: $P = 2(l+w)$
- Area: $A = l \\times w$
- Diagonal: $d = \\sqrt{l^2 + w^2}$

### Square (special rectangle)
- Perimeter: $P = 4s$
- Area: $A = s^2$
- Diagonal: $d = s\\sqrt{2}$

### Triangle
- Area (base-height): $A = \\frac{1}{2} b h$
- Area (Heron): $A = \\sqrt{s(s-a)(s-b)(s-c)}$, $s = \\frac{a+b+c}{2}$

### Parallelogram
- Area: $A = b \\times h$ (base × perpendicular height)

### Rhombus
- Area: $A = \\frac{1}{2} d_1 d_2$ (half the product of diagonals)

### Trapezium
- Area: $A = \\frac{1}{2}(a+b)h$ (average of parallel sides × height)

### Circle
- Circumference: $C = 2\\pi r$
- Area: $A = \\pi r^2$

> important
> For a triangle, "height" always means the **perpendicular** height from the base to the opposite vertex. Slant heights give wrong answers.`,
  },
  {
    id: 'T-MN-03', title: 'Surface Area and Volume (3D)', order: 3, createdAt: '2026-09-02',
    body: `## Solids — Quick Reference

### Cube
- Volume: $V = s^3$
- Surface area: $\\text{SA} = 6s^2$
- Diagonal: $d = s\\sqrt{3}$

### Cuboid
- Volume: $V = lwh$
- Surface area: $\\text{SA} = 2(lw + lh + wh)$
- Diagonal: $d = \\sqrt{l^2 + w^2 + h^2}$

### Cylinder
- Volume: $V = \\pi r^2 h$
- Curved surface area: $\\text{CSA} = 2\\pi r h$
- Total surface area: $\\text{TSA} = 2\\pi r(h+r)$

### Cone
- Volume: $V = \\frac{1}{3}\\pi r^2 h$
- Slant height: $l = \\sqrt{r^2 + h^2}$
- CSA: $\\pi r l$
- TSA: $\\pi r(l + r)$

### Sphere
- Volume: $V = \\frac{4}{3}\\pi r^3$
- Surface area: $\\text{SA} = 4\\pi r^2$

### Hemisphere
- Volume: $V = \\frac{2}{3}\\pi r^3$
- CSA: $2\\pi r^2$
- TSA: $3\\pi r^2$ (includes the flat circular base)

> tip
> The cone is exactly **one-third** of a cylinder with the same base and height. Remember this and you will never forget the cone formula.`,
  },
  {
    id: 'T-MN-04', title: 'Worked Examples', order: 4, createdAt: '2026-09-02',
    body: `## Example 1 — Painting a Room
A room is 5 m long, 4 m wide and 3 m high. The cost of painting the four walls is ₹10 per m². Find the total cost.

**Step 1:** Area of four walls = $2(l+h)h + 2(w+h)h$ — actually, simpler:
$$\\text{Wall area} = \\text{perimeter} \\times h = 2(5+4) \\times 3 = 54 \\text{ m}^2$$

**Step 2:** Cost = $54 \\times 10 = ₹540$

## Example 2 — Volume of a Cylinder
A cylindrical tank has radius 7 m and height 10 m. Find its capacity in litres.
$$V = \\pi r^2 h = \\frac{22}{7} \\times 49 \\times 10 = 1540 \\text{ m}^3 = 15{,}40{,}000 \\text{ litres}$$

## Example 3 — Surface Area of a Sphere
A sphere has surface area $314 \\text{ cm}^2$. Find its radius (use $\\pi \\approx 3.14$).
$$4\\pi r^2 = 314 \\implies r^2 = 25 \\implies r = 5 \\text{ cm}$$

> warning
> When converting m³ to litres, multiply by 1000 (since 1 m³ = 1000 litres). When converting cm³ to litres, divide by 1000 (since 1 litre = 1000 cm³).`,
  },
  {
    id: 'T-MN-05', title: 'Summary & Quick Revision', order: 5, createdAt: '2026-09-02',
    body: `## Quick Revision

> important
> **Cube**: $s^3$ volume, $6s^2$ surface. **Cylinder**: $\\pi r^2 h$ volume, $2\\pi r h$ curved area. **Sphere**: $\\frac{4}{3}\\pi r^3$ volume, $4\\pi r^2$ surface.

### Key Formulae Recap
| Shape | Volume | Surface Area |
|-------|--------|--------------|
| Cube | $s^3$ | $6s^2$ |
| Cuboid | $lwh$ | $2(lw+lh+wh)$ |
| Cylinder | $\\pi r^2 h$ | $2\\pi r(h+r)$ |
| Cone | $\\frac{1}{3}\\pi r^2 h$ | $\\pi r(l+r)$ |
| Sphere | $\\frac{4}{3}\\pi r^3$ | $4\\pi r^2$ |

### Common Mistakes
1. Using the **diameter** in $\\pi r^2$ instead of the radius.
2. Forgetting that the cone volume is **one-third** of the cylinder.
3. Mixing units (e.g. cm sides with m height).

### Practice Notes
- A cuboid is 10 cm × 8 cm × 5 cm. Find its volume and total surface area.
- A cylindrical pipe has radius 2 cm and length 1 m. Find its volume in cm³.
- A solid sphere of radius 6 cm is melted and recast into a cylinder of radius 4 cm. Find the height of the cylinder.`,
  },
]

// ───────────────────────────── CH006 — Statistics & Probability ─────────────────────────────

const formulasStatistics: Formula[] = [
  {
    id: 'F-ST-01', title: 'Mean (Ungrouped)', category: 'Central Tendency',
    expression: '\\bar{x} = \\frac{\\sum_{i=1}^{n} x_i}{n} = \\frac{x_1 + x_2 + \\cdots + x_n}{n}',
    explanation: 'Arithmetic mean of $n$ values; sum divided by count.',
    example: 'Mean of 4, 7, 10 = 21/3 = 7', order: 1, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-02', title: 'Median (Ungrouped)', category: 'Central Tendency',
    expression: '\\text{Median} = \\begin{cases} x_{\\frac{n+1}{2}} & n \\text{ odd} \\\\ \\frac{x_{n/2} + x_{n/2+1}}{2} & n \\text{ even} \\end{cases}',
    explanation: 'Middle value of an ordered dataset.',
    example: 'Median of 2,5,7,9 = (5+7)/2 = 6', order: 2, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-03', title: 'Mode', category: 'Central Tendency',
    expression: '\\text{Mode} = \\text{most frequent value}',
    explanation: 'The value that appears most often in a dataset.',
    example: 'Mode of 2,3,3,3,5,7 is 3', order: 3, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-04', title: 'Range', category: 'Dispersion',
    expression: '\\text{Range} = x_{\\max} - x_{\\min}',
    explanation: 'The simplest measure of spread.',
    example: 'Range of 5,8,12,20 = 20-5 = 15', order: 4, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-05', title: 'Variance', category: 'Dispersion',
    expression: '\\sigma^2 = \\frac{1}{n}\\sum_{i=1}^{n}(x_i - \\bar{x})^2',
    explanation: 'Mean of squared deviations from the mean.',
    example: 'For 2,4,6,8: \\bar{x}=5, \\sigma^2 = (9+1+1+9)/4 = 5', order: 5, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-06', title: 'Standard Deviation', category: 'Dispersion',
    expression: '\\sigma = \\sqrt{\\frac{1}{n}\\sum_{i=1}^{n}(x_i - \\bar{x})^2}',
    explanation: 'Square root of variance; same units as the data.',
    example: 'For 2,4,6,8: \\sigma = \\sqrt{5} \\approx 2.24', order: 6, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-07', title: 'Probability of an Event', category: 'Probability',
    expression: 'P(E) = \\frac{\\text{number of favourable outcomes}}{\\text{total number of outcomes}}',
    explanation: 'Classical definition of probability; $0 \\le P(E) \\le 1$.',
    example: 'P(head) = 1/2, P(6 on die) = 1/6', order: 7, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-08', title: 'Complementary Event', category: 'Probability',
    expression: 'P(\\overline{E}) = 1 - P(E)',
    explanation: 'The probability that the event does NOT happen.',
    example: 'If P(rain) = 0.3, P(no rain) = 0.7', order: 8, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-09', title: 'Addition Rule (Mutually Exclusive)', category: 'Probability',
    expression: 'P(A \\text{ or } B) = P(A) + P(B)',
    explanation: 'When events A and B cannot happen together.',
    example: 'P(1 or 6 on die) = 1/6 + 1/6 = 1/3', order: 9, createdAt: '2026-10-02',
  },
  {
    id: 'F-ST-10', title: 'General Addition Rule', category: 'Probability',
    expression: 'P(A \\cup B) = P(A) + P(B) - P(A \\cap B)',
    explanation: 'For any two events, subtract the overlap to avoid double counting.',
    example: 'P(A)=0.5, P(B)=0.4, P(A∩B)=0.2 → P(A∪B) = 0.7', order: 10, createdAt: '2026-10-02',
  },
  // v3.28.0 — 10 additional very-easy Class 8–11 formulas (F-ST-11 … F-ST-20).
  {
    id: 'F-ST-11', title: 'Mean of Grouped Data (Direct Method)', category: 'Central Tendency',
    expression: '\\bar{x} = \\frac{\\sum f_i x_i}{\\sum f_i}',
    explanation: 'Mean of grouped data using class marks (x_i) and frequencies (f_i).',
    example: 'If Σfx = 120 and Σf = 20, mean = 6', order: 11, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-12', title: 'Frequency', category: 'Data Handling',
    expression: 'f_i = \\text{number of times value } x_i \\text{ occurs}',
    explanation: 'Frequency counts how many times each value appears in a data set.',
    example: 'In 2, 3, 3, 4, 4, 4 — the frequency of 4 is 3', order: 12, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-13', title: 'Cumulative Frequency', category: 'Data Handling',
    expression: 'cf_i = f_1 + f_2 + \\cdots + f_i',
    explanation: 'Running total of frequencies up to and including each class.',
    example: 'f = 5, 3, 2 → cf = 5, 8, 10', order: 13, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-14', title: 'Class Interval Width', category: 'Data Handling',
    expression: '\\text{Width} = \\text{Upper limit} - \\text{Lower limit}',
    explanation: 'The size of each class interval in grouped data.',
    example: 'Class 10–20 has width 10', order: 14, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-15', title: 'Empirical Probability', category: 'Probability',
    expression: 'P(E) = \\frac{\\text{Number of trials where } E \\text{ happened}}{\\text{Total number of trials}}',
    explanation: 'Probability based on observed data over many trials.',
    example: 'Coin flipped 100 times, 48 heads: P(heads) ≈ 0.48', order: 15, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-16', title: 'Sure Event', category: 'Probability',
    expression: 'P(\\text{Sure event}) = 1',
    explanation: 'An event that always happens has probability 1.',
    example: 'Rolling a number from 1 to 6 on a standard die: P = 1', order: 16, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-17', title: 'Impossible Event', category: 'Probability',
    expression: 'P(\\text{Impossible event}) = 0',
    explanation: 'An event that can never happen has probability 0.',
    example: 'Rolling a 7 on a standard die: P = 0', order: 17, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-18', title: 'Sample Space', category: 'Probability',
    expression: 'S = \\{\\text{all possible outcomes}\\}',
    explanation: 'The set of all possible outcomes of a random experiment.',
    example: 'Rolling a die: S = {1, 2, 3, 4, 5, 6}', order: 18, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-19', title: 'Theoretical Probability', category: 'Probability',
    expression: 'P(E) = \\frac{\\text{Number of favourable outcomes}}{\\text{Total number of possible outcomes}}',
    explanation: 'Probability when all outcomes are equally likely.',
    example: 'Drawing a king from 52 cards: P = 4/52 = 1/13', order: 19, createdAt: '2026-11-02',
  },
  {
    id: 'F-ST-20', title: 'Range of Probability', category: 'Probability',
    expression: '0 \\leq P(E) \\leq 1',
    explanation: 'Every probability lies between 0 (impossible) and 1 (certain).',
    example: 'A probability of −0.2 or 1.5 is not valid', order: 20, createdAt: '2026-11-02',
  },
]

const theoryStatistics: TheorySection[] = [
  {
    id: 'T-ST-01', title: 'Introduction to Statistics', order: 1, createdAt: '2026-10-02',
    body: `## What is Statistics?

**Statistics** is the science of collecting, organising, presenting, analysing and interpreting numerical data.

### The Five Stages of a Statistical Study
1. **Collection** — surveys, experiments, censuses
2. **Organisation** — tallying, tabulation
3. **Presentation** — tables, charts, graphs
4. **Analysis** — mean, median, mode, variance
5. **Interpretation** — drawing conclusions

> tip
> A statistic is a number computed from a **sample**; a parameter is a number that describes a whole **population**. School problems usually deal with samples.

### Types of Data
- **Ungrouped**: a list of raw values (e.g. 4, 7, 8, 12, 9)
- **Grouped**: values binned into class intervals (e.g. 0–10, 10–20, ...)`,
  },
  {
    id: 'T-ST-02', title: 'Measures of Central Tendency', order: 2, createdAt: '2026-10-02',
    body: `## Mean
The **arithmetic mean** is the sum of all values divided by the count:
$$\\bar{x} = \\frac{x_1 + x_2 + \\cdots + x_n}{n}$$

### Median
The **median** is the middle value when data is sorted.
- Odd $n$: the single middle value
- Even $n$: the average of the two middle values

### Mode
The **mode** is the value that occurs most often. A dataset may have one mode, more than one mode, or no mode at all.

### Which to Use?
- **Mean**: best for symmetric data without outliers
- **Median**: best for skewed data or data with outliers (e.g. incomes)
- **Mode**: best for categorical data (e.g. shoe sizes, colours)

> important
> The mean is sensitive to **outliers**. The median is not. A single billionaire in a small group can make the mean very misleading, while the median stays representative of "the typical person".

### Worked Example
Data: 3, 5, 7, 8, 8, 10, 12
- Mean = $53/7 \\approx 7.57$
- Median = 8 (4th value)
- Mode = 8 (occurs twice)`,
  },
  {
    id: 'T-ST-03', title: 'Measures of Dispersion', order: 3, createdAt: '2026-10-02',
    body: `## Range
The simplest measure of spread:
$$\\text{Range} = x_{\\max} - x_{\\min}$$

## Variance
The **average squared deviation** from the mean:
$$\\sigma^2 = \\frac{1}{n}\\sum_{i=1}^{n}(x_i - \\bar{x})^2$$

## Standard Deviation
The square root of variance — back in the original units:
$$\\sigma = \\sqrt{\\sigma^2}$$

### Why Square the Deviations?
Squaring does two things:
1. Makes all deviations positive (so they don't cancel out)
2. Penalises large deviations more heavily than small ones

> tip
> A **smaller standard deviation** means the data points are clustered tightly around the mean. A larger one means they are spread out.

### Worked Example
Data: 2, 4, 6, 8
- Mean $\\bar{x} = 5$
- Deviations: $-3, -1, 1, 3$
- Squared deviations: $9, 1, 1, 9$
- Variance $\\sigma^2 = 20/4 = 5$
- Standard deviation $\\sigma = \\sqrt{5} \\approx 2.24$`,
  },
  {
    id: 'T-ST-04', title: 'Data Presentation', order: 4, createdAt: '2026-10-02',
    body: `## Common Graphs

### Bar Graph
Used for categorical data. Each category gets a bar; bar height = frequency.

### Histogram
Like a bar graph but for **grouped continuous data**. Bars touch each other because there is no gap between class intervals.

### Frequency Polygon
Plot the frequency at the midpoint of each class interval, then connect the points with straight lines.

### Pie Chart
A circle divided into sectors. Each sector's angle = $\\frac{\\text{category value}}{\\text{total}} \\times 360°$.

### Worked Example — Pie Chart
A student spends a day as: Sleep 8h, School 6h, Study 4h, Play 3h, Other 3h (total 24h). The angle for "Study" is:
$$\\frac{4}{24} \\times 360° = 60°$$

> warning
> Pie charts are only meaningful when the categories together make up a **whole** (i.e. they sum to 100% or 360°). Don't use a pie chart for unrelated quantities.`,
  },
  {
    id: 'T-ST-05', title: 'Introduction to Probability', order: 5, createdAt: '2026-10-02',
    body: `## What is Probability?

**Probability** is the measure of how likely an event is to occur. It is always between 0 (impossible) and 1 (certain).

### Classical Definition
$$P(E) = \\frac{\\text{number of favourable outcomes}}{\\text{total number of possible outcomes}}$$

### Key Terms
- **Experiment**: an action with uncertain results (e.g. tossing a coin)
- **Sample space** ($S$): the set of all possible outcomes
- **Event** ($E$): a subset of the sample space

### Examples
- Tossing a coin: $S = \\{\\text{H, T}\\}$, $P(\\text{H}) = 1/2$
- Rolling a die: $S = \\{1,2,3,4,5,6\\}$, $P(\\text{even}) = 3/6 = 1/2$
- Drawing a card: 52 cards, $P(\\text{ace}) = 4/52 = 1/13$

> important
> Probability 0 means **impossible**. Probability 1 means **certain**. Probabilities are always between 0 and 1 inclusive — never negative, never more than 1.`,
  },
  {
    id: 'T-ST-06', title: 'Probability Rules', order: 6, createdAt: '2026-10-02',
    body: `## Complementary Events
$$P(\\overline{E}) = 1 - P(E)$$
If the probability of rain is 0.3, the probability of no rain is 0.7.

## Addition Rule (Mutually Exclusive)
If A and B **cannot** happen at the same time:
$$P(A \\text{ or } B) = P(A) + P(B)$$

## General Addition Rule
For **any** two events:
$$P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$$
The intersection term prevents double-counting outcomes that satisfy both events.

## Multiplication Rule (Independent Events)
If A and B are **independent** (one does not affect the other):
$$P(A \\text{ and } B) = P(A) \\times P(B)$$

### Worked Example
A bag has 4 red and 6 blue balls. Two balls are drawn **with replacement**. Find the probability that both are red.
- $P(\\text{red}) = 4/10 = 2/5$
- With replacement → independent → $P(\\text{both red}) = (2/5) \\times (2/5) = 4/25$

> tip
> "With replacement" means the second draw is independent. "Without replacement" means it is dependent — you must adjust the probability for the second draw.`,
  },
  {
    id: 'T-ST-07', title: 'Summary & Quick Revision', order: 7, createdAt: '2026-10-02',
    body: `## Quick Revision

> important
> **Mean = sum ÷ count**, **Median = middle value**, **Mode = most frequent**, **Probability = favourable ÷ total**.

### Key Formulae Recap
- Mean: $\\bar{x} = \\frac{\\sum x_i}{n}$
- Variance: $\\sigma^2 = \\frac{1}{n}\\sum(x_i - \\bar{x})^2$
- Std deviation: $\\sigma = \\sqrt{\\sigma^2}$
- Probability: $P(E) = \\frac{\\text{favourable}}{\\text{total}}$
- Complement: $P(\\overline{E}) = 1 - P(E)$
- Addition: $P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$

### Common Mistakes
1. Forgetting to **sort** the data before finding the median.
2. Confusing $P(A \\cap B)$ with $P(A) \\times P(B)$ — the latter only holds for independent events.
3. Reporting a probability greater than 1 or less than 0 — always wrong.

### Practice Notes
- Find the mean, median and mode of 12, 15, 11, 14, 13, 14, 15, 14.
- The probabilities of three mutually exclusive events A, B, C are 0.2, 0.3, 0.4. Find P(A or B or C).
- Two dice are rolled. Find the probability that the sum is 7.`,
  },
]

// ───────────────────────────── Exported seed maps ─────────────────────────────

export const SEED_FORMULAS: Record<string, Formula[]> = {
  CH001: formulasNumberSystem,
  CH002: formulasAlgebra,
  CH003: formulasGeometry,
  CH004: formulasTrigonometry,
  CH005: formulasMensuration,
  CH006: formulasStatistics,
}

export const SEED_THEORIES: Record<string, TheorySection[]> = {
  CH001: theoryNumberSystem,
  CH002: theoryAlgebra,
  CH003: theoryGeometry,
  CH004: theoryTrigonometry,
  CH005: theoryMensuration,
  CH006: theoryStatistics,
}
