/**
 * v3.36.0 — Portal-wide accent (primary) color theming.
 *
 * The "Accent color" picker in Settings → Appearance was previously cosmetic
 * only (it updated a local useState + showed a toast, but never persisted or
 * applied the choice). This module makes it functional:
 *
 *   • `ACCENT_THEMES` maps each accent name → the OKLCH CSS-variable overrides
 *     for BOTH light and dark mode. We override the variables that every
 *     `bg-primary` / `text-primary` / `ring` / `btn-premium-primary` /
 *     sidebar-active / chart-1 / success element reads from, so the whole
 *     portal recolors at once.
 *   • `applyAccentTheme(name)` injects (or updates) a single `<style id="pm-accent-theme">`
 *     element with `:root{…}` and `.dark{…}` rule blocks. Called on app mount
 *     + whenever `settings.themeAccent` changes.
 *   • `ACCENT_SWATCHES` is the display list (name + tailwind classes) the
 *     Settings picker renders.
 *
 * OKLCH values are tuned to keep WCAG AA contrast against `--primary-foreground`
 * (near-white in light mode, near-black in dark mode) for each hue.
 */

export interface AccentTheme {
  /** Canonical key stored in `settings.themeAccent`. */
  name: string
  /** Human label shown in the Settings picker. */
  label: string
  /** Tailwind bg class for the swatch button. */
  swatch: string
  /** Tailwind ring class for the active swatch. */
  ring: string
  /** CSS-variable overrides applied under `:root` (light mode). */
  light: Record<string, string>
  /** CSS-variable overrides applied under `.dark` (dark mode). */
  dark: Record<string, string>
}

/**
 * The set of CSS variables we override for each accent. These are the
 * variables that `bg-primary`, `text-primary`, `ring`, `border-primary`,
 * `btn-premium-primary`, the sidebar active item, chart-1 and success states
 * all resolve through, so recoloring them recolors the whole portal.
 */
const VARS = [
  '--primary',
  '--primary-foreground',
  '--ring',
  '--sidebar-primary',
  '--sidebar-primary-foreground',
  '--sidebar-ring',
  '--sidebar-accent',
  '--sidebar-accent-foreground',
  '--accent',
  '--accent-foreground',
  '--chart-1',
  '--success',
] as const

function build(
  light: [number, number, number, number, number, number],
  dark: [number, number, number, number, number, number]
): { light: Record<string, string>; dark: Record<string, string> } {
  // light = [L primary, C primary, H primary, L accent-bg, C accent, H accent]
  // dark  = same slots for dark mode
  const [lp, cp, hp, la, ca, ha] = light
  const [dp, cpd, hp2, da, cad, ha2] = dark
  const lightVars: Record<string, string> = {
    '--primary': `oklch(${lp} ${cp} ${hp})`,
    '--primary-foreground': `oklch(0.99 0.01 ${hp})`,
    '--ring': `oklch(${lp} ${cp} ${hp})`,
    '--sidebar-primary': `oklch(${lp} ${cp} ${hp})`,
    '--sidebar-primary-foreground': `oklch(0.99 0.01 ${hp})`,
    '--sidebar-ring': `oklch(${lp} ${cp} ${hp})`,
    '--sidebar-accent': `oklch(${la} ${ca} ${ha})`,
    '--sidebar-accent-foreground': `oklch(0.35 0.08 ${ha})`,
    '--accent': `oklch(${la} ${ca} ${ha})`,
    '--accent-foreground': `oklch(0.35 0.08 ${ha})`,
    '--chart-1': `oklch(${lp} ${cp} ${hp})`,
    '--success': `oklch(${lp} ${cp} ${hp})`,
  }
  const darkVars: Record<string, string> = {
    '--primary': `oklch(${dp} ${cpd} ${hp2})`,
    '--primary-foreground': `oklch(0.16 0.02 ${hp2})`,
    '--ring': `oklch(${dp} ${cpd} ${hp2})`,
    '--sidebar-primary': `oklch(${dp} ${cpd} ${hp2})`,
    '--sidebar-primary-foreground': `oklch(0.99 0.01 ${hp2})`,
    '--sidebar-ring': `oklch(${dp} ${cpd} ${hp2})`,
    '--sidebar-accent': `oklch(${da} ${cad} ${ha2})`,
    '--sidebar-accent-foreground': `oklch(0.9 0.04 ${ha2})`,
    '--accent': `oklch(${da} ${cad} ${ha2})`,
    '--accent-foreground': `oklch(0.9 0.04 ${ha2})`,
    '--chart-1': `oklch(${dp} ${cpd} ${hp2})`,
    '--success': `oklch(${dp} ${cpd} ${hp2})`,
  }
  return { light: lightVars, dark: darkVars }
}

export const ACCENT_THEMES: Record<string, AccentTheme> = {
  emerald: {
    name: 'emerald',
    label: 'Emerald',
    swatch: 'bg-emerald-500',
    ring: 'ring-emerald-500',
    // Matches the globals.css :root baseline so default looks identical.
    ...build([0.62, 0.13, 160, 0.95, 0.02, 165], [0.7, 0.15, 162, 0.3, 0.06, 162]),
  },
  teal: {
    name: 'teal',
    label: 'Teal',
    swatch: 'bg-teal-500',
    ring: 'ring-teal-500',
    ...build([0.6, 0.11, 180, 0.95, 0.025, 182], [0.68, 0.12, 182, 0.3, 0.06, 182]),
  },
  green: {
    name: 'green',
    label: 'Green',
    swatch: 'bg-green-500',
    ring: 'ring-green-500',
    ...build([0.58, 0.13, 145, 0.95, 0.025, 145], [0.66, 0.15, 145, 0.3, 0.06, 145]),
  },
  amber: {
    name: 'amber',
    label: 'Amber',
    swatch: 'bg-amber-500',
    ring: 'ring-amber-500',
    // Amber is a warm hue — use a slightly darker L for primary so white
    // foreground text stays legible (AA contrast).
    ...build([0.55, 0.14, 65, 0.95, 0.03, 70], [0.7, 0.15, 70, 0.32, 0.06, 70]),
  },
  violet: {
    name: 'violet',
    label: 'Violet',
    swatch: 'bg-violet-500',
    ring: 'ring-violet-500',
    ...build([0.55, 0.16, 295, 0.95, 0.03, 295], [0.65, 0.16, 295, 0.32, 0.07, 295]),
  },
}

/** Display list for the Settings picker (stable order). */
export const ACCENT_SWATCHES: AccentTheme[] = [
  ACCENT_THEMES.emerald,
  ACCENT_THEMES.teal,
  ACCENT_THEMES.green,
  ACCENT_THEMES.amber,
  ACCENT_THEMES.violet,
]

const STYLE_ID = 'pm-accent-theme'

/**
 * Inject (or update) a `<style id="pm-accent-theme">` element that overrides
 * the primary CSS variables for both light (`:root`) and dark (`.dark`) modes.
 * Safe to call repeatedly — it reuses the same style node. No-op on the server
 * and when the name is unknown (falls back to the globals.css defaults).
 */
export function applyAccentTheme(name: string | undefined): void {
  if (typeof document === 'undefined') return
  const theme = ACCENT_THEMES[name || 'emerald'] || ACCENT_THEMES.emerald

  const lightRules = VARS.map((v) => `${v}: ${theme.light[v]};`).join(' ')
  const darkRules = VARS.map((v) => `${v}: ${theme.dark[v]};`).join(' ')
  const css = `:root{${lightRules}}.dark{${darkRules}}`

  let el = document.getElementById(STYLE_ID) as HTMLStyleElement | null
  if (!el) {
    el = document.createElement('style')
    el.id = STYLE_ID
    el.setAttribute('data-pm-accent', theme.name)
    document.head.appendChild(el)
  }
  if (el.getAttribute('data-pm-accent') !== theme.name || el.textContent !== css) {
    el.setAttribute('data-pm-accent', theme.name)
    el.textContent = css
  }
}

/** Resolve a stored accent name to its display label (defensive). */
export function accentLabel(name: string | undefined): string {
  return (ACCENT_THEMES[name || 'emerald'] || ACCENT_THEMES.emerald).label
}
