/**
 * v3.53.6 — Question Bank Import parser.
 *
 * Parses plain-text questions (extracted from .docx / .pdf / .txt files)
 * into the QuestionForm shape used by the admin Question Bank.
 *
 * ── Supported question format ──
 *
 *   Q: What is the value of 2 + 3?
 *   A) 4
 *   B) 5
 *   C) 6
 *   D) 7
 *   Correct: B
 *   Solution: 2 + 3 = 5.
 *
 *   <blank line separates questions>
 *
 * Rules:
 *   • `Q:` starts a new question (text after it is the question text)
 *   • `A)`, `B)`, `C)`, `D)` (or lowercase `a)`, `b)`, `c)`, `d)`) are options
 *   • `Correct:` — letter of the correct answer (A/B/C/D)
 *   • `Solution:` (or `Explanation:`) — solution/explanation text (may span
 *     multiple lines until the next recognized key)
 *   • `Marks:` — optional integer marks (if omitted, the Import dialog's
 *     default Marks value is used)
 *   • `Difficulty:` — optional: very-easy / easy / medium / hard
 *   • `Type:` — optional: mcq / numerical / true-false
 *   • Blank line separates questions
 *
 * v3.53.8 changes:
 *   • `Solution:` is now the preferred key (replaces `Explanation:`).
 *     Both are still recognized for backward compatibility.
 *   • `Marks:`, `Difficulty:`, `Type:` are now OPTIONAL — the admin sets
 *     defaults in the Import dialog popup instead of putting them in the
 *     file. If the file does specify them, the file's values take priority.
 */

import type { QuestionLevel } from '@/lib/data-store'

export interface ParsedQuestion {
  text: string
  options: string[]
  correctAnswer: number // index 0-3, -1 if not specified
  explanation: string
  /** Optional — if not in the file, the dialog's default is used. */
  marks?: number
  /** Optional — if not in the file, the dialog's default is used. */
  difficulty?: QuestionLevel
  /** Optional — if not in the file, the dialog's default is used. */
  type?: 'mcq' | 'numerical' | 'true-false'
  /**Parsing warning — set when the question is incomplete/malformed.
   * The admin can still see it in the preview and edit it before import. */
  warning?: string
}

/** Convert a letter (A/B/C/D or a/b/c/d) to an index (0-3).
 * Returns -1 if the letter is not a valid option letter. */
function letterToIndex(letter: string): number {
  const upper = letter.trim().toUpperCase()
  const code = upper.charCodeAt(0)
  if (code >= 65 && code <= 90) return code - 65 // A=0, B=1, ...
  return -1
}

/** Normalize a difficulty/level string to the canonical QuestionLevel union.
 * v3.54.0 — accepts the new "Level 1"…"Level 12" format (case-insensitive,
 * with or without the word "Level", with or without hyphen/space). Also
 * accepts the old "very-easy"/"easy"/"medium"/"hard" for backward compat:
 *   very-easy → level-1, easy → level-4, medium → level-7, hard → level-11
 * Falls back to level-6 (the middle of the 1-12 range). */
function normalizeDifficulty(raw: string): QuestionLevel {
  const d = raw.trim().toLowerCase().replace(/[\s_-]+/g, '-')
  // Old format → new mapping
  if (d.startsWith('very')) return 'level-1'
  if (d.startsWith('easy')) return 'level-4'
  if (d.startsWith('med')) return 'level-7'
  if (d.startsWith('hard')) return 'level-11'
  // New format: "level-N", "levelN", "LN", or just "N" (1-12)
  const m = d.match(/level?[-]?(\d{1,2})/) || d.match(/^l?(\d{1,2})$/)
  if (m) {
    const n = parseInt(m[1], 10)
    if (n >= 1 && n <= 12) return `level-${n}` as QuestionLevel
  }
  return 'level-6'
}

/** Normalize a type string to the canonical union. */
function normalizeType(raw: string): ParsedQuestion['type'] {
  const t = raw.trim().toLowerCase().replace(/[\s_-]+/g, '-')
  if (t.startsWith('num')) return 'numerical'
  if (t.startsWith('tf') || t === 'true-false' || t === 'truefalse' || t.startsWith('true')) return 'true-false'
  return 'mcq'
}

/** Regex matching an option line: "A) text", "a) text", "A. text", "a. text" */
const OPTION_RE = /^([A-Da-d])\s*[)\.]\s*(.*)$/

/** Key prefixes we recognize on a line (case-insensitive). */
const KEY_Q = /^q\s*[:.)]\s*/i
const KEY_CORRECT = /^correct\s*[:.)]\s*/i
// v3.53.8 — "Solution:" is the preferred key; "Explanation:" still works.
const KEY_SOL = /^(solution|explanation)\s*[:.)]\s*/i
const KEY_MARKS = /^marks\s*[:.)]\s*/i
// v3.54.0 — accept both "Level:" and "Difficulty:" as the key
const KEY_DIFF = /^(difficulty|level)\s*[:.)]\s*/i
const KEY_TYPE = /^type\s*[:.)]\s*/i

/**
 * Parse a block of plain text into an array of questions.
 *
 * The algorithm:
 *   1. Split text into lines.
 *   2. Walk through lines. When we hit `Q:` (and we're already building a
 *      question), push the current one and start a new one.
 *   3. Within a question, classify each line: option / correct / explanation
 *      / marks / difficulty / type / continuation of the previous field.
 *   4. At EOF, push the last question.
 *   5. Post-process: validate each question, set warnings for incomplete ones.
 */
export function parseQuestions(rawText: string): ParsedQuestion[] {
  const text = rawText.replace(/\r\n/g, '\n').replace(/\r/g, '\n')
  const lines = text.split('\n')

  const questions: ParsedQuestion[] = []
  let current: ParsedQuestion | null = null
  /** Tracks which multi-line field we're appending to, so continuation
   * lines (e.g. a wrapped explanation) get appended to the right field. */
  let appendMode: 'none' | 'explanation' | 'question' = 'none'

  const pushCurrent = () => {
    if (!current) return
    // Trim trailing whitespace on all text fields
    current.text = current.text.trim()
    current.explanation = current.explanation.trim()
    current.options = current.options.map((o) => o.trim())
    questions.push(current)
    current = null
    appendMode = 'none'
  }

  for (const line of lines) {
    const trimmed = line.trim()

    // Blank line handling:
    // - For explanation continuation mode, preserve the blank line as part
    //   of the explanation (mammoth/pdf often produce \n\n between paragraphs,
    //   and we don't want to cut the explanation short).
    // - For question text continuation, a blank line ends the question text
    //   continuation (so the question text doesn't accidentally swallow
    //   stray lines).
    if (trimmed === '') {
      if (appendMode === 'explanation' && current) {
        // Preserve the blank line in the explanation (it's part of the
        // multi-line working the user typed).
        current.explanation += '\n'
      } else {
        appendMode = 'none'
      }
      continue
    }

    // ── Q: starts a new question ──
    if (KEY_Q.test(trimmed)) {
      if (current) pushCurrent()
      // v3.53.8 — marks/difficulty/type start undefined; the Import
      // dialog's default values fill them in if the file doesn't specify.
      current = {
        text: trimmed.replace(KEY_Q, ''),
        options: [],
        correctAnswer: -1,
        explanation: '',
      }
      appendMode = 'question'
      continue
    }

    // If we haven't started a question yet, skip stray lines
    if (!current) continue

    // ── Correct: ──
    if (KEY_CORRECT.test(trimmed)) {
      const val = trimmed.replace(KEY_CORRECT, '').trim()
      // Accept "B", "B)", "Option B", etc. — grab the first letter A-D.
      const m = val.match(/([A-Da-d])/)
      current.correctAnswer = m ? letterToIndex(m[1]) : -1
      appendMode = 'none'
      continue
    }

    // ── Solution: (or Explanation:) ──
    if (KEY_SOL.test(trimmed)) {
      current.explanation = trimmed.replace(KEY_SOL, '')
      appendMode = 'explanation'
      continue
    }

    // ── Marks: ──
    if (KEY_MARKS.test(trimmed)) {
      const val = trimmed.replace(KEY_MARKS, '').trim()
      const n = parseInt(val, 10)
      if (!Number.isNaN(n) && n > 0) current.marks = n
      appendMode = 'none'
      continue
    }

    // ── Difficulty: ──
    if (KEY_DIFF.test(trimmed)) {
      current.difficulty = normalizeDifficulty(trimmed.replace(KEY_DIFF, ''))
      appendMode = 'none'
      continue
    }

    // ── Type: ──
    if (KEY_TYPE.test(trimmed)) {
      current.type = normalizeType(trimmed.replace(KEY_TYPE, ''))
      appendMode = 'none'
      continue
    }

    // ── Option line: A) / B) / C) / D) ──
    const optMatch = trimmed.match(OPTION_RE)
    if (optMatch) {
      const idx = letterToIndex(optMatch[1])
      if (idx >= 0 && idx <= 3) {
        // Ensure options array has enough slots
        while (current.options.length < idx) current.options.push('')
        current.options[idx] = optMatch[2]
        appendMode = 'none'
        continue
      }
    }

    // ── Continuation line: append to whichever field was active ──
    if (appendMode === 'explanation') {
      // v3.53.6 fix — preserve newlines in explanations so multi-line
      // step-by-step working (e.g. "Ones: ...\nTens: ...\nHundreds: ...")
      // displays nicely in the post-exam review instead of one run-on line.
      current.explanation += (current.explanation ? '\n' : '') + trimmed
    } else if (appendMode === 'question') {
      // Question text stays joined with spaces (a wrapped question is a
      // single sentence, not a multi-line block).
      current.text += ' ' + trimmed
    }
    // Otherwise the line is ignored (unrecognized)
  }

  // Push the last pending question
  pushCurrent()

  // ── Validation pass: set warnings for incomplete questions ──
  // v3.53.8 — type/marks/difficulty are now optional (dialog provides
  // defaults). We only warn about structural issues (missing text, missing
  // options for MCQ, missing correct answer). The dialog's default type
  // is used for the type-dependent validation below.
  for (const q of questions) {
    const warnings: string[] = []
    if (!q.text) warnings.push('missing question text')
    // Use the question's type if specified, else assume mcq (the dialog
    // default) for validation purposes.
    const effectiveType = q.type ?? 'mcq'
    if (effectiveType === 'mcq') {
      // MCQ should have at least 2 options
      const nonEmpty = q.options.filter((o) => o.trim() !== '')
      if (nonEmpty.length < 2) warnings.push('MCQ needs at least 2 options')
      if (q.correctAnswer < 0 || q.correctAnswer >= q.options.length || q.options[q.correctAnswer] === '') {
        warnings.push('correct answer not specified or out of range')
      }
    } else if (effectiveType === 'true-false') {
      // For true-false, auto-set options if missing
      if (q.options.length < 2) q.options = ['True', 'False']
      if (q.correctAnswer < 0) warnings.push('correct answer not specified (use A for True, B for False)')
    } else if (effectiveType === 'numerical') {
      // Numerical questions don't need options; correctAnswer is unused
      q.options = []
    }
    q.warning = warnings.length > 0 ? warnings.join('; ') : undefined
  }

  return questions
}

/**
 * Extract plain text from a .docx file using mammoth.
 * Runs entirely in the browser — the file never leaves the user's machine.
 *
 * v3.53.6 fix — mammoth depends on Node.js `fs`/`path` built-ins, so
 * `import('mammoth')` fails in the browser. We ship mammoth's pre-built
 * browser bundle (public/vendor/mammoth.browser.min.js) and load it via
 * a <script> tag, which assigns `window.mammoth`. The loader is cached
 * so subsequent imports reuse the same script.
 */
let mammothPromise: Promise<unknown> | null = null

function loadMammoth(): Promise<unknown> {
  if (mammothPromise) return mammothPromise
  mammothPromise = new Promise((resolve, reject) => {
    // Already loaded?
    if (typeof window !== 'undefined' && (window as Record<string, unknown>).mammoth) {
      resolve((window as Record<string, unknown>).mammoth)
      return
    }
    const script = document.createElement('script')
    script.src = '/vendor/mammoth.browser.min.js'
    script.async = true
    script.onload = () => {
      const m = (window as Record<string, unknown>).mammoth
      if (m) resolve(m)
      else reject(new Error('mammoth failed to initialize'))
    }
    script.onerror = () => reject(new Error('Failed to load mammoth browser bundle'))
    document.head.appendChild(script)
  })
  return mammothPromise
}

export async function extractTextFromDocx(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer()
  const mammoth = await loadMammoth() as { extractRawText: (opts: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string }> }
  const result = await mammoth.extractRawText({ arrayBuffer })
  return result.value
}

/**
 * Extract plain text from a .pdf file using pdf-parse.
 * Runs entirely in the browser.
 *
 * v3.53.9 fix — pdf-parse v2.x exports a NAMED CLASS `PDFParse`, not a
 * default function. The old code tried `mod.default || mod` which was
 * undefined → "pdfParse is not a function" error.
 *
 * Also sets the pdf.js worker source via `PDFParse.setWorker()` —
 * without this, pdfjs-dist throws:
 *   "No GlobalWorkerOptions.workerSrc specified."
 *
 * The worker file is served from /vendor/pdf.worker.min.mjs (copied
 * from pdfjs-dist/legacy/build/pdf.worker.min.mjs to public/vendor/).
 */
let pdfWorkerConfigured = false

export async function extractTextFromPdf(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer()
  const uint8 = new Uint8Array(arrayBuffer)
  const mod = await import('pdf-parse') as {
    PDFParse: {
      new (opts: { data: Uint8Array }): {
        getText: () => Promise<{ text: string }>
        destroy: () => Promise<void>
      }
      setWorker: (src: string) => void
    }
  }
  // Configure the pdf.js worker once (idempotent — safe to call every time)
  if (!pdfWorkerConfigured) {
    try {
      mod.PDFParse.setWorker('/vendor/pdf.worker.min.mjs')
    } catch {
      // If setWorker fails, pdfjs-dist may fall back to a fake worker
    }
    pdfWorkerConfigured = true
  }
  const parser = new mod.PDFParse({ data: uint8 })
  try {
    const result = await parser.getText()
    return result.text
  } finally {
    await parser.destroy()
  }
}

/**
 * Extract plain text from a .txt file (native, no library).
 */
export async function extractTextFromTxt(file: File): Promise<string> {
  return await file.text()
}

/**
 * Dispatcher: pick the right extractor based on the file extension.
 */
export async function extractTextFromFile(file: File): Promise<string> {
  const name = file.name.toLowerCase()
  if (name.endsWith('.docx')) return extractTextFromDocx(file)
  if (name.endsWith('.pdf')) return extractTextFromPdf(file)
  if (name.endsWith('.txt')) return extractTextFromTxt(file)
  throw new Error(`Unsupported file type: ${file.name}. Please use .docx, .pdf, or .txt`)
}
