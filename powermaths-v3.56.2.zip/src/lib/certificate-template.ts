/**
 * Certificate template helpers (v3.29.0).
 *
 * The admin edits the certificate template from Settings → Certificates.
 * This module is the single source of truth used by:
 *   • `CertificateArtwork` (the on-screen React component in
 *     student-certificates.tsx AND the Settings live-preview)
 *   • `printCertificate` (the standalone-HTML print window)
 *
 * Keeping the helpers here means changing the template shape in one place
 * updates every consumer.
 */

import type { Certificate, CertificateTemplate } from '@/lib/data-store'
import { defaultSettings } from '@/lib/data-store'

// ─────────────────────────── Helpers ───────────────────────────

/**
 * Resolve the active certificate template. Falls back to the default if the
 * store hasn't hydrated yet (e.g. during SSR or first paint).
 */
export function resolveTemplate(
  t: CertificateTemplate | undefined | null,
): CertificateTemplate {
  return t ?? defaultSettings.certificateTemplate
}

/**
 * Score-tier label based on the template's thresholds.
 */
export function scoreTier(
  score: number,
  t: CertificateTemplate,
): { label: 'Distinction' | 'Merit' | 'Passed'; kind: 'distinction' | 'merit' | 'passed' } {
  if (score >= t.distinctionThreshold) return { label: 'Distinction', kind: 'distinction' }
  if (score >= t.meritThreshold) return { label: 'Merit', kind: 'merit' }
  return { label: 'Passed', kind: 'passed' }
}

/**
 * Map a few well-known tailwind color names to hex values for the print
 * window (which is a standalone HTML doc without Tailwind). Hex / rgb
 * strings are returned as-is.
 */
const TAILWIND_HEX: Record<string, string> = {
  emerald: '#059669',
  'emerald-50': '#ecfdf5',
  'emerald-100': '#d1fae5',
  'emerald-600': '#059669',
  'emerald-700': '#047857',
  'emerald-800': '#065f46',
  teal: '#0d9488',
  'teal-700': '#0f766e',
  amber: '#d97706',
  'amber-400': '#fbbf24',
  'amber-500': '#f59e0b',
  'amber-600': '#d97706',
  'amber-50': '#fffbeb',
  'amber-100': '#fef3c7',
  rose: '#e11d48',
  violet: '#7c3aed',
  zinc: '#71717a',
  white: '#ffffff',
  black: '#000000',
  gray: '#6b7280',
  'gray-800': '#1f2937',
}

export function toHex(color: string): string {
  if (!color) return '#000000'
  const c = color.trim()
  if (c.startsWith('#') || c.startsWith('rgb') || c.startsWith('hsl')) return c
  return TAILWIND_HEX[c.toLowerCase()] ?? c
}

/** Build a CSS `linear-gradient(135deg, ...)` string from the template. */
export function bgGradient(t: CertificateTemplate): string {
  return `linear-gradient(135deg, ${toHex(t.backgroundFrom)} 0%, ${toHex(t.backgroundVia)} 50%, ${toHex(t.backgroundTo)} 100%)`
}

/** Brand-mark gradient (primary → a darker shade of primary). */
export function brandGradient(t: CertificateTemplate): string {
  return `linear-gradient(135deg, ${toHex(t.primaryColor)}, ${toHex(t.primaryColor)})`
}

/** Gold seal gradient (always amber family for the "official" look). */
export function sealGradient(t: CertificateTemplate): string {
  return `linear-gradient(135deg, ${toHex(t.accentColor)}, ${toHex(t.accentColor)})`
}

/** Convert a hex color to an `rgba(hex, alpha)` string. */
export function withAlpha(color: string, alpha: number): string {
  const hex = toHex(color)
  if (hex.startsWith('#') && hex.length === 7) {
    const r = parseInt(hex.slice(1, 3), 16)
    const g = parseInt(hex.slice(3, 5), 16)
    const b = parseInt(hex.slice(5, 7), 16)
    return `rgba(${r}, ${g}, ${b}, ${alpha})`
  }
  return hex
}

// ─────────────────────────── HTML print template ───────────────────────────
//
// A pure-string builder that emits a complete standalone HTML document for
// the print/download window. Driven entirely by the template — what the
// admin sees in the Settings preview is what prints.

export interface PrintCertContext {
  cert: Certificate
  template: CertificateTemplate
}

export function buildCertificateHtml({ cert, template: t }: PrintCertContext): string {
  const tier = scoreTier(cert.score, t)
  const scoreBg =
    tier.kind === 'distinction'
      ? withAlpha(t.accentColor, 0.15)
      : tier.kind === 'merit'
      ? withAlpha(t.primaryColor, 0.15)
      : 'rgba(13, 148, 136, 0.15)'

  // v3.31 — Official Power Maths logo. The print window is a blank document,
  // so we need an absolute URL. Resolve from window.location.origin when
  // running client-side; fall back to a relative path for SSR / tests.
  // v3.35 — use the transparent-background PNG so there's no white "patch"
  // around the logo on the certificate's colored gradient.
  const logoUrl =
    typeof window !== 'undefined' && window.location
      ? `${window.location.origin}/branding/power-maths-logo-transparent.png`
      : '/branding/power-maths-logo-transparent.png'
  const scoreFg =
    tier.kind === 'distinction'
      ? t.accentColor
      : tier.kind === 'merit'
      ? t.primaryColor
      : '#0f766e'

  // Layout-driven border classes
  const showOuter = t.layout !== 'minimal'
  const showInner = t.layout === 'classic'
  const showCorners = t.layout === 'classic' && t.showCornerFlourishes

  const titleFontEsc = t.titleFont.replace(/'/g, "\\'")
  const bodyFontEsc = t.bodyFont.replace(/'/g, "\\'")
  const googleFonts = encodeURIComponent(`${titleFontEsc}:ital,wght@0,600;0,700;1,600|${bodyFontEsc}:wght@400;500;600;700`)

  // v3.46.0 — Level / Batch Completion Certificate branch.
  const isLevelCert = cert.certificateType === 'level'
  const levelChapters = isLevelCert ? (cert.chapterNames ?? []) : []
  // Title and subtitle are overridden for level certs so the scope is explicit.
  const displayTitle = isLevelCert ? 'Level Completion Certificate' : t.title
  const displaySubtitle = isLevelCert ? 'Successful completion of an entire learning level' : t.subtitle

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escapeHtml(displayTitle)} — ${escapeHtml(cert.studentName)} — ${escapeHtml(cert.chapterName)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=${googleFonts}&display=swap" rel="stylesheet">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body {
    font-family: '${bodyFontEsc}', system-ui, sans-serif;
    color: ${toHex(t.textColor)};
    background: #fff;
    display: flex; align-items: center; justify-content: center;
    min-height: 100vh; padding: 24px;
  }
  .cert {
    width: 100%; max-width: 800px; aspect-ratio: 1.414 / 1;
    position: relative;
    background: ${bgGradient(t)};
    border-radius: 8px; overflow: hidden;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    color: ${toHex(t.textColor)};
  }
  ${showOuter ? `.border-outer { position: absolute; inset: 10px; border: 2.5px solid ${withAlpha(t.borderOuterColor, 0.6)}; border-radius: 8px; }` : ''}
  ${showInner ? `.border-inner { position: absolute; inset: 16px; border: 1px solid ${withAlpha(t.borderInnerColor, 0.5)}; border-radius: 4px; }` : ''}
  ${showCorners ? `
  .corner { position: absolute; width: 28px; height: 28px; border-color: ${withAlpha(t.borderOuterColor, 0.7)}; }
  .corner.tl { left: 12px; top: 12px; border-left: 2.5px solid; border-top: 2.5px solid; border-top-left-radius: 8px; }
  .corner.tr { right: 12px; top: 12px; border-right: 2.5px solid; border-top: 2.5px solid; border-top-right-radius: 8px; }
  .corner.bl { left: 12px; bottom: 12px; border-left: 2.5px solid; border-bottom: 2.5px solid; border-bottom-left-radius: 8px; }
  .corner.br { right: 12px; bottom: 12px; border-right: 2.5px solid; border-bottom: 2.5px solid; border-bottom-right-radius: 8px; }
  ` : ''}
  ${t.showWatermark ? `.watermark { position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); font-size: 200px; line-height: 1; opacity: 0.05; pointer-events: none; user-select: none; }` : ''}
  .content { position: relative; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 40px 56px; text-align: center; }
  .brand { display: flex; align-items: center; gap: 14px; }
  .brand-mark { width: 80px; height: 80px; border-radius: 9999px; display: flex; align-items: center; justify-content: center; overflow: hidden; }
  .brand-mark img { width: 100%; height: 100%; object-fit: contain; }
  .brand-name { font-size: 18px; font-weight: 700; color: ${toHex(t.primaryColor)}; line-height: 1.1; letter-spacing: 0.02em; }
  .brand-sub { font-size: 11px; text-transform: uppercase; letter-spacing: 0.18em; color: #6b7280; margin-top: 2px; }
  .divider { margin: 10px 0; display: flex; align-items: center; gap: 8px; }
  .divider .line { height: 1px; width: 48px; background: linear-gradient(to right, transparent, ${withAlpha(t.accentColor, 0.5)}); }
  .divider .line.r { background: linear-gradient(to left, transparent, ${withAlpha(t.accentColor, 0.5)}); }
  .divider .star { color: ${toHex(t.accentColor)}; font-size: 12px; }
  .title { font-family: '${titleFontEsc}', serif; font-size: 26px; font-weight: 700; color: ${toHex(t.textColor)}; letter-spacing: -0.01em; }
  .subtitle { margin-top: 4px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.2em; color: #6b7280; }
  .name { margin-top: 10px; font-family: '${titleFontEsc}', serif; font-size: 30px; font-weight: 600; font-style: italic; color: ${toHex(t.nameColor)}; }
  .underline { margin-top: 4px; height: 1px; width: 140px; background: linear-gradient(to right, transparent, ${withAlpha(t.primaryColor, 0.5)}, transparent); }
  .detail { margin-top: 12px; font-size: 12px; color: #6b7280; }
  .chapter { font-size: 15px; font-weight: 600; color: ${toHex(t.textColor)}; }
  .exam { font-size: 11px; color: #6b7280; }
  ${t.showScoreBadge ? `.score-badge { margin-top: 12px; display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 9999px; font-size: 11px; font-weight: 700; background: ${scoreBg}; color: ${scoreFg}; }` : ''}
  /* v3.46.0 — Level cert chapter list grid */
  .chapters { margin-top: 14px; display: grid; grid-template-columns: 1fr 1fr; gap: 4px 24px; max-width: 540px; width: 100%; text-align: left; }
  .chapters .row { display: flex; align-items: baseline; gap: 8px; font-size: 11px; color: ${toHex(t.textColor)}; }
  .chapters .row .n { font-family: monospace; font-size: 9px; color: ${toHex(t.accentColor)}; min-width: 14px; }
  .chapters .row .nm { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .chapters .more { grid-column: 1 / -1; text-align: center; font-size: 10px; font-style: italic; color: #6b7280; margin-top: 2px; }
  .level-name { font-size: 17px; font-weight: 700; color: ${toHex(t.primaryColor)}; margin-top: 4px; }
  .footer { position: absolute; bottom: 28px; left: 56px; right: 56px; display: flex; align-items: flex-end; justify-content: space-between; }
  .footer .label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: #6b7280; }
  .footer .value { font-size: 12px; font-weight: 500; color: ${toHex(t.textColor)}; margin-top: 2px; }
  .footer .sig { font-family: '${titleFontEsc}', serif; font-size: 14px; font-style: italic; }
  .footer .line-below { margin-top: 2px; height: 1px; background: rgba(24,24,27,0.3); }
  .seal { position: relative; width: 64px; height: 64px; display: flex; align-items: center; justify-content: center; }
  .seal .ring-dashed { position: absolute; inset: 0; transform: rotate(12deg); border: 2px dashed ${withAlpha(t.accentColor, 0.5)}; border-radius: 9999px; }
  .seal .ring-solid { position: absolute; inset: 6px; border: 1px solid ${withAlpha(t.accentColor, 0.3)}; border-radius: 9999px; }
  .seal .body { width: 48px; height: 48px; border-radius: 9999px; background: ${sealGradient(t)}; color: #fff; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 8px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; box-shadow: 0 4px 6px rgba(0,0,0,0.15); }
  .seal .body .emoji { font-size: 14px; line-height: 1; margin-bottom: 1px; }
  ${t.showSerial ? `.serial { position: absolute; bottom: 10px; left: 0; right: 0; text-align: center; font-size: 8px; text-transform: uppercase; letter-spacing: 0.15em; color: rgba(107,114,128,0.7); }` : ''}
  ${t.showQrCode ? `.qr { position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%); width: 40px; height: 40px; background: repeating-conic-gradient(${toHex(t.textColor)} 0% 25%, transparent 0% 50%); background-size: 8px 8px; border: 2px solid ${toHex(t.textColor)}; border-radius: 4px; }` : ''}
  @media print {
    body { padding: 0; background: #fff; }
    .cert { box-shadow: none; border-radius: 0; max-width: 100%; width: 100%; }
  }
</style>
</head>
<body>
  <div class="cert">
    ${showOuter ? '<div class="border-outer"></div>' : ''}
    ${showInner ? '<div class="border-inner"></div>' : ''}
    ${showCorners ? '<div class="corner tl"></div><div class="corner tr"></div><div class="corner bl"></div><div class="corner br"></div>' : ''}
    ${t.showWatermark ? '<div class="watermark">🎓</div>' : ''}
    <div class="content">
      <div class="brand">
        <div class="brand-mark"><img src="${logoUrl}" alt="Power Maths" /></div>
        <div style="text-align:left;">
          <div class="brand-name">${escapeHtml(t.brandName)}</div>
          <div class="brand-sub">${escapeHtml(t.brandSub)}</div>
        </div>
      </div>
      <div class="divider">
        <div class="line"></div>
        <span class="star">★</span>
        <div class="line r"></div>
      </div>
      <div class="title">${escapeHtml(displayTitle)}</div>
      <div class="subtitle">${escapeHtml(displaySubtitle)}</div>
      <div class="name">${escapeHtml(cert.studentName)}</div>
      <div class="underline"></div>
      ${isLevelCert
        ? `<div class="detail">has successfully completed</div>
           <div class="level-name">${escapeHtml(cert.levelName ?? cert.chapterName)}</div>
           ${levelChapters.length > 0 ? `<div class="chapters">
             ${levelChapters.slice(0, 8).map((name, i) => `<div class="row"><span class="n">${String(i + 1).padStart(2, '0')}</span><span class="nm">${escapeHtml(name)}</span></div>`).join('')}
             ${levelChapters.length > 8 ? `<div class="more">+ ${levelChapters.length - 8} more chapters</div>` : ''}
           </div>` : ''}`
        : `<div class="detail">${escapeHtml(t.completionLine)} the</div>
           <div class="chapter">${escapeHtml(cert.chapterName)}</div>
           <div class="exam">chapter examination · ${escapeHtml(cert.examTitle)}</div>
           ${t.showScoreBadge ? `<div class="score-badge">${tier.label} with ${cert.score}%</div>` : ''}`
      }
      <div class="footer">
        ${t.showDate ? `<div>
          <div class="label">Date issued</div>
          <div class="value">${escapeHtml(cert.issuedAt)}</div>
          <div class="line-below" style="width:80px;"></div>
        </div>` : '<div></div>'}
        <div class="seal">
          <div class="ring-dashed"></div>
          <div class="ring-solid"></div>
          <div class="body"><span class="emoji">${escapeHtml(t.sealEmoji)}</span>${escapeHtml(t.sealText)}</div>
        </div>
        <div style="text-align:right;">
          <div class="label">${escapeHtml(t.instructorTitle)}</div>
          <div class="value sig">${escapeHtml(t.instructorName)}</div>
          <div class="line-below" style="width:96px; margin-left:auto;"></div>
        </div>
      </div>
      ${t.showQrCode ? '<div class="qr"></div>' : ''}
      ${t.showSerial ? `<div class="serial">Serial · ${escapeHtml(cert.certificateNumber)}</div>` : ''}
    </div>
  </div>
  <script>
    window.onload = function() { window.print(); setTimeout(function(){ window.close(); }, 500); };
  </script>
</body>
</html>`
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}
