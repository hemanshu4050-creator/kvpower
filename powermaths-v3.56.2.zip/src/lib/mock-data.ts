// ============================================================
// Power Maths — Mock data layer
// Realistic content for a premium math education SaaS portal
// ============================================================

export interface Student {
  id: string
  name: string
  email: string
  phone: string
  batch: string
  status: 'active' | 'inactive' | 'suspended'
  enrolledAt: string
  lastLogin: string | null
  progress: number
  examsCompleted: number
  avgScore: number
  certificates: number
  avatarColor: string
}

export interface Chapter {
  id: string
  name: string
  description: string
  order: number
  status: 'active' | 'draft'
  studyMaterials: number
  practiceSheets: number
  tests: number
  enrolledStudents: number
  avgCompletion: number
  icon: string
}

export interface Question {
  id: string
  chapterId: string
  type: 'mcq' | 'numerical' | 'true-false'
  // v3.54.0 — 12 levels (was 4 difficulty tiers)
  difficulty: 'level-1' | 'level-2' | 'level-3' | 'level-4' | 'level-5' | 'level-6' | 'level-7' | 'level-8' | 'level-9' | 'level-10' | 'level-11' | 'level-12'
  text: string
  marks: number
  usageCount: number
  successRate: number
}

export interface Exam {
  id: string
  title: string
  chapterId: string
  chapterName: string
  marks: number
  duration: number
  passingPercentage: number
  questions: number
  attempts: number
  avgScore: number
  status: 'published' | 'draft'
  createdAt: string
}

export interface Result {
  id: string
  studentId: string
  studentName: string
  examId: string
  examTitle: string
  score: number
  totalMarks: number
  percentage: number
  status: 'passed' | 'failed'
  date: string
  duration: number
}

export interface Certificate {
  id: string
  studentId: string
  studentName: string
  chapterName: string
  examTitle: string
  score: number
  issuedAt: string
  status: 'issued' | 'revoked'
}

export interface ActivityLog {
  id: string
  user: string
  role: 'admin' | 'student'
  action: string
  target: string
  time: string
  type: 'create' | 'update' | 'delete' | 'login' | 'submit' | 'system'
}

export interface Announcement {
  id: string
  title: string
  body: string
  audience: 'all' | 'students' | 'admins'
  priority: 'low' | 'normal' | 'high'
  status: 'active' | 'archived'
  createdAt: string
  author: string
}

export interface Note {
  id: string
  title: string
  content: string
  chapter: string
  color: string
  updatedAt: string
}

export interface Message {
  id: string
  from: string
  to: string
  subject: string
  preview: string
  time: string
  read: boolean
  direction: 'in' | 'out'
}

// ───────────────────────── Students ─────────────────────────
export const students: Student[] = [
  { id: 'STU1024', name: 'Aarav Sharma', email: 'aarav.sharma@student.com', phone: '+91 98200 11223', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 09:24', progress: 78, examsCompleted: 12, avgScore: 84, certificates: 4, avatarColor: 'emerald' },
  { id: 'STU1025', name: 'Diya Patel', email: 'diya.patel@student.com', phone: '+91 98200 44556', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 08:10', progress: 92, examsCompleted: 15, avgScore: 91, certificates: 6, avatarColor: 'rose' },
  { id: 'STU1026', name: 'Vivaan Gupta', email: 'vivaan.gupta@student.com', phone: '+91 98200 77889', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-18 18:42', progress: 64, examsCompleted: 9, avgScore: 72, certificates: 3, avatarColor: 'amber' },
  { id: 'STU1027', name: 'Ananya Iyer', email: 'ananya.iyer@student.com', phone: '+91 98200 33221', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-19 07:55', progress: 88, examsCompleted: 14, avgScore: 89, certificates: 5, avatarColor: 'violet' },
  { id: 'STU1028', name: 'Arjun Reddy', email: 'arjun.reddy@student.com', phone: '+91 98200 99887', batch: 'Batch 2026-A', status: 'inactive', enrolledAt: '2026-06-12', lastLogin: '2026-06-20 14:30', progress: 41, examsCompleted: 6, avgScore: 58, certificates: 1, avatarColor: 'sky' },
  { id: 'STU1029', name: 'Ishita Verma', email: 'ishita.verma@student.com', phone: '+91 98200 55443', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-19 10:02', progress: 95, examsCompleted: 16, avgScore: 94, certificates: 7, avatarColor: 'teal' },
  { id: 'STU1030', name: 'Kabir Singh', email: 'kabir.singh@student.com', phone: '+91 98200 22110', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-17 20:15', progress: 56, examsCompleted: 8, avgScore: 68, certificates: 2, avatarColor: 'orange' },
  { id: 'STU1031', name: 'Saanvi Nair', email: 'saanvi.nair@student.com', phone: '+91 98200 66778', batch: 'Batch 2026-B', status: 'suspended', enrolledAt: '2026-07-03', lastLogin: '2026-05-05 11:20', progress: 33, examsCompleted: 4, avgScore: 49, certificates: 0, avatarColor: 'fuchsia' },
  { id: 'STU1032', name: 'Reyansh Joshi', email: 'reyansh.joshi@student.com', phone: '+91 98200 88990', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 06:48', progress: 81, examsCompleted: 13, avgScore: 86, certificates: 5, avatarColor: 'cyan' },
  { id: 'STU1033', name: 'Myra Desai', email: 'myra.desai@student.com', phone: '+91 98200 11009', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-18 22:10', progress: 73, examsCompleted: 11, avgScore: 79, certificates: 4, avatarColor: 'lime' },
  { id: 'STU1034', name: 'Aditya Mehta', email: 'aditya.mehta@student.com', phone: '+91 98200 43210', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-19 05:30', progress: 69, examsCompleted: 10, avgScore: 75, certificates: 3, avatarColor: 'indigo' },
  { id: 'STU1035', name: 'Kiara Kapoor', email: 'kiara.kapoor@student.com', phone: '+91 98200 87654', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 09:15', progress: 90, examsCompleted: 15, avgScore: 92, certificates: 6, avatarColor: 'pink' },
]

// ───────────────────────── Chapters ─────────────────────────
export const chapters: Chapter[] = [
  { id: 'CH001', name: 'Number System', description: 'Understanding different types of numbers — natural, whole, integers, rationals and irrationals.', order: 1, status: 'active', studyMaterials: 4, practiceSheets: 3, tests: 2, enrolledStudents: 48, avgCompletion: 86, icon: 'Hash' },
  { id: 'CH002', name: 'Algebra Basics', description: 'Variables, expressions, linear equations and foundational algebraic manipulation.', order: 2, status: 'active', studyMaterials: 5, practiceSheets: 4, tests: 3, enrolledStudents: 45, avgCompletion: 74, icon: 'Sigma' },
  { id: 'CH003', name: 'Geometry', description: 'Lines, angles, triangles, circles and the properties of 2D shapes.', order: 3, status: 'active', studyMaterials: 6, practiceSheets: 4, tests: 2, enrolledStudents: 41, avgCompletion: 68, icon: 'Triangle' },
  { id: 'CH004', name: 'Trigonometry', description: 'Ratios, identities and solving right-angled triangles.', order: 4, status: 'active', studyMaterials: 4, practiceSheets: 5, tests: 3, enrolledStudents: 38, avgCompletion: 61, icon: 'Compass' },
  { id: 'CH005', name: 'Mensuration', description: 'Perimeter, area and volume of 2D and 3D figures.', order: 5, status: 'active', studyMaterials: 3, practiceSheets: 3, tests: 2, enrolledStudents: 36, avgCompletion: 55, icon: 'Box' },
  { id: 'CH006', name: 'Statistics & Probability', description: 'Data handling, central tendency and basic probability theory.', order: 6, status: 'draft', studyMaterials: 4, practiceSheets: 2, tests: 2, enrolledStudents: 12, avgCompletion: 22, icon: 'BarChart3' },
]

// ───────────────────────── Questions ─────────────────────────
export const questions: Question[] = [
  { id: 'Q001', chapterId: 'CH001', type: 'mcq', difficulty: 'level-4', text: 'Which of the following is an irrational number?', marks: 2, usageCount: 124, successRate: 88 },
  { id: 'Q002', chapterId: 'CH001', type: 'numerical', difficulty: 'level-7', text: 'Find the LCM of 12 and 18.', marks: 3, usageCount: 98, successRate: 76 },
  { id: 'Q003', chapterId: 'CH002', type: 'mcq', difficulty: 'level-7', text: 'Solve for x: 3x + 7 = 22', marks: 2, usageCount: 156, successRate: 82 },
  { id: 'Q004', chapterId: 'CH002', type: 'numerical', difficulty: 'level-11', text: 'If 2x² - 8 = 0, find the positive value of x.', marks: 4, usageCount: 87, successRate: 54 },
  { id: 'Q005', chapterId: 'CH003', type: 'true-false', difficulty: 'level-4', text: 'The sum of angles in a triangle is 180°.', marks: 1, usageCount: 210, successRate: 96 },
  { id: 'Q006', chapterId: 'CH003', type: 'mcq', difficulty: 'level-7', text: 'The circumference of a circle with radius 7 is (π = 22/7):', marks: 2, usageCount: 132, successRate: 71 },
  { id: 'Q007', chapterId: 'CH004', type: 'numerical', difficulty: 'level-11', text: 'Evaluate sin30° + cos60°.', marks: 3, usageCount: 95, successRate: 63 },
  { id: 'Q008', chapterId: 'CH004', type: 'mcq', difficulty: 'level-7', text: 'tan45° equals:', marks: 1, usageCount: 178, successRate: 91 },
  { id: 'Q009', chapterId: 'CH005', type: 'numerical', difficulty: 'level-7', text: 'Find the volume of a cube with side 5 cm.', marks: 3, usageCount: 104, successRate: 79 },
  { id: 'Q010', chapterId: 'CH006', type: 'mcq', difficulty: 'level-4', text: 'The mean of 2, 4, 6, 8, 10 is:', marks: 2, usageCount: 142, successRate: 93 },
]

// ───────────────────────── Exams ─────────────────────────
export const exams: Exam[] = [
  { id: 'EX001', title: 'Number System — Chapter Test', chapterId: 'CH001', chapterName: 'Number System', marks: 20, duration: 30, passingPercentage: 50, questions: 10, attempts: 48, avgScore: 78, status: 'published', createdAt: '2026-09-12' },
  { id: 'EX002', title: 'Algebra — Mid Chapter Test', chapterId: 'CH002', chapterName: 'Algebra Basics', marks: 25, duration: 40, passingPercentage: 50, questions: 12, attempts: 45, avgScore: 72, status: 'published', createdAt: '2026-10-04' },
  { id: 'EX003', title: 'Algebra — Final Test', chapterId: 'CH002', chapterName: 'Algebra Basics', marks: 40, duration: 60, passingPercentage: 60, questions: 18, attempts: 42, avgScore: 68, status: 'published', createdAt: '2026-10-22' },
  { id: 'EX004', title: 'Geometry — Chapter Test', chapterId: 'CH003', chapterName: 'Geometry', marks: 30, duration: 45, passingPercentage: 50, questions: 15, attempts: 41, avgScore: 65, status: 'published', createdAt: '2026-11-08' },
  { id: 'EX005', title: 'Trigonometry — Quiz 1', chapterId: 'CH004', chapterName: 'Trigonometry', marks: 15, duration: 20, passingPercentage: 50, questions: 8, attempts: 38, avgScore: 61, status: 'published', createdAt: '2026-11-28' },
  { id: 'EX006', title: 'Trigonometry — Chapter Test', chapterId: 'CH004', chapterName: 'Trigonometry', marks: 35, duration: 50, passingPercentage: 55, questions: 16, attempts: 0, avgScore: 0, status: 'draft', createdAt: '2026-07-10' },
  { id: 'EX007', title: 'Mensuration — Chapter Test', chapterId: 'CH005', chapterName: 'Mensuration', marks: 30, duration: 45, passingPercentage: 50, questions: 14, attempts: 36, avgScore: 70, status: 'published', createdAt: '2026-12-15' },
]

// ───────────────────────── Results ─────────────────────────
export const results: Result[] = [
  { id: 'R001', studentId: 'STU1024', studentName: 'Aarav Sharma', examId: 'EX001', examTitle: 'Number System — Chapter Test', score: 17, totalMarks: 20, percentage: 85, status: 'passed', date: '2026-09-14', duration: 26 },
  { id: 'R002', studentId: 'STU1025', studentName: 'Diya Patel', examId: 'EX001', examTitle: 'Number System — Chapter Test', score: 19, totalMarks: 20, percentage: 95, status: 'passed', date: '2026-09-14', duration: 22 },
  { id: 'R003', studentId: 'STU1026', studentName: 'Vivaan Gupta', examId: 'EX002', examTitle: 'Algebra — Mid Chapter Test', score: 14, totalMarks: 25, percentage: 56, status: 'passed', date: '2026-10-06', duration: 38 },
  { id: 'R004', studentId: 'STU1027', studentName: 'Ananya Iyer', examId: 'EX003', examTitle: 'Algebra — Final Test', score: 35, totalMarks: 40, percentage: 88, status: 'passed', date: '2026-10-24', duration: 55 },
  { id: 'R005', studentId: 'STU1028', studentName: 'Arjun Reddy', examId: 'EX004', examTitle: 'Geometry — Chapter Test', score: 11, totalMarks: 30, percentage: 37, status: 'failed', date: '2026-11-10', duration: 44 },
  { id: 'R006', studentId: 'STU1029', studentName: 'Ishita Verma', examId: 'EX004', examTitle: 'Geometry — Chapter Test', score: 28, totalMarks: 30, percentage: 93, status: 'passed', date: '2026-11-10', duration: 39 },
  { id: 'R007', studentId: 'STU1032', studentName: 'Reyansh Joshi', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', score: 13, totalMarks: 15, percentage: 87, status: 'passed', date: '2026-11-30', duration: 18 },
  { id: 'R008', studentId: 'STU1024', studentName: 'Aarav Sharma', examId: 'EX003', examTitle: 'Algebra — Final Test', score: 33, totalMarks: 40, percentage: 83, status: 'passed', date: '2026-10-24', duration: 58 },
  { id: 'R009', studentId: 'STU1035', studentName: 'Kiara Kapoor', examId: 'EX007', examTitle: 'Mensuration — Chapter Test', score: 27, totalMarks: 30, percentage: 90, status: 'passed', date: '2026-12-17', duration: 41 },
  { id: 'R010', studentId: 'STU1030', studentName: 'Kabir Singh', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', score: 7, totalMarks: 15, percentage: 47, status: 'failed', date: '2026-11-30', duration: 20 },
  { id: 'R011', studentId: 'STU1029', studentName: 'Ishita Verma', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', score: 14, totalMarks: 15, percentage: 93, status: 'passed', date: '2026-11-30', duration: 16 },
  { id: 'R012', studentId: 'STU1025', studentName: 'Diya Patel', examId: 'EX003', examTitle: 'Algebra — Final Test', score: 38, totalMarks: 40, percentage: 95, status: 'passed', date: '2026-10-24', duration: 52 },
]

// ───────────────────────── Certificates ─────────────────────────
export const certificates: Certificate[] = [
  { id: 'CERT001', studentId: 'STU1024', studentName: 'Aarav Sharma', chapterName: 'Number System', examTitle: 'Number System — Chapter Test', score: 85, issuedAt: '2026-09-15', status: 'issued' },
  { id: 'CERT002', studentId: 'STU1025', studentName: 'Diya Patel', chapterName: 'Number System', examTitle: 'Number System — Chapter Test', score: 95, issuedAt: '2026-09-15', status: 'issued' },
  { id: 'CERT003', studentId: 'STU1027', studentName: 'Ananya Iyer', chapterName: 'Algebra Basics', examTitle: 'Algebra — Final Test', score: 88, issuedAt: '2026-10-25', status: 'issued' },
  { id: 'CERT004', studentId: 'STU1029', studentName: 'Ishita Verma', chapterName: 'Geometry', examTitle: 'Geometry — Chapter Test', score: 93, issuedAt: '2026-11-11', status: 'issued' },
  { id: 'CERT005', studentId: 'STU1024', studentName: 'Aarav Sharma', chapterName: 'Algebra Basics', examTitle: 'Algebra — Final Test', score: 83, issuedAt: '2026-10-25', status: 'issued' },
  { id: 'CERT006', studentId: 'STU1035', studentName: 'Kiara Kapoor', chapterName: 'Mensuration', examTitle: 'Mensuration — Chapter Test', score: 90, issuedAt: '2026-12-18', status: 'issued' },
  { id: 'CERT007', studentId: 'STU1029', studentName: 'Ishita Verma', chapterName: 'Trigonometry', examTitle: 'Trigonometry — Quiz 1', score: 93, issuedAt: '2026-12-01', status: 'issued' },
]

// ───────────────────────── Activity ─────────────────────────
export const activityLogs: ActivityLog[] = [
  { id: 'L001', user: 'Aarav Sharma', role: 'student', action: 'submitted exam', target: 'Trigonometry — Quiz 1', time: '2 min ago', type: 'submit' },
  { id: 'L002', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'published exam', target: 'Trigonometry — Chapter Test', time: '18 min ago', type: 'create' },
  { id: 'L003', user: 'Diya Patel', role: 'student', action: 'earned certificate', target: 'Number System', time: '1 hour ago', type: 'create' },
  { id: 'L004', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added question', target: 'Q010 — Statistics', time: '2 hours ago', type: 'create' },
  { id: 'L005', user: 'Vivaan Gupta', role: 'student', action: 'logged in', target: '', time: '3 hours ago', type: 'login' },
  { id: 'L006', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated chapter', target: 'Mensuration', time: '5 hours ago', type: 'update' },
  { id: 'L007', user: 'Ishita Verma', role: 'student', action: 'completed study material', target: 'Geometry — Worksheet 3', time: '6 hours ago', type: 'update' },
  { id: 'L008', user: 'System', role: 'admin', action: 'auto-backup completed', target: 'backup_20260719.zip', time: '8 hours ago', type: 'system' },
  { id: 'L009', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'suspended student', target: 'Saanvi Nair', time: '12 hours ago', type: 'update' },
  { id: 'L010', user: 'Ananya Iyer', role: 'student', action: 'submitted exam', target: 'Algebra — Final Test', time: '1 day ago', type: 'submit' },
]

// ───────────────────────── Announcements ─────────────────────────
export const announcements: Announcement[] = [
  { id: 'A001', title: 'Trigonometry Chapter Test scheduled for Jan 20', body: 'The final chapter test for Trigonometry will be held on January 20, 10:00 AM. Please complete all practice sheets beforehand.', audience: 'students', priority: 'high', status: 'active', createdAt: '2026-07-19', author: 'Prof. Kalpesh Vyas' },
  { id: 'A002', title: 'New Statistics & Probability chapter coming soon', body: 'We are adding a new chapter on Statistics & Probability. Expected release by end of this month.', audience: 'all', priority: 'normal', status: 'active', createdAt: '2026-07-17', author: 'Prof. Kalpesh Vyas' },
  { id: 'A003', title: 'Maintenance window — Jan 18, 2–4 AM', body: 'The portal will undergo scheduled maintenance. Please save your work before the window.', audience: 'all', priority: 'normal', status: 'active', createdAt: '2026-07-15', author: 'System' },
  { id: 'A004', title: 'Holiday schedule for Republic Day', body: 'No exams will be scheduled on January 26. Regular classes resume January 27.', audience: 'students', priority: 'low', status: 'active', createdAt: '2026-07-13', author: 'Prof. Kalpesh Vyas' },
]

// ───────────────────────── Notes (student) ─────────────────────────
export const notes: Note[] = [
  { id: 'N001', title: 'Trig identities cheat sheet', content: 'sin²θ + cos²θ = 1\n1 + tan²θ = sec²θ\n1 + cot²θ = cosec²θ\nsin(90−θ) = cosθ', chapter: 'Trigonometry', color: 'emerald', updatedAt: '2 hours ago' },
  { id: 'N002', title: 'Algebra formulas', content: '(a+b)² = a² + 2ab + b²\n(a−b)² = a² − 2ab + b²\na² − b² = (a+b)(a−b)', chapter: 'Algebra Basics', color: 'amber', updatedAt: 'yesterday' },
  { id: 'N003', title: 'Circle theorems', content: 'Angle at center = 2 × angle at circumference\nAngles in same segment are equal', chapter: 'Geometry', color: 'violet', updatedAt: '3 days ago' },
]

// ───────────────────────── Messages ─────────────────────────
export const messages: Message[] = [
  { id: 'M001', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Great progress!', preview: 'You scored 85% on the Number System test. Keep up the excellent work...', time: '1 hour ago', read: false, direction: 'in' },
  { id: 'M002', from: 'Aarav Sharma', to: 'Prof. Kalpesh Vyas', subject: 'Doubt in Q4 of Algebra', preview: 'Sir, I could not understand how to factorise 2x² - 8...', time: '3 hours ago', read: true, direction: 'out' },
  { id: 'M003', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Re: Doubt in Q4 of Algebra', preview: 'Take 2 common first: 2(x² - 4) = 2(x-2)(x+2)...', time: '2 hours ago', read: false, direction: 'in' },
  { id: 'M004', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Reminder: Trigonometry test', preview: 'This is a reminder about your upcoming test on January 20...', time: '1 day ago', read: true, direction: 'in' },
]

// ───────────────────────── Chart data ─────────────────────────
export const weeklyActivity = [
  { day: 'Mon', study: 42, exams: 8 },
  { day: 'Tue', study: 55, exams: 12 },
  { day: 'Wed', study: 38, exams: 6 },
  { day: 'Thu', study: 61, exams: 14 },
  { day: 'Fri', study: 48, exams: 10 },
  { day: 'Sat', study: 72, exams: 18 },
  { day: 'Sun', study: 35, exams: 4 },
]

export const examPerformance = [
  { name: 'Num System', avg: 78, pass: 88 },
  { name: 'Algebra Mid', avg: 72, pass: 74 },
  { name: 'Algebra Final', avg: 68, pass: 66 },
  { name: 'Geometry', avg: 65, pass: 70 },
  { name: 'Trig Quiz', avg: 61, pass: 68 },
  { name: 'Mensuration', avg: 70, pass: 78 },
]

export const enrollmentTrend = [
  { month: 'Jul', students: 28 },
  { month: 'Aug', students: 36 },
  { month: 'Sep', students: 41 },
  { month: 'Oct', students: 44 },
  { month: 'Nov', students: 47 },
  { month: 'Dec', students: 49 },
  { month: 'Jan', students: 52 },
]

export const scoreDistribution = [
  { range: '0-20', count: 3 },
  { range: '21-40', count: 7 },
  { range: '41-60', count: 14 },
  { range: '61-80', count: 28 },
  { range: '81-100', count: 19 },
]

export const studentProgressData = [
  { subject: 'Number System', progress: 100, score: 85 },
  { subject: 'Algebra', progress: 90, score: 83 },
  { subject: 'Geometry', progress: 75, score: 78 },
  { subject: 'Trigonometry', progress: 45, score: 87 },
  { subject: 'Mensuration', progress: 20, score: 0 },
  { subject: 'Statistics', progress: 0, score: 0 },
]

// ───────────────────────── Helpers ─────────────────────────
export const dashboardStats = {
  totalStudents: students.length,
  activeToday: students.filter((s) => s.lastLogin?.startsWith('2026-07-19')).length,
  totalChapters: chapters.length,
  totalExams: exams.length,
  totalQuestions: questions.length,
  totalMaterials: chapters.reduce((a, c) => a + c.studyMaterials + c.practiceSheets, 0),
  totalCertificates: certificates.length,
  passRate: Math.round(
    (results.filter((r) => r.status === 'passed').length / results.length) * 100
  ),
  avgScore: Math.round(results.reduce((a, r) => a + r.percentage, 0) / results.length),
}

export const studentDashboardStats = {
  chaptersCompleted: 3,
  chaptersTotal: chapters.length,
  examsCompleted: 12,
  avgScore: 84,
  certificates: 4,
  rank: 3,
  studyHours: 47,
  streak: 12,
}
