// ============================================================
// Navigation helpers — resolve page titles from the admin/student
// nav config so that when the admin renames a menu item in
// Settings → Navigation, the corresponding page header title
// follows the custom label automatically.
// ============================================================

import { useDataStore } from './data-store'

/**
 * Resolve a page's display title from the persisted nav config.
 *
 * @param pageId    the nav item id (matches AdminPage / StudentPage ids,
 *                  e.g. 'batches', 'students', 'chapters')
 * @param fallback  the canonical default title to use if the nav item
 *                  is somehow missing from the persisted config
 * @param role      'admin' (default) or 'student' — which nav list to read
 *
 * @example
 * const title = useNavLabel('batches', 'Levels Management')
 * // → 'Level Management' if the admin renamed it, else 'Levels Management'
 */
export function useNavLabel(
  pageId: string,
  fallback: string,
  role: 'admin' | 'student' = 'admin',
): string {
  return useDataStore((s) => {
    const nav = role === 'admin' ? s.settings.adminNav : s.settings.studentNav
    const item = nav.find((n) => n.id === pageId)
    return item?.label || fallback
  })
}
