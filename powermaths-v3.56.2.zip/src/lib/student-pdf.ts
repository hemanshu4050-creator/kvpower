'use client'

// ============================================================
// Power Maths — Student Progress PDF Report Generator
// Generates a professional multi-page PDF using jsPDF.
// Used by:
//   1. admin-students.tsx     → "Download PDF" quick action + drawer button
//   2. admin-student-reports  → "Download PDF" in the reports module
// Filename = student name (sanitized).
// ============================================================

import { jsPDF } from 'jspdf'

// ── Types (mirrors the data-store interfaces; kept loose to avoid
//    circular imports — callers pass plain objects) ───────────────
export interface PdfStudent {
  id: string
  name: string
  email: string
  phone: string
  address?: string
  batch: string
  status: string
  enrolledAt: string
  lastLogin: string | null
  photo?: string
  assignedChapters: string[]
  notes?: string
  validityEnd?: string
}

export interface PdfChapter {
  id: string
  name: string
}

export interface PdfResult {
  id: string
  examTitle: string
  chapterName: string
  attemptNumber: number
  createdAt: string
  timeTakenMinutes: number
  totalQuestions: number
  attempted: number
  correct: number
  wrong: number
  marksObtained: number
  totalMarks: number
  percentage: number
  status: string
}

export interface PdfCertificate {
  id: string
  chapterName: string
  examTitle: string
  score: number
  certificateNumber: string
  issuedAt: string
  status: string
}

export interface PdfReportInput {
  student: PdfStudent
  chapters: PdfChapter[]
  results: PdfResult[]
  certificates: PdfCertificate[]
  teacherName?: string
  instituteName?: string
  teacherNotes?: string
}

// ── Color palette (matches the emerald brand) ───────────────────
const C = {
  brand:     [16, 185, 129] as [number, number, number],   // emerald-500
  brandDark: [4, 120, 87]   as [number, number, number],   // emerald-700
  brandLite: [209, 250, 229] as [number, number, number],  // emerald-100
  ink:       [24, 24, 27]   as [number, number, number],   // zinc-900
  inkSoft:   [82, 82, 91]   as [number, number, number],   // zinc-600
  muted:     [161, 161, 170] as [number, number, number],  // zinc-400
  line:      [228, 228, 231] as [number, number, number],  // zinc-200
  lineDark:  [212, 212, 216] as [number, number, number],  // zinc-300
  bg:        [250, 250, 250] as [number, number, number],  // zinc-50
  white:     [255, 255, 255] as [number, number, number],
  pass:      [16, 185, 129]  as [number, number, number],
  fail:      [244, 63, 94]   as [number, number, number],
  warn:      [245, 158, 11]  as [number, number, number],
  info:      [99, 102, 241]  as [number, number, number],
}

// ── Helpers ─────────────────────────────────────────────────────
function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9-_ ]/g, '').trim().replace(/\s+/g, '_') || 'student'
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

// Compute per-chapter performance for a student
function computeChapterPerf(
  student: PdfStudent,
  chapters: PdfChapter[],
  results: PdfResult[]
) {
  return student.assignedChapters
    .map((id) => {
      const ch = chapters.find((c) => c.id === id)
      if (!ch) return null
      const chResults = results.filter((r) => r.chapterName === ch.name)
      const passed = chResults.some((r) => r.status === 'passed')
      const bestPct = chResults.length ? Math.max(...chResults.map((r) => r.percentage)) : 0
      const studyPct = chResults.length ? 100 : 0
      const practicePct = chResults.length ? Math.min(100, chResults.length * 50) : 0
      const worksheetPct = chResults.filter((r) => r.attemptNumber > 0).length ? 100 : 0
      const examPct = bestPct
      const status = passed ? 'Completed' : chResults.length ? 'In Progress' : 'Not Started'
      return { id, name: ch.name, studyPct, practicePct, worksheetPct, examPct, status, attempts: chResults.length }
    })
    .filter(Boolean) as NonNullable<ReturnType<typeof computeChapterPerf[number]>>[]
}

// ─────────────────────────────────────────────────────────────────
//  MAIN GENERATOR
// ─────────────────────────────────────────────────────────────────
export function generateStudentReportPdf(input: PdfReportInput): void {
  const { student, chapters, results, certificates, teacherName = 'Prof. Kalpesh Vyas', instituteName = 'Power Maths', teacherNotes } = input
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const W = doc.internal.pageSize.getWidth()   // 595
  const H = doc.internal.pageSize.getHeight()  // 842
  const M = 40 // margin
  const contentW = W - M * 2
  const now = new Date()
  const reportDate = fmtDate(now)
  const reportId = `PM-RPT-${student.id}-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`

  // ── Derived stats ──
  const sResults = results.filter((r) => r.chapterName !== '' ) // all are for this student (caller filters)
  const avg = sResults.length ? Math.round(sResults.reduce((a, r) => a + r.percentage, 0) / sResults.length) : 0
  const highest = sResults.length ? Math.max(...sResults.map((r) => r.percentage)) : 0
  const lowest = sResults.length ? Math.min(...sResults.map((r) => r.percentage)) : 0
  const passed = sResults.filter((r) => r.status === 'passed').length
  const failed = sResults.filter((r) => r.status === 'failed').length
  const passPct = sResults.length ? Math.round((passed / sResults.length) * 100) : 0
  const failPct = sResults.length ? Math.round((failed / sResults.length) * 100) : 0
  const assigned = student.assignedChapters.length
  const chapterPerf = computeChapterPerf(student, chapters, results)
  const completedChapters = chapterPerf.filter((c) => c.status === 'Completed').length
  const remainingChapters = assigned - completedChapters
  const certs = certificates.filter((c) => c.status === 'issued')
  const totalStudyMin = sResults.reduce((a, r) => a + r.timeTakenMinutes, 0)
  const totalStudyHrs = Math.round((totalStudyMin / 60) * 10) / 10
  const avgTimePerCh = assigned ? Math.round(totalStudyMin / assigned) : 0
  const progress = assigned ? Math.round((completedChapters / assigned) * 100) : 0

  // ── Page header / footer ──
  let page = 1
  const totalPagesPlaceholder = '{TP}'

  function drawHeader(title: string) {
    // Brand bar
    doc.setFillColor(...C.brand)
    doc.rect(0, 0, W, 6, 'F')
    // Logo block
    doc.setFillColor(...C.brandDark)
    doc.roundedRect(M, 18, 28, 28, 4, 4, 'F')
    doc.setTextColor(...C.white)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(13)
    doc.text('PM', M + 14, 36, { align: 'center' })
    // Title
    doc.setTextColor(...C.ink)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(11)
    doc.text(instituteName, M + 38, 28)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.setTextColor(...C.inkSoft)
    doc.text(title, M + 38, 40)
    // Right: report id
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(reportId, W - M, 28, { align: 'right' })
    doc.text(reportDate, W - M, 40, { align: 'right' })
    // Divider
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, 54, W - M, 54)
  }

  function drawFooter() {
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, H - 30, W - M, H - 30)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(`${instituteName} · ${teacherName}`, M, H - 18)
    doc.text(`${student.name} · ${student.id}`, W / 2, H - 18, { align: 'center' })
    doc.text(`Page ${page} of ${totalPagesPlaceholder}`, W - M, H - 18, { align: 'right' })
  }

  function newPage(title: string) {
    if (page > 1) drawFooter()
    doc.addPage()
    page++
    drawHeader(title)
    return 70 // top y
  }

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 1 — COVER
  // ═══════════════════════════════════════════════════════════════
  drawHeader('Student Performance Report')
  // Hero band
  doc.setFillColor(...C.bg)
  doc.rect(M, 70, contentW, 200, 'F')
  // Photo
  const photoSize = 90
  const photoX = M + 30
  const photoY = 95
  if (student.photo) {
    try {
      doc.addImage(student.photo, 'JPEG', photoX, photoY, photoSize, photoSize, undefined, 'FAST')
    } catch {
      doc.setFillColor(...C.brandLite)
      doc.roundedRect(photoX, photoY, photoSize, photoSize, 8, 8, 'F')
      doc.setTextColor(...C.brandDark)
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(28)
      doc.text(student.name.split(' ').map((w) => w[0]).slice(0, 2).join(''), photoX + photoSize / 2, photoY + photoSize / 2 + 10, { align: 'center' })
    }
  } else {
    doc.setFillColor(...C.brandLite)
    doc.roundedRect(photoX, photoY, photoSize, photoSize, 8, 8, 'F')
    doc.setTextColor(...C.brandDark)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(28)
    doc.text(student.name.split(' ').map((w) => w[0]).slice(0, 2).join(''), photoX + photoSize / 2, photoY + photoSize / 2 + 10, { align: 'center' })
  }
  // Name + meta
  const textX = photoX + photoSize + 30
  doc.setTextColor(...C.ink)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(22)
  doc.text(student.name, textX, 120)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.setTextColor(...C.inkSoft)
  doc.text(`Student ID: ${student.id}`, textX, 142)
  doc.text(`Batch: ${student.batch}`, textX, 157)
  doc.text(`Status: ${student.status}`, textX, 172)
  doc.text(`Enrolled: ${student.enrolledAt}`, textX, 187)
  doc.text(`Last Login: ${student.lastLogin ?? '—'}`, textX, 202)
  // Report title band
  doc.setFillColor(...C.brand)
  doc.rect(M, 70, contentW, 4, 'F')
  doc.setFillColor(...C.brandDark)
  doc.rect(M, 266, contentW, 4, 'F')

  // KPI summary on cover
  let y = 300
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text('Performance Snapshot', M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 160, y)
  y += 18

  const kpis = [
    { label: 'Overall Progress', value: `${progress}%` },
    { label: 'Average Score', value: `${avg}%` },
    { label: 'Highest Score', value: `${highest}%` },
    { label: 'Lowest Score', value: `${lowest}%` },
    { label: 'Pass Rate', value: `${passPct}%` },
    { label: 'Chapters Done', value: `${completedChapters}/${assigned}` },
    { label: 'Exams Taken', value: `${sResults.length}` },
    { label: 'Certificates', value: `${certs.length}` },
  ]
  const kpiW = (contentW - 30) / 4
  const kpiH = 52
  kpis.forEach((k, i) => {
    const col = i % 4
    const row = Math.floor(i / 4)
    const x = M + col * (kpiW + 10)
    const ky = y + row * (kpiH + 10)
    doc.setFillColor(...C.white)
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.roundedRect(x, ky, kpiW, kpiH, 5, 5, 'FD')
    doc.setFillColor(...C.brand)
    doc.roundedRect(x, ky, 3, kpiH, 1.5, 1.5, 'F')
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8)
    doc.setTextColor(...C.muted)
    doc.text(k.label.toUpperCase(), x + 12, ky + 16)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(16)
    doc.setTextColor(...C.ink)
    doc.text(k.value, x + 12, ky + 38)
  })
  y += 2 * (kpiH + 10) + 10

  // Teacher + institute info
  doc.setDrawColor(...C.line)
  doc.setLineWidth(0.5)
  doc.roundedRect(M, y, contentW, 70, 5, 5, 'FD')
  doc.setFillColor(...C.brandLite)
  doc.roundedRect(M, y, 4, 70, 2, 2, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.setTextColor(...C.ink)
  doc.text('Report Details', M + 16, y + 20)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(...C.inkSoft)
  doc.text(`Institute: ${instituteName}`, M + 16, y + 36)
  doc.text(`Teacher: ${teacherName}`, M + 16, y + 50)
  doc.text(`Generated: ${reportDate} ${now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`, M + 16, y + 64)
  // Right column
  doc.text(`Report ID: ${reportId}`, W - M - 16, y + 36, { align: 'right' })
  doc.text(`Student: ${student.name}`, W - M - 16, y + 50, { align: 'right' })
  doc.text(`Batch: ${student.batch}`, W - M - 16, y + 64, { align: 'right' })

  page = 1

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 2 — PERFORMANCE OVERVIEW (detailed KPIs + marks trend)
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Performance Overview')
  // 12 KPI cards in 4x3 grid
  const fullKpis = [
    { label: 'Overall Progress', value: `${progress}%`, accent: C.brand },
    { label: 'Overall Average', value: `${avg}%`, accent: C.info },
    { label: 'Highest Score', value: `${highest}%`, accent: C.pass },
    { label: 'Lowest Score', value: `${lowest}%`, accent: C.fail },
    { label: 'Pass Percentage', value: `${passPct}%`, accent: C.pass },
    { label: 'Fail Percentage', value: `${failPct}%`, accent: C.fail },
    { label: 'Chapters Completed', value: `${completedChapters}`, accent: C.brand },
    { label: 'Chapters Remaining', value: `${remainingChapters}`, accent: C.warn },
    { label: 'Certificates Earned', value: `${certs.length}`, accent: C.warn },
    { label: 'Exams Attempted', value: `${sResults.length}`, accent: C.info },
    { label: 'Total Study Time', value: `${totalStudyHrs}h`, accent: C.brand },
    { label: 'Avg Time/Chapter', value: `${avgTimePerCh}m`, accent: C.info },
  ]
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text('Key Performance Indicators', M, y)
  y += 12
  const fkW = (contentW - 30) / 4
  const fkH = 48
  fullKpis.forEach((k, i) => {
    const col = i % 4
    const row = Math.floor(i / 4)
    const x = M + col * (fkW + 10)
    const ky = y + row * (fkH + 8)
    doc.setFillColor(...C.white)
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.roundedRect(x, ky, fkW, fkH, 4, 4, 'FD')
    doc.setFillColor(...k.accent)
    doc.roundedRect(x, ky, fkW, 3, 1.5, 1.5, 'F')
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(k.label.toUpperCase(), x + 10, ky + 16)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(15)
    doc.setTextColor(...C.ink)
    doc.text(k.value, x + 10, ky + 36)
  })
  y += 3 * (fkH + 8) + 14

  // Marks trend bar chart
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(11)
  doc.setTextColor(...C.ink)
  doc.text('Marks Trend (recent attempts)', M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 180, y)
  y += 12
  const trend = sResults.slice(-8)
  if (trend.length) {
    const chartW = contentW
    const chartH = 100
    const barW = chartW / trend.length * 0.6
    const gap = chartW / trend.length
    doc.setFillColor(...C.bg)
    doc.roundedRect(M, y, chartW, chartH, 4, 4, 'F')
    // gridlines
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.3)
    for (let p = 0; p <= 100; p += 25) {
      const gy = y + chartH - (p / 100) * (chartH - 16) - 8
      doc.line(M + 4, gy, M + chartW - 4, gy)
      doc.setFontSize(6.5)
      doc.setTextColor(...C.muted)
      doc.text(`${p}`, M + 2, gy + 2, { align: 'right' })
    }
    trend.forEach((r, i) => {
      const bx = M + i * gap + gap * 0.2
      const bh = (r.percentage / 100) * (chartH - 16)
      const by = y + chartH - bh - 8
      const col = r.status === 'passed' ? C.pass : C.fail
      doc.setFillColor(...col)
      doc.roundedRect(bx, by, barW, bh, 2, 2, 'F')
      doc.setFontSize(7)
      doc.setTextColor(...C.ink)
      doc.text(`${r.percentage}%`, bx + barW / 2, by - 3, { align: 'center' })
      doc.setFontSize(6)
      doc.setTextColor(...C.muted)
      const label = r.examTitle.length > 14 ? r.examTitle.slice(0, 12) + '…' : r.examTitle
      doc.text(label, bx + barW / 2, y + chartH - 2, { align: 'center' })
    })
    y += chartH + 8
  } else {
    doc.setFontSize(9)
    doc.setTextColor(...C.muted)
    doc.text('No exam attempts yet.', M, y + 10)
    y += 20
  }

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 3 — CHAPTER REPORT
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Chapter Performance Report')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text(`Assigned Chapters (${chapterPerf.length})`, M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 200, y)
  y += 14

  // Table header
  const cols = [
    { name: 'Chapter', x: M, w: 130 },
    { name: 'Study', x: M + 130, w: 55 },
    { name: 'Practice', x: M + 185, w: 60 },
    { name: 'Worksheet', x: M + 245, w: 65 },
    { name: 'Exam', x: M + 310, w: 50 },
    { name: 'Attempts', x: M + 360, w: 50 },
    { name: 'Status', x: M + 410, w: 105 },
  ]
  doc.setFillColor(...C.ink)
  doc.rect(M, y - 2, contentW, 20, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.setTextColor(...C.white)
  cols.forEach((c) => doc.text(c.name.toUpperCase(), c.x + 6, y + 11))
  y += 22

  // Mini progress bar helper
  const barMaxW = 44
  function miniBar(x: number, by: number, pct: number, color: [number, number, number]) {
    doc.setFillColor(...C.line)
    doc.roundedRect(x, by, barMaxW, 6, 2, 2, 'F')
    const fillW = (pct / 100) * barMaxW
    if (fillW > 0) {
      doc.setFillColor(...color)
      doc.roundedRect(x, by, fillW, 6, 2, 2, 'F')
    }
    doc.setFontSize(7)
    doc.setTextColor(...C.inkSoft)
    doc.text(`${pct}%`, x + barMaxW + 4, by + 5)
  }

  chapterPerf.forEach((c, i) => {
    if (y > H - 60) { y = newPage('Chapter Performance Report (cont.)'); 
      doc.setFillColor(...C.ink); doc.rect(M, y - 2, contentW, 20, 'F')
      doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(...C.white)
      cols.forEach((cc) => doc.text(cc.name.toUpperCase(), cc.x + 6, y + 11))
      y += 22
    }
    if (i % 2 === 0) {
      doc.setFillColor(...C.bg)
      doc.rect(M, y - 2, contentW, 22, 'F')
    }
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.setTextColor(...C.ink)
    const chName = c.name.length > 22 ? c.name.slice(0, 20) + '…' : c.name
    doc.text(chName, cols[0].x + 6, y + 11)
    miniBar(cols[1].x + 6, y + 7, c.studyPct, C.brand)
    miniBar(cols[2].x + 6, y + 7, c.practicePct, C.info)
    miniBar(cols[3].x + 6, y + 7, c.worksheetPct, C.warn)
    miniBar(cols[4].x + 6, y + 7, c.examPct, c.examPct >= 50 ? C.pass : C.fail)
    doc.setTextColor(...C.ink)
    doc.text(`${c.attempts}`, cols[5].x + 6, y + 11)
    const stCol = c.status === 'Completed' ? C.pass : c.status === 'In Progress' ? C.warn : C.muted
    doc.setFillColor(...stCol)
    doc.circle(cols[6].x + 10, y + 9, 2.5, 'F')
    doc.setTextColor(...C.inkSoft)
    doc.setFontSize(8)
    doc.text(c.status, cols[6].x + 18, y + 11)
    y += 22
  })

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 4 — EXAM REPORT
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Exam History Report')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text(`Exam Attempts (${sResults.length})`, M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 180, y)
  y += 14

  const ecols = [
    { name: 'Exam', x: M, w: 150 },
    { name: 'Chapter', x: M + 150, w: 90 },
    { name: 'Att', x: M + 240, w: 30 },
    { name: 'Date', x: M + 270, w: 60 },
    { name: 'Time', x: M + 330, w: 40 },
    { name: 'Marks', x: M + 370, w: 55 },
    { name: '%', x: M + 425, w: 35 },
    { name: 'Result', x: M + 460, w: 55 },
  ]
  doc.setFillColor(...C.ink)
  doc.rect(M, y - 2, contentW, 20, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.setTextColor(...C.white)
  ecols.forEach((c) => doc.text(c.name.toUpperCase(), c.x + 4, y + 11))
  y += 22

  const sortedResults = [...sResults].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  sortedResults.forEach((r, i) => {
    if (y > H - 60) { y = newPage('Exam History Report (cont.)')
      doc.setFillColor(...C.ink); doc.rect(M, y - 2, contentW, 20, 'F')
      doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(...C.white)
      ecols.forEach((c) => doc.text(c.name.toUpperCase(), c.x + 4, y + 11))
      y += 22
    }
    if (i % 2 === 0) {
      doc.setFillColor(...C.bg)
      doc.rect(M, y - 2, contentW, 20, 'F')
    }
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8)
    doc.setTextColor(...C.ink)
    const eTitle = r.examTitle.length > 26 ? r.examTitle.slice(0, 24) + '…' : r.examTitle
    doc.text(eTitle, ecols[0].x + 4, y + 10)
    const ch = r.chapterName.length > 16 ? r.chapterName.slice(0, 14) + '…' : r.chapterName
    doc.text(ch, ecols[1].x + 4, y + 10)
    doc.text(`#${r.attemptNumber}`, ecols[2].x + 4, y + 10)
    doc.text(r.createdAt.slice(0, 10), ecols[3].x + 4, y + 10)
    doc.text(`${r.timeTakenMinutes}m`, ecols[4].x + 4, y + 10)
    doc.text(`${r.marksObtained}/${r.totalMarks}`, ecols[5].x + 4, y + 10)
    doc.setFont('helvetica', 'bold')
    doc.text(`${r.percentage}%`, ecols[6].x + 4, y + 10)
    const rc = r.status === 'passed' ? C.pass : C.fail
    doc.setFillColor(...rc)
    doc.roundedRect(ecols[7].x + 2, y + 2, 50, 12, 3, 3, 'F')
    doc.setTextColor(...C.white)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(7)
    doc.text(r.status.toUpperCase(), ecols[7].x + 27, y + 10, { align: 'center' })
    y += 20
  })

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 5 — CERTIFICATES
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Certificates Earned')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text(`Certificates (${certs.length})`, M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 150, y)
  y += 14

  if (certs.length === 0) {
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
    doc.setTextColor(...C.muted)
    doc.text('No certificates have been issued to this student yet.', M, y + 14)
  } else {
    const ccols = [
      { name: 'Certificate #', x: M, w: 120 },
      { name: 'Chapter', x: M + 120, w: 110 },
      { name: 'Exam', x: M + 230, w: 150 },
      { name: 'Score', x: M + 380, w: 50 },
      { name: 'Issue Date', x: M + 430, w: 85 },
    ]
    doc.setFillColor(...C.ink)
    doc.rect(M, y - 2, contentW, 20, 'F')
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.setTextColor(...C.white)
    ccols.forEach((c) => doc.text(c.name.toUpperCase(), c.x + 6, y + 11))
    y += 22
    certs.forEach((c, i) => {
      if (i % 2 === 0) {
        doc.setFillColor(...C.bg)
        doc.rect(M, y - 2, contentW, 24, 'F')
      }
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8.5)
      doc.setTextColor(...C.ink)
      doc.text(c.certificateNumber, ccols[0].x + 6, y + 12)
      doc.text(c.chapterName, ccols[1].x + 6, y + 12)
      const eTitle = c.examTitle.length > 26 ? c.examTitle.slice(0, 24) + '…' : c.examTitle
      doc.text(eTitle, ccols[2].x + 6, y + 12)
      doc.setFont('helvetica', 'bold')
      doc.setTextColor(...C.brandDark)
      doc.text(`${c.score}%`, ccols[3].x + 6, y + 12)
      doc.setFont('helvetica', 'normal')
      doc.setTextColor(...C.inkSoft)
      doc.text(c.issuedAt, ccols[4].x + 6, y + 12)
      y += 24
    })
  }
  y += 16

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 6 — LEARNING TIMELINE + INSIGHTS
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Learning Timeline & Insights')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text('Learning Timeline', M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 150, y)
  y += 16

  const timeline = [
    { label: 'Student Registered', time: student.enrolledAt, done: true },
    { label: `Chapter Assigned (${assigned})`, time: student.enrolledAt, done: assigned > 0 },
    { label: 'First Worksheet Completed', time: sResults[0]?.createdAt ?? '—', done: sResults.length > 0 },
    { label: 'First Practice Completed', time: sResults[0]?.createdAt ?? '—', done: sResults.length > 0 },
    { label: 'First Exam Attempted', time: sResults[0]?.createdAt ?? '—', done: sResults.length > 0 },
    { label: 'First Exam Passed', time: sResults.find((r) => r.status === 'passed')?.createdAt ?? '—', done: passed > 0 },
    { label: 'Certificate Generated', time: certs[0]?.issuedAt ?? '—', done: certs.length > 0 },
    { label: 'Started Next Chapter', time: chapterPerf.find((c) => c.status === 'In Progress')?.name ?? '—', done: chapterPerf.some((c) => c.status === 'In Progress') },
  ]
  timeline.forEach((t, i) => {
    const isLast = i === timeline.length - 1
    const dotX = M + 10
    // connecting line
    if (!isLast) {
      doc.setDrawColor(...C.lineDark)
      doc.setLineWidth(1)
      doc.line(dotX, y + 6, dotX, y + 26)
    }
    // dot
    doc.setFillColor(...(t.done ? C.brand : C.muted))
    doc.circle(dotX, y + 6, 3.5, 'F')
    if (t.done) {
      doc.setFillColor(...C.white)
      doc.setTextColor(...C.white)
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(6)
      doc.text('✓', dotX, y + 8.5, { align: 'center' })
    }
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(9.5)
    doc.setTextColor(...C.ink)
    doc.text(t.label, dotX + 14, y + 9)
    doc.setFontSize(8)
    doc.setTextColor(...C.muted)
    doc.text(String(t.time), dotX + 14, y + 21)
    y += 26
  })
  y += 10

  // Performance insights
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text('Performance Insights', M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 160, y)
  y += 14

  // Compute insights
  const chapterScores = chapterPerf.map((c) => ({ name: c.name, pct: c.examPct, attempts: c.attempts })).filter((c) => c.attempts > 0)
  const strongest = chapterScores.length ? chapterScores.reduce((a, b) => (a.pct > b.pct ? a : b)) : null
  const weakest = chapterScores.length ? chapterScores.reduce((a, b) => (a.pct < b.pct ? a : b)) : null
  const mostAttempts = chapterScores.length ? chapterScores.reduce((a, b) => (a.attempts > b.attempts ? a : b)) : null
  const insights = [
    { label: 'Strongest Subject', value: strongest ? `${strongest.name} (${strongest.pct}%)` : '—', accent: C.pass },
    { label: 'Weakest Subject', value: weakest ? `${weakest.name} (${weakest.pct}%)` : '—', accent: C.fail },
    { label: 'Most Time Spent', value: mostAttempts ? `${mostAttempts.name} (${mostAttempts.attempts} attempts)` : '—', accent: C.info },
    { label: 'Fastest Completed Chapter', value: chapterPerf.find((c) => c.status === 'Completed')?.name ?? '—', accent: C.brand },
    { label: 'Lowest Performing Chapter', value: weakest?.name ?? '—', accent: C.warn },
    { label: 'Highest Performing Chapter', value: strongest?.name ?? '—', accent: C.pass },
    { label: 'Recommended Revision', value: weakest?.name ?? '—', accent: C.warn },
    { label: 'Overall Status', value: progress >= 75 ? 'On Track' : progress >= 50 ? 'Needs Attention' : 'At Risk', accent: progress >= 75 ? C.pass : progress >= 50 ? C.warn : C.fail },
  ]
  const insW = (contentW - 10) / 2
  const insH = 34
  insights.forEach((ins, i) => {
    const col = i % 2
    const row = Math.floor(i / 2)
    const x = M + col * (insW + 10)
    const iy = y + row * (insH + 6)
    doc.setFillColor(...C.white)
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.roundedRect(x, iy, insW, insH, 4, 4, 'FD')
    doc.setFillColor(...ins.accent)
    doc.roundedRect(x, iy, 3, insH, 1.5, 1.5, 'F')
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(ins.label.toUpperCase(), x + 12, iy + 12)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(11)
    doc.setTextColor(...C.ink)
    const val = ins.value.length > 40 ? ins.value.slice(0, 38) + '…' : ins.value
    doc.text(val, x + 12, iy + 26)
  })
  y += 4 * (insH + 6) + 10

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 7 — TEACHER NOTES + OVERALL SUMMARY
  // ═══════════════════════════════════════════════════════════════
  y = newPage('Teacher Notes & Summary')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text("Teacher's Private Notes", M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 160, y)
  y += 14
  doc.setFillColor(...C.bg)
  doc.roundedRect(M, y, contentW, 90, 5, 5, 'F')
  doc.setFillColor(...C.warn)
  doc.roundedRect(M, y, 4, 90, 2, 2, 'F')
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9.5)
  doc.setTextColor(...C.ink)
  const notes = teacherNotes?.trim() || student.notes?.trim() || 'No teacher notes have been recorded for this student yet.'
  const splitNotes = doc.splitTextToSize(notes, contentW - 30)
  doc.text(splitNotes, M + 16, y + 20)
  y += 104

  // Overall summary
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(...C.ink)
  doc.text('Overall Summary & Recommendation', M, y)
  y += 8
  doc.setDrawColor(...C.line)
  doc.line(M, y, M + 240, y)
  y += 14

  let summary = ''
  if (progress >= 75 && avg >= 75) {
    summary = `${student.name} is performing excellently with ${progress}% curriculum coverage and an average score of ${avg}%. The student has completed ${completedChapters} of ${assigned} assigned chapters and earned ${certs.length} certificate(s). Performance is consistent across subjects. Recommended next step: advance to higher-difficulty problems and peer mentoring.`
  } else if (progress >= 50) {
    summary = `${student.name} is making satisfactory progress with ${progress}% curriculum coverage and an average score of ${avg}%. The student has completed ${completedChapters} of ${assigned} chapters. Focus areas: ${weakest?.name ?? 'foundation topics'}. Recommended action: schedule additional practice sessions and review sessions for weaker topics.`
  } else {
    summary = `${student.name} requires additional attention. Current progress is ${progress}% with an average score of ${avg}%. Only ${completedChapters} of ${assigned} chapters have been completed. Immediate intervention is recommended: schedule a one-on-one session, review foundational concepts, and assign remedial worksheets${weakest ? ` focusing on ${weakest.name}` : ''}.`
  }
  doc.setFillColor(...C.brandLite)
  doc.roundedRect(M, y, contentW, 110, 5, 5, 'F')
  doc.setFillColor(...C.brand)
  doc.roundedRect(M, y, 4, 110, 2, 2, 'F')
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9.5)
  doc.setTextColor(...C.ink)
  const splitSummary = doc.splitTextToSize(summary, contentW - 30)
  doc.text(splitSummary, M + 16, y + 22)
  y += 124

  // Signature block
  doc.setDrawColor(...C.inkSoft)
  doc.setLineWidth(0.5)
  doc.line(M, y + 30, M + 180, y + 30)
  doc.line(W - M - 180, y + 30, W - M, y + 30)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  doc.setTextColor(...C.inkSoft)
  doc.text(teacherName, M, y + 42)
  doc.text('Teacher Signature', M, y + 54)
  doc.text(`${instituteName} Administration`, W - M - 180, y + 42)
  doc.text('Institution Seal', W - M - 180, y + 54)

  // ── Final footer on last page ──
  drawFooter()

  // ── Replace page-count placeholder ──
  const pageCount = doc.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    // Re-draw the page-number text (we know it's at H-18, right-aligned at W-M)
    // First erase the old placeholder text by covering with white
    doc.setFillColor(...C.white)
    doc.rect(W - M - 70, H - 26, 70, 12, 'F')
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(`Page ${i} of ${pageCount}`, W - M, H - 18, { align: 'right' })
  }

  // ── Save ──
  doc.save(`${sanitizeFileName(student.name)}_Progress_Report.pdf`)
}

// Convenience: lightweight single-student progress PDF (used by the
// quick "Download PDF" action in the students table — same generator,
// just a thinner wrapper so callers don't need to assemble everything).
export function downloadStudentProgressPdf(student: PdfStudent, chapters: PdfChapter[], results: PdfResult[], certificates: PdfCertificate[]): void {
  generateStudentReportPdf({ student, chapters, results, certificates })
}

// ─────────────────────────────────────────────────────────────────
//  SINGLE-RESULT SCORECARD PDF
//  Used by both the student "My Results" page and the admin "Results"
//  page → "Download PDF" action on each result row. Generates a clean
//  one-or-two-page scorecard showing the score, pass/fail status,
//  per-question breakdown (when answers are recorded) and a per-question
//  table (admin view shows the student's chosen answer + the correct
//  answer for every question).
// ─────────────────────────────────────────────────────────────────

export interface PdfAnswerOption {
  questionText: string
  options: string[]
  selectedOption: number | null
  correctOption: number
  isCorrect: boolean
  marksAwarded: number
  maxMarks: number
  explanation?: string
  timeTakenSeconds?: number
}

export interface PdfResultDetail {
  id: string
  studentName: string
  studentId?: string
  examTitle: string
  chapterName: string
  attemptNumber: number
  createdAt: string
  timeTakenMinutes: number
  totalQuestions: number
  attempted: number
  correct: number
  wrong: number
  marksObtained: number
  totalMarks: number
  percentage: number
  status: 'passed' | 'failed'
  answers?: PdfAnswerOption[]
  /** When true, the per-question breakdown shows the student's selected
   *  answer + the correct answer (admin view). When false, only the
   *  question + correctness is shown (student view). */
  showAnswers?: boolean
  /** Optional pass percentage threshold (defaults to 50). */
  passingPercentage?: number
}

export function downloadResultScorecardPdf(result: PdfResultDetail): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const W = doc.internal.pageSize.getWidth()
  const H = doc.internal.pageSize.getHeight()
  const M = 40
  const contentW = W - M * 2
  const now = new Date()
  const passingPct = result.passingPercentage ?? 50
  const isPassed = result.status === 'passed'
  const showAnswers = result.showAnswers !== false // default true

  // ── Header band ──
  doc.setFillColor(...C.brand)
  doc.rect(0, 0, W, 80, 'F')
  doc.setFillColor(...C.brandDark)
  doc.rect(0, 76, W, 4, 'F')

  doc.setTextColor(...C.white)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(20)
  doc.text('Exam Scorecard', M, 36)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.text('Power Maths · by Prof. Kalpesh Vyas', M, 54)
  doc.setFontSize(8)
  doc.text(`Generated ${fmtDate(now)}`, W - M, 36, { align: 'right' })
  doc.text(`Report ID: PM-SCR-${result.id}`, W - M, 54, { align: 'right' })

  // ── Student + exam info ──
  let y = 110
  doc.setTextColor(...C.ink)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(14)
  doc.text(result.examTitle, M, y)
  y += 18
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.setTextColor(...C.inkSoft)
  doc.text(`Chapter: ${result.chapterName}`, M, y)
  y += 14
  doc.text(`Student: ${result.studentName}${result.studentId ? `  ·  ID: ${result.studentId}` : ''}`, M, y)
  y += 14
  doc.text(`Attempt #${result.attemptNumber}  ·  Date: ${result.createdAt}  ·  Duration: ${result.timeTakenMinutes} min`, M, y)

  // ── Status banner ──
  y += 26
  const bannerH = 56
  doc.setFillColor(...(isPassed ? C.pass : C.fail))
  doc.roundedRect(M, y, contentW, bannerH, 8, 8, 'F')
  doc.setTextColor(...C.white)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(22)
  doc.text(isPassed ? 'PASSED' : 'FAILED', M + 24, y + 28)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.text(`Passing mark: ${passingPct}%`, M + 24, y + 46)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(28)
  doc.text(`${result.percentage}%`, W - M - 24, y + 30, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.text(`${result.marksObtained} / ${result.totalMarks} marks`, W - M - 24, y + 46, { align: 'right' })

  // ── Stat tiles ──
  y += bannerH + 22
  const tileW = (contentW - 12) / 4
  const tiles = [
    { label: 'Total Qs', value: String(result.totalQuestions), color: C.ink },
    { label: 'Attempted', value: String(result.attempted), color: C.info },
    { label: 'Correct', value: String(result.correct), color: C.pass },
    { label: 'Wrong', value: String(result.wrong), color: C.fail },
  ]
  tiles.forEach((t, i) => {
    const tx = M + i * (tileW + 4)
    doc.setFillColor(...C.bg)
    doc.roundedRect(tx, y, tileW, 56, 6, 6, 'F')
    doc.setTextColor(...C.muted)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8)
    doc.text(t.label.toUpperCase(), tx + tileW / 2, y + 18, { align: 'center' })
    doc.setTextColor(...t.color)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(22)
    doc.text(t.value, tx + tileW / 2, y + 42, { align: 'center' })
  })
  y += 56 + 24

  // ── Per-question breakdown ──
  if (result.answers && result.answers.length > 0) {
    doc.setTextColor(...C.ink)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(12)
    doc.text(showAnswers ? 'Question-by-question review' : 'Question summary', M, y)
    y += 8
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, y, W - M, y)
    y += 14

    doc.setFontSize(9)
    result.answers.forEach((a, i) => {
      // Page break?
      if (y > H - 80) {
        doc.addPage()
        y = M + 10
      }

      const qNum = `Q${i + 1}`
      const statusColor = a.isCorrect ? C.pass : (a.selectedOption === null ? C.warn : C.fail)
      const statusLabel = a.isCorrect ? 'Correct' : (a.selectedOption === null ? 'Skipped' : 'Wrong')

      // Question row
      doc.setFillColor(...C.bg)
      doc.roundedRect(M, y - 8, contentW, 22, 4, 4, 'F')
      doc.setTextColor(...C.inkSoft)
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(9)
      doc.text(qNum, M + 8, y + 6)
      doc.setFont('helvetica', 'normal')
      doc.setTextColor(...C.ink)
      const qLines = doc.splitTextToSize(a.questionText, contentW - 80)
      doc.text(qLines, M + 32, y + 6)
      doc.setTextColor(...statusColor)
      doc.setFont('helvetica', 'bold')
      doc.text(statusLabel, W - M - 8, y + 6, { align: 'right' })
      y += 22 + (qLines.length - 1) * 11

      // Options (only when showAnswers is true OR the question was answered)
      if (showAnswers) {
        a.options.filter(Boolean).forEach((opt, idx) => {
          if (y > H - 60) {
            doc.addPage()
            y = M + 10
          }
          const isCorrectOpt = idx === a.correctOption
          const isSel = idx === a.selectedOption
          const letter = String.fromCharCode(65 + idx)
          doc.setFont('helvetica', 'bold')
          doc.setFontSize(8)
          if (isCorrectOpt) {
            doc.setTextColor(...C.pass)
            doc.text(`✓ ${letter}`, M + 24, y)
          } else if (isSel) {
            doc.setTextColor(...C.fail)
            doc.text(`✗ ${letter}`, M + 24, y)
          } else {
            doc.setTextColor(...C.muted)
            doc.text(`  ${letter}`, M + 24, y)
          }
          doc.setFont('helvetica', 'normal')
          doc.setTextColor(...(isCorrectOpt ? C.pass : isSel ? C.fail : C.inkSoft))
          const optLines = doc.splitTextToSize(opt, contentW - 80)
          doc.text(optLines, M + 44, y)
          if (isSel && !isCorrectOpt) {
            doc.setTextColor(...C.fail)
            doc.setFont('helvetica', 'italic')
            doc.setFontSize(7)
            doc.text('(your answer)', W - M - 8, y, { align: 'right' })
          }
          y += 12 + (optLines.length - 1) * 9
        })
      }

      // Marks awarded
      if (y > H - 50) {
        doc.addPage()
        y = M + 10
      }
      doc.setTextColor(...C.muted)
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(7)
      doc.text(
        `Marks: ${a.marksAwarded > 0 ? '+' : ''}${a.marksAwarded}/${a.maxMarks}${a.timeTakenSeconds ? `  ·  Time: ${a.timeTakenSeconds}s` : ''}`,
        M + 24, y,
      )
      y += 14
    })
  } else {
    // No answers recorded — show a note
    doc.setTextColor(...C.muted)
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(9)
    doc.text(
      'No answer-level breakdown was recorded for this attempt.',
      M, y,
    )
    y += 16
  }

  // ── Footer on every page ──
  const pageCount = doc.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, H - 32, W - M, H - 32)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text('Power Maths · by Prof. Kalpesh Vyas', M, H - 18)
    doc.text(`Page ${i} of ${pageCount}`, W - M, H - 18, { align: 'right' })
    if (result.studentName) {
      doc.text(`Authorized for: ${result.studentName}${result.studentId ? ` (ID: ${result.studentId})` : ''}`, M, H - 8)
    }
  }

  // ── Save ──
  const fileName = `${sanitizeFileName(result.studentName || 'student')}_${sanitizeFileName(result.examTitle)}_Scorecard.pdf`
  doc.save(fileName)
}
