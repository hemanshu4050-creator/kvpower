/**
 * Certificate PDF generator (v3.34.0).
 *
 * Produces a proper VECTOR PDF of a student certificate using jsPDF's native
 * drawing APIs (text, rectangles, circles, embedded images) — NOT a
 * rasterized JPEG wrapped in a PDF. This means:
 *   • The student name, chapter, title, etc. are real selectable text.
 *   • The Power Maths logo is embedded at high resolution and enlarged.
 *   • The file is a genuine .pdf with crisp vector borders and graphics.
 *
 * The layout mirrors the on-screen `CertificateArtwork` component and the
 * standalone print HTML (`buildCertificateHtml`), driven by the same
 * `CertificateTemplate` settings the admin configures in Settings →
 * Certificates. Landscape A4 (297mm × 210mm).
 */

import type { Certificate, CertificateTemplate } from '@/lib/data-store'
import {
  resolveTemplate, scoreTier, toHex, withAlpha,
} from '@/lib/certificate-template'

/** Fetch a static image URL and rasterize through a canvas to a PNG data
 *  URL. Preserves the alpha channel so transparent logos can be embedded
 *  without a white "patch" background. Returns null on failure. */
async function fetchImageAsDataUrl(url: string): Promise<{ dataUrl: string; format: 'PNG' } | null> {
  try {
    const res = await fetch(url, { cache: 'no-cache' })
    if (!res.ok) return null
    const blob = await res.blob()
    const objectUrl = URL.createObjectURL(blob)
    const img = new Image()
    img.crossOrigin = 'anonymous'
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve()
      img.onerror = () => reject(new Error('img load failed'))
      img.src = objectUrl
    })
    const scale = 3 // crisp at print resolution
    const canvas = document.createElement('canvas')
    canvas.width = img.naturalWidth * scale
    canvas.height = img.naturalHeight * scale
    const ctx = canvas.getContext('2d')
    if (!ctx) {
      URL.revokeObjectURL(objectUrl)
      return null
    }
    // Do NOT fill a white background — preserve transparency so the logo
    // can be placed directly on the certificate's colored gradient without
    // a white rectangular "patch" around it.
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    URL.revokeObjectURL(objectUrl)
    return { dataUrl: canvas.toDataURL('image/png'), format: 'PNG' as const }
  } catch {
    return null
  }
}

/** Parse a hex color string ("#rrggbb") into [r, g, b] numbers. */
function hexToRgb(hex: string): [number, number, number] {
  const h = toHex(hex).replace('#', '')
  if (h.length !== 6) return [31, 41, 55]
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]
}

/**
 * Generate and download a landscape A4 vector PDF of the certificate.
 *
 * @param cert  The certificate record (student name, chapter, score, etc.)
 * @param templateOverride  Optional template override (defaults to store).
 */
export async function downloadCertificatePdf(
  cert: Certificate,
  templateOverride?: CertificateTemplate,
): Promise<void> {
  if (typeof window === 'undefined') return
  const { jsPDF } = await import('jspdf')

  // Resolve the template from the override or the live store.
  const storeModule = await import('@/lib/data-store')
  const store = storeModule.useDataStore.getState()
  const t = resolveTemplate(templateOverride ?? store.settings.certificateTemplate)

  // Landscape A4: 297mm × 210mm
  const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' })
  const pageW = pdf.internal.pageSize.getWidth()   // 297
  const pageH = pdf.internal.pageSize.getHeight()  // 210

  // ── Colours ──
  const primary = hexToRgb(t.primaryColor)
  const accent = hexToRgb(t.accentColor)
  const text = hexToRgb(t.textColor)
  const name = hexToRgb(t.nameColor)
  const bgFrom = hexToRgb(t.backgroundFrom)
  const bgTo = hexToRgb(t.backgroundTo)

  // ── Background (vertical gradient simulated with banded fills) ──
  // jsPDF doesn't support gradients natively, so we draw a series of thin
  // horizontal bands interpolating from bgFrom → bgTo. The certificate
  // area is inset by the margin.
  const margin = 8
  const bands = 60
  const certX = margin
  const certY = margin
  const certW = pageW - margin * 2
  const certH = pageH - margin * 2
  for (let i = 0; i < bands; i++) {
    const f = i / (bands - 1)
    const r = Math.round(bgFrom[0] + (bgTo[0] - bgFrom[0]) * f)
    const g = Math.round(bgFrom[1] + (bgTo[1] - bgFrom[1]) * f)
    const b = Math.round(bgFrom[2] + (bgTo[2] - bgFrom[2]) * f)
    pdf.setFillColor(r, g, b)
    pdf.rect(certX, certY + (certH / bands) * i, certW, certH / bands + 0.2, 'F')
  }

  // ── Borders (layout-driven) ──
  const showOuter = t.layout !== 'minimal'
  const showInner = t.layout === 'classic'
  if (showOuter) {
    pdf.setDrawColor(...accent)
    pdf.setLineWidth(1.2)
    pdf.roundedRect(certX + 3, certY + 3, certW - 6, certH - 6, 2, 2, 'S')
  }
  if (showInner) {
    pdf.setDrawColor(...primary)
    pdf.setLineWidth(0.4)
    pdf.roundedRect(certX + 6, certY + 6, certW - 12, certH - 12, 1.5, 1.5, 'S')
  }

  // ── Corner flourishes (classic layout) ──
  if (t.layout === 'classic' && t.showCornerFlourishes) {
    pdf.setDrawColor(...accent)
    pdf.setLineWidth(1)
    const c = 12
    const off = 5
    // top-left
    pdf.line(certX + off, certY + off + c, certX + off, certY + off)
    pdf.line(certX + off, certY + off, certX + off + c, certY + off)
    // top-right
    pdf.line(certX + certW - off - c, certY + off, certX + certW - off, certY + off)
    pdf.line(certX + certW - off, certY + off, certX + certW - off, certY + off + c)
    // bottom-left
    pdf.line(certX + off, certY + certH - off - c, certX + off, certY + certH - off)
    pdf.line(certX + off, certY + certH - off, certX + off + c, certY + certH - off)
    // bottom-right
    pdf.line(certX + certW - off - c, certY + certH - off, certX + certW - off, certY + certH - off)
    pdf.line(certX + certW - off, certY + certH - off, certX + certW - off, certY + certH - off - c)
  }

  // ── Watermark (very faint brand text — jsPDF can't render emoji) ──
  if (t.showWatermark) {
    // jsPDF's built-in fonts can't render the 🎓 emoji, so we use a large
    // faint "Power Maths" text as the watermark instead. Blended toward
    // white to simulate ~12% opacity.
    const wm: [number, number, number] = [
      Math.round(primary[0] * 0.1 + 255 * 0.9),
      Math.round(primary[1] * 0.1 + 255 * 0.9),
      Math.round(primary[2] * 0.1 + 255 * 0.9),
    ]
    pdf.setTextColor(...wm)
    pdf.setFont('times', 'bolditalic')
    pdf.setFontSize(72)
    pdf.text('Power Maths', pageW / 2, pageH / 2 + 5, { align: 'center', baseline: 'middle' })
  }

  // ── Logo (Power Maths circular badge, enlarged, transparent) ──
  // v3.35 — uses the transparent-background PNG so there's no white
  // "patch" rectangle around the logo on the certificate's colored
  // gradient. The logo is placed directly on the background.
  const logoUrl =
    typeof window !== 'undefined' && window.location
      ? `${window.location.origin}/branding/power-maths-logo-transparent.png`
      : '/branding/power-maths-logo-transparent.png'
  const logoData = await fetchImageAsDataUrl(logoUrl)
  // v3.35 — enlarged from 24mm to 32mm so the logo is even more prominent.
  const logoSize = 32
  const logoX = pageW / 2 - logoSize / 2
  const logoY = certY + 12
  if (logoData) {
    // Embed the transparent PNG directly — no white backdrop circle.
    pdf.addImage(logoData.dataUrl, logoData.format, logoX, logoY, logoSize, logoSize, undefined, 'FAST')
  } else {
    // Fallback: draw "PM" text if the logo fails to load.
    pdf.setTextColor(...primary)
    pdf.setFontSize(22)
    pdf.setFont('helvetica', 'bold')
    pdf.text('PM', pageW / 2, logoY + logoSize / 2 + 2, { align: 'center', baseline: 'middle' })
  }

  // ── Brand name + subtitle (below logo) ──
  pdf.setTextColor(...primary)
  pdf.setFont('helvetica', 'bold')
  pdf.setFontSize(15)
  pdf.text(t.brandName, pageW / 2, logoY + logoSize + 7, { align: 'center' })
  pdf.setTextColor(107, 114, 128) // gray-500
  pdf.setFont('helvetica', 'normal')
  pdf.setFontSize(8)
  pdf.text(t.brandSub.toUpperCase(), pageW / 2, logoY + logoSize + 12, { align: 'center' })

  // ── Divider (star between two lines) ──
  const divY = logoY + logoSize + 19
  pdf.setDrawColor(...accent)
  pdf.setLineWidth(0.4)
  pdf.line(pageW / 2 - 20, divY, pageW / 2 - 5, divY)
  pdf.line(pageW / 2 + 5, divY, pageW / 2 + 20, divY)
  pdf.setTextColor(...accent)
  pdf.setFontSize(10)
  pdf.text('★', pageW / 2, divY + 1.5, { align: 'center', baseline: 'middle' })

  // ── Title ──
  pdf.setTextColor(...text)
  pdf.setFont('times', 'bold')
  pdf.setFontSize(28)
  // v3.46.0 — override the title for Level Completion certificates.
  const isLevelCert = cert.certificateType === 'level'
  const displayTitle = isLevelCert ? 'Level Completion Certificate' : t.title
  pdf.text(displayTitle, pageW / 2, divY + 14, { align: 'center' })

  // ── Subtitle ──
  pdf.setTextColor(107, 114, 128)
  pdf.setFont('helvetica', 'normal')
  pdf.setFontSize(9)
  const displaySubtitle = isLevelCert
    ? 'SUCCESSFUL COMPLETION OF AN ENTIRE LEARNING LEVEL'
    : t.subtitle.toUpperCase()
  pdf.text(displaySubtitle, pageW / 2, divY + 21, { align: 'center' })

  // ── Student name (italic, large) ──
  pdf.setTextColor(...name)
  pdf.setFont('times', 'italic')
  pdf.setFontSize(32)
  pdf.text(cert.studentName, pageW / 2, divY + 36, { align: 'center' })

  // ── Underline beneath the name ──
  pdf.setDrawColor(...primary)
  pdf.setLineWidth(0.3)
  pdf.line(pageW / 2 - 35, divY + 40, pageW / 2 + 35, divY + 40)

  // v3.46.0 — Branch: level-completion layout vs exam layout.
  if (isLevelCert) {
    // ── Level completion line + level name + chapter list ──
    pdf.setTextColor(107, 114, 128)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(11)
    pdf.text('has successfully completed', pageW / 2, divY + 49, { align: 'center' })

    pdf.setTextColor(...primary)
    pdf.setFont('helvetica', 'bold')
    pdf.setFontSize(18)
    pdf.text(cert.levelName ?? cert.chapterName, pageW / 2, divY + 57, { align: 'center' })

    // Chapter list — 2-column grid, max 8 visible + "+N more" hint.
    const levelChapters = cert.chapterNames ?? []
    if (levelChapters.length > 0) {
      const gridTopY = divY + 64
      const colWidth = 60
      const colLeftX = pageW / 2 - colWidth - 4
      const colRightX = pageW / 2 + 4
      const rowH = 5.5
      const maxRows = 4 // 4 rows × 2 cols = 8 chapters visible
      const visible = levelChapters.slice(0, maxRows * 2)
      pdf.setFontSize(9)
      visible.forEach((chName, i) => {
        const col = i % 2
        const row = Math.floor(i / 2)
        const x = col === 0 ? colLeftX : colRightX
        const y = gridTopY + row * rowH
        const numStr = `${String(i + 1).padStart(2, '0')}`
        pdf.setTextColor(...accent)
        pdf.setFont('helvetica', 'bold')
        pdf.text(numStr, x, y)
        pdf.setTextColor(...text)
        pdf.setFont('helvetica', 'normal')
        // Truncate to fit the column width (approx 22 chars at 9pt).
        const maxChars = 26
        const truncated = chName.length > maxChars ? `${chName.slice(0, maxChars - 1)}…` : chName
        pdf.text(truncated, x + 6, y)
      })
      if (levelChapters.length > visible.length) {
        pdf.setTextColor(107, 114, 128)
        pdf.setFont('helvetica', 'italic')
        pdf.setFontSize(8)
        pdf.text(
          `+ ${levelChapters.length - visible.length} more chapters`,
          pageW / 2,
          gridTopY + maxRows * rowH + 1,
          { align: 'center' },
        )
      }
    }
  } else {
    // ── Completion line + chapter + exam (existing exam flow) ──
    pdf.setTextColor(107, 114, 128)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(11)
    pdf.text(`${t.completionLine} the`, pageW / 2, divY + 49, { align: 'center' })

    pdf.setTextColor(...text)
    pdf.setFont('helvetica', 'bold')
    pdf.setFontSize(15)
    pdf.text(cert.chapterName, pageW / 2, divY + 57, { align: 'center' })

    pdf.setTextColor(107, 114, 128)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(10)
    pdf.text(`chapter examination · ${cert.examTitle}`, pageW / 2, divY + 63, { align: 'center' })

    // ── Score badge (optional, exam certs only) ──
    const tier = scoreTier(cert.score, t)
    const tierFg =
      tier.kind === 'distinction' ? accent : tier.kind === 'merit' ? primary : [15, 118, 110] as [number, number, number]
    const tierBg =
      tier.kind === 'distinction'
        ? [Math.round(accent[0] * 0.15 + 255 * 0.85), Math.round(accent[1] * 0.15 + 255 * 0.85), Math.round(accent[2] * 0.15 + 255 * 0.85)]
        : tier.kind === 'merit'
        ? [Math.round(primary[0] * 0.15 + 255 * 0.85), Math.round(primary[1] * 0.15 + 255 * 0.85), Math.round(primary[2] * 0.15 + 255 * 0.85)]
        : [221, 247, 244]
    if (t.showScoreBadge) {
      const badgeText = `${tier.label} with ${cert.score}%`
      pdf.setFont('helvetica', 'bold')
      pdf.setFontSize(11)
      const badgeW = pdf.getTextWidth(badgeText) + 14
      const badgeH = 8
      const badgeX = pageW / 2 - badgeW / 2
      const badgeY = divY + 69
      pdf.setFillColor(...tierBg)
      pdf.roundedRect(badgeX, badgeY, badgeW, badgeH, 4, 4, 'F')
      pdf.setTextColor(...tierFg)
      pdf.text(badgeText, pageW / 2, badgeY + badgeH / 2 + 1, { align: 'center', baseline: 'middle' })
    }
  }

  // ── Footer row: date (left) · seal (centre) · instructor (right) ──
  const footerY = certY + certH - 22

  // Date (left)
  if (t.showDate) {
    pdf.setTextColor(107, 114, 128)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(7)
    pdf.text('DATE ISSUED', certX + 22, footerY)
    pdf.setTextColor(...text)
    pdf.setFont('helvetica', 'bold')
    pdf.setFontSize(11)
    pdf.text(cert.issuedAt, certX + 22, footerY + 5)
    pdf.setDrawColor(...text)
    pdf.setLineWidth(0.2)
    pdf.line(certX + 22, footerY + 8, certX + 52, footerY + 8)
  }

  // Seal (centre) — gold circle with dashed outer ring + solid inner ring
  const sealCx = pageW / 2
  const sealCy = footerY + 3
  // dashed outer ring (approximated with a thin solid ring + gaps)
  pdf.setDrawColor(...accent)
  pdf.setLineWidth(0.3)
  pdf.setLineDashPattern([1.2, 0.8], 0)
  pdf.circle(sealCx, sealCy, 11, 'S')
  pdf.setLineDashPattern([], 0)
  pdf.setLineWidth(0.2)
  pdf.circle(sealCx, sealCy, 8.5, 'S')
  // gold body
  pdf.setFillColor(...accent)
  pdf.circle(sealCx, sealCy, 7, 'F')
  pdf.setTextColor(255, 255, 255)
  pdf.setFont('helvetica', 'bold')
  pdf.setFontSize(11)
  // jsPDF's built-in helvetica font cannot render emoji glyphs (they show
  // as mojibake like "QA"). Use a star symbol instead — it renders cleanly
  // and still reads as a "seal of excellence" mark. The on-screen and
  // print-HTML versions still use the admin-configured sealEmoji.
  const sealGlyph = /^[\u0000-\u00ff]$/.test(t.sealEmoji) ? t.sealEmoji : '★'
  pdf.text(sealGlyph, sealCx, sealCy - 1.5, { align: 'center', baseline: 'middle' })
  pdf.setFontSize(5)
  pdf.text(t.sealText, sealCx, sealCy + 3, { align: 'center', baseline: 'middle' })

  // Instructor (right)
  pdf.setTextColor(107, 114, 128)
  pdf.setFont('helvetica', 'normal')
  pdf.setFontSize(7)
  pdf.text(t.instructorTitle.toUpperCase(), certX + certW - 22, footerY, { align: 'right' })
  pdf.setTextColor(...text)
  pdf.setFont('times', 'italic')
  pdf.setFontSize(13)
  pdf.text(t.instructorName, certX + certW - 22, footerY + 5, { align: 'right' })
  pdf.setDrawColor(...text)
  pdf.setLineWidth(0.2)
  pdf.line(certX + certW - 52, footerY + 8, certX + certW - 22, footerY + 8)

  // ── Serial number (bottom centre, optional) ──
  if (t.showSerial) {
    pdf.setTextColor(107, 114, 128)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(7)
    pdf.text(
      `SERIAL · ${cert.certificateNumber}`,
      pageW / 2,
      certY + certH - 6,
      { align: 'center' },
    )
  }

  // ── Save ──
  const safeName = cert.studentName.replace(/[^a-zA-Z0-9-_ ]/g, '').trim().replace(/\s+/g, '_')
  // v3.46.0 — For level certs, use the level name (e.g. "Level_1") in the
  // filename; for exam certs, use the chapter name as before.
  const safeScope = (isLevelCert
    ? (cert.levelName ?? cert.chapterName)
    : cert.chapterName
  ).replace(/[^a-zA-Z0-9-_ ]/g, '').trim().replace(/\s+/g, '_')
  pdf.save(`${safeName}-${safeScope}-${cert.certificateNumber}.pdf`)
}

// Re-export for callers that need the template helpers.
export { resolveTemplate, scoreTier, toHex, withAlpha }
