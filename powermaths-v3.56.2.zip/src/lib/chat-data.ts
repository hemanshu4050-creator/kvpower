// ============================================================
// Power Maths — "Friend" Chatbot Data Layer (non-AI, rule-based)
//
// Two audiences:
//   1. VISITOR  — pre-login users on the home / login page. Goal: convert
//                 to a lead by capturing a WhatsApp number.
//   2. STUDENT  — logged-in students. Goal: help them navigate, get hints,
//                 look up formulas, see their progress, and escalate to a
//                 human via WhatsApp when stuck.
//
// The matching engine (chat-engine.ts) combines keyword matching, scripted
// decision-tree flows, and fuzzy FAQ retrieval. No AI / LLM is used.
// ============================================================

export type ChatAudience = 'visitor' | 'student'

// ─────────────────────────── Types ───────────────────────────

export interface FaqEntry {
  id: string
  audience: ChatAudience[]
  /** Comma-separated keywords used for fuzzy matching. */
  keywords: string[]
  question: string
  answer: string
  /** Optional quick-reply chips to show after this answer. */
  followUps?: string[]
}

export interface QuickReply {
  label: string
  /** An action key the engine understands (see ChatAction in chat-engine.ts). */
  action: string
}

export interface ScriptedFlow {
  id: string
  /** Trigger keywords; if any match the user's message, this flow starts. */
  triggers: string[]
  /** Ordered list of steps. Each step is a bot message + quick replies. */
  steps: FlowStep[]
}

export interface FlowStep {
  message: string
  quickReplies?: QuickReply[]
  /** If set, this step collects input (e.g. WhatsApp number) and stores it. */
  collect?: 'whatsapp' | 'name' | 'class' | 'free'
}

// ─────────────────────────── Visitor FAQs ───────────────────────────

export const VISITOR_FAQS: FaqEntry[] = [
  {
    id: 'VF01',
    audience: ['visitor'],
    keywords: ['class', 'classes', 'grade', 'standard', 'which class', 'age', 'who'],
    question: 'Which classes is Power Maths for?',
    answer:
      'Power Maths is built for Class 8, 9 and 10 students (CBSE, ICSE and State Boards). We cover 6 chapters with 315+ practice questions, mock exams and a formula notebook.',
    followUps: ['See pricing', 'Start a free demo', 'Talk to Prof. Vyas'],
  },
  {
    id: 'VF02',
    audience: ['visitor'],
    keywords: ['price', 'pricing', 'fees', 'fee', 'cost', 'charge', 'kitne', 'how much', 'subscription', 'plan'],
    question: 'What are the fees / pricing?',
    answer:
      'We offer 3 plans:\n• Free — Chapter 1 + 30 practice questions\n• Student Pro — ₹299 / month (all chapters, exams, formula notebook)\n• School Plan — ₹99 / student / month (bulk licenses for schools)',
    followUps: ['Start a free demo', 'Talk to Prof. Vyas', 'What is included in Pro?'],
  },
  {
    id: 'VF03',
    audience: ['visitor'],
    keywords: ['demo', 'trial', 'try', 'sample', 'free', 'preview', 'test drive'],
    question: 'Can I try a demo before buying?',
    answer:
      'Yes! You can preview the full Number System chapter (theory + 10 sample questions + formula notebook) without signing up. No credit card needed.',
    followUps: ['Open free demo', 'See pricing', 'Talk to Prof. Vyas'],
  },
  {
    id: 'VF04',
    audience: ['visitor'],
    keywords: ['chapter', 'syllabus', 'topics', 'subject', 'curriculum', 'what is covered'],
    question: 'What chapters are covered?',
    answer:
      '6 chapters aligned to Class 8–10:\n1. Number System\n2. Algebra Basics\n3. Geometry\n4. Trigonometry\n5. Mensuration\n6. Statistics & Probability\nEach chapter has theory, worked examples, formulas, practice questions and a chapter test.',
    followUps: ['Start a free demo', 'See pricing'],
  },
  {
    id: 'VF05',
    audience: ['visitor'],
    keywords: ['board', 'cbse', 'icse', 'state board', 'igcse', 'ib', 'curriculum board'],
    question: 'Which education boards are supported?',
    answer:
      'Power Maths is board-agnostic — the concepts are common to CBSE, ICSE and all State Boards for Class 8–10. The question bank is designed to match the standard NCERT-aligned syllabus.',
    followUps: ['See chapters', 'Start a free demo'],
  },
  {
    id: 'VF06',
    audience: ['visitor'],
    keywords: ['language', 'hindi', 'english', 'marathi', 'gujarati', 'medium'],
    question: 'Is the content available in Hindi or regional languages?',
    answer:
      'The interface and content are currently in English (the exam language). We are working on a Hindi UI toggle for a future release. The chatbot you are talking to right now is also English-only for now.',
    followUps: ['See chapters', 'Talk to Prof. Vyas'],
  },
  {
    id: 'VF07',
    audience: ['visitor'],
    keywords: ['device', 'phone', 'mobile', 'laptop', 'tablet', 'android', 'ios', 'browser', 'app'],
    question: 'Which devices can I use Power Maths on?',
    answer:
      'Power Maths runs in any modern web browser — phone, tablet or laptop. It works on Android, iOS, Windows and macOS. No app install needed. It is mobile-optimised and works on slow connections too.',
    followUps: ['Start a free demo', 'See pricing'],
  },
  {
    id: 'VF08',
    audience: ['visitor'],
    keywords: ['certificate', 'certification', 'completion', 'achievement'],
    question: 'Do students get a certificate?',
    answer:
      'Yes! Students who pass a chapter test receive a digital certificate signed by Prof. Kalpesh Vyas, which they can download and print. Certificates are stored in their student portal.',
    followUps: ['See chapters', 'Start a free demo'],
  },
  {
    id: 'VF09',
    audience: ['visitor'],
    keywords: ['teacher', 'professor', 'kalpesh', 'vyas', 'who', 'author', 'founder'],
    question: 'Who is behind Power Maths?',
    answer:
      'Power Maths is authored by Prof. Kalpesh Vyas, a mathematics educator with years of experience coaching Class 8–10 students. The platform is designed to mirror his classroom teaching style — clear, step-by-step and exam-focused.',
    followUps: ['See chapters', 'Talk to Prof. Vyas'],
  },
  {
    id: 'VF10',
    audience: ['visitor'],
    keywords: ['refund', 'cancel', 'money back', 'cancel subscription'],
    question: 'What is the refund policy?',
    answer:
      'Student Pro subscriptions can be cancelled anytime from the settings page — you keep access until the end of your billing cycle. For a refund within the first 7 days, message Prof. Vyas on WhatsApp and we will process it within 3 working days.',
    followUps: ['Talk to Prof. Vyas', 'See pricing'],
  },
  {
    id: 'VF11',
    audience: ['visitor'],
    keywords: ['school', 'institute', 'coaching', 'tuition', 'bulk', 'institution', 'batch'],
    question: 'Do you offer school / coaching institute plans?',
    answer:
      'Yes. The School Plan is ₹99 / student / month (minimum 20 students) and includes a teacher dashboard, batch management, custom exams and bulk student import. Message Prof. Vyas on WhatsApp for a personalised quote and onboarding.',
    followUps: ['Talk to Prof. Vyas', 'See pricing'],
  },
  {
    id: 'VF12',
    audience: ['visitor'],
    keywords: ['exam', 'test', 'mock', 'assessment', 'proctored'],
    question: 'How do exams work?',
    answer:
      'Each chapter has a chapter test with a timer, instant scoring, and a detailed solution review. Proctored exams run in a lockdown mode that blocks tab-switching, copy and right-click — so they are safe for real assessments, not just practice.',
    followUps: ['See chapters', 'Start a free demo'],
  },
  {
    id: 'VF13',
    audience: ['visitor'],
    keywords: ['safe', 'secure', 'privacy', 'data', 'gdpr', 'dpdp'],
    question: 'Is my child\'s data safe?',
    answer:
      'Yes. Student data stays on the Power Maths server and is never sold. We comply with India\'s DPDP Act 2023 — parents can request a data export or deletion anytime. Only the student\'s name and progress are visible to their teacher.',
    followUps: ['Talk to Prof. Vyas', 'See chapters'],
  },
  {
    id: 'VF14',
    audience: ['visitor'],
    keywords: ['support', 'help', 'contact', 'whatsapp', 'phone', 'reach', 'email'],
    question: 'How do I contact support?',
    answer:
      'The fastest way is WhatsApp — Prof. Vyas\'s team replies within working hours (Mon–Sat, 10 AM – 7 PM IST). Tap "Talk to Prof. Vyas" and share your WhatsApp number.',
    followUps: ['Talk to Prof. Vyas'],
  },
  {
    id: 'VF15',
    audience: ['visitor'],
    keywords: ['level', 'levels', 'difficulty', 'adaptive', 'grade 7'],
    question: 'Are the questions suitable for my child\'s level?',
    answer:
      'Every chapter has questions across 12 Levels — from Level 1 (foundational entry) up to Level 12 (mastery / extension). Students can filter practice by level and progress naturally from basic recall to exam-level challenge.',
    followUps: ['See chapters', 'Start a free demo'],
  },
]

// ─────────────────────────── Student FAQs ───────────────────────────

export const STUDENT_FAQS: FaqEntry[] = [
  {
    id: 'SF01',
    audience: ['student'],
    keywords: ['password', 'reset password', 'forgot', 'change password', 'login'],
    question: 'How do I reset or change my password?',
    answer:
      'Open Settings from the left sidebar → scroll to the "Account" section → enter your new password and confirm. If you forgot your current password, ask your teacher or message Prof. Vyas on WhatsApp to reset it for you.',
    followUps: ['Open Settings', 'How do I retake an exam?'],
  },
  {
    id: 'SF02',
    audience: ['student'],
    keywords: ['retake', 'retry', 'again', 'reattempt', 'redo exam', 'repeat'],
    question: 'Can I retake an exam?',
    answer:
      'Yes. Open the Exams page, find the exam you want to retake, and click "Start" again. Each attempt is saved separately in your Results page so you can track your improvement. There is no limit on attempts for practice exams.',
    followUps: ['Open Exams', 'See my results'],
  },
  {
    id: 'SF03',
    audience: ['student'],
    keywords: ['fail', 'failed', 'passing', 'what happens if', 'retake after fail'],
    question: 'What happens if I fail an exam?',
    answer:
      'Nothing bad! Your failed attempt is saved in Results, but it does not lock you out. Review the detailed solutions, practise the weak topics, and retake the exam when you are ready. You need 50–60% (set per exam) to pass.',
    followUps: ['See my results', 'Open Practice', 'Get a hint'],
  },
  {
    id: 'SF04',
    audience: ['student'],
    keywords: ['certificate', 'download certificate', 'print', 'completion'],
    question: 'How do I download my certificate?',
    answer:
      'Open the Certificates page from the left sidebar. Any certificate you have earned will have a "Download" button. Certificates are issued automatically when you pass a chapter test for the first time.',
    followUps: ['Open Certificates'],
  },
  {
    id: 'SF05',
    audience: ['student'],
    keywords: ['formula', 'formulas', 'formula notebook', 'reference', 'cheat sheet'],
    question: 'Where can I see all the formulas?',
    answer:
      'Open any chapter and click the "Formula" tab — that opens the Formula Notebook with every formula for that chapter, sorted by category. You can search it too. Just remember: copying is disabled to protect the content.',
    followUps: ['Open My Chapters'],
  },
  {
    id: 'SF06',
    audience: ['student'],
    keywords: ['hint', 'stuck', 'help me', 'dont know', 'don\'t know', 'difficult', 'hard question'],
    question: 'I am stuck on a question. Can you help?',
    answer:
      'Yes! On any question in Practice or a chapter test, tap the "Hint" button (lightbulb icon). I will give you 3 hints — one at a time — that nudge you toward the answer without giving it away. Use them wisely: hint 1 = concept, hint 2 = formula, hint 3 = half-worked set-up.',
    followUps: ['Open Practice', 'Open My Chapters'],
  },
  {
    id: 'SF07',
    audience: ['student'],
    keywords: ['progress', 'how am i doing', 'my stats', 'my score', 'performance', 'dashboard'],
    question: 'How am I doing overall?',
    answer:
      'I can show you a quick snapshot right here — just tap "Show my progress" below. For the full view, open your Dashboard from the left sidebar.',
    followUps: ['Show my progress', 'Open Dashboard'],
  },
  {
    id: 'SF08',
    audience: ['student'],
    keywords: ['streak', 'daily', 'consecutive', 'days', 'fire'],
    question: 'What is a streak and how do I keep it?',
    answer:
      'A streak counts the number of consecutive days you have practised. Solve at least one question a day to keep your streak alive — miss a day and it resets. Streaks build consistency, which is the #1 predictor of maths improvement.',
    followUps: ['Open Practice', 'Show my progress'],
  },
  {
    id: 'SF09',
    audience: ['student'],
    keywords: ['exam', 'proctored', 'lockdown', 'tab switch', 'warning', 'rules'],
    question: 'What are the rules for a proctored exam?',
    answer:
      'Proctored exams run in lockdown mode to keep them fair:\n• Full-screen only — exiting full-screen is a warning.\n• Switching tabs or windows = 1 warning. 3 warnings and your exam auto-submits.\n• Right-click, copy and print are blocked.\n• Each student gets questions in a different order with shuffled options.\nTake a deep breath and focus — you\'ve got this!',
    followUps: ['Open Exams', 'Get a hint'],
  },
  {
    id: 'SF10',
    audience: ['student'],
    keywords: ['logout', 'sign out', 'exit', 'switch account'],
    question: 'How do I log out?',
    answer:
      'Click your name at the bottom of the left sidebar, then "Sign out". You can also use the keyboard shortcut Ctrl+K to open the command palette and search "sign out".',
    followUps: [],
  },
  {
    id: 'SF11',
    audience: ['student'],
    keywords: ['dark mode', 'theme', 'light mode', 'night mode', 'appearance'],
    question: 'How do I switch to dark mode?',
    answer:
      'Click the sun/moon icon in the top header bar (next to the search box). You can choose Light, Dark or System theme. Your choice is saved automatically.',
    followUps: [],
  },
  {
    id: 'SF12',
    audience: ['student'],
    keywords: ['notes', 'my notes', 'save note', 'bookmark'],
    question: 'Can I save my own notes?',
    answer:
      'Yes. Open the "My Notes" page from the left sidebar. You can add, edit and delete personal notes — they are private to you and saved on this device. Great for jotting down a tricky formula or a question to ask your teacher.',
    followUps: ['Open My Notes'],
  },
  {
    id: 'SF13',
    audience: ['student'],
    keywords: ['message', 'teacher', 'professor', 'ask', 'doubt', 'whatsapp'],
    question: 'How do I ask Prof. Vyas a doubt?',
    answer:
      'Two ways:\n1. Use the Messages page in the left sidebar to send an in-app message.\n2. Tap "Talk to Prof. Vyas" below and I will open WhatsApp for you with your doubt pre-filled.',
    followUps: ['Open Messages', 'Talk to Prof. Vyas'],
  },
  {
    id: 'SF14',
    audience: ['student'],
    keywords: ['notification', 'announcement', 'update', 'news', 'alert'],
    question: 'Where do I see announcements and notifications?',
    answer:
      'Click the bell icon in the top header (top-right). The Notifications page in the left sidebar also lists everything — exam schedules, new chapters, maintenance windows and your result alerts.',
    followUps: ['Open Notifications'],
  },
  {
    id: 'SF15',
    audience: ['student'],
    keywords: ['chapter', 'unlock', 'locked', 'next chapter', 'progress chapter'],
    question: 'Why is the next chapter locked?',
    answer:
      'Chapters unlock sequentially — you need to complete (and pass the chapter test of) the current chapter before the next one opens. This is to make sure you have the foundations before moving on. Keep going, you\'re nearly there!',
    followUps: ['Open My Chapters'],
  },
]

export const ALL_FAQS: FaqEntry[] = [...VISITOR_FAQS, ...STUDENT_FAQS]

// ─────────────────────────── Scripted Flows ───────────────────────────

export const VISITOR_FLOWS: ScriptedFlow[] = [
  {
    id: 'VF_CLASS',
    triggers: ['which class', 'my child', 'my son', 'my daughter', 'class 8', 'class 9', 'class 10', 'grade'],
    steps: [
      {
        message:
          'Happy to help! Power Maths is for Class 8, 9 and 10. Which class is the student in?',
        quickReplies: [
          { label: 'Class 8', action: 'flow:VF_CLASS_8' },
          { label: 'Class 9', action: 'flow:VF_CLASS_9' },
          { label: 'Class 10', action: 'flow:VF_CLASS_10' },
          { label: 'All three', action: 'flow:VF_CLASS_ALL' },
        ],
      },
    ],
  },
  {
    id: 'VF_LEAD',
    triggers: ['talk to', 'prof vyas', 'human', 'call', 'whatsapp', 'callback', 'enquire', 'enquiry'],
    steps: [
      {
        message:
          'I would love to connect you with Prof. Vyas\'s team on WhatsApp. Could you share your WhatsApp number please? (10 digits, e.g. 9876543210)',
        collect: 'whatsapp',
      },
      {
        message:
          'Thank you! And your name please?',
        collect: 'name',
      },
      {
        message:
          'Got it. Prof. Vyas\'s team will WhatsApp you within working hours (Mon–Sat, 10 AM – 7 PM IST). Meanwhile, would you like to preview a free chapter?',
        quickReplies: [
          { label: 'Yes, open free demo', action: 'nav:demo' },
          { label: 'No, I\'ll wait', action: 'flow:VF_END' },
        ],
      },
    ],
  },
  {
    id: 'VF_PRICING',
    triggers: ['pricing', 'price', 'plans', 'how much'],
    steps: [
      {
        message:
          'Here are our plans:\n\n• Free — Chapter 1 + 30 questions. ₹0 forever.\n• Student Pro — ₹299 / month. All 6 chapters, 315+ questions, mock exams, formula notebook, certificates.\n• School — ₹99 / student / month (min 20 students). Teacher dashboard + bulk import.\n\nWhich one sounds right for you?',
        quickReplies: [
          { label: 'Student Pro', action: 'flow:VF_LEAD' },
          { label: 'School plan', action: 'flow:VF_LEAD' },
          { label: 'Just the free demo', action: 'nav:demo' },
          { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
        ],
      },
    ],
  },
]

export const STUDENT_FLOWS: ScriptedFlow[] = [
  {
    id: 'SF_PROGRESS',
    triggers: ['how am i doing', 'my progress', 'my stats', 'show my progress', 'progress'],
    steps: [
      {
        message:
          'Here is your snapshot — I\'ll fetch it now. Tap "See full dashboard" for the detailed view.',
        quickReplies: [
          { label: 'See full dashboard', action: 'nav:dashboard' },
          { label: 'Open Practice', action: 'nav:practice' },
        ],
      },
    ],
  },
  {
    id: 'SF_HANDOFF',
    triggers: ['talk to prof', 'human', 'whatsapp', 'teacher', 'doubt'],
    steps: [
      {
        message:
          'I can open WhatsApp for you so you can chat with Prof. Vyas\'s team directly. Want me to?',
        quickReplies: [
          { label: 'Yes, open WhatsApp', action: 'handoff:whatsapp' },
          { label: 'No, stay here', action: 'flow:SF_END' },
        ],
      },
    ],
  },
]

// ─────────────────────────── Welcome messages ───────────────────────────

export const VISITOR_WELCOME = {
  message:
    'Hi! I\'m Friend, Prof. Vyas\'s assistant. I can help you explore Power Maths, see pricing, or start a free demo. What would you like to do?',
  quickReplies: [
    { label: 'Which class is this for?', action: 'flow:VF_CLASS' },
    { label: 'See pricing', action: 'flow:VF_PRICING' },
    { label: 'Start a free demo', action: 'nav:demo' },
    { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
  ],
}

export const STUDENT_WELCOME = {
  message:
    'Hi! I\'m Friend, your study buddy. I can help you find things, give you hints on questions, or look up formulas. What do you need?',
  quickReplies: [
    { label: 'Show my progress', action: 'flow:SF_PROGRESS' },
    { label: 'Open Practice', action: 'nav:practice' },
    { label: 'Open My Chapters', action: 'nav:chapters' },
    { label: 'Get a hint', action: 'hint:howto' },
  ],
}

// ─────────────────────────── Handoff config ───────────────────────────

/**
 * Prof. Vyas's WhatsApp number in international format (without + or spaces).
 * The chatbot builds a wa.me link with a pre-filled message.
 * Update this number when the client confirms the real one.
 */
export const WHATSAPP_NUMBER = '919876543210'
export const WHATSAPP_DISPLAY = '+91 98765 43210'

export function buildWhatsappLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`
}

// ─────────────────────────── Default quick replies ───────────────────────────

export const VISITOR_DEFAULT_REPLIES: QuickReply[] = [
  { label: 'See pricing', action: 'flow:VF_PRICING' },
  { label: 'Start a free demo', action: 'nav:demo' },
  { label: 'Talk to Prof. Vyas', action: 'flow:VF_LEAD' },
]

export const STUDENT_DEFAULT_REPLIES: QuickReply[] = [
  { label: 'Show my progress', action: 'flow:SF_PROGRESS' },
  { label: 'Open Practice', action: 'nav:practice' },
  { label: 'Open My Chapters', action: 'nav:chapters' },
  { label: 'Talk to Prof. Vyas', action: 'flow:SF_HANDOFF' },
]
