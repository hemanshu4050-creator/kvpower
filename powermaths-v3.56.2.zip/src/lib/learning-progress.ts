'use client'

// ============================================================
// Learning Progress Store
// ------------------------------------------------------------
// Tracks per-student, per-chapter learning state:
//   • Which study materials have been viewed (and to what depth)
//   • Practice sheet progress (started / attempted / completed / time)
//   • PDF reading progress (last page, reading %, time spent, last visit)
//   • Aggregated chapter completion % used by the chapter list + lock logic
//
// Persisted to localStorage under `pm-learning-progress` so students can
// resume exactly where they left off across sessions / refreshes.
// ============================================================

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

// ─────────────────────── Types ───────────────────────

export interface MaterialProgress {
  materialId: string
  viewed: boolean
  firstViewedAt?: string
  lastViewedAt?: string
  /** 0–100 — how far through the PDF the student read. */
  readPercent: number
  /** Seconds spent reading this material. */
  timeSpentSeconds: number
  lastPage?: number
  totalPages?: number
}

export interface PracticeProgress {
  practiceId: string
  status: 'not_started' | 'in_progress' | 'completed'
  startedAt?: string
  completedAt?: string
  /** How many questions the student has attempted. */
  attempted: number
  /** Total questions in this practice sheet (set when started). */
  totalQuestions: number
  /** Seconds spent on this practice sheet. */
  timeSpentSeconds: number
  lastActiveAt?: string
}

export interface ChapterProgressState {
  chapterId: string
  materials: Record<string, MaterialProgress>
  practice: Record<string, PracticeProgress>
  /** v3.12.0 — formula notebook viewing progress. */
  formulas: Record<string, FormulaProgress>
  /** v3.12.0 — theory textbook reading progress. */
  theories: Record<string, TheoryProgress>
  /** ISO timestamp of the first time the student opened this chapter. */
  firstOpenedAt?: string
  /** ISO timestamp of the most recent visit. */
  lastVisitedAt?: string
  /** Total seconds spent on this chapter (materials + practice + theory). */
  totalTimeSpentSeconds: number
}

export interface FormulaProgress {
  formulaId: string
  viewed: boolean
  firstViewedAt?: string
  lastViewedAt?: string
  timeSpentSeconds: number
}

export interface TheoryProgress {
  theoryId: string
  /** 0–100 — how far the student has scrolled/read. */
  readPercent: number
  timeSpentSeconds: number
  lastReadAt?: string
  firstReadAt?: string
}

interface LearningProgressState {
  /** Keyed by `${studentId}:${chapterId}` */
  chapters: Record<string, ChapterProgressState>

  // ── Material actions ──
  markMaterialViewed: (
    studentId: string,
    chapterId: string,
    materialId: string,
    meta?: { totalPages?: number }
  ) => void
  updateMaterialReadProgress: (
    studentId: string,
    chapterId: string,
    materialId: string,
    meta: { page: number; totalPages: number; timeSpentDeltaSeconds?: number }
  ) => void

  // ── Practice actions ──
  startPractice: (
    studentId: string,
    chapterId: string,
    practiceId: string,
    totalQuestions: number
  ) => void
  updatePracticeProgress: (
    studentId: string,
    chapterId: string,
    practiceId: string,
    meta: { attemptedDelta?: number; timeSpentDeltaSeconds?: number }
  ) => void
  completePractice: (
    studentId: string,
    chapterId: string,
    practiceId: string
  ) => void

  // ── Chapter actions ──
  touchChapter: (studentId: string, chapterId: string) => void
  resetChapter: (studentId: string, chapterId: string) => void

  // ── Formula actions (v3.12.0) ──
  markFormulaViewed: (
    studentId: string,
    chapterId: string,
    formulaId: string,
    meta?: { timeSpentDeltaSeconds?: number }
  ) => void

  // ── Theory actions (v3.12.0) ──
  updateTheoryReadProgress: (
    studentId: string,
    chapterId: string,
    theoryId: string,
    meta: { readPercent: number; timeSpentDeltaSeconds?: number }
  ) => void
}

// ─────────────────────── Helpers ───────────────────────

const key = (studentId: string, chapterId: string) => `${studentId}:${chapterId}`

const nowIso = () => new Date().toISOString()

function ensureChapter(
  state: LearningProgressState,
  studentId: string,
  chapterId: string
): ChapterProgressState {
  const k = key(studentId, chapterId)
  const existing = state.chapters[k]
  if (existing) {
    // Backfill v3.12.0 fields on older persisted states.
    return {
      ...existing,
      formulas: existing.formulas ?? {},
      theories: existing.theories ?? {},
    }
  }
  return {
    chapterId,
    materials: {},
    practice: {},
    formulas: {},
    theories: {},
    firstOpenedAt: nowIso(),
    lastVisitedAt: nowIso(),
    totalTimeSpentSeconds: 0,
  }
}

// ─────────────────────── Store ───────────────────────

export const useLearningProgress = create<LearningProgressState>()(
  persist(
    (set, get) => ({
      chapters: {},

      markMaterialViewed: (studentId, chapterId, materialId, meta) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prevMat = cur.materials[materialId]
          const mat: MaterialProgress = {
            materialId,
            viewed: true,
            firstViewedAt: prevMat?.firstViewedAt ?? nowIso(),
            lastViewedAt: nowIso(),
            readPercent: prevMat?.readPercent ?? 0,
            timeSpentSeconds: prevMat?.timeSpentSeconds ?? 0,
            lastPage: prevMat?.lastPage,
            totalPages: meta?.totalPages ?? prevMat?.totalPages,
          }
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                materials: { ...cur.materials, [materialId]: mat },
              },
            },
          }
        })
      },

      updateMaterialReadProgress: (studentId, chapterId, materialId, meta) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prevMat = cur.materials[materialId]
          const readPercent = meta.totalPages > 0
            ? Math.min(100, Math.round(((meta.page + 1) / meta.totalPages) * 100))
            : (prevMat?.readPercent ?? 0)
          const mat: MaterialProgress = {
            materialId,
            viewed: true,
            firstViewedAt: prevMat?.firstViewedAt ?? nowIso(),
            lastViewedAt: nowIso(),
            readPercent: Math.max(readPercent, prevMat?.readPercent ?? 0),
            timeSpentSeconds:
              (prevMat?.timeSpentSeconds ?? 0) + (meta.timeSpentDeltaSeconds ?? 0),
            lastPage: Math.max(meta.page, prevMat?.lastPage ?? 0),
            totalPages: meta.totalPages,
          }
          // Recompute total time across all materials + practice for this chapter.
          const totalTimeSpentSeconds =
            Object.values({ ...cur.materials, [materialId]: mat }).reduce(
              (a, m) => a + (m.timeSpentSeconds ?? 0),
              0
            ) +
            Object.values(cur.practice).reduce(
              (a, p) => a + (p.timeSpentSeconds ?? 0),
              0
            )
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                totalTimeSpentSeconds,
                materials: { ...cur.materials, [materialId]: mat },
              },
            },
          }
        })
      },

      startPractice: (studentId, chapterId, practiceId, totalQuestions) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prev = cur.practice[practiceId]
          // Don't downgrade a completed practice.
          if (prev?.status === 'completed') return {}
          const pp: PracticeProgress = {
            practiceId,
            status: 'in_progress',
            startedAt: prev?.startedAt ?? nowIso(),
            completedAt: undefined,
            attempted: prev?.attempted ?? 0,
            totalQuestions,
            timeSpentSeconds: prev?.timeSpentSeconds ?? 0,
            lastActiveAt: nowIso(),
          }
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                practice: { ...cur.practice, [practiceId]: pp },
              },
            },
          }
        })
      },

      updatePracticeProgress: (studentId, chapterId, practiceId, meta) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prev = cur.practice[practiceId]
          if (!prev) return {}
          if (prev.status === 'completed') return {}
          const attempted = Math.max(0, prev.attempted + (meta.attemptedDelta ?? 0))
          const timeSpentSeconds = prev.timeSpentSeconds + (meta.timeSpentDeltaSeconds ?? 0)
          // Auto-complete when all questions are attempted.
          const status: PracticeProgress['status'] =
            attempted >= prev.totalQuestions && prev.totalQuestions > 0
              ? 'completed'
              : 'in_progress'
          const pp: PracticeProgress = {
            ...prev,
            attempted,
            timeSpentSeconds,
            status,
            completedAt: status === 'completed' ? nowIso() : undefined,
            lastActiveAt: nowIso(),
          }
          const totalTimeSpentSeconds =
            Object.values(cur.materials).reduce(
              (a, m) => a + (m.timeSpentSeconds ?? 0),
              0
            ) +
            Object.values({ ...cur.practice, [practiceId]: pp }).reduce(
              (a, p) => a + (p.timeSpentSeconds ?? 0),
              0
            )
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                totalTimeSpentSeconds,
                practice: { ...cur.practice, [practiceId]: pp },
              },
            },
          }
        })
      },

      completePractice: (studentId, chapterId, practiceId) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prev = cur.practice[practiceId]
          if (!prev) return {}
          const pp: PracticeProgress = {
            ...prev,
            status: 'completed',
            completedAt: nowIso(),
            lastActiveAt: nowIso(),
            attempted: Math.max(prev.attempted, prev.totalQuestions),
          }
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                practice: { ...cur.practice, [practiceId]: pp },
              },
            },
          }
        })
      },

      touchChapter: (studentId, chapterId) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                firstOpenedAt: cur.firstOpenedAt ?? nowIso(),
              },
            },
          }
        })
      },

      resetChapter: (studentId, chapterId) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const next = { ...s.chapters }
          delete next[k]
          return { chapters: next }
        })
      },

      // ── Formula actions (v3.12.0) ──
      markFormulaViewed: (studentId, chapterId, formulaId, meta) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prev = cur.formulas[formulaId]
          const fp: FormulaProgress = {
            formulaId,
            viewed: true,
            firstViewedAt: prev?.firstViewedAt ?? nowIso(),
            lastViewedAt: nowIso(),
            timeSpentSeconds: (prev?.timeSpentSeconds ?? 0) + (meta?.timeSpentDeltaSeconds ?? 0),
          }
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                formulas: { ...cur.formulas, [formulaId]: fp },
              },
            },
          }
        })
      },

      // ── Theory actions (v3.12.0) ──
      updateTheoryReadProgress: (studentId, chapterId, theoryId, meta) => {
        set((s) => {
          const k = key(studentId, chapterId)
          const cur = ensureChapter(s, studentId, chapterId)
          const prev = cur.theories[theoryId]
          const tp: TheoryProgress = {
            theoryId,
            readPercent: Math.max(prev?.readPercent ?? 0, Math.min(100, meta.readPercent)),
            timeSpentSeconds: (prev?.timeSpentSeconds ?? 0) + (meta.timeSpentDeltaSeconds ?? 0),
            firstReadAt: prev?.firstReadAt ?? nowIso(),
            lastReadAt: nowIso(),
          }
          // Recompute total time including theory reading.
          const theoryTime = Object.values({ ...cur.theories, [theoryId]: tp }).reduce(
            (a, t) => a + (t.timeSpentSeconds ?? 0),
            0
          )
          const materialsTime = Object.values(cur.materials).reduce(
            (a, m) => a + (m.timeSpentSeconds ?? 0),
            0
          )
          const practiceTime = Object.values(cur.practice).reduce(
            (a, p) => a + (p.timeSpentSeconds ?? 0),
            0
          )
          return {
            chapters: {
              ...s.chapters,
              [k]: {
                ...cur,
                lastVisitedAt: nowIso(),
                totalTimeSpentSeconds: materialsTime + practiceTime + theoryTime,
                theories: { ...cur.theories, [theoryId]: tp },
              },
            },
          }
        })
      },
    }),
    {
      name: 'pm-learning-progress',
      version: 2,
      storage: createJSONStorage(() =>
        typeof window !== 'undefined' ? localStorage : (undefined as unknown as Storage)
      ),
      partialize: (s) => ({ chapters: s.chapters }),
      migrate: (persisted: unknown) => {
        // v1 → v2: backfill `formulas` and `theories` maps on every
        // existing chapter progress entry so the new fields exist.
        const p = (persisted || {}) as { chapters?: Record<string, ChapterProgressState> }
        if (!p.chapters || typeof p.chapters !== 'object') return p as LearningProgressState
        const chapters: Record<string, ChapterProgressState> = {}
        for (const [k, v] of Object.entries(p.chapters)) {
          chapters[k] = {
            ...v,
            formulas: v.formulas ?? {},
            theories: v.theories ?? {},
          }
        }
        return { chapters } as LearningProgressState
      },
    }
  )
)

// ─────────────────────── Selectors / Helpers ───────────────────────

/**
 * Returns the ChapterProgressState for a student + chapter (or a blank
 * default if the student has never opened the chapter).
 */
export function getChapterProgress(
  studentId: string,
  chapterId: string
): ChapterProgressState {
  const k = key(studentId, chapterId)
  const cur = useLearningProgress.getState().chapters[k]
  if (cur) {
    return {
      ...cur,
      formulas: cur.formulas ?? {},
      theories: cur.theories ?? {},
    }
  }
  return {
    chapterId,
    materials: {},
    practice: {},
    formulas: {},
    theories: {},
    totalTimeSpentSeconds: 0,
  }
}

/**
 * Compute the chapter's overall learning progress percentage using the
 * v3.12.0 five-component learning sequence:
 *   • Theory            — 15% weight (avg readPercent across sections)
 *   • Materials viewed   — 25% weight (depth-weighted: 50% for opening,
 *     full credit at ≥80% read)
 *   • Formula revision  — 10% weight (viewed formulas / total formulas)
 *   • Practice sheets   — 25% weight (completed / total, partial credit)
 *   • Chapter test      — 25% weight (100% if passed, else 0%)
 *
 * The weights reflect the recommended learning sequence: Theory → Materials
 * → Formula revision → Practice → Test. Returns 0–100.
 */
export interface ChapterCompletionInput {
  materialIds: string[]
  practiceIds: string[]
  formulaIds: string[]
  theoryIds: string[]
  testPassed: boolean
  /**
   * v3.13.0 — which content tabs the admin has left visible for this chapter.
   * Hidden tabs (and tabs with zero content) are excluded from BOTH the
   * weighted sum and the denominator, so the remaining weights are
   * renormalised to 100%. This means a student can complete a chapter
   * without touching hidden tabs (e.g. admin hides Theory → the chapter is
   * fully completable via Materials + Formula + Practice + Test).
   *
   * If omitted, all five tabs are treated as active (legacy behaviour).
   */
  activeTabs?: Set<string>
}

export function computeChapterCompletion(
  progress: ChapterProgressState,
  input: ChapterCompletionInput
): number {
  const active =
    input.activeTabs ??
    new Set(['theory', 'materials', 'formula', 'practice', 'test'])

  // Early-out when there is literally nothing to compute.
  if (
    input.materialIds.length === 0 &&
    input.practiceIds.length === 0 &&
    input.formulaIds.length === 0 &&
    input.theoryIds.length === 0 &&
    !input.testPassed
  ) {
    return 0
  }
  const theoryWeight = 0.15
  const materialsWeight = 0.25
  const formulaWeight = 0.10
  const practiceWeight = 0.25
  const testWeight = 0.25

  // Theory: average readPercent across all sections (0–100 → 0–1).
  const theoryScore =
    input.theoryIds.length > 0
      ? input.theoryIds.reduce((acc, id) => {
          const t = (progress.theories ?? {})[id]
          return acc + ((t?.readPercent ?? 0) / 100)
        }, 0) / input.theoryIds.length
      : 0

  // Materials: each viewed material counts; deeper-read materials count more.
  const materialsScore =
    input.materialIds.length > 0
      ? input.materialIds.reduce((acc, id) => {
          const m = progress.materials[id]
          if (!m || !m.viewed) return acc
          // 50% credit for opening, full credit for reading ≥80% of pages.
          const depth = Math.min(1, 0.5 + (m.readPercent / 100) * 0.5)
          return acc + depth
        }, 0) / input.materialIds.length
      : 0

  // Formula revision: viewed formulas / total formulas.
  const formulaScore =
    input.formulaIds.length > 0
      ? input.formulaIds.reduce((acc, id) => {
          const f = (progress.formulas ?? {})[id]
          return acc + (f?.viewed ? 1 : 0)
        }, 0) / input.formulaIds.length
      : 0

  const practiceScore =
    input.practiceIds.length > 0
      ? input.practiceIds.reduce((acc, id) => {
          const p = progress.practice[id]
          if (!p) return acc
          if (p.status === 'completed') return acc + 1
          if (p.status === 'in_progress' && p.totalQuestions > 0) {
            return acc + Math.min(0.7, p.attempted / p.totalQuestions * 0.7)
          }
          return acc
        }, 0) / input.practiceIds.length
      : 0

  const testScore = input.testPassed ? 1 : 0

  // v3.13.0 — Weight renormalisation. A tab contributes to the final
  // percentage ONLY when it is BOTH admin-visible AND has content (test is
  // treated as always having "content" since testPassed is the only signal).
  // Hidden / empty tabs drop out of both the numerator and the denominator,
  // so the visible, non-empty tabs' weights are rescaled to sum to 100%.
  let weightedSum = 0
  let totalWeight = 0
  if (active.has('theory') && input.theoryIds.length > 0) {
    weightedSum += theoryScore * theoryWeight
    totalWeight += theoryWeight
  }
  if (active.has('materials') && input.materialIds.length > 0) {
    weightedSum += materialsScore * materialsWeight
    totalWeight += materialsWeight
  }
  if (active.has('formula') && input.formulaIds.length > 0) {
    weightedSum += formulaScore * formulaWeight
    totalWeight += formulaWeight
  }
  if (active.has('practice') && input.practiceIds.length > 0) {
    weightedSum += practiceScore * practiceWeight
    totalWeight += practiceWeight
  }
  if (active.has('test')) {
    weightedSum += testScore * testWeight
    totalWeight += testWeight
  }

  if (totalWeight === 0) return 0
  return Math.round(Math.min(100, Math.max(0, (weightedSum / totalWeight) * 100)))
}

/**
 * Format a duration in seconds as `Xh Ym` or `Ym Zs` for compact display.
 */
export function formatDuration(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds))
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ${s % 60}s`
  const h = Math.floor(m / 60)
  return `${h}h ${m % 60}m`
}
