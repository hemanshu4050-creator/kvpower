'use client'

// ============================================================
// Power Maths — Admin Portal Snapshot PDF Generator (v3.32.0)
// Generates a 1–2 page PDF snapshot of the entire portal:
//   • Power Maths logo on top
//   • Summary KPIs (students, batches, chapters, exams, questions,
//     certificates, materials, formulas, theory sections, pass rate)
//   • Per-chapter breakdown table:
//       Theory · Materials · Formula · Practice · Tests · Questions
// Used by admin-dashboard.tsx → "Export Snapshot" button.
// ============================================================

import { jsPDF } from 'jspdf'

// ── Types (mirror data-store interfaces; kept loose to avoid circular
//    imports — callers pass plain objects) ───────────────────────
export interface SnapshotChapter {
  id: string
  name: string
  order: number
  status: 'active' | 'draft'
  theories: unknown[]
  studyMaterials: unknown[]
  formulas: unknown[]
  practiceSheets: unknown[]
  tests: unknown[]
}

export interface SnapshotQuestion {
  id: string
  chapterIds: string[]
}

export interface SnapshotExam {
  id: string
  title: string
  status: 'published' | 'draft'
}

export interface SnapshotResult {
  id: string
  status: 'passed' | 'failed'
  percentage: number
}

export interface SnapshotCertificate {
  id: string
  status: 'issued' | 'revoked'
}

export interface SnapshotStudent {
  id: string
  status: 'active' | 'inactive' | 'suspended'
  batch?: string // batch name (Student.batch) — used to count students per level
}

export interface SnapshotBatch {
  id: string
  name: string            // display name, e.g. "Level One" / "Batch 2026-A"
  code?: string           // short code, e.g. "PM26-A"
  status: 'active' | 'inactive' | 'archived'
  chapterIds: string[]    // chapters assigned to this level/batch
  examIds: string[]       // exams assigned to this level/batch
}

export interface SnapshotInput {
  students: SnapshotStudent[]
  batches: SnapshotBatch[]
  chapters: SnapshotChapter[]
  questions: SnapshotQuestion[]
  exams: SnapshotExam[]
  results: SnapshotResult[]
  certificates: SnapshotCertificate[]
  adminName?: string
  logoUrl?: string // defaults to /branding/power-maths-logo.png
}

// ── Color palette (matches the emerald brand) ───────────────────
const C = {
  brand:     [16, 185, 129] as [number, number, number],   // emerald-500
  brandDark: [4, 120, 87]   as [number, number, number],   // emerald-700
  brandLite: [209, 250, 229] as [number, number, number],  // emerald-100
  ink:       [24, 24, 27]   as [number, number, number],   // zinc-900
  inkSoft:   [82, 82, 91]   as [number, number, number],   // zinc-600
  muted:     [161, 161, 170] as [number, number, number],  // zinc-400
  line:      [228, 228, 231] as [number, number, number],  // zinc-200
  lineDark:  [212, 212, 216] as [number, number, number],  // zinc-300
  bg:        [250, 250, 250] as [number, number, number],  // zinc-50
  bgAlt:     [244, 244, 245] as [number, number, number],  // zinc-100
  white:     [255, 255, 255] as [number, number, number],
  teal:      [13, 148, 136]  as [number, number, number],  // teal-600
  amber:     [217, 119, 6]   as [number, number, number],  // amber-600
  violet:    [124, 58, 237]  as [number, number, number],  // violet-600
  rose:      [225, 29, 72]   as [number, number, number],  // rose-600
  sky:       [2, 132, 199]   as [number, number, number],  // sky-600
}

// ── Helpers ─────────────────────────────────────────────────────
function fmtDate(d: Date): string {
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function fmtDateTime(d: Date): string {
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

/**
 * Fetch a static image URL and rasterize it through a canvas to produce
 * a clean JPEG data URL with no alpha channel. jsPDF v4's PNG encoder
 * struggles with RGBA images (throws "Invalid argument passed to jsPDF"),
 * so we flatten the logo onto a white background — which matches the
 * white circular backdrop we draw behind the logo in the PDF anyway.
 *
 * Returns null if anything fails (caller falls back to a "PM" text mark).
 */
async function fetchImageAsDataUrl(url: string): Promise<{ dataUrl: string; format: 'JPEG' } | null> {
  try {
    const res = await fetch(url, { cache: 'no-cache' })
    if (!res.ok) return null
    const blob = await res.blob()
    const objectUrl = URL.createObjectURL(blob)
    const img = new Image()
    img.crossOrigin = 'anonymous'
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve()
      img.onerror = () => reject(new Error('img load failed'))
      img.src = objectUrl
    })
    // Render at 2× for crisp output in the PDF
    const scale = 2
    const canvas = document.createElement('canvas')
    canvas.width = img.naturalWidth * scale
    canvas.height = img.naturalHeight * scale
    const ctx = canvas.getContext('2d')
    if (!ctx) {
      URL.revokeObjectURL(objectUrl)
      return null
    }
    // White background (flattens alpha)
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    URL.revokeObjectURL(objectUrl)
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92)
    return { dataUrl, format: 'JPEG' }
  } catch {
    return null
  }
}

// ─────────────────────────────────────────────────────────────────
//  MAIN GENERATOR (async — fetches logo first)
// ─────────────────────────────────────────────────────────────────
export async function generateAdminSnapshotPdf(input: SnapshotInput): Promise<void> {
  const {
    students,
    batches,
    chapters,
    questions,
    exams,
    results,
    certificates,
    adminName = 'Prof. Kalpesh Vyas',
    logoUrl = '/branding/power-maths-logo.png',
  } = input

  // ── Fetch logo (so we can embed it in the PDF) ──
  const logo = await fetchImageAsDataUrl(logoUrl)

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const W = doc.internal.pageSize.getWidth()   // 595
  const H = doc.internal.pageSize.getHeight()  // 842
  const M = 40 // margin
  const contentW = W - M * 2

  const now = new Date()
  const reportDate = fmtDate(now)
  const reportId = `PM-SNAP-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`

  // ── Derived stats ──
  const totalStudents = students.length
  const activeStudents = students.filter((s) => s.status === 'active').length
  const totalBatches = batches.length
  const activeBatches = batches.filter((b) => b.status === 'active').length
  const totalChapters = chapters.length
  const activeChapters = chapters.filter((c) => c.status === 'active').length
  const totalExams = exams.length
  const publishedExams = exams.filter((e) => e.status === 'published').length
  const totalQuestions = questions.length
  const totalCerts = certificates.filter((c) => c.status === 'issued').length
  const totalTheory = chapters.reduce((a, c) => a + (c.theories?.length || 0), 0)
  const totalMaterials = chapters.reduce((a, c) => a + (c.studyMaterials?.length || 0), 0)
  const totalFormulas = chapters.reduce((a, c) => a + (c.formulas?.length || 0), 0)
  const totalPractice = chapters.reduce((a, c) => a + (c.practiceSheets?.length || 0), 0)
  const totalTests = chapters.reduce((a, c) => a + (c.tests?.length || 0), 0)
  const passRate = results.length
    ? Math.round((results.filter((r) => r.status === 'passed').length / results.length) * 100)
    : 0
  const avgScore = results.length
    ? Math.round(results.reduce((a, r) => a + r.percentage, 0) / results.length)
    : 0

  // ── Per-chapter breakdown rows ──
  const chapterRows = [...chapters]
    .sort((a, b) => (a.order || 0) - (b.order || 0))
    .map((c) => {
      const qCount = questions.filter((q) => Array.isArray(q.chapterIds) && q.chapterIds.includes(c.id)).length
      return {
        id: c.id,
        name: c.name,
        status: c.status,
        theory: c.theories?.length || 0,
        materials: c.studyMaterials?.length || 0,
        formula: c.formulas?.length || 0,
        practice: c.practiceSheets?.length || 0,
        tests: c.tests?.length || 0,
        questions: qCount,
      }
    })

  // ── Per-level/batch breakdown rows ──
  // For each batch (a.k.a. "Level" in the UI) we aggregate:
  //   • chapters assigned (batch.chapterIds)
  //   • students enrolled (Student.batch === batch.name)
  //   • exams assigned (batch.examIds)
  //   • content totals summed across the batch's assigned chapters
  //   • questions whose chapterIds intersect the batch's chapters
  const batchRows = [...batches]
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
    .map((b) => {
      const cIds = Array.isArray(b.chapterIds) ? b.chapterIds : []
      const eIds = Array.isArray(b.examIds) ? b.examIds : []
      const assignedChapters = chapters.filter((c) => cIds.includes(c.id))
      const studentCount = students.filter(
        (s) => s.batch && s.batch === b.name,
      ).length
      const materials = assignedChapters.reduce((a, c) => a + (c.studyMaterials?.length || 0), 0)
      const formulas = assignedChapters.reduce((a, c) => a + (c.formulas?.length || 0), 0)
      const practice = assignedChapters.reduce((a, c) => a + (c.practiceSheets?.length || 0), 0)
      const tests = assignedChapters.reduce((a, c) => a + (c.tests?.length || 0), 0)
      const qCount = questions.filter(
        (q) => Array.isArray(q.chapterIds) && q.chapterIds.some((id) => cIds.includes(id)),
      ).length
      return {
        id: b.id,
        name: b.name,
        code: b.code,
        status: b.status,
        chapters: cIds.length,
        students: studentCount,
        exams: eIds.length,
        materials,
        formulas,
        practice,
        tests,
        questions: qCount,
      }
    })

  // ── Page header / footer ──
  // We draw headers inline (during content layout) but DEFER footers to
  // a final pass — that way each footer can show the correct "Page X of Y"
  // once we know the total page count.
  let page = 1

  function drawHeader() {
    // Brand bar (top stripe)
    doc.setFillColor(...C.brand)
    doc.rect(0, 0, W, 6, 'F')

    // Logo (circular badge) — embed the real Power Maths logo image
    const logoSize = 34
    const logoX = M
    const logoY = 18
    if (logo) {
      try {
        // White circular backdrop so the logo's transparency looks clean
        doc.setFillColor(...C.white)
        doc.circle(logoX + logoSize / 2, logoY + logoSize / 2, logoSize / 2 + 2, 'F')
        doc.setDrawColor(...C.line)
        doc.setLineWidth(0.5)
        doc.circle(logoX + logoSize / 2, logoY + logoSize / 2, logoSize / 2 + 2, 'S')
        // Embed the image (contain inside the circle via a square clip region)
        doc.addImage(
          logo.dataUrl,
          logo.format,
          logoX,
          logoY,
          logoSize,
          logoSize,
          undefined,
          'FAST',
        )
      } catch {
        drawTextLogo(logoX, logoY, logoSize)
      }
    } else {
      drawTextLogo(logoX, logoY, logoSize)
    }

    // Title block to the right of the logo
    doc.setTextColor(...C.ink)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(14)
    doc.text('Power Maths', M + logoSize + 12, 30)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(9)
    doc.setTextColor(...C.inkSoft)
    doc.text('Portal Snapshot · by ' + adminName, M + logoSize + 12, 44)

    // Right: report id + date
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(reportId, W - M, 28, { align: 'right' })
    doc.text(reportDate, W - M, 40, { align: 'right' })

    // Divider
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, 60, W - M, 60)
  }

  function drawTextLogo(x: number, y: number, size: number) {
    doc.setFillColor(...C.brandDark)
    doc.roundedRect(x, y, size, size, 5, 5, 'F')
    doc.setTextColor(...C.white)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(14)
    doc.text('PM', x + size / 2, y + size / 2 + 5, { align: 'center' })
  }

  function drawFooter(pageNum: number, totalPages: number) {
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.line(M, H - 30, W - M, H - 30)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(`Power Maths · ${adminName}`, M, H - 18)
    doc.text(`Generated ${fmtDateTime(now)}`, W / 2, H - 18, { align: 'center' })
    doc.text(`Page ${pageNum} of ${totalPages}`, W - M, H - 18, { align: 'right' })
  }

  function newPage() {
    doc.addPage()
    page++
    drawHeader()
    return 78 // top y
  }

  // ═══════════════════════════════════════════════════════════════
  //  PAGE 1 — TITLE + SUMMARY KPIs
  // ═══════════════════════════════════════════════════════════════
  drawHeader()

  // Title band
  let y = 80
  doc.setFillColor(...C.bg)
  doc.rect(M, y, contentW, 56, 'F')
  doc.setFillColor(...C.brand)
  doc.rect(M, y, contentW, 3, 'F')
  doc.setTextColor(...C.ink)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(18)
  doc.text('Portal Snapshot Report', M + 16, y + 26)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9.5)
  doc.setTextColor(...C.inkSoft)
  doc.text(
    `A quick overview of students, chapters, content, exams & certifications.`,
    M + 16,
    y + 44,
  )
  y += 76

  // ── Summary KPI grid (4 cols × 3 rows = 12 cards) ──
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.setTextColor(...C.ink)
  doc.text('At a Glance', M, y)
  y += 6
  doc.setDrawColor(...C.line)
  doc.setLineWidth(0.5)
  doc.line(M, y, M + 120, y)
  y += 16

  const kpis = [
    { label: 'Total Students',   value: totalStudents,    sub: `${activeStudents} active`,                   color: C.brand },
    { label: 'Total Batches',    value: totalBatches,     sub: `${activeBatches} active`,                    color: C.teal },
    { label: 'Total Chapters',   value: totalChapters,    sub: `${activeChapters} active`,                   color: C.sky },
    { label: 'Total Exams',      value: totalExams,       sub: `${publishedExams} published`,                color: C.violet },
    { label: 'Question Bank',    value: totalQuestions,   sub: 'across all chapters',                        color: C.amber },
    { label: 'Certificates',     value: totalCerts,       sub: 'issued to students',                         color: C.rose },
    { label: 'Theory Sections',  value: totalTheory,      sub: 'across all chapters',                        color: C.brandDark },
    { label: 'Study Materials',  value: totalMaterials,   sub: 'worksheets + PDFs',                          color: C.teal },
    { label: 'Formulas',         value: totalFormulas,    sub: 'reference cards',                            color: C.sky },
    { label: 'Practice Sheets',  value: totalPractice,    sub: 'across all chapters',                        color: C.violet },
    { label: 'Chapter Tests',    value: totalTests,       sub: 'built per chapter',                          color: C.amber },
    { label: 'Pass Rate',        value: `${passRate}%`,   sub: `avg score ${avgScore}%`,                     color: C.brand },
  ]

  const cols = 4
  const gap = 10
  const kpiW = (contentW - gap * (cols - 1)) / cols
  const kpiH = 64
  const rows = Math.ceil(kpis.length / cols)
  kpis.forEach((k, i) => {
    const col = i % cols
    const row = Math.floor(i / cols)
    const x = M + col * (kpiW + gap)
    const ky = y + row * (kpiH + gap)
    doc.setFillColor(...C.white)
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.5)
    doc.roundedRect(x, ky, kpiW, kpiH, 5, 5, 'FD')
    // Accent stripe
    doc.setFillColor(...k.color)
    doc.roundedRect(x, ky, 3, kpiH, 1.5, 1.5, 'F')
    // Label
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.muted)
    doc.text(k.label.toUpperCase(), x + 12, ky + 16)
    // Value
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(20)
    doc.setTextColor(...C.ink)
    doc.text(String(k.value), x + 12, ky + 42)
    // Sub
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.inkSoft)
    doc.text(k.sub, x + 12, ky + 56)
  })

  y += rows * (kpiH + gap) + 10

  // ── Per-chapter breakdown table ──
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.setTextColor(...C.ink)
  doc.text('Chapter-wise Content Breakdown', M, y)
  y += 6
  doc.setDrawColor(...C.line)
  doc.setLineWidth(0.5)
  doc.line(M, y, M + 260, y)
  y += 12

  // Table header
  const tableCols = [
    { key: 'idx',   label: '#',          w: 24,  align: 'left'   as const },
    { key: 'name',  label: 'Chapter',    w: 150, align: 'left'   as const },
    { key: 'theory',label: 'Theory',     w: 52,  align: 'center' as const },
    { key: 'mat',   label: 'Materials',  w: 60,  align: 'center' as const },
    { key: 'form',  label: 'Formula',    w: 52,  align: 'center' as const },
    { key: 'prac',  label: 'Practice',   w: 56,  align: 'center' as const },
    { key: 'test',  label: 'Tests',      w: 44,  align: 'center' as const },
    { key: 'q',     label: 'Questions',  w: 61,  align: 'center' as const },
  ]
  const tableW = tableCols.reduce((a, c) => a + c.w, 0)
  // Ensure table fits within content width; if slightly wider, scale down
  const tableX = M + Math.max(0, (contentW - tableW) / 2)

  function drawTableHeader(yy: number) {
    doc.setFillColor(...C.brandDark)
    doc.rect(tableX, yy, tableW, 22, 'F')
    let xx = tableX
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.setTextColor(...C.white)
    for (const col of tableCols) {
      doc.text(
        col.label,
        col.align === 'center' ? xx + col.w / 2 : xx + 6,
        yy + 14,
        { align: col.align === 'center' ? 'center' : 'left' },
      )
      xx += col.w
    }
    return yy + 22
  }

  function drawRow(yy: number, row: (typeof chapterRows)[number], idx: number) {
    if (idx % 2 === 1) {
      doc.setFillColor(...C.bg)
      doc.rect(tableX, yy, tableW, 22, 'F')
    }
    let xx = tableX
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.setTextColor(...C.ink)
    // #
    doc.text(String(idx), xx + 6, yy + 14)
    xx += tableCols[0].w
    // Name (truncate if too long)
    const name = row.name.length > 28 ? row.name.slice(0, 26) + '…' : row.name
    doc.setTextColor(...(row.status === 'draft' ? C.muted : C.ink))
    doc.text(name, xx + 6, yy + 14)
    if (row.status === 'draft') {
      doc.setFontSize(6.5)
      doc.setTextColor(...C.muted)
      doc.text('draft', xx + 6, yy + 21)
      doc.setFontSize(8.5)
    }
    xx += tableCols[1].w
    // Numeric cells
    const cells = [row.theory, row.materials, row.formula, row.practice, row.tests, row.questions]
    for (let i = 2; i < tableCols.length; i++) {
      const col = tableCols[i]
      const val = cells[i - 2]
      doc.setTextColor(...(val === 0 ? C.muted : C.ink))
      doc.setFont('helvetica', val === 0 ? 'normal' : 'bold')
      doc.text(String(val), xx + col.w / 2, yy + 14, { align: 'center' })
      xx += col.w
    }
    // Bottom border
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.3)
    doc.line(tableX, yy + 22, tableX + tableW, yy + 22)
    return yy + 22
  }

  y = drawTableHeader(y)
  chapterRows.forEach((row, i) => {
    // Page break if we're near the bottom
    if (y > H - 80) {
      y = newPage()
      y = drawTableHeader(y)
    }
    y = drawRow(y, row, i + 1)
  })

  // ── Totals row ──
  if (y > H - 60) y = newPage()
  doc.setFillColor(...C.brandLite)
  doc.rect(tableX, y, tableW, 24, 'F')
  let xx = tableX
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9)
  doc.setTextColor(...C.brandDark)
  doc.text('TOTAL', xx + tableCols[0].w + 6, y + 16)
  xx += tableCols[0].w + tableCols[1].w
  const totals = [totalTheory, totalMaterials, totalFormulas, totalPractice, totalTests, totalQuestions]
  for (let i = 2; i < tableCols.length; i++) {
    const col = tableCols[i]
    doc.text(String(totals[i - 2]), xx + col.w / 2, y + 16, { align: 'center' })
    xx += col.w
  }
  y += 30

  // ═══════════════════════════════════════════════════════════════
  //  LEVEL / BATCH WISE CONTENT BREAKDOWN TABLE
  //  (placed right after the Chapter-wise breakdown table — same
  //   visual style: emerald header band, zebra rows, totals row)
  // ═══════════════════════════════════════════════════════════════
  // Start on a fresh page if there isn't enough room for at least the
  // heading + header + a couple of rows.
  if (y > H - 160) y = newPage()

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.setTextColor(...C.ink)
  doc.text('Level / Batch wise Content Breakdown', M, y)
  y += 6
  doc.setDrawColor(...C.line)
  doc.setLineWidth(0.5)
  doc.line(M, y, M + 290, y)
  y += 12

  // Table columns — 9 cols, total width ~515 (fits inside contentW=515)
  const lvlCols = [
    { key: 'idx',   label: '#',          w: 22,  align: 'left'   as const },
    { key: 'name',  label: 'Level / Batch', w: 130, align: 'left'   as const },
    { key: 'chap',  label: 'Chapters',   w: 52,  align: 'center' as const },
    { key: 'stu',   label: 'Students',   w: 52,  align: 'center' as const },
    { key: 'exam',  label: 'Exams',      w: 44,  align: 'center' as const },
    { key: 'mat',   label: 'Materials',  w: 56,  align: 'center' as const },
    { key: 'form',  label: 'Formulas',   w: 50,  align: 'center' as const },
    { key: 'prac',  label: 'Practice',   w: 52,  align: 'center' as const },
    { key: 'q',     label: 'Questions',  w: 57,  align: 'center' as const },
  ]
  const lvlTableW = lvlCols.reduce((a, c) => a + c.w, 0) // ~515
  const lvlTableX = M + Math.max(0, (contentW - lvlTableW) / 2)

  function drawLvlHeader(yy: number) {
    doc.setFillColor(...C.brandDark)
    doc.rect(lvlTableX, yy, lvlTableW, 22, 'F')
    let xx2 = lvlTableX
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.setTextColor(...C.white)
    for (const col of lvlCols) {
      doc.text(
        col.label,
        col.align === 'center' ? xx2 + col.w / 2 : xx2 + 6,
        yy + 14,
        { align: col.align === 'center' ? 'center' : 'left' },
      )
      xx2 += col.w
    }
    return yy + 22
  }

  function drawLvlRow(yy: number, row: (typeof batchRows)[number], idx: number) {
    if (idx % 2 === 1) {
      doc.setFillColor(...C.bg)
      doc.rect(lvlTableX, yy, lvlTableW, 22, 'F')
    }
    let xx2 = lvlTableX
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.setTextColor(...C.ink)
    // #
    doc.text(String(idx), xx2 + 6, yy + 14)
    xx2 += lvlCols[0].w
    // Name (truncate if too long)
    const name = row.name.length > 24 ? row.name.slice(0, 22) + '…' : row.name
    doc.setTextColor(...(row.status === 'archived' ? C.muted : C.ink))
    doc.text(name, xx2 + 6, yy + 14)
    if (row.code) {
      doc.setFontSize(6.5)
      doc.setTextColor(...C.muted)
      doc.text(row.code, xx2 + 6, yy + 21)
      doc.setFontSize(8.5)
    }
    xx2 += lvlCols[1].w
    // Numeric cells: chapters, students, exams, materials, formulas, practice, questions
    const cells = [row.chapters, row.students, row.exams, row.materials, row.formulas, row.practice, row.questions]
    for (let i = 2; i < lvlCols.length; i++) {
      const col = lvlCols[i]
      const val = cells[i - 2]
      doc.setTextColor(...(val === 0 ? C.muted : C.ink))
      doc.setFont('helvetica', val === 0 ? 'normal' : 'bold')
      doc.text(String(val), xx2 + col.w / 2, yy + 14, { align: 'center' })
      xx2 += col.w
    }
    // Bottom border
    doc.setDrawColor(...C.line)
    doc.setLineWidth(0.3)
    doc.line(lvlTableX, yy + 22, lvlTableX + lvlTableW, yy + 22)
    return yy + 22
  }

  if (batchRows.length === 0) {
    // Empty-state row
    doc.setFillColor(...C.bg)
    doc.rect(lvlTableX, y, lvlTableW, 28, 'F')
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(9)
    doc.setTextColor(...C.muted)
    doc.text('No levels / batches configured yet.', lvlTableX + lvlTableW / 2, y + 18, { align: 'center' })
    y += 28
  } else {
    y = drawLvlHeader(y)
    batchRows.forEach((row, i) => {
      if (y > H - 80) {
        y = newPage()
        y = drawLvlHeader(y)
      }
      y = drawLvlRow(y, row, i + 1)
    })

    // ── Totals row for level/batch table ──
    if (y > H - 60) y = newPage()
    const lvlTotals = {
      chapters: batchRows.reduce((a, r) => a + r.chapters, 0),
      students: batchRows.reduce((a, r) => a + r.students, 0),
      exams: batchRows.reduce((a, r) => a + r.exams, 0),
      materials: batchRows.reduce((a, r) => a + r.materials, 0),
      formulas: batchRows.reduce((a, r) => a + r.formulas, 0),
      practice: batchRows.reduce((a, r) => a + r.practice, 0),
      questions: batchRows.reduce((a, r) => a + r.questions, 0),
    }
    doc.setFillColor(...C.brandLite)
    doc.rect(lvlTableX, y, lvlTableW, 24, 'F')
    let xx2 = lvlTableX
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(9)
    doc.setTextColor(...C.brandDark)
    doc.text('TOTAL', xx2 + lvlCols[0].w + 6, y + 16)
    xx2 += lvlCols[0].w + lvlCols[1].w
    const lvlTotalsArr = [lvlTotals.chapters, lvlTotals.students, lvlTotals.exams, lvlTotals.materials, lvlTotals.formulas, lvlTotals.practice, lvlTotals.questions]
    for (let i = 2; i < lvlCols.length; i++) {
      const col = lvlCols[i]
      doc.text(String(lvlTotalsArr[i - 2]), xx2 + col.w / 2, y + 16, { align: 'center' })
      xx2 += col.w
    }
    y += 30
  }

  // ── Footer note ──
  if (y > H - 80) y = newPage()
  doc.setDrawColor(...C.line)
  doc.setLineWidth(0.5)
  doc.line(M, y, W - M, y)
  y += 16
  doc.setFont('helvetica', 'italic')
  doc.setFontSize(8.5)
  doc.setTextColor(...C.inkSoft)
  doc.text(
    `This snapshot was generated on ${fmtDateTime(now)} from the live portal data. ` +
    `Numbers reflect the current state of students, batches, chapters, content, ` +
    `exams, results and certifications as stored in the Power Maths portal.`,
    M,
    y,
    { maxWidth: contentW },
  )

  // ── Final pass: draw footers on every page now that we know the total ──
  const totalPages = doc.getNumberOfPages()
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i)
    drawFooter(i, totalPages)
  }

  // ── Save ──
  const filename = `PowerMaths-Snapshot-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}.pdf`
  doc.save(filename)
}
