// ============================================================
// Power Maths — Persistent Data Store
// Single source of truth for all portal entities with full CRUD.
// Seeded with rich data including real MCQ questions (options,
// correct answer, explanation) so the exam flow is functional.
// ============================================================

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { SEED_FORMULAS, SEED_THEORIES } from './seed-formulas-theories'
import { EXPANDED_QUESTIONS } from './seed-questions-expanded'
import { QUESTIONS_V325 } from './seed-questions-v325'
// v3.54.2 — real curriculum data (admin's actual 180 questions + 8 exams)
import { REAL_DATA_QUESTIONS } from './real-data-questions'
import { REAL_DATA_EXAMS } from './real-data-exams'

// ─────────────────────────── Types ───────────────────────────

// A file uploaded by the admin (PDF worksheet / practice sheet / solution).
// `data` is a base64 data URL so it round-trips through localStorage and is
// served straight into <img src> / the DRM viewer. `size` is bytes.
export interface UploadedFile {
  data: string
  name: string
  size: number
}

export interface StudyMaterial {
  id: string
  title: string
  type: 'pdf'
  order: number
  uploadedAt: string
  // ── Optional uploaded PDF file (stored as a base64 data URL so it
  //     persists in localStorage and is served to students through the
  //     DRM-protected SecurePdfViewer). When absent, the material is a
  //     title-only placeholder (legacy behaviour). ──
  fileData?: string
  fileName?: string
  fileSize?: number
  // ── v3.20.0: optional static file path under /public (e.g.
  //     '/practice/Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf').
  //     When present, the viewer fetches the PDF from this path instead of
  //     decoding `fileData`. This bypasses the localStorage ~5 MB cap and
  //     lets large pre-authored PDFs ship with the app. ──
  filePath?: string
}
export interface PracticeSheet {
  id: string
  title: string
  order: number
  hasSolution: boolean
  uploadedAt: string
  // ── Optional uploaded PDF file (worksheet + optional solutions). ──
  fileData?: string
  fileName?: string
  fileSize?: number
  solutionFileData?: string
  solutionFileName?: string
  // ── v3.20.0: optional static file paths under /public for the
  //     worksheet and the solutions PDF respectively. ──
  filePath?: string
  solutionFilePath?: string
}
export interface ChapterTest {
  id: string
  title: string
  marks: number
  duration: number // minutes
  passingPercentage: number
}

// ──────────────────────────────────────────────────────────────────────
// Formula & Theory learning modules (v3.12.0)
// ──────────────────────────────────────────────────────────────────────

/**
 * A single formula entry in the chapter's Formula notebook.
 *
 * `expression` is a KaTeX-compatible LaTeX string (e.g. `\\frac{a}{b}`).
 * It is rendered with KaTeX in both the admin editor preview and the
 * student view. Copy/download/print are all disabled by the DRM wrapper.
 */
export interface Formula {
  id: string
  title: string
  category: string            // e.g. "Identities", "Areas", "Trigonometric Ratios"
  expression: string          // LaTeX string, KaTeX-rendered
  explanation: string         // Plain-text explanation
  example: string             // Worked example (may contain inline LaTeX via $...$)
  notes?: string              // Optional extra notes
  order: number
  hidden?: boolean            // Admin can hide a formula without deleting it
  createdAt: string
  updatedAt?: string
}

/**
 * A single theory section in the chapter's Theory textbook.
 *
 * `body` is a lightweight markdown-ish string supporting:
 *   • `## Heading`, `### Subheading`
 *   • `- bullet` / `1. numbered`
 *   • `> tip`, `> important`, `> warning` (callout boxes)
 *   • Inline LaTeX via `$...$` and display LaTeX via `$$...$$`
 *   • `![alt](data-url)` images (admin uploads via the editor)
 * The student Theory viewer renders this into a premium textbook layout.
 */
export interface TheorySection {
  id: string
  title: string
  body: string                // markdown-ish content (see comment above)
  order: number
  hidden?: boolean
  image?: string              // optional data URL for a section banner image
  createdAt: string
  updatedAt?: string
}

/**
 * Per-chapter content tab configuration (v3.13.0).
 *
 * Each chapter owns an ordered list of these entries — one per content tab —
 * that lets the admin:
 *   • hide a tab from students entirely (`visible: false`) — a hidden tab is
 *     excluded from the chapter completion calculation, so students can finish
 *     the chapter without it;
 *   • reorder tabs by dragging — the array order IS the display order in both
 *     the admin Manage Content page and the student chapter learning page.
 *
 * Default order mirrors the recommended learning sequence:
 *   Theory → Materials → Formula → Practice → Test.
 */
export type ContentTabId = 'theory' | 'materials' | 'formula' | 'practice' | 'test'

/**
 * v3.36.0 — default display labels for each content tab. Used as the fallback
 * when a chapter has no custom `label` set on a tab (so existing chapters
 * keep showing "Theory", "Materials", etc. unchanged until the admin renames).
 */
export const DEFAULT_TAB_LABELS: Record<ContentTabId, string> = {
  theory: 'Theory',
  materials: 'Materials',
  formula: 'Formula',
  practice: 'Practice',
  // v3.53.2 — renamed "Tests" to "Exams" so the Manage Content tab
  // matches the Exams module vocabulary.
  test: 'Exams',
}

export interface ContentTab {
  id: ContentTabId
  visible: boolean
  /**
   * v3.36.0 — optional custom display name for this tab. When empty/undefined
   * the canonical `DEFAULT_TAB_LABELS[id]` is used. Lets the admin rename the
   * 5 chapter tabs per-chapter (e.g. "Theory" → "Concepts").
   */
  label?: string
}

export const DEFAULT_CONTENT_TABS: ContentTab[] = [
  { id: 'theory', visible: true },
  { id: 'materials', visible: true },
  { id: 'formula', visible: true },
  { id: 'practice', visible: true },
  { id: 'test', visible: true },
]

/** Resolve a chapter's content tabs, falling back to the canonical defaults. */
export function resolveContentTabs(chapter: { contentTabs?: ContentTab[] }): ContentTab[] {
  if (Array.isArray(chapter.contentTabs) && chapter.contentTabs.length > 0) {
    // Ensure every canonical tab id is present (defensive: older stores may
    // have a partial list after migration). Missing tabs are appended as
    // visible in their canonical position.
    const present = new Set(chapter.contentTabs.map((t) => t.id))
    const out = [...chapter.contentTabs]
    for (const d of DEFAULT_CONTENT_TABS) {
      if (!present.has(d.id)) out.push({ ...d })
    }
    return out
  }
  return DEFAULT_CONTENT_TABS.map((t) => ({ ...t }))
}

/**
 * v3.36.0 — resolve the display label for a tab: returns the custom label if
 * set (non-empty after trim), otherwise the canonical default. Used by both
 * the admin chapter manager and the student chapter learning page so the
 * rename is reflected everywhere.
 */
export function resolveTabLabel(tab: ContentTab): string {
  const custom = tab.label?.trim()
  return custom && custom.length > 0 ? custom : DEFAULT_TAB_LABELS[tab.id]
}

/** Visible tab ids in display order — used by the student view + completion math. */
export function visibleContentTabIds(chapter: { contentTabs?: ContentTab[] }): ContentTabId[] {
  return resolveContentTabs(chapter).filter((t) => t.visible).map((t) => t.id)
}

export interface Chapter {
  id: string
  name: string
  description: string
  order: number
  status: 'active' | 'draft'
  icon: string
  studyMaterials: StudyMaterial[]
  practiceSheets: PracticeSheet[]
  tests: ChapterTest[]
  formulas: Formula[]
  theories: TheorySection[]
  contentTabs?: ContentTab[]        // v3.13.0: per-chapter tab visibility + order
  // v3.55.0 — soft tag linking a chapter to a Level (Batch) for filtering.
  // This is OPTIONAL and used ONLY for the Chapters page Level filter.
  // The master relationship is still batch.chapterIds[] (drives student
  // inheritance, learning path, exams). This field is a convenience tag
  // so the admin can filter chapters by Level on the Chapters page.
  batchId?: string
  createdAt: string
}

/**
 * v3.54.0 — The 12 question Levels (was 4 difficulty tiers: very-easy /
 * easy / medium / hard). Displayed as "Level 1" … "Level 12" in the UI.
 * Stored kebab-case so existing `.replace('-', ' ')` display logic works.
 */
export type QuestionLevel =
  | 'level-1' | 'level-2' | 'level-3' | 'level-4'
  | 'level-5' | 'level-6' | 'level-7' | 'level-8'
  | 'level-9' | 'level-10' | 'level-11' | 'level-12'

/** All 12 levels in order — used by dropdowns, filters, badge maps. */
export const QUESTION_LEVELS: QuestionLevel[] = [
  'level-1', 'level-2', 'level-3', 'level-4',
  'level-5', 'level-6', 'level-7', 'level-8',
  'level-9', 'level-10', 'level-11', 'level-12',
]

export interface Question {
  id: string
  // Primary chapter (kept for backward compatibility with existing code
  // that reads `q.chapterId`). Always equals `chapterIds[0]`.
  chapterId: string
  // ALL chapters this question belongs to. A question can now be shared
  // across multiple chapters — the admin picks one or more when creating
  // / editing. `chapterId` mirrors the first entry for legacy consumers.
  chapterIds: string[]
  examId?: string
  type: 'mcq' | 'numerical' | 'true-false'
  // v3.54.0 — "Difficulty" renamed to "Level" in the UI. The underlying
  // field is still called `difficulty` for backward compatibility, but its
  // values are now `level-1` through `level-12` (kebab-case). The display
  // label "Level N" is derived via `.replace('-', ' ')` + capitalize.
  difficulty: QuestionLevel
  text: string
  // Optional image attached to the question (data URL). Rendered above the
  // options in the exam runner + question bank table.
  imageData?: string
  imageName?: string
  options: string[]
  correctAnswer: number // index for mcq/true-false
  explanation: string
  // Optional image attached to the explanation (data URL). Shown in the
  // post-exam review screen beneath the explanation text.
  explanationImage?: string
  explanationImageName?: string
  marks: number
  createdAt: string
}

export interface ExamQuestionRef {
  questionId: string
  marks: number
}

export interface Exam {
  id: string
  title: string
  chapterId: string
  chapterName: string
  type: 'chapter_test' | 'cumulative' | 'semi' | 'final' | 'worksheet_test'
  marks: number
  duration: number // minutes
  passingPercentage: number
  negativeMarking: number // 0 = none, 0.25 = -0.25
  shuffleQuestions: boolean
  shuffleOptions: boolean
  showResultImmediately: boolean
  instructions: string
  questionIds: string[]
  status: 'published' | 'draft'
  attempts: number
  createdAt: string
  // ── v3.27.0 Proctoring (Theme 6 — Exam Integrity) ──
  /** When true, the exam runs in lockdown mode with violation tracking. */
  proctored?: boolean
  /** Optional larger question pool — when set, `questionsToPick` questions
   *  are randomly selected from this pool per student (anti-cheating). */
  questionPoolIds?: string[]
  /** How many questions to pick from the pool. Ignored if no pool. */
  questionsToPick?: number
  /** Whether the question-pool picking is seeded per student (deterministic
   *  retake) or fully random each attempt. Default true (seeded). */
  poolSeedByStudent?: boolean
  // v3.56.0 — soft tag linking an exam to a Level (Batch) for filtering.
  // OPTIONAL — used ONLY for the Exams page Level filter.
  // The master relationship is still batch.examIds[] (drives the Levels
  // page exam-status computation). This field is a convenience tag so
  // the admin can filter exams by Level on the Exams page.
  batchId?: string
}

export interface AnswerRecord {
  questionId: string
  questionText: string
  options: string[]
  selectedOption: number | null
  correctOption: number
  isCorrect: boolean
  marksAwarded: number
  maxMarks: number
  timeTakenSeconds: number
  explanation: string
}

export interface Result {
  id: string
  studentId: string
  studentName: string
  examId: string
  examTitle: string
  chapterName: string
  attemptNumber: number
  startTime: string
  endTime: string
  timeTakenMinutes: number
  totalQuestions: number
  attempted: number
  correct: number
  wrong: number
  marksObtained: number
  totalMarks: number
  percentage: number
  status: 'passed' | 'failed'
  answers: AnswerRecord[]
  createdAt: string
}

export interface Certificate {
  id: string
  studentId: string
  studentName: string
  chapterName: string
  examTitle: string
  score: number
  certificateNumber: string
  issuedAt: string
  status: 'issued' | 'revoked'
  // v3.46.0 — Level/Batch Completion Certificate support.
  // When `certificateType === 'level'`, the cert represents successful
  // completion of an entire Level/Batch (not a single exam). In that case:
  //   • `levelName`   holds the Level/Batch display name (e.g. "Level 1")
  //   • `chapterNames` lists every chapter included in that Level/Batch
  //   • `chapterName` / `examTitle` / `score` are kept for backward-compat
  //     with the table/PDF consumers but are not the primary display values.
  // Absent (or 'exam') → standard exam certificate (the original behaviour).
  certificateType?: 'exam' | 'level'
  levelName?: string
  chapterNames?: string[]
}

export interface Student {
  id: string
  name: string
  email: string
  phone: string
  address?: string
  batch: string
  status: 'active' | 'inactive' | 'suspended'
  enrolledAt: string
  lastLogin: string | null
  avatarColor: string
  // Optional profile photo stored as a data URL (base64). When present it
  // replaces the coloured initials avatar in the admin table, student profile
  // and sidebar user card.
  photo?: string
  assignedChapters: string[]
  notes?: string
  validityEnd?: string
  // Optional password — only written by an admin via the Edit Student
  // dialog's "Reset Password" field. Stored in plain-text here because the
  // portal is a demo; in production this would be a hashed credential.
  password?: string
  // v3.44.0 — ordered list of Level/Batch IDs assigned to this student
  // (their sequential learning path). Level 1 = index 0, Level 2 = index 1, etc.
  // When absent, the student's learning path is derived from their `batch` field.
  assignedBatchIds?: string[]
}

// ─────────────────────── Batches ───────────────────────
// An enterprise batch groups students together so chapters / exams can be
// assigned to the whole cohort at once. `chapterIds` / `examIds` are the
// canonical batch-level assignments — every student whose `batch` field
// matches `batch.name` automatically inherits the chapters (merged into their
// own `assignedChapters`). The inheritance is re-applied whenever a batch's
// chapter list changes OR a student is added / moved into the batch.
export interface Batch {
  id: string
  name: string            // display name, e.g. "Batch 2026-A" — links to Student.batch
  code: string            // short code, e.g. "PM26-A"
  academicYear: string    // e.g. "2026-2027"
  startDate: string       // ISO date
  endDate: string         // ISO date
  description: string
  status: 'active' | 'inactive' | 'archived'
  maxStudents: number
  notes: string
  chapterIds: string[]    // chapters assigned to every student in this batch
  examIds: string[]       // exams assigned to this batch (tracking + notifications)
  createdAt: string
}

export interface Announcement {
  id: string
  title: string
  body: string
  audience: 'all' | 'students' | 'admins'
  priority: 'low' | 'normal' | 'high'
  status: 'active' | 'archived'
  createdAt: string
  author: string
}

// ─────────────────────── Marketing Campaigns (v3.50.0) ───────────────────────
// Admin-authored promotional campaigns (banner image OR YouTube video) shown
// on the student dashboard right after the existing brand banner. Each
// campaign is targeted at all students, specific batches (by name, matching
// Student.batch), or individual students (by id). Visibility is governed by
// `status` ('published' only), the [startDate, endDate] window, and audience
// match. When multiple campaigns are visible they render in ascending
// `priority` order (1 = top).
export interface MarketingCampaign {
  id: string
  title: string
  description: string
  // Campaign creative type.
  //   • 'banner' — an uploaded image (stored as a base64 data URL in `image`)
  //   • 'video'  — a YouTube video (embed URL derived from `videoUrl`)
  //   • 'text'   — a premium personalized text card (v3.52.0). The admin
  //                writes rich markdown-like content with dynamic placeholders
  //                ({{student_name}}, {{first_name}}, {{level}}, …) which are
  //                resolved per-student at render time. No image upload needed.
  type: 'banner' | 'video' | 'text'
  // type === 'banner': base64 data URL of the uploaded creative.
  image?: string
  // type === 'video': raw YouTube URL (watch / youtu.be / embed / shorts).
  // Parsed to an embed URL at render time.
  videoUrl?: string
  // v3.52.0 — type === 'text': the rich message body authored by the admin.
  // Supports multiple paragraphs, line breaks, bullet lists, emoji, and
  // dynamic placeholders ({{student_name}}, {{first_name}}, {{last_name}},
  // {{level}}, {{batch}}, {{today_date}}). Plain text — rendered with
  // whitespace preserved and basic markdown-style bullet detection.
  messageContent?: string
  // Target audience.
  //   • 'all'     — every logged-in student sees the campaign
  //   • 'batch'   — only students whose `batch` is in `targetBatches`
  //   • 'individual' — only students whose id is in `targetStudentIds`
  audience: 'all' | 'batch' | 'individual'
  // audience === 'batch': batch names (matches Student.batch).
  targetBatches?: string[]
  // audience === 'individual': student ids.
  targetStudentIds?: string[]
  // Campaign duration (ISO date strings, YYYY-MM-DD). Empty string = unbounded.
  startDate: string
  endDate: string
  // Display priority — lower numbers render first. Defaults to 1.
  priority: number
  // Campaign status.
  //   • 'draft'     — not shown to students (admin preview only)
  //   • 'published' — live on student dashboard (subject to date/audience)
  //   • 'paused'    — temporarily hidden without deleting
  status: 'draft' | 'published' | 'paused'
  // Optional CTA button rendered under the creative.
  ctaText?: string
  ctaUrl?: string
  // Metadata
  createdAt: string
  updatedAt: string
  author: string
}

export interface ActivityLog {
  id: string
  user: string
  role: 'admin' | 'student' | 'system'
  action: string
  target: string
  time: string
  timestamp: number
  type: 'create' | 'update' | 'delete' | 'login' | 'submit' | 'system'
}

export interface Note {
  id: string
  studentId: string
  title: string
  content: string
  chapter: string
  color: string
  pinned: boolean
  updatedAt: string
}

export interface Message {
  id: string
  studentId: string
  from: string
  to: string
  subject: string
  body: string
  preview: string
  time: string
  read: boolean
  direction: 'in' | 'out'
  // v3.35 — optional thread link. When the admin replies from the Inbox
  // tab, the reply message stores the original student message's id here
  // so the Inbox can show the full conversation thread (student question +
  // teacher reply) under one card. Older messages without this field still
  // work — the Inbox falls back to subject-matching to find replies.
  replyToId?: string
}

// ─────────────────────── Notifications ───────────────────────
// Enterprise notification system. Each notification has a category (drives
// icon + colour), a priority, an audience selector (individual / multiple /
// batch / all students), and a read-tracking ledger so the admin can see
// exactly who has read it and when. Notifications can be drafted, scheduled,
// sent and expired — mirroring a modern SaaS notification center.

export type NotificationCategory =
  | 'system'
  | 'chapter_assigned'
  | 'exam_available'
  | 'exam_result'
  | 'certificate'
  | 'announcement'
  | 'reminder'
  | 'maintenance'
  | 'message'
  | 'general'

export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent'
export type NotificationStatus = 'draft' | 'scheduled' | 'sent' | 'expired'
export type NotificationAudience = 'individual' | 'multiple' | 'batch' | 'all'

export interface NotificationReadRecord {
  studentId: string
  readAt: string // ISO timestamp
}

export interface NotificationAttachment {
  name: string
  data: string  // base64 data URL
  size: number
  kind: 'pdf' | 'image'
}

export interface AppNotification {
  id: string
  title: string
  description: string  // short preview (1 line)
  body: string         // rich text body (supports **bold**, *italic*, line breaks, [links](url))
  category: NotificationCategory
  priority: NotificationPriority
  audience: NotificationAudience
  // For 'individual' / 'multiple': student IDs. For 'batch': empty (use recipientBatch).
  // For 'all': empty.
  recipientIds: string[]
  // Batch name when audience === 'batch'. Links to Batch.name.
  recipientBatch?: string
  sender: string       // display name, e.g. "Prof. Kalpesh Vyas"
  senderId: string     // "ADMIN001"
  status: NotificationStatus
  readBy: NotificationReadRecord[]
  links?: string[]            // optional URLs mentioned in the body
  imageData?: string          // optional inline image (data URL)
  attachments?: NotificationAttachment[]
  createdAt: string    // ISO
  scheduledAt?: string // ISO when status === 'scheduled'
  expiresAt?: string   // ISO expiry
  sentAt?: string      // ISO when status flipped to 'sent'
}

// ─────────────────────── Email subsystem ───────────────────────

export type EmailEncryption = 'none' | 'ssl' | 'tls' | 'starttls'

export interface EmailConfig {
  enabled: boolean
  provider: 'smtp' | 'console'   // 'console' = log to EmailLog without sending
  host: string
  port: number
  username: string
  password: string
  encryption: EmailEncryption
  fromName: string
  fromEmail: string
  replyTo: string
}

export type EmailTemplateId =
  | 'welcome'
  | 'exam_assigned'
  | 'exam_result'
  | 'certificate_issued'
  | 'password_reset'
  | 'account_suspended'
  | 'payment_received'
  | 'announcement'

export interface EmailTemplate {
  id: EmailTemplateId
  name: string
  subject: string
  body: string
  // Variables available in the template, shown as a hint in the editor.
  variables: string[]
  enabled: boolean
  lastEditedAt: string
}

export type EmailStatus = 'sent' | 'queued' | 'failed'

export interface EmailLog {
  id: string
  templateId: EmailTemplateId | 'manual'
  templateName: string
  toName: string
  toEmail: string
  subject: string
  preview: string
  status: EmailStatus
  sentAt: string         // ISO date
  timestamp: number
}

export type LogoMode = 'icon' | 'text' | 'image'

export interface NavItemConfig {
  id: string
  label: string
  // If the item is hidden by the admin it won't render in the sidebar
  hidden?: boolean
}

export interface PortalSettings {
  siteName: string
  tagline: string
  adminEmail: string
  // v3.33 — admin profile photo (data URL). Stored in settings so it
  // persists across sessions and is independent of the student roster.
  adminPhoto?: string
  phone: string
  timezone: string
  defaultPassPercentage: number
  negativeMarking: number
  shuffleByDefault: boolean
  sessionTimeout: number
  emailNotifications: boolean
  certificateAutoGenerate: boolean

  // ── Email configuration (SMTP) ──
  emailConfig: EmailConfig

  // ── Branding (header / sidebar logo + footer copy) ──
  // Logo
  logoMode: LogoMode            // 'icon' = GraduationCap, 'text' = monogram, 'image' = uploaded dataURL
  logoText: string              // 1–3 char monogram when logoMode === 'text'
  logoImage: string             // dataURL when logoMode === 'image'
  logoAccent: string            // tailwind color name for the logo chip (emerald/teal/amber/violet/...)

  // v3.36.0 — Portal-wide accent (primary) color theme. One of the keys in
  // ACCENT_THEMES (emerald/teal/green/amber/violet). Applied to the :root CSS
  // variables (--primary, --ring, --sidebar-primary, --chart-1, --success, …)
  // by applyAccentTheme() in src/lib/accent-theme.ts. Drives EVERY element
  // that uses bg-primary / text-primary / ring / btn-premium-primary, so the
  // whole portal recolors at once. Default 'emerald' matches the CSS baseline.
  themeAccent: string

  // Header
  headerTitle: string           // brand name shown in the sidebar brand block + browser title

  // Footer
  footerCopyright: string       // e.g. "© 2026 Power Maths by Prof. Kalpesh Vyas. All rights reserved."
  footerStatus: string          // e.g. "All systems operational"
  footerVersion: string         // e.g. "v3.1.0"
  footerStatusColor: 'emerald' | 'amber' | 'rose' | 'zinc'

  // ── Navigation (menu order + rename) ──
  adminNav: NavItemConfig[]     // flat ordered list of admin nav item ids + labels
  studentNav: NavItemConfig[]   // flat ordered list of student nav item ids + labels

  // ── Certificate template (editable from Settings → Certificates) ──
  certificateTemplate: CertificateTemplate
}

// ─────────────────────────── Certificate Template ───────────────────────────
//
// v3.29.0 — every visual aspect of the student Certificate of Achievement
// is now driven by this template (editable from Settings → Certificates).
// Both the on-screen `CertificateArtwork` component and the print/download
// HTML window read from the same source, so what the admin sees in the
// Settings preview is exactly what the student prints.
//
// All color fields accept arbitrary CSS color strings (hex / rgb / named /
// tailwind class names — the renderer maps a few well-known tailwind names
// to actual hex values for the print window, since the print window is a
// standalone HTML doc without Tailwind).

export type CertificateLayout = 'classic' | 'modern' | 'minimal'

export interface CertificateTemplate {
  // ── Wording ──
  title: string                  // e.g. "Certificate of Achievement"
  subtitle: string               // e.g. "This certificate is proudly presented to"
  completionLine: string         // e.g. "has successfully completed"
  brandName: string              // e.g. "Power Maths"
  brandSub: string               // e.g. "by Prof. Kalpesh Vyas"
  instructorName: string         // e.g. "Prof. K. Vyas"
  instructorTitle: string        // e.g. "Founder & Lead Instructor"
  sealText: string               // e.g. "SEAL OF EXCELLENCE"
  sealEmoji: string              // e.g. "🏆" (rendered inside the gold seal)
  serialPrefix: string           // e.g. "PM-" → cert numbers become PM-2026-0001

  // ── Layout ──
  layout: CertificateLayout      // classic = ornate double border, modern = clean single frame, minimal = no border
  showWatermark: boolean         // central graduation-cap watermark
  showCornerFlourishes: boolean  // 4 corner ornaments (classic layout only)
  showScoreBadge: boolean        // distinction/merit/passed badge on the cert
  showQrCode: boolean            // QR placeholder in the footer (visual only for now)
  showDate: boolean              // issue date in the footer
  showSerial: boolean            // serial number in the footer

  // ── Score-tier thresholds (percentages) ──
  distinctionThreshold: number   // ≥ this → Distinction (default 90)
  meritThreshold: number         // ≥ this → Merit (default 75)

  // ── Colors (CSS color strings) ──
  primaryColor: string           // brand gradient start + headings (default emerald #059669)
  accentColor: string            // brand gradient end + borders + seal (default amber #d97706)
  textColor: string              // body text (default #1f2937)
  nameColor: string              // student name italic (default #047857)
  backgroundFrom: string         // top of the bg gradient (default #ecfdf5)
  backgroundVia: string          // middle of the bg gradient (default #ffffff)
  backgroundTo: string           // bottom of the bg gradient (default #fffbeb)
  borderOuterColor: string       // outer border (default accent #d97706)
  borderInnerColor: string       // inner border (default primary #059669)

  // ── Typography ──
  // Font family stacks. The print window loads these from Google Fonts.
  titleFont: string              // serif display (default "Playfair Display")
  bodyFont: string               // sans body (default "Inter")
}

// ─────────────────────── Seed Data ───────────────────────

const now = () => new Date().toISOString()
const uid = (p: string) => `${p}${Math.random().toString(36).slice(2, 8).toUpperCase()}`
const logTime = () => {
  const d = new Date()
  return d.toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' })
}

/**
 * v3.36.0 — Activity & Email log retention window. Entries older than this
 * are automatically purged: (a) on every new logActivity/sendEmail call,
 * (b) during the v25 persist migration, and (c) on store rehydrate. The
 * admin Activity Log + Email Log pages show a note to users about this.
 * 30 days in milliseconds.
 */
export const LOG_RETENTION_MS = 30 * 24 * 60 * 60 * 1000
export const LOG_RETENTION_DAYS = 30
/** True if a log entry's timestamp is still within the 30-day retention window. */
const isLogCurrent = (ts: number) => typeof ts === 'number' && ts > Date.now() - LOG_RETENTION_MS

const seedChapters: Chapter[] = [
  {
    id: 'CH001', name: "Number System - L1", description: "Level 1 - Number System",
    order: 1, status: 'active', icon: 'Hash', createdAt: '2026-06-01',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH002', name: "LR - L1", description: "Level 1 - LR",
    order: 2, status: 'active', icon: 'Lightbulb', createdAt: '2026-06-10',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH003', name: "Geometry - L1", description: "Level 1 - Geometry",
    order: 3, status: 'active', icon: 'Triangle', createdAt: '2026-07-01',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH004', name: "Mental Maths - L1", description: "Level 1 - Mental Maths",
    order: 4, status: 'active', icon: 'Brain', createdAt: '2026-08-01',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH005', name: "Vedic Maths - L1", description: "Level 1 - Vedic Maths",
    order: 5, status: 'active', icon: 'Sparkles', createdAt: '2026-09-01',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH006', name: "Statistics - L1", description: "Level 1 - Statistics",
    order: 6, status: 'active', icon: 'BarChart3', createdAt: '2026-10-01',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B6L9VY2',
  },
  {
    id: 'CH1UFYZE', name: "Number System - L2", description: "Level 2 - Number System",
    order: 7, status: 'active', icon: 'Sigma', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHQZI47Z', name: "LR - L2", description: "Level 2 - LR",
    order: 8, status: 'active', icon: 'Compass', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHPR0CWM', name: "Geometry - L2", description: "Level 2 - Geometry",
    order: 9, status: 'active', icon: 'Brain', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHMAKYP8', name: "Mental Maths - L2", description: "Level 2 - Mental Maths",
    order: 10, status: 'active', icon: 'Box', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHNY62XV', name: "Vedic Maths - L2", description: "Level 2 - Vedic Maths",
    order: 12, status: 'active', icon: 'Hash', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHUC7MM4', name: "Statistics - L2", description: "Level 2 - Statistics",
    order: 13, status: 'active', icon: 'Sparkles', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHQLPFAR', name: "Equations - L2", description: "Level 2 - Equations",
    order: 14, status: 'active', icon: 'Triangle', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
  {
    id: 'CHQSLDXR', name: "Algebra - L2", description: "Level 2 -Algebra",
    order: 15, status: 'active', icon: 'Box', createdAt: '2026-10-03',
    studyMaterials: [], practiceSheets: [], tests: [],
    formulas: [], theories: [],
    contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })),
    batchId: 'B9TGRTU',
  },
]



// Real MCQ questions with options, correct answer index, and explanation.
// `chapterIds` is backfilled from `chapterId` so every seed question belongs
// to exactly one chapter by default (the admin can later add more).
// v3.54.2 — Real curriculum questions from the admin's actual question bank
// (extracted via the Backup feature). 180 MCQs across Number System (60),
// LR (40) and Geometry (80). The admin will import more via the Import feature.
const seedQuestions: Question[] = []

// v3.54.2 — Use the real data questions as the seed (180 questions).
const allSeedQuestions: Question[] = REAL_DATA_QUESTIONS
void allSeedQuestions

// v3.54.2 — Real curriculum exams from the admin's actual exam list.
// 8 exams: L1T1, L1T2, L1T3, L1T4, L1C1, L1T5, L1T6, L1S1.
const seedExams: Exam[] = REAL_DATA_EXAMS

// v3.44.0 — every seed student now carries an `assignedBatchIds` learning
// path. The student's own batch is Level 1 (always unlocked), and the OTHER
// active batches (sorted by name) are Levels 2 / 3 (locked until Level 1 is
// fully completed: all chapters done + the level's exam passed). The active
// batches are B001 (Batch 2026-A), B002 (Batch 2026-B), B003 (Batch 2026-C);
// B004 (archived) is intentionally excluded from learning paths.
const seedStudents: Student[] = [
  { id: 'STU1024', name: 'Aarav Sharma', email: 'aarav.sharma@student.com', phone: '+91 98200 11223', address: 'Pune, Maharashtra', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 09:24', avatarColor: 'emerald', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005', 'CH006'], validityEnd: '2026-12-31', assignedBatchIds: ['B001', 'B002', 'B003'] },
  { id: 'STU1025', name: 'Diya Patel', email: 'diya.patel@student.com', phone: '+91 98200 44556', address: 'Ahmedabad, Gujarat', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 08:10', avatarColor: 'rose', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005'], validityEnd: '2026-12-31', assignedBatchIds: ['B001', 'B002', 'B003'] },
  { id: 'STU1026', name: 'Vivaan Gupta', email: 'vivaan.gupta@student.com', phone: '+91 98200 77889', address: 'Mumbai, Maharashtra', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-18 18:42', avatarColor: 'amber', assignedChapters: ['CH001', 'CH002', 'CH003'], validityEnd: '2026-12-31', assignedBatchIds: ['B002', 'B001', 'B003'] },
  { id: 'STU1027', name: 'Ananya Iyer', email: 'ananya.iyer@student.com', phone: '+91 98200 33221', address: 'Chennai, Tamil Nadu', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-19 07:55', avatarColor: 'violet', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005'], validityEnd: '2026-12-31', assignedBatchIds: ['B002', 'B001', 'B003'] },
  { id: 'STU1028', name: 'Arjun Reddy', email: 'arjun.reddy@student.com', phone: '+91 98200 99887', address: 'Hyderabad, Telangana', batch: 'Batch 2026-A', status: 'inactive', enrolledAt: '2026-06-12', lastLogin: '2026-06-20 14:30', avatarColor: 'sky', assignedChapters: ['CH001', 'CH002'], validityEnd: '2026-12-31', assignedBatchIds: ['B001', 'B002', 'B003'] },
  { id: 'STU1029', name: 'Ishita Verma', email: 'ishita.verma@student.com', phone: '+91 98200 55443', address: 'Delhi', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-19 10:02', avatarColor: 'teal', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005', 'CH006'], validityEnd: '2026-12-31', assignedBatchIds: ['B003', 'B001', 'B002'] },
  { id: 'STU1030', name: 'Kabir Singh', email: 'kabir.singh@student.com', phone: '+91 98200 22110', address: 'Jaipur, Rajasthan', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-17 20:15', avatarColor: 'orange', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004'], validityEnd: '2026-12-31', assignedBatchIds: ['B003', 'B001', 'B002'] },
  { id: 'STU1031', name: 'Saanvi Nair', email: 'saanvi.nair@student.com', phone: '+91 98200 66778', address: 'Kochi, Kerala', batch: 'Batch 2026-B', status: 'suspended', enrolledAt: '2026-07-03', lastLogin: '2026-05-05 11:20', avatarColor: 'fuchsia', assignedChapters: ['CH001'], validityEnd: '2026-12-31', assignedBatchIds: ['B002', 'B001', 'B003'] },
  { id: 'STU1032', name: 'Reyansh Joshi', email: 'reyansh.joshi@student.com', phone: '+91 98200 88990', address: 'Nagpur, Maharashtra', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 06:48', avatarColor: 'cyan', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005'], validityEnd: '2026-12-31', assignedBatchIds: ['B001', 'B002', 'B003'] },
  { id: 'STU1033', name: 'Myra Desai', email: 'myra.desai@student.com', phone: '+91 98200 11009', address: 'Surat, Gujarat', batch: 'Batch 2026-C', status: 'active', enrolledAt: '2026-08-19', lastLogin: '2026-07-18 22:10', avatarColor: 'lime', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004'], validityEnd: '2026-12-31', assignedBatchIds: ['B003', 'B001', 'B002'] },
  { id: 'STU1034', name: 'Aditya Mehta', email: 'aditya.mehta@student.com', phone: '+91 98200 43210', address: 'Indore, MP', batch: 'Batch 2026-B', status: 'active', enrolledAt: '2026-07-03', lastLogin: '2026-07-19 05:30', avatarColor: 'indigo', assignedChapters: ['CH001', 'CH002', 'CH003'], validityEnd: '2026-12-31', assignedBatchIds: ['B002', 'B001', 'B003'] },
  { id: 'STU1035', name: 'Kiara Kapoor', email: 'kiara.kapoor@student.com', phone: '+91 98200 87654', address: 'Chandigarh', batch: 'Batch 2026-A', status: 'active', enrolledAt: '2026-06-12', lastLogin: '2026-07-19 09:15', avatarColor: 'pink', assignedChapters: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005'], validityEnd: '2026-12-31', assignedBatchIds: ['B001', 'B002', 'B003'] },
]

// Three seed batches that match the `batch` strings already used by the 12
// seed students ("Batch 2026-A/B/C") + a fourth archived batch for variety.
// `chapterIds` are intentionally a superset of what each seed student has in
// their own `assignedChapters` so the batch page shows real "assigned vs
// completed" gaps.
const seedBatches: Batch[] = [
  {
    id: 'B6L9VY2', name: "Level 1", code: 'L1', academicYear: '2026-2027',
    startDate: '', endDate: '',
    description: "Level 1",
    status: 'active', maxStudents: 40,
    notes: "Level 1",
    chapterIds: ['CH001', 'CH002', 'CH003', 'CH004', 'CH005', 'CH006'],
    examIds: ['EXW3Y174', 'EXJ5P4JF', 'EX9G9NU7', 'EXOEO4B7', 'EXS72LTA', 'EXKOK8WQ', 'EXI9A42I', 'EXCKO82P', 'EXOX105S', 'EXX22X01', 'EXRZOG4M', 'EXXV496V', 'EXA64RG9', 'EXFWILVM', 'EXKAX36U', 'EXSZ5UFT', 'EXAEE8C6', 'EXQ6DATM'],
    createdAt: '2026-10-03',
  },
  {
    id: 'B9TGRTU', name: "Level 2", code: 'L2', academicYear: '2026-2027',
    startDate: '', endDate: '',
    description: "Level 2",
    status: 'active', maxStudents: 40,
    notes: "Level 2",
    chapterIds: ['CHN0MDJV', 'CHROJPWA', 'CHA6OTAT', 'CH1UFYZE', 'CHQZI47Z', 'CHPR0CWM', 'CHMAKYP8', 'CHNY62XV', 'CHUC7MM4', 'CHQLPFAR', 'CHQSLDXR'],
    examIds: [],
    createdAt: '2026-10-03',
  },
]



const seedResults: Result[] = [
  { id: 'R001', studentId: 'STU1024', studentName: 'Aarav Sharma', examId: 'EX001', examTitle: 'Number System — Chapter Test', chapterName: 'Number System', attemptNumber: 1, startTime: '2026-09-14 10:00', endTime: '2026-09-14 10:26', timeTakenMinutes: 26, totalQuestions: 5, attempted: 5, correct: 4, wrong: 1, marksObtained: 8, totalMarks: 10, percentage: 80, status: 'passed', answers: [], createdAt: '2026-09-14' },
  { id: 'R002', studentId: 'STU1025', studentName: 'Diya Patel', examId: 'EX001', examTitle: 'Number System — Chapter Test', chapterName: 'Number System', attemptNumber: 1, startTime: '2026-09-14 10:00', endTime: '2026-09-14 10:22', timeTakenMinutes: 22, totalQuestions: 5, attempted: 5, correct: 5, wrong: 0, marksObtained: 10, totalMarks: 10, percentage: 100, status: 'passed', answers: [], createdAt: '2026-09-14' },
  { id: 'R003', studentId: 'STU1026', studentName: 'Vivaan Gupta', examId: 'EX002', examTitle: 'Algebra — Mid Chapter Test', chapterName: 'Algebra Basics', attemptNumber: 1, startTime: '2026-10-06 10:00', endTime: '2026-10-06 10:38', timeTakenMinutes: 38, totalQuestions: 5, attempted: 4, correct: 3, wrong: 1, marksObtained: 8.75, totalMarks: 12, percentage: 73, status: 'passed', answers: [], createdAt: '2026-10-06' },
  { id: 'R004', studentId: 'STU1027', studentName: 'Ananya Iyer', examId: 'EX003', examTitle: 'Algebra — Final Test', chapterName: 'Algebra Basics', attemptNumber: 1, startTime: '2026-10-24 10:00', endTime: '2026-10-24 10:55', timeTakenMinutes: 55, totalQuestions: 5, attempted: 5, correct: 4, wrong: 1, marksObtained: 13.75, totalMarks: 12, percentage: 88, status: 'passed', answers: [], createdAt: '2026-10-24' },
  { id: 'R005', studentId: 'STU1028', studentName: 'Arjun Reddy', examId: 'EX004', examTitle: 'Geometry — Chapter Test', chapterName: 'Geometry', attemptNumber: 1, startTime: '2026-11-10 10:00', endTime: '2026-11-10 10:44', timeTakenMinutes: 44, totalQuestions: 4, attempted: 3, correct: 1, wrong: 2, marksObtained: 3, totalMarks: 7, percentage: 43, status: 'failed', answers: [], createdAt: '2026-11-10' },
  { id: 'R006', studentId: 'STU1029', studentName: 'Ishita Verma', examId: 'EX004', examTitle: 'Geometry — Chapter Test', chapterName: 'Geometry', attemptNumber: 1, startTime: '2026-11-10 10:00', endTime: '2026-11-10 10:39', timeTakenMinutes: 39, totalQuestions: 4, attempted: 4, correct: 4, wrong: 0, marksObtained: 7, totalMarks: 7, percentage: 100, status: 'passed', answers: [], createdAt: '2026-11-10' },
  { id: 'R007', studentId: 'STU1032', studentName: 'Reyansh Joshi', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', chapterName: 'Trigonometry', attemptNumber: 1, startTime: '2026-11-30 10:00', endTime: '2026-11-30 10:18', timeTakenMinutes: 18, totalQuestions: 4, attempted: 4, correct: 3, wrong: 1, marksObtained: 6, totalMarks: 8, percentage: 75, status: 'passed', answers: [], createdAt: '2026-11-30' },
  { id: 'R008', studentId: 'STU1024', studentName: 'Aarav Sharma', examId: 'EX003', examTitle: 'Algebra — Final Test', chapterName: 'Algebra Basics', attemptNumber: 1, startTime: '2026-10-24 10:00', endTime: '2026-10-24 10:58', timeTakenMinutes: 58, totalQuestions: 5, attempted: 5, correct: 4, wrong: 1, marksObtained: 13.75, totalMarks: 12, percentage: 88, status: 'passed', answers: [], createdAt: '2026-10-24' },
  { id: 'R009', studentId: 'STU1035', studentName: 'Kiara Kapoor', examId: 'EX007', examTitle: 'Mensuration — Chapter Test', chapterName: 'Mensuration', attemptNumber: 1, startTime: '2026-12-17 10:00', endTime: '2026-12-17 10:41', timeTakenMinutes: 41, totalQuestions: 3, attempted: 3, correct: 3, wrong: 0, marksObtained: 7, totalMarks: 7, percentage: 100, status: 'passed', answers: [], createdAt: '2026-12-17' },
  { id: 'R010', studentId: 'STU1030', studentName: 'Kabir Singh', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', chapterName: 'Trigonometry', attemptNumber: 1, startTime: '2026-11-30 10:00', endTime: '2026-11-30 10:20', timeTakenMinutes: 20, totalQuestions: 4, attempted: 2, correct: 1, wrong: 1, marksObtained: 2.75, totalMarks: 8, percentage: 34, status: 'failed', answers: [], createdAt: '2026-11-30' },
  { id: 'R011', studentId: 'STU1029', studentName: 'Ishita Verma', examId: 'EX005', examTitle: 'Trigonometry — Quiz 1', chapterName: 'Trigonometry', attemptNumber: 1, startTime: '2026-11-30 10:00', endTime: '2026-11-30 10:16', timeTakenMinutes: 16, totalQuestions: 4, attempted: 4, correct: 4, wrong: 0, marksObtained: 8, totalMarks: 8, percentage: 100, status: 'passed', answers: [], createdAt: '2026-11-30' },
  { id: 'R012', studentId: 'STU1025', studentName: 'Diya Patel', examId: 'EX003', examTitle: 'Algebra — Final Test', chapterName: 'Algebra Basics', attemptNumber: 1, startTime: '2026-10-24 10:00', endTime: '2026-10-24 10:52', timeTakenMinutes: 52, totalQuestions: 5, attempted: 5, correct: 5, wrong: 0, marksObtained: 12, totalMarks: 12, percentage: 100, status: 'passed', answers: [], createdAt: '2026-10-24' },
]

const seedCertificates: Certificate[] = [
  { id: 'CERT001', studentId: 'STU1024', studentName: 'Aarav Sharma', chapterName: 'Number System', examTitle: 'Number System — Chapter Test', score: 80, certificateNumber: 'PM-2026-0001', issuedAt: '2026-09-15', status: 'issued' },
  { id: 'CERT002', studentId: 'STU1025', studentName: 'Diya Patel', chapterName: 'Number System', examTitle: 'Number System — Chapter Test', score: 100, certificateNumber: 'PM-2026-0002', issuedAt: '2026-09-15', status: 'issued' },
  { id: 'CERT003', studentId: 'STU1027', studentName: 'Ananya Iyer', chapterName: 'Algebra Basics', examTitle: 'Algebra — Final Test', score: 88, certificateNumber: 'PM-2026-0003', issuedAt: '2026-10-25', status: 'issued' },
  { id: 'CERT004', studentId: 'STU1029', studentName: 'Ishita Verma', chapterName: 'Geometry', examTitle: 'Geometry — Chapter Test', score: 100, certificateNumber: 'PM-2026-0004', issuedAt: '2026-11-11', status: 'issued' },
  { id: 'CERT005', studentId: 'STU1024', studentName: 'Aarav Sharma', chapterName: 'Algebra Basics', examTitle: 'Algebra — Final Test', score: 88, certificateNumber: 'PM-2026-0005', issuedAt: '2026-10-25', status: 'issued' },
  { id: 'CERT006', studentId: 'STU1035', studentName: 'Kiara Kapoor', chapterName: 'Mensuration', examTitle: 'Mensuration — Chapter Test', score: 100, certificateNumber: 'PM-2026-0006', issuedAt: '2026-12-18', status: 'issued' },
  { id: 'CERT007', studentId: 'STU1029', studentName: 'Ishita Verma', chapterName: 'Trigonometry', examTitle: 'Trigonometry — Quiz 1', score: 100, certificateNumber: 'PM-2026-0007', issuedAt: '2026-12-01', status: 'issued' },
]

const seedAnnouncements: Announcement[] = [
  { id: 'A001', title: 'Trigonometry Chapter Test scheduled for Jan 20', body: 'The final chapter test for Trigonometry will be held on January 20, 10:00 AM. Please complete all practice sheets beforehand.', audience: 'students', priority: 'high', status: 'active', createdAt: '2026-07-19', author: 'Prof. Kalpesh Vyas' },
  { id: 'A002', title: 'New Statistics & Probability chapter coming soon', body: 'We are adding a new chapter on Statistics & Probability. Expected release by end of this month.', audience: 'all', priority: 'normal', status: 'active', createdAt: '2026-07-17', author: 'Prof. Kalpesh Vyas' },
  { id: 'A003', title: 'Maintenance window — Jan 18, 2–4 AM', body: 'The portal will undergo scheduled maintenance. Please save your work before the window.', audience: 'all', priority: 'normal', status: 'active', createdAt: '2026-07-15', author: 'System' },
  { id: 'A004', title: 'Holiday schedule for Republic Day', body: 'No exams will be scheduled on January 26. Regular classes resume January 27.', audience: 'students', priority: 'low', status: 'active', createdAt: '2026-07-13', author: 'Prof. Kalpesh Vyas' },
]

// v3.50.0 — Marketing Campaigns seed. Two sample campaigns so the feature is
// visible immediately on first load:
//   • MC001 — a banner campaign visible to ALL students (published, active)
//   • MC002 — a YouTube video campaign targeted at "Batch 2026-A" (published)
// Both render on the student dashboard right after the existing brand banner.
const seedMarketingCampaigns: MarketingCampaign[] = [
  {
    id: 'MC001',
    title: 'New IELTS Batch — Enrollments Open!',
    description: 'Our brand-new IELTS preparation batch kicks off next month. Limited seats — early-bird discount available for the first 20 enrollments. Speak to Prof. Kalpesh to reserve your spot.',
    type: 'banner',
    image: '/branding/ielts-batch-banner.png',
    audience: 'all',
    startDate: '',
    endDate: '',
    priority: 1,
    status: 'published',
    ctaText: 'Enroll Now',
    ctaUrl: '#',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-01',
    author: 'Prof. Kalpesh Vyas',
  },
  {
    id: 'MC002',
    title: 'Diwali Offer — 25% Off All Courses',
    description: 'Celebrate the festival of lights with Power Maths! Use coupon code DIWALI25 at checkout to get 25% off on all chapter packages. Offer valid for a limited time only.',
    type: 'video',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    audience: 'batch',
    targetBatches: ['Batch 2026-A'],
    startDate: '',
    endDate: '',
    priority: 2,
    status: 'published',
    ctaText: 'Claim Offer',
    ctaUrl: '#',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-01',
    author: 'Prof. Kalpesh Vyas',
  },
  // v3.52.0 — Text Banner campaign. A premium personalized text card.
  // The {{student_name}} placeholder is resolved per-student at render
  // time, so every student sees the message addressed to them by name.
  {
    id: 'MC003',
    title: 'Special Announcement',
    description: 'Personalized progress congratulations + next-batch enrollment nudge with early-bird offer.',
    type: 'text',
    messageContent: 'Hello {{student_name}} 👋\n\nCongratulations on completing your current level! 🎉\n\nWe are excited to invite you to the next batch starting soon.\n\n• Exclusive early-bird discount available\n• Limited seats — reserve your spot today\n• Personalized mentoring from Prof. Kalpesh\n\nRegister today and take the next step in your learning journey.\n\nThank you for being part of Power Maths! ✨',
    audience: 'all',
    startDate: '',
    endDate: '',
    priority: 3,
    status: 'published',
    ctaText: 'Enroll Now',
    ctaUrl: '#',
    createdAt: '2026-08-02',
    updatedAt: '2026-08-02',
    author: 'Prof. Kalpesh Vyas',
  },
]

const seedNotes: Note[] = [
  { id: 'N001', studentId: 'STU1024', title: 'Trig identities cheat sheet', content: 'sin²θ + cos²θ = 1\n1 + tan²θ = sec²θ\n1 + cot²θ = cosec²θ\nsin(90−θ) = cosθ', chapter: 'Trigonometry', color: 'emerald', pinned: true, updatedAt: '2 hours ago' },
  { id: 'N002', studentId: 'STU1024', title: 'Algebra formulas', content: '(a+b)² = a² + 2ab + b²\n(a−b)² = a² − 2ab + b²\na² − b² = (a+b)(a−b)', chapter: 'Algebra Basics', color: 'amber', pinned: false, updatedAt: 'yesterday' },
  { id: 'N003', studentId: 'STU1024', title: 'Circle theorems', content: 'Angle at center = 2 × angle at circumference\nAngles in same segment are equal', chapter: 'Geometry', color: 'violet', pinned: false, updatedAt: '3 days ago' },
]

const seedMessages: Message[] = [
  { id: 'M001', studentId: 'STU1024', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Great progress!', body: 'You scored 80% on the Number System test. Keep up the excellent work! Focus on the irrational numbers question for next time.', preview: 'You scored 80% on the Number System test...', time: '1 hour ago', read: false, direction: 'in' },
  { id: 'M002', studentId: 'STU1024', from: 'Aarav Sharma', to: 'Prof. Kalpesh Vyas', subject: 'Doubt in Q4 of Algebra', body: 'Sir, I could not understand how to factorise 2x² - 8. Could you please explain the steps?', preview: 'Sir, I could not understand how to factorise 2x² - 8...', time: '3 hours ago', read: true, direction: 'out' },
  { id: 'M003', studentId: 'STU1024', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Re: Doubt in Q4 of Algebra', body: 'Take 2 common first: 2(x² - 4) = 2(x-2)(x+2). This is the difference of squares formula.', preview: 'Take 2 common first: 2(x² - 4) = 2(x-2)(x+2)...', time: '2 hours ago', read: false, direction: 'in' },
  { id: 'M004', studentId: 'STU1024', from: 'Prof. Kalpesh Vyas', to: 'Aarav Sharma', subject: 'Reminder: Trigonometry test', body: 'This is a reminder about your upcoming Trigonometry Chapter Test on January 20. Make sure to revise all identities.', preview: 'This is a reminder about your upcoming test on January 20...', time: '1 day ago', read: true, direction: 'in' },
]

// ─────────────────────── Notifications seed ───────────────────────
// Realistic notifications covering every category + audience + status so the
// Notifications Center renders with rich data on first load. `readBy` is
// pre-populated for "sent" notifications so the read-tracking table + progress
// bars show meaningful engagement on day one.

const isoHoursAgo = (h: number) => new Date(Date.now() - h * 3600_000).toISOString()
const isoDaysAgo = (d: number) => new Date(Date.now() - d * 86_400_000).toISOString()
const isoDaysAhead = (d: number) => new Date(Date.now() + d * 86_400_000).toISOString()

const seedNotifications: AppNotification[] = [
  {
    id: 'N001',
    title: 'Trigonometry Chapter Test — Schedule Released',
    description: 'Final chapter test for Trigonometry scheduled for Jan 20, 10:00 AM.',
    body: 'Dear Students,\n\nThe **Trigonometry Chapter Test** is scheduled for **January 20, 2026 at 10:00 AM**. The test carries 40 marks and must be completed in 60 minutes.\n\nPlease revise all identities, compound angles and inverse trigonometric functions. A practice worksheet has been uploaded to the Trigonometry chapter page.\n\nGood luck!\n— Prof. Kalpesh Vyas',
    category: 'exam_available',
    priority: 'high',
    audience: 'batch',
    recipientIds: [],
    recipientBatch: 'Batch 2026-A',
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoHoursAgo(20) },
      { studentId: 'STU1025', readAt: isoHoursAgo(18) },
      { studentId: 'STU1032', readAt: isoHoursAgo(12) },
      { studentId: 'STU1035', readAt: isoHoursAgo(6) },
    ],
    createdAt: isoDaysAgo(2),
    sentAt: isoDaysAgo(2),
    expiresAt: isoDaysAhead(7),
  },
  {
    id: 'N002',
    title: 'New Chapter Assigned: Geometry',
    description: 'Geometry chapter has been added to your syllabus. Start with Worksheet 1.',
    body: 'Hi Aarav,\n\nA new chapter **Geometry** has been assigned to you. Please start with **Worksheet 1 — Basics of Geometry** which covers points, lines, angles and triangles.\n\nThis chapter is part of your Batch 2026-A syllabus and will be tested in the next cumulative exam.\n\nHappy learning!\n— Prof. Kalpesh Vyas',
    category: 'chapter_assigned',
    priority: 'normal',
    audience: 'individual',
    recipientIds: ['STU1024'],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [{ studentId: 'STU1024', readAt: isoHoursAgo(5) }],
    createdAt: isoDaysAgo(1),
    sentAt: isoDaysAgo(1),
  },
  {
    id: 'N003',
    title: 'Certificate Generated — Number System',
    description: 'Diya Patel earned a certificate for scoring 100% in Number System.',
    body: 'Congratulations **Diya Patel**!\n\nYou have successfully completed the **Number System** chapter with a perfect score of **100%**. Your certificate (ID: PM-2026-0002) has been generated and is available for download from your Certificates page.\n\nKeep up the outstanding work!\n— Prof. Kalpesh Vyas',
    category: 'certificate',
    priority: 'normal',
    audience: 'individual',
    recipientIds: ['STU1025'],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [{ studentId: 'STU1025', readAt: isoHoursAgo(30) }],
    createdAt: isoDaysAgo(3),
    sentAt: isoDaysAgo(3),
  },
  {
    id: 'N004',
    title: 'Exam Result Published — Algebra Basics',
    description: 'Results for the Algebra Basics Chapter Test are now available.',
    body: 'Dear Students,\n\nThe results for the **Algebra Basics Chapter Test** have been published. You can view your detailed scorecard and review the correct answers from your Results page.\n\nStudents who scored below 50% are requested to schedule a doubt-clearing session.\n\n— Prof. Kalpesh Vyas',
    category: 'exam_result',
    priority: 'high',
    audience: 'all',
    recipientIds: [],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoHoursAgo(40) },
      { studentId: 'STU1025', readAt: isoHoursAgo(38) },
      { studentId: 'STU1026', readAt: isoHoursAgo(36) },
      { studentId: 'STU1027', readAt: isoHoursAgo(34) },
      { studentId: 'STU1029', readAt: isoHoursAgo(28) },
      { studentId: 'STU1030', readAt: isoHoursAgo(26) },
      { studentId: 'STU1032', readAt: isoHoursAgo(22) },
      { studentId: 'STU1033', readAt: isoHoursAgo(20) },
      { studentId: 'STU1035', readAt: isoHoursAgo(15) },
    ],
    createdAt: isoDaysAgo(4),
    sentAt: isoDaysAgo(4),
  },
  {
    id: 'N005',
    title: 'Scheduled Maintenance — Portal Offline Tonight',
    description: 'Portal will be unavailable on Jan 25, 1:00 AM–3:00 AM for maintenance.',
    body: 'Dear Students,\n\nThe Power Maths portal will undergo scheduled maintenance tonight from **1:00 AM to 3:00 AM IST**. During this window the portal will be temporarily unavailable.\n\nPlease save any in-progress work and log out before the maintenance window begins.\n\nThank you for your patience.\n— Power Maths Admin',
    category: 'maintenance',
    priority: 'urgent',
    audience: 'all',
    recipientIds: [],
    sender: 'System Admin',
    senderId: 'ADMIN001',
    status: 'scheduled',
    scheduledAt: isoDaysAhead(2),
    readBy: [],
    createdAt: isoHoursAgo(6),
    expiresAt: isoDaysAhead(10),
  },
  {
    id: 'N006',
    title: 'Reminder: Complete Geometry Chapter before Friday',
    description: 'Aarav, please complete the Geometry chapter worksheets before Friday.',
    body: 'Hi Aarav,\n\nThis is a reminder to complete the **Geometry** chapter worksheets before this **Friday**. You currently have 2 out of 4 worksheets pending.\n\nCompleting these on time will ensure you are ready for the upcoming cumulative test.\n\n— Prof. Kalpesh Vyas',
    category: 'reminder',
    priority: 'high',
    audience: 'multiple',
    recipientIds: ['STU1024', 'STU1026', 'STU1034'],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoHoursAgo(3) },
      { studentId: 'STU1034', readAt: isoHoursAgo(2) },
    ],
    createdAt: isoDaysAgo(1),
    sentAt: isoDaysAgo(1),
    expiresAt: isoDaysAhead(4),
  },
  {
    id: 'N007',
    title: 'Personal Message: Excellent Progress This Week',
    description: 'Vivaan, your algebra scores have improved by 25%. Keep it up!',
    body: 'Hi Vivaan,\n\nI wanted to personally appreciate your efforts this week. Your algebra scores have improved by **25%** compared to last month — this is a remarkable jump!\n\nContinue practising daily and do not hesitate to reach out if you have any doubts.\n\n— Prof. Kalpesh Vyas',
    category: 'message',
    priority: 'normal',
    audience: 'individual',
    recipientIds: ['STU1026'],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [],
    createdAt: isoHoursAgo(8),
    sentAt: isoHoursAgo(8),
  },
  {
    id: 'N008',
    title: 'New Practice Worksheets Added — Statistics',
    description: 'Two new practice worksheets added to the Statistics chapter.',
    body: 'Dear Batch 2026-B Students,\n\nTwo new practice worksheets have been added to the **Statistics** chapter:\n\n1. Worksheet 5 — Mean, Median & Mode\n2. Worksheet 6 — Standard Deviation & Variance\n\nBoth worksheets include detailed solutions. Please attempt them before the next class.\n\n— Prof. Kalpesh Vyas',
    category: 'announcement',
    priority: 'normal',
    audience: 'batch',
    recipientIds: [],
    recipientBatch: 'Batch 2026-B',
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1026', readAt: isoHoursAgo(10) },
      { studentId: 'STU1027', readAt: isoHoursAgo(9) },
      { studentId: 'STU1034', readAt: isoHoursAgo(7) },
    ],
    createdAt: isoDaysAgo(2),
    sentAt: isoDaysAgo(2),
  },
  {
    id: 'N009',
    title: 'Welcome to Power Maths Portal — New Semester',
    description: 'Welcome aboard! Your student account is now active for 2026-2027.',
    body: 'Dear Students,\n\nWelcome to **Power Maths by Prof. Kalpesh Vyas** for the **2026-2027** academic year!\n\nYour student account is now active. Please explore your dashboard, check the chapters assigned to your batch, and review the exam schedule.\n\nIf you face any login issues, contact admin@powermaths.com.\n\nLet’s make this a great year!\n— Prof. Kalpesh Vyas',
    category: 'general',
    priority: 'low',
    audience: 'all',
    recipientIds: [],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoDaysAgo(40) },
      { studentId: 'STU1025', readAt: isoDaysAgo(39) },
      { studentId: 'STU1026', readAt: isoDaysAgo(38) },
      { studentId: 'STU1027', readAt: isoDaysAgo(38) },
      { studentId: 'STU1029', readAt: isoDaysAgo(37) },
      { studentId: 'STU1030', readAt: isoDaysAgo(37) },
      { studentId: 'STU1032', readAt: isoDaysAgo(36) },
      { studentId: 'STU1033', readAt: isoDaysAgo(36) },
      { studentId: 'STU1035', readAt: isoDaysAgo(35) },
    ],
    createdAt: isoDaysAgo(45),
    sentAt: isoDaysAgo(45),
  },
  {
    id: 'N010',
    title: 'System Update: New Question Bank Features Live',
    description: 'Multi-chapter questions and Level filters are now available.',
    body: 'Dear Students,\n\nWe have rolled out a system update with the following improvements:\n\n- **Multi-chapter questions** — questions can now span multiple chapters\n- **Level filters** — filter the question bank across 12 Levels (Level 1 to Level 12)\n- **Faster exam loading** — exam runner is now 40% faster\n\nExplore the new features from your Question Bank page.\n\n— Power Maths Admin',
    category: 'system',
    priority: 'low',
    audience: 'all',
    recipientIds: [],
    sender: 'System Admin',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoDaysAgo(15) },
      { studentId: 'STU1029', readAt: isoDaysAgo(14) },
    ],
    createdAt: isoDaysAgo(16),
    sentAt: isoDaysAgo(16),
  },
  {
    id: 'N011',
    title: 'Draft: Cumulative Exam Announcement',
    description: 'Draft notification for the upcoming cumulative exam — not yet sent.',
    body: 'Dear Students,\n\nA **cumulative exam** covering Chapters 1–6 is being planned for **February 5, 2026**. The exam will carry 80 marks and must be completed in 90 minutes.\n\n(Draft — please review before sending.)',
    category: 'exam_available',
    priority: 'high',
    audience: 'all',
    recipientIds: [],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'draft',
    readBy: [],
    createdAt: isoHoursAgo(2),
  },
  {
    id: 'N012',
    title: 'Annual Day Invitation — Power Maths 2026',
    description: 'Annual day celebration on Feb 15. All students invited!',
    body: 'Dear Students,\n\nYou are cordially invited to the **Power Maths Annual Day 2026** celebration on **February 15, 2026 at 5:00 PM** at the main campus auditorium.\n\nTop performers will be felicitated with medals and certificates. Dress code: formal.\n\nRSVP by Feb 10.\n— Prof. Kalpesh Vyas',
    category: 'announcement',
    priority: 'normal',
    audience: 'all',
    recipientIds: [],
    sender: 'Prof. Kalpesh Vyas',
    senderId: 'ADMIN001',
    status: 'sent',
    readBy: [
      { studentId: 'STU1024', readAt: isoDaysAgo(5) },
      { studentId: 'STU1025', readAt: isoDaysAgo(5) },
      { studentId: 'STU1030', readAt: isoDaysAgo(4) },
    ],
    createdAt: isoDaysAgo(7),
    sentAt: isoDaysAgo(7),
    expiresAt: isoDaysAhead(20),
  },
]

const seedActivity: ActivityLog[] = [
  { id: 'L001', user: 'Aarav Sharma', role: 'student', action: 'submitted exam', target: 'Trigonometry — Quiz 1', time: '2 min ago', timestamp: Date.now() - 120000, type: 'submit' },
  { id: 'L002', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'published exam', target: 'Trigonometry — Chapter Test', time: '18 min ago', timestamp: Date.now() - 1080000, type: 'create' },
  { id: 'L003', user: 'Diya Patel', role: 'student', action: 'earned certificate', target: 'Number System', time: '1 hour ago', timestamp: Date.now() - 3600000, type: 'create' },
  { id: 'L004', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added question', target: 'Statistics — Q022', time: '2 hours ago', timestamp: Date.now() - 7200000, type: 'create' },
  { id: 'L005', user: 'Vivaan Gupta', role: 'student', action: 'logged in', target: '', time: '3 hours ago', timestamp: Date.now() - 10800000, type: 'login' },
  { id: 'L006', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated chapter', target: 'Mensuration', time: '5 hours ago', timestamp: Date.now() - 18000000, type: 'update' },
  { id: 'L007', user: 'Ishita Verma', role: 'student', action: 'completed study material', target: 'Geometry — Worksheet 5', time: '6 hours ago', timestamp: Date.now() - 21600000, type: 'update' },
  { id: 'L008', user: 'System', role: 'system', action: 'auto-backup completed', target: 'backup_20260719.zip', time: '8 hours ago', timestamp: Date.now() - 28800000, type: 'system' },
  { id: 'L009', user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'suspended student', target: 'Saanvi Nair', time: '12 hours ago', timestamp: Date.now() - 43200000, type: 'update' },
  { id: 'L010', user: 'Ananya Iyer', role: 'student', action: 'submitted exam', target: 'Algebra — Final Test', time: '1 day ago', timestamp: Date.now() - 86400000, type: 'submit' },
]

// Default admin navigation — order matches the sidebar layout.
// Sections are derived from the item id in the sidebar component, so the
// admin is free to reorder items within / across sections here.
//
// v9 layout:
//   • Notifications moved after Announcements (both in the Insights section)
//   • Email Templates removed from the sidebar — it's now embedded inside
//     the Settings page's Email tab.
//   • SYSTEM section holds exactly 3 items: Activity Logs, Email Log, Settings
//     (Activity Logs was previously in the Overview section).
const defaultAdminNav: NavItemConfig[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'students', label: 'Students' },
  { id: 'chapters', label: 'Chapters' },
  { id: 'questions', label: 'Question Bank' },
  { id: 'exams', label: 'Exams' },
  { id: 'batches', label: 'Levels Management' },
  { id: 'student-reports', label: 'Student Reports' },
  { id: 'certificates', label: 'Certificates' },
  { id: 'results', label: 'Results' },
  { id: 'announcements', label: 'Announcements' },
  { id: 'marketing', label: 'Marketing' },
  { id: 'notifications', label: 'Notifications' },
  { id: 'activity', label: 'Activity Logs' },
  { id: 'email-log', label: 'Email Log' },
  { id: 'settings', label: 'Settings' },
]

const defaultStudentNav: NavItemConfig[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'levels', label: 'Level / Batch' },
  { id: 'chapters', label: 'My Chapters' },
  { id: 'practice', label: 'Practice' },
  { id: 'exams', label: 'Exams' },
  { id: 'results', label: 'Results' },
  { id: 'certificates', label: 'Certificates' },
  { id: 'notifications', label: 'Notifications' },
  { id: 'notes', label: 'My Notes' },
  { id: 'messages', label: 'Messages' },
  { id: 'profile', label: 'Profile' },
  { id: 'settings', label: 'Settings' },
]

export const defaultSettings: PortalSettings = {
  siteName: 'Power Maths',
  tagline: 'by Prof. Kalpesh Vyas',
  adminEmail: 'admin@powermaths.com',
  phone: '+91 98200 00000',
  timezone: 'Asia/Kolkata',
  defaultPassPercentage: 50,
  negativeMarking: 0,
  shuffleByDefault: true,
  sessionTimeout: 30,
  emailNotifications: true,
  certificateAutoGenerate: true,

  // Email configuration defaults — "console" provider so the portal logs
  // emails to the Email Log without requiring a real SMTP server.
  emailConfig: {
    enabled: true,
    provider: 'console',
    host: 'smtp.powermaths.com',
    port: 587,
    username: 'noreply@powermaths.com',
    password: '',
    encryption: 'starttls',
    fromName: 'Power Maths Portal',
    fromEmail: 'noreply@powermaths.com',
    replyTo: 'admin@powermaths.com',
  },

  // Branding defaults
  // v3.31.0 — Power Maths official logo (circular badge: "POWER MATHS" /
  // "KALPESH VYAS" with flexed bicep + lightning bolt). Shipped as a static
  // asset in /public/branding/ and referenced by URL so it never bloats the
  // localStorage quota (a base64 data URL of a 106 KB PNG would be ~140 KB
  // of string — fine, but a URL is cleaner and cacheable).
  logoMode: 'image',
  logoText: 'PM',
  logoImage: '/branding/power-maths-logo.png',
  logoAccent: 'emerald',
  themeAccent: 'emerald',   // v3.36.0 — portal-wide primary color (emerald/teal/green/amber/violet)
  headerTitle: 'Power Maths',
  footerCopyright: '© 2026 Power Maths by Prof. Kalpesh Vyas. All rights reserved.',
  footerStatus: 'All systems operational',
  footerVersion: 'v3.56.2',
  footerStatusColor: 'emerald',

  // Navigation defaults
  adminNav: defaultAdminNav,
  studentNav: defaultStudentNav,

  // v3.29.0 — Certificate template defaults. Mirrors the original hardcoded
  // CertificateArtwork design (emerald/amber, Playfair Display + Inter,
  // classic ornate double border with corner flourishes + watermark).
  certificateTemplate: {
    title: 'Certificate of Achievement',
    subtitle: 'This certificate is proudly presented to',
    completionLine: 'has successfully completed',
    brandName: 'Power Maths',
    brandSub: 'by Prof. Kalpesh Vyas',
    instructorName: 'Prof. K. Vyas',
    instructorTitle: 'Founder & Lead Instructor',
    sealText: 'SEAL OF EXCELLENCE',
    sealEmoji: '🏆',
    serialPrefix: 'PM-',

    layout: 'classic',
    showWatermark: true,
    showCornerFlourishes: true,
    showScoreBadge: true,
    showQrCode: false,
    showDate: true,
    showSerial: true,

    distinctionThreshold: 90,
    meritThreshold: 75,

    primaryColor: '#059669',   // emerald-600
    accentColor: '#d97706',    // amber-600
    textColor: '#1f2937',      // gray-800
    nameColor: '#047857',      // emerald-700
    backgroundFrom: '#ecfdf5', // emerald-50
    backgroundVia: '#ffffff',  // white
    backgroundTo: '#fffbeb',   // amber-50
    borderOuterColor: '#d97706',
    borderInnerColor: '#059669',

    titleFont: 'Playfair Display',
    bodyFont: 'Inter',
  },
}

const seedEmailTemplates: EmailTemplate[] = [
  {
    id: 'welcome',
    name: 'Student Welcome',
    subject: 'Welcome to Power Maths, {{student_name}}!',
    body: `Hi {{student_name}},\n\nWelcome to Power Maths by Prof. Kalpesh Vyas! Your student account is now active.\n\nLogin: {{login_url}}\nBatch: {{batch}}\nValidity: {{validity_end}}\n\nGet started by visiting your dashboard and exploring the chapters assigned to you.\n\nHappy learning!\n— Prof. Kalpesh Vyas`,
    variables: ['student_name', 'login_url', 'batch', 'validity_end'],
    enabled: true,
    lastEditedAt: '2026-07-10',
  },
  {
    id: 'exam_assigned',
    name: 'Exam Assigned',
    subject: 'New exam assigned: {{exam_title}}',
    body: `Hi {{student_name}},\n\nA new exam has been assigned to you:\n\nExam: {{exam_title}}\nChapter: {{chapter_name}}\nDuration: {{duration}} minutes\nTotal marks: {{total_marks}}\nPass %: {{pass_percentage}}%\n\nLog in to your portal to attempt the exam before the deadline.\n\n— Power Maths Portal`,
    variables: ['student_name', 'exam_title', 'chapter_name', 'duration', 'total_marks', 'pass_percentage'],
    enabled: true,
    lastEditedAt: '2026-07-12',
  },
  {
    id: 'exam_result',
    name: 'Exam Result Published',
    subject: 'Your result for {{exam_title}} — {{percentage}}%',
    body: `Hi {{student_name}},\n\nYour result for "{{exam_title}}" has been published.\n\nScore: {{marks_obtained}} / {{total_marks}} ({{percentage}}%)\nStatus: {{status}}\nTime taken: {{time_taken}} minutes\n\n{{#if passed}}Congratulations! Keep up the great work.{{else}}Don't be discouraged — review the solutions and try again.{{/if}}\n\n— Power Maths Portal`,
    variables: ['student_name', 'exam_title', 'marks_obtained', 'total_marks', 'percentage', 'status', 'time_taken', 'passed'],
    enabled: true,
    lastEditedAt: '2026-07-13',
  },
  {
    id: 'certificate_issued',
    name: 'Certificate Issued',
    subject: 'Certificate issued — {{certificate_number}}',
    body: `Hi {{student_name}},\n\nCongratulations! You have successfully earned a certificate.\n\nCertificate: {{certificate_number}}\nChapter: {{chapter_name}}\nExam: {{exam_title}}\nScore: {{score}}%\nIssued on: {{issued_at}}\n\nYou can view and download your certificate from the Certificates section of your portal.\n\n— Prof. Kalpesh Vyas`,
    variables: ['student_name', 'certificate_number', 'chapter_name', 'exam_title', 'score', 'issued_at'],
    enabled: true,
    lastEditedAt: '2026-07-14',
  },
  {
    id: 'password_reset',
    name: 'Password Reset',
    subject: 'Reset your Power Maths password',
    body: `Hi {{student_name}},\n\nWe received a request to reset your password. Click the link below to choose a new password:\n\n{{reset_url}}\n\nThis link expires in 30 minutes. If you didn't request this, you can safely ignore this email.\n\n— Power Maths Portal`,
    variables: ['student_name', 'reset_url'],
    enabled: true,
    lastEditedAt: '2026-07-08',
  },
  {
    id: 'account_suspended',
    name: 'Account Suspended',
    subject: 'Your Power Maths account has been suspended',
    body: `Hi {{student_name}},\n\nYour account has been suspended. Please contact your instructor at {{admin_email}} for more information.\n\n— Power Maths Portal`,
    variables: ['student_name', 'admin_email'],
    enabled: false,
    lastEditedAt: '2026-07-05',
  },
  {
    id: 'payment_received',
    name: 'Payment Received',
    subject: 'Payment received — {{amount}}',
    body: `Hi {{student_name}},\n\nWe've received your payment of {{amount}} for {{plan_name}}.\n\nTransaction ID: {{transaction_id}}\nDate: {{payment_date}}\n\nThank you for your continued trust in Power Maths.\n\n— Prof. Kalpesh Vyas`,
    variables: ['student_name', 'amount', 'plan_name', 'transaction_id', 'payment_date'],
    enabled: true,
    lastEditedAt: '2026-07-09',
  },
  {
    id: 'announcement',
    name: 'Announcement Broadcast',
    subject: '{{announcement_title}}',
    body: `Hi {{student_name}},\n\n{{announcement_body}}\n\n— {{author}}`,
    variables: ['student_name', 'announcement_title', 'announcement_body', 'author'],
    enabled: true,
    lastEditedAt: '2026-07-14',
  },
]

const seedEmailLogs: EmailLog[] = [
  { id: 'EL001', templateId: 'welcome', templateName: 'Student Welcome', toName: 'Aarav Sharma', toEmail: 'aarav.sharma@student.com', subject: 'Welcome to Power Maths, Aarav Sharma!', preview: 'Welcome to Power Maths by Prof. Kalpesh Vyas! Your student account is now active...', status: 'sent', sentAt: '2026-06-12 10:15', timestamp: Date.now() - 86400000 * 30 },
  { id: 'EL002', templateId: 'exam_assigned', templateName: 'Exam Assigned', toName: 'Aarav Sharma', toEmail: 'aarav.sharma@student.com', subject: 'New exam assigned: Number System — Chapter Test', preview: 'A new exam has been assigned to you: Number System — Chapter Test...', status: 'sent', sentAt: '2026-09-12 09:00', timestamp: Date.now() - 86400000 * 15 },
  { id: 'EL003', templateId: 'exam_result', templateName: 'Exam Result Published', toName: 'Aarav Sharma', toEmail: 'aarav.sharma@student.com', subject: 'Your result for Number System — Chapter Test — 80%', preview: 'Your result for "Number System — Chapter Test" has been published...', status: 'sent', sentAt: '2026-09-14 10:30', timestamp: Date.now() - 86400000 * 14 },
  { id: 'EL004', templateId: 'certificate_issued', templateName: 'Certificate Issued', toName: 'Aarav Sharma', toEmail: 'aarav.sharma@student.com', subject: 'Certificate issued — PM-2026-0001', preview: 'Congratulations! You have successfully earned a certificate...', status: 'sent', sentAt: '2026-09-15 11:00', timestamp: Date.now() - 86400000 * 13 },
  { id: 'EL005', templateId: 'welcome', templateName: 'Student Welcome', toName: 'Diya Patel', toEmail: 'diya.patel@student.com', subject: 'Welcome to Power Maths, Diya Patel!', preview: 'Welcome to Power Maths by Prof. Kalpesh Vyas!...', status: 'sent', sentAt: '2026-06-12 10:16', timestamp: Date.now() - 86400000 * 28 },
  { id: 'EL006', templateId: 'exam_result', templateName: 'Exam Result Published', toName: 'Diya Patel', toEmail: 'diya.patel@student.com', subject: 'Your result for Number System — Chapter Test — 100%', preview: 'Your result has been published. Score: 100%. Congratulations!', status: 'sent', sentAt: '2026-09-14 10:25', timestamp: Date.now() - 86400000 * 14 },
  { id: 'EL007', templateId: 'certificate_issued', templateName: 'Certificate Issued', toName: 'Diya Patel', toEmail: 'diya.patel@student.com', subject: 'Certificate issued — PM-2026-0002', preview: 'Congratulations! Certificate PM-2026-0002 issued...', status: 'sent', sentAt: '2026-09-15 11:02', timestamp: Date.now() - 86400000 * 13 },
  { id: 'EL008', templateId: 'announcement', templateName: 'Announcement Broadcast', toName: 'All Students', toEmail: 'students@powermaths.com', subject: 'Trigonometry Chapter Test scheduled for Jan 20', preview: 'The final chapter test for Trigonometry will be held on January 20...', status: 'sent', sentAt: '2026-07-19 08:00', timestamp: Date.now() - 3600000 * 6 },
  { id: 'EL009', templateId: 'exam_assigned', templateName: 'Exam Assigned', toName: 'Ishita Verma', toEmail: 'ishita.verma@student.com', subject: 'New exam assigned: Trigonometry — Chapter Test', preview: 'A new exam has been assigned: Trigonometry — Chapter Test...', status: 'queued', sentAt: '2026-07-19 09:30', timestamp: Date.now() - 3600000 * 2 },
  { id: 'EL010', templateId: 'password_reset', templateName: 'Password Reset', toName: 'Arjun Reddy', toEmail: 'arjun.reddy@student.com', subject: 'Reset your Power Maths password', preview: 'We received a request to reset your password...', status: 'failed', sentAt: '2026-12-20 14:35', timestamp: Date.now() - 86400000 * 25 },
]

// ─────────────────────── Store ───────────────────────

interface DataState {
  students: Student[]
  batches: Batch[]
  chapters: Chapter[]
  questions: Question[]
  exams: Exam[]
  results: Result[]
  certificates: Certificate[]
  announcements: Announcement[]
  marketingCampaigns: MarketingCampaign[]
  activityLogs: ActivityLog[]
  notes: Note[]
  messages: Message[]
  notifications: AppNotification[]
  emailTemplates: EmailTemplate[]
  emailLogs: EmailLog[]
  settings: PortalSettings
  seeded: boolean

  // activity
  logActivity: (log: Omit<ActivityLog, 'id' | 'time' | 'timestamp'>) => void

  // students
  addStudent: (s: Omit<Student, 'id' | 'enrolledAt' | 'lastLogin'>) => Student
  updateStudent: (id: string, patch: Partial<Student>) => void
  deleteStudent: (id: string) => void
  assignChapters: (studentId: string, chapterIds: string[]) => void

  // batches
  addBatch: (b: Omit<Batch, 'id' | 'createdAt'>) => Batch
  updateBatch: (id: string, patch: Partial<Batch>) => void
  deleteBatch: (id: string) => void
  // Assign chapters to a batch AND auto-merge them into every student in
  // that batch's `assignedChapters` (union, de-duplicated). New students
  // added to the batch later also inherit these chapters.
  assignChaptersToBatch: (batchId: string, chapterIds: string[]) => void
  removeChaptersFromBatch: (batchId: string, chapterIds: string[]) => void
  assignExamsToBatch: (batchId: string, examIds: string[]) => void
  removeExamsFromBatch: (batchId: string, examIds: string[]) => void
  // Move a set of existing students into a batch (updates `student.batch`
  // + inherits the batch's chapter assignments).
  addStudentsToBatch: (batchId: string, studentIds: string[]) => void
  removeStudentsFromBatch: (batchId: string, studentIds: string[]) => void
  moveStudentsToBatch: (toBatchId: string, studentIds: string[]) => void

  // chapters
  addChapter: (c: { name: string; description: string; icon?: string; batchId?: string }) => Chapter
  updateChapter: (id: string, patch: Partial<Chapter>) => void
  deleteChapter: (id: string) => void
  addStudyMaterial: (chapterId: string, title: string, file?: UploadedFile) => void
  updateStudyMaterial: (chapterId: string, materialId: string, patch: Partial<StudyMaterial>) => void
  deleteStudyMaterial: (chapterId: string, materialId: string) => void
  addPracticeSheet: (chapterId: string, title: string, file?: UploadedFile, solutionFile?: UploadedFile) => void
  // v3.53.2 — rename + reorder support for practice sheets
  updatePracticeSheet: (chapterId: string, sheetId: string, patch: Partial<PracticeSheet>) => void
  reorderPracticeSheets: (chapterId: string, fromIndex: number, toIndex: number) => void
  deletePracticeSheet: (chapterId: string, sheetId: string) => void
  // v3.53.2 — reorder support for study materials (rename already existed)
  reorderStudyMaterials: (chapterId: string, fromIndex: number, toIndex: number) => void

  // formulas (v3.12.0)
  addFormula: (chapterId: string, formula: Omit<Formula, 'id' | 'order' | 'createdAt'>) => void
  updateFormula: (chapterId: string, formulaId: string, patch: Partial<Formula>) => void
  deleteFormula: (chapterId: string, formulaId: string) => void
  duplicateFormula: (chapterId: string, formulaId: string) => void
  reorderFormulas: (chapterId: string, orderedIds: string[]) => void

  // theories (v3.12.0)
  addTheory: (chapterId: string, theory: Omit<TheorySection, 'id' | 'order' | 'createdAt'>) => void
  updateTheory: (chapterId: string, theoryId: string, patch: Partial<TheorySection>) => void
  deleteTheory: (chapterId: string, theoryId: string) => void
  reorderTheories: (chapterId: string, orderedIds: string[]) => void

  // content tabs (v3.13.0) — per-chapter tab visibility + order
  updateChapterContentTabs: (chapterId: string, tabs: ContentTab[]) => void

  // questions
  addQuestion: (q: Omit<Question, 'id' | 'createdAt'>) => void
  // v3.53.6 — bulk import: adds many questions at once (used by the
  // Import-from-Word/PDF feature). Each entry is the same shape as addQuestion.
  addQuestions: (qs: Omit<Question, 'id' | 'createdAt'>[]) => number
  updateQuestion: (id: string, patch: Partial<Question>) => void
  deleteQuestion: (id: string) => void

  // exams
  addExam: (e: Omit<Exam, 'id' | 'attempts' | 'createdAt'>) => void
  updateExam: (id: string, patch: Partial<Exam>) => void
  deleteExam: (id: string) => void

  // results
  addResult: (r: Omit<Result, 'id' | 'createdAt'>) => Result

  // certificates
  generateCertificate: (studentId: string, studentName: string, chapterName: string, examTitle: string, score: number) => void
  // v3.46.0 — Issue a Level/Batch Completion Certificate (no exam/score).
  generateLevelCertificate: (studentId: string, studentName: string, levelName: string, chapterNames: string[]) => void
  revokeCertificate: (id: string) => void

  // announcements
  addAnnouncement: (a: Omit<Announcement, 'id' | 'createdAt'>) => void
  updateAnnouncement: (id: string, patch: Partial<Announcement>) => void
  deleteAnnouncement: (id: string) => void

  // marketing campaigns (v3.50.0)
  addMarketingCampaign: (c: Omit<MarketingCampaign, 'id' | 'createdAt' | 'updatedAt'>) => void
  updateMarketingCampaign: (id: string, patch: Partial<MarketingCampaign>) => void
  deleteMarketingCampaign: (id: string) => void
  duplicateMarketingCampaign: (id: string) => void

  // notes
  addNote: (n: Omit<Note, 'id' | 'updatedAt'>) => void
  updateNote: (id: string, patch: Partial<Note>) => void
  deleteNote: (id: string) => void

  // messages
  sendMessage: (m: Omit<Message, 'id' | 'time' | 'read' | 'direction'>) => void
  // v3.33 — Admin replies to a student message from the Notifications → Inbox
  // tab. Unlike `sendMessage` (which is student-initiated and triggers an
  // auto-reply), this creates a single `direction: 'in'` message from the
  // teacher that lands in the student's Messages inbox with no auto-reply.
  // v3.35 — accepts an optional `replyToId` so the reply is linked to the
  // original student message for thread display in the Inbox.
  replyToStudent: (m: Omit<Message, 'id' | 'time' | 'read' | 'direction'> & { replyToId?: string }) => void
  markMessageRead: (id: string) => void
  // v3.35 — Delete a single message by id. Used by the admin Inbox to
  // remove a student's question. Also deletes any replies linked to it
  // (via replyToId) so the thread is cleaned up on BOTH the admin Inbox
  // and the student's Messages page.
  deleteMessage: (id: string) => void
  // v3.35 — Delete an entire thread: the student's original message PLUS
  // every reply (direction='in' with replyToId === id OR matching subject).
  // This is the action wired to the Inbox "Delete" button.
  deleteMessageThread: (studentMessageId: string) => void

  // notifications
  addNotification: (n: Omit<AppNotification, 'id' | 'createdAt' | 'readBy'> & { status?: NotificationStatus; createdAt?: string }) => AppNotification
  updateNotification: (id: string, patch: Partial<AppNotification>) => void
  deleteNotification: (id: string) => void
  duplicateNotification: (id: string) => AppNotification | undefined
  sendNotification: (id: string) => void
  markNotificationRead: (id: string, studentId: string) => void
  markAllNotificationsRead: (studentId: string) => void

  // email templates
  updateEmailTemplate: (id: EmailTemplateId, patch: Partial<EmailTemplate>) => void
  toggleEmailTemplate: (id: EmailTemplateId) => void
  resetEmailTemplate: (id: EmailTemplateId) => void

  // email log
  sendEmail: (e: Omit<EmailLog, 'id' | 'sentAt' | 'timestamp'>) => void
  clearEmailLog: () => void

  // settings
  updateSettings: (patch: Partial<PortalSettings>) => void

  // navigation (menu reorder + rename + hide/show)
  moveNavItem: (role: 'admin' | 'student', id: string, direction: 'up' | 'down') => void
  renameNavItem: (role: 'admin' | 'student', id: string, label: string) => void
  toggleNavHidden: (role: 'admin' | 'student', id: string) => void
  resetNav: (role: 'admin' | 'student') => void

  // reset
  resetData: () => void

  // v3.51.0 — import a full database snapshot (uploaded backup JSON)
  importDatabase: (data: Partial<DataState>) => void
}

const seedAll = () => ({
  students: seedStudents,
  batches: seedBatches,
  chapters: seedChapters,
  questions: allSeedQuestions,
  exams: seedExams,
  results: seedResults,
  certificates: seedCertificates,
  announcements: seedAnnouncements,
  marketingCampaigns: seedMarketingCampaigns,
  activityLogs: seedActivity,
  notes: seedNotes,
  messages: seedMessages,
  notifications: seedNotifications,
  emailTemplates: seedEmailTemplates,
  emailLogs: seedEmailLogs,
  settings: defaultSettings,
  seeded: true,
})

export const useDataStore = create<DataState>()(
  persist(
    (set, get) => ({
      ...seedAll(),

      logActivity: (log) =>
        set((s) => ({
          // v3.36.0 — also drop any entries older than 30 days on every write,
          // so the log self-prunes without needing a manual cleanup action.
          activityLogs: [
            { ...log, id: uid('L'), time: 'just now', timestamp: Date.now() },
            ...s.activityLogs,
          ]
            .filter((l) => isLogCurrent(l.timestamp))
            .slice(0, 200),
        })),

      // ── Students ──
      // When a student is created or their batch changes, the chapters
      // assigned to that batch are automatically merged into the student's
      // own `assignedChapters` (union, de-duplicated) so batch-level
      // assignments propagate instantly.
      addStudent: (data) => {
        const batch = get().batches.find((b) => b.name === data.batch)
        const inherited = batch ? batch.chapterIds : []
        const student: Student = {
          ...data,
          id: uid('STU'),
          enrolledAt: new Date().toISOString().slice(0, 10),
          lastLogin: null,
          assignedChapters: Array.from(new Set([...(data.assignedChapters || []), ...inherited])),
        }
        set((s) => ({ students: [...s.students, student] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added student', target: student.name, type: 'create' })
        return student
      },
      updateStudent: (id, patch) => {
        set((s) => ({
          students: s.students.map((st) => {
            if (st.id !== id) return st
            const merged = { ...st, ...patch }
            // If the batch changed, inherit the new batch's chapters.
            if (patch.batch !== undefined && patch.batch !== st.batch) {
              const batch = get().batches.find((b) => b.name === patch.batch)
              if (batch) {
                merged.assignedChapters = Array.from(new Set([...(merged.assignedChapters || []), ...batch.chapterIds]))
              }
            }
            return merged
          }),
        }))
        const st = get().students.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated student', target: st?.name || id, type: 'update' })
      },
      deleteStudent: (id) => {
        const st = get().students.find((x) => x.id === id)
        set((s) => ({ students: s.students.filter((x) => x.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted student', target: st?.name || id, type: 'delete' })
      },
      assignChapters: (studentId, chapterIds) => {
        set((s) => ({ students: s.students.map((st) => (st.id === studentId ? { ...st, assignedChapters: chapterIds } : st)) }))
        const st = get().students.find((x) => x.id === studentId)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'assigned chapters to', target: st?.name || studentId, type: 'update' })
      },

      // ── Batches ──
      addBatch: (b) => {
        const batch: Batch = {
          ...b,
          id: uid('B'),
          createdAt: new Date().toISOString().slice(0, 10),
          chapterIds: b.chapterIds || [],
          examIds: b.examIds || [],
        }
        set((s) => ({ batches: [...s.batches, batch] }))
        // Auto-apply the batch's chapters to any students already in this
        // batch (matched by name) — covers the case where a teacher creates
        // a batch whose name matches existing students.
        if (batch.chapterIds.length) {
          set((s) => ({
            students: s.students.map((st) =>
              st.batch === batch.name
                ? { ...st, assignedChapters: Array.from(new Set([...st.assignedChapters, ...batch.chapterIds])) }
                : st
            ),
          }))
        }
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'created batch', target: batch.name, type: 'create' })
        return batch
      },
      updateBatch: (id, patch) => {
        set((s) => ({ batches: s.batches.map((b) => (b.id === id ? { ...b, ...patch } : b)) }))
        const b = get().batches.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated batch', target: b?.name || id, type: 'update' })
      },
      deleteBatch: (id) => {
        const b = get().batches.find((x) => x.id === id)
        set((s) => ({ batches: s.batches.filter((x) => x.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted batch', target: b?.name || id, type: 'delete' })
      },
      assignChaptersToBatch: (batchId, chapterIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        const merged = Array.from(new Set([...batch.chapterIds, ...chapterIds]))
        set((s) => ({ batches: s.batches.map((b) => (b.id === batchId ? { ...b, chapterIds: merged } : b)) }))
        // Propagate to every student in this batch.
        set((s) => ({
          students: s.students.map((st) =>
            st.batch === batch.name
              ? { ...st, assignedChapters: Array.from(new Set([...st.assignedChapters, ...chapterIds])) }
              : st
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'assigned chapters to batch', target: batch.name, type: 'update' })
      },
      removeChaptersFromBatch: (batchId, chapterIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        const remaining = batch.chapterIds.filter((c) => !chapterIds.includes(c))
        set((s) => ({ batches: s.batches.map((b) => (b.id === batchId ? { ...b, chapterIds: remaining } : b)) }))
        // Remove from every student in this batch (batch-level removal).
        set((s) => ({
          students: s.students.map((st) =>
            st.batch === batch.name
              ? { ...st, assignedChapters: st.assignedChapters.filter((c) => !chapterIds.includes(c)) }
              : st
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'removed chapters from batch', target: batch.name, type: 'update' })
      },
      assignExamsToBatch: (batchId, examIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        const merged = Array.from(new Set([...batch.examIds, ...examIds]))
        set((s) => ({ batches: s.batches.map((b) => (b.id === batchId ? { ...b, examIds: merged } : b)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'assigned exams to batch', target: batch.name, type: 'update' })
      },
      removeExamsFromBatch: (batchId, examIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        const remaining = batch.examIds.filter((e) => !examIds.includes(e))
        set((s) => ({ batches: s.batches.map((b) => (b.id === batchId ? { ...b, examIds: remaining } : b)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'removed exams from batch', target: batch.name, type: 'update' })
      },
      addStudentsToBatch: (batchId, studentIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        set((s) => ({
          students: s.students.map((st) =>
            studentIds.includes(st.id)
              ? { ...st, batch: batch.name, assignedChapters: Array.from(new Set([...st.assignedChapters, ...batch.chapterIds])) }
              : st
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: `added ${studentIds.length} student(s) to batch`, target: batch.name, type: 'update' })
      },
      removeStudentsFromBatch: (batchId, studentIds) => {
        const batch = get().batches.find((b) => b.id === batchId)
        if (!batch) return
        set((s) => ({
          students: s.students.map((st) =>
            studentIds.includes(st.id) && st.batch === batch.name ? { ...st, batch: '' } : st
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: `removed ${studentIds.length} student(s) from batch`, target: batch.name, type: 'update' })
      },
      moveStudentsToBatch: (toBatchId, studentIds) => {
        const toBatch = get().batches.find((b) => b.id === toBatchId)
        if (!toBatch) return
        set((s) => ({
          students: s.students.map((st) =>
            studentIds.includes(st.id)
              ? { ...st, batch: toBatch.name, assignedChapters: Array.from(new Set([...st.assignedChapters, ...toBatch.chapterIds])) }
              : st
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: `moved ${studentIds.length} student(s) to batch`, target: toBatch.name, type: 'update' })
      },

      // ── Chapters ──
      addChapter: (c) => {
        const order = get().chapters.length + 1
        const chapter: Chapter = {
          id: uid('CH'),
          name: c.name,
          description: c.description,
          order,
          status: 'active',
          icon: c.icon || 'BookOpen',
          studyMaterials: [],
          practiceSheets: [],
          tests: [],
          createdAt: new Date().toISOString().slice(0, 10),
          // v3.55.0 — soft tag for Level filter (optional)
          ...(c.batchId ? { batchId: c.batchId } : {}),
        }
        set((s) => ({ chapters: [...s.chapters, chapter] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'created chapter', target: chapter.name, type: 'create' })
        return chapter
      },
      updateChapter: (id, patch) => {
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === id ? { ...c, ...patch } : c)) }))
        const c = get().chapters.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated chapter', target: c?.name || id, type: 'update' })
      },
      deleteChapter: (id) => {
        const c = get().chapters.find((x) => x.id === id)
        set((s) => ({
          chapters: s.chapters.filter((x) => x.id !== id),
          exams: s.exams.filter((e) => e.chapterId !== id),
          // Remove this chapter from every question's chapterIds. A question
          // that no longer belongs to any chapter is dropped; a question that
          // still belongs to other chapters is kept (its primary chapterId is
          // rebased to the first remaining chapter).
          questions: s.questions
            .map((q) => {
              const ids = (q.chapterIds && q.chapterIds.length ? q.chapterIds : [q.chapterId]).filter((cid) => cid !== id)
              if (ids.length === 0) return null
              return { ...q, chapterIds: ids, chapterId: ids[0] }
            })
            .filter(Boolean) as Question[],
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted chapter', target: c?.name || id, type: 'delete' })
      },
      addStudyMaterial: (chapterId, title, file) => {
        const order = get().chapters.find((c) => c.id === chapterId)?.studyMaterials.length || 0 + 1
        const mat: StudyMaterial = {
          id: uid('SM'),
          title,
          type: 'pdf',
          order,
          uploadedAt: new Date().toISOString().slice(0, 10),
          ...(file ? { fileData: file.data, fileName: file.name, fileSize: file.size } : {}),
        }
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, studyMaterials: [...c.studyMaterials, mat] } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added study material', target: file ? `${title} (${file.name})` : title, type: 'create' })
      },
      updateStudyMaterial: (chapterId, materialId, patch) => {
        set((s) => ({
          chapters: s.chapters.map((c) =>
            c.id === chapterId
              ? { ...c, studyMaterials: c.studyMaterials.map((m) => (m.id === materialId ? { ...m, ...patch } : m)) }
              : c,
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated study material', target: materialId, type: 'update' })
      },
      deleteStudyMaterial: (chapterId, materialId) => {
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, studyMaterials: c.studyMaterials.filter((m) => m.id !== materialId) } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted study material', target: materialId, type: 'delete' })
      },
      addPracticeSheet: (chapterId, title, file, solutionFile) => {
        const order = get().chapters.find((c) => c.id === chapterId)?.practiceSheets.length || 0 + 1
        const ps: PracticeSheet = {
          id: uid('PS'),
          title,
          order,
          hasSolution: !!solutionFile || true,
          uploadedAt: new Date().toISOString().slice(0, 10),
          ...(file ? { fileData: file.data, fileName: file.name, fileSize: file.size } : {}),
          ...(solutionFile ? { solutionFileData: solutionFile.data, solutionFileName: solutionFile.name } : {}),
        }
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, practiceSheets: [...c.practiceSheets, ps] } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added practice sheet', target: file ? `${title} (${file.name})` : title, type: 'create' })
      },
      deletePracticeSheet: (chapterId, sheetId) => {
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, practiceSheets: c.practiceSheets.filter((p) => p.id !== sheetId) } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted practice sheet', target: sheetId, type: 'delete' })
      },
      // v3.53.2 — rename a practice sheet (title-only patch; mirrors
      // the existing updateStudyMaterial pattern).
      updatePracticeSheet: (chapterId, sheetId, patch) => {
        set((s) => ({
          chapters: s.chapters.map((c) =>
            c.id === chapterId
              ? { ...c, practiceSheets: c.practiceSheets.map((p) => (p.id === sheetId ? { ...p, ...patch } : p)) }
              : c,
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated practice sheet', target: sheetId, type: 'update' })
      },
      // v3.53.2 — reorder practice sheets within a chapter. Swaps the
      // item at fromIndex with the item at toIndex and renumbers `order`.
      reorderPracticeSheets: (chapterId, fromIndex, toIndex) => {
        set((s) => ({
          chapters: s.chapters.map((c) => {
            if (c.id !== chapterId) return c
            const arr = [...c.practiceSheets]
            if (fromIndex < 0 || fromIndex >= arr.length || toIndex < 0 || toIndex >= arr.length) return c
            const [moved] = arr.splice(fromIndex, 1)
            arr.splice(toIndex, 0, moved)
            return { ...c, practiceSheets: arr.map((p, i) => ({ ...p, order: i + 1 })) }
          }),
        }))
      },
      // v3.53.2 — reorder study materials within a chapter (rename was
      // already supported via updateStudyMaterial).
      reorderStudyMaterials: (chapterId, fromIndex, toIndex) => {
        set((s) => ({
          chapters: s.chapters.map((c) => {
            if (c.id !== chapterId) return c
            const arr = [...c.studyMaterials]
            if (fromIndex < 0 || fromIndex >= arr.length || toIndex < 0 || toIndex >= arr.length) return c
            const [moved] = arr.splice(fromIndex, 1)
            arr.splice(toIndex, 0, moved)
            return { ...c, studyMaterials: arr.map((m, i) => ({ ...m, order: i + 1 })) }
          }),
        }))
      },

      // ── Formulas (v3.12.0) ──
      addFormula: (chapterId, formula) => {
        const ch = get().chapters.find((c) => c.id === chapterId)
        const order = ch ? ch.formulas.length + 1 : 1
        const f: Formula = {
          ...formula,
          id: uid('F'),
          order,
          createdAt: new Date().toISOString().slice(0, 10),
        }
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, formulas: [...c.formulas, f] } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added formula', target: formula.title, type: 'create' })
      },
      updateFormula: (chapterId, formulaId, patch) => {
        set((s) => ({
          chapters: s.chapters.map((c) =>
            c.id === chapterId
              ? { ...c, formulas: c.formulas.map((f) => (f.id === formulaId ? { ...f, ...patch, updatedAt: new Date().toISOString().slice(0, 10) } : f)) }
              : c
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated formula', target: formulaId, type: 'update' })
      },
      deleteFormula: (chapterId, formulaId) => {
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, formulas: c.formulas.filter((f) => f.id !== formulaId) } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted formula', target: formulaId, type: 'delete' })
      },
      duplicateFormula: (chapterId, formulaId) => {
        const ch = get().chapters.find((c) => c.id === chapterId)
        const original = ch?.formulas.find((f) => f.id === formulaId)
        if (!original) return
        const copy: Formula = {
          ...original,
          id: uid('F'),
          title: `${original.title} (copy)`,
          order: ch!.formulas.length + 1,
          createdAt: new Date().toISOString().slice(0, 10),
        }
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, formulas: [...c.formulas, copy] } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'duplicated formula', target: original.title, type: 'create' })
      },
      reorderFormulas: (chapterId, orderedIds) => {
        set((s) => ({
          chapters: s.chapters.map((c) => {
            if (c.id !== chapterId) return c
            const reordered = orderedIds
              .map((id, idx) => ({ ...c.formulas.find((f) => f.id === id)!, order: idx + 1 }))
              .filter(Boolean)
            return { ...c, formulas: reordered }
          }),
        }))
      },

      // ── Theories (v3.12.0) ──
      addTheory: (chapterId, theory) => {
        const ch = get().chapters.find((c) => c.id === chapterId)
        const order = ch ? ch.theories.length + 1 : 1
        const t: TheorySection = {
          ...theory,
          id: uid('T'),
          order,
          createdAt: new Date().toISOString().slice(0, 10),
        }
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, theories: [...c.theories, t] } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added theory section', target: theory.title, type: 'create' })
      },
      updateTheory: (chapterId, theoryId, patch) => {
        set((s) => ({
          chapters: s.chapters.map((c) =>
            c.id === chapterId
              ? { ...c, theories: c.theories.map((t) => (t.id === theoryId ? { ...t, ...patch, updatedAt: new Date().toISOString().slice(0, 10) } : t)) }
              : c
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated theory section', target: theoryId, type: 'update' })
      },
      deleteTheory: (chapterId, theoryId) => {
        set((s) => ({ chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, theories: c.theories.filter((t) => t.id !== theoryId) } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted theory section', target: theoryId, type: 'delete' })
      },
      reorderTheories: (chapterId, orderedIds) => {
        set((s) => ({
          chapters: s.chapters.map((c) => {
            if (c.id !== chapterId) return c
            const reordered = orderedIds
              .map((id, idx) => ({ ...c.theories.find((t) => t.id === id)!, order: idx + 1 }))
              .filter(Boolean)
            return { ...c, theories: reordered }
          }),
        }))
      },

      // ── Content tabs (v3.13.0) — admin per-chapter tab visibility + order ──
      updateChapterContentTabs: (chapterId, tabs) => {
        set((s) => ({
          chapters: s.chapters.map((c) => (c.id === chapterId ? { ...c, contentTabs: tabs.map((t) => ({ ...t })) } : c)),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated chapter content tabs', target: chapterId, type: 'update' })
      },

      // ── Questions ──
      addQuestion: (q) => {
        const question: Question = { ...q, id: uid('Q'), createdAt: new Date().toISOString().slice(0, 10) }
        set((s) => ({ questions: [...s.questions, question] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'added question', target: q.text.slice(0, 40), type: 'create' })
      },
      // v3.53.6 — bulk import. Creates N questions in a single state update
      // (one re-render, one activity log entry) so importing 50 questions
      // is as smooth as adding one. Returns the number actually added.
      addQuestions: (qs) => {
        if (!Array.isArray(qs) || qs.length === 0) return 0
        const today = new Date().toISOString().slice(0, 10)
        const newQuestions: Question[] = qs.map((q) => ({ ...q, id: uid('Q'), createdAt: today }))
        set((s) => ({ questions: [...s.questions, ...newQuestions] }))
        get().logActivity({
          user: 'Prof. Kalpesh Vyas',
          role: 'admin',
          action: `imported ${newQuestions.length} questions`,
          target: qs[0]?.text.slice(0, 40) ?? 'bulk import',
          type: 'create',
        })
        return newQuestions.length
      },
      updateQuestion: (id, patch) => {
        set((s) => ({ questions: s.questions.map((q) => (q.id === id ? { ...q, ...patch } : q)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated question', target: id, type: 'update' })
      },
      deleteQuestion: (id) => {
        set((s) => ({
          questions: s.questions.filter((q) => q.id !== id),
          exams: s.exams.map((e) => ({ ...e, questionIds: e.questionIds.filter((qid) => qid !== id) })),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted question', target: id, type: 'delete' })
      },

      // ── Exams ──
      addExam: (e) => {
        const exam: Exam = { ...e, id: uid('EX'), attempts: 0, createdAt: new Date().toISOString().slice(0, 10) }
        set((s) => ({ exams: [...s.exams, exam] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'created exam', target: exam.title, type: 'create' })
      },
      updateExam: (id, patch) => {
        set((s) => ({ exams: s.exams.map((e) => (e.id === id ? { ...e, ...patch } : e)) }))
        const e = get().exams.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated exam', target: e?.title || id, type: 'update' })
      },
      deleteExam: (id) => {
        const e = get().exams.find((x) => x.id === id)
        set((s) => ({ exams: s.exams.filter((x) => x.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted exam', target: e?.title || id, type: 'delete' })
      },

      // ── Results ──
      addResult: (r) => {
        const result: Result = { ...r, id: uid('R'), createdAt: new Date().toISOString().slice(0, 10) }
        set((s) => ({
          results: [...s.results, result],
          exams: s.exams.map((e) => (e.id === r.examId ? { ...e, attempts: e.attempts + 1 } : e)),
        }))
        get().logActivity({ user: r.studentName, role: 'student', action: 'submitted exam', target: r.examTitle, type: 'submit' })
        // Auto-generate certificate on pass if enabled
        if (r.status === 'passed' && get().settings.certificateAutoGenerate) {
          const existing = get().certificates.find((c) => c.studentId === r.studentId && c.examTitle === r.examTitle)
          if (!existing) {
            get().generateCertificate(r.studentId, r.studentName, r.chapterName, r.examTitle, r.percentage)
          }
        }
        return result
      },

      // ── Certificates ──
      generateCertificate: (studentId, studentName, chapterName, examTitle, score) => {
        // v3.29.0 — honor the editable certificate template's serial prefix.
        const prefix = get().settings.certificateTemplate?.serialPrefix ?? 'PM-'
        const cert: Certificate = {
          id: uid('CERT'),
          studentId,
          studentName,
          chapterName,
          examTitle,
          score,
          certificateNumber: `${prefix}${new Date().getFullYear()}-${String(get().certificates.length + 1).padStart(4, '0')}`,
          issuedAt: new Date().toISOString().slice(0, 10),
          status: 'issued',
          certificateType: 'exam',
        }
        set((s) => ({ certificates: [...s.certificates, cert] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'generated certificate for', target: studentName, type: 'create' })
      },
      // v3.46.0 — Level/Batch Completion Certificate. Same serial-prefix logic
      // as `generateCertificate`, but with `certificateType: 'level'`, no
      // score, and the full chapter list of the completed level attached.
      generateLevelCertificate: (studentId, studentName, levelName, chapterNames) => {
        const prefix = get().settings.certificateTemplate?.serialPrefix ?? 'PM-'
        const cert: Certificate = {
          id: uid('CERT'),
          studentId,
          studentName,
          // Backward-compat fields — populated with the level name so existing
          // table columns / search still produce a sensible label.
          chapterName: levelName,
          examTitle: 'Level Completion',
          score: 100,
          certificateNumber: `${prefix}${new Date().getFullYear()}-${String(get().certificates.length + 1).padStart(4, '0')}`,
          issuedAt: new Date().toISOString().slice(0, 10),
          status: 'issued',
          certificateType: 'level',
          levelName,
          chapterNames: [...chapterNames],
        }
        set((s) => ({ certificates: [...s.certificates, cert] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: `generated level certificate (${levelName}) for`, target: studentName, type: 'create' })
      },
      revokeCertificate: (id) => {
        set((s) => ({ certificates: s.certificates.map((c) => (c.id === id ? { ...c, status: 'revoked' } : c)) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'revoked certificate', target: id, type: 'update' })
      },

      // ── Announcements ──
      addAnnouncement: (a) => {
        const ann: Announcement = { ...a, id: uid('A'), createdAt: new Date().toISOString().slice(0, 10) }
        set((s) => ({ announcements: [ann, ...s.announcements] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'posted announcement', target: a.title, type: 'create' })
      },
      updateAnnouncement: (id, patch) => {
        set((s) => ({ announcements: s.announcements.map((a) => (a.id === id ? { ...a, ...patch } : a)) }))
      },
      deleteAnnouncement: (id) => {
        set((s) => ({ announcements: s.announcements.filter((a) => a.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted announcement', target: id, type: 'delete' })
      },

      // ── Marketing Campaigns (v3.50.0) ──
      addMarketingCampaign: (c) => {
        const now = new Date().toISOString().slice(0, 10)
        const campaign: MarketingCampaign = {
          ...c,
          id: uid('MC'),
          createdAt: now,
          updatedAt: now,
        }
        set((s) => ({ marketingCampaigns: [...s.marketingCampaigns, campaign] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'created marketing campaign', target: c.title, type: 'create' })
      },
      updateMarketingCampaign: (id, patch) => {
        const now = new Date().toISOString().slice(0, 10)
        set((s) => ({
          marketingCampaigns: s.marketingCampaigns.map((c) =>
            c.id === id ? { ...c, ...patch, updatedAt: now } : c,
          ),
        }))
      },
      deleteMarketingCampaign: (id) => {
        set((s) => ({ marketingCampaigns: s.marketingCampaigns.filter((c) => c.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted marketing campaign', target: id, type: 'delete' })
      },
      duplicateMarketingCampaign: (id) => {
        const src = get().marketingCampaigns.find((c) => c.id === id)
        if (!src) return
        const now = new Date().toISOString().slice(0, 10)
        const copy: MarketingCampaign = {
          ...src,
          id: uid('MC'),
          title: `${src.title} (Copy)`,
          status: 'draft',
          createdAt: now,
          updatedAt: now,
        }
        set((s) => ({ marketingCampaigns: [...s.marketingCampaigns, copy] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'duplicated marketing campaign', target: src.title, type: 'create' })
      },

      // ── Notes ──
      addNote: (n) => {
        const note: Note = { ...n, id: uid('N'), updatedAt: 'just now', pinned: false }
        set((s) => ({ notes: [note, ...s.notes] }))
      },
      updateNote: (id, patch) => {
        set((s) => ({ notes: s.notes.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: 'just now' } : n)) }))
      },
      deleteNote: (id) => {
        set((s) => ({ notes: s.notes.filter((n) => n.id !== id) }))
      },

      // ── Messages ──
      sendMessage: (m) => {
        const msg: Message = { ...m, id: uid('M'), time: 'just now', read: false, direction: 'out' }
        set((s) => ({ messages: [...s.messages, msg] }))
        // Auto-reply after delay (simulated teacher response)
        setTimeout(() => {
          const reply: Message = {
            id: uid('M'),
            studentId: m.studentId,
            from: 'Prof. Kalpesh Vyas',
            to: m.from,
            subject: `Re: ${m.subject}`,
            body: 'Thank you for your message. I will get back to you with a detailed explanation soon. Keep practicing!',
            preview: 'Thank you for your message. I will get back to you...',
            time: 'just now',
            read: false,
            direction: 'in',
          }
          set((s) => ({ messages: [...s.messages, reply] }))
        }, 2500)
      },
      // v3.33 — Admin replies from the Notifications → Inbox tab. Creates a
      // single `direction: 'in'` message (incoming from the student's POV)
      // with NO auto-reply. The student sees this in their Messages inbox.
      // v3.35 — stores replyToId so the Inbox can show the full thread.
      replyToStudent: (m) => {
        const msg: Message = {
          ...m,
          id: uid('M'),
          time: 'just now',
          read: false,
          direction: 'in',
          replyToId: m.replyToId,
        }
        set((s) => ({ messages: [...s.messages, msg] }))
      },
      markMessageRead: (id) => {
        set((s) => ({ messages: s.messages.map((m) => (m.id === id ? { ...m, read: true } : m)) }))
      },
      // v3.35 — Delete a single message by id.
      deleteMessage: (id) => {
        set((s) => ({ messages: s.messages.filter((m) => m.id !== id) }))
      },
      // v3.35 — Delete an entire thread. Removes the student's original
      // message (direction='out', the given id) PLUS every reply linked to
      // it: (a) messages with replyToId === id (the explicit link set by
      // replyToStudent), and (b) fallback: direction='in' messages for the
      // same student with a matching "Re: <subject>" subject line (covers
      // replies sent before v3.35 that don't have replyToId). This cleans
      // up BOTH the admin Inbox and the student's Messages page in one go.
      deleteMessageThread: (studentMessageId) => {
        set((s) => {
          const original = s.messages.find((m) => m.id === studentMessageId)
          if (!original) return s
          const baseSubject = original.subject.replace(/^Re:\s*/i, '').trim()
          const toRemove = new Set<string>([studentMessageId])
          for (const m of s.messages) {
            if (m.id === studentMessageId) continue
            // Explicit link (v3.35+ replies)
            if (m.replyToId === studentMessageId) {
              toRemove.add(m.id)
              continue
            }
            // Fallback: direction='in' (teacher→student) reply for the same
            // student with a matching subject. This catches older replies.
            if (
              m.direction === 'in' &&
              m.studentId === original.studentId &&
              m.subject.replace(/^Re:\s*/i, '').trim() === baseSubject
            ) {
              toRemove.add(m.id)
            }
          }
          return { messages: s.messages.filter((m) => !toRemove.has(m.id)) }
        })
      },

      // ── Notifications ──
      // Enterprise notification center. `addNotification` covers create + send
      // (when status === 'sent') + schedule (when status === 'scheduled' with a
      // future scheduledAt). Read tracking is recorded per-student in `readBy`.
      addNotification: (n) => {
        const status: NotificationStatus = n.status ?? 'sent'
        const nowIso = new Date().toISOString()
        const notif: AppNotification = {
          ...n,
          id: uid('N'),
          status,
          readBy: [],
          createdAt: n.createdAt ?? nowIso,
          sentAt: status === 'sent' ? (n.sentAt ?? nowIso) : undefined,
        }
        set((s) => ({ notifications: [notif, ...s.notifications] }))
        const verb = status === 'scheduled' ? 'scheduled notification' : status === 'draft' ? 'created draft notification' : 'sent notification'
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: verb, target: notif.title, type: status === 'draft' ? 'create' : 'submit' })
        return notif
      },
      updateNotification: (id, patch) => {
        set((s) => ({
          notifications: s.notifications.map((n) => (n.id === id ? { ...n, ...patch } : n)),
        }))
        const n = get().notifications.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated notification', target: n?.title || id, type: 'update' })
      },
      deleteNotification: (id) => {
        const n = get().notifications.find((x) => x.id === id)
        set((s) => ({ notifications: s.notifications.filter((x) => x.id !== id) }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'deleted notification', target: n?.title || id, type: 'delete' })
      },
      duplicateNotification: (id) => {
        const orig = get().notifications.find((n) => n.id === id)
        if (!orig) return undefined
        const copy: AppNotification = {
          ...orig,
          id: uid('N'),
          title: `${orig.title} (Copy)`,
          status: 'draft',
          readBy: [],
          createdAt: new Date().toISOString(),
          sentAt: undefined,
          scheduledAt: undefined,
        }
        set((s) => ({ notifications: [copy, ...s.notifications] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'duplicated notification', target: orig.title, type: 'create' })
        return copy
      },
      sendNotification: (id) => {
        const nowIso = new Date().toISOString()
        set((s) => ({
          notifications: s.notifications.map((n) =>
            n.id === id ? { ...n, status: 'sent', sentAt: nowIso } : n
          ),
        }))
        const n = get().notifications.find((x) => x.id === id)
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'sent notification', target: n?.title || id, type: 'submit' })
      },
      markNotificationRead: (id, studentId) => {
        set((s) => ({
          notifications: s.notifications.map((n) => {
            if (n.id !== id) return n
            if (n.readBy.some((r) => r.studentId === studentId)) return n
            return { ...n, readBy: [...n.readBy, { studentId, readAt: new Date().toISOString() }] }
          }),
        }))
      },
      markAllNotificationsRead: (studentId) => {
        const nowIso = new Date().toISOString()
        set((s) => ({
          notifications: s.notifications.map((n) =>
            n.readBy.some((r) => r.studentId === studentId)
              ? n
              : { ...n, readBy: [...n.readBy, { studentId, readAt: nowIso }] }
          ),
        }))
      },

      // ── Email templates ──
      updateEmailTemplate: (id, patch) => {
        set((s) => ({
          emailTemplates: s.emailTemplates.map((t) =>
            t.id === id ? { ...t, ...patch, lastEditedAt: new Date().toISOString().slice(0, 10) } : t
          ),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated email template', target: id, type: 'update' })
      },
      toggleEmailTemplate: (id) => {
        set((s) => ({
          emailTemplates: s.emailTemplates.map((t) => (t.id === id ? { ...t, enabled: !t.enabled } : t)),
        }))
      },
      resetEmailTemplate: (id) => {
        const original = seedEmailTemplates.find((t) => t.id === id)
        if (!original) return
        set((s) => ({
          emailTemplates: s.emailTemplates.map((t) => (t.id === id ? { ...original } : t)),
        }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'reset email template', target: id, type: 'update' })
      },

      // ── Email log ──
      sendEmail: (e) => {
        const log: EmailLog = {
          ...e,
          id: uid('EL'),
          sentAt: new Date().toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' }),
          timestamp: Date.now(),
        }
        // v3.36.0 — purge entries older than 30 days on every send.
        set((s) => ({
          emailLogs: [log, ...s.emailLogs]
            .filter((l) => isLogCurrent(l.timestamp))
            .slice(0, 500),
        }))
      },
      clearEmailLog: () => {
        set((s) => ({ emailLogs: [] }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'cleared email log', target: '', type: 'delete' })
      },

      // ── Settings ──
      updateSettings: (patch) => {
        set((s) => ({ settings: { ...s.settings, ...patch } }))
        get().logActivity({ user: 'Prof. Kalpesh Vyas', role: 'admin', action: 'updated settings', target: Object.keys(patch).join(', '), type: 'update' })
      },

      // ── Navigation (menu reorder + rename + hide/show) ──
      moveNavItem: (role, id, direction) => {
        set((s) => {
          const key = role === 'admin' ? 'adminNav' : 'studentNav'
          const list = [...s.settings[key]]
          const idx = list.findIndex((n) => n.id === id)
          if (idx === -1) return {}
          const target = direction === 'up' ? idx - 1 : idx + 1
          if (target < 0 || target >= list.length) return {}
          ;[list[idx], list[target]] = [list[target], list[idx]]
          return { settings: { ...s.settings, [key]: list } }
        })
      },
      renameNavItem: (role, id, label) => {
        set((s) => {
          const key = role === 'admin' ? 'adminNav' : 'studentNav'
          const list = s.settings[key].map((n) => (n.id === id ? { ...n, label } : n))
          return { settings: { ...s.settings, [key]: list } }
        })
      },
      toggleNavHidden: (role, id) => {
        set((s) => {
          const key = role === 'admin' ? 'adminNav' : 'studentNav'
          const list = s.settings[key].map((n) => (n.id === id ? { ...n, hidden: !n.hidden } : n))
          return { settings: { ...s.settings, [key]: list } }
        })
      },
      resetNav: (role) => {
        set((s) => ({
          settings: {
            ...s.settings,
            [role === 'admin' ? 'adminNav' : 'studentNav']:
              role === 'admin' ? defaultAdminNav : defaultStudentNav,
          },
        }))
      },

      // ── Reset ──
      resetData: () => set(seedAll()),

      // ── v3.51.0: Import a full database snapshot ──
      // Replaces every data collection with the provided snapshot.
      // Missing collections fall back to the current in-memory value so a
      // partial import never wipes unrelated data. Settings is deep-merged
      // against defaults so new fields always have sane values.
      importDatabase: (data) =>
        set((s) => ({
          students: Array.isArray(data.students) ? data.students : s.students,
          batches: Array.isArray(data.batches) ? data.batches : s.batches,
          chapters: Array.isArray(data.chapters) ? data.chapters : s.chapters,
          questions: Array.isArray(data.questions) ? data.questions : s.questions,
          exams: Array.isArray(data.exams) ? data.exams : s.exams,
          results: Array.isArray(data.results) ? data.results : s.results,
          certificates: Array.isArray(data.certificates)
            ? data.certificates
            : s.certificates,
          announcements: Array.isArray(data.announcements)
            ? data.announcements
            : s.announcements,
          marketingCampaigns: Array.isArray(data.marketingCampaigns)
            ? data.marketingCampaigns
            : s.marketingCampaigns,
          activityLogs: Array.isArray(data.activityLogs)
            ? data.activityLogs
            : s.activityLogs,
          notes: Array.isArray(data.notes) ? data.notes : s.notes,
          messages: Array.isArray(data.messages) ? data.messages : s.messages,
          notifications: Array.isArray(data.notifications)
            ? data.notifications
            : s.notifications,
          emailTemplates: Array.isArray(data.emailTemplates)
            ? data.emailTemplates
            : s.emailTemplates,
          emailLogs: Array.isArray(data.emailLogs) ? data.emailLogs : s.emailLogs,
          settings: {
            ...defaultSettings,
            ...(s.settings || {}),
            ...(data.settings || {}),
            emailConfig: {
              ...defaultSettings.emailConfig,
              ...((s.settings && s.settings.emailConfig) || {}),
              ...((data.settings && data.settings.emailConfig) || {}),
            },
          },
          seeded: true,
        })),
    }),
    {
      name: 'pm-data-store',
      version: 61,
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : undefined)),
      partialize: (s) => ({
        students: s.students,
        batches: s.batches,
        chapters: s.chapters,
        questions: s.questions,
        exams: s.exams,
        results: s.results,
        certificates: s.certificates,
        announcements: s.announcements,
        marketingCampaigns: s.marketingCampaigns,
        activityLogs: s.activityLogs,
        notes: s.notes,
        messages: s.messages,
        notifications: s.notifications,
        emailTemplates: s.emailTemplates,
        emailLogs: s.emailLogs,
        settings: s.settings,
        seeded: s.seeded,
      }),
      migrate: (persisted: unknown) => {
        // Deep-merge settings so new branding / nav / email fields get
        // defaults while keeping any previously-saved values.
        const p = (persisted || {}) as Partial<DataState>
        const merged: Partial<DataState> = { ...p }
        if (p.settings) {
          merged.settings = {
            ...defaultSettings,
            ...p.settings,
            // Email config — deep-merge so new fields get defaults.
            emailConfig: { ...defaultSettings.emailConfig, ...(p.settings.emailConfig || {}) },
            // v3.29.0 — Certificate template: deep-merge so new fields get
            // defaults. Stores persisted before v19 don't have this object
            // at all, so the spread of defaults fills every field.
            certificateTemplate: {
              ...defaultSettings.certificateTemplate,
              ...((p.settings as Partial<PortalSettings>).certificateTemplate || {}),
            },
            // Ensure nav arrays always exist + contain every required item.
            adminNav: mergeNav(defaultSettings.adminNav, p.settings.adminNav),
            studentNav: mergeNav(defaultSettings.studentNav, p.settings.studentNav),
          }
        }
        // Backfill email templates / logs for stores created before v4.
        if (!p.emailTemplates || p.emailTemplates.length === 0) {
          merged.emailTemplates = seedEmailTemplates
        }
        if (!p.emailLogs) {
          merged.emailLogs = seedEmailLogs
        }
        // v3.50.0 — Backfill marketing campaigns for stores created before the
        // Marketing module existed. Existing stores won't have this key in
        // their persisted state, so we seed the sample campaigns so the
        // feature is visible immediately.
        if (!p.marketingCampaigns || !Array.isArray(p.marketingCampaigns) || p.marketingCampaigns.length === 0) {
          merged.marketingCampaigns = seedMarketingCampaigns
        }
        // v5: backfill `chapterIds` on every question (multi-chapter support).
        // Older stores only have `chapterId`; we seed `chapterIds` with it so
        // the question belongs to its original single chapter.
        if (Array.isArray(p.questions)) {
          merged.questions = p.questions.map((q) => {
            const ids = (q as Question).chapterIds
            const base = (q as Question).chapterId
            if (Array.isArray(ids) && ids.length > 0) return q as Question
            return { ...(q as Question), chapterIds: base ? [base] : [] } as Question
          })
        }
        // v6: seed batches for stores created before the Batch Management
        // module existed. Existing students keep their `batch` string (e.g.
        // "Batch 2026-A") which now links to the matching seeded Batch record
        // by name, so batch-level chapter assignments work retroactively.
        if (!p.batches || !Array.isArray(p.batches) || p.batches.length === 0) {
          merged.batches = seedBatches
        }
        // v7: Student Reports module + sidebar reorder (Batch Management now
        // sits after Exams, Student Reports is a new item after batches). For
        // stores created before v7 the persisted admin nav won't contain
        // `student-reports` and `batches` will be in the old position — we
        // rebuild the nav from the new default order while preserving any
        // label / hidden overrides the admin previously configured.
        if (p.settings?.adminNav && Array.isArray(p.settings.adminNav)) {
          const persistedNav = p.settings.adminNav
          const hasStudentReports = persistedNav.some((n) => n.id === 'student-reports')
          const batchesInOldPos = (() => {
            const bIdx = persistedNav.findIndex((n) => n.id === 'batches')
            const eIdx = persistedNav.findIndex((n) => n.id === 'exams')
            return bIdx !== -1 && eIdx !== -1 && bIdx < eIdx
          })()
          if (!hasStudentReports || batchesInOldPos) {
            // Rebuild from default order, preserving overrides
            const overrides = new Map(persistedNav.map((n) => [n.id, n]))
            merged.settings = {
              ...merged.settings!,
              adminNav: defaultAdminNav.map((d) => {
                const ov = overrides.get(d.id)
                return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
              }),
            }
          }
        }
        // v8: Notifications Management System. Backfill seed notifications for
        // stores created before the module existed, and ensure the
        // `notifications` nav item is present in both admin + student navs
        // (mergeNav appends missing defaults automatically, but we force a
        // rebuild here so the new item lands in its canonical position rather
        // than at the bottom of an existing custom order).
        if (!p.notifications || !Array.isArray(p.notifications) || p.notifications.length === 0) {
          merged.notifications = seedNotifications
        }
        if (p.settings?.adminNav && Array.isArray(p.settings.adminNav)) {
          const hasNotifAdmin = p.settings.adminNav.some((n) => n.id === 'notifications')
          if (!hasNotifAdmin) {
            const overrides = new Map(p.settings.adminNav.map((n) => [n.id, n]))
            merged.settings = {
              ...merged.settings!,
              adminNav: defaultAdminNav.map((d) => {
                const ov = overrides.get(d.id)
                return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
              }),
            }
          }
        }
        if (p.settings?.studentNav && Array.isArray(p.settings.studentNav)) {
          const hasNotifStudent = p.settings.studentNav.some((n) => n.id === 'notifications')
          if (!hasNotifStudent) {
            const overrides = new Map(p.settings.studentNav.map((n) => [n.id, n]))
            merged.settings = {
              ...merged.settings!,
              studentNav: defaultStudentNav.map((d) => {
                const ov = overrides.get(d.id)
                return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
              }),
            }
          }
        }
        // v9 → v11: Sidebar reorganisation — (a) move Notifications after
        // Announcements, (b) drop Email Templates from the main sidebar (it
        // is now embedded inside Settings → Email), (c) move Activity Logs
        // into the SYSTEM section so the section has exactly 3 items
        // (Activity Logs · Email Log · Settings).
        //
        // We force-rebuild the persisted admin nav to match the canonical
        // defaultAdminNav order EXACTLY whenever:
        //   • the persisted list still contains `email-templates`
        //   • OR the persisted list of IDs (ignoring hidden flags) doesn't
        //     match the canonical defaultAdminNav ID sequence.
        // This guarantees every user — including those who customised their
        // nav in older versions — sees the new Notifications / Email
        // Templates / SYSTEM grouping layout immediately.
        if (p.settings?.adminNav && Array.isArray(p.settings.adminNav)) {
          const persisted = p.settings.adminNav
          const stillHasEmailTemplates = persisted.some((n) => n.id === 'email-templates')
          const persistedIds = persisted.map((n) => n.id).filter((id) => id !== 'email-templates')
          const defaultIds = defaultAdminNav.map((n) => n.id)
          const idsMismatch =
            persistedIds.length !== defaultIds.length ||
            persistedIds.some((id, i) => id !== defaultIds[i])
          if (stillHasEmailTemplates || idsMismatch) {
            const overrides = new Map(persisted.map((n) => [n.id, n]))
            merged.settings = {
              ...merged.settings!,
              adminNav: defaultAdminNav.map((d) => {
                const ov = overrides.get(d.id)
                return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
              }),
            }
          }
        }
        // v3.44.0 — Student "Level / Batch" learning path. The new `levels`
        // item must sit in its canonical position (right after `dashboard`,
        // before `chapters`) — NOT appended at the bottom of an existing
        // custom nav order. mergeNav() only appends missing items at the
        // end, so we force-rebuild the student nav from the canonical
        // defaultStudentNav order whenever the persisted ID sequence doesn't
        // match, preserving any custom label / hidden overrides the student
        // (or admin) previously configured.
        if (p.settings?.studentNav && Array.isArray(p.settings.studentNav)) {
          const persistedStudent = p.settings.studentNav
          const studentDefaultIds = defaultStudentNav.map((n) => n.id)
          const studentIdsMismatch =
            persistedStudent.length !== studentDefaultIds.length ||
            persistedStudent.some((n, i) => n.id !== studentDefaultIds[i])
          if (studentIdsMismatch) {
            const overrides = new Map(persistedStudent.map((n) => [n.id, n]))
            merged.settings = {
              ...merged.settings!,
              studentNav: defaultStudentNav.map((d) => {
                const ov = overrides.get(d.id)
                return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
              }),
            }
          }
        }
        // v10: Formula & Theory learning modules. Backfill the new
        // `formulas` and `theories` arrays on every chapter that was
        // created before v10 (i.e. chapters missing the fields or with
        // empty arrays). Chapters created after v10 already have the
        // fields via the seed. We merge seed content by chapter id so
        // existing users get the same rich default formula + theory
        // library that fresh installs get.
        if (Array.isArray(merged.chapters)) {
          let changed = false
          merged.chapters = merged.chapters.map((c) => {
            if (!c) return c
            const seedFormulas = SEED_FORMULAS[c.id] || []
            const seedTheories = SEED_THEORIES[c.id] || []
            const existingFormulas = Array.isArray(c.formulas) ? c.formulas : []
            const existingTheories = Array.isArray(c.theories) ? c.theories : []
            // If the chapter already has the right number of formulas +
            // theories (or MORE, meaning the admin added some), don't
            // touch it. If it has FEWER (e.g. 0 from an old install),
            // backfill the seed content.
            const needsFormulas = existingFormulas.length < seedFormulas.length
            const needsTheories = existingTheories.length < seedTheories.length
            if (!needsFormulas && !needsTheories) return c
            changed = true
            return {
              ...c,
              formulas: needsFormulas ? seedFormulas : existingFormulas,
              theories: needsTheories ? seedTheories : existingTheories,
            }
          })
          void changed
        }
        // v11: Per-chapter content tab configuration (v3.13.0). Every chapter
        // now owns an ordered list of {id, visible} entries controlling which
        // tabs (Theory / Materials / Formula / Practice / Test) students see
        // and in what order. Chapters created before v11 are missing the
        // field — we backfill the canonical default (all 5 tabs visible in
        // the recommended learning sequence). Chapters that already have a
        // non-empty contentTabs array are left untouched so the admin's
        // custom visibility/order survives upgrades. We also normalise any
        // legacy list that is missing tabs (defensive — should not happen,
        // but guarantees all 5 ids are present).
        if (Array.isArray(merged.chapters)) {
          merged.chapters = merged.chapters.map((c) => {
            if (!c) return c
            const existing = (c as Chapter).contentTabs
            if (Array.isArray(existing) && existing.length > 0) {
              // Defensive: ensure all canonical tab ids are present.
              const present = new Set(existing.map((t) => t.id))
              const complete = DEFAULT_CONTENT_TABS.every((d) => present.has(d.id))
              if (complete) return c
              const out = [...existing]
              for (const d of DEFAULT_CONTENT_TABS) {
                if (!present.has(d.id)) out.push({ ...d })
              }
              return { ...c, contentTabs: out }
            }
            return { ...c, contentTabs: DEFAULT_CONTENT_TABS.map((t) => ({ ...t })) }
          })
        }
        // v12→v15: Expanded Question Bank. Backfill any seed questions
        // (from the 315-question library = 24 base + 111 expanded + 180
        // v3.25 additions) that are missing from the persisted store. This
        // is idempotent — it only adds questions whose IDs are not already
        // present, so any custom questions the admin created are preserved,
        // and re-running the migration is a no-op.
        //   • v13 first shipped the 120-question pack.
        //   • v14 added Q121–Q135 (15 more) so per-chapter counts vary.
        //   • v15 (v3.25.0) added Q200–Q379 (180 more, 30 per chapter) —
        //     grade 7–9 level, very-easy / easy / medium difficulty, mix of
        //     mcq / numerical / true-false. Each chapter now has 50+ questions.
        if (Array.isArray(p.questions)) {
          const existingIds = new Set(p.questions.map((q) => (q as Question).id))
          const missing = allSeedQuestions.filter((q) => !existingIds.has(q.id))
          if (missing.length > 0) {
            merged.questions = [...p.questions, ...missing]
          }
        }
        // v15 (v3.20.0): Pre-authored PDF worksheets shipped as static files
        // under /public/practice/. Two worksheets are wired in this release:
        //   • PS003 — Algebra Basics Worksheet 1 (Fundamentals + Solutions)
        //   • PS005 — Geometry Worksheet 1 (Fundamentals + Solutions)
        // For existing users (whose persisted chapters were seeded before
        // v15), backfill the `filePath` / `solutionFilePath` fields onto
        // those specific practice sheets, and refresh their titles so the
        // student-facing practice list shows the friendly worksheet name.
        // Idempotent: only fills fields that are currently missing.
        if (Array.isArray(merged.chapters)) {
          const pdfBackfill: Record<string, {
            title: string
            filePath: string
            solutionFilePath: string
          }> = {
            PS003: {
              title: 'Algebra Basics — Worksheet 1: Fundamentals',
              filePath: '/practice/Power_Maths_Algebra_Basics_Worksheet_1_Fundamentals.pdf',
              solutionFilePath: '/practice/Power_Maths_Algebra_Basics_Worksheet_1_Solutions.pdf',
            },
            PS005: {
              title: 'Geometry — Worksheet 1: Fundamentals',
              filePath: '/practice/Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf',
              solutionFilePath: '/practice/Power_Maths_Geometry_Worksheet_1_Solutions.pdf',
            },
          }
          merged.chapters = merged.chapters.map((c) => {
            if (!c || !Array.isArray(c.practiceSheets)) return c
            let changed = false
            const practiceSheets = c.practiceSheets.map((ps) => {
              const patch = pdfBackfill[ps.id]
              if (!patch) return ps
              if (ps.filePath && ps.solutionFilePath) {
                // Already wired — only refresh the title if it is still the
                // legacy placeholder (so the friendly name shows up).
                if (ps.title === patch.title) return ps
                changed = true
                return { ...ps, title: patch.title }
              }
              changed = true
              return {
                ...ps,
                title: patch.title,
                hasSolution: true,
                filePath: patch.filePath,
                solutionFilePath: patch.solutionFilePath,
              }
            })
            return changed ? { ...c, practiceSheets } : c
          })
        }

        // v17 (v3.27.0): Exam Integrity & Proctoring (Theme 6). Ensure the
        // proctored Algebra Final exam (EX003) carries the new `proctored`,
        // `questionPoolIds`, `questionsToPick` and `poolSeedByStudent` fields
        // even on stores persisted before v17. Any other exam keeps its
        // existing config (proctoring defaults to off).
        if (Array.isArray(merged.exams)) {
          merged.exams = merged.exams.map((e) => {
            const ex = e as Exam
            // Backfill defaults for any exam missing the new fields.
            const patch: Partial<Exam> = {
              proctored: ex.proctored ?? false,
              poolSeedByStudent: ex.poolSeedByStudent ?? true,
            }
            if (!ex.questionPoolIds) patch.questionPoolIds = undefined
            if (!ex.questionsToPick) patch.questionsToPick = undefined
            // Specifically upgrade EX003 to a proctored pool-based final.
            if (ex.id === 'EX003') {
              patch.proctored = true
              patch.title = 'Algebra — Final Test (Proctored)'
              patch.instructions = 'PROCTORED FINAL. 60 minutes. 60% to pass. Negative marking applies. Lockdown mode is ON — tab-switching, copy and right-click are blocked. 3 violations and your exam auto-submits. Each student sees a different set of questions.'
              patch.questionPoolIds = ['Q006', 'Q007', 'Q008', 'Q009', 'Q010', 'Q230', 'Q231', 'Q232', 'Q233', 'Q234']
              patch.questionsToPick = 5
              patch.poolSeedByStudent = true
            }
            // EX006 — proctored Trigonometry chapter test (demo).
            if (ex.id === 'EX006') {
              patch.proctored = true
              patch.title = 'Trigonometry — Chapter Test (Proctored)'
              patch.instructions = 'PROCTORED CHAPTER TEST. 50 minutes. 55% to pass. Lockdown mode is ON — do not switch tabs. 3 violations = auto-submit.'
            }
            return { ...ex, ...patch } as Exam
          })
        }
        // v18 (v3.28.0): Expanded Formula Library. Each chapter's seed
        // formula library grew from 10 → 20 formulas (10 new "very easy"
        // Class 8–11 formulas per chapter — F-*-11 … F-*-20). Backfill
        // the new seed formulas BY ID onto every chapter so existing
        // users get them on upgrade. Idempotent — only adds formulas
        // whose IDs are not already present, so any custom formulas the
        // admin created are preserved (and re-running is a no-op).
        if (Array.isArray(merged.chapters)) {
          let formulasChanged = false
          merged.chapters = merged.chapters.map((c) => {
            if (!c) return c
            const seedFormulas = SEED_FORMULAS[c.id] || []
            const existing = Array.isArray(c.formulas) ? c.formulas : []
            const existingIds = new Set(existing.map((f) => (f as Formula).id))
            const missing = seedFormulas.filter((f) => !existingIds.has(f.id))
            if (missing.length === 0) return c
            formulasChanged = true
            return { ...c, formulas: [...existing, ...missing] }
          })
          void formulasChanged
        }
        // v20 (v3.31.0): Official Power Maths logo. The branding now ships
        // with a real circular badge logo ("POWER MATHS" / "KALPESH VYAS" +
        // flexed bicep + lightning bolt) at /branding/power-maths-logo.png.
        // Existing users who never touched branding (still on the old
        // default `logoMode: 'icon'` with an empty `logoImage`) are
        // upgraded to `logoMode: 'image'` pointing at the new asset.
        // Users who uploaded their OWN logo (logoMode==='image' with a
        // non-empty, non-default logoImage) are preserved — we only
        // upgrade the genuine default state.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          const isOldDefault =
            (!s.logoMode || s.logoMode === 'icon') &&
            (!s.logoImage || s.logoImage === '')
          if (isOldDefault) {
            merged.settings = {
              ...merged.settings,
              logoMode: 'image',
              logoImage: '/branding/power-maths-logo.png',
            } as PortalSettings
          }
        }
        // v21 (v3.32.0): Admin "Export Snapshot" PDF + welcome-card
        // cleanup. Only a cosmetic footer-version bump for existing users
        // so the new version string shows in the sidebar footer.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (!s.footerVersion || s.footerVersion === 'v3.32.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.33.0',
            } as PortalSettings
          }
        }
        // v23 (v3.34.0): Math support in message replies, admin photo in
        // student Messages, certificate vector-PDF download with enlarged
        // logo. Cosmetic footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.33.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.34.0',
            } as PortalSettings
          }
        }
        // v24 (v3.35.0): Inbox reply thread visibility + delete, student
        // Messages scroll fix, transparent certificate logo. Cosmetic
        // footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.34.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.35.0',
            } as PortalSettings
          }
        }
        // v25 (v3.36.0): (1) Per-chapter content-tab rename (optional `label`
        // field on ContentTab — old stores simply have no label, falls back
        // to the canonical default). (2) Activity & Email log auto-purge —
        // drop any log entries older than 30 days on upgrade. (3) New
        // `settings.themeAccent` field (portal-wide primary color). (4)
        // Cosmetic footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.35.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.36.0',
              // Backfill the new themeAccent field for existing users.
              themeAccent: s.themeAccent || 'emerald',
            } as PortalSettings
          }
        }
        // v3.36.0 — purge stale Activity logs (>30 days) on upgrade.
        if (Array.isArray(merged.activityLogs)) {
          merged.activityLogs = (merged.activityLogs as ActivityLog[]).filter((l) =>
            isLogCurrent(l.timestamp)
          )
        }
        // v3.36.0 — purge stale Email logs (>30 days) on upgrade.
        if (Array.isArray(merged.emailLogs)) {
          merged.emailLogs = (merged.emailLogs as EmailLog[]).filter((l) =>
            isLogCurrent(l.timestamp)
          )
        }
        // v26 (v3.37.0): (1) Settings → Navigation now has an explicit Rename
        // action (pencil button) for every admin & student menu item — the
        // rename store action already existed, so no data migration is
        // needed; persisted custom labels keep working. (2) Student Profile
        // no longer lets students edit their own Name (admin-only) — no
        // data change, purely a UI restriction. (3) Cosmetic footer-version
        // bump for existing users so the new version shows immediately.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.36.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.37.0',
            } as PortalSettings
          }
        }
        // v27 (v3.38.0): (1) Page titles now follow nav renames via the new
        // useNavLabel hook — no data migration needed (titles resolve at
        // render time from the persisted nav config). (2) Level Management
        // page (admin-batches) now shows a Hierarchy info banner making the
        // existing Level → Chapters → Students → individual-chapter-assignment
        // structure explicit. The data model already supported all four
        // relationships (Batch.chapterIds, Student.batch + assignedChapters
        // with inheritance); this is a UI enhancement only. (3) Cosmetic
        // footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.37.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.38.0',
            } as PortalSettings
          }
        }
        // v28 (v3.39.0): (1) The Batch/Level detail view is now a full page
        //   instead of a cramped side popup — no data migration needed, purely
        //   a rendering change. (2) The Create/Edit Level form now has
        //   Chapters / Exams / Students tabs so the admin can configure
        //   everything in one place; on Create the selections are applied to
        //   the freshly-created batch (addBatch returns the new Batch with its
        //   id), on Edit they are reconciled via diff against the batch's
        //   current assignments. (3) The previously-broken "Add Students"
        //   button on the detail view is now wired to a real dialog.
        //   Cosmetic footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.38.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.39.0',
            } as PortalSettings
          }
        }
        // v29 (v3.41.0): (1) The Export Snapshot PDF now includes a new
        //   "Level / Batch wise Content Breakdown" table right after the
        //   Chapter-wise table — per level/batch: chapters, students, exams,
        //   materials, formulas, practice sheets, questions + a totals row.
        //   (2) The admin Dashboard page now shows the same breakdown as a
        //   premium visual card with per-level chapter-coverage bars and a
        //   totals footer row. No data migration needed; cosmetic
        //   footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.39.0' || s.footerVersion === 'v3.40.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.41.0',
            } as PortalSettings
          }
        }
        // v30 (v3.42.0): Dashboard simplified to match the clean PDF
        //   presentation style — removed all charts (Weekly Engagement,
        //   Enrollment Trend, Exam Performance, Score Distribution),
        //   removed both stat-card rows (8 StatCards), and removed the
        //   Quick Links section. The dashboard now shows only: Welcome
        //   banner (with Export Snapshot), Level/Batch wise Content
        //   Breakdown card, Recent Activity + Top Performers (side by
        //   side), and Recent Results table. No data migration needed;
        //   cosmetic footer-version bump for existing users.
        if (merged.settings) {
          const s = merged.settings as Partial<PortalSettings>
          if (s.footerVersion === 'v3.41.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.42.0',
            } as PortalSettings
          }
          // v3.43.0 — Chapter-wise Content Breakdown card added to the
          // admin Dashboard (mirrors the same table in the Export Snapshot
          // PDF). Rendering-only change, so this migration is just a
          // cosmetic footer-version bump for existing users.
          if (s.footerVersion === 'v3.42.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.43.0',
            } as PortalSettings
          }
          // v3.44.0 — Student "Level / Batch" learning path page added.
          //   • Adds assignedBatchIds to each student (ordered learning path).
          //   • Bumps footer version.
          if (s.footerVersion === 'v3.43.0') {
            // Populate assignedBatchIds for students that don't have it yet.
            const activeBatches = (merged.batches || [])
              .filter((b: any) => b.status === 'active')
              .sort((a: any, b: any) => (a.name || '').localeCompare(b.name || ''))
            if (Array.isArray(merged.students)) {
              merged.students = merged.students.map((st: any) => {
                if (Array.isArray(st.assignedBatchIds) && st.assignedBatchIds.length > 0) return st
                const ownBatch = activeBatches.find((b: any) => b.name === st.batch)
                const others = activeBatches.filter((b: any) => b.name !== st.batch)
                const path = ownBatch ? [ownBatch.id, ...others.map((b: any) => b.id)] : others.map((b: any) => b.id)
                return { ...st, assignedBatchIds: path }
              })
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.44.0',
            } as PortalSettings
          }
          // v3.45.0 — Two fixes:
          //   (1) Force-rebuild the student nav so the `levels` item lands
          //       in its canonical position (right after `dashboard`,
          //       before `chapters`) for ALL users — including those whose
          //       persisted nav had `levels` appended at the bottom by the
          //       earlier mergeNav() call. The rebuild code in the
          //       non-version-specific section of migrate handles this, but
          //       it only runs when the persist version changes. Bumping
          //       32->33 ensures migrate runs for every existing user.
          //   (2) Locked levels on the student Level/Batch page no longer
          //       show misleading exam/chapter stats (exams are shared
          //       across batches, so a passed exam in Level 1 would show
          //       as "Passed" for Level 2/3). Rendering-only fix.
          if (s.footerVersion === 'v3.44.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.45.0',
            } as PortalSettings
          }
          // v3.46.0 — Level/Batch Completion Certificate support.
          //   • New `generateLevelCertificate` store action + new optional
          //     `certificateType` / `levelName` / `chapterNames` fields on the
          //     Certificate interface. Existing persisted certificates don't
          //     have these fields; we backfill `certificateType: 'exam'` so
          //     every consumer's `cert.certificateType === 'level'` check
          //     returns false for legacy exam certs.
          //   • Bumps footer version to v3.46.0.
          if (s.footerVersion === 'v3.45.0') {
            if (Array.isArray(merged.certificates)) {
              merged.certificates = merged.certificates.map((c: any) => ({
                ...c,
                certificateType: c.certificateType ?? 'exam',
              }))
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.46.0',
            } as PortalSettings
          }
          // v3.48.0 — Fix level-name duplication in Level Completion
          //   certificates. Previously the admin generate dialog synthesised
          //   `levelName = "Level N"` from the path-order number AND prepended
          //   "Level N —" before the batch name, so a batch literally named
          //   "Level 1" rendered as "Level 1 — Level 1". We now store the
          //   batch's own name as `levelName` and dedupe the dropdown label.
          //   • Bumps footer version to v3.48.0.
          if (s.footerVersion === 'v3.46.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.48.0',
            } as PortalSettings
          }
          // v3.49.0 — Header profile menu fix + responsive verification.
          //   • The profile avatar dropdown's "Profile" item had no onClick
          //     handler (clicking it did nothing). Now: students → Profile
          //     page, admins → Settings (which holds the Profile tab).
          //   • "Billing" / "Keyboard shortcuts" / "Help & support" items
          //     also gained handlers so the whole menu is functional.
          //   • Full responsive audit passed at 320 / 375 / 768 / 1440 /
          //     1920px with zero horizontal overflow on every page.
          //   • Bumps footer version to v3.49.0.
          if (s.footerVersion === 'v3.48.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.49.0',
            } as PortalSettings
          }
          // v3.50.0 — Marketing Campaigns module.
          //   • New "Marketing" admin page: create banner-image or YouTube-video
          //     campaigns targeted at all students, specific batches (by name),
          //     or individual students (by id).
          //   • Campaigns render on the student dashboard immediately after the
          //     existing brand banner, in ascending `priority` order, respecting
          //     `status === 'published'`, the [startDate, endDate] window, and
          //     audience match (all / batch / individual).
          //   • Admin list page supports Edit, Duplicate, Pause/Resume, Delete.
          //   • Inserts the new `marketing` nav item into custom admin navs
          //     (after Announcements) so existing users see it without a reset.
          //   • Bumps footer version to v3.50.0.
          if (s.footerVersion === 'v3.49.0') {
            // Ensure marketingCampaigns collection exists (backfilled above
            // for empty/missing arrays).
            if (!Array.isArray(merged.marketingCampaigns)) {
              merged.marketingCampaigns = seedMarketingCampaigns
            }
            // Insert 'marketing' nav item into custom admin navs if missing,
            // rebuilding from the canonical default order so it lands in its
            // proper position (after Announcements) rather than at the bottom.
            if (merged.settings?.adminNav && Array.isArray(merged.settings.adminNav)) {
              const hasMarketing = merged.settings.adminNav.some((n) => n.id === 'marketing')
              if (!hasMarketing) {
                const overrides = new Map(merged.settings.adminNav.map((n) => [n.id, n]))
                merged.settings = {
                  ...merged.settings,
                  adminNav: defaultAdminNav.map((d) => {
                    const ov = overrides.get(d.id)
                    return ov ? { ...d, label: ov.label ?? d.label, hidden: ov.hidden } : d
                  }),
                } as PortalSettings
              }
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.50.0',
            } as PortalSettings
          }
          // v39 (v3.51.0): Backup system overhaul — removed the Danger Zone
          //   / Reset option from Settings → Backup, and the “Take Backup”
          //   button now generates a complete full-project ZIP (every file +
          //   folder in the project root plus a JSON export of the entire
          //   database) for one-click disaster recovery / migration. Also
          //   adds an importDatabase store action and a Restore Database
          //   upload control. No persisted-shape change; cosmetic
          //   footer-version bump for existing users.
          if (s.footerVersion === 'v3.50.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.51.0',
            } as PortalSettings
          }
          // v40 (v3.52.0): Text Banner campaign type added to the Marketing
          //   module. New 'text' value on MarketingCampaign.type with a
          //   messageContent field supporting dynamic placeholders
          //   ({{student_name}}, {{first_name}}, {{level}}, …) resolved
          //   per-student at render time. The seed MC003 text campaign is
          //   appended if missing so existing users see the new format.
          //   No persisted-shape change beyond the optional messageContent
          //   field; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.51.0') {
            // Backfill the MC003 text campaign if the user's persisted
            // collection doesn't already include it.
            if (
              Array.isArray(merged.marketingCampaigns) &&
              !merged.marketingCampaigns.some((c) => c.id === 'MC003')
            ) {
              const mc3 = seedMarketingCampaigns.find((c) => c.id === 'MC003')
              if (mc3) {
                merged.marketingCampaigns = [...merged.marketingCampaigns, mc3]
              }
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.52.0',
            } as PortalSettings
          }
          // v41 (v3.53.0): Marketing module polish.
          //   • Text Banner card footer now renders the administrator's
          //     profile photo (settings.adminPhoto) + name/designation as a
          //     hand-signed institute message instead of a generic icon.
          //   • Removed the hardcoded /branding/power-maths-banner.jpg static
          //     banner from the student dashboard — all dashboard promotions
          //     now flow through the centralized Marketing module (Banner
          //     Image / YouTube Video / Text Announcement).
          //   • The MC001 seed banner previously reused the brand banner
          //     image (/branding/power-maths-banner.jpg) which created visual
          //     confusion with the removed static banner. Any marketing
          //     banner campaign still pointing at the old brand banner is
          //     rewritten to use the new IELTS-themed promotional banner
          //     (/branding/ielts-batch-banner.png) so the dashboard clearly
          //     shows a Marketing-managed promo, not the old static banner.
          //     Admin-uploaded custom banners (data URLs) are left untouched.
          if (s.footerVersion === 'v3.52.0') {
            if (Array.isArray(merged.marketingCampaigns)) {
              merged.marketingCampaigns = merged.marketingCampaigns.map((c) => {
                if (
                  c.type === 'banner' &&
                  typeof c.image === 'string' &&
                  c.image === '/branding/power-maths-banner.jpg'
                ) {
                  return { ...c, image: '/branding/ielts-batch-banner.png' }
                }
                return c
              })
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.0',
            } as PortalSettings
          }
          // v42 (v3.53.1): Responsive header polish.
          //   • Mobile header icon buttons enlarged from 36px (h-9 w-9) to
          //     44px (h-11 w-11) to meet Apple HIG / Material tap-target
          //     guidelines.
          //   • Fullscreen + Settings buttons moved into a "More actions"
          //     overflow dropdown on mobile/tablet to free up horizontal
          //     space for the page title.
          //   • Page title font scaled down to text-xs on mobile so longer
          //     titles like "Question Bank" / "Batch Management" fit without
          //     heavy truncation at 375px.
          //   No persisted-shape change; cosmetic footer-version bump so the
          //   new layout is visible to existing users.
          if (s.footerVersion === 'v3.53.0') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.1',
            } as PortalSettings
          }
          // v43 (v3.53.2): Manage Content polish.
          //   • "Tests" content tab renamed to "Exams" so the vocabulary
          //     matches the standalone Exams module.
          //   • The Exams tab now shows exams linked to the chapter via
          //     `exam.chapterId` (read from the global `exams` array)
          //     instead of the disconnected `chapter.tests` stub array.
          //   • Added Move Up / Move Down + Rename action buttons next to
          //     the existing Delete button on Materials and Practice rows.
          //   • Added an "Add Exam" button inside the Exams tab so admins
          //     can create a chapter-linked exam without leaving Manage
          //     Content.
          //   No persisted-shape change required — the new store actions
          //   (updatePracticeSheet, reorderStudyMaterials,
          //   reorderPracticeSheets) operate on existing array fields.
          if (s.footerVersion === 'v3.53.1') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.2',
            } as PortalSettings
          }
          // v44 (v3.53.3): Exam form + Manage Content >> Exams polish.
          //   • Exam form question picker now has 4 filters: search box,
          //     difficulty, question type, and marks. "Select all" now
          //     selects all FILTERED questions (not all chapter questions).
          //   • The Exams tab in Manage Content no longer deletes the exam
          //     from the global exams array. Instead, it "unlinks" the exam
          //     from the chapter (sets chapterId to '' so it disappears from
          //     this chapter's view but stays in the Exams manager).
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.2') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.3',
            } as PortalSettings
          }
          // v45 (v3.53.4): Popup overflow fix.
          //   • "Create new Level" dialog in Batch Management now has
          //     max-h-[90vh] overflow-y-auto so the exam list and action
          //     buttons are reachable on short screens.
          //   • Same defensive fix applied to View Result, Edit Email
          //     Template, and Generate Certificate dialogs.
          //   • Inner exam/chapter/question lists in the Level dialog
          //     bumped from max-h-[340px] to max-h-[50vh] so they show
          //     more rows on taller screens.
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.3') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.4',
            } as PortalSettings
          }
          // v46 (v3.53.5): Popup overflow REAL fix.
          //   • Root cause: the base DialogContent used `grid` without a
          //     max-h, so it grew past the viewport on short screens. The
          //     v3.53.4 per-dialog fix only worked on tall screens.
          //   • Fix: the shared DialogContent now always caps at
          //     `max-h-[calc(100vh-2rem)] overflow-y-auto`. twMerge lets
          //     callers override (e.g. the PDF viewer uses overflow-hidden).
          //   • Inner exam/chapter/student lists in the Create Level
          //     dialog changed from max-h-[50vh] to max-h-[40vh] so they
          //     leave room for header, tabs and footer buttons.
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.4') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.5',
            } as PortalSettings
          }
          // v47 (v3.53.6): Question Bank Import feature.
          //   • New "Import" button in the Question Bank header (between
          //     Export and Add Question) opens a dialog that parses
          //     questions from .docx / .pdf / .txt files (mammoth +
          //     pdf-parse, both run in the browser — no server upload).
          //   • Multi-select chapter picker (same UX as Create Question).
          //   • Preview table with inline edit before import.
          //   • New store action `addQuestions(qs)` for bulk import.
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.5') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.6',
            } as PortalSettings
          }
          // v48 (v3.53.7): Fresh backup checkpoint.
          //   • Question Bank Import feature fully verified working by user
          //     (.docx / .pdf / .txt extraction with multi-line explanations
          //     preserved, preview rendering correctly, import stores all
          //     fields including explanations with \n preserved).
          //   • No code or shape changes — cosmetic footer-version bump so
          //     the v3.53.7 backup is identifiable in the portal footer.
          if (s.footerVersion === 'v3.53.6') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.7',
            } as PortalSettings
          }
          // v49 (v3.53.8): Import popup — Marks/Difficulty/Type defaults + Solution: rename.
          //   • The Import dialog now has 3 default fields (Marks, Difficulty,
          //     Type) set in the popup — no longer required in the Word/PDF file.
          //   • `Solution:` is now the preferred key (replaces `Explanation:`;
          //     both still recognized).
          //   • If the file does specify Marks/Difficulty/Type, the file's
          //     values take priority over the popup defaults.
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.7') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.8',
            } as PortalSettings
          }
          // v50 (v3.53.9): PDF import fix.
          //   • pdf-parse v2.x exports a NAMED CLASS `PDFParse` (not a
          //     default function) — old code tried `mod.default || mod`
          //     which was undefined → "pdfParse is not a function" error.
          //   • Now correctly uses `new PDFParse({ data })` + `.getText()`.
          //   • Configures the pdf.js worker via `PDFParse.setWorker()` —
          //     the worker file is served from /vendor/pdf.worker.min.mjs
          //     (copied from pdf-parse's web build to match the API version).
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.53.8') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.53.9',
            } as PortalSettings
          }
          // v51 (v3.54.0): Difficulty → Levels (12 levels).
          //   • The 4 difficulty tiers (very-easy/easy/medium/hard) are
          //     replaced with 12 levels (level-1 … level-12).
          //   • All UI labels changed from "Difficulty" to "Level".
          //   • Existing persisted questions are migrated:
          //       very-easy → level-1
          //       easy     → level-4
          //       medium   → level-7
          //       hard     → level-11
          //   • The field name stays `difficulty` for backward compat.
          if (s.footerVersion === 'v3.53.9') {
            if (Array.isArray(merged.questions)) {
              const diffMap: Record<string, string> = {
                'very-easy': 'level-1',
                'easy': 'level-4',
                'medium': 'level-7',
                'hard': 'level-11',
              }
              merged.questions = merged.questions.map((q) => {
                if (q && typeof q.difficulty === 'string' && diffMap[q.difficulty]) {
                  return { ...q, difficulty: diffMap[q.difficulty] }
                }
                return q
              })
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.54.0',
            } as PortalSettings
          }
          // v52 (v3.54.1): Real curriculum reset.
          //   • Demo chapters replaced with 6 real chapters:
          //     Number System, LR, Geometry, Mental Maths, Vedic Maths, Statistics
          //   • All demo questions removed (315 → 0)
          //   • All demo exams removed (7 → 0)
          //   • Persisted chapters/questions/exams are wiped and replaced
          //     with the new 6 empty chapters so the admin starts fresh.
          //   • Results + certificates that reference old question/exam IDs
          //     are also cleared (they'd be broken without the questions).
          if (s.footerVersion === 'v3.54.0') {
            // Replace persisted chapters with the new 6 real chapters
            merged.chapters = seedChapters.map((c) => ({ ...c }))
            // Clear all questions and exams
            merged.questions = []
            merged.exams = []
            // Clear results + certificates that reference old data
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.54.1',
            } as PortalSettings
          }
          // v53 (v3.54.2): Load real curriculum data (180 questions + 8 exams).
          //   • The admin's actual question bank (180 MCQs across Number
          //     System / LR / Geometry) and exam list (8 exams: L1T1-L1T6,
          //     L1C1, L1S1) are now embedded as seed data so they survive
          //     session resets.
          //   • On existing browsers that already have v3.54.1 data, we
          //     re-seed from the embedded real data so nothing is lost.
          //   • Stale demo results + certificates (which referenced old
          //     question/exam IDs from v3.49) are cleared.
          if (s.footerVersion === 'v3.54.1') {
            // Load the real curriculum questions + exams into persisted state
            merged.questions = REAL_DATA_QUESTIONS.map((q) => ({ ...q }))
            merged.exams = REAL_DATA_EXAMS.map((e) => ({ ...e }))
            // Clear stale demo results + certificates (they reference old IDs)
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.54.2',
            } as PortalSettings
          }
          // v54 (v3.54.3): Updated real curriculum data (420 questions + 18 exams).
          //   • The admin added 240 more questions (180→420) and 10 more exams
          //     (8→18). All 6 chapters now have questions:
          //       Number System: 60, LR: 40, Geometry: 80,
          //       Mental Maths: 60, Vedic Maths: 40, Statistics: 140
          //   • Re-seed from the updated embedded data so existing browsers
          //     pick up the new questions + exams.
          //   • Stale demo results + certificates cleared again.
          if (s.footerVersion === 'v3.54.2') {
            merged.questions = REAL_DATA_QUESTIONS.map((q) => ({ ...q }))
            merged.exams = REAL_DATA_EXAMS.map((e) => ({ ...e }))
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.54.3',
            } as PortalSettings
          }
          // v55 (v3.54.4): Force-clear accumulated old demo questions.
          //   • Some browsers had 735 questions (420 real + 315 old demo
          //     from v3.49 that wasn't fully cleared by earlier migrations).
          //   • This migration FORCES the questions + exams to match the
          //     embedded real data exactly (420 questions + 18 exams),
          //     regardless of what was previously in localStorage.
          //   • Also clears stale demo results + certificates.
          if (s.footerVersion === 'v3.54.3') {
            merged.questions = REAL_DATA_QUESTIONS.map((q) => ({ ...q }))
            merged.exams = REAL_DATA_EXAMS.map((e) => ({ ...e }))
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.54.4',
            } as PortalSettings
          }
          // v56 (v3.55.0): Levels Management rename + Chapter Level filter.
          //   • "Batch Management" renamed to "Levels Management" in nav,
          //     header title, and command palette.
          //   • New optional `batchId` field on Chapter (soft tag for the
          //     Chapters page Level filter — does NOT affect student
          //     inheritance or the batch.chapterIds master relationship).
          //   • New Level filter dropdown on the Chapters page.
          //   • New Level picker in the Add/Edit Chapter dialog.
          //   No persisted-shape change required (batchId is optional).
          if (s.footerVersion === 'v3.54.4') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.55.0',
            } as PortalSettings
          }
          // v57 (v3.55.1): UI polish + nav label fix.
          //   • Chapter cards now show assigned Level name in bold.
          //   • "Enrolled Students" stat card replaced with "Total Levels".
          //   • All remaining "Batch" strings renamed to "Level".
          //   • Fixes persisted nav label: if the admin's settings.adminNav
          //     still has "Batch Management" (from old versions), update it
          //     to "Levels Management" so Settings >> Navigation shows the
          //     correct label.
          if (s.footerVersion === 'v3.55.0') {
            if (Array.isArray(merged.settings.adminNav)) {
              merged.settings.adminNav = merged.settings.adminNav.map((n) => {
                if (n.id === 'batches' && n.label === 'Batch Management') {
                  return { ...n, label: 'Levels Management' }
                }
                return n
              })
            }
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.55.1',
            } as PortalSettings
          }
          // v58 (v3.55.2): Chapter card layout + Exams grid view.
          //   • Chapter cards: Level name now on its own bold line, then
          //     small "#1 · CH001" below (was all on one line).
          //   • Exams page: Grid/List view toggle (default grid), Chapter
          //     filter, Type filter. Removed Attempts, Avg score, Created
          //     date from both views.
          if (s.footerVersion === 'v3.55.1') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.55.2',
            } as PortalSettings
          }
          // v59 (v3.56.0): Exam Level filter + Level picker in Exam form.
          //   • New optional `batchId?: string` field on the Exam interface
          //     (soft tag for the Exams page Level filter — mirrors the
          //     Chapter.batchId pattern from v3.55.0).
          //   • New Level filter dropdown on the Exams page (between
          //     Chapter and Status filters).
          //   • New Level picker in the Create/Edit Exam dialog (3rd
          //     column next to Chapter and Type).
          //   • Level badge shown on exam grid cards + list view rows.
          //   • The master relationship (batch.examIds[]) is unchanged.
          //   No persisted-shape change; cosmetic footer-version bump.
          if (s.footerVersion === 'v3.55.2') {
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.56.0',
            } as PortalSettings
          }
          // v60 (v3.56.1): Updated real curriculum data.
          //   • Questions: 420 → 660 (+240 Level 2 questions)
          //   • Exams: 18 → 29 (+11 Level 2 exams)
          //   • Chapters: 6 → 14 (added 8 Level 2 chapters + Equations + Algebra)
          //   • Batches: 4 demo → 2 real (Level 1 + Level 2)
          //   • All chapters + exams now have batchId assigned
          //   • Re-seed from the updated embedded data so existing browsers
          //     pick up the new questions + exams + chapters + batches.
          if (s.footerVersion === 'v3.56.0') {
            merged.chapters = seedChapters.map((c) => ({ ...c }))
            merged.batches = seedBatches.map((b) => ({ ...b }))
            merged.questions = REAL_DATA_QUESTIONS.map((q) => ({ ...q }))
            merged.exams = REAL_DATA_EXAMS.map((e) => ({ ...e }))
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.56.1',
            } as PortalSettings
          }
          // v61 (v3.56.2): Updated real curriculum data.
          //   • Questions: 660 → 940 (+280 new Level 2 questions)
          //   • Exams: 29 → 41 (+12 new Level 2 exams)
          //   • All 14 chapters now have questions (Vedic Maths L2, Statistics L2,
          //     Equations L2, Algebra L2 all filled in)
          //   • Re-seed from the updated embedded data.
          if (s.footerVersion === 'v3.56.1') {
            merged.chapters = seedChapters.map((c) => ({ ...c }))
            merged.batches = seedBatches.map((b) => ({ ...b }))
            merged.questions = REAL_DATA_QUESTIONS.map((q) => ({ ...q }))
            merged.exams = REAL_DATA_EXAMS.map((e) => ({ ...e }))
            merged.results = []
            merged.certificates = []
            merged.settings = {
              ...merged.settings,
              footerVersion: 'v3.56.2',
            } as PortalSettings
          }
        }
        return merged
      },
    }
  )
)

// Merge a persisted nav list with the defaults — keeps the persisted order
// + labels, but appends any default items that are missing (e.g. new pages
// added in a later release).
function mergeNav(defaults: NavItemConfig[], persisted?: NavItemConfig[]): NavItemConfig[] {
  if (!persisted || !Array.isArray(persisted) || persisted.length === 0) return defaults
  const out = persisted.map((p) => {
    const d = defaults.find((d) => d.id === p.id)
    return d ? { ...d, label: p.label ?? d.label, hidden: p.hidden } : p
  })
  for (const d of defaults) {
    if (!out.some((o) => o.id === d.id)) out.push(d)
  }
  return out
}

// ─────────────────────── Selectors / Helpers ───────────────────────

export const getStudentResults = (studentId: string) =>
  useDataStore.getState().results.filter((r) => r.studentId === studentId)

export const getStudentCertificates = (studentId: string) =>
  useDataStore.getState().certificates.filter((c) => c.studentId === studentId && c.status === 'issued')

export const getStudentProgress = (studentId: string) => {
  const { students, chapters, results } = useDataStore.getState()
  const student = students.find((s) => s.id === studentId)
  if (!student) return []
  return student.assignedChapters.map((chId) => {
    const chapter = chapters.find((c) => c.id === chId)
    if (!chapter) return null
    const chResults = results.filter((r) => r.studentId === studentId && r.chapterName === chapter.name)
    const bestScore = chResults.length ? Math.max(...chResults.map((r) => r.percentage)) : 0
    const passed = chResults.some((r) => r.status === 'passed')
    const status: 'completed' | 'in_progress' | 'not_started' = passed ? 'completed' : chResults.length ? 'in_progress' : 'not_started'
    return { chapter, status, bestScore, attempts: chResults.length }
  }).filter(Boolean)
}

export const getExamQuestions = (exam: Exam): Question[] => {
  const { questions } = useDataStore.getState()
  return exam.questionIds.map((qid) => questions.find((q) => q.id === qid)).filter(Boolean) as Question[]
}

/**
 * v3.27.0 — Returns the question set a SPECIFIC student should see.
 *
 * If the exam has a `questionPoolIds` and `questionsToPick`, a subset of N
 * questions is picked from the pool. The picking is seeded by
 * `studentId + examId` so the same student sees the same subset on a retake
 * (deterministic), unless `poolSeedByStudent` is false.
 *
 * Falls back to `getExamQuestions` when no pool is configured.
 */
export const getExamQuestionsForStudent = (exam: Exam, studentId: string): Question[] => {
  const { questions } = useDataStore.getState()

  // No pool → standard behaviour.
  if (!exam.questionPoolIds || exam.questionPoolIds.length === 0 || !exam.questionsToPick) {
    return getExamQuestions(exam)
  }

  const pool = exam.questionPoolIds
    .map((qid) => questions.find((q) => q.id === qid))
    .filter(Boolean) as Question[]

  if (pool.length === 0) return getExamQuestions(exam)

  // Deterministic seeded pick (so retakes are fair to the student).
  const seed = exam.poolSeedByStudent === false
    ? `${exam.id}-${Date.now()}`
    : `${exam.id}-${studentId}`

  // Inline mulberry32 + Fisher-Yates (kept here so data-store stays
  // dependency-free; mirrors exam-proctor.ts pickFromPool but we can't import
  // a 'use client' module here).
  let h = 0
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0
  const rng = () => {
    h = (h * 1664525 + 1013904223) >>> 0
    return h / 4294967296
  }
  const arr = [...pool]
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr.slice(0, Math.min(exam.questionsToPick, arr.length))
}

export const getDashboardStats = () => {
  const s = useDataStore.getState()
  const today = new Date().toISOString().slice(0, 10)
  return {
    totalStudents: s.students.length,
    activeToday: s.students.filter((st) => st.lastLogin?.startsWith(today)).length,
    totalChapters: s.chapters.length,
    totalExams: s.exams.length,
    totalQuestions: s.questions.length,
    totalMaterials: s.chapters.reduce((a, c) => a + c.studyMaterials.length + c.practiceSheets.length, 0),
    totalCertificates: s.certificates.filter((c) => c.status === 'issued').length,
    passRate: s.results.length ? Math.round((s.results.filter((r) => r.status === 'passed').length / s.results.length) * 100) : 0,
    avgScore: s.results.length ? Math.round(s.results.reduce((a, r) => a + r.percentage, 0) / s.results.length) : 0,
  }
}
