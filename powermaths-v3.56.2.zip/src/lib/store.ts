'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type Role = 'admin' | 'student'
export type AdminPage =
  | 'dashboard'
  | 'students'
  | 'batches'
  | 'chapters'
  | 'questions'
  | 'exams'
  | 'results'
  | 'certificates'
  | 'student-reports'
  | 'notifications'
  | 'announcements'
  | 'marketing'
  | 'activity'
  | 'email-templates'
  | 'email-log'
  | 'settings'
export type StudentPage =
  | 'dashboard'
  | 'levels'        // v3.44.0 — Level / Batch learning path
  | 'chapters'
  | 'practice'
  | 'exams'
  | 'results'
  | 'certificates'
  | 'notifications'
  | 'notes'
  | 'messages'
  | 'profile'
  | 'settings'

export interface SessionUser {
  id: string
  name: string
  email: string
  role: Role
  avatarColor?: string
  batch?: string
}

/**
 * Chapter learning view state for the student portal.
 *  • `mode: 'list'`    — show the chapters list (default)
 *  • `mode: 'learning'`— render the full-page Chapter Learning Page for the
 *                        chapter identified by `chapterId`. The left sidebar
 *                        and top header stay visible; only the content area
 *                        switches. The PDF Viewer remains the only popup.
 */
export interface StudentChapterView {
  mode: 'list' | 'learning'
  chapterId?: string
}

interface AppState {
  // Auth
  user: SessionUser | null
  loginAs: (role: Role) => void
  logout: () => void

  // Navigation
  adminPage: AdminPage
  studentPage: StudentPage
  setAdminPage: (p: AdminPage) => void
  setStudentPage: (p: StudentPage) => void

  // Student chapter learning view (drives the full-page Chapter Learning Page)
  studentChapterView: StudentChapterView
  openChapterLearning: (chapterId: string) => void
  closeChapterLearning: () => void

  // Layout
  sidebarCollapsed: boolean
  toggleSidebar: () => void
  setSidebarCollapsed: (v: boolean) => void
  mobileSidebarOpen: boolean
  setMobileSidebarOpen: (v: boolean) => void

  // Command palette
  commandOpen: boolean
  setCommandOpen: (v: boolean) => void

  // Exam lockdown flag — true while a student is taking an exam. The Friend
  // chatbot hides itself and the browser proctoring hooks are active.
  examInProgress: boolean
  setExamInProgress: (v: boolean) => void
}

const ADMIN_USER: SessionUser = {
  id: 'ADMIN001',
  name: 'Prof. Kalpesh Vyas',
  email: 'admin@powermaths.com',
  role: 'admin',
  avatarColor: 'emerald',
}

const STUDENT_USER: SessionUser = {
  id: 'STU1024',
  name: 'Aarav Sharma',
  email: 'aarav.sharma@student.com',
  role: 'student',
  avatarColor: 'teal',
  batch: 'Batch 2026-A',
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      loginAs: (role) =>
        set({
          user: role === 'admin' ? ADMIN_USER : STUDENT_USER,
          adminPage: 'dashboard',
          studentPage: 'dashboard',
        }),
      logout: () => set({ user: null, mobileSidebarOpen: false }),

      adminPage: 'dashboard',
      studentPage: 'dashboard',
      setAdminPage: (p) => set({ adminPage: p, mobileSidebarOpen: false }),
      setStudentPage: (p) => set({ studentPage: p, mobileSidebarOpen: false }),

      // Chapter learning view — defaults to the chapters list. When the
      // student clicks "Review Chapter" / "Start Learning" / "Continue",
      // `openChapterLearning` switches the content area to the full-page
      // Chapter Learning Page (sidebar + header stay visible).
      studentChapterView: { mode: 'list' },
      openChapterLearning: (chapterId) =>
        set({ studentChapterView: { mode: 'learning', chapterId }, mobileSidebarOpen: false }),
      closeChapterLearning: () =>
        set({ studentChapterView: { mode: 'list' } }),

      sidebarCollapsed: false,
      toggleSidebar: () =>
        set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
      mobileSidebarOpen: false,
      setMobileSidebarOpen: (v) => set({ mobileSidebarOpen: v }),

      commandOpen: false,
      setCommandOpen: (v) => set({ commandOpen: v }),

      examInProgress: false,
      setExamInProgress: (v) => set({ examInProgress: v }),
    }),
    {
      name: 'pm-portal-store',
      partialize: (s) => ({
        user: s.user,
        adminPage: s.adminPage,
        studentPage: s.studentPage,
        sidebarCollapsed: s.sidebarCollapsed,
        // NOTE: `studentChapterView` is intentionally NOT persisted — a
        // fresh page load should always land the student on the chapters
        // list, never on a stale chapter learning view.
      }),
    }
  )
)
