/**
 * question-hints.ts
 *
 * Three-tier hint ladders for all 315 Power Maths seed questions
 * (Q001-Q024 base, Q025-Q135 expanded, Q200-Q379 v3.25.0).
 *
 * Each hint ladder is [hint1, hint2, hint3]:
 *   - Hint 1: concept nudge (no formula, no answer)
 *   - Hint 2: formula / method (no numbers plugged in)
 *   - Hint 3: half-worked set-up that stops just before the final answer
 *
 * Plain-text only (no LaTeX / markdown). Use ^, *, sqrt(), / and Greek
 * letter names (theta, pi). Hints kept under ~120 chars to fit a chat bubble.
 */

export type HintLadder = [string, string, string]

export const QUESTION_HINTS: Record<string, HintLadder> = {
  // ───────────────────────────── Q001-Q024 (base) ─────────────────────────────
  Q001: [
    'Recall which numbers cannot be written as p/q.',
    'Irrational numbers have non-terminating, non-recurring decimals.',
    '1/2, 0.5 and -3 are rational. The remaining option involves a square root.',
  ],
  Q002: [
    'Use prime factorisation of both numbers.',
    'LCM = product of highest powers of all prime factors.',
    '12 = 2^2*3 and 18 = 2*3^2. LCM = 2^2 * 3^2. Now multiply these out.',
  ],
  Q003: [
    'Think about how rational numbers behave in decimal form.',
    'Rational decimals either end (terminate) or repeat a block.',
    'Eliminate the non-terminating non-recurring option. Pick the one covering both endings and repeats.',
  ],
  Q004: [
    'Recall the definition of a rational number.',
    'A rational number can be written as p/q with q not zero.',
    'Any integer n can be written as n/1. Denominator 1 is allowed.',
  ],
  Q005: [
    'Recognise the exponent 1/2 as a square root.',
    'x^(1/2) means sqrt(x).',
    '0.0001 = 1/10000, sqrt(0.0001) = sqrt(1/10000). Take the square root of numerator and denominator.',
  ],
  Q006: [
    'Isolate the variable term on one side.',
    'For ax + b = c, subtract b from both sides then divide by a.',
    '3x = 22 - 7 = 15. Now divide both sides by 3.',
  ],
  Q007: [
    'Move the constant to the right side first.',
    'For ax^2 + c = 0, x^2 = -c/a then take the positive square root.',
    '2x^2 = 8, so x^2 = 4. Take the positive square root of 4.',
  ],
  Q008: [
    'Spot the special binomial pattern.',
    'Difference of squares: a^2 - b^2 = (a - b)(a + b).',
    'Here a = x and b = 3, since 9 = 3^2. Apply the identity directly.',
  ],
  Q009: [
    'Use the distributive law on each term.',
    '(x+a)(x+b) = x^2 + (a+b)x + ab.',
    'Multiply x*x, x*3, 2*x and 2*3, then collect like terms.',
  ],
  Q010: [
    'Recall how the degree of a polynomial is defined.',
    'Degree of a term = sum of exponents of its variables.',
    'For 3x^2y: exponents are 2 and 1. Add them. Compare to the degree of 5xy.',
  ],
  Q011: [
    'Recall the angle-sum property of a triangle.',
    'The three interior angles of any triangle always sum to a constant.',
    'That constant is 180 degrees, regardless of the triangle type.',
  ],
  Q012: [
    'Use the circumference formula of a circle.',
    'Circumference C = 2 * pi * r.',
    'Substitute r = 7 and pi = 22/7: C = 2 * (22/7) * 7. Simplify the 7s.',
  ],
  Q013: [
    'Think about the sides of a right triangle.',
    'The side opposite the 90 degree angle has a special name.',
    'It is also the longest side of the triangle. Eliminate Adjacent, Opposite and Base.',
  ],
  Q014: [
    'Recall what complementary angles mean.',
    'Complementary angles add up to 90 degrees.',
    'Other angle = 90 - 35. Subtract to finish.',
  ],
  Q015: [
    'Use the standard values of sin and cos at 30 and 60 degrees.',
    'sin 30 deg = 1/2 and cos 60 deg = 1/2.',
    'Substitute: 1/2 + 1/2. Now add the two fractions.',
  ],
  Q016: [
    'Recall the standard value at 45 degrees.',
    'tan theta = sin theta / cos theta. At 45 deg sin = cos.',
    'A number divided by itself gives which value? Eliminate 0, sqrt3 and 1/sqrt3.',
  ],
  Q017: [
    'Recall the most famous trig identity.',
    'Pythagorean identity: sin^2 theta + cos^2 theta = ?',
    'Think of a right triangle with sides a, b, hypotenuse 1. sin^2 + cos^2 = (a^2 + b^2)/1^2.',
  ],
  Q018: [
    'Use the Pythagorean identity.',
    'cos^2 theta = 1 - sin^2 theta, so cos theta = sqrt(1 - sin^2 theta).',
    'sin^2 = 9/25, so cos^2 = 1 - 9/25 = 16/25. Take the positive square root.',
  ],
  Q019: [
    'Use the volume formula for a cube.',
    'Volume of a cube = side^3.',
    'Substitute side = 5: V = 5^3 = 5 * 5 * 5. Multiply out.',
  ],
  Q020: [
    'Use the area formula for a rectangle.',
    'Area of rectangle = length * breadth.',
    'Substitute l = 8 and b = 5: A = 8 * 5. Multiply.',
  ],
  Q021: [
    'Think about how a sphere is curved in all directions.',
    'Surface area of a sphere = 4 * pi * r^2.',
    'Eliminate pi*r^2 (circle area), (4/3)pi*r^3 (volume) and 2*pi*r (circumference).',
  ],
  Q022: [
    'Recall the formula for the mean.',
    'Mean = (sum of all values) / (number of values).',
    'Sum = 2+4+6+8+10 = 30, count = 5. Divide 30 by 5.',
  ],
  Q023: [
    'Think about the probability scale from 0 to 1.',
    'Probability 0 = impossible, probability 1 = certain.',
    'An impossible event cannot ever occur, so its probability is the lower bound.',
  ],
  Q024: [
    'Recall how the median is found.',
    'Median = middle value when data is sorted.',
    'With 5 sorted values, the middle (3rd) value is the median. Pick it from 3, 5, 7, 9, 11.',
  ],

  // ───────────────────────────── Q025-Q135 (expanded) ─────────────────────────────
  Q025: [
    'Recall where the natural numbers start.',
    'Natural numbers are 1, 2, 3, ... — they start at 1.',
    'Eliminate 0 (whole number), -1 (negative) and 2 (not the smallest).',
  ],
  Q026: [
    'Recall where the whole numbers start.',
    'Whole numbers are 0, 1, 2, 3, ... — they include 0.',
    'Eliminate 1, -1 and 2 — none of them is the smallest whole number.',
  ],
  Q027: [
    'Compare the two number sets.',
    'Natural = {1, 2, 3, ...}; Whole = {0, 1, 2, 3, ...}.',
    'Every natural number also appears in the whole-number list, so the statement is True.',
  ],
  Q028: [
    'Compare whole numbers and integers.',
    'Integers = {..., -3, -2, -1, 0, 1, 2, 3, ...}.',
    'Whole numbers (0, 1, 2, ...) are the non-negative part of the integers, so the statement is True.',
  ],
  Q029: [
    'Recall what absolute value means.',
    'Absolute value |n| is the distance from 0, always non-negative.',
    'Drop the minus sign from -7. The result is the distance from 0.',
  ],
  Q030: [
    'Recall which numbers are rational.',
    'Rational numbers can be written as p/q (q not zero).',
    '0.333... = 1/3 is rational. sqrt2, pi and sqrt3 cannot be written as p/q.',
  ],
  Q031: [
    'Convert the fraction to a decimal.',
    'Divide the numerator by the denominator.',
    'Compute 3 / 4. Equivalently, 3/4 of 100 = 75, so divide by 100 to get the decimal.',
  ],
  Q032: [
    'Simplify the square root first.',
    'sqrt4 is a perfect square — evaluate it directly.',
    'sqrt4 = 2, which equals 2/1, so it is rational. The statement says irrational — judge True or False.',
  ],
  Q033: [
    'Recall the definition of a reciprocal.',
    'Reciprocal of n is 1/n.',
    'Apply 1/n with n = 5. The reciprocal is 1/5 (which is 0.2).',
  ],
  Q034: [
    'Add fractions with the same denominator.',
    'When denominators match, add the numerators and keep the denominator.',
    'Numerator: 2 + 1 = 3. Keep denominator 5. The sum is 3/5.',
  ],
  Q035: [
    'Compare the decimals place by place.',
    'Start at the tenths place — the largest digit there wins.',
    '0.5 has 5 in the tenths place; the others have 4 or 0. Pick the one with 5.',
  ],
  Q036: [
    'Think about when a decimal expansion ends.',
    'A fraction terminates only if the denominator (in lowest terms) has prime factors 2 and 5 only.',
    '1/3 = 0.333... is recurring, not terminating. So the statement is False.',
  ],
  Q037: [
    'List the factors of each number.',
    'HCF = highest factor common to both lists.',
    'Factors of 8: {1,2,4,8}; factors of 12: {1,2,3,4,6,12}. Largest common one is the HCF.',
  ],
  Q038: [
    'Recall the multiplicative identity.',
    'n * (1/n) = 1 for any non-zero n.',
    'The product of a number and its reciprocal always collapses to 1.',
  ],
  Q039: [
    'Recall the definition of natural numbers.',
    'Natural numbers start at 1 and go upward.',
    'Zero is part of the whole numbers, not the naturals. So the statement is False.',
  ],
  Q040: [
    'Substitute the value of x into the expression.',
    'Replace every x with the given number.',
    'Substitute x = 3: 2*3 + 1. Multiply first, then add 1.',
  ],
  Q041: [
    'Isolate x on one side.',
    'For x + a = b, subtract a from both sides.',
    'x = 12 - 5. Subtract to finish.',
  ],
  Q042: [
    'Recall the definition of like terms.',
    'Like terms must have the same variable part.',
    '5x has variable x; 5y has variable y. Different variables mean NOT like terms.',
  ],
  Q043: [
    'Combine like terms by adding coefficients.',
    'ax + bx = (a + b)x when variables match.',
    'Coefficients 3 and 2: (3 + 2)x. Add them.',
  ],
  Q044: [
    'Undo the multiplication by 3 first.',
    'For a(x + b) = c, divide both sides by a first.',
    'Divide by 3: x - 2 = 3. Then add 2 to both sides.',
  ],
  Q045: [
    'Recall what a coefficient is.',
    'The coefficient is the numerical factor multiplying the variable.',
    'In 7x the number 7 multiplies x. Decide if the statement is True.',
  ],
  Q046: [
    'Factorise a quadratic trinomial.',
    'Find two numbers that multiply to the constant and add to the middle coefficient.',
    'Need two numbers with product 6 and sum 5. They are 2 and 3. Write (x+2)(x+3).',
  ],
  Q047: [
    'Evaluate each square separately.',
    'a^2 - b^2 = (a+b)(a+b) is wrong; use direct subtraction or (a+b)(a-b).',
    '4^2 = 16 and 3^2 = 9. Subtract: 16 - 9.',
  ],
  Q048: [
    'Isolate x in a one-step equation.',
    'For ax = b, divide both sides by a.',
    'x = 10 / 2. Divide to finish.',
  ],
  Q049: [
    'Recall the expansion identity.',
    '(a + b)^2 = a^2 + 2ab + b^2.',
    'The middle term 2ab is missing from the given formula. Decide True or False.',
  ],
  Q050: [
    'Use elimination with the two equations.',
    'Adding x+y and x-y eliminates y, giving 2x.',
    '(x+y) + (x-y) = 10 + 4 = 14, so 2x = 14. Divide by 2.',
  ],
  Q051: [
    'Identify terms with the same variable.',
    'Like terms share the same variable letter.',
    '3a and -2a both contain a; 4b has a different variable. Pick that pair.',
  ],
  Q052: [
    'Recall the names for one-term expressions.',
    'Mono = one, bi = two, tri = three terms.',
    'An expression with a single term (like 5x or 7y^2) is called a monomial. Decide True or False.',
  ],
  Q053: [
    'Subtract like terms by subtracting coefficients.',
    'ax - bx = (a - b)x when variables match.',
    'Coefficients 7 and 2: (7 - 2)x. Subtract.',
  ],
  Q054: [
    'Use the square-of-a-difference identity.',
    '(a - b)^2 = a^2 - 2ab + b^2.',
    'Substitute a = x and b = 1: x^2 - 2*x*1 + 1^2. Combine the pieces.',
  ],
  Q055: [
    'Recall the definition of a triangle.',
    '"Tri" means three — a triangle is a 3-sided polygon.',
    'A triangle has exactly 3 sides and 3 angles. Decide True or False.',
  ],
  Q056: [
    'Recall what a right angle measures.',
    'A right angle is formed by two perpendicular lines.',
    'The measure of a right angle is exactly 90 degrees.',
  ],
  Q057: [
    'Use the angle-sum property.',
    'All three angles in an equilateral triangle are equal and sum to 180 deg.',
    'Each angle = 180 / 3. Divide.',
  ],
  Q058: [
    'Recall polygon names by side count.',
    'Quad = four, so a 4-sided polygon is a quadrilateral.',
    'Eliminate triangle, pentagon and hexagon — they have 3, 5 and 6 sides.',
  ],
  Q059: [
    'Recall the properties of a parallelogram.',
    'A parallelogram has both pairs of opposite sides parallel and equal.',
    'Opposite sides are equal in length, so the statement is True.',
  ],
  Q060: [
    'Use the angle-sum property of a triangle.',
    'Sum of all three angles = 180 deg.',
    'Third angle = 180 - (50 + 60) = 180 - 110. Subtract.',
  ],
  Q061: [
    'Think about a full turn around a point.',
    'Angles around a single point make one complete revolution.',
    'A complete revolution measures 360 degrees.',
  ],
  Q062: [
    'Recall the definition of a square.',
    'A square has 4 equal sides and 4 right angles.',
    'All four sides are equal in length, so the statement is True.',
  ],
  Q063: [
    'Recall what a chord is.',
    'A chord joins two points on the circle; the longest one passes through the centre.',
    'The longest chord passes through the centre. It is called the diameter.',
  ],
  Q064: [
    'Use the perimeter formula for a square.',
    'Perimeter of a square = 4 * side.',
    'Substitute side = 6: P = 4 * 6. Multiply.',
  ],
  Q065: [
    'Recall rectangle properties.',
    'A rectangle has opposite sides equal and diagonals that bisect each other.',
    'In a rectangle both diagonals are equal in length, so the statement is True.',
  ],
  Q066: [
    'Recall the term for non-intersecting lines.',
    'Lines that stay the same distance apart never meet.',
    'Such lines are called parallel lines. Eliminate intersecting, perpendicular and concurrent.',
  ],
  Q067: [
    'Use the triangle area formula.',
    'Area of a triangle = (1/2) * base * height.',
    'Substitute base = 10, height = 5: A = (1/2) * 10 * 5. Multiply then halve.',
  ],
  Q068: [
    'Recall the symmetry of a circle.',
    'Each diameter of a circle is a line of symmetry.',
    'A circle has infinitely many diameters, hence infinitely many symmetry lines. Decide True or False.',
  ],
  Q069: [
    'Recall angle-type names.',
    'An angle of 180 deg looks like a straight line.',
    'Eliminate right (90 deg), acute (<90) and reflex (>180). Pick the straight-line option.',
  ],
  Q070: [
    'Recall the angle inside a square.',
    'Each interior angle of a square is a right angle.',
    'A square has 4 right angles, each 90 degrees.',
  ],
  Q071: [
    'Think about the unit circle at 0 degrees.',
    'sin theta = opposite / hypotenuse.',
    'At 0 deg the opposite side has zero length, so sin 0 deg = 0 / hypotenuse. Decide True or False.',
  ],
  Q072: [
    'Evaluate cosine at 0 degrees.',
    'cos theta = adjacent / hypotenuse.',
    'At 0 deg the adjacent side equals the hypotenuse, so cos 0 deg = hypotenuse / hypotenuse.',
  ],
  Q073: [
    'Evaluate sine at 90 degrees.',
    'sin theta = opposite / hypotenuse.',
    'At 90 deg the opposite side equals the hypotenuse, so sin 90 deg = hypotenuse / hypotenuse.',
  ],
  Q074: [
    'Recall the SOH-CAH-TOA definitions.',
    'sin = opposite/hypotenuse; cos = adjacent/hypotenuse; tan = opposite/adjacent.',
    'Eliminate cos, tan and cot — sin is the ratio of opposite to hypotenuse.',
  ],
  Q075: [
    'Recall what tan 90 deg involves.',
    'tan theta = sin theta / cos theta.',
    'At 90 deg, cos 90 deg = 0, so tan 90 deg = 1/0 — division by zero. Decide True or False.',
  ],
  Q076: [
    'Use the standard value of tan 30 deg.',
    'tan theta = sin theta / cos theta.',
    'sin 30 deg = 1/2, cos 30 deg = sqrt3/2. Divide: (1/2) / (sqrt3/2). Simplify.',
  ],
  Q077: [
    'Recall the standard value at 60 degrees.',
    'In a 30-60-90 triangle, the side adjacent to 60 deg is half the hypotenuse.',
    'cos 60 deg = (half-hypotenuse) / hypotenuse = 1/2. Pick the matching option.',
  ],
  Q078: [
    'Recall the Pythagorean identity.',
    'sin^2 theta + cos^2 theta = 1 for every angle theta.',
    'It is one of the most fundamental trig identities and holds for all theta. Decide True or False.',
  ],
  Q079: [
    'Recall the SOH-CAH-TOA sides.',
    'The adjacent side forms the angle along with the hypotenuse.',
    'Eliminate opposite (across from the angle) and hypotenuse. Pick adjacent.',
  ],
  Q080: [
    'Use the standard values at 45 degrees.',
    'sin 45 deg = cos 45 deg = 1/sqrt2.',
    'Substitute: (1/sqrt2) * (1/sqrt2). Multiply the fractions.',
  ],
  Q081: [
    'Recall the co-function identity.',
    'sin theta = cos(90 deg - theta).',
    'The two non-right angles of a right triangle are complementary. Decide True or False.',
  ],
  Q082: [
    'Recall the reciprocal trig functions.',
    'cosec = 1/sin, sec = 1/cos, cot = 1/tan.',
    'Eliminate sec (1/cos), cot (1/tan) and tan. The reciprocal of sin is cosec.',
  ],
  Q083: [
    'Match the value to a standard angle.',
    'Recall the standard cos values: cos 0 = 1, cos 30 = sqrt3/2, cos 45 = 1/sqrt2, cos 60 = 1/2, cos 90 = 0.',
    'cos 60 deg = 1/2 matches the given value. Identify the angle.',
  ],
  Q084: [
    'Recall the standard value at 30 degrees.',
    'In a 30-60-90 triangle, the side adjacent to 30 deg is sqrt3/2 times the hypotenuse.',
    'cos 30 deg = sqrt3/2 is a standard value. Decide True or False.',
  ],
  Q085: [
    'Recall the standard value of tan 60 deg.',
    'tan theta = sin theta / cos theta.',
    'sin 60 deg = sqrt3/2 and cos 60 deg = 1/2. Their ratio gives sqrt3. Identify the trig function.',
  ],
  Q086: [
    'Substitute the standard values.',
    'sin 30 deg = 1/2 and cos 60 deg = 1/2.',
    'Compute 2 * (1/2) * (1/2). Multiply step by step.',
  ],
  Q087: [
    'Use the area formula for a square.',
    'Area of a square = side * side = side^2.',
    'Substitute side = 4: A = 4 * 4. Multiply.',
  ],
  Q088: [
    'Use the perimeter formula for a rectangle.',
    'Perimeter of a rectangle = 2 * (length + breadth).',
    'Substitute l = 5, b = 3: P = 2 * (5 + 3). Add inside the bracket, then double.',
  ],
  Q089: [
    'Recall the cuboid volume formula.',
    'Volume of a cuboid = length * breadth * height.',
    'Multiply the three dimensions together. Decide if the statement is True or False.',
  ],
  Q090: [
    'Use the circle area formula.',
    'Area of a circle = pi * r^2.',
    'Eliminate 2*pi*r (circumference), (4/3)pi*r^3 (sphere volume) and pi*r (wrong). Pick pi*r^2.',
  ],
  Q091: [
    'Use the cylinder volume formula.',
    'Volume of a cylinder = pi * r^2 * h.',
    'Substitute r = 3, h = 10, pi = 3.14: V = 3.14 * 3^2 * 10. Multiply step by step.',
  ],
  Q092: [
    'Recall the litre-to-cm^3 conversion.',
    '1 litre is defined as 1000 cm^3.',
    'A 10 cm cube holds exactly 1 litre. Decide True or False.',
  ],
  Q093: [
    'Use the perimeter formula for an equilateral triangle.',
    'Equilateral perimeter = side + side + side = 3a.',
    'Eliminate 2a, 4a and a^2 — pick 3a.',
  ],
  Q094: [
    'Use the triangle area formula.',
    'Area of a triangle = (1/2) * base * height.',
    'Substitute base = 8, height = 6: A = (1/2) * 8 * 6. Multiply then halve.',
  ],
  Q095: [
    'Think about unrolling a cylinder.',
    'Curved surface area = circumference * height = 2 * pi * r * h.',
    'Width = 2*pi*r, height = h, so CSA = 2*pi*r*h. Decide True or False.',
  ],
  Q096: [
    'Compare cone and cylinder volumes.',
    'A cone has 1/3 the volume of a cylinder with the same base and height.',
    'V = (1/3) * pi * r^2 * h. Eliminate pi*r^2*h, (1/2)pi*r^2*h and pi*r*h.',
  ],
  Q097: [
    'Use the surface area formula for a cube.',
    'A cube has 6 equal square faces, each of area side^2.',
    'Each face area = 2*2 = 4. Multiply by 6 faces.',
  ],
  Q098: [
    'Recall the units of area.',
    'Area is a 2D quantity measured in cm^2, m^2, etc.',
    'Square units measure area. Decide True or False.',
  ],
  Q099: [
    'Use the parallelogram area formula.',
    'Area of a parallelogram = base * height (perpendicular height).',
    'Eliminate (1/2)*base*height (triangle), (1/2)*pi*r^2 and base + height. Pick base*height.',
  ],
  Q100: [
    'Use the circumference formula with diameter.',
    'Circumference = pi * diameter.',
    'Substitute pi = 22/7 and diameter = 14: C = (22/7) * 14. Multiply and simplify.',
  ],
  Q101: [
    'Recall the units of volume.',
    'Volume is a 3D quantity measured in cm^3, m^3, litres.',
    'Cubic units measure volume. Decide True or False.',
  ],
  Q102: [
    'Combine curved and base areas of a cylinder.',
    'Total surface area = curved area + 2 * base area = 2*pi*r*h + 2*pi*r^2.',
    'Factor out 2*pi*r: TSA = 2*pi*r*(r + h). Pick that option.',
  ],
  Q103: [
    'Use the cube volume formula.',
    'Volume of a cube = side^3.',
    'Substitute side = 3: V = 3^3 = 3*3*3. Multiply out.',
  ],
  Q104: [
    'Recall the measure of central tendency for "most frequent".',
    'The mode is the value that appears most often.',
    'Eliminate mean (average), median (middle) and range (spread). Pick mode.',
  ],
  Q105: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 5 + 10 + 15 = 30, count = 3. Divide 30 by 3.',
  ],
  Q106: [
    'Recall the probability scale.',
    'A sure (certain) event always happens — its probability is the upper bound.',
    'The maximum probability is 1, which corresponds to certainty. Decide True or False.',
  ],
  Q107: [
    'Recall the middle-value measure.',
    'The median is the middle value when data is sorted.',
    'Eliminate mean, mode and range. Pick median.',
  ],
  Q108: [
    'Find the middle of an ordered list.',
    'For n sorted values, median = value at position (n+1)/2.',
    'n = 5, so position = 3. The 3rd value of 2, 4, 6, 8, 10 is the median.',
  ],
  Q109: [
    'Recall what the range measures.',
    'Range = highest value - lowest value.',
    'Range tells you how spread out the data is. Decide True or False.',
  ],
  Q110: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Die has 6 outcomes; even ones are {2,4,6} = 3 favourable. P = 3/6. Simplify.',
  ],
  Q111: [
    'Find the most frequent value.',
    'Mode = the value appearing more times than any other.',
    '3 appears twice; all others appear once. Pick 3.',
  ],
  Q112: [
    'Think about how the mean is computed.',
    'Mean = sum / count — it need not equal any data value.',
    'E.g. mean of 1 and 4 is 2.5, which is not in the data. Decide True or False.',
  ],
  Q113: [
    'Use the probability formula for a coin.',
    'P(event) = favourable outcomes / total outcomes.',
    'Coin has 2 outcomes (H, T); 1 favourable (H). P = 1/2.',
  ],
  Q114: [
    'Recall the law of total probability.',
    'The probabilities of all possible outcomes always add up to 1.',
    'Something must happen, so the sum is the certainty value. Decide what it equals.',
  ],
  Q115: [
    'Recall bar graph conventions.',
    'In a bar graph, all bars have the same width; only heights vary.',
    'Equal width is a defining feature of bar graphs. Decide True or False.',
  ],
  Q116: [
    'List the outcomes for two coins.',
    'Two coins give 4 equally likely outcomes: HH, HT, TH, TT.',
    'Favourable (HH) = 1 out of 4. P = 1/4.',
  ],
  Q117: [
    'Use the range formula.',
    'Range = highest value - lowest value.',
    'Highest = 50, lowest = 10. Subtract.',
  ],
  Q118: [
    'Recall the purpose of a pie chart.',
    'A pie chart divides a circle into slices representing parts of a whole.',
    'Each slice is a fraction of the total. Decide True or False.',
  ],
  Q119: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 3 + 7 + 5 + 9 = 24, count = 4. Divide 24 by 4.',
  ],
  Q120: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Red = 3, total = 3 + 2 = 5. P = 3/5. Reduce if possible.',
  ],
  Q121: [
    'Recall the definition of a prime number.',
    'A prime has exactly two factors: 1 and itself.',
    'Eliminate 9 (=3*3), 15 (=3*5) and 21 (=3*7) — they are composite.',
  ],
  Q122: [
    'Convert a decimal to a fraction.',
    'Write the decimal as a fraction over 100, 1000, etc., then simplify.',
    '0.25 = 25/100. Divide top and bottom by 25.',
  ],
  Q123: [
    'Substitute then apply BODMAS.',
    'Replace a and b with their values; multiply before adding.',
    'a*b + 1 = 2*3 + 1. Multiply first, then add 1.',
  ],
  Q124: [
    'Count the terms in an expression.',
    'Terms are separated by + or - signs.',
    '2x and 3y are the two terms. Decide True or False.',
  ],
  Q125: [
    'Isolate x in a one-step equation.',
    'For x - a = b, add a to both sides.',
    'x = 10 + 4. Add.',
  ],
  Q126: [
    'Spot the difference-of-squares pattern.',
    'a^2 - b^2 = (a - b)(a + b).',
    '9 = 3^2, so a = x and b = 3. Write (x - 3)(x + 3).',
  ],
  Q127: [
    'Solve a two-step linear equation.',
    'Subtract the constant, then divide by the coefficient.',
    '2x = 11 - 3 = 8. Divide by 2.',
  ],
  Q128: [
    'Recall polygon names by side count.',
    '"Penta" means five.',
    'A 5-sided polygon is a pentagon. Eliminate quadrilateral, hexagon and octagon.',
  ],
  Q129: [
    'Recall the standard value of sin 30 deg.',
    'In a 30-60-90 triangle, the side opposite 30 deg is half the hypotenuse.',
    'sin 30 deg = (half-hypotenuse) / hypotenuse = 1/2. Decide True or False.',
  ],
  Q130: [
    'Evaluate cos at 90 degrees.',
    'cos theta = adjacent / hypotenuse.',
    'At 90 deg the adjacent side has zero length. Compute 0 / hypotenuse.',
  ],
  Q131: [
    'Recall the SOH-CAH-TOA definitions.',
    'tan theta = opposite / adjacent.',
    'Eliminate opposite/hypotenuse (sin) and adjacent/hypotenuse (cos). Pick opposite/adjacent.',
  ],
  Q132: [
    'Use the rectangle area formula.',
    'Area of a rectangle = length * breadth.',
    'Substitute l = 8, b = 4: A = 8 * 4. Multiply.',
  ],
  Q133: [
    'Recall the special name for the perimeter of a circle.',
    'Perimeter of a circle = circumference = 2*pi*r.',
    'Eliminate diameter, radius and arc — pick circumference.',
  ],
  Q134: [
    'Compare triangle and parallelogram areas.',
    'Triangle area = (1/2) * base * height; parallelogram area = base * height.',
    'On the same base and between the same parallels, the triangle has half the area. Decide True or False.',
  ],
  Q135: [
    'Use the equilateral perimeter formula.',
    'Perimeter of an equilateral triangle = 3 * side.',
    'Substitute side = 5: P = 3 * 5. Multiply.',
  ],

  // ───────────────────────────── Q200-Q379 (v3.25.0) ─────────────────────────────
  Q200: [
    'Count the natural numbers in the given range.',
    'Natural numbers are 1, 2, 3, ... — include both endpoints.',
    'Count: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10. The count is the number of items in this list.',
  ],
  Q201: [
    'Recall how 0 is classified.',
    '0 is neither positive nor negative — it is neutral.',
    'Positive integers start at 1; 0 sits at the boundary. Decide True or False.',
  ],
  Q202: [
    'Recall the definition of natural numbers.',
    'Natural numbers are 1, 2, 3, ... — they start at 1.',
    'Eliminate -2 (negative), 0 (whole only) and 1.5 (decimal). Pick the positive whole number.',
  ],
  Q203: [
    'Use the rule for adding a negative number.',
    'Adding a negative is the same as subtracting.',
    '7 + (-3) = 7 - 3. Subtract to finish.',
  ],
  Q204: [
    'Compare whole and natural number sets.',
    'Whole = {0, 1, 2, ...}; Natural = {1, 2, 3, ...}.',
    '0 is a whole number but not a natural number, so the statement is False.',
  ],
  Q205: [
    'Think about the integer number line.',
    'Integers extend forever in both directions.',
    'Negative integers keep going: ..., -3, -2, -1. There is no lower bound. Pick the matching option.',
  ],
  Q206: [
    'Recall the additive inverse property.',
    'A number plus its opposite (additive inverse) always equals 0.',
    '-5 and 5 are additive inverses. Their sum is 0.',
  ],
  Q207: [
    'Recall the definition of integers.',
    'Integers = {..., -3, -2, -1, 0, 1, 2, 3, ...} — whole numbers and their negatives.',
    'Eliminate 1.5 (decimal), sqrt2 (irrational) and pi (irrational). Pick -3.',
  ],
  Q208: [
    'Compare positive and negative on the number line.',
    'On a number line, positive numbers lie to the right of negatives.',
    '7 is to the right of -7, so 7 > -7. Decide True or False.',
  ],
  Q209: [
    'Use the sign rule for multiplication.',
    'Positive * negative = negative.',
    'Multiply 2 * 4 = 8, then apply the negative sign.',
  ],
  Q210: [
    'Recall which numbers are rational.',
    'Rational numbers can be written as p/q with q not zero.',
    '0.75 = 3/4 is rational; sqrt2, pi and sqrt5 cannot be p/q. Pick 0.75.',
  ],
  Q211: [
    'Use the sign rules for products.',
    'Negative * negative = positive; positive * positive = positive.',
    '(-3) * (-2) = 6 first. Then 6 * 2. Multiply.',
  ],
  Q212: [
    'Recall the sign rule for two negatives.',
    'Negative * negative = positive.',
    'Example: (-2) * (-3) = 6. Decide True or False.',
  ],
  Q213: [
    'Recall the additive inverse.',
    'The additive inverse of n is the number that adds to n to give 0.',
    '-8 + ? = 0. The missing number is +8.',
  ],
  Q214: [
    'Add fractions with unlike denominators.',
    'Make denominators equal (find a common denominator), then add numerators.',
    '2/3 = 4/6 (multiply top and bottom by 2). Then 4/6 + 1/6. Add numerators.',
  ],
  Q215: [
    'Convert the decimal to a fraction.',
    '0.25 = 25/100, then simplify.',
    'Divide numerator and denominator by 25: 25/100 = ?/4. Decide True or False.',
  ],
  Q216: [
    'Compare fractions by converting to decimals.',
    'Divide each numerator by its denominator to compare.',
    '2/3 ~ 0.67, 3/4 = 0.75, 1/2 = 0.5, 5/6 ~ 0.83. Pick the largest decimal.',
  ],
  Q217: [
    'List the factors of each number.',
    'HCF = highest factor common to both lists.',
    'Factors of 6: {1,2,3,6}; factors of 9: {1,3,9}. Largest common factor is the answer.',
  ],
  Q218: [
    'Simplify the second fraction.',
    'Reduce 3/6 by dividing top and bottom by 3.',
    '3/6 = 1/2, which matches the first fraction. Decide True or False.',
  ],
  Q219: [
    'Recall the reciprocal of a fraction.',
    'Reciprocal of a/b is b/a, keeping the sign.',
    'Flip -2/3 to get -3/2. Check: (-2/3) * (-3/2) should equal 1.',
  ],
  Q220: [
    'Convert the decimal to a fraction.',
    'Write 0.4 as 4/10, then simplify.',
    'Divide top and bottom by 2: 4/10 = ?/5. Reduce.',
  ],
  Q221: [
    'Recall the definition of a rational number.',
    'A rational number is any p/q with q not zero.',
    'A fraction p/q fits this definition. Decide True or False.',
  ],
  Q222: [
    'Use the terminating-decimal test.',
    'A fraction terminates only if the denominator (in lowest terms) has prime factors 2 and 5 only.',
    '7/20: 20 = 2^2 * 5 (only 2 and 5) — terminates. Others have 3 or 7. Pick 7/20.',
  ],
  Q223: [
    'Use prime factorisation for LCM.',
    'LCM = product of highest powers of all prime factors.',
    '9 = 3^2, 12 = 2^2 * 3. LCM = 2^2 * 3^2. Multiply.',
  ],
  Q224: [
    'Recall the irrationality of sqrt2.',
    'sqrt2 cannot be written as p/q.',
    'sqrt2 is a classic example of an irrational number. Decide True or False.',
  ],
  Q225: [
    'Use the sign rule for powers of -1.',
    '(-1)^even = 1 and (-1)^odd = -1.',
    '100 is even, so (-1)^100 equals the positive result. Pick the matching option.',
  ],
  Q226: [
    'Divide by a fraction.',
    'Dividing by a/b is the same as multiplying by b/a.',
    '3/4 / (2/3) = 3/4 * 3/2. Multiply numerators and denominators.',
  ],
  Q227: [
    'Recall the reciprocal of 0.',
    'Reciprocal of n is 1/n.',
    '1/0 is undefined (division by zero). Decide True or False.',
  ],
  Q228: [
    'Identify non-terminating non-recurring decimals.',
    'Irrational numbers have decimals that never end and never repeat.',
    '0.1010010001... (pattern-free) is irrational. 1/3, 0.25, 2/5 are rational. Pick the irrational one.',
  ],
  Q229: [
    'Use the exponent multiplication rule.',
    'a^m * a^n = a^(m+n) when bases match.',
    '2^3 * 2^2 = 2^(3+2) = 2^5. Compute 2^5.',
  ],
  Q230: [
    'Substitute the value of x.',
    'Replace every x with the given number.',
    'x + 3 with x = 2 becomes 2 + 3. Add.',
  ],
  Q231: [
    'Recall what a coefficient is.',
    'The coefficient is the number multiplying the variable.',
    'In 4x, the number 4 multiplies x. Decide True or False.',
  ],
  Q232: [
    'Recall the definition of a variable.',
    'A variable is a symbol that can represent different numbers.',
    'Eliminate 5 (constant), + and = (operators). Pick the letter.',
  ],
  Q233: [
    'Substitute the value of x.',
    'Replace x with the given number.',
    '2x becomes 2 * 5. Multiply.',
  ],
  Q234: [
    'Recall the definition of like terms.',
    'Like terms have the same variable.',
    '3x and 5x both contain x. Decide True or False.',
  ],
  Q235: [
    'Combine the same variable.',
    'x + x = (1 + 1)x.',
    'Adding one x to another x gives the coefficient 2 in front of x.',
  ],
  Q236: [
    'Substitute the values of a and b.',
    'Replace each letter with its given number.',
    'a + b becomes 2 + 3. Add.',
  ],
  Q237: [
    'Distinguish expression from equation.',
    'An expression has no equal sign; an equation does.',
    '3x + 2 has no = sign, but 3x + 2 = 8 does. Decide True or False.',
  ],
  Q238: [
    'Count terms separated by + or -.',
    'Each piece between + or - signs is a term.',
    '5x and 3y are the two terms. Count them.',
  ],
  Q239: [
    'Recall the additive identity.',
    'Adding 0 does not change a number: x + 0 = x.',
    'So x + 0 = 7 gives x = 7 directly.',
  ],
  Q240: [
    'Solve a one-step equation.',
    'For x - a = b, add a to both sides.',
    'x = 10 + 5. Add.',
  ],
  Q241: [
    'Isolate x in ax = b.',
    'Divide both sides by the coefficient a.',
    'x = 14 / 2. Divide.',
  ],
  Q242: [
    'Recall the definition of like terms.',
    'Like terms must have the same power of the variable.',
    '3x^2 has power 2, 3x has power 1. Decide True or False.',
  ],
  Q243: [
    'Subtract like terms by subtracting coefficients.',
    'ax - bx = (a - b)x when variables match.',
    'Coefficients 5 and 2: (5 - 2)x. Subtract.',
  ],
  Q244: [
    'Substitute and evaluate a power.',
    'x^2 = x * x.',
    'Substitute x = 4: 4^2 = 4 * 4. Multiply.',
  ],
  Q245: [
    'Solve x + 3 = 0.',
    'Subtract the constant from both sides.',
    'x = 0 - 3. The result is the negative of 3. Decide True or False.',
  ],
  Q246: [
    'Use the distributive law.',
    'a(b + c) = ab + ac.',
    '2(x + 3) = 2*x + 2*3. Multiply each piece.',
  ],
  Q247: [
    'Solve a one-step equation.',
    'For ax = b, divide both sides by a.',
    'x = 21 / 3. Divide.',
  ],
  Q248: [
    'Recall the expansion identity.',
    '(x + y)^2 = x^2 + 2xy + y^2.',
    'The middle term 2xy is missing from the given formula. Decide True or False.',
  ],
  Q249: [
    'Identify the coefficient of the asked variable.',
    'The coefficient is the number multiplying that specific variable.',
    'In 5x + 3y, the coefficient of y is the number in front of y.',
  ],
  Q250: [
    'Substitute then apply BODMAS.',
    'Replace x with 2; multiply before adding.',
    '3*2 + 4. Multiply first, then add 4.',
  ],
  Q251: [
    'Recall the multiplicative property of zero.',
    'Any number multiplied by 0 equals 0.',
    '0 * x = 0 for every x. Decide True or False.',
  ],
  Q252: [
    'Factorise a quadratic trinomial.',
    'Find two numbers that multiply to the constant and add to the middle coefficient.',
    'Need product 12, sum 7. The numbers are 3 and 4. Write (x + 3)(x + 4).',
  ],
  Q253: [
    'Solve a two-step linear equation.',
    'Subtract the constant, then divide by the coefficient.',
    '2x = 17 - 5 = 12. Divide by 2.',
  ],
  Q254: [
    'Recall the degree of an expression.',
    'Degree = sum of exponents of variables in a term.',
    'In 5x^2y, exponents are 2 and 1, summing to 3. The degree is 3, not 2. Decide True or False.',
  ],
  Q255: [
    'Spot the difference-of-squares pattern.',
    '(a + b)(a - b) = a^2 - b^2.',
    'a = x, b = 2. Apply the identity to get x^2 - 2^2. Square the 2.',
  ],
  Q256: [
    'Undo the multiplication first.',
    'For a(x + b) = c, divide both sides by a.',
    'Divide by 3: x - 2 = 4. Then add 2 to both sides.',
  ],
  Q257: [
    'Verify by substitution.',
    'Plug the proposed value into the equation and check both sides.',
    'Substitute x = 2: 2^2 - 4 = 4 - 4. Decide if it equals 0. True or False.',
  ],
  Q258: [
    'Use the power-of-a-power rule.',
    '(x^a)^b = x^(a*b).',
    'Multiply the exponents: 2 * 3 = 6. Write x^6.',
  ],
  Q259: [
    'Solve a one-step equation with division.',
    'For x/a = b, multiply both sides by a.',
    'x = 9 * 2. Multiply.',
  ],
  Q260: [
    'Recall the definition of a triangle.',
    '"Tri" means three.',
    'A triangle has exactly 3 sides. Eliminate 4, 5 and 6.',
  ],
  Q261: [
    'Recall what a right angle measures.',
    'A right angle is formed by two perpendicular lines.',
    'A right angle is exactly 90 degrees. Decide True or False.',
  ],
  Q262: [
    'Recall polygon names by side count.',
    '"Penta" means five.',
    'Eliminate quadrilateral, hexagon and octagon. Pick pentagon.',
  ],
  Q263: [
    'Recall the measure of a straight angle.',
    'A straight angle looks like a straight line.',
    'It is half of a full turn (360 deg). Divide 360 by 2.',
  ],
  Q264: [
    'Recall the definition of a square.',
    'A square has 4 equal sides and 4 right angles.',
    'All four sides are equal in length. Decide True or False.',
  ],
  Q265: [
    'Think about a full turn around a point.',
    'Angles around a single point sum to a complete revolution.',
    'A complete revolution is 360 degrees.',
  ],
  Q266: [
    'Visualise the corners of a cube.',
    'A cube has 4 vertices on the top face and 4 on the bottom.',
    'Add the top 4 and bottom 4 corners. Eliminate 6, 12 and 4.',
  ],
  Q267: [
    'Recall the definition of a circle.',
    'A circle is a smooth curved shape with no straight edges.',
    'No straight edges means no corners. Decide True or False.',
  ],
  Q268: [
    'Recall angle-type names.',
    'An acute angle is less than 90 deg; an obtuse angle is between 90 and 180 deg.',
    'Eliminate right (90), obtuse (>90) and reflex (>180). Pick acute.',
  ],
  Q269: [
    'Recall polygon names by side count.',
    '"Hexa" means six.',
    'A hexagon has 6 sides. Eliminate 5, 7 and 8.',
  ],
  Q270: [
    'Recall the names for special angle sums.',
    'Complementary angles sum to 90 deg; supplementary sum to 180 deg.',
    'Eliminate supplementary, adjacent and vertical. Pick complementary.',
  ],
  Q271: [
    'Use the angle-sum property of a triangle.',
    'Sum of all three angles = 180 deg.',
    'Third angle = 180 - (60 + 70) = 180 - 130. Subtract.',
  ],
  Q272: [
    'Recall parallelogram angle properties.',
    'In a parallelogram, both pairs of opposite angles are equal.',
    'Opposite angles being equal is a defining property. Decide True or False.',
  ],
  Q273: [
    'Recall the special side of a right triangle.',
    'The hypotenuse is opposite the 90 deg angle and is the longest side.',
    'Eliminate leg, base and adjacent. Pick hypotenuse.',
  ],
  Q274: [
    'Use the complementary-angle rule.',
    'Complement of angle A = 90 - A.',
    'Complement = 90 - 35. Subtract.',
  ],
  Q275: [
    'Recall the property of a circle.',
    'Every radius of a circle goes from the centre to the edge.',
    'All radii of one circle share the same length. Decide True or False.',
  ],
  Q276: [
    'Recall triangle types by side length.',
    'Equilateral = 3 equal sides; isosceles = 2 equal; scalene = none equal.',
    'Eliminate isosceles, scalene and right. Pick equilateral.',
  ],
  Q277: [
    'Use the supplementary-angle rule.',
    'Supplement of angle A = 180 - A.',
    'Supplement = 180 - 110. Subtract.',
  ],
  Q278: [
    'Recall the definition of a rectangle.',
    'A rectangle has opposite sides equal and 4 right angles.',
    'Every rectangle has four 90-degree angles. Decide True or False.',
  ],
  Q279: [
    'Use the angle-sum of a quadrilateral.',
    'A quadrilateral splits into 2 triangles, so the sum is 2 * 180 deg.',
    'Multiply 2 * 180. Eliminate 180, 270 and 540. Pick the result.',
  ],
  Q280: [
    'Use the property of an equilateral triangle.',
    'All 3 angles are equal and sum to 180 deg.',
    'Each angle = 180 / 3. Divide.',
  ],
  Q281: [
    'Recall the definition of a rhombus.',
    'A rhombus has 4 equal sides (like a tilted square).',
    'Four equal sides is the defining property. Decide True or False.',
  ],
  Q282: [
    'Use the Pythagorean theorem.',
    'hypotenuse^2 = leg1^2 + leg2^2.',
    '3^2 + 4^2 = 9 + 16 = 25. Take the square root of 25.',
  ],
  Q283: [
    'Use the angle-sum property of a triangle.',
    'Sum of all three angles = 180 deg.',
    'x + 2x + 3x = 6x = 180. Divide by 6.',
  ],
  Q284: [
    'Recall the diagonal property of a rhombus.',
    'A rhombus has diagonals that bisect at 90 deg but are NOT equal.',
    'Only a square has equal diagonals in the rhombus family. Decide True or False.',
  ],
  Q285: [
    'Recall the names for special angle sums.',
    'Supplementary angles sum to 180 deg; complementary sum to 90 deg.',
    'Eliminate complementary, adjacent and right. Pick supplementary.',
  ],
  Q286: [
    'Use the perimeter formula for an equilateral triangle.',
    'Perimeter = 3 * side.',
    'Substitute side = 7: P = 3 * 7. Multiply.',
  ],
  Q287: [
    'Recall the diagonal property of a square.',
    'A square has equal diagonals that bisect each other at 90 deg.',
    'Each diagonal = side * sqrt2, and they are equal. Decide True or False.',
  ],
  Q288: [
    'Recall the symmetry of an equilateral triangle.',
    'Each line of symmetry runs from a vertex to the midpoint of the opposite side.',
    'Three vertices give three such lines. Count them.',
  ],
  Q289: [
    'Use the angle sum of a right triangle.',
    'In a right triangle, the two acute angles sum to 90 deg.',
    'Other acute angle = 90 - 40. Subtract.',
  ],
  Q290: [
    'Recall the SOH-CAH-TOA definitions.',
    'sin = opposite/hypotenuse; cos = adjacent/hypotenuse; tan = opposite/adjacent.',
    'Eliminate cos, tan and cot. Pick sin.',
  ],
  Q291: [
    'Recall the standard value at 45 degrees.',
    'In a 45-45-90 triangle, opposite and adjacent sides are equal.',
    'tan 45 deg = opposite/adjacent = equal/equal. Decide what value this gives. True or False.',
  ],
  Q292: [
    'Recall the special side of a right triangle.',
    'The hypotenuse sits opposite the 90 deg angle and is the longest side.',
    'Eliminate leg, base and adjacent. Pick hypotenuse.',
  ],
  Q293: [
    'Evaluate cos at 0 degrees.',
    'cos theta = adjacent / hypotenuse.',
    'At 0 deg the adjacent side equals the hypotenuse. Compute the ratio.',
  ],
  Q294: [
    'Evaluate tan at 0 degrees.',
    'tan theta = opposite / adjacent.',
    'At 0 deg the opposite side has zero length. Compute 0 / adjacent.',
  ],
  Q295: [
    'Recall which ratios avoid the hypotenuse.',
    'tan = opposite/adjacent uses only the two legs.',
    'Eliminate sin, cos and sec — all use the hypotenuse. Pick tan.',
  ],
  Q296: [
    'Use the standard value of sin 30 deg.',
    'sin 30 deg = 1/2.',
    'Substitute: 2 * (1/2). Multiply.',
  ],
  Q297: [
    'Recall the definition of hypotenuse.',
    'The hypotenuse is opposite the right angle.',
    'It is the side across from the 90 deg angle. Decide True or False.',
  ],
  Q298: [
    'Recall the SOH-CAH-TOA definitions.',
    'cos = adjacent / hypotenuse.',
    'Eliminate opposite/hypotenuse (sin) and opposite/adjacent (tan). Pick adjacent/hypotenuse.',
  ],
  Q299: [
    'Substitute the standard value of tan 45 deg.',
    'tan 45 deg = 1.',
    'Compute 1 * 1. Multiply.',
  ],
  Q300: [
    'Recall the standard value of sin 60 deg.',
    'In a 30-60-90 triangle, the side opposite 60 deg is sqrt3/2 times the hypotenuse.',
    'sin 60 deg = sqrt3/2. Eliminate 1/2, 1 and sqrt2/2. Pick sqrt3/2.',
  ],
  Q301: [
    'Square the standard value of sin 30 deg.',
    'sin 30 deg = 1/2, so sin^2 30 deg = (1/2)^2.',
    '(1/2)^2 = (1/2) * (1/2). Multiply the fractions.',
  ],
  Q302: [
    'Recall the standard value at 45 degrees.',
    'cos 45 deg = 1/sqrt2 = sqrt2/2 after rationalising.',
    '1/sqrt2 = sqrt2/2. Decide True or False.',
  ],
  Q303: [
    'Use the standard value of tan 30 deg.',
    'tan theta = sin theta / cos theta.',
    'sin 30 deg = 1/2, cos 30 deg = sqrt3/2. Divide: (1/2) / (sqrt3/2). Simplify.',
  ],
  Q304: [
    'Solve sin theta = 0 on the given range.',
    'sin theta = 0 when the opposite side is 0.',
    'On 0 deg to 90 deg, this happens only at the lower endpoint. Identify it.',
  ],
  Q305: [
    'Recall the reciprocal trig functions.',
    'cosec = 1/sin; sec = 1/cos; cot = 1/tan.',
    'cosec uses sin, not cos. Decide True or False.',
  ],
  Q306: [
    'Recall the reciprocal trig functions.',
    'sec = 1/cos; cosec = 1/sin; cot = 1/tan.',
    'Eliminate cosec (1/sin), cot (1/tan) and sin. Pick sec.',
  ],
  Q307: [
    'Use the standard value of tan 60 deg.',
    'tan theta = sin theta / cos theta.',
    'sin 60 deg = sqrt3/2, cos 60 deg = 1/2. Divide: (sqrt3/2) / (1/2). Simplify.',
  ],
  Q308: [
    'Recall the quotient identity.',
    'tan theta = sin theta / cos theta.',
    'Dividing opposite/hypotenuse by adjacent/hypotenuse gives opposite/adjacent = sin/cos. Decide True or False.',
  ],
  Q309: [
    'Recall the reciprocal trig functions.',
    'cot = 1/tan = cos/sin.',
    'Eliminate sin/cos (tan), 1/sin (cosec) and 1/cos (sec). Pick cos/sin.',
  ],
  Q310: [
    'Solve cos theta = 1 on the given range.',
    'cos theta = 1 when adjacent equals hypotenuse.',
    'On 0 deg to 90 deg, this happens only at the lower endpoint. Identify it.',
  ],
  Q311: [
    'Recall the ASTC rule for quadrants.',
    'In the first quadrant (0 deg to 90 deg), all trig ratios are positive.',
    'All ratios positive means sin theta > 0 throughout. Decide True or False.',
  ],
  Q312: [
    'Use the sine addition identity.',
    'sin A cos B + cos A sin B = sin(A + B).',
    'A = 60 deg, B = 30 deg. Compute sin(60 + 30) = sin(90 deg). Decide the value.',
  ],
  Q313: [
    'Use the Pythagorean identity.',
    'sin^2 theta + cos^2 theta = 1 for every theta.',
    'Substitute theta = 45 deg — the identity still holds. The sum equals 1.',
  ],
  Q314: [
    'Recall the co-function identity.',
    'cos(90 deg - theta) = sin theta.',
    'The two non-right angles of a right triangle are complementary. Decide True or False.',
  ],
  Q315: [
    'Solve cos theta = 0 on the given range.',
    'cos theta = 0 when the adjacent side has zero length.',
    'On 0 deg to 90 deg, this happens at the upper endpoint. Identify it.',
  ],
  Q316: [
    'Use the standard values at 30 and 60 degrees.',
    'tan 30 deg = 1/sqrt3 and tan 60 deg = sqrt3.',
    'Multiply: (1/sqrt3) * sqrt3. The sqrt3s cancel.',
  ],
  Q317: [
    'Recall the maximum value of sine.',
    'sin theta = opposite/hypotenuse, and opposite <= hypotenuse.',
    'The maximum ratio is 1, occurring at 90 deg. Decide True or False.',
  ],
  Q318: [
    'Interpret the sine ratio.',
    'sin theta = opposite/hypotenuse.',
    'sin theta = 3/5 means opposite = 3, hypotenuse = 5. Pick the matching ratio.',
  ],
  Q319: [
    'Solve tan theta = 1 for an acute angle.',
    'tan 45 deg = 1 (opposite = adjacent).',
    'In a 45-45-90 triangle, opposite equals adjacent. Identify the angle.',
  ],
  Q320: [
    'Use the area formula for a square.',
    'Area of a square = side * side.',
    'Substitute side = 5: A = 5 * 5. Multiply.',
  ],
  Q321: [
    'Use the perimeter formula for a square.',
    'A square has 4 equal sides, so perimeter = 4 * side.',
    'Sum of the four equal sides = side + side + side + side. Decide True or False.',
  ],
  Q322: [
    'Use the perimeter formula for a rectangle.',
    'Perimeter = length + breadth + length + breadth.',
    'Factor: P = 2 * (length + breadth). Pick that option.',
  ],
  Q323: [
    'Use the perimeter formula for a square.',
    'Perimeter of a square = 4 * side.',
    'Substitute side = 3: P = 4 * 3. Multiply.',
  ],
  Q324: [
    'Recall the cube volume formula.',
    'A cube has equal length, breadth and height, so V = side^3.',
    'V = side * side * side = side^3. Decide True or False.',
  ],
  Q325: [
    'Recall the name for 3D space inside a solid.',
    'Volume measures 3D space; area is 2D; perimeter is 1D.',
    'Eliminate area, perimeter and surface. Pick volume.',
  ],
  Q326: [
    'Use the rectangle area formula.',
    'Area of a rectangle = length * breadth.',
    'Substitute l = 4, b = 3: A = 4 * 3. Multiply.',
  ],
  Q327: [
    'Recall the definition of perimeter.',
    'Perimeter is the total length around the outside of a shape.',
    'It is the sum of all the sides. Decide True or False.',
  ],
  Q328: [
    'Recall the metre-to-cm conversion.',
    '1 metre = 100 centimetres.',
    'Eliminate 10, 1000 and 10000. Pick 100.',
  ],
  Q329: [
    'Use the area formula for a square.',
    'Area of a square = side * side.',
    'Substitute side = 2: A = 2 * 2. Multiply.',
  ],
  Q330: [
    'Use the triangle area formula.',
    'Area of a triangle = (1/2) * base * height.',
    'Substitute base = 6, height = 4: A = (1/2) * 6 * 4. Multiply then halve.',
  ],
  Q331: [
    'Use the perimeter formula for a rectangle.',
    'Perimeter = 2 * (length + breadth).',
    'Substitute l = 7, b = 2: P = 2 * (7 + 2). Add, then double.',
  ],
  Q332: [
    'Visualise the faces of a cube.',
    'A cube has top, bottom, front, back, left and right faces.',
    'All six faces are squares. Count them. Decide True or False.',
  ],
  Q333: [
    'Use the cuboid volume formula.',
    'Volume of a cuboid = l * b * h.',
    'Substitute l = 2, b = 3, h = 4: V = 2 * 3 * 4. Multiply.',
  ],
  Q334: [
    'Use the circle area formula.',
    'Area of a circle = pi * r^2.',
    'Substitute r = 1, pi = 3.14: A = 3.14 * 1^2. Multiply.',
  ],
  Q335: [
    'Use the cube volume formula.',
    'Volume of a cube = side^3.',
    'Substitute side = 1: V = 1^3 = 1 * 1 * 1. Multiply. Decide True or False.',
  ],
  Q336: [
    'Use the surface area formula for a cube.',
    'A cube has 6 equal square faces, each of area a^2.',
    'Total surface area = 6 * a^2. Pick that option.',
  ],
  Q337: [
    'Use the cube volume formula.',
    'Volume of a cube = side^3.',
    'Substitute side = 2: V = 2^3 = 2 * 2 * 2. Multiply.',
  ],
  Q338: [
    'Recall the units of area.',
    'Area is a 2D quantity measured in cm^2, m^2, etc.',
    'Square units measure area. Decide True or False.',
  ],
  Q339: [
    'Use the perimeter formula for a square.',
    'Perimeter of a square = 4 * side.',
    'Substitute side = 10: P = 4 * 10. Multiply.',
  ],
  Q340: [
    'Use the cuboid volume formula.',
    'Volume of a cuboid = l * b * h.',
    'Substitute l = 3, b = 2, h = 1: V = 3 * 2 * 1. Multiply.',
  ],
  Q341: [
    'Convert square metres to square cm.',
    '1 m = 100 cm, so 1 m^2 = 100 * 100 cm^2.',
    'Multiply 100 * 100. Decide True or False.',
  ],
  Q342: [
    'Use the cylinder volume formula.',
    'Volume of a cylinder = pi * r^2 * h.',
    'Substitute r = 7, h = 2, pi = 22/7: V = (22/7) * 7^2 * 2. Multiply step by step.',
  ],
  Q343: [
    'Use the surface area formula for a cube.',
    'Surface area of a cube = 6 * side^2.',
    'Substitute side = 3: SA = 6 * 3^2 = 6 * 9. Multiply.',
  ],
  Q344: [
    'Recall the curved surface area of a cone.',
    'Unrolling the cone gives a sector with radius l and arc 2*pi*r, area = pi*r*l.',
    'The formula pi*r*l uses the slant height l. Decide True or False.',
  ],
  Q345: [
    'Use the sphere volume formula.',
    'Volume of a sphere = (4/3) * pi * r^3.',
    'Eliminate 4*pi*r^2 (surface area), pi*r^2 (circle area) and (4/3)*pi*r^2. Pick (4/3)pi*r^3.',
  ],
  Q346: [
    'Use the circle area formula.',
    'Area of a circle = pi * r^2.',
    'Substitute r = 7, pi = 22/7: A = (22/7) * 7^2. Multiply and simplify.',
  ],
  Q347: [
    'Add the curved and flat parts of a hemisphere.',
    'Curved part = 2*pi*r^2; flat circular base = pi*r^2.',
    'Total = 2*pi*r^2 + pi*r^2 = 3*pi*r^2. Decide True or False.',
  ],
  Q348: [
    'Use the cone volume formula.',
    'Volume of a cone = (1/3) * pi * r^2 * h.',
    'Substitute r = 7, h = 3, pi = 22/7: V = (1/3) * (22/7) * 49 * 3. Multiply and simplify.',
  ],
  Q349: [
    'Use the perimeter formula for a rectangle.',
    'Perimeter = 2 * (length + breadth).',
    'Substitute l = 10, b = 4: P = 2 * (10 + 4). Add, then double.',
  ],
  Q350: [
    'Recall the formula for the average.',
    'Mean = (sum of all values) / (number of values).',
    'Eliminate median, mode and range. Pick mean.',
  ],
  Q351: [
    'Recall the probability bounds.',
    'Probability 0 = impossible; probability 1 = certain.',
    'All probabilities fall in the closed interval [0, 1]. Decide True or False.',
  ],
  Q352: [
    'List the outcomes of a coin toss.',
    'A coin has 2 sides: Heads and Tails.',
    'Count the two outcomes H and T. The total is 2.',
  ],
  Q353: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 4 + 6 = 10, count = 2. Divide 10 by 2.',
  ],
  Q354: [
    'Recall what a bar graph uses.',
    'A bar graph uses rectangular bars of equal width to show values.',
    'Heights of the bars represent the values. Decide True or False.',
  ],
  Q355: [
    'List the faces of a die.',
    'A standard die has faces 1, 2, 3, 4, 5, 6.',
    'Count the six faces. The total is 6.',
  ],
  Q356: [
    'Use the range formula.',
    'Range = highest value - lowest value.',
    'Highest = 9, lowest = 4. Subtract.',
  ],
  Q357: [
    'Identify the possible die outcomes.',
    'A standard die has faces 1 through 6 only.',
    '7 is not on the die, so it is impossible. Decide the probability. True or False.',
  ],
  Q358: [
    'Recall the probability bounds.',
    'Probability 0 = impossible; probability 1 = certain.',
    'Eliminate -1 to 1, 0 to 100 and 1 to 10. Pick [0, 1].',
  ],
  Q359: [
    'Find the middle value of an ordered list.',
    'For n sorted values, median = value at position (n+1)/2.',
    'n = 3, so position = 2. The 2nd value of 3, 5, 7 is the median.',
  ],
  Q360: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 10 + 20 + 30 = 60, count = 3. Divide 60 by 3.',
  ],
  Q361: [
    'Find the most frequent value.',
    'Mode = the value appearing more times than any other.',
    '4 appears twice; all others appear once. Pick 4.',
  ],
  Q362: [
    'Find the median of an even-sized list.',
    'For even n, median = average of the two middle values.',
    'Two middle values are 2 and 3. Compute (2 + 3) / 2. Decide True or False.',
  ],
  Q363: [
    'List the outcomes of two coins.',
    'Two coins give the ordered outcomes HH, HT, TH, TT.',
    'Count the four outcomes. The total is 4.',
  ],
  Q364: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 5 + 10 + 15 + 20 = 50, count = 4. Divide 50 by 4.',
  ],
  Q365: [
    'Use the range formula.',
    'Range = highest value - lowest value.',
    'Highest = 15, lowest = 3. Subtract to verify 12. Decide True or False.',
  ],
  Q366: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Die has 6 outcomes; only one is a 3. P = 1/6. Pick the matching option.',
  ],
  Q367: [
    'Find the median of an even-sized list.',
    'For even n, median = average of the two middle values.',
    'Two middle values are 6 and 8. Compute (6 + 8) / 2.',
  ],
  Q368: [
    'Find the most frequent value.',
    'Mode = the value that appears more than any other.',
    'Each value (1, 2, 3, 4, 5) appears exactly once. There is no mode. Decide True or False.',
  ],
  Q369: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Die has 6 outcomes; numbers > 4 are {5, 6} = 2 favourable. P = 2/6. Simplify.',
  ],
  Q370: [
    'Use the mean formula.',
    'Mean = (sum of values) / (number of values).',
    'Sum = 1 + 3 + 5 + 7 = 16, count = 4. Divide 16 by 4.',
  ],
  Q371: [
    'Recall the complement rule.',
    'P(not A) = 1 - P(A).',
    'An event either happens or does not, so probabilities sum to 1. Decide True or False.',
  ],
  Q372: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Red = 4, total = 4 + 6 = 10. P = 4/10. Simplify to lowest terms.',
  ],
  Q373: [
    'Find the median of an even-sized list.',
    'For even n, median = average of the two middle values.',
    'Two middle values (3rd and 4th of 2,5,7,9,11,15) are 7 and 9. Compute (7 + 9) / 2.',
  ],
  Q374: [
    'Compute both mean and median.',
    'Mean = sum/count; median = middle value of sorted data.',
    'Mean = (2+4+6)/3 = 4; median = 4. Compare. Decide True or False.',
  ],
  Q375: [
    'Count outcomes for two dice.',
    'Each die has 6 faces; the two dice are independent.',
    'Multiply 6 * 6 to get the total. Eliminate 6, 12 and 21. Pick 36.',
  ],
  Q376: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Aces = 4, total cards = 52. P = 4/52. Simplify to lowest terms.',
  ],
  Q377: [
    'Use the complement rule.',
    'P(not A) = 1 - P(A).',
    'P(not A) = 1 - 0.3. Subtract. Decide True or False.',
  ],
  Q378: [
    'Use the probability formula.',
    'P(event) = favourable outcomes / total outcomes.',
    'Green = 4, total = 3 + 4 + 5 = 12. P = 4/12. Simplify to lowest terms.',
  ],
  Q379: [
    'Identify the first 5 natural numbers.',
    'Natural numbers start at 1.',
    'The first five are 1, 2, 3, 4, 5. Sum = 15, count = 5. Divide 15 by 5.',
  ],
}
