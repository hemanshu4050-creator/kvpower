'use client'

import { useEffect } from 'react'
import { useAppStore } from '@/lib/store'
import { useDataStore } from '@/lib/data-store'
import { applyAccentTheme } from '@/lib/accent-theme'
import { LoginScreen } from '@/components/portal/login-screen'
import { AppShell } from '@/components/portal/app-shell'

export default function Home() {
  const user = useAppStore((s) => s.user)
  // v3.36.0 — apply the portal-wide accent theme on the login screen too (so
  // the chosen primary color shows before the user signs in). The AppShell
  // also re-applies it on mount; this covers the pre-login surface.
  const themeAccent = useDataStore((s) => s.settings.themeAccent)
  useEffect(() => {
    applyAccentTheme(themeAccent)
  }, [themeAccent])

  if (!user) return <LoginScreen />
  return <AppShell />
}
