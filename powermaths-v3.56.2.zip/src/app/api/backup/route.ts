import { NextRequest, NextResponse } from 'next/server'
import { execSync } from 'child_process'
import {
  writeFileSync,
  mkdirSync,
  rmSync,
  existsSync,
  readFileSync,
} from 'fs'
import { join } from 'path'
import { tmpdir } from 'os'

export const runtime = 'nodejs'
// A full-project zip can take a little while on slow disks; allow up to 5 min.
export const maxDuration = 300

// v3.51.0 — Complete full-project backup endpoint.
//
// Receives the entire portal database (the current Zustand-persisted store
// state) as JSON in the request body, then produces a single downloadable ZIP
// containing:
//
//   1. database-export.json  — the full database snapshot (students,
//      chapters, questions, exams, results, certificates, announcements,
//      marketing campaigns, activity, settings, etc.).
//   2. RESTORE-GUIDE.txt     — step-by-step instructions for restoring the
//      backup on another server.
//   3. Every file & folder in the project root — source code (src/), public
//      assets & uploaded study materials (public/), prisma schema, db client,
//      scripts, mini-services, config files (.env, package.json, tsconfig,
//      next.config, tailwind, postcss, eslint, Caddyfile, deploy.sh, etc.)
//      and all other application files.
//
// Build artifacts that are trivially regenerated on the target server are
// excluded to keep the archive lean & portable:
//   node_modules, .next, .git, upload, download, skills, tool-results,
//   agent-ctx, dev.log, .zscripts (dev-server pid bookkeeping).
//
// The result is a self-contained archive that, after `bun install` + restoring
// the database, fully reproduces this application on any compatible server.

const EXCLUDED_PATTERNS = [
  'node_modules/*',
  'node_modules',
  '.next/*',
  '.next',
  '.git/*',
  '.git',
  'upload/*',
  'upload',
  'download/*',
  'download',
  'skills/*',
  'skills',
  'tool-results/*',
  'tool-results',
  'agent-ctx/*',
  'agent-ctx',
  'dev.log',
  '.zscripts/*',
  '.zscripts',
]

const RESTORE_GUIDE = `POWER MATHS — FULL BACKUP RESTORE GUIDE (v3.51.0)
=====================================================

This archive is a complete snapshot of the Power Maths portal and contains
everything required to fully restore the application on another server:

  • database-export.json   — the entire portal database (all students,
    chapters, questions, exams, results, certificates, announcements,
    marketing campaigns, activity logs, email templates, settings, …)
  • src/                    — application source code (Next.js 16 + TypeScript)
  • public/                 — branding assets, study materials, PDFs, logos
  • prisma/                 — Prisma schema
  • db/                     — Prisma client helper
  • scripts/                — utility scripts
  • mini-services/          — sidecar services (e.g. websocket chat)
  • package.json, bun.lock  — dependency manifest
  • tsconfig.json, next.config.ts, tailwind.config.ts, postcss.config.mjs,
    eslint.config.mjs, components.json, .env, Caddyfile, deploy.sh, …


STEP 1 — Install dependencies
-----------------------------
  cd /path/to/project
  bun install


STEP 2 — Start the app
----------------------
  Development:  bun run dev      (http://localhost:3000)
  Production:   bun run build && bun run start


STEP 3 — Restore the database
-----------------------------
The portal stores its data in the browser's localStorage (key: "pm-data-store").
To restore the database from this backup:

  Option A (from the admin UI — recommended):
    1. Log in as admin → Settings → Backup tab.
    2. Click "Restore Database" and select the database-export.json file
       included in this archive.
    3. Confirm. The portal reloads with the restored data.

  Option B (manual, via browser console):
    1. Open the running portal in your browser and log in once.
    2. Open DevTools → Console and run:

       const fs = await (await fetch('database-export.json')).text();
       const data = JSON.parse(fs);
       const snapshot = data.state ? data.state : data;
       localStorage.setItem('pm-data-store', JSON.stringify(
         { state: snapshot, version: 39 }
       ));
       location.reload();

    (If you are restoring an older backup, the portal's built-in migrator
     will upgrade the data shape automatically on the next load.)


STEP 4 — Verify
---------------
  • Footer should display the version matching this backup.
  • Students, chapters, exams, certificates, marketing campaigns, etc.
    should all be present.
  • Uploaded study materials & banners (stored in public/ and as base64 in
    the database) render correctly.

That's it — the portal is now fully restored.
`

export async function POST(req: NextRequest) {
  const started = Date.now()
  try {
    // ── 1. Read the database snapshot from the request body ──
    const rawBody = await req.text()
    if (!rawBody || rawBody.length < 2) {
      return NextResponse.json(
        { error: 'Empty database payload — nothing to back up.' },
        { status: 400 },
      )
    }

    // Validate it is JSON before we write it to disk.
    try {
      JSON.parse(rawBody)
    } catch {
      return NextResponse.json(
        { error: 'Database payload is not valid JSON.' },
        { status: 400 },
      )
    }

    const projectRoot = process.cwd()
    const tmp = tmpdir()
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    const workDir = join(tmp, `pm-backup-${stamp}`)
    mkdirSync(workDir, { recursive: true })

    // ── 2. Write the database export + restore guide into the work dir ──
    const dbFile = join(workDir, 'database-export.json')
    const guideFile = join(workDir, 'RESTORE-GUIDE.txt')
    writeFileSync(dbFile, rawBody, 'utf8')
    writeFileSync(guideFile, RESTORE_GUIDE, 'utf8')

    // ── 3. Build the zip ──
    const zipPath = join(workDir, `powermaths-backup.zip`)
    if (existsSync(zipPath)) rmSync(zipPath, { force: true })

    // 3a. Archive the entire project root (with exclusions).
    const excludeArgs = EXCLUDED_PATTERNS.map(
      (p) => `-x "${p}"`,
    ).join(' ')

    execSync(
      `zip -r -q "${zipPath}" . ${excludeArgs} -x "powermaths-backup-*.zip"`,
      {
        cwd: projectRoot,
        maxBuffer: 256 * 1024 * 1024,
        stdio: ['ignore', 'ignore', 'ignore'],
      },
    )

    // 3b. Append the database export + restore guide (stored at zip root).
    execSync(`zip -j -q "${zipPath}" "${dbFile}" "${guideFile}"`, {
      maxBuffer: 256 * 1024 * 1024,
      stdio: ['ignore', 'ignore', 'ignore'],
    })

    // ── 4. Stream the archive back to the client ──
    const zipBuffer = readFileSync(zipPath)
    const zipSize = zipBuffer.length

    // Cleanup the temp work dir (zip lives inside it).
    rmSync(workDir, { recursive: true, force: true })

    const filename = `powermaths-full-backup-${new Date()
      .toISOString()
      .slice(0, 19)
      .replace(/[:T]/g, '-')}.zip`

    const elapsed = ((Date.now() - started) / 1000).toFixed(1)

    return new NextResponse(zipBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': zipSize.toString(),
        'X-Backup-Size': zipSize.toString(),
        'X-Backup-Elapsed': elapsed,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
      },
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return NextResponse.json(
      {
        error: 'Backup generation failed.',
        detail: message,
      },
      { status: 500 },
    )
  }
}

// Simple health-check so admins can verify the endpoint exists.
export async function GET() {
  return NextResponse.json({
    ok: true,
    endpoint: '/api/backup',
    method: 'POST',
    description:
      'Generates a complete full-project ZIP backup (database + all files).',
  })
}
