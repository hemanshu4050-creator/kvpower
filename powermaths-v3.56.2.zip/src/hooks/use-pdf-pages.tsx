'use client'

/**
 * usePdfPages — renders a base64 data-URL PDF into a list of image pages
 * suitable for feeding into the SecurePdfViewer (DRM-protected viewer).
 *
 * How it works:
 *  1. Lazy-dynamically imports `pdfjs-dist` inside `useEffect` so the heavy
 *     library never ships with the initial bundle / never runs during SSR.
 *  2. Points `GlobalWorkerOptions.workerSrc` at the locally-bundled worker
 *     at `/pdf.worker.min.mjs` (no CDN / runtime internet dependency).
 *  3. Converts the dataURL to a Uint8Array, calls `getDocument({ data })`,
 *     then for each page calls `page.render({ canvas, viewport })` at a
 *     scale of ~1.5 for crisp resolution, converts the canvas to a PNG
 *     dataURL, and wraps it in `<img src={dataUrl} className="mx-auto
 *     max-w-full h-auto" />` so the DRM viewer can paginate it.
 *  4. Handles errors gracefully (corrupt PDF, worker load failure, etc.)
 *     and surfaces them via the `error` field.
 *  5. Memoizes on `fileDataUrl` so re-renders don't re-render the PDF.
 */

import * as React from 'react'
import { Loader2 } from 'lucide-react'
// NOTE: pdfjs-dist is imported DYNAMICALLY inside the effect (not statically)
// because its `canvas.js` module accesses `DOMMatrix` at eval time, which
// does not exist during Next.js SSR. The effect only runs client-side.
// We import the explicit `build/pdf.mjs` subpath (not the bare package
// specifier) because Turbopack leaves bare-specifier dynamic imports for
// the browser to resolve, which fails. The explicit file path is bundled
// into a client chunk correctly.

// Module-level guard so we configure the pdf.js worker only once per
// session. (We can't attach this flag to the pdfjs module object itself
// because ESM module namespaces are not extensible.)
let workerConfigured = false

export interface PdfPage {
  content: React.ReactNode
}

export interface UsePdfPagesResult {
  pages: PdfPage[]
  loading: boolean
  error: string | null
}

/**
 * Convert a `data:application/pdf;base64,XXXX` (or any data: URL) into a
 * Uint8Array pdf.js can consume. Strips the data: prefix and base64-decodes.
 */
function dataUrlToUint8Array(dataUrl: string): Uint8Array {
  const commaIdx = dataUrl.indexOf(',')
  const base64 = commaIdx >= 0 ? dataUrl.slice(commaIdx + 1) : dataUrl
  // Use atob in the browser; Node fallback for completeness.
  const binary =
    typeof atob === 'function'
      ? atob(base64)
      : Buffer.from(base64, 'base64').toString('binary')
  const len = binary.length
  const bytes = new Uint8Array(len)
  for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i) & 0xff
  return bytes
}

/**
 * Resolve a PDF source reference into a Uint8Array that pdf.js can consume.
 *
 * Accepts BOTH:
 *   • a base64 data URL  — `data:application/pdf;base64,XXXX`
 *   • a static file path — `/practice/Power_Maths_Geometry_Worksheet_1_Fundamentals.pdf`
 *     (served from /public). The PDF bytes are fetched via `fetch()` and
 *     read as an ArrayBuffer. This bypasses the localStorage ~5 MB cap so
 *     large pre-authored PDFs can ship with the app.
 */
async function resolvePdfSource(src: string): Promise<Uint8Array> {
  if (src.startsWith('data:')) {
    return dataUrlToUint8Array(src)
  }
  // Treat as a URL path (relative or absolute). Use the browser fetch API.
  const res = await fetch(src, { credentials: 'same-origin' })
  if (!res.ok) {
    throw new Error(`Failed to load PDF (${res.status} ${res.statusText}): ${src}`)
  }
  const buf = await res.arrayBuffer()
  return new Uint8Array(buf)
}

export function usePdfPages(fileDataUrl: string | undefined): UsePdfPagesResult {
  const [pages, setPages] = React.useState<PdfPage[]>([])
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    // Reset state whenever the input changes.
    setPages([])
    setError(null)

    if (!fileDataUrl) {
      setLoading(false)
      return
    }

    let cancelled = false
    const controller = new AbortController()

    setLoading(true)

    ;(async () => {
      try {
        // Dynamic-import pdfjs inside the effect so its top-level
        // `new DOMMatrix()` never runs during SSR. The explicit subpath is
        // bundled by Turbopack (bare `pdfjs-dist` is not).
        const pdfjsLib = await import('pdfjs-dist/build/pdf.mjs')

        // Configure the worker once per session.
        if (!workerConfigured) {
          pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs'
          workerConfigured = true
        }

        // v3.20.0: support BOTH base64 data URLs and /public file paths.
        const data = await resolvePdfSource(fileDataUrl)

        // `getDocument` may also accept a string URL or a Uint8Array.
        const loadingTask = pdfjsLib.getDocument({
          data,
          // Disable streaming fetches so we never touch the network.
          disableAutoFetch: true,
          disableStream: true,
        })
        if (controller.signal.aborted) {
          try { loadingTask.destroy() } catch { /* noop */ }
          return
        }

        const pdf = await loadingTask.promise
        if (cancelled) {
          try { pdf.destroy() } catch { /* noop */ }
          return
        }

        const numPages = pdf.numPages
        const renderedPages: PdfPage[] = []

        const scale = 1.5

        for (let i = 1; i <= numPages; i++) {
          if (cancelled) {
            try { pdf.destroy() } catch { /* noop */ }
            return
          }
          const page = await pdf.getPage(i)
          const viewport = page.getViewport({ scale })

          // Create an off-DOM canvas to render into.
          const canvas = document.createElement('canvas')
          const ctx = canvas.getContext('2d')
          if (!ctx) {
            throw new Error('Could not acquire a 2D canvas context for PDF rendering.')
          }
          canvas.width = Math.floor(viewport.width)
          canvas.height = Math.floor(viewport.height)

          // In pdfjs v6 the preferred param is `canvas`. We pass both
          // `canvas` and `canvasContext` for maximum compatibility across
          // v4/v5/v6 builds.
          await page.render({
            canvas,
            canvasContext: ctx,
            viewport,
          } as never).promise

          const dataUrl = canvas.toDataURL('image/png')

          renderedPages.push({
            content: (
              <img
                src={dataUrl}
                alt={`Page ${i} of ${numPages}`}
                className="mx-auto max-w-full h-auto"
                draggable={false}
              />
            ),
          })

          // Free the page's resources before moving on.
          try { page.cleanup() } catch { /* noop */ }
        }

        if (!cancelled) {
          setPages(renderedPages)
          setLoading(false)
        }

        try { pdf.destroy() } catch { /* noop */ }
      } catch (err) {
        if (cancelled) return
        const message = err instanceof Error ? err.message : String(err)
        setError(message || 'Failed to render PDF')
        setLoading(false)
      }
    })()

    return () => {
      cancelled = true
      controller.abort()
    }
  }, [fileDataUrl])

  return { pages, loading, error }
}

/**
 * Small helper component for showing a "loading protected document" state
 * while the PDF is being rasterised.
 */
export function PdfLoadingPlaceholder({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-sm font-medium">
        {label ?? 'Loading protected document…'}
      </p>
      <p className="text-xs text-muted-foreground">
        Decrypting &amp; rasterising pages for view-only display.
      </p>
    </div>
  )
}
