#!/bin/bash
# Fully detached dev server launcher — double-fork style so the process
# survives after this script (and the bash tool call) exits.
cd /home/z/my-project

# Kill any prior instances
pkill -f "next dev" 2>/dev/null
pkill -f "next-server" 2>/dev/null
sleep 1

# Launch in a brand-new session with ALL fds redirected away from the tool.
# Using Turbopack (default, no flag) — it compiles faster and served HTTP 200
# cleanly. Capped heap to avoid the OOM killer on this 3.9GB machine.
nohup setsid env NODE_OPTIONS="--max-old-space-size=1536" \
  ./node_modules/.bin/next dev -p 3000 \
  </dev/null >/home/z/my-project/dev.log 2>&1 &

disown
exit 0
