# Power Maths Portal — Deployment Guide

**Version:** v3.48.0
**Backup file:** `powermaths-v3.48.0-full-backup.zip`

This guide explains how to deploy the Power Maths portal on a fresh Linux
server using the included `deploy.sh` script.

---

## 🚀 Quick Start (5 steps)

### 1. Get a Linux VPS
- **Recommended:** Hetzner Cloud, DigitalOcean, or AWS Lightsail
- **Specs:** 1 vCPU, 2 GB RAM, 20 GB disk (Ubuntu 22.04+ or Debian 12+)
- **Cost:** ~$5–6/month

### 2. Point your domain to the server
In your domain registrar's DNS settings (GoDaddy, Cloudflare, Namecheap):
- Add an **A record**: `@` → `your-server-IP`
- (Optional) Add `www` → `your-server-IP`

Wait 5–10 minutes for DNS to propagate.

### 3. Upload the backup zip to your server
From your local machine:
```bash
scp powermaths-v3.48.0-full-backup.zip root@YOUR-SERVER-IP:/root/
```

### 4. SSH into the server & unzip
```bash
ssh root@YOUR-SERVER-IP
unzip powermaths-v3.48.0-full-backup.zip -d /root/powermaths
cd /root/powermaths
```

### 5. Run the deploy script
```bash
sudo bash deploy.sh --domain powermaths.com --zip /root/powermaths-v3.48.0-full-backup.zip
```

That's it! The script will:
1. Install Bun, Caddy, PM2, and all dependencies
2. Extract your project to `/var/www/powermaths`
3. Install Node packages (`bun install`)
4. Set up the SQLite database
5. Build Next.js for production
6. Start the app under PM2 (auto-restarts, survives reboots)
7. Configure Caddy with automatic HTTPS (free SSL certificate)

When it finishes, visit **`https://powermaths.com`** 🎉

---

## 📋 Prerequisites

| Requirement | Details |
|---|---|
| **OS** | Ubuntu 22.04+ / Debian 12+ (fresh install) |
| **RAM** | 2 GB minimum (1 GB works but build may be slow) |
| **Disk** | 10 GB free |
| **Access** | Root or sudo user |
| **Domain** | A registered domain with DNS pointing to your server |
| **Backup zip** | `powermaths-v3.48.0-full-backup.zip` uploaded to the server |

---

## 🛠️ deploy.sh — All Options

```bash
sudo bash deploy.sh [OPTIONS]

Options:
  --domain <domain>        Your domain (e.g. powermaths.com). Required for HTTPS.
  --zip <path>             Path to your backup zip
  --app-dir <path>         Install directory (default: /var/www/powermaths)
  --app-port <port>        Internal port (default: 3000)
  --no-bun                 Skip Bun install (use existing Node/Bun)
  --no-caddy               Skip Caddy install (set up proxy yourself)
  --no-pm2                 Skip PM2 install (use systemd instead)
  --yes / -y               Non-interactive (use defaults, don't prompt)
  --help                   Show this help message
```

### Examples

**Full auto with domain:**
```bash
sudo bash deploy.sh --domain powermaths.com --zip ./powermaths-v3.48.0-full-backup.zip
```

**Non-interactive (for CI/CD):**
```bash
sudo bash deploy.sh --domain powermaths.com --zip ./backup.zip --yes
```

**No domain (HTTP only — testing):**
```bash
sudo bash deploy.sh --zip ./backup.zip --yes
```

**Use existing project directory (no zip):**
```bash
sudo bash deploy.sh --app-dir /var/www/powermaths --domain powermaths.com
```

---

## 📦 What Gets Installed

| Software | Purpose | Auto-installed? |
|---|---|---|
| **Bun 1.3+** | Runtime + package manager | ✅ Yes |
| **Node.js LTS** | Required by PM2 | ✅ Yes (if PM2 enabled) |
| **Caddy** | Reverse proxy + auto HTTPS | ✅ Yes |
| **PM2** | Process manager (auto-restart) | ✅ Yes |
| **UFW firewall** | Security (SSH/HTTP/HTTPS only) | ✅ Yes |
| **SQLite** | Database (file-based, no server) | ✅ Built into Bun |

**No separate database server needed!** SQLite is a single file at
`/var/www/powermaths/db/custom.db`.

---

## 🔧 Post-Deployment Commands

### View app status & logs
```bash
pm2 status                    # list running apps
pm2 logs powermaths           # live logs (Ctrl+C to exit)
pm2 logs powermaths --lines 100   # last 100 lines
```

### Restart / stop the app
```bash
pm2 restart powermaths        # restart after code update
pm2 stop powermaths           # stop
pm2 delete powermaths         # remove from PM2
```

### Caddy (web server)
```bash
sudo systemctl status caddy           # status
sudo systemctl reload caddy           # reload after Caddyfile change
sudo caddy validate --config /etc/caddy/Caddyfile   # validate config
sudo journalctl -u caddy -f           # Caddy logs
```

### Database
```bash
cd /var/www/powermaths
sudo -u powermaths bun run db:push       # apply schema changes
sudo -u powermaths bun run db:generate   # regenerate Prisma client
```

---

## 🔄 Updating the App (Redeploy)

When you have a new version of the code:

```bash
# 1. Upload the new backup zip to the server
scp powermaths-v3.49.0-full-backup.zip root@YOUR-SERVER-IP:/root/

# 2. SSH in and re-run deploy.sh (it's idempotent — overwrites safely)
ssh root@YOUR-SERVER-IP
sudo bash deploy.sh --domain powermaths.com --zip /root/powermaths-v3.49.0-full-backup.zip

# 3. Or, if you only changed source files (no new zip):
cd /var/www/powermaths
# (copy new src/ files here)
sudo -u powermaths bun run build
pm2 restart powermaths
```

---

## 🌐 DNS & SSL Notes

- **First HTTPS request triggers cert issuance.** Caddy automatically
  obtains a Let's Encrypt certificate the first time someone visits your
  domain. This takes ~10 seconds.
- **DNS must be correct first.** If DNS doesn't point to your server,
  Let's Encrypt validation fails. Verify with:
  ```bash
  dig +short powermaths.com   # should return your server IP
  ```
- **Port 80 & 443 must be open.** The script configures UFW for you.

---

## 🆘 Troubleshooting

### App not responding?
```bash
pm2 status                     # is powermaths running?
pm2 logs powermaths --lines 50 # check for errors
curl http://localhost:3000/    # test directly (bypass Caddy)
```

### SSL certificate not issuing?
```bash
sudo journalctl -u caddy -f    # watch Caddy try to get the cert
# Common causes:
#  - DNS A record not pointing to this server
#  - Ports 80/443 blocked by cloud provider firewall
#  - Domain already has SSL from another provider (remove it)
```

### Build runs out of memory (OOM)?
On a 1 GB RAM server, the Next.js build can OOM. Add swap:
```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
# Then re-run deploy.sh
```

### Permission denied on database?
```bash
sudo chown -R powermaths:powermaths /var/www/powermaths/db
pm2 restart powermaths
```

---

## 📁 Directory Layout After Deployment

```
/var/www/powermaths/
├── .next/
│   └── standalone/
│       └── server.js          ← production server entry
├── .env                       ← DATABASE_URL, NODE_ENV, PORT
├── db/
│   └── custom.db              ← SQLite database file
├── prisma/
│   └── schema.prisma          ← database schema
├── public/                    ← static assets
├── src/                       ← source code
├── package.json
├── deploy.sh                  ← this deployment script
└── worklog.md                 ← full development history
```

**PM2 config:** `/home/powermaths/.pm2/`
**Caddy config:** `/etc/caddy/Caddyfile`
**Caddy logs:** `sudo journalctl -u caddy`

---

## 💰 Monthly Cost Breakdown

| Item | Cost |
|---|---|
| VPS (2 GB RAM) | ~$5–6/month |
| Domain name | ~$10/year (~$1/month) |
| SSL certificate | **Free** (Let's Encrypt via Caddy) |
| SQLite database | **Free** (built-in) |
| **Total** | **~$6/month** |

---

## ✅ Production Checklist

- [ ] VPS provisioned (2 GB RAM recommended)
- [ ] Domain DNS A record → server IP
- [ ] Backup zip uploaded to server
- [ ] `deploy.sh` executed with `--domain`
- [ ] `https://yourdomain.com` loads in browser
- [ ] PM2 startup configured (auto-restart on reboot)
- [ ] Firewall enabled (UFW: SSH + HTTP + HTTPS)
- [ ] SSL padlock visible in browser

---

**Need help?** Check `pm2 logs powermaths` and `sudo journalctl -u caddy`
for detailed error messages. The full development history is in
`worklog.md` inside the backup zip.

Happy teaching! 🎉
