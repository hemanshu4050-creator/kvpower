#!/usr/bin/env bash
# ============================================================================
# Power Maths Portal — Production Deployment Script
# Version: v3.48.0
# ----------------------------------------------------------------------------
# Automates a full production deployment on a FRESH Linux server (Ubuntu
# 22.04+ / Debian 12+). It is safe to re-run (idempotent): it skips steps
# that are already done.
#
# WHAT THIS SCRIPT DOES:
#   1. Installs system dependencies (curl, unzip, git, Caddy)
#   2. Installs the Bun runtime + package manager
#   3. Uploads/extracts your backup zip (or uses an existing project dir)
#   4. Installs Node dependencies (bun install)
#   5. Pushes the Prisma schema to SQLite (creates db/custom.db)
#   6. Builds Next.js for production (.next/standalone/server.js)
#   7. Generates the Prisma Client
#   8. Starts the app under PM2 (auto-restart + survives reboot)
#   9. Configures Caddy as reverse proxy with automatic HTTPS
#  10. Prints the final URL + status
#
# USAGE:
#   sudo bash deploy.sh                          # full auto, asks for domain
#   sudo bash deploy.sh --domain powermaths.com  # pre-set domain
#   sudo bash deploy.sh --zip ./powermaths-v3.48.0-full-backup.zip
#   sudo bash deploy.sh --app-dir /var/www/powermaths --domain powermaths.com
#
# REQUIREMENTS:
#   - A fresh Ubuntu 22.04+ / Debian 12+ VPS with root/sudo access
#   - A registered domain name pointed (A record) to this server's IP
#   - Your backup zip uploaded to the server (optional — script can use an
#     existing project directory instead)
#
# AFTER FIRST RUN, the app is reachable at https://YOUR-DOMAIN
# ============================================================================

set -Eeuo pipefail

# ── Defaults (override with flags) ──────────────────────────────────────────
APP_NAME="powermaths"
APP_DIR="/var/www/powermaths"
APP_PORT="3000"
DOMAIN=""
ZIP_FILE=""
NODE_USER="powermaths"
INSTALL_BUN="yes"
INSTALL_CADDY="yes"
INSTALL_PM2="yes"
NON_INTERACTIVE="no"

# ── Color helpers (only if terminal supports them) ──────────────────────────
if [[ -t 1 ]] && [[ -z "${NO_COLOR:-}" ]]; then
    GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
    BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
else
    GREEN=''; YELLOW=''; RED=''; BLUE=''; BOLD=''; NC=''
fi

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
info() { echo -e "${BLUE}[i]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*" >&2; }
step() { echo -e "\n${BOLD}${BLUE}── $* ──${NC}"; }

# ── Parse arguments ──────────────────────────────────────────────────────────
usage() {
    cat <<EOF
Power Maths Portal — Production Deployment Script (v3.48.0)

USAGE:
    sudo bash deploy.sh [OPTIONS]

OPTIONS:
    --domain <domain>        Your domain (e.g. powermaths.com). Required for HTTPS.
    --zip <path>             Path to your backup zip (powermaths-v3.48.0-full-backup.zip)
    --app-dir <path>         Install directory (default: /var/www/powermaths)
    --app-port <port>        Internal port (default: 3000)
    --no-bun                 Skip Bun install (use existing Node/Bun)
    --no-caddy               Skip Caddy install (you'll set up the proxy yourself)
    --no-pm2                 Skip PM2 install (use bare bun start)
    --yes / -y               Non-interactive (use defaults, don't prompt)

EXAMPLES:
    sudo bash deploy.sh --domain powermaths.com \\
        --zip ./powermaths-v3.48.0-full-backup.zip

    sudo bash deploy.sh --app-dir /var/www/powermaths --domain powermaths.com -y
EOF
    exit 1
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --domain)       DOMAIN="$2"; shift 2 ;;
        --zip)          ZIP_FILE="$2"; shift 2 ;;
        --app-dir)      APP_DIR="$2"; shift 2 ;;
        --app-port)     APP_PORT="$2"; shift 2 ;;
        --no-bun)       INSTALL_BUN="no"; shift ;;
        --no-caddy)     INSTALL_CADDY="no"; shift ;;
        --no-pm2)       INSTALL_PM2="no"; shift ;;
        --yes|-y)       NON_INTERACTIVE="yes"; shift ;;
        --help|-h)      usage ;;
        *) err "Unknown option: $1"; usage ;;
    esac
done

# ── Preflight checks ─────────────────────────────────────────────────────────
preflight() {
    step "Preflight checks"

    # Must be root (for apt + caddy + pm2 systemd unit)
    if [[ $EUID -ne 0 ]]; then
        err "This script must be run as root (use sudo)."
        exit 1
    fi
    log "Running as root"

    # OS detection
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        info "OS: ${PRETTY_NAME:-unknown}"
        case "${ID:-}" in
            ubuntu|debian) log "Supported OS family (apt)" ;;
            *) warn "OS '${ID:-}' is not Ubuntu/Debian — apt-based steps may fail. Proceeding anyway." ;;
        esac
    else
        warn "Could not detect OS. Assuming apt-based Linux."
    fi

    # Architecture
    ARCH=$(uname -m)
    info "Architecture: ${ARCH}"
    case "$ARCH" in
        x86_64|aarch64|arm64) log "Supported architecture" ;;
        *) warn "Architecture '$ARCH' may not have a Bun build. Proceeding anyway." ;;
    esac

    # Memory (warn if < 1 GB)
    if [[ -f /proc/meminfo ]]; then
        MEM_KB=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo 0)
        MEM_MB=$(( MEM_KB / 1024 ))
        if (( MEM_MB < 1024 )); then
            warn "Only ${MEM_MB} MB RAM detected. Next.js build needs ~1.5 GB."
            warn "Consider adding swap: sudo fallocate -l 2G /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile"
        else
            log "RAM: ${MEM_MB} MB"
        fi
    fi

    # Domain check
    if [[ -z "$DOMAIN" && "$INSTALL_CADDY" == "yes" ]]; then
        if [[ "$NON_INTERACTIVE" == "yes" ]]; then
            warn "No --domain provided. Caddy will serve on :80 without a domain (no HTTPS)."
            DOMAIN="_"
        else
            printf '%bEnter your domain name (e.g. powermaths.com) or press Enter to skip HTTPS:%b ' "$BOLD" "$NC"
            read -r DOMAIN
            DOMAIN="${DOMAIN:-_}"
        fi
    fi
    if [[ "$DOMAIN" == "_" ]]; then
        info "No domain set — Caddy will listen on :80 (HTTP only, no SSL)."
    else
        log "Domain: ${DOMAIN}"
        # Resolve domain to check it points here
        PUBLIC_IP=$(curl -s4 https://ifconfig.me 2>/dev/null || curl -s4 https://api.ipify.org 2>/dev/null || echo "unknown")
        info "This server's public IP: ${PUBLIC_IP}"
        if command -v dig &>/dev/null; then
            DOMAIN_IP=$(dig +short "$DOMAIN" 2>/dev/null | head -1 || echo "")
            if [[ -n "$DOMAIN_IP" && "$DOMAIN_IP" != "$PUBLIC_IP" ]]; then
                warn "DNS for ${DOMAIN} resolves to ${DOMAIN_IP}, but this server is ${PUBLIC_IP}."
                warn "Make sure your A record points to ${PUBLIC_IP} before enabling HTTPS."
            elif [[ -n "$DOMAIN_IP" ]]; then
                log "DNS for ${DOMAIN} correctly points to this server."
            fi
        fi
    fi

    # Zip file check
    if [[ -n "$ZIP_FILE" ]]; then
        if [[ ! -f "$ZIP_FILE" ]]; then
            err "Backup zip not found: $ZIP_FILE"
            exit 1
        fi
        log "Backup zip: $ZIP_FILE"
    elif [[ ! -d "$APP_DIR/src" ]]; then
        # No zip AND no existing app — error
        err "No --zip provided and $APP_DIR does not contain a project."
        err "Either pass --zip <path-to-backup.zip> or --app-dir <existing-project-dir>."
        exit 1
    else
        info "Using existing project directory: $APP_DIR"
    fi
}

# ── Step 1: Install system packages ──────────────────────────────────────────
install_system_deps() {
    step "Installing system dependencies"

    export DEBIAN_FRONTEND=noninteractive

    apt-get update -y
    apt-get install -y \
        curl \
        unzip \
        git \
        ca-certificates \
        gnupg \
        build-essential \
        python3

    if [[ "$INSTALL_CADDY" == "yes" ]]; then
        # Caddy official repo
        if ! command -v caddy &>/dev/null; then
            info "Installing Caddy from official repository..."
            apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
            curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
                | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null || true
            curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
                | tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
            apt-get update -y
            apt-get install -y caddy
            log "Caddy installed: $(caddy version 2>/dev/null | head -1)"
        else
            log "Caddy already installed: $(caddy version 2>/dev/null | head -1)"
        fi
    else
        info "Skipping Caddy install (--no-caddy)"
    fi

    log "System dependencies ready"
}

# ── Step 2: Install Bun ───────────────────────────────────────────────────────
install_bun() {
    [[ "$INSTALL_BUN" == "no" ]] && { info "Skipping Bun install (--no-bun)"; return; }

    step "Installing Bun runtime"

    if command -v bun &>/dev/null; then
        log "Bun already installed: $(bun --version)"
        return
    fi

    info "Installing Bun for root..."
    curl -fsSL https://bun.sh/install | bash

    # Source bun env so it's on PATH for this script
    export BUN_INSTALL="$HOME/.bun"
    export PATH="$BUN_INSTALL/bin:$PATH"

    # Make bun available system-wide for all users
    ln -sf "$BUN_INSTALL/bin/bun" /usr/local/bin/bun

    log "Bun installed: $(bun --version)"
}

# ── Step 3: Create unprivileged user + extract project ──────────────────────
setup_app_dir() {
    step "Setting up application directory"

    # Create dedicated unprivileged user (if missing)
    if ! id "$NODE_USER" &>/dev/null; then
        useradd --system --create-home --home-dir "/home/$NODE_USER" --shell /bin/bash "$NODE_USER"
        log "Created system user: $NODE_USER"
    else
        log "User $NODE_USER already exists"
    fi

    # Create app directory
    mkdir -p "$APP_DIR"

    if [[ -n "$ZIP_FILE" ]]; then
        info "Extracting $ZIP_FILE → $APP_DIR"
        # Extract to a temp dir first, then rsync to preserve ownership
        TMP_EXTRACT=$(mktemp -d)
        unzip -q -o "$ZIP_FILE" -d "$TMP_EXTRACT"
        # Copy contents (the zip has src/, package.json, etc. at root)
        cp -r "$TMP_EXTRACT"/. "$APP_DIR"/
        rm -rf "$TMP_EXTRACT"
        log "Project extracted to $APP_DIR"
    else
        info "Using existing project at $APP_DIR"
    fi

    # Ensure the database directory exists
    mkdir -p "$APP_DIR/db"

    # Fix the .env DATABASE_URL path to match this deployment
    if [[ -f "$APP_DIR/.env" ]]; then
        info "Updating .env DATABASE_URL for this deployment..."
        sed -i "s|^DATABASE_URL=.*|DATABASE_URL=file:$APP_DIR/db/custom.db|" "$APP_DIR/.env"
        log ".env updated → DATABASE_URL=file:$APP_DIR/db/custom.db"
    else
        warn ".env not found in backup. Creating a default one."
        cat > "$APP_DIR/.env" <<EOF
DATABASE_URL=file:$APP_DIR/db/custom.db
NODE_ENV=production
PORT=$APP_PORT
EOF
        log "Created .env"
    fi

    # Set ownership
    chown -R "$NODE_USER":"$NODE_USER" "$APP_DIR"
    log "Ownership set to $NODE_USER:$NODE_USER"
}

# ── Step 4: Install Node dependencies ────────────────────────────────────────
install_deps() {
    step "Installing Node dependencies (bun install)"

    cd "$APP_DIR"

    if [[ ! -f package.json ]]; then
        err "package.json not found in $APP_DIR. Extraction may have failed."
        exit 1
    fi

    # Run as the unprivileged user (not root) — better security
    info "Running bun install as $NODE_USER..."
    sudo -u "$NODE_USER" -H bash -lc "cd '$APP_DIR' && bun install --frozen-lockfile 2>&1 || bun install" || {
        warn "bun install with frozen lockfile failed; retrying without --frozen-lockfile"
        sudo -u "$NODE_USER" -H bash -lc "cd '$APP_DIR' && bun install"
    }

    log "Dependencies installed"
}

# ── Step 5: Generate Prisma Client + push schema ─────────────────────────────
setup_database() {
    step "Setting up SQLite database (Prisma)"

    cd "$APP_DIR"

    info "Generating Prisma Client..."
    sudo -u "$NODE_USER" -H bash -lc "cd '$APP_DIR' && bun run db:generate" || {
        err "Prisma client generation failed."
        exit 1
    }
    log "Prisma Client generated"

    info "Pushing schema to SQLite (creates $APP_DIR/db/custom.db if missing)..."
    sudo -u "$NODE_USER" -H bash -lc "cd '$APP_DIR' && bun run db:push" || {
        err "Prisma db push failed. Check prisma/schema.prisma and .env"
        exit 1
    }
    log "Database schema applied"

    # Ensure the SQLite file is owned by the app user
    chown -R "$NODE_USER":"$NODE_USER" "$APP_DIR/db"
    log "Database file ownership set"
}

# ── Step 6: Build for production ─────────────────────────────────────────────
build_app() {
    step "Building Next.js for production (standalone)"

    cd "$APP_DIR"

    # The build is memory-heavy; allow more heap on small servers
    info "Running bun run build (this may take 2–5 minutes)..."
    sudo -u "$NODE_USER" -H bash -lc \
        "cd '$APP_DIR' && NODE_OPTIONS='--max-old-space-size=1536' bun run build" || {
        err "Next.js build failed."
        err "If this is an OOM, add swap: sudo fallocate -l 2G /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile"
        exit 1
    }

    if [[ -f "$APP_DIR/.next/standalone/server.js" ]]; then
        log "Standalone server built: .next/standalone/server.js"
    else
        err "Build completed but .next/standalone/server.js is missing."
        err "Make sure next.config.ts has output: 'standalone'"
        exit 1
    fi

    # Copy static assets (the build script already does cp -r, but double-check)
    if [[ -d "$APP_DIR/.next/static" && ! -d "$APP_DIR/.next/standalone/.next/static" ]]; then
        cp -r "$APP_DIR/.next/static" "$APP_DIR/.next/standalone/.next/"
    fi
    if [[ -d "$APP_DIR/public" && ! -d "$APP_DIR/.next/standalone/public" ]]; then
        cp -r "$APP_DIR/public" "$APP_DIR/.next/standalone/"
    fi
    chown -R "$NODE_USER":"$NODE_USER" "$APP_DIR/.next"
    log "Static assets in place"
}

# ── Step 7: Install PM2 + start app ──────────────────────────────────────────
start_app() {
    step "Starting app under PM2"

    if [[ "$INSTALL_PM2" == "yes" ]]; then
        # PM2 needs Node. Bun can run it, but PM2 itself prefers Node.
        # Install Node LTS if not present (PM2 dependency).
        if ! command -v node &>/dev/null; then
            info "Installing Node.js LTS (required by PM2)..."
            curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
            apt-get install -y nodejs
            log "Node.js installed: $(node --version)"
        else
            log "Node.js already installed: $(node --version)"
        fi

        if ! command -v pm2 &>/dev/null; then
            info "Installing PM2 globally..."
            npm install -g pm2
        else
            log "PM2 already installed: $(pm2 --version)"
        fi

        PM2_BIN=$(command -v pm2)

        # Stop existing app if re-deploying
        sudo -u "$NODE_USER" -H bash -lc "$PM2_BIN delete $APP_NAME 2>/dev/null || true"

        info "Starting app: $APP_NAME on port $APP_PORT..."
        sudo -u "$NODE_USER" -H bash -lc \
            "cd '$APP_DIR' && $PM2_BIN start 'bun .next/standalone/server.js' \
                --name $APP_NAME \
                --env production \
                -- --port $APP_PORT \
                || $PM2_BIN start '$APP_DIR/.next/standalone/server.js' --name $APP_NAME"

        # Save PM2 process list + configure startup on boot
        sudo -u "$NODE_USER" -H bash -lc "$PM2_BIN save"
        info "Configuring PM2 to start on boot..."
        $PM2_BIN startup systemd -u "$NODE_USER" --hp "/home/$NODE_USER" 2>/dev/null || \
            $PM2_BIN startup systemd 2>/dev/null || true

        log "App started under PM2 (name: $APP_NAME)"
        sudo -u "$NODE_USER" -H bash -lc "$PM2_BIN status"
    else
        info "Skipping PM2 (--no-pm2). Starting app directly..."
        # Start with systemd instead
        cat > "/etc/systemd/system/${APP_NAME}.service" <<EOF
[Unit]
Description=Power Maths Portal (Next.js standalone)
After=network.target

[Service]
Type=simple
User=$NODE_USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=PORT=$APP_PORT
Environment=DATABASE_URL=file:$APP_DIR/db/custom.db
ExecStart=$(command -v bun) $APP_DIR/.next/standalone/server.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable "$APP_NAME"
        systemctl restart "$APP_NAME"
        log "App started via systemd (service: $APP_NAME)"
        systemctl --no-pager status "$APP_NAME" || true
    fi

    # Wait for the app to respond
    info "Waiting for app to respond on port $APP_PORT..."
    for i in {1..30}; do
        if curl -s -o /dev/null -w "" "http://localhost:$APP_PORT/" 2>/dev/null; then
            HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$APP_PORT/" 2>/dev/null || echo "000")
            if [[ "$HTTP_CODE" == "200" || "$HTTP_CODE" == "307" || "$HTTP_CODE" == "302" ]]; then
                log "App is responding (HTTP $HTTP_CODE) on port $APP_PORT"
                return
            fi
        fi
        sleep 2
    done
    warn "App did not respond within 60 seconds. Check logs: pm2 logs $APP_NAME"
}

# ── Step 8: Configure Caddy reverse proxy + HTTPS ────────────────────────────
setup_caddy() {
    [[ "$INSTALL_CADDY" == "no" ]] && { info "Skipping Caddy setup (--no-caddy)"; return; }

    step "Configuring Caddy reverse proxy"

    if ! command -v caddy &>/dev/null; then
        err "Caddy is not installed. Run without --no-caddy, or install it manually."
        return
    fi

    CADDYFILE="/etc/caddy/Caddyfile"

    # Backup existing Caddyfile
    if [[ -f "$CADDYFILE" ]]; then
        cp "$CADDYFILE" "${CADDYFILE}.bak.$(date +%s)"
    fi

    if [[ "$DOMAIN" == "_" || -z "$DOMAIN" ]]; then
        # No domain — HTTP only on port 80
        cat > "$CADDYFILE" <<EOF
# Power Maths Portal — HTTP only (no domain configured)
:80 {
    reverse_proxy localhost:$APP_PORT {
        header_up Host {host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
        header_up X-Real-IP {remote_host}
    }
}
EOF
        info "Caddy configured for HTTP on :80 (no SSL — no domain set)"
    else
        # With a domain — Caddy auto-issues a Let's Encrypt SSL cert
        cat > "$CADDYFILE" <<EOF
# Power Maths Portal — HTTPS with automatic Let's Encrypt certificates
$DOMAIN {
    # Redirect www → root (optional, safe to keep)
    @www host www.$DOMAIN
    redir @www https://$DOMAIN{uri} permanent

    reverse_proxy localhost:$APP_PORT {
        header_up Host {host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
        header_up X-Real-IP {remote_host}
    }

    # Compression + sane timeouts
    encode zstd gzip
    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Content-Type-Options nosniff
        X-Frame-Options SAMEORIGIN
        Referrer-Policy strict-origin-when-cross-origin
    }
}
EOF
        info "Caddy configured for https://$DOMAIN (auto-HTTPS)"
    fi

    # Validate + reload
    info "Validating Caddyfile..."
    if caddy validate --config "$CADDYFILE"; then
        log "Caddyfile is valid"
    else
        err "Caddyfile validation failed. Review $CADDYFILE"
        return
    fi

    systemctl enable caddy
    systemctl reload caddy || systemctl restart caddy
    log "Caddy reloaded"

    # Make sure Caddy can read its data dir
    chown -R caddy:caddy /var/lib/caddy 2>/dev/null || true
}

# ── Step 9: Firewall (optional, best-effort) ─────────────────────────────────
setup_firewall() {
    step "Configuring firewall (UFW)"

    if ! command -v ufw &>/dev/null; then
        apt-get install -y ufw
    fi

    # Allow SSH, HTTP, HTTPS
    ufw allow OpenSSH 2>/dev/null || ufw allow 22/tcp 2>/dev/null || true
    ufw allow 80/tcp 2>/dev/null || true
    ufw allow 443/tcp 2>/dev/null || true

    # Enable firewall (non-interactive)
    yes | ufw enable 2>/dev/null || true
    log "Firewall enabled (SSH, HTTP, HTTPS allowed)"
    ufw status 2>/dev/null || true
}

# ── Final report ─────────────────────────────────────────────────────────────
print_report() {
    step "Deployment complete!"

    PUBLIC_IP=$(curl -s4 https://ifconfig.me 2>/dev/null || echo "your-server-ip")

    echo -e "${GREEN}${BOLD}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}${BOLD}║  Power Maths Portal v3.48.0 — Deployed Successfully     ║${NC}"
    echo -e "${GREEN}${BOLD}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BOLD}Application:${NC}"
    echo "  • Directory : $APP_DIR"
    echo "  • Port      : $APP_PORT (internal)"
    echo "  • Process   : ${APP_NAME} (under $([ "$INSTALL_PM2" == "yes" ] && echo "PM2" || echo "systemd"))"
    echo "  • Database  : SQLite at $APP_DIR/db/custom.db"
    echo "  • User      : $NODE_USER"
    echo ""
    echo -e "${BOLD}Access URLs:${NC}"
    if [[ "$DOMAIN" == "_" || -z "$DOMAIN" ]]; then
        echo -e "  • ${YELLOW}http://${PUBLIC_IP}${NC}  (HTTP only — no domain configured)"
        echo -e "  • ${YELLOW}http://localhost:80${NC}     (on this server)"
    else
        echo -e "  • ${GREEN}https://${DOMAIN}${NC}  ← primary URL (auto-HTTPS)"
        echo -e "  • ${GREEN}http://${DOMAIN}${NC}   (redirects to HTTPS)"
    fi
    echo ""
    echo -e "${BOLD}Useful commands:${NC}"
    if [[ "$INSTALL_PM2" == "yes" ]]; then
        echo "  pm2 status              # see running apps"
        echo "  pm2 logs $APP_NAME       # view live logs"
        echo "  pm2 restart $APP_NAME    # restart after code update"
        echo "  pm2 stop $APP_NAME       # stop the app"
    else
        echo "  systemctl status $APP_NAME     # see status"
        echo "  journalctl -u $APP_NAME -f     # view live logs"
        echo "  systemctl restart $APP_NAME    # restart"
    fi
    echo "  sudo systemctl reload caddy     # reload Caddy after Caddyfile edit"
    echo "  sudo caddy validate --config /etc/caddy/Caddyfile"
    echo ""
    if [[ "$DOMAIN" != "_" && -n "$DOMAIN" ]]; then
        echo -e "${YELLOW}${BOLD}Next steps:${NC}"
        echo "  1. Make sure DNS A record for $DOMAIN → $PUBLIC_IP"
        echo "  2. Wait 5–10 min for SSL cert provisioning (first request triggers it)"
        echo "  3. Visit https://$DOMAIN in your browser"
        echo ""
    fi
    echo -e "${GREEN}Done. Happy teaching! 🎉${NC}"
}

# ── Main ─────────────────────────────────────────────────────────────────────
main() {
    echo -e "${BOLD}${BLUE}"
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║  Power Maths Portal — Production Deployment (v3.48.0)     ║"
    echo "║  by Prof. Kalpesh Vyas                                    ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    preflight
    install_system_deps
    install_bun
    setup_app_dir
    install_deps
    setup_database
    build_app
    start_app
    setup_caddy
    setup_firewall
    print_report
}

main "$@"
